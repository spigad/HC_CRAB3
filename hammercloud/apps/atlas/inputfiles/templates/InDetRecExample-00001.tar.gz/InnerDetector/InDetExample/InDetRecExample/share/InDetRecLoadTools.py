# ------------------------------------------------------------
# 
# ----------- Loading the Tracking Services 
#
# ------------------------------------------------------------

# --- load cabling (if needed)
include("InDetRecExample/InDetRecCabling.py")

# ------------------------------------------------------------
#
# ----------- Loading of Tracking Tools
#
# ------------------------------------------------------------

#
# ----------- control loading of ROT_creator
#
if InDetFlags.loadRotCreator():
    #
    # load SCT ROT creator, we overwrite the defaults for it
    #
    from SiClusterOnTrackTool.SiClusterOnTrackToolConf import InDet__SCT_ClusterOnTrackTool
    SCT_ClusterOnTrackTool = InDet__SCT_ClusterOnTrackTool ("InDetSCT_ClusterOnTrackTool",
                                                            CorrectionStrategy = 0,  # do correct position bias
                                                            ErrorStrategy      = 2)  # do use phi dependent errors
    ToolSvc += SCT_ClusterOnTrackTool
    if (InDetFlags.doPrintConfigurables()):
      print      SCT_ClusterOnTrackTool
    #
    # default ROT creator, not smart !
    #
    from TrkRIO_OnTrackCreator.TrkRIO_OnTrackCreatorConf import Trk__RIO_OnTrackCreator
    InDetRotCreator = Trk__RIO_OnTrackCreator(name            = 'InDetRotCreator',
                                              ToolSCT_Cluster = SCT_ClusterOnTrackTool,
                                              Mode            = 'indet')
    ToolSvc += InDetRotCreator
    if (InDetFlags.doPrintConfigurables()):
      print      InDetRotCreator
    #
    # tool to always make conservative pixel cluster errors
    from SiClusterOnTrackTool.SiClusterOnTrackToolConf import InDet__PixelClusterOnTrackTool
    BroadPixelClusterOnTrackTool = InDet__PixelClusterOnTrackTool("InDetBroadPixelClusterOnTrackTool",
                                                                  ErrorStrategy = 0)
    ToolSvc += BroadPixelClusterOnTrackTool
    #
    # tool to always make conservative sct cluster errors
    #
    from SiClusterOnTrackTool.SiClusterOnTrackToolConf import InDet__SCT_ClusterOnTrackTool
    BroadSCT_ClusterOnTrackTool = InDet__SCT_ClusterOnTrackTool ("InDetBroadSCT_ClusterOnTrackTool",
                                                                 CorrectionStrategy = 0,  # do correct position bias
                                                                 ErrorStrategy      = 0)  # do use broad errors
    ToolSvc += BroadSCT_ClusterOnTrackTool

    from TrkRIO_OnTrackCreator.TrkRIO_OnTrackCreatorConf import Trk__RIO_OnTrackCreator
    BroadInDetRotCreator = Trk__RIO_OnTrackCreator(name            = 'InDetBroadInDetRotCreator',
                                                   ToolPixelCluster=BroadPixelClusterOnTrackTool,
                                                   ToolSCT_Cluster = BroadSCT_ClusterOnTrackTool,
                                                   Mode            = 'indet')
    ToolSvc += BroadInDetRotCreator

    if rec.Commissioning():
      InDetRotCreator.ToolPixelCluster=BroadPixelClusterOnTrackTool
      InDetRotCreator.ToolSCT_Cluster=BroadSCT_ClusterOnTrackTool

    #
    # load error scaling
    #
    from IOVDbSvc.CondDB import conddb
    conddb.addFolder("INDET","/Indet/TrkErrorScaling")
    #
    # smart ROT creator in case we do the TRT LR in the refit
    #
    if InDetFlags.redoTRT_LR():

        from TRT_DriftCircleOnTrackTool.TRT_DriftCircleOnTrackToolConf import InDet__TRT_DriftCircleOnTrackUniversalTool
        if rec.Commissioning():
            ScaleHitUncertainty = 5
        else:
            ScaleHitUncertainty = 2.5
        TRT_RefitRotCreator = InDet__TRT_DriftCircleOnTrackUniversalTool(name                = 'InDetTRT_RefitRotCreator',
                                                                         ScaleHitUncertainty = ScaleHitUncertainty) # fix from Thijs
        ToolSvc += TRT_RefitRotCreator
        if (InDetFlags.doPrintConfigurables()):
          print      TRT_RefitRotCreator
        
        from TrkRIO_OnTrackCreator.TrkRIO_OnTrackCreatorConf import Trk__RIO_OnTrackCreator
        InDetRefitRotCreator = Trk__RIO_OnTrackCreator(name                = 'InDetRefitRotCreator',
                                                       ToolSCT_Cluster     = SCT_ClusterOnTrackTool,
                                                       ToolTRT_DriftCircle = TRT_RefitRotCreator,
                                                       Mode                = 'indet')
        if rec.Commissioning():
            InDetRefitRotCreator.ToolPixelCluster=BroadPixelClusterOnTrackTool
            InDetRefitRotCreator.ToolSCT_Cluster=BroadSCT_ClusterOnTrackTool

        ToolSvc += InDetRefitRotCreator
        if (InDetFlags.doPrintConfigurables()):
          print      InDetRefitRotCreator
                            
    else:
        InDetRefitRotCreator = InDetRotCreator

#
# ----------- control loading of the kalman updator
#
if InDetFlags.loadUpdator() :
    
    if InDetFlags.kalmanUpdator() is "fast" :
        from TrkMeasurementUpdator_xk.TrkMeasurementUpdator_xkConf import Trk__KalmanUpdator_xk
        InDetUpdator = Trk__KalmanUpdator_xk(name = 'InDetUpdator')
    elif InDetFlags.kalmanUpdator() is "weight" :
        from TrkMeasurementUpdator.TrkMeasurementUpdatorConf import Trk__KalmanWeightUpdator as ConfiguredWeightUpdator
        InDetUpdator = ConfiguredWeightUpdator(name='InDetUpdator')
    else :
        from TrkMeasurementUpdator.TrkMeasurementUpdatorConf import Trk__KalmanUpdator as ConfiguredKalmanUpdator
        InDetUpdator = ConfiguredKalmanUpdator(name = 'InDetUpdator')
    ToolSvc += InDetUpdator
    if (InDetFlags.doPrintConfigurables()):
      print      InDetUpdator
    #
    # ---------- control loading of the gsf updator
    #
    if InDetFlags.trackFitterType() is 'GaussianSumFilter' :
        #
        # Load the Gsf Measurement Updator
        #
        from TrkGaussianSumFilter.TrkGaussianSumFilterConf import Trk__GsfMeasurementUpdator
        InDetGsfMeasurementUpdator = Trk__GsfMeasurementUpdator( name    = 'InDetGsfMeasurementUpdator',
                                                            Updator = InDetUpdator )
        ToolSvc += InDetGsfMeasurementUpdator
        if (InDetFlags.doPrintConfigurables()):
          print      InDetGsfMeasurementUpdator
        
#
# ----------- control laoding extrapolation
#
if InDetFlags.loadExtrapolator():
    #
    # Magnetic field tool
    #
    if InDetFlags.magField() is "fast" :
        from TrkMagFieldTools_xk.TrkMagFieldTools_xkConf import Trk__MagneticFieldTool_xk
        InDetMagField = Trk__MagneticFieldTool_xk('InDetMagField')
    else:
        from TrkMagFieldTools.TrkMagFieldToolsConf import Trk__MagneticFieldTool
        InDetMagField = Trk__MagneticFieldTool('InDetMagField')
    ToolSvc += InDetMagField
    if (InDetFlags.doPrintConfigurables()):
      print      InDetMagField
    #
    # set up geometry
    #
    if InDetFlags.doBeamHalo() or InDetFlags.doCosmics():
        from InDetTrackingGeometry.InDetTrackingGeometryConf import InDet__TRT_VolumeBuilder
        TRT_VolumeBuilder = InDet__TRT_VolumeBuilder(name='TRT_VolumeBuilder',
                                                     FullGeometryFromGeoModel=True) 
        ToolSvc += TRT_VolumeBuilder
        print      TRT_VolumeBuilder

    include('TrkDetDescrSvc/AtlasTrackingGeometrySvc.py')
    from AthenaCommon.AppMgr import ServiceMgr as svcMgr
    AtlasTrackingGeometrySvc = svcMgr.AtlasTrackingGeometrySvc
    
    #
    # get propagator
    #
    if InDetFlags.propagatorType() is "STEP":
        from TrkExSTEP_Propagator.TrkExSTEP_PropagatorConf import Trk__STEP_Propagator as Propagator
    else:
        from TrkExRungeKuttaPropagator.TrkExRungeKuttaPropagatorConf import Trk__RungeKuttaPropagator as Propagator
    #   
    InDetPropagator = Propagator(name = 'InDetPropagator')
    if InDetFlags.propagatorType() is "RungeKutta":
        InDetPropagator.AccuracyParameter = 0.0001
    ToolSvc += InDetPropagator
    
    # set up the propagator for outside ID (A.S. needed as a fix for 14.5.0 )
    from TrkExSTEP_Propagator.TrkExSTEP_PropagatorConf import Trk__STEP_Propagator as StepPropagator
    InDetStepPropagator = StepPropagator(name = 'InDetStepPropagator')
    ToolSvc += InDetStepPropagator
    
    if (InDetFlags.doPrintConfigurables()):
      print      InDetPropagator
    #
    # Setup the Navigator (default, could be removed)
    #
    from TrkExTools.TrkExToolsConf import Trk__Navigator
    InDetNavigator = Trk__Navigator(name                = 'InDetNavigator',
                                    TrackingGeometrySvc = AtlasTrackingGeometrySvc)
    ToolSvc += InDetNavigator
    if (InDetFlags.doPrintConfigurables()):
      print      InDetNavigator
    #
    # Setup the MaterialEffectsUpdator
    #
    from TrkExTools.TrkExToolsConf import Trk__MaterialEffectsUpdator
    InDetMaterialUpdator = Trk__MaterialEffectsUpdator(name = "InDetMaterialEffectsUpdator")
    if not InDetFlags.solenoidOn():
      InDetMaterialUpdator.EnergyLoss = False
      InDetMaterialUpdator.ForceMomentum = True
      InDetMaterialUpdator.ForcedMomentumValue = 1000*MeV

    ToolSvc += InDetMaterialUpdator
    
    if (InDetFlags.doPrintConfigurables()):
      print      InDetMaterialUpdator
      
    # CONFIGURE PROPAGATORS/UPDATORS ACCORDING TO GEOMETRY SIGNATURE
       
    InDetSubPropagators = []
    InDetSubUpdators = []
       
    # -------------------- set it depending on the geometry ----------------------------------------------------
    # default for ID is (Rk,Mat)
    InDetSubPropagators += [ InDetPropagator.name() ]
    InDetSubUpdators    += [ InDetMaterialUpdator.name() ]
       
    # default for Calo is (Rk,MatLandau)
    InDetSubPropagators += [ InDetPropagator.name() ]
    InDetSubUpdators    += [ InDetMaterialUpdator.name() ]
       
    # default for MS is (STEP,Mat)
    InDetSubPropagators += [ InDetStepPropagator.name() ]
    InDetSubUpdators    += [ InDetMaterialUpdator.name() ]
    # ----------------------------------------------------------------------------------------------------------            
      
    #
    # set up extrapolator
    #
    from TrkExTools.TrkExToolsConf import Trk__Extrapolator
    InDetExtrapolator = Trk__Extrapolator(name                    = 'InDetExtrapolator',
                                          Propagators             = [ InDetPropagator, InDetStepPropagator ],
                                          MaterialEffectsUpdators = [ InDetMaterialUpdator ],
                                          Navigator               = InDetNavigator,
                                          SubPropagators          = InDetSubPropagators,
                                          SubMEUpdators           = InDetSubUpdators,
                                          DoCaloDynamic           = False)
    ToolSvc += InDetExtrapolator
    if (InDetFlags.doPrintConfigurables()):
      print      InDetExtrapolator  

#
# ----------- control loading of fitters
#
if InDetFlags.loadFitter():

    if InDetFlags.trackFitterType() is 'KalmanFitter' or InDetFlags.trackFitterType() is 'KalmanDNAFitter':

        if InDetFlags.trackFitterType() is 'KalmanDNAFitter':
            from TrkDynamicNoiseAdjustor.TrkDynamicNoiseAdjustorConf import Trk__InDetDynamicNoiseAdjustment
            InDetDNAdjustor = Trk__InDetDynamicNoiseAdjustment(name       = 'InDetDNAdjustor',
                                                               signifmin  = 2.0,
                                                               lambdaxmin = 2.0)
            ToolSvc += InDetDNAdjustor
            if (InDetFlags.doPrintConfigurables()):
              print      InDetDNAdjustor
            
            from InDetDNASeparator.InDetDNASeparatorConf import InDet__InDetDNASeparator
            InDetDNASeparator = InDet__InDetDNASeparator(name="InDetDNASeparator")
            
            ToolSvc += InDetDNASeparator
            if (InDetFlags.doPrintConfigurables()):
              print      InDetDNASeparator
            
        else:
            InDetDNAdjustor = None
            InDetDNASeparator = None
            
        # Load Kalman Filter tools
        from TrkKalmanFitter.TrkKalmanFitterConf import Trk__ForwardKalmanFitter as PublicFKF
        InDetFKF = PublicFKF(name                  = 'InDetFKF',
                             StateChi2PerNDFPreCut = 30.0)
        ToolSvc += InDetFKF
        if (InDetFlags.doPrintConfigurables()):
          print      InDetFKF
        from TrkKalmanFitter.TrkKalmanFitterConf import Trk__KalmanSmoother as PublicBKS
        InDetBKS = PublicBKS(name                        = 'InDetBKS',
                             InitialCovarianceSeedFactor = 200.)
        ToolSvc += InDetBKS
        if (InDetFlags.doPrintConfigurables()):
          print      InDetBKS
        from TrkKalmanFitter.TrkKalmanFitterConf import Trk__KalmanOutlierLogic as PublicKOL
        InDetKOL = PublicKOL(name                    = 'InDetKOL',
                             TrackChi2PerNDFCut      = 17.0,
                             StateChi2PerNDFCut      = 12.5,
                             BroadPixelClusterHandle = BroadPixelClusterOnTrackTool)
        ToolSvc += InDetKOL
        if (InDetFlags.doPrintConfigurables()):
          print      InDetKOL

        from TrkKalmanFitter.TrkKalmanFitterConf import Trk__MeasRecalibSteeringTool_TRT
        InDetTRT_MeasRecalibST = Trk__MeasRecalibSteeringTool_TRT(name='InDetTRT_MeasRecalibST')
        ToolSvc += InDetTRT_MeasRecalibST
        if (InDetFlags.doPrintConfigurables()):
          print      InDetTRT_MeasRecalibST

        from TrkKalmanFitter.TrkKalmanFitterConf import Trk__KalmanFitter as ConfiguredKalmanFitter
        InDetTrackFitter = ConfiguredKalmanFitter(name                           = 'InDetTrackFitter',
                                                  ExtrapolatorHandle             = InDetExtrapolator,
                                                  RIO_OnTrackCreatorHandle       = InDetRefitRotCreator,
                                                  MeasurementUpdatorHandle       = InDetUpdator,
                                                  ForwardKalmanFitterHandle      = InDetFKF,
                                                  KalmanSmootherHandle           = InDetBKS,
                                                  KalmanOutlierLogicHandle       = InDetKOL,
                                                  DynamicNoiseAdjustorHandle     = InDetDNAdjustor,
                                                  BrempointAnalyserHandle        = InDetDNASeparator,
                                                  AlignableSurfaceProviderHandle = None,
                                                  RecalibratorHandle             = InDetTRT_MeasRecalibST)

        #    InDetTrackFitter.doHitSorting = False # by default it's on.
    elif InDetFlags.trackFitterType() is 'DistributedKalmanFilter' :
        from TrkDistributedKalmanFilter.TrkDistributedKalmanFilterConf import Trk__DistributedKalmanFilter
        InDetTrackFitter = Trk__DistributedKalmanFilter(name             = 'InDetTrackFitter',
                                                        MagFieldTool     = InDetMagField,    
                                                        ExtrapolatorTool = InDetExtrapolator,
                                                        ROTcreator       = InDetRotCreator
                                                        #sortingReferencePoint = ???
                                                        )
    elif InDetFlags.trackFitterType() is 'GlobalChi2Fitter' :

        # do we use smart material effects
        if InDetFlags.useNewGlobalChi2Tuning() :
            SmartMaterialEffects = True
            TrackChi2PerNDFCut   = 3.5
            TRTExtensionCuts     = True
        else:
            SmartMaterialEffects = False
            TrackChi2PerNDFCut   = 10.
            TRTExtensionCuts     = False

        from TrkGlobalChi2Fitter.TrkGlobalChi2FitterConf import Trk__GlobalChi2Fitter
        InDetTrackFitter = Trk__GlobalChi2Fitter(name                  = 'InDetTrackFitter',
                                                 ExtrapolationTool     = InDetExtrapolator,
                                                 NavigatorTool         = InDetNavigator,
                                                 PropagatorTool        = InDetPropagator,
                                                 RotCreatorTool        = InDetRefitRotCreator,
                                                 BroadRotCreatorTool   = BroadInDetRotCreator,
                                                 MeasurementUpdateTool = InDetUpdator,
                                                 StraightLine          = not InDetFlags.solenoidOn(),
                                                 ExternalMatTools      = True,
                                                 OutlierCut            = 3.0,
                                                 NumericalDerivs       = False,
                                                 SignedDriftRadius     = True,
                                                 CopyCircleRIOs        = False,
                                                 ReintegrateOutliers   = True,
                                                 MaxIterations         = 10,
                                                 RecalculateDerivatives= InDetFlags.doCosmics(),
                                                 TRTExtensionCuts      = TRTExtensionCuts,
                                                 TrackChi2PerNDFCut    = TrackChi2PerNDFCut,
                                                 SmartMaterialEffects  = SmartMaterialEffects)
        if InDetFlags.doRefit():
            InDetTrackFitter.ReintegrateOutliers = False
        if rec.Commissioning():
            #InDetTrackFitter.BroadRotCreatorTool=None
            InDetTrackFitter.OutlierCut=5.0
            InDetTrackFitter.MaxIterations= 20
        if InDetFlags.materialInteractions() and not InDetFlags.solenoidOn():
            InDetTrackFitter.Momentum=1000.*MeV
        InDetTrackFitterLowPt = Trk__GlobalChi2Fitter(name                  = 'InDetTrackFitterLowPt',
                                                      ExtrapolationTool     = InDetExtrapolator,
                                                      NavigatorTool         = InDetNavigator,
                                                      PropagatorTool        = InDetPropagator,
                                                      RotCreatorTool        = InDetRefitRotCreator,
                                                      BroadRotCreatorTool   = BroadInDetRotCreator,
                                                      MeasurementUpdateTool = InDetUpdator,
                                                      StraightLine          = not InDetFlags.solenoidOn(),
                                                      ExternalMatTools      = True,
                                                      OutlierCut            = 3.0,
                                                      NumericalDerivs       = False,
                                                      SignedDriftRadius     = True,
                                                      CopyCircleRIOs        = False,
                                                      ReintegrateOutliers   = True,
                                                      MaxIterations         = 10,
                                                      TRTExtensionCuts      = TRTExtensionCuts,
                                                      TrackChi2PerNDFCut    = TrackChi2PerNDFCut,
                                                      SmartMaterialEffects  = SmartMaterialEffects,
                                                      LowPt                 = True)


        InDetTrackFitterTRT = Trk__GlobalChi2Fitter(name                  = 'InDetTrackFitterTRT',
                                                    ExtrapolationTool     = InDetExtrapolator,
                                                    NavigatorTool         = InDetNavigator,
                                                    PropagatorTool        = InDetPropagator,
                                                    RotCreatorTool        = InDetRefitRotCreator,
                                                    MeasurementUpdateTool = InDetUpdator,
                                                    StraightLine          = not InDetFlags.solenoidOn(),
                                                    ReintegrateOutliers   = True,
                                                    ConvergenceCut        = 0,
                                                    MaxIterations         = 30,
                                                    MinimizationMethod    = 2,
                                                    RecalculateDerivatives= True,
                                                    TrackChi2PerNDFCut    = TrackChi2PerNDFCut)

        if InDetFlags.materialInteractions() and not InDetFlags.solenoidOn():
            InDetTrackFitterTRT.Momentum=1000.*MeV

        if InDetFlags.doRefit():
            InDetTrackFitterTRT.ReintegrateOutliers = False

    elif InDetFlags.trackFitterType() is 'GaussianSumFilter' :
        #
        # Material effects for the Gsf Extrapolator
        #
        from TrkGaussianSumFilter.TrkGaussianSumFilterConf import Trk__GsfMaterialMixtureConvolution
        InDetGsfMaterialUpdator = Trk__GsfMaterialMixtureConvolution (name = 'InDetGsfMaterialUpdator')
        ToolSvc += InDetGsfMaterialUpdator
        if (InDetFlags.doPrintConfigurables()):
          print      InDetGsfMaterialUpdator
        #
        # component Reduction
        #
        from TrkGaussianSumFilter.TrkGaussianSumFilterConf import Trk__CloseComponentsMultiStateMerger
        InDetGsfComponentReduction = Trk__CloseComponentsMultiStateMerger (name                      = 'InDetGsfComponentReduction',
                                                                      MaximumNumberOfComponents = 12)
        ToolSvc += InDetGsfComponentReduction
        if (InDetFlags.doPrintConfigurables()):
          print      InDetGsfComponentReduction
        #
        # declare the extrapolator
        #
        from TrkGaussianSumFilter.TrkGaussianSumFilterConf import Trk__GsfExtrapolator
        InDetGsfExtrapolator = Trk__GsfExtrapolator(name                          = 'InDetGsfExtrapolator',
                                               Propagators                   = [ InDetPropagator ],
                                               SearchLevelClosestParameters  = 10,
                                               StickyConfiguration           = True,
                                               Navigator                     = InDetNavigator,
                                               GsfMaterialConvolution        = InDetGsfMaterialUpdator,
                                               ComponentMerger               = InDetGsfComponentReduction,
                                               SurfaceBasedMaterialEffects   = False )
        ToolSvc += InDetGsfExtrapolator
        if (InDetFlags.doPrintConfigurables()):
          print      InDetGsfExtrapolator
        # load alternative track fitter
        from TrkGaussianSumFilter.TrkGaussianSumFilterConf import Trk__GaussianSumFitter
        InDetTrackFitter = Trk__GaussianSumFitter(name                    = 'InDetTrackFitter',
                                                  ToolForExtrapolation    = InDetGsfExtrapolator,
                                                  MeasurementUpdatorType  = InDetGsfMeasurementUpdator,
                                                  ToolForROTCreation      = InDetRotCreator,
                                                  ReintegrateOutliers     = False,
                                                  MakePerigee             = True,
                                                  RefitOnMeasurementBase  = True,
                                                  DoHitSorting            = True)
    # --- end of fitter loading
    ToolSvc += InDetTrackFitter
    if (InDetFlags.doPrintConfigurables()):
      print      InDetTrackFitter
                                                                     
    if InDetFlags.trackFitterType() is not 'GlobalChi2Fitter' :
      InDetTrackFitterTRT=InDetTrackFitter
      InDetTrackFitterLowPt=InDetTrackFitter

    ToolSvc += InDetTrackFitterTRT
    if (InDetFlags.doPrintConfigurables()):
      print      InDetTrackFitterTRT

    ToolSvc+=InDetTrackFitterLowPt
    if (InDetFlags.doPrintConfigurables()):
      print      InDetTrackFitterLowPt
#
# ----------- load association tool from Inner Detector to handle pixel ganged ambiguities
#
if InDetFlags.loadAssoTool():

    from InDetAssociationTools.InDetAssociationToolsConf import InDet__InDetPRD_AssociationToolGangedPixels
    InDetPrdAssociationTool = InDet__InDetPRD_AssociationToolGangedPixels(name                           = "InDetPrdAssociationTool",
                                                                          PixelClusterAmbiguitiesMapName = InDetKeys.GangedPixelMap())
    ToolSvc += InDetPrdAssociationTool
    if (InDetFlags.doPrintConfigurables()):
      print      InDetPrdAssociationTool

    if InDetFlags.doCosmics():
      InDetPrdAssociationTool_CTB = InDet__InDetPRD_AssociationToolGangedPixels(name                           = "InDetPrdAssociationTool_CTB",
                                                                                PixelClusterAmbiguitiesMapName = InDetKeys.GangedPixelMap())
      ToolSvc += InDetPrdAssociationTool_CTB
      if (InDetFlags.doPrintConfigurables()):
        print      InDetPrdAssociationTool_CTB


#
# ----------- control loading of SummaryTool
#
if InDetFlags.loadSummaryTool():
    #
    # Loading Configurable HoleSearchTool
    #
    from InDetTrackHoleSearch.InDetTrackHoleSearchConf import InDet__InDetTrackHoleSearchTool
    InDetHoleSearchTool = InDet__InDetTrackHoleSearchTool(name = "InDetHoleSearchTool",
                                                          Extrapolator = InDetExtrapolator,
                                                          usePixel      = DetFlags.haveRIO.pixel_on(),
                                                          useSCT        = DetFlags.haveRIO.SCT_on())
    if (DetFlags.haveRIO.SCT_on()):
      InDetHoleSearchTool.SctSummarySvc = InDetSCT_ConditionsSummarySvc
    else:
      InDetHoleSearchTool.SctSummarySvc = None

    if InDetFlags.doCosmics:
        InDetHoleSearchTool.Cosmics = True

    ToolSvc += InDetHoleSearchTool
    if (InDetFlags.doPrintConfigurables()):
      print      InDetHoleSearchTool
    #
    # Configrable version of loading the InDetTrackSummaryHelperTool
    #
    from InDetTrackSummaryHelperTool.InDetTrackSummaryHelperToolConf import InDet__InDetTrackSummaryHelperTool
    InDetTrackSummaryHelperTool = InDet__InDetTrackSummaryHelperTool(name         = "InDetSummaryHelper",
                                                                     AssoTool     = InDetPrdAssociationTool,
                                                                     DoSharedHits = False,
                                                                     HoleSearch   = InDetHoleSearchTool)
    ToolSvc += InDetTrackSummaryHelperTool
    if (InDetFlags.doPrintConfigurables()):
      print      InDetTrackSummaryHelperTool                                                                   
    

    if InDetFlags.doCosmics():
        from InDetTrackSummaryHelperTool.InDetTrackSummaryHelperToolConf import InDet__InDetTrackSummaryHelperTool
        InDetTrackSummaryHelperToolCosmics = InDet__InDetTrackSummaryHelperTool(name         = "InDetSummaryHelperCosmics",
                                                                                HoleSearch   = InDetHoleSearchTool,
                                                                                DoSharedHits = False)
        ToolSvc += InDetTrackSummaryHelperToolCosmics
        if (InDetFlags.doPrintConfigurables()):
            print      InDetTrackSummaryHelperToolCosmics                                                                   
    
    #
    # Configurable version of TRT_ElectronPidTools
    #
    from IOVDbSvc.CondDB import conddb
    conddb.addFolder("TRT","/TRT/Calib/PID")
    conddb.addFolder('TRT','/TRT/Calib/PID_RToT')
    from TRT_ElectronPidTools.TRT_ElectronPidToolsConf import InDet__TRT_ElectronPidTool
    InDetTRT_ElectronPidTool = InDet__TRT_ElectronPidTool(name = "InDetTRT_ElectronPidTool")
    if InDetFlags.trackFitterType() is "KalmanDNAFitter":
       InDetTRT_ElectronPidTool.DNAfitterEnabled = True  
    ToolSvc += InDetTRT_ElectronPidTool
    if (InDetFlags.doPrintConfigurables()):
      print      InDetTRT_ElectronPidTool
    
    #
    # Configurable version of TrkTrackSummaryTool: no TRT_PID tool needed here (no shared hits)
    #
    from TrkTrackSummaryTool.TrkTrackSummaryToolConf import Trk__TrackSummaryTool
    InDetTrackSummaryTool = Trk__TrackSummaryTool(name = "InDetTrackSummaryTool",
                                                  InDetSummaryHelperTool = InDetTrackSummaryHelperTool,
                                                  doSharedHits           = False,
                                                  InDetHoleSearchTool    = InDetHoleSearchTool)
    #InDetTrackSummaryTool.OutputLevel = DEBUG
    ToolSvc += InDetTrackSummaryTool
    if (InDetFlags.doPrintConfigurables()):
      print      InDetTrackSummaryTool


    if InDetFlags.doCosmics():
        from TrkTrackSummaryTool.TrkTrackSummaryToolConf import Trk__TrackSummaryTool
        InDetTrackSummaryToolCosmics = Trk__TrackSummaryTool(name = "InDetTrackSummaryToolCosmics",
                                                             InDetSummaryHelperTool = InDetTrackSummaryHelperToolCosmics,
                                                             InDetHoleSearchTool    = InDetHoleSearchTool)

        ToolSvc += InDetTrackSummaryToolCosmics
        if (InDetFlags.doPrintConfigurables()):
            print      InDetTrackSummaryToolCosmics

        from InDetTrackScoringTools.InDetTrackScoringToolsConf import InDet__InDetCosmicScoringTool
        InDetScoringToolCosmics = InDet__InDetCosmicScoringTool(name         = 'InDetCosmicScoringTool',
                                                                SummaryTool  = InDetTrackSummaryToolCosmics)
        
        ToolSvc += InDetScoringToolCosmics
        if (InDetFlags.doPrintConfigurables()):
            print      InDetScoringToolCosmics

        from InDetTrackScoringTools.InDetTrackScoringToolsConf import InDet__InDetCosmicScoringTool
        InDetScoringToolCosmics_SiPattern = InDet__InDetCosmicScoringTool(name         = 'InDetCosmicScoringTool_SiPattern',
                                                                          nWeightedClustersMin = InDetCutValues.nWeightedClustersMin(),
                                                                          minTRTHits = 0,
                                                                          SummaryTool  = InDetTrackSummaryToolCosmics)
        
        ToolSvc += InDetScoringToolCosmics_SiPattern
        if (InDetFlags.doPrintConfigurables()):
            print      InDetScoringToolCosmics_SiPattern

        from InDetTrackScoringTools.InDetTrackScoringToolsConf import InDet__InDetCosmicScoringTool
        InDetScoringToolCosmics_TRT= InDet__InDetCosmicScoringTool(name         = 'InDetCosmicScoringTool_TRT',
                                                                   nWeightedClustersMin = 0,
                                                                   minTRTHits = InDetCutValues.minTRTonTrkCosmics(),
                                                                   SummaryTool  = InDetTrackSummaryToolCosmics)
        
        ToolSvc += InDetScoringToolCosmics_TRT
        if (InDetFlags.doPrintConfigurables()):
            print      InDetScoringToolCosmics_TRT



    #
    # --- we may need another instance for shared hits computation
    #
    if InDetFlags.doSharedHits():
        #
        # Configrable version of loading the InDetTrackSummaryHelperTool
        #
        from InDetTrackSummaryHelperTool.InDetTrackSummaryHelperToolConf import InDet__InDetTrackSummaryHelperTool
        InDetTrackSummaryHelperToolSharedHits = InDet__InDetTrackSummaryHelperTool(name         = "InDetSummaryHelperSharedHits",
                                                                                   AssoTool     = InDetPrdAssociationTool,
                                                                                   DoSharedHits = InDetFlags.doSharedHits(),
                                                                                   HoleSearch   = InDetHoleSearchTool)
        ToolSvc += InDetTrackSummaryHelperToolSharedHits
        if (InDetFlags.doPrintConfigurables()):
          print      InDetTrackSummaryHelperToolSharedHits
        #
        # Configurable version of TrkTrackSummaryTool
        #
        from TrkTrackSummaryTool.TrkTrackSummaryToolConf import Trk__TrackSummaryTool
        InDetTrackSummaryToolSharedHits = Trk__TrackSummaryTool(name = "InDetTrackSummaryToolSharedHits",
                                                                InDetSummaryHelperTool = InDetTrackSummaryHelperToolSharedHits,
                                                                doSharedHits           = InDetFlags.doSharedHits(),
                                                                InDetHoleSearchTool    = InDetHoleSearchTool,
                                                                TRT_ElectronPidTool    = InDetTRT_ElectronPidTool)
        #InDetTrackSummaryToolSharedHits.OutputLevel = DEBUG
        ToolSvc += InDetTrackSummaryToolSharedHits
        if (InDetFlags.doPrintConfigurables()):
          print      InDetTrackSummaryToolSharedHits

    else:   
        InDetTrackSummaryToolSharedHits        = InDetTrackSummaryTool

#
# ----------- control loading of tools which are needed by new tracking and backtracking
#
if InDetFlags.doNewTracking() or InDetFlags.doBeamGas() or InDetFlags.doBeamHalo() or InDetFlags.doBackTracking() or InDetFlags.doTrtSegments() or InDetFlags.doTrackSegmentsPixel() or InDetFlags.doTrackSegmentsSCT() or InDetFlags.doTrackSegmentsTRT():
    #
    # Igors propagator needed by Igors tools
    #
    from TrkExRungeKuttaPropagator.TrkExRungeKuttaPropagatorConf import Trk__RungeKuttaPropagator as Propagator
    InDetPatternPropagator = Propagator(name = 'InDetPatternPropagator')
    ToolSvc += InDetPatternPropagator
    if (InDetFlags.doPrintConfigurables()):
      print      InDetPatternPropagator
    #
    # fast Kalman updator tool
    #
    from TrkMeasurementUpdator_xk.TrkMeasurementUpdator_xkConf import Trk__KalmanUpdator_xk
    InDetPatternUpdator = Trk__KalmanUpdator_xk(name = 'InDetPatternUpdator')
    ToolSvc += InDetPatternUpdator
    if (InDetFlags.doPrintConfigurables()):
      print      InDetPatternUpdator
    # 
    # field
    #
    from TrkMagFieldTools_xk.TrkMagFieldTools_xkConf import Trk__MagneticFieldTool_xk
    InDetPatternMagField = Trk__MagneticFieldTool_xk('InDetPatternMagField')
    ToolSvc += InDetPatternMagField
    if (InDetFlags.doPrintConfigurables()):
      print      InDetPatternMagField
    
    #
    # SCT and Pixel detector elements road builder
    #
    from SiDetElementsRoadTool_xk.SiDetElementsRoadTool_xkConf import InDet__SiDetElementsRoadMaker_xk
    InDetSiDetElementsRoadMaker = InDet__SiDetElementsRoadMaker_xk(name               = 'InDetSiRoadMaker',
                                                                   PropagatorTool     = InDetPatternPropagator,
                                                                   MagneticTool       = InDetPatternMagField,
                                                                   usePixel           = DetFlags.haveRIO.pixel_on(), 
                                                                   PixManagerLocation = InDetKeys.PixelManager(),
                                                                   useSCT             = DetFlags.haveRIO.SCT_on(), 
                                                                   SCTManagerLocation = InDetKeys.SCT_Manager())
    if InDetFlags.doCosmics():
        InDetSiDetElementsRoadMaker.RoadWidth          = 60.
        
    ToolSvc += InDetSiDetElementsRoadMaker
    if (InDetFlags.doPrintConfigurables()):
      print      InDetSiDetElementsRoadMaker
    
    #
    # TRT detector elements road builder
    #
    from TRT_DetElementsRoadTool_xk.TRT_DetElementsRoadTool_xkConf import InDet__TRT_DetElementsRoadMaker_xk
    InDetTRTDetElementsRoadMaker =  InDet__TRT_DetElementsRoadMaker_xk(name                  = 'InDetTRT_RoadMaker',
                                                                      DetectorStoreLocation = 'DetectorStore',
                                                                      TRTManagerLocation    = InDetKeys.TRT_Manager(),
                                                                      MagneticFieldMode     = 'MapSolenoid',
                                                                      MagneticTool          = InDetPatternMagField,
                                                                      PropagatorTool        = InDetPatternPropagator)
    ToolSvc += InDetTRTDetElementsRoadMaker
    if (InDetFlags.doPrintConfigurables()):
      print      InDetTRTDetElementsRoadMaker
    #
    # Local combinatorial track finding using space point seed and detector element road 
    #
    from SiCombinatorialTrackFinderTool_xk.SiCombinatorialTrackFinderTool_xkConf import InDet__SiCombinatorialTrackFinder_xk
    InDetSiComTrackFinder = InDet__SiCombinatorialTrackFinder_xk(name                  = 'InDetSiComTrackFinder',
                                                                 MagneticTool          = InDetPatternMagField,
                                                                 PropagatorTool        = InDetPatternPropagator,
                                                                 UpdatorTool           = InDetPatternUpdator,
                                                                 RIOonTrackTool        = InDetRotCreator,
                                                                 AssosiationTool       = InDetPrdAssociationTool,
                                                                 usePixel              = DetFlags.haveRIO.pixel_on(),
                                                                 useSCT                = DetFlags.haveRIO.SCT_on(),
                                                                 PixManagerLocation    = InDetKeys.PixelManager(),
                                                                 SCTManagerLocation    = InDetKeys.SCT_Manager(),
                                                                 PixelClusterContainer = InDetKeys.PixelClusters(),
                                                                 SCT_ClusterContainer  = InDetKeys.SCT_Clusters())

    if (DetFlags.haveRIO.SCT_on()):
      InDetSiComTrackFinder.SctSummarySvc = InDetSCT_ConditionsSummarySvc
    else:
      InDetSiComTrackFinder.SctSummarySvc = None
    ToolSvc += InDetSiComTrackFinder
    if (InDetFlags.doPrintConfigurables()):
      print      InDetSiComTrackFinder
    #
    # Track extension to TRT tool
    #
    if (DetFlags.haveRIO.TRT_on()):
      # if new tracking is OFF then xk extension type has to be used!!
      if (InDetFlags.trtExtensionType() is 'xk') or (not InDetFlags.doNewTracking()) :
        #
        # load normal extension code
        #
        from TRT_TrackExtensionTool_xk.TRT_TrackExtensionTool_xkConf import InDet__TRT_TrackExtensionTool_xk
        InDetTRTExtensionTool =  InDet__TRT_TrackExtensionTool_xk(name                  = 'InDetTRT_ExtensionTool',
                                                                  MagneticFieldMode     = 'MapSolenoid',      # default
                                                                  TRT_ClustersContainer = InDetKeys.TRT_DriftCircles(),
                                                                  TrtManagerLocation    = InDetKeys.TRT_Manager(),
                                                                  MagneticTool          = InDetPatternMagField,
                                                                  PropagatorTool        = InDetPatternPropagator,
                                                                  UpdatorTool           = InDetPatternUpdator, 
                                                                  RoadTool              = InDetTRTDetElementsRoadMaker,
                                                                  MinNumberDriftCircles = InDetCutValues.minTRTonTrk(),
                                                                  ScaleHitUncertainty   = 2.)
        if InDetFlags.doCosmics():
            from TRT_TrackExtensionTool_xk.TRT_TrackExtensionTool_xkConf import InDet__TRT_TrackExtensionToolCosmics
            InDetTRTExtensionToolCosmicsPhase =  InDet__TRT_TrackExtensionToolCosmics(name                  = 'InDetTRT_ExtensionToolCosmicsPhase',
                                                                                      Propagator        = InDetPropagator,
                                                                                      Extrapolator      = InDetExtrapolator,
                                                                                      TRT_ClustersContainer = InDetKeys.TRT_DriftCirclesUncalibrated(),
                                                                                      SearchNeighbour   = False, #needs debugging!!!
                                                                                      RoadWidth         = 20.) 

            ToolSvc += InDetTRTExtensionToolCosmicsPhase
            if (InDetFlags.doPrintConfigurables()):
                print      InDetTRTExtensionToolCosmicsPhase

            InDetTRTExtensionToolCosmics =  InDet__TRT_TrackExtensionToolCosmics(name                  = 'InDetTRT_ExtensionToolCosmics',
                                                                                 Propagator        = InDetPropagator,
                                                                                 Extrapolator      = InDetExtrapolator,
                                                                                 TRT_ClustersContainer = InDetKeys.TRT_DriftCircles(),
                                                                                 SearchNeighbour   = False, #needs debugging!!!
                                                                                 RoadWidth         = 20.) 

            ToolSvc += InDetTRTExtensionToolCosmics
            if (InDetFlags.doPrintConfigurables()):
                print      InDetTRTExtensionToolCosmics



      elif InDetFlags.trtExtensionType() is 'DAF' :
        #
        # laod TRT Competing ROT tool
        #
        from TrkDeterministicAnnealingFilter.TrkDeterministicAnnealingFilterConf import Trk__DAF_SimpleWeightCalculator
        InDetWeightCalculator =  Trk__DAF_SimpleWeightCalculator( name = 'InDetWeightCalculator')
        ToolSvc += InDetWeightCalculator
        if (InDetFlags.doPrintConfigurables()):
          print      InDetWeightCalculator
        #
        from InDetCompetingRIOsOnTrackTool.InDetCompetingRIOsOnTrackToolConf import InDet__CompetingTRT_DriftCirclesOnTrackTool
        InDetCompetingTRT_DC_Tool =  InDet__CompetingTRT_DriftCirclesOnTrackTool( name                                  = 'InDetCompetingTRT_DC_Tool',
                                                                                  MagneticFieldMode                     = 'MapSolenoid',      # default
                                                                                  MagneticTool                          = InDetPatternMagField,
                                                                                  PropagatorTool                        = InDetPatternPropagator,
                                                                                  ToolForWeightCalculation              = InDetWeightCalculator,
                                                                                  ToolForTRT_DriftCircleOnTrackCreation = InDetRefitRotCreator.ToolTRT_DriftCircle)
        ToolSvc += InDetCompetingTRT_DC_Tool
        if (InDetFlags.doPrintConfigurables()):
          print      InDetCompetingTRT_DC_Tool
  
        from TRT_TrackExtensionTool_DAF.TRT_TrackExtensionTool_DAFConf import InDet__TRT_TrackExtensionTool_DAF
        InDetTRTExtensionTool =  InDet__TRT_TrackExtensionTool_DAF(name                        = 'InDetTRT_ExtensionTool',
                                                                   MagneticFieldMode           = 'MapSolenoid',      # default
                                                                   TRT_DriftCircleContainer    = InDetKeys.TRT_DriftCircles(),
                                                                   CompetingDriftCircleTool    = InDetCompetingTRT_DC_Tool,
                                                                   MagneticTool                = InDetPatternMagField,
                                                                   PropagatorTool              = InDetPatternPropagator,
                                                                   RoadTool                    = InDetTRTDetElementsRoadMaker)
        
        
      ToolSvc += InDetTRTExtensionTool
      if (InDetFlags.doPrintConfigurables()):
        print      InDetTRTExtensionTool


#
# ------ load special Ambiguity tools for cosmics
#
if InDetFlags.doCosmics() and InDetFlags.doAmbiSolving():
    from InDetAmbiTrackSelectionTool.InDetAmbiTrackSelectionToolConf import InDet__InDetAmbiTrackSelectionTool
    InDetAmbiTrackSelectionToolCosmics = InDet__InDetAmbiTrackSelectionTool(name             = 'InDetAmbiTrackSelectionToolCosmics',
                                                                            AssociationTool  =  InDetPrdAssociationTool,
                                                                            minNotShared     = 3,
                                                                            minHits          = 0,
                                                                            maxShared = 0,
                                                                            maxTracksPerSharedPRD = 10,
                                                                            Cosmics=True)
    
    ToolSvc += InDetAmbiTrackSelectionToolCosmics
    if (InDetFlags.doPrintConfigurables()):
        print      InDetAmbiTrackSelectionToolCosmics


    from TrkAmbiguityProcessor.TrkAmbiguityProcessorConf import Trk__SimpleAmbiguityProcessorTool
    InDetAmbiguityProcessorCosmics = Trk__SimpleAmbiguityProcessorTool(name        = 'InDetAmbiguityProcessorCosmics',
                                                                       ScoringTool = InDetScoringToolCosmics,
                                                                       Fitter      = InDetTrackFitter,
                                                                       SelectionTool = InDetAmbiTrackSelectionToolCosmics,
                                                                       SuppressTrackFit = True,
                                                                       ForceRefit=False,
                                                                       RefitPrds   = False)
    
    ToolSvc += InDetAmbiguityProcessorCosmics
    if (InDetFlags.doPrintConfigurables()):
        print      InDetAmbiguityProcessorCosmics
        
        
#
# ------ load track selector for vertexing, needs to be done here because is also needed for vertex ntuple creation
#
if InDetFlags.doVertexFinding() or InDetFlags.doVtxNtuple():
  #
  # ------ load new track selector (common for all vertexing algorithms, except for the moment VKalVrt)
  #
  if (InDetFlags.useBeamConstraint()):
  
    from InDetTrackSelectorTool.InDetTrackSelectorToolConf import InDet__InDetDetailedTrackSelectorTool
    InDetTrackSelectorTool = InDet__InDetDetailedTrackSelectorTool(name = "InDetDetailedTrackSelectorTool",
                                                                   pTMin                = 500,
                                                                   IPd0Max              = 1,
                                                                   IPz0Max              = 1000,
                                                                   z0Max                = 1000,
                                                                   sigIPd0Max           = 0.35,
                                                                   sigIPz0Max           = 2.5,
                                                                   d0significanceMax    = 4.,
                                                                   z0significanceMax    = -1.,
                                                                   etaMax               = 9999.,
                                                                   useTrackSummaryInfo  = True,
                                                                   nHitBLayer           = 0,
                                                                   nHitPix              = 1,
                                                                   nHitBLayerPlusPix    = 0,
                                                                   nHitSct              = 5,
                                                                   nHitSi               = 7,
                                                                   nHitTrt              = 0,
                                                                   nHitTrtHighEFractionMax = 1,
                                                                   nHitTrtHighEFractionWithOutliersMax = 1,
                                                                   useSharedHitInfo     = False,
                                                                   useTrackQualityInfo  = True,
                                                                   fitChi2OnNdfMax      = 3.5,
                                                                   TrtMaxEtaAcceptance  = 1.9,
                                                                   TrackSummaryTool     = InDetTrackSummaryTool,
                                                                   Extrapolator         = InDetExtrapolator)
  else:
    from InDetTrackSelectorTool.InDetTrackSelectorToolConf import InDet__InDetDetailedTrackSelectorTool
    InDetTrackSelectorTool = InDet__InDetDetailedTrackSelectorTool(name = "InDetDetailedTrackSelectorTool",
                                                                   pTMin                = 500,
                                                                   IPd0Max              = 4,
                                                                   IPz0Max              = 1000,
                                                                   z0Max                = 1000,
                                                                   sigIPd0Max           = 0.35,
                                                                   sigIPz0Max           = 2.5,
                                                                   d0significanceMax    = -1.,#problem is that you cannot use the significance at all!
                                                                   z0significanceMax    = -1.,
                                                                   etaMax               = 9999.,
                                                                   useTrackSummaryInfo  = True,
                                                                   nHitBLayer           = 0,
                                                                   nHitPix              = 1,
                                                                   nHitBLayerPlusPix    = 0,
                                                                   nHitSct              = 5,
                                                                   nHitSi               = 7,
                                                                   nHitTrt              = 0,
                                                                   nHitTrtHighEFractionMax = 1,
                                                                   nHitTrtHighEFractionWithOutliersMax = 1,
                                                                   useSharedHitInfo     = False,
                                                                   useTrackQualityInfo  = True,
                                                                   fitChi2OnNdfMax      = 3.5,
                                                                   TrtMaxEtaAcceptance  = 1.9,
                                                                   TrackSummaryTool     = InDetTrackSummaryTool,
                                                                   Extrapolator         = InDetExtrapolator)
  
  # adjust some values if low pt tracking is also on
  if (InDetFlags.doLowPt()):
      InDetTrackSelectorTool.pTMin      = InDetCutValues.minLowPT()
      if (InDetFlags.useBeamConstraint()):
        InDetTrackSelectorTool.IPd0Max    = 2.5
      else:
        InDetTrackSelectorTool.IPd0Max    = 4.
      InDetTrackSelectorTool.sigIPd0Max = 0.9
      InDetTrackSelectorTool.nHitSct    = 4
      InDetTrackSelectorTool.nHitSi     = 6
      InDetTrackSelectorTool.useTrackQualityInfo = False
  
  ToolSvc += InDetTrackSelectorTool
  if (InDetFlags.doPrintConfigurables()):
    print      InDetTrackSelectorTool


