# ------------------------------------------------------------
#
# ----------- now we do the RTF tracking
#
# ------------------------------------------------------------
# minPt cut for the pixel stand alone tracking (it differs from ID tracking) 
if not InDetFlags.doCosmics():
  PixelStandAloneMinPtCut = 1. * GeV
else:
  PixelStandAloneMinPtCut = InDetCutValues.minPTCosmics()
#
#
# ----------- SiSPSeededTrackFinder
#
#
# Space points seeds maker
#
if not InDetFlags.doCosmics():
  from SiSpacePointsSeedTool_xk.SiSpacePointsSeedTool_xkConf import InDet__SiSpacePointsSeedMaker_ATLxk
  InDetSiSpacePointsSeedMakerPixel = InDet__SiSpacePointsSeedMaker_ATLxk(name                   = 'InDetSpSeedsMakerPixel',
                                                                         MagneticTool           = InDetPatternMagField,
                                                                         pTmin                  = PixelStandAloneMinPtCut, #InDetCutValues.minPT(),
                                                                         maxdImpact             = InDetCutValues.maxPrimaryImpact(),
                                                                         maxZ                   = InDetCutValues.maxZImpact(),
                                                                         minZ                   = -InDetCutValues.maxZImpact(),
                                                                         SpacePointsPixelName   = InDetKeys.PixelSpacePoints(),
                                                                         SpacePointsSCTName     = "",
                                                                         useOverlapSpCollection = False,
                                                                         SpacePointsOverlapName = "",
                                                                         useSCT                 = False)
  ToolSvc += InDetSiSpacePointsSeedMakerPixel
  if (InDetFlags.doPrintConfigurables()):
    print      InDetSiSpacePointsSeedMakerPixel
else:
  from SiSpacePointsSeedTool_xk.SiSpacePointsSeedTool_xkConf import InDet__SiSpacePointsSeedMaker_Cosmic
  InDetSiSpacePointsSeedMakerCosmicsPixel = InDet__SiSpacePointsSeedMaker_Cosmic(name                   = 'InDetSpSeedsMakerCosmicsPixel',
                                                                                 MagneticTool           = InDetPatternMagField,
                                                                                 pTmin                  = InDetCutValues.minPTCosmics(),
                                                                                 maxdImpact             = InDetCutValues.maxPrimaryImpactCosmics(),
                                                                                 maxZ                   = InDetCutValues.maxZImpactCosmics(),
                                                                                 minZ                   = -InDetCutValues.maxZImpactCosmics(),
                                                                                 SpacePointsPixelName   = InDetKeys.PixelSpacePoints(),
                                                                                 SpacePointsSCTName     = "",
                                                                                 useSCT                 = False, 
                                                                                 useOverlapSpCollection = False,
                                                                                 SpacePointsOverlapName = "",
                                                                                 UseAssociationTool     = False,
                                                                                 AssociationTool        = InDetPrdAssociationTool)
  ToolSvc += InDetSiSpacePointsSeedMakerCosmicsPixel
  if (InDetFlags.doPrintConfigurables()):
    print      InDetSiSpacePointsSeedMakerCosmicsPixel
         

#
# Z-coordinates primary vertices finder
#
if InDetFlags.useZvertexTool():
  from SiZvertexTool_xk.SiZvertexTool_xkConf import InDet__SiZvertexMaker_xk
  InDetZvertexMakerPixel = InDet__SiZvertexMaker_xk(name          = 'InDetZvertexMakerPixel',
                                                    SeedMakerTool = InDetSiSpacePointsSeedMakerPixel,
                                                    Zmax          = InDetCutValues.maxZImpact(),
                                                    Zmin          = -InDetCutValues.maxZImpact(),
                                                    minRatio      = 0.17) # not default
  ToolSvc += InDetZvertexMakerPixel
  if (InDetFlags.doPrintConfigurables()):
    print      InDetZvertexMakerPixel
else:
  InDetZvertexMakerPixel = None

#
# SCT and Pixel detector elements road builder
#
from SiDetElementsRoadTool_xk.SiDetElementsRoadTool_xkConf import InDet__SiDetElementsRoadMaker_xk
InDetSiDetElementsRoadMakerPixel = InDet__SiDetElementsRoadMaker_xk(name               = 'InDetSiRoadMakerPixel',
                                                              PropagatorTool     = InDetPatternPropagator,
                                                              MagneticTool       = InDetPatternMagField,
                                                              PixManagerLocation = InDetKeys.PixelManager(),
                                                              useSCT             = False, 
                                                              SCTManagerLocation = InDetKeys.SCT_Manager())
if InDetFlags.doCosmics():
  InDetSiDetElementsRoadMakerPixel.RoadWidth = 50

ToolSvc += InDetSiDetElementsRoadMakerPixel
if (InDetFlags.doPrintConfigurables()):
  print      InDetSiDetElementsRoadMakerPixel

#
# Local track finding using space point seed
#
from SiTrackMakerTool_xk.SiTrackMakerTool_xkConf import InDet__SiTrackMaker_xk
InDetSiTrackMakerPixel = InDet__SiTrackMaker_xk(name                     = 'InDetSiTrackMakerPixel',
                                                MagneticTool             = InDetPatternMagField,
                                                RoadTool                 = InDetSiDetElementsRoadMakerPixel,
                                                CombinatorialTrackFinder = InDetSiComTrackFinder,
                                                pTmin                    = PixelStandAloneMinPtCut, #InDetCutValues.minPT(),
                                                nClustersMin             = 3,
                                                nWeightedClustersMin     = 6, # and this is new
                                                nHolesMax                = 1,
                                                nHolesGapMax             = 1, 
                                                SeedsFilterLevel         = 2)
if InDetFlags.doCosmics():
  InDetSiTrackMakerPixel.CosmicTrack = True
  InDetSiTrackMakerPixel.GoodSeedClusterCount = 3
  InDetSiTrackMakerPixel.nHolesMax = InDetCutValues.maxHolesCosmics()

ToolSvc += InDetSiTrackMakerPixel
if (InDetFlags.doPrintConfigurables()):
  print      InDetSiTrackMakerPixel

#
# set output track collection name
OutputTrackCollection = "SiSPSeededPixelTracks"

#
# Setup Track finder using space points seeds
#
from SiSPSeededTrackFinder.SiSPSeededTrackFinderConf import InDet__SiSPSeededTrackFinder
InDetSiSPSeededTrackFinderPixel = InDet__SiSPSeededTrackFinder(name           = 'InDetSiSpTrackFinderPixel',
                                                          ZvertexTool    = InDetZvertexMakerPixel, 
                                                          TrackTool      = InDetSiTrackMakerPixel,
                                                          TracksLocation = OutputTrackCollection,
                                                          useZvertexTool = InDetFlags.useZvertexTool())
if not InDetFlags.doCosmics():    
  InDetSiSPSeededTrackFinderPixel.SeedsTool      = InDetSiSpacePointsSeedMakerPixel
else:
  InDetSiSPSeededTrackFinderPixel.SeedsTool      = InDetSiSpacePointsSeedMakerCosmicsPixel

topSequence += InDetSiSPSeededTrackFinderPixel
if (InDetFlags.doPrintConfigurables()):
  print          InDetSiSPSeededTrackFinderPixel

#
# set input collection for next algorithm
#
InputTrackCollection = OutputTrackCollection

if InDetFlags.doTruth():
  #
  # set collection name for truth
  #
  InputTrackCollectionTruth = "SiSPSeededPixelTracksTruthCollection"
  InputDetailedTrackTruth   = "SiSPSeededPixelTracksDetailedTruth"
  #
  # set up the truth info for this container
  #
  include ("InDetRecExample/ConfiguredInDetTrackTruth.py")
  InDetTracksTruth = ConfiguredInDetTrackTruth(InputTrackCollection,
                                                InputDetailedTrackTruth,
                                                InputTrackCollectionTruth)
  #
  # add final output for statistics
  #
  TrackCollectionKeys      += [ InputTrackCollection ]
  TrackCollectionTruthKeys += [ InputTrackCollectionTruth ]
#
# ---------- Ambiguity solving
#
if not InDetFlags.doAmbiSolving():
   InDetKeys.PixelTracks = OutputTrackCollection
else:
   #
   # load InnerDetector TrackSelectionTool
   #
   from InDetAmbiTrackSelectionTool.InDetAmbiTrackSelectionToolConf import InDet__InDetAmbiTrackSelectionTool
   InDetAmbiTrackSelectionToolPixel = InDet__InDetAmbiTrackSelectionTool(name            = 'InDetAmbiTrackSelectionToolPixel',
                                                                    AssociationTool = InDetPrdAssociationTool,
                                                                    minHits         = 3,
                                                                    minNotShared    = 3,
                                                                    maxShared       = 0,
                                                                    minTRTHits      = 0 ) # used for Si only tracking !!!
   if InDetFlags.doCosmics():
     InDetAmbiTrackSelectionToolPixel.Cosmics         = True
     InDetAmbiTrackSelectionToolPixel.maxShared = 3

   ToolSvc += InDetAmbiTrackSelectionToolPixel
   if (InDetFlags.doPrintConfigurables()):
     print      InDetAmbiTrackSelectionToolPixel
   #
   # set up Scoring Tool
   #
   if not InDetFlags.doCosmics():
     from InDetTrackScoringTools.InDetTrackScoringToolsConf import InDet__InDetAmbiScoringTool
     InDetAmbiScoringToolPixel = InDet__InDetAmbiScoringTool(name           = 'InDetAmbiScoringToolPixel',
                                                             Extrapolator   = InDetExtrapolator,
                                                             SummaryTool    = InDetTrackSummaryTool,
                                                             useAmbigFcn    = True,
                                                             useTRT_AmbigFcn= False,
                                                             minPt          = PixelStandAloneMinPtCut, #InDetCutValues.minPT(),
                                                             maxRPhiImp     = InDetCutValues.maxPrimaryImpact(),
                                                             maxZImp        = InDetCutValues.maxZImpact(),
                                                             maxEta         = InDetCutValues.maxEta(),
                                                             minSiClusters  = 3,
                                                             maxSiHoles     = 1,
                                                             maxDoubleHoles = 1,
                                                             minTRTonTrk    = 0,    # no TRT here
                                                             useSigmaChi2   = False)
                                                             # useSigmaChi2   = True) # use it for Si only
     
     
     #InDetAmbiScoringTool.OutputLevel = VERBOSE
     ToolSvc += InDetAmbiScoringToolPixel
     if (InDetFlags.doPrintConfigurables()):
       print      InDetAmbiScoringToolPixel

   #
   # load Ambiguity Processor
   #
   from TrkAmbiguityProcessor.TrkAmbiguityProcessorConf import Trk__SimpleAmbiguityProcessorTool
   InDetAmbiguityProcessorPixel = Trk__SimpleAmbiguityProcessorTool(name          = 'InDetAmbiguityProcessorPixel',
                                                               Fitter        = InDetTrackFitter,
                                                               SelectionTool = InDetAmbiTrackSelectionToolPixel,
                                                               RefitPrds     = not InDetFlags.refitROT(),
                                                               SuppressHoleSearch = True)
   if InDetFlags.materialInteractions():
      InDetAmbiguityProcessorPixel.MatEffects = 3
   else:
      InDetAmbiguityProcessorPixel.MatEffects = 0

   if not InDetFlags.doCosmics():
     InDetAmbiguityProcessorPixel.ScoringTool   = InDetAmbiScoringToolPixel
   else:
     InDetAmbiguityProcessorPixel.ScoringTool = InDetScoringToolCosmics_SiPattern


   ToolSvc += InDetAmbiguityProcessorPixel
   if (InDetFlags.doPrintConfigurables()):
     print      InDetAmbiguityProcessorPixel
   #
   # configure Ambiguity solver
   #
   from TrkAmbiguitySolver.TrkAmbiguitySolverConf import Trk__TrkAmbiguitySolver
   InDetAmbiguitySolverPixel = Trk__TrkAmbiguitySolver(name               = 'InDetAmbiguitySolverPixel',
                                                  TrackInput         = [ InputTrackCollection ],
                                                  TrackOutput        = InDetKeys.PixelTracks(),
                                                  AmbiguityProcessor = InDetAmbiguityProcessorPixel)
   topSequence += InDetAmbiguitySolverPixel
   if (InDetFlags.doPrintConfigurables()):
     print          InDetAmbiguitySolverPixel
   
   if InDetFlags.doTruth():
      #
      # set collection name for truth
      #
      InputTrackCollectionTruth = "ResolvedPixelTracksTruthCollection"
      InputDetailedTrackTruth   = "ResolvedPixelTracksDetailedTruth"      
      #
      # set up the truth info for this container
      #
      include ("InDetRecExample/ConfiguredInDetTrackTruth.py")
      InDetTracksTruthPixel = ConfiguredInDetTrackTruth(InDetKeys.PixelTracks(),
                                                        InputDetailedTrackTruth,
                                                        InputTrackCollectionTruth)
      #
      # add final output for statistics
      #
      TrackCollectionKeys      += [ InDetKeys.PixelTracks() ]
      TrackCollectionTruthKeys += [ InputTrackCollectionTruth ]
        

   
