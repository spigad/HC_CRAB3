# ------------------------------------------------------------
#
# ----------- now we do the RTF tracking
#
# ------------------------------------------------------------
#
# get list of already associated hits (always do this, even if no other tracking ran before)
#
from InDetTrackPRD_Association.InDetTrackPRD_AssociationConf import InDet__InDetTrackPRD_Association
InDetLowPtPRD_Association = InDet__InDetTrackPRD_Association(name            = 'InDetLowPtPRD_Association',
                                                             AssociationTool = InDetPrdAssociationTool,
                                                             TracksName      = list(InputCombinedInDetTracks)) 
topSequence += InDetLowPtPRD_Association
if (InDetFlags.doPrintConfigurables()):
  print          InDetLowPtPRD_Association

#
# ----------- SiSPSeededTrackFinder for low momentum tracks
#
if InDetFlags.doSiSPSeededTrackFinder():
   #
   # Space points seeds maker
   #
   from SiSpacePointsSeedTool_xk.SiSpacePointsSeedTool_xkConf import InDet__SiSpacePointsSeedMaker_LowMomentum
   InDetSiSpacePointsSeedMakerLowPt = InDet__SiSpacePointsSeedMaker_LowMomentum(name                   = 'InDetSpSeedsMakerLowPt',
                                                                                MagneticTool           = InDetPatternMagField,
                                                                                pTmin                  = InDetCutValues.minLowPT(),
                                                                                pTmax                  = InDetCutValues.maxLowPT(),
                                                                                maxdImpact             = InDetCutValues.maxPrimaryImpact(),
                                                                                maxZ                   = InDetCutValues.maxZImpact(),
                                                                                minZ                   = -InDetCutValues.maxZImpact(),
                                                                                SpacePointsPixelName   = InDetKeys.PixelSpacePoints(),
                                                                                SpacePointsSCTName     = InDetKeys.SCT_SpacePoints(),
                                                                                SpacePointsOverlapName = InDetKeys.OverlapSpacePoints(),
                                                                                UseAssociationTool     = True,
                                                                                AssociationTool        = InDetPrdAssociationTool)
   ToolSvc += InDetSiSpacePointsSeedMakerLowPt
   if (InDetFlags.doPrintConfigurables()):
     print      InDetSiSpacePointsSeedMakerLowPt

   #
   # Local track finding using space point seed
   #
   from SiTrackMakerTool_xk.SiTrackMakerTool_xkConf import InDet__SiTrackMaker_xk
   InDetSiTrackMakerLowPt = InDet__SiTrackMaker_xk(name                     = 'InDetSiTrackMakerLowPt',
                                                   MagneticTool             = InDetPatternMagField,
                                                   RoadTool                 = InDetSiDetElementsRoadMaker,
                                                   CombinatorialTrackFinder = InDetSiComTrackFinder,
                                                   pTmin                    = InDetCutValues.minLowPT(),
                                                   nClustersMin             = 3, # InDetCutValues.minClustersLowPt(),
                                                   nWeightedClustersMin     = 6, # and this is new
                                                   nHolesMax                = InDetCutValues.maxHolesLowPt(),
                                                   nHolesGapMax             = 3, # was 2
                                                   SeedsFilterLevel         = 2,
                                                   UseAssociationTool       = True)

   ToolSvc += InDetSiTrackMakerLowPt
   if (InDetFlags.doPrintConfigurables()):
     print      InDetSiTrackMakerLowPt
   
   #
   # set output track collection name
   OutputTrackCollection = "SiSPSeededTracksLowPt"
   
   #
   # Setup Track finder using space points seeds
   #
   from SiSPSeededTrackFinder.SiSPSeededTrackFinderConf import InDet__SiSPSeededTrackFinder
   InDetSiSPSeededTrackFinderLowPt = InDet__SiSPSeededTrackFinder(name           = 'InDetSiSpTrackFinderLowPt',
                                                                  SeedsTool      = InDetSiSpacePointsSeedMakerLowPt,
                                                                  ZvertexTool    = None, 
                                                                  TrackTool      = InDetSiTrackMakerLowPt,
                                                                  TracksLocation = OutputTrackCollection,
                                                                  useZvertexTool = False)
   topSequence += InDetSiSPSeededTrackFinderLowPt
   if (InDetFlags.doPrintConfigurables()):
     print          InDetSiSPSeededTrackFinderLowPt

   #
   # set input collection for next algorithm
   #
   InputTrackCollection = OutputTrackCollection
    
   if InDetFlags.doTruth():
      #
      # set collection name for truth
      #
      InputTrackCollectionTruth = "SiSPSeededTracksLowPtTruthCollection"
      InputDetailedTrackTruth   = "SiSPSeededTracksLowPtDetailedTruth"
      #
      # set up the truth info for this container
      #
      include ("InDetRecExample/ConfiguredInDetTrackTruth.py")
      InDetTracksTruth = ConfiguredInDetTrackTruth(InputTrackCollection,
                                                   InputDetailedTrackTruth,
                                                   InputTrackCollectionTruth)
      #
      # add final output for statistics
      #
      TrackCollectionKeys      += [ InputTrackCollection ]
      TrackCollectionTruthKeys += [ InputTrackCollectionTruth ]
#
# ---------- Ambiguity solving
#
if InDetFlags.doAmbiSolving():
   #
   # load InnerDetector TrackSelectionTool
   #
   ## This is currently the same as NewTracking version, but may need lowPt tuning.
   from InDetAmbiTrackSelectionTool.InDetAmbiTrackSelectionToolConf import InDet__InDetAmbiTrackSelectionTool
   InDetAmbiTrackSelectionToolLowPt = InDet__InDetAmbiTrackSelectionTool(name            = 'InDetAmbiTrackSelectionToolLowPt',
                                                                         AssociationTool = InDetPrdAssociationTool,
                                                                         minHits         = InDetCutValues.minClustersLowPt(),
                                                                         minNotShared    = InDetCutValues.minSiNotShared(),
                                                                         maxShared       = InDetCutValues.maxShared(),
                                                                         minTRTHits      = 0 ) # used for Si only tracking !!!
   ToolSvc += InDetAmbiTrackSelectionToolLowPt
   if (InDetFlags.doPrintConfigurables()):
     print      InDetAmbiTrackSelectionToolLowPt
   #
   # set up Scoring Tool
   #
   from InDetTrackScoringTools.InDetTrackScoringToolsConf import InDet__InDetAmbiScoringTool
   InDetAmbiScoringToolLowPt = InDet__InDetAmbiScoringTool(name           = 'InDetAmbiScoringToolLowPt',
                                                           Extrapolator   = InDetExtrapolator,
                                                           SummaryTool    = InDetTrackSummaryTool,
                                                           useAmbigFcn    = True,
                                                           useTRT_AmbigFcn= False,
                                                           minPt          = InDetCutValues.minLowPT(),
                                                           maxRPhiImp     = InDetCutValues.maxPrimaryImpact(),
                                                           maxZImp        = InDetCutValues.maxZImpact(),
                                                           maxEta         = InDetCutValues.maxEta(),
                                                           minSiClusters  = InDetCutValues.minClustersLowPt(),
                                                           maxSiHoles     = InDetCutValues.maxHolesLowPt(),
                                                           maxDoubleHoles = InDetCutValues.maxDoubleHoles(),
                                                           minTRTonTrk    = 0,    # no TRT here
                                                           useSigmaChi2   = False) # Thijs turn it off
                                                           # useSigmaChi2   = True) # use it for Si only
   #InDetAmbiScoringToolLowPt.OutputLevel = VERBOSE
   ToolSvc += InDetAmbiScoringToolLowPt
   if (InDetFlags.doPrintConfigurables()):
     print      InDetAmbiScoringToolLowPt
   #
   # load Ambiguity Processor
   #
   from TrkAmbiguityProcessor.TrkAmbiguityProcessorConf import Trk__SimpleAmbiguityProcessorTool
   InDetAmbiguityProcessorLowPt = Trk__SimpleAmbiguityProcessorTool(name          = 'InDetAmbiguityProcessorLowPt',
                                                                    ScoringTool   = InDetAmbiScoringToolLowPt,
                                                                    Fitter        = InDetTrackFitterLowPt,
                                                                    SelectionTool = InDetAmbiTrackSelectionToolLowPt,
                                                                    RefitPrds     = not InDetFlags.refitROT())
   if InDetFlags.materialInteractions():
      InDetAmbiguityProcessorLowPt.MatEffects = 3
   else:
      InDetAmbiguityProcessorLowPt.MatEffects = 0

   ToolSvc += InDetAmbiguityProcessorLowPt
   if (InDetFlags.doPrintConfigurables()):
     print      InDetAmbiguityProcessorLowPt
   #
   # set output track name
   #
   OutputTrackCollection = "ResolvedTracksLowPt"
   #
   # configure Ambiguity solver
   #
   from TrkAmbiguitySolver.TrkAmbiguitySolverConf import Trk__TrkAmbiguitySolver
   InDetAmbiguitySolverLowPt = Trk__TrkAmbiguitySolver(name               = 'InDetAmbiguitySolverLowPt',
                                                       TrackInput         = [ InputTrackCollection ],
                                                       TrackOutput        = OutputTrackCollection,
                                                       AmbiguityProcessor = InDetAmbiguityProcessorLowPt)
   topSequence += InDetAmbiguitySolverLowPt
   if (InDetFlags.doPrintConfigurables()):
     print          InDetAmbiguitySolverLowPt

   #
   # Input of the next algorithm
   #
   InputTrackCollection = OutputTrackCollection

   if InDetFlags.doTruth():
      #
      # set collection name for truth
      #
      InputTrackCollectionTruth = "ResolvedTracksLowPtTruthCollection"
      InputDetailedTrackTruth   = "ResolvedTracksLowPtDetailedTruth"      
      #
      # set up the truth info for this container
      #
      include ("InDetRecExample/ConfiguredInDetTrackTruth.py")
      InDetTracksTruth = ConfiguredInDetTrackTruth(InputTrackCollection,
                                                   InputDetailedTrackTruth,
                                                   InputTrackCollectionTruth)
      #
      # add final output for statistics
      #
      TrackCollectionKeys      += [ InputTrackCollection ]
      TrackCollectionTruthKeys += [ InputTrackCollectionTruth ]

   # output track collection
   LowPtTrackCollection = InputTrackCollection

#    
# ---------- TRT_TrackExtension
#
if InDetFlags.doTRTExtension():
      
   #
   # Track extension to TRT algorithm
   #
   # set output extension map name
   OutputExtendedTracks = "ExtendedTracksMapLowPt"
   #
   from TRT_TrackExtensionAlg.TRT_TrackExtensionAlgConf import InDet__TRT_TrackExtensionAlg
   InDetTRTExtensionLowPt = InDet__TRT_TrackExtensionAlg (name                   = 'InDetTRT_ExtensionLowPt',
                                                          TrackExtensionTool     = InDetTRTExtensionTool,
                                                          InputTracksLocation    = InputTrackCollection,
                                                          ExtendedTracksLocation = OutputExtendedTracks   )
   topSequence += InDetTRTExtensionLowPt
   if (InDetFlags.doPrintConfigurables()):
     print          InDetTRTExtensionLowPt
   
#
# ------------ Track Extension Processor
#
if InDetFlags.doExtensionProcessor():
   
   if InDetFlags.trtExtensionType() is 'DAF' :
      #
      # DAF Fitter setup
      #
      from TrkCompetingRIOsOnTrackTool.TrkCompetingRIOsOnTrackToolConf import Trk__CompetingRIOsOnTrackTool
      InDetCompetingRotCreatorLowPt =  Trk__CompetingRIOsOnTrackTool( name                        = 'InDetCompetingRotCreatorLowPt',
                                                                      ToolForCompPixelClusters    = None,      # default
                                                                      ToolForCompSCT_Clusters     = None,      # default
                                                                      ToolForCompTRT_DriftCircles = InDetCompetingTRT_DC_Tool )
      ToolSvc += InDetCompetingRotCreatorLowPt
      if (InDetFlags.doPrintConfigurables()):
        print      InDetCompetingRotCreatorLowPt
      #
      from TrkDeterministicAnnealingFilter.TrkDeterministicAnnealingFilterConf import Trk__DeterministicAnnealingFilter
      InDetExtensionFitterLowPt =  Trk__DeterministicAnnealingFilter( name = 'InDetDAFLowPt',
                                                                              ToolForExtrapolation           = InDetExtrapolator,
                                                                              ToolForCompetingROTsCreation   = InDetCompetingRotCreatorLowPt,
                                                                              ToolForUpdating                = InDetPatternUpdator,
                                                                              AnnealingScheme                = [200., 81., 9., 4., 1., 1., 1.],
                                                                              DropOutlierCutValue            = 1.E-7,
                                                                              OutlierCutValue                = 0.01 )
      ToolSvc += InDetExtensionFitterLowPt
      if (InDetFlags.doPrintConfigurables()):
        print      InDetExtensionFitterLowPt
   else:
      InDetExtensionFitterLowPt = InDetTrackFitterLowPt
   #
   # load scoring for extension
   #
   from InDetTrackScoringTools.InDetTrackScoringToolsConf import InDet__InDetAmbiScoringTool
   InDetExtenScoringToolLowPt = InDet__InDetAmbiScoringTool(name           = 'InDetExtenScoringToolLowPt',
                                                       Extrapolator   = InDetExtrapolator,
                                                       SummaryTool    = InDetTrackSummaryTool,
                                                       useAmbigFcn    = True,
                                                       useTRT_AmbigFcn= False,
                                                       minPt          = InDetCutValues.minLowPT(),
                                                       maxRPhiImp     = InDetCutValues.maxPrimaryImpact(),
                                                       maxZImp        = InDetCutValues.maxZImpact(),
                                                       maxEta         = InDetCutValues.maxEta(),
                                                       minSiClusters  = InDetCutValues.minClustersLowPt(),
                                                       maxSiHoles     = InDetCutValues.maxHolesLowPt(),
                                                       maxDoubleHoles = InDetCutValues.maxDoubleHoles(),
                                                       minTRTonTrk    = InDetCutValues.minTRTonTrk(),
                                                       useSigmaChi2   = False) # do not use it for extension
   ToolSvc += InDetExtenScoringToolLowPt
   if (InDetFlags.doPrintConfigurables()):
     print      InDetExtenScoringToolLowPt
   #
   # set output track collection name
   #
   OutputTrackCollection = "ExtendedTracksLowPt"
   #
   # get configured track extension processor
   #
   from InDetExtensionProcessor.InDetExtensionProcessorConf import InDet__InDetExtensionProcessor   
   InDetExtensionProcessorLowPt = InDet__InDetExtensionProcessor ( name               = "InDetExtensionProcessorLowPt",
                                                              TrackName          = InputTrackCollection,
                                                              ExtensionMap       = OutputExtendedTracks,
                                                              NewTrackName       = OutputTrackCollection,
                                                              TrackFitter        = InDetExtensionFitterLowPt,
                                                              ScoringTool        = InDetExtenScoringToolLowPt,
                                                              suppressHoleSearch = False,  # does not work properly
                                                              RefitPrds          = not (InDetFlags.refitROT() or (InDetFlags.trtExtensionType() is 'DAF')))
   if InDetFlags.materialInteractions():
      InDetExtensionProcessorLowPt.matEffects = 3 # default in code is 4!!
   else :
      InDetExtensionProcessorLowPt.matEffects = 0
   
   topSequence += InDetExtensionProcessorLowPt
   if (InDetFlags.doPrintConfigurables()):
     print          InDetExtensionProcessorLowPt
   #
   # and set new input track collection
   #
   InputTrackCollection    = OutputTrackCollection

   #
   # ------------ Track truth.
   #
   if InDetFlags.doTruth():
      #
      # set collection name for truth
      #
      InputTrackCollectionTruth = "ExtendedTracksLowPtTruthCollection"
      InputDetailedTrackTruth   = "ExtendedTracksLowPtDetailedTruth"       
      #
      # set up the truth info for this container
      #
      include ("InDetRecExample/ConfiguredInDetTrackTruth.py")
      InDetLowPtTruth = ConfiguredInDetTrackTruth(InputTrackCollection,
                                                    InputDetailedTrackTruth,
                                                    InputTrackCollectionTruth)
      #
      # add final output for statistics
      #
      TrackCollectionKeys      += [ InputTrackCollection ]
      TrackCollectionTruthKeys += [ InputTrackCollectionTruth ]

   # output track collection
   LowPtTrackCollection = InputTrackCollection
   
