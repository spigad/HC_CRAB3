#
# ----------- TRT Segment finding
#
   
#
# get list of already associated hits (always do this, even if no other tracking ran before)
#
from InDetTrackPRD_Association.InDetTrackPRD_AssociationConf import InDet__InDetTrackPRD_Association
InDetSegmentPRD_Association = InDet__InDetTrackPRD_Association(name            = 'InDetSegmentPRD_Association',
                                                               AssociationTool = InDetPrdAssociationTool,
                                                               TracksName      = list(InputCombinedInDetTracks)) 
topSequence += InDetSegmentPRD_Association
if (InDetFlags.doPrintConfigurables()):
  print          InDetSegmentPRD_Association
#
# TRT seed maker
#
if not InDetFlags.doCosmics():
  from TRT_TrackSegmentsTool_xk.TRT_TrackSegmentsTool_xkConf import InDet__TRT_TrackSegmentsMaker_ATLxk
  InDetTRT_TrackSegmentsMaker = InDet__TRT_TrackSegmentsMaker_ATLxk(name                    = 'InDetTRT_SeedsMaker',
                                                                    TrtManagerLocation      = InDetKeys.TRT_Manager(),
                                                                    TRT_ClustersContainer   = InDetKeys.TRT_DriftCircles(),
                                                                    MagneticFieldMode       = 'MapSolenoid',  
                                                                    MagneticTool            = InDetPatternMagField,
                                                                    PropagatorTool          = InDetPatternPropagator,
                                                                    TrackExtensionTool      = InDetTRTExtensionTool,
                                                                    AssosiationTool         = InDetPrdAssociationTool,
                                                                    RemoveNoiseDriftCircles = InDetFlags.removeTRTNoise(),
                                                                    UseAssosiationTool      = True,
                                                                    pTmin                   = InDetCutValues.minPT())
  # if new tracking is off then no association tool is to be used!
  if not InDetFlags.doNewTracking():
    InDetTRT_TrackSegmentsMaker.UseAssosiationTool = False 
    InDetTRT_TrackSegmentsMaker.AssosiationTool    = None
  ToolSvc += InDetTRT_TrackSegmentsMaker
  if (InDetFlags.doPrintConfigurables()):
    print      InDetTRT_TrackSegmentsMaker
else:
  #
  # cosmics barrel segments
  #
  from TRT_TrackSegmentsTool_xk.TRT_TrackSegmentsTool_xkConf import InDet__TRT_TrackSegmentsMaker_BarrelCosmics
  InDetTRT_TrackSegmentsMaker_BarrelCosmics_TRT = InDet__TRT_TrackSegmentsMaker_BarrelCosmics(name= 'InDetTRTSegmentsMaker_BarrelCosmics_TRT',
                                                                                              IsMagneticFieldOn=InDetFlags.solenoidOn(),
                                                                                              AssosiationTool         = InDetPrdAssociationTool,
                                                                                              UseAssosiationTool      = True,
                                                                                              MinimalNumberOfTRTHits=20)
  
  ToolSvc += InDetTRT_TrackSegmentsMaker_BarrelCosmics_TRT 
  if (InDetFlags.doPrintConfigurables()):
    print      InDetTRT_TrackSegmentsMaker_BarrelCosmics_TRT


#
# TRT track reconstruction
#
from TRT_TrackSegmentsFinder.TRT_TrackSegmentsFinderConf import InDet__TRT_TrackSegmentsFinder
InDetTRT_TrackSegmentsFinder = InDet__TRT_TrackSegmentsFinder(name              = 'InDetTRT_TrackSegmentsFinder')

if not InDetFlags.doCosmics():
  InDetTRT_TrackSegmentsFinder.SegmentsLocation  = InDetKeys.TRT_Segments()
  InDetTRT_TrackSegmentsFinder.SegmentsMakerTool = InDetTRT_TrackSegmentsMaker
else:
  InDetTRT_TrackSegmentsFinder.SegmentsLocation  = "TRT_Segments_BarrelCosmics_TRTstandalone"
  InDetTRT_TrackSegmentsFinder.SegmentsMakerTool = InDetTRT_TrackSegmentsMaker_BarrelCosmics_TRT
  

topSequence += InDetTRT_TrackSegmentsFinder
if (InDetFlags.doPrintConfigurables()):
  print          InDetTRT_TrackSegmentsFinder



# cosmic track segments for EC
if InDetFlags.doCosmics():
  from TRT_TrackSegmentsTool_xk.TRT_TrackSegmentsTool_xkConf import InDet__TRT_TrackSegmentsMaker_ECcosmics
  InDetTRT_TrackSegmentsMaker_EC_TRTstandalone = InDet__TRT_TrackSegmentsMaker_ECcosmics(name= 'InDetTRTSegmentsMaker_EC_TRTstandalone',
                                                                                         ToTCutLoose           = 9,
                                                                                         ToTCutTight           = 15.,
                                                                                         ToTCutUpper           = 40.,
                                                                                         ScaleFactorTube       = 4.,
                                                                                         MinDCperSeed          = 7,
                                                                                         UseDriftTime          = False,
                                                                                         TRT_ClustersContainer = InDetKeys.TRT_DriftCircles(),
                                                                                         AssosiationTool       = InDetPrdAssociationTool,
                                                                                         UseAssosiationTool    = True)
  
  
  ToolSvc += InDetTRT_TrackSegmentsMaker_EC_TRTstandalone
  if (InDetFlags.doPrintConfigurables()):
    print      InDetTRT_TrackSegmentsMaker_EC_TRTstandalone
    
  from TRT_TrackSegmentsFinder.TRT_TrackSegmentsFinderConf import InDet__TRT_TrackSegmentsFinder
  InDetTRT_TrackSegmentsFinder_EC_TRTstandalone = InDet__TRT_TrackSegmentsFinder(name              = 'InDetTRTSegmentsFinder_EC_TRTstandalone',
                                                                   SegmentsLocation  = "TRT_Segments_EC_TRTstandalone",
                                                                   SegmentsMakerTool = InDetTRT_TrackSegmentsMaker_EC_TRTstandalone)  
  topSequence += InDetTRT_TrackSegmentsFinder_EC_TRTstandalone
  if (InDetFlags.doPrintConfigurables()):
    print          InDetTRT_TrackSegmentsFinder_EC_TRTstandalone
    
    
