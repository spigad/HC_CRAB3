#--------------------------------------------------------------
# produce tracking ntuple
#--------------------------------------------------------------

if InDetFlags.doTrkNtuple() or InDetFlags.doPixelTrkNtuple():
  # --- include helper tools
  from TrkValTools.TrkValToolsConf import Trk__ResidualValidationNtupleHelper
  ResidualNtupleHelper      = Trk__ResidualValidationNtupleHelper( name = 'InDetResidualValHelper' )
  ToolSvc += ResidualNtupleHelper
  if (InDetFlags.doPrintConfigurables()):
    print      ResidualNtupleHelper
  #
  from TrkValTools.TrkValToolsConf import Trk__HitPositionNtupleHelper
  HitPositionNtupleHelper   = Trk__HitPositionNtupleHelper( name = 'InDetHitPosValHelper' )
  ToolSvc += HitPositionNtupleHelper
  if (InDetFlags.doPrintConfigurables()):
    print      HitPositionNtupleHelper
  #
  from TrkValTools.TrkValToolsConf import Trk__TrackPositionNtupleHelper
  TrackPositionNtupleHelper = Trk__TrackPositionNtupleHelper( name = 'InDetTrackPosValHelper' )
  ToolSvc += TrackPositionNtupleHelper
  if (InDetFlags.doPrintConfigurables()):
    print      TrackPositionNtupleHelper
  
  PixelNtupleHelperToolsList = []
  SCTNtupleHelperToolsList   = []
  TRTNtupleHelperToolsList   = []
  
  if DetFlags.haveRIO.pixel_on():
    PixelNtupleHelperToolsList   = [ResidualNtupleHelper]
  if DetFlags.haveRIO.SCT_on():
    SCTNtupleHelperToolsList     = [ResidualNtupleHelper]
  if DetFlags.haveRIO.TRT_on():
    TRTNtupleHelperToolsList     = [ResidualNtupleHelper]
  GeneralNtupleHelperToolsList = [HitPositionNtupleHelper, TrackPositionNtupleHelper]

  minNumberOfPixelHitsForTracksInNtuple = 1 # for now, crashes if set to zero, under investigation

  if InDetFlags.doPixelTrkNtuple():
    # Pixel specific helper tool
    from InDetTrackValidation.InDetTrackValidationConf import InDet__SiResidualValidationNtupleHelper
    PixSiResidualNtupleHelper      = InDet__SiResidualValidationNtupleHelper( name = 'InDetPixelSiResidualValHelper' )
    ToolSvc += PixSiResidualNtupleHelper
    if (InDetFlags.doPrintConfigurables()):
      print      PixSiResidualNtupleHelper
    # add to lists of tools to use
    PixelNtupleHelperToolsList  += [PixSiResidualNtupleHelper]
    if DetFlags.haveRIO.SCT_on():
      SCTNtupleHelperToolsList    += [PixSiResidualNtupleHelper]
    minNumberOfPixelHitsForTracksInNtuple = 1
    
  # helper tool to fill trt ntuple part with drift time info
  if DetFlags.haveRIO.TRT_on():
    from InDetTrackValidation.InDetTrackValidationConf import InDet__TRT_DriftTimeNtupleHelper
    TRT_DriftTimeNtupleHelper      = InDet__TRT_DriftTimeNtupleHelper ( name = 'InDetTRT_DriftTimeNtupleHelper' )
    ToolSvc += TRT_DriftTimeNtupleHelper
    if (InDetFlags.doPrintConfigurables()):
      print      TRT_DriftTimeNtupleHelper
    TRTNtupleHelperToolsList  += [TRT_DriftTimeNtupleHelper]

  # --- include basic tool
  from TrkValTools.TrkValToolsConf import Trk__BasicValidationNtupleTool
  BasicValidationNtupleTool = Trk__BasicValidationNtupleTool(name                     = 'InDetValNtupleTool',
                                                             BookNewNtuple            = True,
                                                             NtupleFileName           = 'TRKVAL',
                                                             NtupleDirectoryName      = 'Validation',
                                                             NtupleTreeName           = 'Tracks',
                                                             HoleSearchTool           = InDetHoleSearchTool,
                                                             UpdatorTool              = InDetUpdator,
                                                             PixelNtupleHelperTools   = PixelNtupleHelperToolsList,
                                                             SCTNtupleHelperTools     = SCTNtupleHelperToolsList,
                                                             TRTNtupleHelperTools     = TRTNtupleHelperToolsList,
                                                             GeneralNtupleHelperTools = GeneralNtupleHelperToolsList,
                                                             DoTruth                  = InDetFlags.doTruth(),
                                                             DoHoleSearch             = True)
  ToolSvc += BasicValidationNtupleTool
  if (InDetFlags.doPrintConfigurables()):
    print      BasicValidationNtupleTool

  # --- include track selection tool
  from InDetTrackSelectorTool.InDetTrackSelectorToolConf import InDet__InDetTrackSelectorTool
  TrkValTrackSelectorTool = InDet__InDetTrackSelectorTool(name                  = 'InDetTrkValTrackSelectorTool',
                                                          minPt                 = InDetCutValues.minPT(),
                                                          maxZ0                 = 1000.,
                                                          maxD0                 = 2000.,
                                                          maxD0overSigmaD0      = 500.,
                                                          numberOfPixelHits     = minNumberOfPixelHitsForTracksInNtuple,
                                                          numberOfBLayerHits    = 0,
                                                          TrackSummaryTool      = InDetTrackSummaryTool)
  if (InDetFlags.doLowPt()):
    TrkValTrackSelectorTool.minPt = InDetCutValues.minLowPT()

  if (InDetFlags.doCosmics()):
    TrkValTrackSelectorTool.minPt                   =       0.0
    TrkValTrackSelectorTool.maxZ0                   = 9999999.0
    TrkValTrackSelectorTool.maxD0                   = 9999999.0
    TrkValTrackSelectorTool.maxD0overSigmaD0        = 9999999.0
    TrkValTrackSelectorTool.numberOfPixelHits       =       0
    TrkValTrackSelectorTool.numberOfBLayerHits      =       0

  ToolSvc += TrkValTrackSelectorTool
  if (InDetFlags.doPrintConfigurables()):
    print      TrkValTrackSelectorTool

  # --- truth ?
  if InDetFlags.doTruth() :
    TruthToTrackTool = InDetTruthToTrack
  else :
    TruthToTrackTool = None
  # --- include track ntuple alg

  if InDetFlags.doCosmics():
    # --- include InDetReconstructableSelector and adjust parameters to cosmics setups
    from TrkValTools.TrkValToolsConf import Trk__InDetReconstructableSelector
    TrkInDetReconstructableSelector = Trk__InDetReconstructableSelector(name               = 'InDetReconstructableSelector',
                                                                        # OutputLevel          = VERBOSE,
                                                                        MinPt              = 0.5,
                                                                        MaxRStartAll       = 2000000, #very loose cuts
                                                                        MaxZStartAll       = 2000000)
    ToolSvc += TrkInDetReconstructableSelector
    if (InDetFlags.doPrintConfigurables()):
      print      TrkInDetReconstructableSelector

  from TrkValAlgs.TrkValAlgsConf import Trk__TrackValidationNtupleWriter
  TrkValNtupleWriter = Trk__TrackValidationNtupleWriter(name                 = 'InDetValNtupleWriter',
                                                        ValidationNtupleTool = BasicValidationNtupleTool,
                                                        TrackCollection      = InDetKeys.UnslimmedTracks(),
                                                        TrackTruthCollection = InDetKeys.UnslimmedTracksTruth(),
                                                        DoTruth              = InDetFlags.doTruth(),
                                                        TruthToTrackTool     = TruthToTrackTool,
                                                        TrackSelectorTool    = TrkValTrackSelectorTool)
  if InDetFlags.doCTBTracking() or (InDetFlags.doCosmics() and not InDetFlags.doNewTracking):
    TrkValNtupleWriter.TrackCollection      = InDetKeys.UnslimmedTracks_CTB()
    TrkValNtupleWriter.TrackTruthCollection = "CombinedInDetTracks_CTBTruthCollection"
                                                       
  topSequence += TrkValNtupleWriter
  if (InDetFlags.doPrintConfigurables()):
    print          TrkValNtupleWriter

  if InDetFlags.doPixelTrkNtuple():
    # include Pixel ntuple writer alg
    # adds information about all PRDs in the Pixels
    from InDetTrackValidation.InDetTrackValidationConf import InDet__PixelClusterValidationNtupleWriter
    PixelNtupleWriter = InDet__PixelClusterValidationNtupleWriter(name                       = 'InDetPixelClusterValidationNtupleWriter',
                                                                    NtupleFileName           = 'TRKVAL',
                                                                    NtupleDirectoryName      = 'Validation',
                                                                    NtupleTreeName           = 'PixelRIOs',
                                                                    PixelClusterContainer    = InDetKeys.PixelClusters())
    topSequence += PixelNtupleWriter
    if (InDetFlags.doPrintConfigurables()):
      print          PixelNtupleWriter  

  if not 'addTrtDriftCirclesToTrkNtuple' in dir():
    addTrtDriftCirclesToTrkNtuple = False
  if addTrtDriftCirclesToTrkNtuple :
    # include TRT ntuple writer alg (large ntuple !!!)
    # adds information about all PRDs in the TRT
    from InDetTrackValidation.InDetTrackValidationConf import InDet__TRT_DriftCircleValidationNtupleWriter
    TRT_NtupleWriter = InDet__TRT_DriftCircleValidationNtupleWriter(name                     = 'InDetTRT_DriftCircleNtupleWriter',
                                                                    NtupleFileName           = 'TRKVAL',
                                                                    NtupleDirectoryName      = 'Validation',
                                                                    NtupleTreeName           = 'TRT_RIOs',
                                                                    TRT_DriftCircleContainer = 'TRT_DriftCircles')
    topSequence += TRT_NtupleWriter
    if (InDetFlags.doPrintConfigurables()):
      print          TRT_NtupleWriter
  
if InDetFlags.doVtxNtuple():  
  from TrkVertexFitterValidationUtils.TrkVertexFitterValidationUtilsConf import Trk__TrkPriVxPurityTool
  InDetPriVxPurityTool =  Trk__TrkPriVxPurityTool(name = "InDetPriVxPurityTool",
                                                  VertexRTolerance = 0.001,
                                                  VertexZTolerance = 0.001,
                                                  SimTrackMapName  = "TrackParticleTruthCollection",
                                                  MonteCarloCollection = "TruthEvent")
  ToolSvc += InDetPriVxPurityTool
  if (InDetFlags.doPrintConfigurables()):
    print InDetPriVxPurityTool

  from TrkVertexFitterValidation.TrkVertexFitterValidationConf import Trk__PUVertexTest
  InDetVertexNTupleWriter = Trk__PUVertexTest(name = "InDetVertexNTupleWriter",
                                              NtupleFileName           = 'TRKVAL',
                                              NtupleDirectoryName      = 'Validation',
                                              NtupleTreeName           = 'VertexTree',
                                              VertexCollectionName = InDetKeys.PrimaryVertices(),
                                              MonteCarloCollection = "TruthEvent",
                                              PurityTool           = InDetPriVxPurityTool,
                                              TrackSelector        = InDetTrackSelectorTool)
  topSequence += InDetVertexNTupleWriter
  if (InDetFlags.doPrintConfigurables()):
    print InDetVertexNTupleWriter

if InDetFlags.doConvVtxNtuple():
  from TrkVertexFitterValidation.TrkVertexFitterValidationConf import Trk__ConvVertexTest
  InDetConversionNTupleWriter = Trk__ConvVertexTest(name                 = "InDetConversionNTupleWriter",
                                                    NtupleFileName       = 'TRKVAL',
                                                    NtupleDirectoryName  = 'Validation',
                                                    NtupleTreeName       = 'ConversionTree',
                                                    VertexCollectionName = InDetKeys.Conversions(),
                                                    MonteCarloCollection = "TruthEvent")
  topSequence += InDetConversionNTupleWriter
  if (InDetFlags.doPrintConfigurables()):
    print InDetConversionNTupleWriter

if InDetFlags.doV0VtxNtuple():
  from TrkVertexFitterValidation.TrkVertexFitterValidationConf import Trk__V0VertexTest
  InDetV0NTupleWriter = Trk__V0VertexTest(name                 = "InDetV0NTupleWriter",
                                          NtupleFileName       = 'TRKVAL',
                                          NtupleDirectoryName  = 'Validation',
                                          NtupleTreeName       = 'V0Tree',
                                          McAvailable          = True,
                                          VertexCollectionName = InDetKeys.V0Candidates(),
                                          MonteCarloCollection = "TruthEvent")
  topSequence += InDetV0NTupleWriter
  if (InDetFlags.doPrintConfigurables()):
    print InDetV0NTupleWriter

if InDetFlags.doTrkNtuple() or InDetFlags.doPixelTrkNtuple() or InDetFlags.doVtxNtuple() or InDetFlags.doConvVtxNtuple() or InDetFlags.doV0VtxNtuple():
  # --- setup
  theApp.HistogramPersistency = 'ROOT'
  if not hasattr(ServiceMgr, 'THistSvc'):
    from GaudiSvc.GaudiSvcConf import THistSvc
    ServiceMgr += THistSvc()
  ServiceMgr.THistSvc.Output += [ "TRKVAL DATAFILE='" + InDetKeys.trkValidationNtupleName() + "' TYPE='ROOT' OPT='RECREATE'" ]
  theApp.Dlls += [ 'RootHistCnv' ]

if InDetFlags.doStandardPlots():
  if len(TrackCollectionKeys) > 0:
    #
    # -- track selections 
    #
    # for standard good quality cuts
    from InDetTrackSelectorTool.InDetTrackSelectorToolConf import InDet__InDetDetailedTrackSelectorTool
    InDetTrackSelectorToolGood = InDet__InDetDetailedTrackSelectorTool(name = "InDetDetailedTrackSelectorToolGood",
                                                                       pTMin                = 0,
                                                                       d0MaxPreselection    = 10,
                                                                       IPd0Max              = 2,
                                                                       IPz0Max              = 10000,
                                                                       etaMax               = 2.5,
                                                                       nHitSi               = 7,
                                                                       nHitBLayer           = 0,
                                                                       nHitPix              = 0,
                                                                       nHitTrtHighEFractionMax = 1,
                                                                       nHitTrtHighEFractionWithOutliersMax = 1,
                                                                       useTrackSummaryInfo  = True,
                                                                       TrackSummaryTool     = InDetTrackSummaryTool,
                                                                       Extrapolator         = InDetExtrapolator,
                                                                       TrtMaxEtaAcceptance  = 1.9)

    ToolSvc+=InDetTrackSelectorToolGood
    if (InDetFlags.doPrintConfigurables()):
      print      InDetTrackSelectorToolGood

    # for track selection as done by b-tagging group
    InDetTrackSelectorToolBtag = InDet__InDetDetailedTrackSelectorTool(name = "InDetDetailedTrackSelectorToolBtag",
                                                                       pTMin                = 0,
                                                                       IPd0Max              = 1,
                                                                       d0MaxPreselection    = 10,
                                                                       IPz0Max              = 40000,
                                                                       etaMax               = 2.5,
                                                                       nHitBLayer           = 1,
                                                                       nHitPix              = 2,
                                                                       nHitSi               = 7,
                                                                       nHitTrtHighEFractionMax = 1,
                                                                       nHitTrtHighEFractionWithOutliersMax = 1,
                                                                       TrackSummaryTool     = InDetTrackSummaryTool,
                                                                       Extrapolator         = InDetExtrapolator,
                                                                       TrtMaxEtaAcceptance  = 1.9)       

    ToolSvc+=InDetTrackSelectorToolBtag
    if (InDetFlags.doPrintConfigurables()):
      print  InDetTrackSelectorToolBtag

    # Extended Hole Search tool configuration
    from InDetTrackHoleSearch.InDetTrackHoleSearchConf import InDet__InDetTrackHoleSearchTool
    ExtendedInDetPerfHoleSearch = InDet__InDetTrackHoleSearchTool (name = "InDetExtendedInDetPerfHoleSearch",
                                                           Extrapolator = InDetExtrapolator,
                                                           ExtendedListOfHoles = True)
    ToolSvc += ExtendedInDetPerfHoleSearch
    if (InDetFlags.doPrintConfigurables()):
      print ExtendedInDetPerfHoleSearch
                                                           
                 
           
    # --- add an AthenaMonManager algorithm to the list of algorithms to be ran
    from AthenaMonitoring.AthenaMonitoringConf import AthenaMonManager
    InDetTrackPerfMonManager = AthenaMonManager( name = "InDetTrackPerfMonManager",
                                              FileKey = "stat",
                                              ManualDataTypeSetup = True,
                                              DataType            = "userDefined", # use this for collision data for now
                                              Environment         = "user",
                                              ManualRunLBSetup    = True,
                                              Run                 = 1,
                                              LumiBlock           = 1)
  
    topSequence += InDetTrackPerfMonManager
    if (InDetFlags.doPrintConfigurables()):
      print InDetTrackPerfMonManager
    

      
    
    # --- Setup the output histogram file(s)
    if not hasattr(ServiceMgr, 'THistSvc'):
      from GaudiSvc.GaudiSvcConf import THistSvc
    ServiceMgr += THistSvc()
    THistSvc = Service( "THistSvc" )
    histOutput = "InDetPerformanceMon DATAFILE='" + InDetKeys.StandardPlotHistName() + "' OPT='RECREATE'"
    THistSvc.Output += [histOutput]
    InDetTrackPerfMonManager.FileKey = "InDetPerformanceMon"
    
    
    from InDetPerformanceRTT.InDetPerformanceRTTConf import IDStandardPerformance as InDetStandardPerformance
    # all tracks
    InDetStandardPerformanceAll = InDetStandardPerformance (name = "InDetStandardPerformanceAll",
                                                      tracksName=InDetKeys.ExtendedTracks(),
                                                      tracksTruthName=InDetKeys.ExtendedTracksTruth(),
                                                      SummaryTool= InDetTrackSummaryToolSharedHits,
                                                      #HoleSearch  =  ExtendedInDetPerfHoleSearch,
                                                      useTrackSelection=False,
                                                      HistDirectoryName="AllTracks",
                                                      TruthToTrackTool=InDetTruthToTrack)
    
    ToolSvc += InDetStandardPerformanceAll
    if (InDetFlags.doPrintConfigurables()):
      print    InDetStandardPerformanceAll
        
    InDetTrackPerfMonManager.AthenaMonTools += [ InDetStandardPerformanceAll ]
    
    # selected tracks passing good quality cuts
    InDetStandardPerformanceGood = InDetStandardPerformance (name = "InDetStandardPerformanceGood",
                                                       tracksName=InDetKeys.ExtendedTracks(),
                                                       tracksTruthName=InDetKeys.ExtendedTracksTruth(),
                                                       SummaryTool= InDetTrackSummaryToolSharedHits,
                                                       #HoleSearch  =  ExtendedInDetPerfHoleSearch,
                                                       useTrackSelection=True,
                                                       TrackSelectorTool=InDetTrackSelectorToolGood,
                                                       HistDirectoryName="SelectedGoodTracks",
                                                       TruthToTrackTool=InDetTruthToTrack)
    
    ToolSvc += InDetStandardPerformanceGood
    if (InDetFlags.doPrintConfigurables()):
      print    InDetStandardPerformanceGood
    
    InDetTrackPerfMonManager.AthenaMonTools += [ InDetStandardPerformanceGood ]
    
    # selected tracks passing b-tagging cuts
    InDetStandardPerformanceBtag = InDetStandardPerformance (name = "InDetStandardPerformanceBtag",
                                                       tracksName=InDetKeys.ExtendedTracks(),
                                                       tracksTruthName=InDetKeys.ExtendedTracksTruth(),
                                                       SummaryTool= InDetTrackSummaryToolSharedHits,
                                                       #HoleSearch  =  ExtendedInDetPerfHoleSearch,
                                                       useTrackSelection=True,
                                                       TrackSelectorTool=InDetTrackSelectorToolBtag,
                                                       HistDirectoryName="SelectedBtagTracks",
                                                       TruthToTrackTool=InDetTruthToTrack)
    
    ToolSvc += InDetStandardPerformanceBtag
    if (InDetFlags.doPrintConfigurables()):
      print    InDetStandardPerformanceBtag
    
    InDetTrackPerfMonManager.AthenaMonTools += [ InDetStandardPerformanceBtag ]

