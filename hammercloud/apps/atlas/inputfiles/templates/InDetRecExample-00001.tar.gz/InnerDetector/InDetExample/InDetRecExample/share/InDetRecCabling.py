include.block ('InDetRecExample/ConfiguredInDetRecCabling.py')
from InDetRecExample.InDetJobProperties import InDetFlags

if DetFlags.detdescr.pixel_on() and not 'PixelCabling' in dir():
  # cabling comes from real data
  from PixelCabling.PixelCablingConf import PixelFillCablingData_Final
  PixelCabling = PixelFillCablingData_Final()

  if not (globalflags.DataSource() == 'geant4'): 
    PixelCabling.MappingFile = "Pixels_Atlas_IdMapping_May08.dat"
  ToolSvc += PixelCabling      
  
  if (InDetFlags.doPrintConfigurables()):
    print  PixelCabling
      
if DetFlags.detdescr.SCT_on() and not 'SCT_CablingSvc' in dir():
  #to read SCT cabling from db 
  from SCT_Cabling.SCT_CablingConf import SCT_CablingSvc
  ServiceMgr+=SCT_CablingSvc()
  IOVDbSvc = Service("IOVDbSvc")
  from IOVDbSvc.CondDB import conddb
  conddb.addFolder("SCT","/SCT/DAQ/Configuration/ROD")
  conddb.addFolder("SCT","/SCT/DAQ/Configuration/MUR")
  conddb.addFolder("SCT","/SCT/DAQ/Configuration/RODMUR")
  conddb.addFolder("SCT","/SCT/DAQ/Configuration/Geog")
  ServiceMgr.SCT_CablingSvc.DataSource = "CORACOOL"
  if globalflags.DataSource() == 'geant4': 
    ServiceMgr.SCT_CablingSvc.DataSource = "SCT_MC_FullCabling_svc.dat"
  
if DetFlags.detdescr.TRT_on() and not 'TRT_Cabling' in dir():
  # if bytestream comes from real data
  from TRT_Cabling.TRT_CablingConf import TRT_FillCablingData_DC3
  TRT_Cabling = TRT_FillCablingData_DC3()
  if not (globalflags.DataSource() == 'geant4'): 
    # TRT needs the hack in "the other direction"
    TRT_Cabling.RealData=True
  ToolSvc += TRT_Cabling 
  if (InDetFlags.doPrintConfigurables()):
    print  TRT_Cabling
       
