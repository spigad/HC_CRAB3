#
# ----------- TRT Segment finding
#
   
#
# get list of already associated hits (always do this, even if no other tracking ran before)
#
from InDetTrackPRD_Association.InDetTrackPRD_AssociationConf import InDet__InDetTrackPRD_Association
InDetSingleSP_PRD_Association = InDet__InDetTrackPRD_Association(name            = 'InDetSingleSP_PRD_Association',
                                                                 AssociationTool = InDetPrdAssociationTool,
                                                                 TracksName      = list(InputCombinedInDetTracks)) 
topSequence += InDetSingleSP_PRD_Association
if (InDetFlags.doPrintConfigurables()):
  print          InDetSingleSP_PRD_Association

#
# TRT seeded space points seed maker
#
from TRT_SeededSpacePointFinderTool.TRT_SeededSpacePointFinderToolConf import InDet__TRT_SeededSpacePointFinder_ATL
InDetTRT_SeededSingleSpSpacePointFinder =  InDet__TRT_SeededSpacePointFinder_ATL(name                  = 'InDetTRT_SeededSingleSpFinder'  ,
                                                                                 MagneticTool          = InDetPatternMagField       ,
                                                                                 SpacePointsSCTName    = InDetKeys.SCT_SpacePoints(),
                                                                                 SpacePointsOverlapName= InDetKeys.OverlapSpacePoints(),
                                                                                 AssociationTool       = InDetPrdAssociationTool    ,
                                                                                 UseAssociationTool    = True,
                                                                                 NeighborSearch        = True,
                                                                                 LoadFull              = False)

ToolSvc += InDetTRT_SeededSingleSpSpacePointFinder
if (InDetFlags.doPrintConfigurables()):
    print      InDetTRT_SeededSingleSpSpacePointFinder

# ---------------------------------------------------------------------
# SingleSP TRT seeded back tracking tool...  takes extensions with 1 SPs
# ---------------------------------------------------------------------
#
# TRT seeded back tracking tool
#
from TRT_SeededSingleSpTrackFinderTool.TRT_SeededSingleSpTrackFinderToolConf import InDet__TRT_SeededSingleSpTrackFinderTool
InDetTRT_SeededSingleSpTrackTool =  InDet__TRT_SeededSingleSpTrackFinderTool(name           = 'InDetTRT_SeededSingleSpTrackMaker',
                                                                             MagneticTool   = InDetPatternMagField,
                                                                             PropagatorTool = InDetPatternPropagator,
                                                                             UpdatorTool    = InDetPatternUpdator,
                                                                             SeedTool       = InDetTRT_SeededSingleSpSpacePointFinder,
                                                                             RIOonTrackTool = InDetRotCreator,
                                                                             BremCorrection = True)
#InDetTRT_SeededSingleSpTrackTool.OutputLevel = DEBUG
ToolSvc   += InDetTRT_SeededSingleSpTrackTool
if (InDetFlags.doPrintConfigurables()):
  print        InDetTRT_SeededSingleSpTrackTool

#
# Output key for the standalone TRT track finder
#
OutputSingleSiExtendedTracks = "TRTSeededSingleSPTracks"
#
# TRT seeded back tracking algorithm
#
from TRT_SeededSingleSpTrackFinder.TRT_SeededSingleSpTrackFinderConf import InDet__TRT_SeededSingleSpTrackFinder
InDetTRT_SeededSingleSpTrackFinder = InDet__TRT_SeededSingleSpTrackFinder(name  = 'InDetTRT_SeededSingleSpTrackFinder',
									  RefitterTool          = InDetTrackFitter,
                                                                          TrackTool             = InDetTRT_SeededSingleSpTrackTool,
                                                                          TrackExtensionTool    = InDetTRTExtensionTool,
                                                                          FinalRefit            = False,
                                                                          FinalStatistics       = False,
                                                                          AssociationTool       = InDetPrdAssociationTool,
                                                                          MinTRThits            = 32,
                                                                          InputSegmentsLocation = InDetKeys.TRT_Segments(),
                                                                          OutputTracksLocation  = OutputSingleSiExtendedTracks,
                                                                          SharedHitsFraction    = .3)
if InDetFlags.doCosmics():
  InDetTRT_SeededSingleSpTrackFinder.InputSegmentsLocation = "TRT_Segments_BarrelCosmics_TRTstandalone"
      
topSequence += InDetTRT_SeededSingleSpTrackFinder
if (InDetFlags.doPrintConfigurables()):
  print          InDetTRT_SeededSingleSpTrackFinder

# ------------ Track truth.
#
if InDetFlags.doTruth():
    #
    # set collection name for truth
    #
    SingleSiExtendedTracksTruth     = "TRTSeededSingleSpTracksTruthCollection"
    SingleDetailedSiExtendedTruth   = "TRTSeededSingleSpTracksDetailedTruth"       
    #
    # set up the truth info for this container
    #
    include ("InDetRecExample/ConfiguredInDetTrackTruth.py")
    InDetTracksTruth = ConfiguredInDetTrackTruth(OutputSingleSiExtendedTracks,
                                                 SingleDetailedSiExtendedTruth,
                                                 SingleSiExtendedTracksTruth)
    #
    # add final output for statistics
    #
    TrackCollectionKeys      += [ OutputSingleSiExtendedTracks ]
    TrackCollectionTruthKeys += [ SingleSiExtendedTracksTruth ]
