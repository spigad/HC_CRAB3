j = Job()
j.application = Athena()
j.application.option_file = 'readesd.py'
j.application.atlas_dbrelease='ddo.000001.Atlas.Ideal.DBRelease.v060301:DBRelease-6.3.1.tar.gz'
j.application.max_events = 100
j.application.prepare()
j.inputdata = DQ2Dataset()
j.inputdata.dataset = ['data08_cosmag.00091890.physics_IDCosmic.merge.DPD_IDCOMM.o4_r602_p16/']
#j.outputdata = DQ2OutputDataset()
#j.outputdata.outputdata = ['newcommission.ntuple.root',
#                           'myMonitoringESD.root']
j.splitter = DQ2JobSplitter()
j.splitter.numsubjobs = 1
j.backend = LCG()
#j.backend.requirements.cloud = 'DE'
j.backend.requirements.sites = ['FZK-LCG2_DATADISK']
#j.backend.requirements.sites = ['LRZ-LMU_DATADISK']
j.backend.requirements.cputime=1440
j.submit()
