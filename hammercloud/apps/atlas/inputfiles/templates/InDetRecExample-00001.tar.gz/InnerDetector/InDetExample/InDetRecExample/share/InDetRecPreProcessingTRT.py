# ------------------------------------------------------------
#
# ----------- Data-Preparation stage
#
# ------------------------------------------------------------
#
# ----------- PrepRawData creation from Raw Data Objects
#
if InDetFlags.doPRDFormation() and not InDetFlags.doCosmics():
   #
   # TRT RIO Maker
   #
   if DetFlags.makeRIO.TRT_on():
      
      #
      # TRT_DriftFunctionTool
      #
      from TRT_DriftFunctionTool.TRT_DriftFunctionToolConf import TRT_DriftFunctionTool
      InDetTRT_DriftFunctionTool = TRT_DriftFunctionTool(name = "InDetTRT_DriftFunctionTool",
							 AllowDataMCOverride = True,
                                                         ForceData = True)
      
      ToolSvc += InDetTRT_DriftFunctionTool
      if (InDetFlags.doPrintConfigurables()):
        print      InDetTRT_DriftFunctionTool

      #
      # TRT_DriftCircleTool
      #
      from TRT_DriftCircleTool.TRT_DriftCircleToolConf import InDet__TRT_DriftCircleTool
      InDetTRT_DriftCircleTool = InDet__TRT_DriftCircleTool(name                   = "InDetTRT_DriftCircleTool",
                                                            TRTDriftFunctionTool   = InDetTRT_DriftFunctionTool,
                                                            TrtDescrManageLocation = InDetKeys.TRT_Manager(),
                                                            ConditionsSummaryTool  = InDetTRTConditionsSummaryTool,
                                                            UseConditionsStatus    = True)
      ToolSvc += InDetTRT_DriftCircleTool
      if (InDetFlags.doPrintConfigurables()):
        print      InDetTRT_DriftCircleTool
      
      #
      # TRT_RIO_Maker Algorithm
      #
      from InDetPrepRawDataFormation.InDetPrepRawDataFormationConf import InDet__TRT_RIO_Maker
      InDetTRT_RIO_Maker = InDet__TRT_RIO_Maker(name                   = "InDetTRT_RIO_Maker",
                                                TRT_DriftCircleTool    = InDetTRT_DriftCircleTool,
                                                TrtDescrManageLocation = InDetKeys.TRT_Manager(),
                                                TRTRDOLocation         = InDetKeys.TRT_RDOs(),
                                                TRTRIOLocation         = InDetKeys.TRT_DriftCircles())


      topSequence += InDetTRT_RIO_Maker
      if (InDetFlags.doPrintConfigurables()):
        print          InDetTRT_RIO_Maker
       
      #
      # -------- we need to do truth association if requested (not for uncalibrated hits in cosmics)
      #
      if InDetFlags.doTruth():
         from InDetTruthAlgs.InDetTruthAlgsConf import InDet__PRD_MultiTruthMaker
         InDetPRD_MultiTruthMakerTRT = InDet__PRD_MultiTruthMaker (name                        = 'InDetPRD_MultiTruthMakerTRT',
                                                                   PixelClusterContainerName   = "",
                                                                   SCTClusterContainerName     = "",
                                                                   TRTDriftCircleContainerName = InDetKeys.TRT_DriftCircles(),
                                                                   SimDataMapNamePixel         = "",
                                                                   SimDataMapNameSCT           = "",
                                                                   SimDataMapNameTRT           = InDetKeys.TRT_SDOs(),
                                                                   TruthNamePixel              = "",
                                                                   TruthNameSCT                = "",
                                                                   TruthNameTRT                = InDetKeys.TRT_DriftCirclesTruth())
         topSequence += InDetPRD_MultiTruthMakerTRT
         if (InDetFlags.doPrintConfigurables()):
            print          InDetPRD_MultiTruthMakerTRT

#
# -- In case of cosmics run first without drifttime information
#
if InDetFlags.doPRDFormation() and DetFlags.makeRIO.TRT_on() and InDetFlags.doCosmics():
    #
    # Dummy tool that gives back uncalibrated hits
    #

    from TRT_DriftFunctionTool.TRT_DriftFunctionToolConf import TRT_DriftFunctionTool
    InDetTRT_DriftFunctionToolNoDT = TRT_DriftFunctionTool(name = "InDetTRT_DriftFunctionToolNoDT",
                                                           DummyMode=True,
                                                           UniversalError=1.15)
    
    ToolSvc += InDetTRT_DriftFunctionToolNoDT
    if (InDetFlags.doPrintConfigurables()):
        print      InDetTRT_DriftFunctionToolNoDT
    

    from TRT_DriftCircleTool.TRT_DriftCircleToolConf import InDet__TRT_DriftCircleTool
    InDetTRT_DriftCircleToolNoDT = InDet__TRT_DriftCircleTool(name                 = "InDetTRT_DriftCircleToolNoDT",
                                                              TRTDriftFunctionTool = InDetTRT_DriftFunctionToolNoDT,
                                                              TrtDescrManageLocation = InDetKeys.TRT_Manager(),
                                                              ConditionsSummaryTool  = InDetTRTConditionsSummaryTool,
                                                              UseConditionsStatus    = True)
    
    ToolSvc += InDetTRT_DriftCircleToolNoDT
    if (InDetFlags.doPrintConfigurables()):
        print      InDetTRT_DriftCircleToolNoDT


    #
    # TRT_RIO_Maker Algorithm
    #
    from InDetPrepRawDataFormation.InDetPrepRawDataFormationConf import InDet__TRT_RIO_Maker
    InDetTRT_RIO_MakerNoDT = InDet__TRT_RIO_Maker(name                   = "InDetTRT_RIO_MakerNoDT",
                                                  TRT_DriftCircleTool    = InDetTRT_DriftCircleToolNoDT,
                                                  TrtDescrManageLocation = InDetKeys.TRT_Manager(),
                                                  TRTRDOLocation         = InDetKeys.TRT_RDOs(),
                                                  TRTRIOLocation         = InDetKeys.TRT_DriftCirclesUncalibrated())
    topSequence += InDetTRT_RIO_MakerNoDT
    if (InDetFlags.doPrintConfigurables()):
        print          InDetTRT_RIO_MakerNoDT

