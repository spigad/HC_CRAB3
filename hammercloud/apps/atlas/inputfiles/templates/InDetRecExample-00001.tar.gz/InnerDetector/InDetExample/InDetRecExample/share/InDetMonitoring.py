# ------------------------------------------------------------
#
# ----------- run monitoring
#
# this file is included from InDetRec_all.py (in case of ID standalone running)
# or through RecExCommon (data quality include)
# ------------------------------------------------------------
#
# --- checking for presence of flags
#
from InDetRecExample.InDetJobProperties import InDetFlags
from InDetRecExample.InDetKeys import InDetKeys
from AthenaCommon.DetFlags import DetFlags
from AthenaCommon.GlobalFlags import globalflags

if InDetFlags.doMonitoringGlobal():
  include("InDetRecExample/InDetMonitoringGlobal.py")
if InDetFlags.doMonitoringPixel():
  if not InDetFlags.doTrackSegmentsPixel():
      InDetKeys.PixelTracks_CTB = InDetKeys.UnslimmedTracks_CTB()
      InDetKeys.PixelTracks = InDetKeys.UnslimmedTracks()
  include( "InDetRecExample/InDetMonitoringPixel.py")
if InDetFlags.doMonitoringSCT():
  if not InDetFlags.doTrackSegmentsSCT():
      InDetKeys.SCTTracks_CTB = InDetKeys.UnslimmedTracks_CTB()
      InDetKeys.SCTTracks = InDetKeys.UnslimmedTracks()
  include( "InDetRecExample/InDetMonitoringSCT.py" )
if InDetFlags.doMonitoringTRT():
  if not InDetFlags.doTrackSegmentsTRT():
      InDetKeys.TRTTracks_CTB = InDetKeys.UnslimmedTracks_CTB()
      InDetKeys.TRTTracks = InDetKeys.UnslimmedTracks()
  include( "InDetRecExample/InDetMonitoringTRT.py" )
if InDetFlags.doMonitoringAlignment():
  include("InDetRecExample/InDetMonitoringAlignment.py")
