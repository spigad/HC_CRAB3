InputTrackCollection = SiTrackCollection
#    
# ---------- TRT_TrackExtension
#
if InDetFlags.doTRTExtension():
      
   #
   # Track extension to TRT algorithm
   #
   # set output extension map name
   OutputExtendedTracks = "ExtendedTracksMap"
   #
   from TRT_TrackExtensionAlg.TRT_TrackExtensionAlgConf import InDet__TRT_TrackExtensionAlg
   InDetTRTExtension    = InDet__TRT_TrackExtensionAlg (name                   = 'InDetTRT_Extension',
                                                        InputTracksLocation    = InputTrackCollection,
                                                        ExtendedTracksLocation = OutputExtendedTracks   )
   if not InDetFlags.doCosmics():
      InDetTRTExtension.TrackExtensionTool     = InDetTRTExtensionTool
   else:
      InDetTRTExtension.TrackExtensionTool     = InDetTRTExtensionToolCosmics
      
   topSequence += InDetTRTExtension
   if (InDetFlags.doPrintConfigurables()):
     print          InDetTRTExtension
   
#
# ------------ Track Extension Processor
#
if InDetFlags.doExtensionProcessor():
   
   if InDetFlags.trtExtensionType() is 'DAF' :
      #
      # DAF Fitter setup
      #
      from TrkCompetingRIOsOnTrackTool.TrkCompetingRIOsOnTrackToolConf import Trk__CompetingRIOsOnTrackTool
      InDetCompetingRotCreator =  Trk__CompetingRIOsOnTrackTool( name                        = 'InDetCompetingRotCreator',
                                                                 ToolForCompPixelClusters    = None,      # default
                                                                 ToolForCompSCT_Clusters     = None,      # default
                                                                 ToolForCompTRT_DriftCircles = InDetCompetingTRT_DC_Tool )
      ToolSvc += InDetCompetingRotCreator
      if (InDetFlags.doPrintConfigurables()):
        print      InDetCompetingRotCreator
      #
      from TrkDeterministicAnnealingFilter.TrkDeterministicAnnealingFilterConf import Trk__DeterministicAnnealingFilter
      InDetExtensionFitter =  Trk__DeterministicAnnealingFilter( name = 'InDetDAF',
                                                                              ToolForExtrapolation           = InDetExtrapolator,
                                                                              ToolForCompetingROTsCreation   = InDetCompetingRotCreator,
                                                                              ToolForUpdating                = InDetUpdator,
                                                                              AnnealingScheme                = [200., 81., 9., 4., 1., 1., 1.],
                                                                              DropOutlierCutValue            = 1.E-7,
                                                                              OutlierCutValue                = 0.01 )
      ToolSvc += InDetExtensionFitter
      if (InDetFlags.doPrintConfigurables()):
        print      InDetExtensionFitter
   else:
      InDetExtensionFitter = InDetTrackFitter
   #
   # load scoring for extension
   #
   if not InDetFlags.doCosmics():
      from InDetTrackScoringTools.InDetTrackScoringToolsConf import InDet__InDetAmbiScoringTool
      InDetExtenScoringTool = InDet__InDetAmbiScoringTool(name           = 'InDetExtenScoringTool',
                                                          Extrapolator   = InDetExtrapolator,
                                                          SummaryTool    = InDetTrackSummaryTool,
                                                          useAmbigFcn    = True,
                                                          useTRT_AmbigFcn= False,
                                                          minPt          = InDetCutValues.minPT(),
                                                          maxRPhiImp     = InDetCutValues.maxPrimaryImpact(),
                                                          maxZImp        = InDetCutValues.maxZImpact(),
                                                          maxEta         = InDetCutValues.maxEta(),
                                                          minSiClusters  = InDetCutValues.minClusters(),
                                                          maxSiHoles     = InDetCutValues.maxHoles(),
                                                          maxDoubleHoles = InDetCutValues.maxDoubleHoles(),
                                                          minTRTonTrk    = InDetCutValues.minTRTonTrk(),
                                                          useSigmaChi2   = False) # do not use it for extension

      ToolSvc += InDetExtenScoringTool
      if (InDetFlags.doPrintConfigurables()):
         print      InDetExtenScoringTool     
         
   #
   # get configured track extension processor
   #
   from InDetExtensionProcessor.InDetExtensionProcessorConf import InDet__InDetExtensionProcessor   
   InDetExtensionProcessor = InDet__InDetExtensionProcessor ( name               = "InDetExtensionProcessor",
                                                              TrackName          = InputTrackCollection,
                                                              Cosmics            = InDetFlags.doCosmics(),
                                                              ExtensionMap       = OutputExtendedTracks,
                                                              NewTrackName       = InDetKeys.ExtendedTracks(),
                                                              TrackFitter        = InDetExtensionFitter,
                                                              suppressHoleSearch = False,  # does not work properly
                                                              RefitPrds          = not (InDetFlags.refitROT() or (InDetFlags.trtExtensionType() is 'DAF')))
   if InDetFlags.materialInteractions():
      InDetExtensionProcessor.matEffects = 3 # default in code is 4!!
   else :
      InDetExtensionProcessor.matEffects = 0

   if not InDetFlags.doCosmics():
      InDetExtensionProcessor.ScoringTool        = InDetExtenScoringTool
   else:
      InDetExtensionProcessor.ScoringTool        = InDetScoringToolCosmics_TRT  
   
   topSequence += InDetExtensionProcessor
   if (InDetFlags.doPrintConfigurables()):
     print          InDetExtensionProcessor
   #
   # and set new input track collection
   #
   InputTrackCollection    = InDetKeys.ExtendedTracks()

   #
   # ------------ Track truth.
   #
   if InDetFlags.doTruth():
      #
      # set up the truth info for this container
      #
      include ("InDetRecExample/ConfiguredInDetTrackTruth.py")
      InDetForwardTruth = ConfiguredInDetTrackTruth(InDetKeys.ExtendedTracks(),
                                                    InDetKeys.ExtendedDetailedTracksTruth(),
                                                    InDetKeys.ExtendedTracksTruth())
      #
      # add final output for statistics
      #
      TrackCollectionKeys      += [ InDetKeys.ExtendedTracks() ]
      TrackCollectionTruthKeys += [ InDetKeys.ExtendedTracksTruth() ]

   # output track collection
   ForwardTrackCollection = InDetKeys.ExtendedTracks()
else:
   ForwardTrackCollection = "ResolvedTracks"
