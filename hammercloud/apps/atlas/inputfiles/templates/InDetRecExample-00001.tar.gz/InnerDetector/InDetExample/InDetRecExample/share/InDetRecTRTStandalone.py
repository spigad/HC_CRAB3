#
# ----------- TRT Segment finding
#
   
#
# get list of already associated hits (always do this, even if no other tracking ran before)
#
from InDetTrackPRD_Association.InDetTrackPRD_AssociationConf import InDet__InDetTrackPRD_Association
InDetTRTonly_PRD_Association = InDet__InDetTrackPRD_Association(name            = 'InDetTRTonly_PRD_Association',
                                                                AssociationTool = InDetPrdAssociationTool,
                                                                TracksName      = list(InputCombinedInDetTracks)) 
topSequence += InDetTRTonly_PRD_Association
if (InDetFlags.doPrintConfigurables()):
  print          InDetTRTonly_PRD_Association

#
# Output key for the standalone TRT track finder
#
OutputTRTStandaloneTracks = "TRTStandaloneTracks"
#
# set up special Scoring Tool for standalone TRT tracks
#
from InDetTrackScoringTools.InDetTrackScoringToolsConf import InDet__InDetTrtTrackScoringTool
InDetTRT_StandaloneScoringTool = InDet__InDetTrtTrackScoringTool(name            = 'InDetTRT_StandaloneScoringTool',
                                                                 SummaryTool     = InDetTrackSummaryTool,
                                                                 useAmbigFcn     = True,
                                                                 useSigmaChi2    = False,
                                                                 PtMin           = InDetCutValues.minTRTonlyMinPt(),
                                                                 maxEta          = 2.1)
ToolSvc += InDetTRT_StandaloneScoringTool
if (InDetFlags.doPrintConfigurables()):
  print      InDetTRT_StandaloneScoringTool
#
# TRT standalone tracks algorithm
#
if not InDetFlags.doCosmics():
  from TRT_StandaloneTrackFinder.TRT_StandaloneTrackFinderConf import InDet__TRT_StandaloneTrackFinder
  InDetTRT_StandaloneTrackFinder = InDet__TRT_StandaloneTrackFinder(name                  = 'InDetTRT_StandaloneTrackFinder',
                                                                    RefitterTool          = InDetTrackFitterTRT,
                                                                    AssociationTool       = InDetPrdAssociationTool,
                                                                    ScoringTool           = InDetTRT_StandaloneScoringTool,
                                                                    Extrapolator          = InDetExtrapolator,
                                                                    FinalRefit            = True,
                                                                    UseAssociationTool    = True,
                                                                    MinNumDriftCircles    = InDetCutValues.minTRTonly(),
                                                                    MaxSharedHitsFraction = InDetCutValues.maxTRTonlyShared(),
                                                                    InputSegmentsLocation = InDetKeys.TRT_Segments(),
                                                                    SuppressHoleSearch    = True,
                                                                    OutputTracksLocation  = OutputTRTStandaloneTracks)
  topSequence += InDetTRT_StandaloneTrackFinder
  if (InDetFlags.doPrintConfigurables()):
    print          InDetTRT_StandaloneTrackFinder

else: 
  from TRT_SegmentsToTrack.TRT_SegmentsToTrackConf import InDet__TRT_SegmentsToTrack
  InDetTrkSegmenttoTrk_TRTstandalone=InDet__TRT_SegmentsToTrack(name="InDetTRT_SegmentsToTrack_Barrel_TRTstandalone",
                                                                OutputTrackCollection = "SegmentTracks_Barrel_TRTstandalone",
                                                                InputSegmentsCollection = "TRT_Segments_BarrelCosmics_TRTstandalone",
                                                                OutputCombiCollection = "notused_Barrel_TRTstandalone",
                                                                TrackFitter=InDetTrackFitter,
                                                                MinNHit = InDetCutValues.minTRTonTrkCosmics(),
                                                                CombineTracks = False,
                                                                InputSCTCollection = "",
                                                                MaterialEffects=False) # does not yet work properly for TRT-only tracks
  
  # TC: disabled until bugs are fixed
  topSequence += InDetTrkSegmenttoTrk_TRTstandalone
  if (InDetFlags.doPrintConfigurables()):
      print InDetTrkSegmenttoTrk_TRTstandalone

if InDetFlags.doCosmics():
  
  # now merge the NewT cosmic barrel segments with the EC ones
  from TRT_SegmentsToTrack.TRT_SegmentsToTrackConf import InDet__TRT_SegmentsToTrack
  InDetTrkSegmenttoTrk_EC_TRTstandalone=InDet__TRT_SegmentsToTrack(name="InDetTRT_SegmentsToTrack_Endcap_TRTstandalone",
                                                                   OutputTrackCollection = "SegmentTracks_EC_TRTstandalone",
                                                                   BarrelEndcapTracks = "SegmentTracks_Combined_Barrel_EC_TRTstandalone",
                                                                   OutputCombiCollection = "notused_EC_TRTstandalone",
                                                                   InputSegmentsCollection = "TRT_Segments_EC_TRTstandalone",
                                                                   InputSCTCollection = "",
                                                                   TrackFitter = InDetTrackFitter,
                                                                   MinNHit = InDetCutValues.minTRTonTrkCosmics(),
                                                                   CombineSegments = True,
                                                                   BarrelSegments = "TRT_Segments_BarrelCosmics_TRTstandalone",
                                                                   EndcapSegments = "TRT_Segments_EC_TRTstandalone",
                                                                   MaterialEffects = False) # does not yet work properly for TRT-only tracks
   
  topSequence += InDetTrkSegmenttoTrk_EC_TRTstandalone
  if (InDetFlags.doPrintConfigurables()):
    print InDetTrkSegmenttoTrk_EC_TRTstandalone

  # ambiguity-solve the cosmic TRT only tracks into one output collection
  from TrkAmbiguitySolver.TrkAmbiguitySolverConf import Trk__TrkAmbiguitySolver
  InDetAmbiguitySolver_TRTStandalone = Trk__TrkAmbiguitySolver(name               = 'InDetAmbiguitySolver_TRTStandalone',
                                                               TrackInput         = [ "SegmentTracks_Barrel_TRTstandalone",
                                                                                      "SegmentTracks_EC_TRTstandalone",
                                                                                      "SegmentTracks_Combined_Barrel_EC_TRTstandalone" ],
                                                               TrackOutput        = OutputTRTStandaloneTracks,
                                                               AmbiguityProcessor = InDetAmbiguityProcessorCosmics)
  
  topSequence += InDetAmbiguitySolver_TRTStandalone
  if (InDetFlags.doPrintConfigurables()):
    print          InDetAmbiguitySolver_TRTStandalone
    
    
#
#
# ------------ Track truth.
#
if InDetFlags.doTruth():
    #
    # set collection name for truth
    #
    TRTStandaloneTracksTruth           = "TRTStandaloneTracksTruthCollection"
    DetailedTRTStandaloneTracksTruth   = "TRTStandaloneTracksDetailedTruth"       
    #
    # set up the truth info for this container
    #
    include ("InDetRecExample/ConfiguredInDetTrackTruth.py")
    InDetTracksTruth = ConfiguredInDetTrackTruth(OutputTRTStandaloneTracks,
                                                 DetailedTRTStandaloneTracksTruth,
                                                 TRTStandaloneTracksTruth)
    #
    # add final output for statistics
    #
    TrackCollectionKeys      += [ OutputTRTStandaloneTracks ]
    TrackCollectionTruthKeys += [ TRTStandaloneTracksTruth ]

