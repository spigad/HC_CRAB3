# ------------------------------------------------------------
#
# ----------- now we do the RTF tracking
#
# ------------------------------------------------------------
#
# ----------- SiSPSeededTrackFinder
#
if InDetFlags.doSiSPSeededTrackFinder():
   #
   # Space points seeds maker, use different ones for cosmics and collisions
   #
   if not InDetFlags.doCosmics():
      from SiSpacePointsSeedTool_xk.SiSpacePointsSeedTool_xkConf import InDet__SiSpacePointsSeedMaker_ATLxk
      InDetSiSpacePointsSeedMaker = InDet__SiSpacePointsSeedMaker_ATLxk(name                   = 'InDetSpSeedsMaker',
                                                                        MagneticTool           = InDetPatternMagField,
                                                                        pTmin                  = InDetCutValues.minPT(),
                                                                        maxdImpact             = InDetCutValues.maxPrimaryImpact(),
                                                                        maxZ                   = InDetCutValues.maxZImpact(),
                                                                        minZ                   = -InDetCutValues.maxZImpact(),
                                                                        usePixel               = DetFlags.haveRIO.pixel_on(),
                                                                        SpacePointsPixelName   = InDetKeys.PixelSpacePoints(),
                                                                        useSCT                 = DetFlags.haveRIO.SCT_on(),
                                                                        SpacePointsSCTName     = InDetKeys.SCT_SpacePoints(),
                                                                        SpacePointsOverlapName = InDetKeys.OverlapSpacePoints())
      ToolSvc += InDetSiSpacePointsSeedMaker
      if (InDetFlags.doPrintConfigurables()):
         print      InDetSiSpacePointsSeedMaker
   else:
      from SiSpacePointsSeedTool_xk.SiSpacePointsSeedTool_xkConf import InDet__SiSpacePointsSeedMaker_Cosmic
      InDetSiSpacePointsSeedMakerCosmics = InDet__SiSpacePointsSeedMaker_Cosmic(name                   = 'InDetSpSeedsMakerCosmics',
                                                                                MagneticTool           = InDetPatternMagField,
                                                                                pTmin                  = InDetCutValues.minPTCosmics(),
                                                                                maxdImpact             = InDetCutValues.maxPrimaryImpactCosmics(),
                                                                                maxZ                   = InDetCutValues.maxZImpactCosmics(),
                                                                                minZ                   = -InDetCutValues.maxZImpactCosmics(),
                                                                                SpacePointsPixelName   = InDetKeys.PixelSpacePoints(),
                                                                                SpacePointsSCTName     = InDetKeys.SCT_SpacePoints(),
                                                                                SpacePointsOverlapName = InDetKeys.OverlapSpacePoints(),
                                                                                useOverlapSpCollection = True,
                                                                                UseAssociationTool     = False,
                                                                                AssociationTool        = InDetPrdAssociationTool)
      ToolSvc += InDetSiSpacePointsSeedMakerCosmics
      if (InDetFlags.doPrintConfigurables()):
         print      InDetSiSpacePointsSeedMakerCosmics
         
   
   #
   # Z-coordinates primary vertices finder (only for collisions)
   #
   if InDetFlags.useZvertexTool():
     from SiZvertexTool_xk.SiZvertexTool_xkConf import InDet__SiZvertexMaker_xk
     InDetZvertexMaker = InDet__SiZvertexMaker_xk(name          = 'InDetZvertexMaker',
                                                  SeedMakerTool = InDetSiSpacePointsSeedMaker,
                                                  Zmax          = InDetCutValues.maxZImpact(),
                                                  Zmin          = -InDetCutValues.maxZImpact(),
                                                  minRatio      = 0.17) # not default
     ToolSvc += InDetZvertexMaker
     if (InDetFlags.doPrintConfigurables()):
       print      InDetZvertexMaker
   else:
     InDetZvertexMaker = None
   
   #
   # Local track finding using space point seed
   #
   from SiTrackMakerTool_xk.SiTrackMakerTool_xkConf import InDet__SiTrackMaker_xk
   InDetSiTrackMaker = InDet__SiTrackMaker_xk(name                     = 'InDetSiTrackMaker',
                                              MagneticTool             = InDetPatternMagField,
                                              RoadTool                 = InDetSiDetElementsRoadMaker,
                                              CombinatorialTrackFinder = InDetSiComTrackFinder,
                                              pTmin                    = InDetCutValues.minPT(),
                                              nClustersMin             = 3, # was InDetCutValues.minClusters(),
                                              nWeightedClustersMin     = 6, # and this is new
                                              nHolesMax                = InDetCutValues.maxHoles(),
                                              nHolesGapMax             = 2, 
                                              SeedsFilterLevel         = 2)

   if InDetFlags.doCosmics():
      InDetSiTrackMaker.pTmin = InDetCutValues.minPTCosmics()
      InDetSiTrackMaker.nClustersMin             = 3 # InDetCutValues.minClustersCosmics()
      InDetSiTrackMaker.nWeightedClustersMin     = 6 # and this is new
      InDetSiTrackMaker.nHolesMax                = InDetCutValues.maxHolesCosmics()
      InDetSiTrackMaker.nHolesGapMax             = 2 # was 2
      InDetSiTrackMaker.SeedsFilterLevel         = 3
      InDetSiTrackMaker.UseAssociationTool       = False
      InDetSiTrackMaker.CosmicTrack              = True
      InDetSiTrackMaker.Xi2max                   = 60.0
      InDetSiTrackMaker.Xi2maxNoAdd              = 100.0
      #InDetSiTrackMaker.Xi2maxlink               = 200.0
      
   ToolSvc += InDetSiTrackMaker
   if (InDetFlags.doPrintConfigurables()):
     print      InDetSiTrackMaker
   
   #
   # set output track collection name
   OutputTrackCollection = "SiSPSeededTracks"
   
   #
   # Setup Track finder using space points seeds
   #
   from SiSPSeededTrackFinder.SiSPSeededTrackFinderConf import InDet__SiSPSeededTrackFinder
   InDetSiSPSeededTrackFinder = InDet__SiSPSeededTrackFinder(name           = 'InDetSiSpTrackFinder',
                                                             TrackTool      = InDetSiTrackMaker,
                                                             TracksLocation = OutputTrackCollection)

   if not InDetFlags.doCosmics():    
      InDetSiSPSeededTrackFinder.SeedsTool      = InDetSiSpacePointsSeedMaker
      InDetSiSPSeededTrackFinder.useZvertexTool = InDetFlags.useZvertexTool()
      InDetSiSPSeededTrackFinder.ZvertexTool    = InDetZvertexMaker
   else:
      InDetSiSPSeededTrackFinder.SeedsTool      = InDetSiSpacePointsSeedMakerCosmics
      InDetSiSPSeededTrackFinder.ZvertexTool    = None
      InDetSiSPSeededTrackFinder.useZvertexTool = False

   topSequence += InDetSiSPSeededTrackFinder
   if (InDetFlags.doPrintConfigurables()):
     print          InDetSiSPSeededTrackFinder

   #
   # set input collection for next algorithm
   #
   InputTrackCollection = OutputTrackCollection
    
   if InDetFlags.doTruth():
      #
      # set collection name for truth
      #
      InputTrackCollectionTruth = "SiSPSeededTracksTruthCollection"
      InputDetailedTrackTruth   = "SiSPSeededTracksDetailedTruth"
      #
      # set up the truth info for this container
      #
      include ("InDetRecExample/ConfiguredInDetTrackTruth.py")
         
      InDetTracksTruth = ConfiguredInDetTrackTruth(InputTrackCollection,
                                                   InputDetailedTrackTruth,
                                                   InputTrackCollectionTruth)
      #
      # add final output for statistics
      #
      TrackCollectionKeys      += [ InputTrackCollection ]
      TrackCollectionTruthKeys += [ InputTrackCollectionTruth ]
#
# ---------- Ambiguity solving
#
if InDetFlags.doAmbiSolving():
   #
   # load InnerDetector TrackSelectionTool
   #
   from InDetAmbiTrackSelectionTool.InDetAmbiTrackSelectionToolConf import InDet__InDetAmbiTrackSelectionTool
   InDetAmbiTrackSelectionTool = InDet__InDetAmbiTrackSelectionTool(name            = 'InDetAmbiTrackSelectionTool',
                                                                    AssociationTool = InDetPrdAssociationTool,
                                                                    minHits         = InDetCutValues.minClusters()-2,
                                                                    minNotShared    = InDetCutValues.minSiNotShared(),
                                                                    maxShared       = InDetCutValues.maxShared(),
                                                                    minTRTHits      = 0 ) # used for Si only tracking !!!
   if InDetFlags.doCosmics():
      InDetAmbiTrackSelectionTool.minHits         = InDetCutValues.minClustersCosmics()
      InDetAmbiTrackSelectionTool.minNotShared    = InDetCutValues.minSiNotShared()
      InDetAmbiTrackSelectionTool.maxShared       = InDetCutValues.maxShared()
      InDetAmbiTrackSelectionTool.Cosmics         = True
      
   ToolSvc += InDetAmbiTrackSelectionTool
   if (InDetFlags.doPrintConfigurables()):
     print      InDetAmbiTrackSelectionTool
   #
   # set up different Scoring Tool for collisions and cosmics
   #
   if not InDetFlags.doCosmics():
      from InDetTrackScoringTools.InDetTrackScoringToolsConf import InDet__InDetAmbiScoringTool
      InDetAmbiScoringTool = InDet__InDetAmbiScoringTool(name           = 'InDetAmbiScoringTool',
                                                         Extrapolator   = InDetExtrapolator,
                                                         SummaryTool    = InDetTrackSummaryTool,
                                                         useAmbigFcn    = True,
                                                         useTRT_AmbigFcn= False,
                                                         minPt          = InDetCutValues.minPT(),
                                                         maxRPhiImp     = InDetCutValues.maxPrimaryImpact(),
                                                         maxZImp        = InDetCutValues.maxZImpact(),
                                                         maxEta         = InDetCutValues.maxEta(),
                                                         minSiClusters  = InDetCutValues.minClusters(),
                                                         maxSiHoles     = InDetCutValues.maxHoles(),
                                                         maxDoubleHoles = InDetCutValues.maxDoubleHoles(),
                                                         minTRTonTrk    = 0,    # no TRT here
                                                         useSigmaChi2   = False) # tuning from Thijs
      # useSigmaChi2   = True) # use it for Si only
      ToolSvc += InDetAmbiScoringTool
      if (InDetFlags.doPrintConfigurables()):
         print      InDetAmbiScoringTool
   #
   # load Ambiguity Processor
   #
   from TrkAmbiguityProcessor.TrkAmbiguityProcessorConf import Trk__SimpleAmbiguityProcessorTool
   InDetAmbiguityProcessor = Trk__SimpleAmbiguityProcessorTool(name          = 'InDetAmbiguityProcessor',
                                                               Fitter        = InDetTrackFitter,
                                                               SelectionTool = InDetAmbiTrackSelectionTool,
                                                               SuppressHoleSearch = False,
                                                               RefitPrds     = not InDetFlags.refitROT())
   if InDetFlags.materialInteractions():
      InDetAmbiguityProcessor.MatEffects = 3
   else:
      InDetAmbiguityProcessor.MatEffects = 0

   if not InDetFlags.doCosmics():
      InDetAmbiguityProcessor.ScoringTool   = InDetAmbiScoringTool
   else:
      InDetAmbiguityProcessor.ScoringTool = InDetScoringToolCosmics_SiPattern
      
   ToolSvc += InDetAmbiguityProcessor
   if (InDetFlags.doPrintConfigurables()):
     print      InDetAmbiguityProcessor
   #
   # set output track name
   #
   OutputTrackCollection = "ResolvedTracks"
   #
   # configure Ambiguity solver
   #
   from TrkAmbiguitySolver.TrkAmbiguitySolverConf import Trk__TrkAmbiguitySolver
   InDetAmbiguitySolver = Trk__TrkAmbiguitySolver(name               = 'InDetAmbiguitySolver',
                                                  TrackInput         = [ InputTrackCollection ],
                                                  TrackOutput        = OutputTrackCollection,
                                                  AmbiguityProcessor = InDetAmbiguityProcessor)
   topSequence += InDetAmbiguitySolver
   if (InDetFlags.doPrintConfigurables()):
     print          InDetAmbiguitySolver

   #
   # Input of the next algorithm
   #
   InputTrackCollection = OutputTrackCollection

   if InDetFlags.doTruth():
      #
      # set collection name for truth
      #
      InputTrackCollectionTruth = "ResolvedTracksTruthCollection"
      InputDetailedTrackTruth   = "ResolvedTracksDetailedTruth"      
      #
      # set up the truth info for this container
      #
      include ("InDetRecExample/ConfiguredInDetTrackTruth.py")

      InDetTracksTruth = ConfiguredInDetTrackTruth(InputTrackCollection,
                                                   InputDetailedTrackTruth,
                                                   InputTrackCollectionTruth)
      #
      # add final output for statistics
      #
      TrackCollectionKeys      += [ InputTrackCollection ]
      TrackCollectionTruthKeys += [ InputTrackCollectionTruth ]

   # output track collection, needed for TRT Extension
   SiTrackCollection = InputTrackCollection
