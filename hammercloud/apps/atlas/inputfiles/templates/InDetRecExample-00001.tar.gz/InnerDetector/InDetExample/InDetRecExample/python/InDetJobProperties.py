##
## @file InDetRecExample/python/InDetJobProperties.py
## @purpose Python module to hold common flags to configure JobOptions
##

""" InDetJobProperties
    Python module to hold common flags to configure InDet JobOptions.

"""

__author__ = "A. Wildauer"
__version__= "$Revision: 1.82 $"
__doc__    = "InDetJobProperties"

__all__    = [ "InDetJobProperties" ]

# kindly stolen from AthenaCommonFlags from S. Binet and M. Gallas

##-----------------------------------------------------------------------------
## Import

from AthenaCommon.JobProperties import JobProperty, JobPropertyContainer
from AthenaCommon.JobProperties import jobproperties

##-----------------------------------------------------------------------------
## 0th step: define infrastructure JPs DO NOT MODIFY THEM!!!


class Enabled(JobProperty):
   """ jobproperty to disable/enable algorithms in the same context
   (container) in one go
   """
   statusOn=True
   allowedTypes=['bool']
   StoredValue=True

   def _do_action(self):
       for obj in self._the_same_context_objects():
           obj.set_On()

   def _undo_action(self):
       for obj in self._the_same_context_objects():
           obj.set_Off()

   def _the_same_context_objects(self):
       context = self._context_name.partition('.'+self.__name__)
       objects = list()

       for i in self.__class__._nInstancesContextDict.keys():
           oname = self.__class__._nInstancesContextDict[i].__name__
           ocontext = self.__class__._nInstancesContextDict[i]._context_name.partition('.'+oname)
           if context !=  ocontext:
               #print ocontext
               if context[0] == ocontext[0]:
                   objects.append(self.__class__._nInstancesContextDict[i])
       return objects

class InDetFlagsJobProperty(JobProperty):
    """ special flag class ANDing with jobproperies.CaloRecFlags.Enabled
    """
    def get_Value(self):
        return self.statusOn and self.StoredValue

##-----------------------------------------------------------------------------
## 1st step: define JobProperty classes

class doPrintConfigurables(JobProperty):
    """if this is on the all the print InDetXYZ lines are activated"""
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = False

class doNewTracking(InDetFlagsJobProperty):
    """Turn running of newTracking on and off"""
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = True

class doxKalman(InDetFlagsJobProperty):
    """Turn running of xKalman on and off"""
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = False

class doiPatRec(InDetFlagsJobProperty):
    """Turn running of iPatRec on and off"""
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = True

class doCTBTracking(InDetFlagsJobProperty):
    """Turn running of CTB Tracking on and off"""
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = False

class preProcessing(InDetFlagsJobProperty):
    """Turn running of pre processing on and off"""
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = True

class doRefit(InDetFlagsJobProperty):
    """Turn running of refitting on and off"""
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = False

class postProcessing(InDetFlagsJobProperty):
    """Turn running of post processing on and off"""
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = True

class doTruth(InDetFlagsJobProperty):
    """Turn running of truth matching on and off"""
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = True

class loadTools(InDetFlagsJobProperty):
    """Turn loading of tools on and off"""
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = True

class doBackTracking(InDetFlagsJobProperty):
    """Turn running of backtracking on and off"""
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = True

class doSingleSpBackTracking(InDetFlagsJobProperty):
    """Turn running of single SP backtracking on and off"""
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = False

class doLowPt(InDetFlagsJobProperty):
    """Turn running of doLowPt second pass on and off"""
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = False
                  
class doBeamGas(InDetFlagsJobProperty):
    """Turn running of BeamGas second pass on and off"""
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = False
                  
class doBeamHalo(InDetFlagsJobProperty):
    """Turn running of BeamHalo second pass on and off"""
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = False

class doCosmics(InDetFlagsJobProperty):
    """Turn running of Cosmics on and off"""
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = False

class doParticleCreation(InDetFlagsJobProperty):
    """Turn running of particle creation on and off"""
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = True

class doTrackSegmentsPixel(InDetFlagsJobProperty):
    """Turn running of track segment creation in pixel on and off"""
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = False

class doTrackSegmentsSCT(InDetFlagsJobProperty):
    """Turn running of track segment creation in SCT on and off"""
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = False

class doTrackSegmentsTRT(InDetFlagsJobProperty):
    """Turn running of track segment creation in TRT on and off"""
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = False

class doMonitoringGlobal(InDetFlagsJobProperty):
    """ Use to turn on global monitoring """
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = False

class doMonitoringPixel(InDetFlagsJobProperty):
    """ Use to turn on Pixel monitoring """
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = False

class doMonitoringSCT(InDetFlagsJobProperty):
    """ Use to turn on SCT monitoring """
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = False

class doMonitoringTRT(InDetFlagsJobProperty):
    """ Use to turn on TRT monitoring """
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = False

class doMonitoringAlignment(InDetFlagsJobProperty):
    """ Use to turn on alignment monitoring """
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = False

class doPerfMon(InDetFlagsJobProperty):
    """ Use to turn on PerfMon """
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = False

class AODall(InDetFlagsJobProperty):
    """ """
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = False

class useBeamConstraint(InDetFlagsJobProperty):
    """ use beam spot service in new tracking """
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = True

class kalmanUpdator(JobProperty):
    """ control which updator to load for KalmanFitter ("None"/"fast"/"weight") """
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'None'

class magField(JobProperty):
    """ control which field tool to use ("None"/"fast") """
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'None'

class propagatorType(JobProperty):
    """ control which propagator to use ('RungeKutta'/'STEP') """
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'RungeKutta'

class trackFitterType(JobProperty):
    """ control which fitter to be used: 'KalmanFitter', 'KalmanDNAFitter', 'DistributedKalmanFilter', 'GlobalChi2Fitter', 'GaussianSumFilter' """
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'GlobalChi2Fitter'

class useNewGlobalChi2Tuning(InDetFlagsJobProperty):
    """ """
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = False

class loadDynamicLayerCreator(InDetFlagsJobProperty):
    """ """
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = False

class doHolesOnTrack(InDetFlagsJobProperty):
    """ do holes search from now on in summry tool """
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = True

class useZvertexTool(InDetFlagsJobProperty):
    """ start with Zvertex finding """
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = False

class doSiSPSeededTrackFinder(InDetFlagsJobProperty):
    """ s """
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = False

class trtExtensionType(JobProperty):
    """ which extension type ("xk"/"DAF") """
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = "xk"
      
class redoTRT_LR(InDetFlagsJobProperty):
    """ use smart TRT LR/tube hit creator and redo ROTs """
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = True

class doTrtSegments(InDetFlagsJobProperty):
    """ control to run TRT Segment finding (do it always after new tracking!) """
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = True

class doTRTSeededTrackFinder(InDetFlagsJobProperty):
    """ control running the back tracking """
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = False

class loadTRTSeededSPFinder(InDetFlagsJobProperty):
    """ control which SP finder is used """
    # exclusive with loadSimpleTRTSeededSPFinder
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = True

class loadSimpleTRTSeededSPFinder(InDetFlagsJobProperty):
    """ control which SP finder is used """
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = False
      
class doResolveBackTracks(InDetFlagsJobProperty):
    """ control running the ambi on back tracking """
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = False
      
class doTRTStandalone(InDetFlagsJobProperty):
    """ control TRT Standalone """
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = True
      
class refitROT(InDetFlagsJobProperty):
    """ control if refit is done from PRD or ROT """
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = True

class doSlimming(InDetFlagsJobProperty):
    """ turn track slimming on/off """
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = True

class doVertexFinding(InDetFlagsJobProperty):        
    """  """
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = True

class primaryVertexSetup(JobProperty):
    """ string to store the type of finder/fitter for pri vertexing, possible types: 'AdaptiveMultiFinding', 'AdaptiveFinding', 'DefaultFastFinding', 'DefaultFullFinding', 'DefaultKalmanFinding', 'DefaultAdaptiveFinding', 'DefaultVKalVrtFinding' """
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'AdaptiveMultiFinding'

class doPrimaryVertex3DFinding(JobProperty):
   """ control if to use 3d seeding for primary vertex finding (useful in case of poor / no knowledge of the beam spot """
   statusOn = True
   allowedTypes = ['bool']
   StoredValue = True       # will be set to false automatically if beam constraint ON, otherwise true

class doSharedHits(InDetFlagsJobProperty):
    """ control if the shared hits are recorded in TrackPatricles """
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = True

class doV0Finder(JobProperty):  
    """ switch on/off V0 finder  """
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = True

class useV0Fitter(JobProperty):  
    """ use V0 Fitter (alternative is VKalVrt) """
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = True

class doSecVertexFinder(JobProperty):  
    """ switch on/off conversion finder fitting V0s  """
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = False

class doConversions(JobProperty):
    """ switch on/off conversion finder """
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = True

class doBremFitAlg(JobProperty):
    """  """
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = False

class doStatistics(JobProperty):
    """  """
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = True

class doStatNtuple(JobProperty):
    """  """
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = False

class doStandardPlots(JobProperty):
    """ Use to turn on creating the Standard Plots of tracking performance """
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = False

class materialInteractions(JobProperty):
    """  """
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = True

class doTrkNtuple(InDetFlagsJobProperty):
    """  """
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = False
        
class doPixelTrkNtuple(InDetFlagsJobProperty):
    """  """
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = False
        
class doVtxNtuple(InDetFlagsJobProperty):
    """  """
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = False
        
class doConvVtxNtuple(InDetFlagsJobProperty):
    """  """
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = False
        
class doV0VtxNtuple(InDetFlagsJobProperty):
    """  """
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = False
        
class removeTRTNoise(InDetFlagsJobProperty):
    """  """
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = True
        
class cutSCTOccupancy(InDetFlagsJobProperty):
    """  """
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = True

class useDCS(InDetFlagsJobProperty):
    """  """
    statusOn     = True
    allowedTypes = ['bool']
    StoredValue  = True

class truthMatchStrategy(JobProperty):
    """defines how truth matching is done. possible values TruthMatchRatio (old style) or TruthMatchTanimoto (new style)"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'TruthMatchRatio'

##-----------------------------------------------------------------------------
## 2nd step
## Definition of the InDet flag container
class InDetJobProperties(JobPropertyContainer):
  """Container for the InDet flags
  """

  def __init__(self, context=''):
    #allow specifying context (used by the trigger) 
    JobPropertyContainer.__init__(self,context)

  def setupDefaults(self):
    #Method to setup the flags according to the beamtype.
    #It MUST ONLY BE CALLED ONCE at the end of this file!!!"""
    print "InDetJobProperties::setupDefaults(): This method MUST ONLY BE CALLED ONCE inside InDetRecExample/InDetJobProperties.py."
    print "jobproperties.Beam.beamType must be set before calling this method constructor (otherwise the default value of beamType will be used)"
    # -------------------------------------------------------------------
    # disable things depending on global beam setup
    # -------------------------------------------------------------------
    from RecExConfig.RecFlags import rec
    if rec.doMonitoring():
      self.doMonitoringGlobal    = True
      self.doMonitoringPixel     = True
      self.doMonitoringSCT       = True
      self.doMonitoringTRT       = True
      self.doMonitoringAlignment = True
    from AthenaCommon.BeamFlags import jobproperties
    if (jobproperties.Beam.beamType()=="singlebeam"):
      print "InDetJobProperties::__init__() BeamType is set to singlebeam - setting flags accordingly!"
      self.doNewTracking          = False
      self.doLowPt                = False
      self.doBeamGas              = True
      self.doBeamHalo             = True
      self.doxKalman              = False
      self.doiPatRec              = False
      self.doBackTracking         = False
      self.doTRTStandalone        = False
      self.doSingleSpBackTracking = False
      self.doParticleCreation     = True
      self.doVertexFinding        = False
      self.doV0Finder             = False
      self.doSecVertexFinder      = False
      self.doConversions          = False
      self.materialInteractions   = False
      self.doSlimming             = False

    elif (jobproperties.Beam.beamType()=="cosmics"):
      print "InDetJobProperties::__init__() BeamType is set to cosmics - setting flags accordingly!"
      self.doNewTracking          = True
      self.doCTBTracking          = True
      self.doLowPt                = False
      self.doBeamGas              = False
      self.doBeamHalo             = False
      self.doxKalman              = False
      self.doiPatRec              = False
      self.doBackTracking         = True
      self.doTRTStandalone        = True
      self.doSingleSpBackTracking = False
      self.doParticleCreation     = True
      self.doVertexFinding        = False
      self.doV0Finder             = False
      self.doSecVertexFinder      = False
      self.doConversions          = False
      self.doTrackSegmentsPixel   = True
      self.doTrackSegmentsSCT     = True
      self.doTrackSegmentsTRT     = True
      self.doCosmics              = True
      self.preProcessing          = True
      self.doSlimming             = False

    elif (jobproperties.Beam.beamType()=="collisions") and rec.Commissioning():
      print "InDetJobProperties::__init__() BeamType is set to collisions - I use commissioning settings of InDetFlags!"
      self.doLowPt                = False
      self.doBeamGas              = False
      self.doBeamHalo             = False
      self.doxKalman              = False
      self.doiPatRec              = False
      self.doSingleSpBackTracking = False
      self.doV0Finder             = False
      self.doSecVertexFinder      = False
      self.doConversions          = False
      self.doTrackSegmentsPixel   = True
      self.doTrackSegmentsSCT     = True
      self.doTrackSegmentsTRT     = True
      self.doSlimming             = False
      self.doPixelTrkNtuple       = True
    elif (jobproperties.Beam.beamType()=="collisions"):
      print "InDetJobProperties::__init__() BeamType is set to collisions - I use default settings of InDetFlags!"
    else:
      print "InDetJobProperties::__init__() BeamType is set an unallowed value: ",jobproperties.Beam.beamType()
 

  def init(self):
    #Method to do the final setup of the flags according to user input before.
    #This method MUST ONLY BE CALLED once in InDetRecExample/InDetRec_jobOptions.py!!
    if not self.Enabled:
      print 'InDetFlags.init(): ID flags are disabled. Locking container and not doing anything else.'
    else:
      print 'Initializing InDetJobProperties with DetFlags and GlobalFlags'
      from AthenaCommon.GlobalFlags import globalflags
      from AthenaCommon.DetFlags    import DetFlags
      
      # -------------------------------------------------------------------
      # ESD/AOD output options
      # -------------------------------------------------------------------
      if self.AODall() and jobproperties.Beam.beamType()=="collisions":
        self.doiPatRec     = True
        self.doNewTracking = True
      
      # --------------------------------------------------------------------
      # --- 1st iteration, inside out tracking
      # --------------------------------------------------------------------
      #
      # no new tracking if pixel or sct off (new tracking = inside out only)
      self.doNewTracking = self.doNewTracking() and (DetFlags.haveRIO.pixel_on() or DetFlags.haveRIO.SCT_on())
      #
      # no low pt tracking if no new tracking before!      
      self.doLowPt       = self.doLowPt() and self.doNewTracking()
      #
      # no BeamGas tracking if no new tracking before (but only if beamtype is not single beam!)      
      if (jobproperties.Beam.beamType()!="singlebeam"):
        self.doBeamGas     = self.doBeamGas() and self.doNewTracking()
      #
      #
      # --------------------------------------------------------------------
      # --- 2nd iteration, outside in tracking
      # --------------------------------------------------------------------
      #
      # control whether to run SiSPSeededTrackFinder
      self.doSiSPSeededTrackFinder = (self.doNewTracking() or self.doBeamGas()) and (DetFlags.haveRIO.pixel_on() or DetFlags.haveRIO.SCT_on())      
      # failsafe lines in case requirements are not met to run TRT standalone or back tracking
      self.doTRTStandalone         = self.doTRTStandalone() and DetFlags.haveRIO.TRT_on()
      self.doBackTracking          = self.doBackTracking() and DetFlags.haveRIO.TRT_on() and DetFlags.haveRIO.SCT_on()
      self.doSingleSpBackTracking  = self.doSingleSpBackTracking() and self.doBackTracking()
      #      
      # control to run steps which are needed for outside in tracking
      self.doTrtSegments           = (self.doTRTStandalone() or self.doBackTracking() or self.doSingleSpBackTracking()) 
      self.doTRTSeededTrackFinder  = self.doBackTracking()
      self.doResolveBackTracks     = self.doBackTracking()
      #
      # --------------------------------------------------------------------
      # ---- PostProcessing algorithms
      # --------------------------------------------------------------------
      #
      # control if run vertexing
      self.doVertexFinding          = self.postProcessing() and self.doVertexFinding()
      self.doPrimaryVertex3DFinding = self.doPrimaryVertex3DFinding() and (not self.useBeamConstraint())
      #
      # control whether to create TrackParticles (default=true)
      self.doParticleCreation       = self.postProcessing() and self.doParticleCreation()
      #
      # control to run InDetV0Finder
      self.doV0Finder               = self.postProcessing() and self.doV0Finder()
      #
      # control to run alternative InDetV0Finder
      self.doSecVertexFinder           = self.postProcessing() and self.doSecVertexFinder()
      #
      # control to run InDetConversionFinder
      self.doConversions            = self.postProcessing() and self.doConversions()
      #
      # control to run InDetBremFitAlg
      self.doBremFitAlg             = self.postProcessing() and self.doBremFitAlg()
      #
      # --------------------------------------------------------------------
      # ---- Statistics
      # --------------------------------------------------------------------
      #
      # control whether to do statistics package
      # self.doStatistics            = (self.doTruth() and (self.doxKalman() or self.doiPatRec() or self.doNewTracking())) and self.doStatistics()
      self.doStatistics            = self.postProcessing() and self.doTruth() and self.doStatistics()
      # control to run Standard Plots
      self.doStandardPlots         = self.postProcessing() and self.doTruth() and self.doStandardPlots()
      #
      # to be able to turn on the standalone trackings (if detector is on)
      self.doTrackSegmentsPixel  = self.doTrackSegmentsPixel() and DetFlags.haveRIO.pixel_on()
      self.doTrackSegmentsSCT    = self.doTrackSegmentsSCT()   and DetFlags.haveRIO.SCT_on()
      self.doTrackSegmentsTRT    = self.doTrackSegmentsTRT()   and DetFlags.haveRIO.TRT_on()
       
      self.doPixelTrkNtuple      = self.doPixelTrkNtuple() and DetFlags.haveRIO.pixel_on()
      # --------------------------------------------------------------------
      # ---- Loading of Tools (depends on settings above)
      # --------------------------------------------------------------------
      #
      # control if to load the tools
      self.loadTools  =  self.loadTools() and \
                        (self.doNewTracking() or  
                         self.doCTBTracking() or
                         self.doiPatRec()     or 
                         self.doxKalman()     or 
                         self.doBeamGas()     or 
                         self.doBeamHalo()    or 
                         self.postProcessing()or 
                         self.doRefit()       or 
                         self.doTrackSegmentsPixel() or 
                         self.doTrackSegmentsSCT()   or 
                         self.doTrackSegmentsTRT()   or
                         self.doTrkNtuple()   or
                         self.doPixelTrkNtuple() or
                         self.doVtxNtuple())
       #
      # --------------------------------------------------------------------
      # --- some configuration of options for the new tracking
      # --------------------------------------------------------------------
      #

      # -------------------------------------------------------------------
      # switch off material effects for cosmics without field
      # -------------------------------------------------------------------
      #if self.doCosmics() and not self.solenoidOn():
      #   self.materialInteractions = False


      # -------------------------------------------------------------------
      # some tracking switches
      # -------------------------------------------------------------------
      self.redoTRT_LR = DetFlags.haveRIO.TRT_on()
      if self.trtExtensionType() == 'DAF':
        self.redoTRT_LR            = False
      if (self.trackFitterType() is 'GlobalChi2Fitter' and self.loadTools()) :
        self.loadDynamicLayerCreator = True
      else:
        self.loadDynamicLayerCreator = False
      #
      # --------------------------------------------------------------------
      # ---- Refit of tracks
      # --------------------------------------------------------------------
      #
      if (self.trackFitterType() is not 'KalmanFitter' and self.trackFitterType() is not 'KalmanDNAFitter') :
          self.refitROT                = True
      if not self.refitROT() and not self.redoTRT_LR():
        print 'ConfiguredInDetFlags.py       WARNING refitROT and redoTRT_LR are both False, NOT RECOMMENDED!' 
      #
      # check if a valid fitter has been used
      if not (   (self.trackFitterType() is 'KalmanFitter') \
            or (self.trackFitterType() is 'KalmanDNAFitter') \
            or (self.trackFitterType() is 'DistributedKalmanFilter') \
            or (self.trackFitterType() is 'GlobalChi2Fitter' ) \
            or (self.trackFitterType() is 'GaussianSumFilter') ):
        print 'InDetJobProperties.py       WARNING unregistered or invalid track fitter setup.'
        print '                                      --> re-setting to TrkKalmanFitter.'
        self.trackFitterType = 'KalmanFitter'
      
      print "Initialization of InDetFlags finished - locking container!"
    # do this also if Enabled == False
    self.lock_JobProperties()

  def loadTrackingGeometry(self):
    return self.loadTools()
  
  def doAmbiSolving(self):
    from AthenaCommon.DetFlags    import DetFlags
    return (self.doNewTracking() or self.doBeamGas() or self.doTrackSegmentsPixel() or self.doTrackSegmentsSCT()) and (DetFlags.haveRIO.pixel_on() or DetFlags.haveRIO.SCT_on())
  
  def loadRotCreator(self):
    return self.loadTools()
  
  def loadUpdator(self):
    return self.loadTools()
  
  def loadExtrapolator(self):
    return self.loadTools()
  
  def loadFitter(self):
    return self.loadTools()
  
  def loadAssoTool(self):
    return self.loadTools()
    
  def loadSummaryTool(self):
    return self.loadTools()
  
  def doLegacyConversion(self):
    return (self.doxKalman() or self.doiPatRec())
  
  def doPRDFormation(self):
    from AthenaCommon.DetFlags    import DetFlags
    return self.preProcessing() and (DetFlags.haveRIO.pixel_on() or DetFlags.haveRIO.SCT_on() or DetFlags.haveRIO.TRT_on())
  
  def doPattern(self):
    return self.doxKalman() or self.doiPatRec() or self.doNewTracking() or self.doBackTracking() or self.doBeamGas() or self.doBeamHalo()
  
  def doSpacePointFormation(self):
    from AthenaCommon.DetFlags    import DetFlags
    return (self.preProcessing() and (DetFlags.haveRIO.pixel_on() or DetFlags.haveRIO.SCT_on()))
  
  def doTRTExtension(self):
    from AthenaCommon.DetFlags    import DetFlags
    return (self.doNewTracking() or self.doBeamGas()) and DetFlags.haveRIO.TRT_on()
  
  def doExtensionProcessor(self):
    from AthenaCommon.DetFlags    import DetFlags
    return (self.doNewTracking() or self.doBeamGas()) and DetFlags.haveRIO.TRT_on()

  def solenoidOn(self):
    from AthenaCommon.BFieldFlags import jobproperties
    return jobproperties.BField.solenoidOn()
  
# ----------------------------------------------------------------------------
# --- Printout of settings
# ----------------------------------------------------------------------------

  def printInfo(self) :
    print '****** Inner Detector Flags ********************************************************'
    if self.AODall() :
      print '*'
      print '* --------------------> write AOD classes for all trackers!'
    print '*'
    print '* PreProcessing:'
    print '* =============='
    print '*'
    if self.doPRDFormation() :
      print '* - run PrepRawDataFormation'
    if self.doSpacePointFormation() :
      print '* - run SpacePointFormation'
    print '*'
    print '* TrackFinding:'
    print '* ============='
    print '*'
    if self.doNewTracking() :
      print '* NewTracking is ON:'
    if self.doCosmics() :
      print '* Tracking for cosmics is ON:'
    if self.doSiSPSeededTrackFinder() :
      print '*   - run SiSPSeededTrackFinder'
      if self.useZvertexTool() :
        print '*     and use ZvertexTool'
    if self.doCTBTracking() :
      print '*   - run CTB tracking'
    if self.doAmbiSolving() :
      print '*   - run AmbiguitySolver'
    if self.doTRTExtension() :
      print '*   - run TRT_TrackExtension'
    if self.doExtensionProcessor() :
      print '*   - run TrackExtensionProcessor'
      if self.redoTRT_LR() :
        print '*     and redo LR and tube hits in fit for TRT !!!'
    print '*'
    if self.doTrtSegments() :
      print '* - run TRT Segment finding'
    if self.doTRTSeededTrackFinder() :
      print '* - run TRT seeded track finding'
      if self.loadTRTSeededSPFinder() :
        print '*   and load TRT_SeededSpacePointFinder'
      if self.loadSimpleTRTSeededSPFinder() :
        print '*   and load SimpleTRT_SeededSpacePointFinder'
      if self.doResolveBackTracks() :
        print '* - run ambi on TRT seeded tracks'
    if self.doSingleSpBackTracking() :
      print '* - create Single SP back tracks'
    print '*'
    if self.doTRTStandalone() :
      print '* - create TRT standalone tracks'
    print '*'
    if self.doRefit() :
      print '* - do a refit of all tracks'
      print '*'
    if self.doSlimming() :
      print '* - slim down the tracks for output on ESD'
      print '*'
    if self.doTrackSegmentsPixel() or self.doTrackSegmentsSCT() or self.doTrackSegmentsTRT():
      print '* Create separate track segments for:'
      standAloneTracking = '*   - '
      if self.doTrackSegmentsPixel():
        standAloneTracking += 'Pixel '
      if self.doTrackSegmentsSCT():
        standAloneTracking += 'SCT '
      if self.doTrackSegmentsTRT():
        standAloneTracking += 'TRT'
      print standAloneTracking
      print '*'
    if self.doxKalman() or self.doiPatRec():
      print '* Alternative trackings:'
      if self.doxKalman() :
        print '*   - run xKalman'
      if self.doiPatRec() :
        print '*   - run iPatRec'
      if self.doLegacyConversion() :
        print '*   - convert their output to TrkTrack EDM'
    print '*'

    print '* PostProcessing:'
    print '* ==============='
    print '*'
    if self.doVertexFinding() :
      print '* - run primary vertex finding with '+self.primaryVertexSetup()
      if self.doPrimaryVertex3DFinding() :
        print '  * - use 3D seed finding'
    if self.doParticleCreation() :
      print '* - create TrackParticles'
      if self.doSharedHits() :
        print '*   and do shared hits search'
    print '*'
    if self.doV0Finder() :
      print '* - run V0 finder'
      if self.useV0Fitter() :
         print '*   use V0 fitter'
      else:
         print '*   use VkalVrt'
    if self.doSecVertexFinder() :
      print '* - run V0 search using conversion finder'
    if self.doConversions() :
      print '* - run conversion finder'
    if self.doBremFitAlg() :
      print '* - run electron brem fitting prototype'
    print '*'
    if self.doTruth() :
      print '* - run truth association: '+self.truthMatchStrategy()
    print '*'
    if self.doStatistics() :
      print '* - run statistics packages'
      if self.doStatNtuple() :
        print '*   and create nutple'
    if self.doStandardPlots() :
      print '* - run Standard Plots package'
    print '*'
    if self.doTrkNtuple() or self.doPixelTrkNtuple() or self.doVtxNtuple() or self.doConvVtxNtuple() or self.doV0VtxNtuple():
      ntupleString = '* - Ntuple creation on for'
      if self.doTrkNtuple():
        ntupleString += ' NewTracking'
      if self.doPixelTrkNtuple():
        ntupleString += ' Pixels'
      if self.doVtxNtuple():
        ntupleString += ' PrimaryVertexing'
      if self.doConvVtxNtuple():
        ntupleString += ' Conversions'
      if self.doV0VtxNtuple():
        ntupleString += ' V0s'
      print ntupleString
    print '*'
    print '* Configurable Services loaded:'
    print '* ============================='
    print '*'
    if self.loadTrackingGeometry() :
      print '* - load tracking geometry for Inner Detector'
    print '*'
    if self.useBeamConstraint() :
      print '* - use Beam Spot Constraint in reconstruction/vertexing'
    print '*'
    print '* Configurable Tools loaded:'
    print '* =========================='
    print '*'
    if self.loadRotCreator() :
      print '* - load ROT_Creator for Inner Detector'
    if self.loadExtrapolator() :
      print '* - load Extrapolator:'
      if self.propagatorType() is 'RungeKutta' :
        print '*     load Runge Kutta propagator'
      elif self.propagatorType() is 'STEP' :
        print '*     load STEP propagator'
      if self.magField() is "fast" :
        print '*     load MagFieldTool_xk'
      else:
        print '*     load MagFieldTool'
      if self.materialInteractions() :
        print '*     use material corrections in extrapolation and fit'
    if self.loadUpdator() :
      if self.kalmanUpdator() is "fast" :
        print '* - load MeasurementUpdator_xk'
      else:
        print '* - load MeasurementUpdator'
    if self.loadFitter() :
      print '* - load track fitter of type ', self.trackFitterType()
      if self.useNewGlobalChi2Tuning() :
        print '*     use new tuning with brem points'
      if self.loadDynamicLayerCreator() :
        print '*     load dynamic layer creator'
      if self.refitROT() :
        print '*     refit from ROT'
      else:
        print '*     refit from PRD, redo the ROTs'
    if self.loadAssoTool() :
      print '* - load PRD_AssociationToolGangedPixels'
    if self.loadSummaryTool() :
      print '* - load TrackSummaryTool'
      if self.doHolesOnTrack() :
        print '*   and do holes on track search'
      print '*'  
    if (self.doMonitoringGlobal() or self.doMonitoringPixel() or self.doMonitoringSCT() or self.doMonitoringTRT() or self.doMonitoringAlignment()):
      myString = '* - Monitoring on for'
      if self.doMonitoringGlobal():
        myString += ' Global'
      if self.doMonitoringPixel():
        myString += ' Pixel'
      if self.doMonitoringSCT():
        myString += ' SCT'
      if self.doMonitoringTRT():
        myString += ' TRT'
      if self.doMonitoringAlignment():
        myString += ' Alignment'
      print myString
      print '*'
    print '************************************************************************************'
    
# ----------------------------------------------------------------------------
# --- set methods for less often used switches
# ----------------------------------------------------------------------------
  
  # decide if the SiSpacePoint track finder should look for primary vertices
  # in z and use this constraint during pattern recognition
  def usePrimVertexZcoordinate ( self, usezvertex ) :
    self.useZvertexTool = usezvertex
    if not self.doNewTracking() :
      print 'ConfiguredInDetFlags.py       WARNING toggling the z-vertex constraint has no effect'
      print '                                      because the new tracking IS NOT SWITCHED ON!'

  # control the validation & ntuple output based on InDetRecStatistics
  def enableStatistics ( self, doStat = True, doStatNtuple = True, StatNtupleName = "InDetRecStatistics.root" ) :
    self.doStatistics            = doStat
    self.doStatNtuple            = doStatNtuple
    from InDetRecExample.InDetKeys import InDetKeys
    InDetKeys.StatNtupleName     = StatNtupleName

# ----------------------------------------------------------------------------
# --- set different vertexing options
# ----------------------------------------------------------------------------

  #def enableTrackSlimming(self, doSlimming):
    #self.doSlimming = doSlimming

##-----------------------------------------------------------------------------
## 3rd step
## adding the container to the general top-level container
jobproperties.add_Container(InDetJobProperties)

##-----------------------------------------------------------------------------
## 4th step
## adding ID flags to the InDetJobProperties container
_list_InDetJobProperties = [Enabled,
			    doPrintConfigurables,
                            doNewTracking,
                            doxKalman,
                            doiPatRec,
                            doCTBTracking,
                            preProcessing,
                            doRefit,
                            postProcessing,
                            doTruth,
                            loadTools,
                            doBackTracking,
                            doSingleSpBackTracking,
                            doLowPt,
                            doBeamGas,
                            doBeamHalo,
                            doCosmics,
                            doParticleCreation,
                            doTrackSegmentsPixel,
                            doTrackSegmentsSCT,
                            doTrackSegmentsTRT,
                            doMonitoringGlobal,
                            doMonitoringPixel,
                            doMonitoringSCT,
                            doMonitoringTRT,
                            doMonitoringAlignment,
                            doPerfMon,
                            AODall,
                            useBeamConstraint,
                            kalmanUpdator,
                            magField,
                            propagatorType,
                            trackFitterType,
                            useNewGlobalChi2Tuning,
                            loadDynamicLayerCreator,
                            doHolesOnTrack,
                            useZvertexTool,
                            doSiSPSeededTrackFinder,
                            trtExtensionType,
                            redoTRT_LR,
                            doTrtSegments,
                            doTRTSeededTrackFinder,
                            loadTRTSeededSPFinder,
                            loadSimpleTRTSeededSPFinder,
                            doResolveBackTracks,
                            doTRTStandalone,
                            refitROT,
                            doSlimming,
                            doVertexFinding,
                            primaryVertexSetup,
                            doPrimaryVertex3DFinding,
                            doSharedHits,
                            doV0Finder,
                            useV0Fitter,
                            doSecVertexFinder,
                            doConversions,
                            doBremFitAlg,
                            doStatistics,
                            doStatNtuple,
                            doStandardPlots,
                            materialInteractions,
                            doTrkNtuple,
                            doPixelTrkNtuple,
                            doVtxNtuple,
                            doConvVtxNtuple,
                            doV0VtxNtuple,
                            removeTRTNoise,
                            cutSCTOccupancy,
                            useDCS,
                            truthMatchStrategy
                           ]
for j in _list_InDetJobProperties: 
    jobproperties.InDetJobProperties.add_JobProperty(j)
#keep the list alive for the trigger
#del _list_InDetJobProperties

##-----------------------------------------------------------------------------
## 5th step
## short-cut for lazy people
## carefull: do not select InDetJobProperties as a short name as well. 
## otherwise problems with pickle
## Note: you still have to import it:
## >>> from InDetRecExample.InDetJobProperties import InDetFlags
InDetFlags = jobproperties.InDetJobProperties
InDetFlags.setupDefaults()
