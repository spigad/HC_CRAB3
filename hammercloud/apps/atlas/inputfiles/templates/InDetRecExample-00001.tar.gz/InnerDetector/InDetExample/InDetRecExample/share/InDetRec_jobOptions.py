# +++++++++++++++++++ beginning of InDetRec_jobOptions.py
# jobOptions Fragment for ID software
# -----------------------------------
# edward.moyse@cern.ch
# markus.elsing@cern.ch
# -----------------------------------

# check (for robustness) if ID is on at all!
if not DetFlags.detdescr.ID_on():
  print "InDetRec_jobOptions.py: DetFlags ID is turned off. Not including anything!"
else:
  # +++++++++++++++++++++++
  # Control 
  # if needed switches are not defined, set them to sensible defaults
  # +++++++++++++++++++++++
  if not 'InDetFlags' in dir():
    #
    # --- setup flags with default values
    #
    print "InDetRec_jobOptions: InDetFlags not set before - I import them now"
    from InDetRecExample.InDetJobProperties import InDetFlags
  #
  InDetFlags.init()
  #
  if InDetFlags.Enabled():
    InDetFlags.printInfo()
    InDetFlags.print_JobProperties()    
    
    #
    # --- this jobO is entry point for top level jobOs: therefore check for presence of global and detflags
    #
    if not 'DetFlags' in dir():
      print "InDetRec_jobOptions: DetFlags not there - I import them now"
      from AthenaCommon.DetFlags import DetFlags
    if not 'globalflags' in dir():
      print "InDetRec_jobOptions: globalflags not there - I import them now"
      from AthenaCommon.GlobalFlags import globalflags
    
    # rec flags are needed (e.g. for commissioning steering ...)
    from RecExConfig.RecFlags import rec
    
    if not 'InDetCutValues' in dir():
      #
      # --- setup physics cuts with default values
      #
      print "InDetRec_jobOptions: InDetCutValues not set before - I import them now"
      include ( "InDetRecExample/ConfiguredInDetCutValues.py" )
      InDetCutValues = ConfiguredInDetCutValues()
    #
    # ----------- printout the setup
    #
    InDetCutValues.printInfo()
    
    if not 'InDetKeys' in dir():
      #
      # --- setup StoreGate keys (JobProperties!)
      #
      print "InDetRec_jobOptions: InDetKeys not set before - I import them now"
      from InDetRecExample.InDetKeys import InDetKeys
      #InDetKeys.lock_JobProperties() # do not lock anymore because some need adjustment lateron ...

    #
    # ----------- printout the setup
    #
    print "Printing InDetKeys. Be aware that some might be adjusted lateron!"
    InDetKeys.print_JobProperties()

    # ----------- 
    if globalflags.InputFormat() == 'bytestream':
      ServiceMgr.ByteStreamCnvSvc.IsSimulation = (globalflags.DataSource() == 'geant4')
              
    # ------------------------------------------------------------
    # 
    # ----------- Configuring the conditions access
    #
    # ------------------------------------------------------------
    
    include ("InDetRecExample/InDetRecConditionsAccess.py")
    
    # ------------------------------------------------------------
    # 
    # ----------- Loading the Tracking Tools and Services 
    #
    # ------------------------------------------------------------
    
    include ("InDetRecExample/InDetRecLoadTools.py")
    
    # ------------------------------------------------------------
    #
    # ----------- Data-Preparation stage
    #
    # ------------------------------------------------------------
    
    include ("InDetRecExample/InDetRecPreProcessingSilicon.py")
    include ("InDetRecExample/InDetRecPreProcessingTRT.py")


    # ------------------------------------------------------------
    #
    # --- the name of the input for the next algorithm
    #
    # ------------------------------------------------------------
    InputTrackCollection       = ""
    # next needs to be defined always otherwise there is a problem 
    # a bit further down when one runs with ReadInDet_jobOptions.py
    ForwardTrackCollection     = "" 
    if not 'TrackCollectionKeys' in dir():
      TrackCollectionKeys        = []
    if not 'TrackCollectionTruthKeys' in dir():
      TrackCollectionTruthKeys   = []


    #
    # In case of cosmics TRT needs to have the drifttime adjusted for the phase
    #
    if InDetFlags.doCosmics():
      #
      # Keep track of each track collection that is created for CTB cosmics tracking
      InDetCosmicTrackCollections=[]
      #
      # We need to run the silicon tracking already at this stage together with 
      # the TRT tracking on uncalibrated PRDs to be able to calculate the phase
      #
      # input collection for TRT Phase
      InDetCosmicSiTrackCollection=""

      if InDetFlags.doCTBTracking():
        include ("InDetRecExample/InDetRecCTBTrackingSiPattern.py")
        InDetCosmicSiTrackCollection = SiTrackCollectionCTB

      if InDetFlags.doNewTracking():
        include ("InDetRecExample/InDetRecNewTrackingSiPattern.py")
        
        if not InDetFlags.doCTBTracking():
          InDetCosmicSiTrackCollection = SiTrackCollection
        else:
          #
          # In case both NewTracking and CTB tracking is switched on, we run the
          # ambiguity solver to give back the best tracks as input to the phase
          # calculation. 
          #
          InputCosmicsAmbiSolver = [ SiTrackCollectionCTB , SiTrackCollection ]

          InDetCosmicSiTrackCollection="ResolvedSiCosmicTracks"
          from TrkAmbiguitySolver.TrkAmbiguitySolverConf import Trk__TrkAmbiguitySolver
          InDetAmbiguitySolverSiCosmics = Trk__TrkAmbiguitySolver(name               = 'InDetTrackAmbiSolverSiCosmics',
                                                                  TrackInput         = InputCosmicsAmbiSolver,
                                                                  TrackOutput        = InDetCosmicSiTrackCollection,
                                                                  AmbiguityProcessor = InDetAmbiguityProcessorCosmics)

          topSequence += InDetAmbiguitySolverSiCosmics
          if (InDetFlags.doPrintConfigurables()):
            print          InDetAmbiguitySolverSiCosmics

      include ("InDetRecExample/InDetRecTRTPhase.py")
      
    # ------------------------------------------------------------
    #
    # ----------- now we do legacy pattern if requested
    #
    # ------------------------------------------------------------
    #
    if InDetFlags.doxKalman() or InDetFlags.doiPatRec():
      include ("InDetRecExample/InDetRecXKalIPat.py")
    
    # ------------------------------------------------------------
    #
    # ----------- Run the subdetector pattern
    #
    # ------------------------------------------------------------
      
    if InDetFlags.doCTBTracking():
      if InDetFlags.doTrackSegmentsPixel():
        include ("InDetRecExample/InDetRecCTBTrackingPixel.py")
      if InDetFlags.doTrackSegmentsSCT():
        include ("InDetRecExample/InDetRecCTBTrackingSCT.py")
      if InDetFlags.doTrackSegmentsTRT():
        include ("InDetRecExample/InDetRecCTBTrackingTRT.py")
        InDetCosmicTrackCollections += [ InDetKeys.TRTTracks_CTB() ]
        
    if (not InDetFlags.doCosmics() or InDetFlags.doNewTracking()):
      if InDetFlags.doTrackSegmentsPixel():
        include ("InDetRecExample/InDetRecNewTrackingPixel.py")
      if InDetFlags.doTrackSegmentsSCT():
        include ("InDetRecExample/InDetRecNewTrackingSCT.py")
      if InDetFlags.doTrackSegmentsTRT():
        include ("InDetRecExample/InDetRecNewTrackingTRT.py") 

    # ------------------------------------------------------------
    #
    # ----------- now we do the RTF tracking
    #
    # ------------------------------------------------------------

    # Vector of track collections to be merged for further analysis
    InputCombinedInDetTracks = []
        
    if InDetFlags.doNewTracking():
      if not InDetFlags.doCosmics():
        include ("InDetRecExample/InDetRecNewTrackingSiPattern.py")
      include ("InDetRecExample/InDetRecNewTrackingTRTExtension.py")
      InputCombinedInDetTracks += [ ForwardTrackCollection ]

    if InDetFlags.doLowPt():
      include ("InDetRecExample/InDetRecLowPtTracking.py")
      InputCombinedInDetTracks += [ LowPtTrackCollection ]

    if InDetFlags.doBeamGas():
      include ("InDetRecExample/InDetRecBeamGasTracking.py")
      InputCombinedInDetTracks += [ BeamGasTrackCollection ]

    if InDetFlags.doBeamHalo():
      include ("InDetRecExample/InDetRecBeamHalo.py")
      InputCombinedInDetTracks += [ BeamHaloTrackCollection ]

    if InDetFlags.doTrtSegments():
      include ("InDetRecExample/InDetRecTRTSegmentFinding.py")

    if InDetFlags.doBackTracking():
      include ("InDetRecExample/InDetRecBackTracking.py")
      if not InDetFlags.doCosmics() or (InDetFlags.doCosmics() and not InDetFlags.doTRTStandalone()):
        InputCombinedInDetTracks += [ ResolvedSiExtendedTracks ]

    if InDetFlags.doSingleSpBackTracking():
      include ("InDetRecExample/InDetRecSingleSpTrackFinder.py")
      InputCombinedInDetTracks += [ OutputSingleSiExtendedTracks ]

    if InDetFlags.doTRTStandalone():
      include ("InDetRecExample/InDetRecTRTStandalone.py")
      if not InDetFlags.doCosmics()or (InDetFlags.doCosmics() and not InDetFlags.doBackTracking()):
        InputCombinedInDetTracks += [ OutputTRTStandaloneTracks ]

    # hack for cosmics!!!
    # ambiguity-solve backtracking and trt-standalone tracks
    if InDetFlags.doCosmics() and InDetFlags.doBackTracking() and InDetFlags.doTRTStandalone(): 
      OutputTRTTracks="TRTTracks"
      from TrkAmbiguitySolver.TrkAmbiguitySolverConf import Trk__TrkAmbiguitySolver
      InDetAmbiguitySolverTRT = Trk__TrkAmbiguitySolver(name               = 'InDetTRTAmbiSolver',
                                                            TrackInput         = [ ResolvedSiExtendedTracks , OutputTRTStandaloneTracks ],
                                                            TrackOutput        = OutputTRTTracks,
                                                            AmbiguityProcessor = InDetAmbiguityProcessorCosmics)
      topSequence += InDetAmbiguitySolverTRT
      if (InDetFlags.doPrintConfigurables()):
        print         InDetAmbiguitySolverTRT
        
      InputCombinedInDetTracks += [ OutputTRTTracks ]


    if InDetFlags.doCTBTracking(): 
      include ("InDetRecExample/InDetRecCTBTrackingTRTExtension.py")
      InDetCosmicTrackCollections += [ OutputCTBTrackCollection ]


    #
    # For CTB we ambisolve all Cosmics tracks into one cosmic track collection
    #
    if InDetFlags.doCTBTracking(): 
      from TrkAmbiguitySolver.TrkAmbiguitySolverConf import Trk__TrkAmbiguitySolver
      InDetAmbiguitySolverCosmics = Trk__TrkAmbiguitySolver(name               = 'InDetCosmicsAmbiSolver',
                                                            TrackInput         = InDetCosmicTrackCollections,
                                                            TrackOutput        = InDetKeys.UnslimmedTracks_CTB(),
                                                            AmbiguityProcessor = InDetAmbiguityProcessorCosmics)
      topSequence += InDetAmbiguitySolverCosmics
      if (InDetFlags.doPrintConfigurables()):
        print          InDetAmbiguitySolverCosmics

      if InDetFlags.doTruth():
        InputTrackCollectionTruth = "CombinedInDetTracks_CTBTruthCollection"
        InputDetailedTrackTruth   = "CombinedInDetTracks_CTBDetailedTruth"       
        #
        # set up the truth info for this container
        #
        include ("InDetRecExample/ConfiguredInDetTrackTruth.py")
        InDetCosmicTruth = ConfiguredInDetTrackTruth(InDetKeys.UnslimmedTracks_CTB(),
                                                       InputDetailedTrackTruth,
                                                       InputTrackCollectionTruth)
        #
        # add final output for statistics
        #
        TrackCollectionKeys      += [ InDetKeys.UnslimmedTracks_CTB() ]
        TrackCollectionTruthKeys += [ InputTrackCollectionTruth ]

    # always merge track collections. even if only one collection ran!
    # (this is because the track merger fills the prd association tool!)
    if (len(InputCombinedInDetTracks) > 0):
      from TrkTrackCollectionMerger.TrkTrackCollectionMergerConf import Trk__TrackCollectionMerger
      TrkTrackCollectionMerger = Trk__TrackCollectionMerger(name                    = "InDetTrackCollectionMerger",
                                                            TracksLocation          = InputCombinedInDetTracks,
                                                            OutputTracksLocation    = InDetKeys.UnslimmedTracks(),
                                                            AssoTool                = InDetPrdAssociationTool,
                                                            SummaryTool             = InDetTrackSummaryToolSharedHits)
        
      # MaxNumSharedHits        = InDetCutValues.maxShared()+1)
      topSequence += TrkTrackCollectionMerger
      if (InDetFlags.doPrintConfigurables()):
        print TrkTrackCollectionMerger
        
      #
      # ------------ Track truth.
      #
      if InDetFlags.doTruth():
        #
        # set up the truth info for this container
        #
        include ("InDetRecExample/ConfiguredInDetTrackTruth.py")
        InDetTracksTruth = ConfiguredInDetTrackTruth(InDetKeys.UnslimmedTracks(),
                                                     InDetKeys.UnslimmedDetailedTracksTruth(),
                                                     InDetKeys.UnslimmedTracksTruth())
        #
        # add final output for statistics
        #
        TrackCollectionKeys      += [ InDetKeys.UnslimmedTracks() ]
        TrackCollectionTruthKeys += [ InDetKeys.UnslimmedTracksTruth() ]
 
    # ------------------------------------------------------------
    #
    # ----------- now we copy over the output track collection
    #             (this needs to be done as soon as one tracking ran!)
    # ------------------------------------------------------------
    
    if ( InDetFlags.doPattern()  or InDetFlags.doTRTStandalone() or InDetFlags.doSingleSpBackTracking() ) or InDetFlags.doRefit() or InDetFlags.doCosmics():
      #
      # Pick one of the result collections and turn it into tracks
      #
      if (InDetFlags.doNewTracking()      or InDetFlags.doLowPt()                or InDetFlags.doBackTracking() \
          or InDetFlags.doTRTStandalone() or InDetFlags.doSingleSpBackTracking() or InDetFlags.doBeamGas()    \
          or InDetFlags.doBeamHalo() ) and not InDetFlags.doCTBTracking():
          InputTrackCollection = InDetKeys.UnslimmedTracks()
      elif InDetFlags.doCTBTracking() or  InDetFlags.doCosmics():
        InputTrackCollection = InDetKeys.UnslimmedTracks_CTB()
      elif InDetFlags.doiPatRec():
          InputTrackCollection = "ConvertedIPatTracks"
      elif InDetFlags.doxKalman():
          InputTrackCollection = "ConvertedXKalmanTracks"
      elif InDetFlags.doRefit() :
          InputTrackCollection = InDetKeys.Tracks()
      else:
          print "InDetRec_jobOptions.py: No correct input collection set for the TrackSlimming! It will use a wrong default! Check the jobOs!!"

      #
      # --- we either refit or copy the input
      #
      if InDetFlags.doRefit():
          from TrkRefitAlg.TrkRefitAlgConf import Trk__ReFitTrack
          InDetReFitTrack = Trk__ReFitTrack (name           = "InDetRefitTrack",
                                            FitterTool     = InDetTrackFitter,
                                            FitterToolTRT  = InDetTrackFitterTRT,
                                            SummaryTool    = InDetTrackSummaryTool,                   
                                            TrackName      = InputTrackCollection,
                                            NewTrackName   = InDetKeys.RefittedTracks(),
                                            fitRIO_OnTrack = InDetFlags.refitROT())

          if InDetFlags.materialInteractions():
            InDetReFitTrack.matEffects = 3 # default in code is 4!!
          else :
            InDetReFitTrack.matEffects = 0
    
          topSequence += InDetReFitTrack
          if (InDetFlags.doPrintConfigurables()):
            print InDetReFitTrack
          # set input track name
          InputTrackCollection = InDetKeys.RefittedTracks()
    
      #
      # set output track name
      #
      OutputTrackCollection = InDetKeys.Tracks()
      #
      # --- slimm the tracks down before writing them
      #

      if InDetFlags.doSlimming() and (InDetFlags.doPattern() or InDetFlags.doTRTStandalone() or InDetFlags.doSingleSpBackTracking()):
          from TrkTrackSlimmingTool.TrkTrackSlimmingToolConf import Trk__TrackSlimmingTool as ConfigurableTrackSlimmingTool
          InDetTrkSlimmingTool = ConfigurableTrackSlimmingTool(name           = "InDetTrackSlimmingTool",
                                                              KeepParameters = True,
                                                              KeepOutliers   = True )
          ToolSvc += InDetTrkSlimmingTool
          if (InDetFlags.doPrintConfigurables()):
            print      InDetTrkSlimmingTool
          
          from TrkTrackSlimmer.TrkTrackSlimmerConf import Trk__TrackSlimmer as ConfigurableTrackSlimmer
          InDetTrkSlimmer = ConfigurableTrackSlimmer(name                 = "InDetTrackSlimmer",
                                                    TrackLocation        = [ InputTrackCollection ],
                                                    SlimmedTrackLocation = [ OutputTrackCollection ],
                                                    TrackSlimmingTool    = InDetTrkSlimmingTool)
          #InDetTrkSlimmer.OutputLevel=VERBOSE
          topSequence += InDetTrkSlimmer
          if (InDetFlags.doPrintConfigurables()):
            print          InDetTrkSlimmer
          # --- for output
          InDetKeys.AliasToTracks = 'none'
                                                                                  
      elif InDetFlags.doPattern() or InDetFlags.doTRTStandalone() or InDetFlags.doSingleSpBackTracking() or InDetFlags.doCosmics():
          #
          # configure Algorithm to create output alias
          #
          from TrkCollectionAliasAlg.TrkCollectionAliasAlgConf import Trk__TrkCollectionAliasAlg
          InDetCopyAlg = Trk__TrkCollectionAliasAlg (name             = "InDetCopyAlg",
                                                    CollectionName   = InputTrackCollection,
                                                    AliasName        = InDetKeys.Tracks()) 
          topSequence += InDetCopyAlg
          if (InDetFlags.doPrintConfigurables()):
            print          InDetCopyAlg
          # --- for output
          InDetKeys.AliasToTracks = InputTrackCollection
      #
      # Input of the next algorithm
      #
      if InDetFlags.doPattern()  or InDetFlags.doTRTStandalone() or InDetFlags.doSingleSpBackTracking() or InDetFlags.doCosmics():
         InputTrackCollection = OutputTrackCollection
      else :
         InputTrackCollection = InDetKeys.RefittedTracks()         
      #
      # now do truth for the output
      #
      if InDetFlags.doTruth():
          #
          # this is the name of the truth
          #
          if InDetFlags.doPattern()  or InDetFlags.doTRTStandalone() or InDetFlags.doSingleSpBackTracking() or InDetFlags.doCosmics():
            InputDetailedTrackTruth   = InDetKeys.DetailedTracksTruth()
            InputTrackCollectionTruth = InDetKeys.TracksTruth()
          else :
            InputDetailedTrackTruth   = InDetKeys.RefittedDetailedTracksTruth()
            InputTrackCollectionTruth = InDetKeys.RefittedTracksTruth()
          #
          # set up the truth info for this container
          #
          include ("InDetRecExample/ConfiguredInDetTrackTruth.py")
          InDetTracksTruth = ConfiguredInDetTrackTruth(InputTrackCollection,
                                                      InputDetailedTrackTruth,
                                                      InputTrackCollectionTruth)
          #
          # add to keys lists for statistics
          #
          TrackCollectionKeys      += [ InputTrackCollection ]
          TrackCollectionTruthKeys += [ InputTrackCollectionTruth ]
      
    
    # ------------------------------------------------------------
    #
    # ----------- now we do post-processing
    #
    # ------------------------------------------------------------
    #
    #
    # id rec stat processing and trk+pixel ntuple creation need this tool if truth is on
    if InDetFlags.doTruth() and (InDetFlags.doStatistics() or InDetFlags.doStandardPlots() or InDetFlags.doTrkNtuple() or InDetFlags.doPixelTrkNtuple()):
      #
      # --- load truth to track tool
      #
      from TrkTruthToTrack.TrkTruthToTrackConf import Trk__TruthToTrack
      InDetTruthToTrack  = Trk__TruthToTrack(name         = "InDetTruthToTrack",
                                            Extrapolator = InDetExtrapolator)
      ToolSvc += InDetTruthToTrack
      if (InDetFlags.doPrintConfigurables()):
        print      InDetTruthToTrack
    
    include("InDetRecExample/InDetRecPostProcessing.py")
      
    # ntuple creation for validation purposes    
    if InDetFlags.doTrkNtuple() or InDetFlags.doPixelTrkNtuple() or InDetFlags.doVtxNtuple() or InDetFlags.doConvVtxNtuple() or InDetFlags.doV0VtxNtuple() or InDetFlags.doStandardPlots():
      include("InDetRecExample/InDetRecNtupleCreation.py")
    
    # +++++++++++++++++++ end of InDetRec_jobOptions.py
  # END if InDetFlags.Enabled()    
