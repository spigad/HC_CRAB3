if InDetFlags.doTrackSegmentsPixel() and DetFlags.haveRIO.pixel_on():
    MinNumberOfPointsOnTrack=4

    if InDetFlags.materialInteractions():
        matEffects=2
    else:
        matEffects=0

    OutputTrackCollection = InDetKeys.PixelTracks_CTB()
    
    from SiCTBTracking.SiCTBTrackingConf import InDet__SiCTBTracking
    
    Pixel_CTBTracking=InDet__SiCTBTracking(name = "Pixel_CTBTracking",
                                           TrackFitter = InDetTrackFitter,
                                           ExtrapolatorName = InDetExtrapolator,
                                           Chi2cut_x = 10,
                                           Chi2cut_z = 50,
                                           MinNumberOfPointsOnTrack = MinNumberOfPointsOnTrack,
                                           MaxNumberOfPoints = 40,
                                           tracksname = OutputTrackCollection,
                                           tracksupname = OutputTrackCollection+"Up",
                                           trackslowname = OutputTrackCollection+"Low",
                                           processPixels = True,
                                           processSCT = False,
                                           matEffects=matEffects,
                                           Magnet = InDetFlags.solenoidOn())
    topSequence += Pixel_CTBTracking
    
    if (InDetFlags.doPrintConfigurables()):
        print          Pixel_CTBTracking
