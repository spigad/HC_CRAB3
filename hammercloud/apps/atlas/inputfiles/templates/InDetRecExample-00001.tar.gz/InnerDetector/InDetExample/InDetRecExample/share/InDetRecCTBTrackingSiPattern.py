if DetFlags.haveRIO.SCT_on() or DetFlags.haveRIO.pixel_on():

    if InDetFlags.materialInteractions():
        matEffects=2
    else:
        matEffects=0

    if InDetFlags.solenoidOn():
        MinNumberOfPointsOnTrack=4
    else:
        MinNumberOfPointsOnTrack=4


    OutputTrackCollection = "Si_Cosmic_Tracks"

    OutputCTBTrackCollection=OutputTrackCollection
    from SiCTBTracking.SiCTBTrackingConf import InDet__SiCTBTracking
    SiCTBTracking=InDet__SiCTBTracking(name="SiCTBTracking",
                                       TrackFitter=InDetTrackFitter,
                                       ExtrapolatorName=InDetExtrapolator,
                                       Chi2cut_x=10,
                                       Chi2cut_z=50,
                                       MinNumberOfPointsOnTrack=MinNumberOfPointsOnTrack,
                                       MaxNumberOfPoints=50,
                                       tracksname = OutputTrackCollection,
                                       tracksupname = OutputTrackCollection+"Up",
                                       trackslowname = OutputTrackCollection+"Low",
                                       processPixels = DetFlags.haveRIO.pixel_on(),
                                       processSCT = DetFlags.haveRIO.SCT_on(),
                                       Magnet = InDetFlags.solenoidOn(),
                                       matEffects = matEffects)
    
    topSequence += SiCTBTracking
    if (InDetFlags.doPrintConfigurables()):
        print          SiCTBTracking


    SiTrackCollectionCTB = OutputTrackCollection
