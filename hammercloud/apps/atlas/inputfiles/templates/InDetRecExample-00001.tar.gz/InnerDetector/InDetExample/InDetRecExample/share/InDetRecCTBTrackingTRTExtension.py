if DetFlags.haveRIO.TRT_on() and InDetFlags.doCTBTracking():

    if InDetFlags.materialInteractions():
        matEffects=2
    else:
        matEffects=0

    InputTrackCollection = SiTrackCollectionCTB
    OutputTrackCollection = "InDetCosmic_Tracks"

    from InDetCTBTracking.InDetCTBTrackingConf import InDet__InDetExtensionProcessor_CTB
    InDetExtensionProcessor_CTB = InDet__InDetExtensionProcessor_CTB(name = "InDetExtensionProcessor_CTB",
                                                                     TrackFitter = InDetTrackFitter,
                                                                     ExtensionTool = InDetTRTExtensionToolCosmics,
                                                                     AssociationTool = InDetPrdAssociationTool_CTB,
                                                                     InputTracksName = InputTrackCollection,
                                                                     OutputTracks = OutputTrackCollection,
                                                                     OutputTracksLow=OutputTrackCollection+"Low",
                                                                     OutputTracksUp=OutputTrackCollection+"Up",
                                                                     Chi2cut = 5000,
                                                                     matEffects = matEffects)
    topSequence+= InDetExtensionProcessor_CTB
    
    if (InDetFlags.doPrintConfigurables()):
        print InDetExtensionProcessor_CTB


    OutputCTBTrackCollection = OutputTrackCollection
