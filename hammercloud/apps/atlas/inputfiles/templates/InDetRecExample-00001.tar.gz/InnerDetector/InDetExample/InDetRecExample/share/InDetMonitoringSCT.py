from AthenaMonitoring.DQMonFlags import DQMonFlags

########################################################################
# Conditions access
# These lines were previously in SCT_Monitoring_ConditionsAccess.py
########################################################################
from IOVDbSvc.CondDB import conddb
if not conddb.folderRequested('/SCT/DAQ/Configuration/Chip'):
  conddb.addFolder("SCT","/SCT/DAQ/Configuration/Chip")
if not conddb.folderRequested('/SCT/DAQ/Configuration/Module'):
  conddb.addFolder("SCT","/SCT/DAQ/Configuration/Module")

# Load conditions configuration service
from SCT_ConditionsServices.SCT_ConditionsServicesConf import SCT_ConfigurationConditionsSvc
SCT_MonConfigurationConditionsSvc = SCT_ConfigurationConditionsSvc(name = "SCT_MonConfigurationConditionsSvc")
ServiceMgr += SCT_MonConfigurationConditionsSvc
if (InDetFlags.doPrintConfigurables()):
   print      SCT_MonConfigurationConditionsSvc

# Load condtions service
from SCT_ConditionsServices.SCT_ConditionsServicesConf import SCT_ConditionsSummarySvc
SCT_MonConditionsSummarySvc = SCT_ConditionsSummarySvc(name = "SCT_MonConditionsSummarySvc",
                                                       ConditionsServices=["SCT_MonConfigurationConditionsSvc"])
ServiceMgr += SCT_MonConditionsSummarySvc
if (InDetFlags.doPrintConfigurables()):
   print      SCT_MonConditionsSummarySvc


from SCT_Monitoring.SCT_MonitoringConf import SCTInitialiseTool
InDetSCTInitTool = SCTInitialiseTool ( name = "InDetSCTInitialiseTool" )
ToolSvc += InDetSCTInitTool
if (InDetFlags.doPrintConfigurables()):
  print      InDetSCTInitTool

from SCT_Monitoring.SCT_MonitoringConf import SCTHitsNoiseMonTool
InDetSCTHitsTool = SCTHitsNoiseMonTool ( name                         = "InDetSCTHitsNoiseMonTool",
                                         OutputLevel                  = 4,
                                         doHitmapHistos               = False,
                                         CheckRate                    = 1000,
                                         doPositiveEndcap             = True,
                                         doNegativeEndcap             = True)

if InDetFlags.doCTBTracking():
    InDetSCTHitsTool.tracksName = InDetKeys.SCTTracks_CTB()

ToolSvc += InDetSCTHitsTool
if (InDetFlags.doPrintConfigurables()):
   print      InDetSCTHitsTool

from SCT_Monitoring.SCT_MonitoringConf import SCTTracksMonTool
InDetSCTTracksMonTool = SCTTracksMonTool ( name             = "InDetSCTTracksMonTool",
                                           OutputLevel      = 4,
                                           CheckRate        = 1000,
                                           doPositiveEndcap = True,
                                           doNegativeEndcap = True,
                                           doUnbiasedCalc   = True)
if InDetFlags.doCTBTracking():
  InDetSCTTracksMonTool.tracksName = InDetKeys.SCTTracks_CTB()
else:
  InDetSCTTracksMonTool.tracksName = InDetKeys.SCTTracks()
                                           
ToolSvc += InDetSCTTracksMonTool
if (InDetFlags.doPrintConfigurables()):
   print      InDetSCTTracksMonTool


from SCT_Monitoring.SCT_MonitoringConf import SCTErrMonTool
InDetSCTErrMonTool = SCTErrMonTool ( name             = "InDetSCTErrMonTool",
                                     OutputLevel      = 4,
                                     histoPathBase    = "/stat",
                                     CheckRate        = 1000,
                                     doPositiveEndcap = True,
                                     doNegativeEndcap = True)
ToolSvc += InDetSCTErrMonTool
if (InDetFlags.doPrintConfigurables()):
   print      InDetSCTErrMonTool


from InDetTrackHoleSearch.InDetTrackHoleSearchConf import InDet__InDetTrackHoleSearchTool
InDetSCT_MonHoleSearch = InDet__InDetTrackHoleSearchTool(name                = "InDetSCT_MonHoleSearch",
                                                         Extrapolator        = InDetExtrapolator,
                                                         ExtendedListOfHoles = True,
                                                         Cosmics             = InDetFlags.doCosmics(),
                                                         SctSummarySvc       = InDetSCT_ConditionsSummarySvc)
   
ToolSvc += InDetSCT_MonHoleSearch
if (InDetFlags.doPrintConfigurables()):
   print      InDetSCT_MonHoleSearch
               
from SCT_Monitoring.SCT_MonitoringConf import SCTHitEffMonTool
InDetSCTHitEffMonTool = SCTHitEffMonTool(name = "InDetSCTHitEffMonTool",
                                         DetectorMode            = 3,
                                         OutputLevel             = 4,
                                         IsCosmic                = InDetFlags.doCosmics(),
                                         UseMasks                = False,
                                         LookAtDatabase          = False,
                                         FlaggedConditionService = ServiceMgr.InDetSCT_FlaggedConditionSvc,
                                         ChronoTime              = False,
                                         HoleSearch              = InDetSCT_MonHoleSearch,
                                         IsSim                   = globalflags.DataSource != "data")
if InDetFlags.doCTBTracking():
  InDetSCTHitEffMonTool.TrackName = InDetKeys.SCTTracks_CTB()
else:
  InDetSCTHitEffMonTool.TrackName = InDetKeys.SCTTracks()
                                         
ToolSvc += InDetSCTHitEffMonTool
if (InDetFlags.doPrintConfigurables()):
   print      InDetSCTHitEffMonTool

#from SCT_Monitoring.SCT_MonitoringConf import SCTTimeDependentMonTool
#SCTTimeDependentMonTool = SCTTimeDependentMonTool("SCTTimeDependentMonTool")
#ToolSvc+=SCTTimeDependentMonTool
#SCTMonMan.AthenaMonTools += [SCTTimeDependentMonTool]

from AthenaMonitoring.AthenaMonitoringConf import AthenaMonManager
topSequence += AthenaMonManager("InDetSCTMonManager")
SCTMonMan = topSequence.InDetSCTMonManager
SCTMonMan.FileKey = DQMonFlags.monManFileKey()
SCTMonMan.ManualDataTypeSetup = DQMonFlags.monManManualDataTypeSetup()
SCTMonMan.ManualRunLBSetup = DQMonFlags.monManManualRunLBSetup()
SCTMonMan.DataType     = DQMonFlags.monManDataType()
SCTMonMan.Environment  = DQMonFlags.monManEnvironment()
SCTMonMan.Run          = DQMonFlags.monManRun()
SCTMonMan.LumiBlock    = DQMonFlags.monManLumiBlock()
SCTMonMan.AthenaMonTools += [ InDetSCTInitTool, InDetSCTHitsTool, InDetSCTTracksMonTool, InDetSCTErrMonTool, InDetSCTHitEffMonTool ]
if (InDetFlags.doPrintConfigurables()):
   print      SCTMonMan
