# ------------------------------------------------------------
#
# ----------- now we do the RTF tracking
#
# ------------------------------------------------------------
# minPt cut for the sct stand alone tracking (it differs from ID tracking)
if not InDetFlags.doCosmics():
  SCTStandAloneMinPtCut = 1. * GeV
else:
  SCTStandAloneMinPtCut = InDetCutValues.minPTCosmics()
#
#
# ----------- SiSPSeededTrackFinder
#
#
# Space points seeds maker
#
if not InDetFlags.doCosmics():
  from SiSpacePointsSeedTool_xk.SiSpacePointsSeedTool_xkConf import InDet__SiSpacePointsSeedMaker_ATLxk
  InDetSiSpacePointsSeedMakerSCT = InDet__SiSpacePointsSeedMaker_ATLxk(name                   = 'InDetSpSeedsMakerSCT',
                                                                       MagneticTool           = InDetPatternMagField,
                                                                       pTmin                  = SCTStandAloneMinPtCut, #InDetCutValues.minPT(),
                                                                       maxdImpact             = InDetCutValues.maxPrimaryImpact(),
                                                                       maxZ                   = InDetCutValues.maxZImpact(),
                                                                       minZ                   = -InDetCutValues.maxZImpact(),
                                                                       SpacePointsPixelName   = "",
                                                                       usePixel               = False,
                                                                       SpacePointsSCTName     = InDetKeys.SCT_SpacePoints(),
                                                                       SpacePointsOverlapName = InDetKeys.OverlapSpacePoints())
  ToolSvc += InDetSiSpacePointsSeedMakerSCT
  if (InDetFlags.doPrintConfigurables()):
    print      InDetSiSpacePointsSeedMakerSCT

else:
  from SiSpacePointsSeedTool_xk.SiSpacePointsSeedTool_xkConf import InDet__SiSpacePointsSeedMaker_Cosmic
  InDetSiSpacePointsSeedMakerCosmicsSCT = InDet__SiSpacePointsSeedMaker_Cosmic(name                   = 'InDetSpSeedsMakerCosmicsSCT',
                                                                                 MagneticTool           = InDetPatternMagField,
                                                                                 pTmin                  = InDetCutValues.minPTCosmics(),
                                                                                 maxdImpact             = InDetCutValues.maxPrimaryImpactCosmics(),
                                                                                 maxZ                   = InDetCutValues.maxZImpactCosmics(),
                                                                                 minZ                   = -InDetCutValues.maxZImpactCosmics(),
                                                                                 SpacePointsPixelName   = "",
                                                                                 SpacePointsSCTName     = InDetKeys.SCT_SpacePoints(),
                                                                                 usePixel               = False, 
                                                                                 useOverlapSpCollection = False,
                                                                                 SpacePointsOverlapName = "",
                                                                                 UseAssociationTool     = False,
                                                                                 AssociationTool        = InDetPrdAssociationTool)
  ToolSvc += InDetSiSpacePointsSeedMakerCosmicsSCT
  if (InDetFlags.doPrintConfigurables()):
    print      InDetSiSpacePointsSeedMakerCosmicsSCT
  
#
# Z-coordinates primary vertices finder
#
if InDetFlags.useZvertexTool():
  from SiZvertexTool_xk.SiZvertexTool_xkConf import InDet__SiZvertexMaker_xk
  InDetZvertexMakerSCT = InDet__SiZvertexMaker_xk(name          = 'InDetZvertexMakerSCT',
                                                  SeedMakerTool = InDetSiSpacePointsSeedMakerSCT,
                                                  Zmax          = InDetCutValues.maxZImpact(),
                                                  Zmin          = -InDetCutValues.maxZImpact(),
                                                  minRatio      = 0.17) # not default
  ToolSvc += InDetZvertexMakerSCT
  if (InDetFlags.doPrintConfigurables()):
    print      InDetZvertexMakerSCT
else:
  InDetZvertexMakerSCT = None
  
#
# SCT and SCT detector elements road builder
#
from SiDetElementsRoadTool_xk.SiDetElementsRoadTool_xkConf import InDet__SiDetElementsRoadMaker_xk
InDetSiDetElementsRoadMakerSCT = InDet__SiDetElementsRoadMaker_xk(name               = 'InDetSiRoadMakerSCT',
                                                              PropagatorTool     = InDetPatternPropagator,
                                                              MagneticTool       = InDetPatternMagField,
                                                              usePixel           = False, 
                                                              PixManagerLocation = InDetKeys.PixelManager(),
                                                              SCTManagerLocation = InDetKeys.SCT_Manager())

if InDetFlags.doCosmics():
  InDetSiDetElementsRoadMakerSCT.RoadWidth = 50
  
ToolSvc += InDetSiDetElementsRoadMakerSCT
if (InDetFlags.doPrintConfigurables()):
  print      InDetSiDetElementsRoadMakerSCT

#
# Local track finding using space point seed
#
from SiTrackMakerTool_xk.SiTrackMakerTool_xkConf import InDet__SiTrackMaker_xk
InDetSiTrackMakerSCT = InDet__SiTrackMaker_xk(name                     = 'InDetSiTrackMakerSCT',
                                          MagneticTool             = InDetPatternMagField,
                                          RoadTool                 = InDetSiDetElementsRoadMakerSCT,
                                          CombinatorialTrackFinder = InDetSiComTrackFinder,
                                          pTmin                    = SCTStandAloneMinPtCut, #InDetCutValues.minPT(),
                                          nClustersMin             = 3, # was 7,
                                          nWeightedClustersMin     = 6, # and this is new
                                          nHolesMax                = 1,
                                          nHolesGapMax             = 1, 
                                          SeedsFilterLevel         = 2,
                                          GoodSeedClusterCount     = 8)

if InDetFlags.doCosmics():
  InDetSiTrackMakerSCT.CosmicTrack = True
  InDetSiTrackMakerSCT.GoodSeedClusterCount = 3
  InDetSiTrackMakerSCT.nHolesMax = InDetCutValues.maxHolesCosmics()

ToolSvc += InDetSiTrackMakerSCT
if (InDetFlags.doPrintConfigurables()):
  print      InDetSiTrackMakerSCT

#
# set output track collection name
OutputTrackCollection = "SiSPSeededSCTTracks"

#
# Setup Track finder using space points seeds
#
from SiSPSeededTrackFinder.SiSPSeededTrackFinderConf import InDet__SiSPSeededTrackFinder
InDetSiSPSeededTrackFinderSCT = InDet__SiSPSeededTrackFinder(name           = 'InDetSiSpTrackFinderSCT',
                                                          ZvertexTool    = InDetZvertexMakerSCT, 
                                                          TrackTool      = InDetSiTrackMakerSCT,
                                                          TracksLocation = OutputTrackCollection,
                                                          useZvertexTool = InDetFlags.useZvertexTool())
if not InDetFlags.doCosmics():    
  InDetSiSPSeededTrackFinderSCT.SeedsTool      = InDetSiSpacePointsSeedMakerSCT
else:
  InDetSiSPSeededTrackFinderSCT.SeedsTool      = InDetSiSpacePointsSeedMakerCosmicsSCT

topSequence += InDetSiSPSeededTrackFinderSCT
if (InDetFlags.doPrintConfigurables()):
  print          InDetSiSPSeededTrackFinderSCT

#
# set input collection for next algorithm
#
InputTrackCollection = OutputTrackCollection

if InDetFlags.doTruth():
  #
  # set collection name for truth
  #
  InputTrackCollectionTruth = "SiSPSeededSCTTracksTruthCollection"
  InputDetailedTrackTruth   = "SiSPSeededSCTTracksDetailedTruth"
  #
  # set up the truth info for this container
  #
  include ("InDetRecExample/ConfiguredInDetTrackTruth.py")
  InDetTracksTruth = ConfiguredInDetTrackTruth(InputTrackCollection,
                                                InputDetailedTrackTruth,
                                                InputTrackCollectionTruth)
  #
  # add final output for statistics
  #
  TrackCollectionKeys      += [ InputTrackCollection ]
  TrackCollectionTruthKeys += [ InputTrackCollectionTruth ]
#
# ---------- Ambiguity solving
#
if not InDetFlags.doAmbiSolving():
   InDetKeys.SCTTracks = OutputTrackCollection
else:
   #
   # load InnerDetector TrackSelectionTool
   #
   from InDetAmbiTrackSelectionTool.InDetAmbiTrackSelectionToolConf import InDet__InDetAmbiTrackSelectionTool
   InDetAmbiTrackSelectionToolSCT = InDet__InDetAmbiTrackSelectionTool(name            = 'InDetAmbiTrackSelectionToolSCT',
                                                                    AssociationTool = InDetPrdAssociationTool,
                                                                    minHits         = 5,
                                                                    minNotShared    = 7,
                                                                    maxShared       = 0,
                                                                    minTRTHits      = 0 ) # used for Si only tracking !!!

   if InDetFlags.doCosmics():
     InDetAmbiTrackSelectionToolSCT.Cosmics         = True
     InDetAmbiTrackSelectionToolSCT.maxShared = 3

   ToolSvc += InDetAmbiTrackSelectionToolSCT
   if (InDetFlags.doPrintConfigurables()):
     print      InDetAmbiTrackSelectionToolSCT
   #
   # set up Scoring Tool
   #
   if not InDetFlags.doCosmics():
     from InDetTrackScoringTools.InDetTrackScoringToolsConf import InDet__InDetAmbiScoringTool
     InDetAmbiScoringToolSCT = InDet__InDetAmbiScoringTool(name           = 'InDetAmbiScoringToolSCT',
                                                           Extrapolator   = InDetExtrapolator,
                                                           SummaryTool    = InDetTrackSummaryTool,
                                                           useAmbigFcn    = True,
                                                           useTRT_AmbigFcn= False,
                                                           minPt          = SCTStandAloneMinPtCut, #InDetCutValues.minPT(),
                                                           maxRPhiImp     = InDetCutValues.maxPrimaryImpact(),
                                                           maxZImp        = InDetCutValues.maxZImpact(),
                                                           maxEta         = InDetCutValues.maxEta(),
                                                           minSiClusters  = 7,
                                                           maxSiHoles     = 1,
                                                           maxDoubleHoles = 1,
                                                           minTRTonTrk    = 0,    # no TRT here
                                                           useSigmaChi2   = False)
                                                           #useSigmaChi2   = True) # use it for Si only


     #InDetAmbiScoringTool.OutputLevel = VERBOSE
     ToolSvc += InDetAmbiScoringToolSCT
     if (InDetFlags.doPrintConfigurables()):
       print      InDetAmbiScoringToolSCT      
     
   #
   # load Ambiguity Processor
   #
   from TrkAmbiguityProcessor.TrkAmbiguityProcessorConf import Trk__SimpleAmbiguityProcessorTool
   InDetAmbiguityProcessorSCT = Trk__SimpleAmbiguityProcessorTool(name          = 'InDetAmbiguityProcessorSCT',
                                                               Fitter        = InDetTrackFitter,
                                                               SelectionTool = InDetAmbiTrackSelectionToolSCT,
                                                               RefitPrds     = not InDetFlags.refitROT())
   if InDetFlags.materialInteractions():
      InDetAmbiguityProcessorSCT.MatEffects = 3
   else:
      InDetAmbiguityProcessorSCT.MatEffects = 0

   if not InDetFlags.doCosmics():
     InDetAmbiguityProcessorSCT.ScoringTool   = InDetAmbiScoringToolSCT
   else:
     InDetAmbiguityProcessorSCT.ScoringTool = InDetScoringToolCosmics_SiPattern

   ToolSvc += InDetAmbiguityProcessorSCT
   if (InDetFlags.doPrintConfigurables()):
     print      InDetAmbiguityProcessorSCT
   #
   # configure Ambiguity solver
   #
   from TrkAmbiguitySolver.TrkAmbiguitySolverConf import Trk__TrkAmbiguitySolver
   InDetAmbiguitySolverSCT = Trk__TrkAmbiguitySolver(name               = 'InDetAmbiguitySolverSCT',
                                                  TrackInput         = [ InputTrackCollection ],
                                                  TrackOutput        = InDetKeys.SCTTracks(),
                                                  AmbiguityProcessor = InDetAmbiguityProcessorSCT)
   topSequence += InDetAmbiguitySolverSCT
   if (InDetFlags.doPrintConfigurables()):
     print          InDetAmbiguitySolverSCT

   if InDetFlags.doTruth():
      #
      # set collection name for truth
      #
      InputTrackCollectionTruth = "ResolvedSCTTracksTruthCollection"
      InputDetailedTrackTruth   = "ResolvedSCTTracksDetailedTruth"      
      #
      # set up the truth info for this container
      #
      include ("InDetRecExample/ConfiguredInDetTrackTruth.py")
      InDetTracksTruthSCT = ConfiguredInDetTrackTruth(InDetKeys.SCTTracks(),
                                                      InputDetailedTrackTruth,
                                                      InputTrackCollectionTruth)
      #
      # add final output for statistics
      #
      TrackCollectionKeys      += [ InDetKeys.SCTTracks() ]
      TrackCollectionTruthKeys += [ InputTrackCollectionTruth ]

   
