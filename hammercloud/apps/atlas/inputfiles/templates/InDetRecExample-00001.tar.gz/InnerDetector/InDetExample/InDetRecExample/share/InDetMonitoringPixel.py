# configure the pixel main monitoring tool
from PixelMonitoring.PixelMonitoringConf import PixelMainMon
PixelMainsMon=PixelMainMon()

##Flags for data container types
PixelMainsMon.doRDO        = True  #RDO plots (tot, timing, hitmaps)
PixelMainsMon.doCluster    = True  #Cluster properties
PixelMainsMon.doSpacePoint = True  #Space points
PixelMainsMon.doStatus     = True  #Module status maps (good/active vs bad/disabled plots)
PixelMainsMon.doErrors     = True  #Module/ROD error flags
PixelMainsMon.doTrack      = False #Track based plots.  Will not work in most cases

##Flags for various histogram classes
PixelMainsMon.doOffline             = True   #Plots for Tier0 running.  Should be on be default since tier0 must run on default flags
PixelMainsMon.doOnline              = False  #Default plots for AthenaPT in the segment
PixelMainsMon.doOnlineLowOccupancy  = False  #Make online plots but with lower occupancy variants (for cosmics etc)
PixelMainsMon.DoModules             = False  #Detailed plots at module level granularity.  Needed for online DQMF.
PixelMainsMon.doDetails             = False  #Turns on detailed monitoring for 4 modules (Good for online interactive monitoring)
PixelMainsMon.doCommissioning       = False  #Full detector detailed plots (can use a lot of memory, good for offline private analysis)
PixelMainsMon.doRodSim              = False  #Plots for the pixel rod simulator

##Names of storegate containers
from InDetRecExample.InDetKeys import InDetKeys
PixelMainsMon.RDOName        = InDetKeys.PixelRDOs()
PixelMainsMon.RODErrorName   = "pixel_error_summary"
PixelMainsMon.SpacePointName = InDetKeys.PixelSpacePoints()
PixelMainsMon.ClusterName    = InDetKeys.PixelClusters()

if InDetFlags.doCTBTracking():
  PixelMainsMon.TrackName      = InDetKeys.PixelTracks_CTB()
else:
  PixelMainsMon.TrackName      = InDetKeys.PixelTracks()

##Other parameters
#PixelMainsMon.OfflineDoPixelOccupancy = False  #pixel occupancy plots for offline analysis.  Leave off except for private analysis

PixelMainsMon.DetailsMod1 = "D1A_B03_S2_M3"  #Give the 4 modules which you want to do detailed monitoring of
PixelMainsMon.DetailsMod2 = "L0_B05_S2_M1A"  #Use the normal name like D1A_B03_S2_M4 or
PixelMainsMon.DetailsMod3 = "L1_B10_S1_M2C"  #L1_B10_S2_M2C and the code should be able to parse
PixelMainsMon.DetailsMod4 = "D2C_B01_S1_M6"  #this for you

PixelMainsMon.CommissioningDoPixelOccupancy = True  #These configure the commissioning plots.  Pixel occupancy is the 80M bin pixel granularity plots
PixelMainsMon.CommissioningDoNoiseMaps      = False #This shows only pixels with an occupancy higher than configured below.  Again, 80M bins
PixelMainsMon.OccupancyCut                  = 1e-5

ToolSvc += PixelMainsMon
if (InDetFlags.doPrintConfigurables()):
  print PixelMainsMon

# configure the pixel mon manager and add main pixel monitoring tool
from AthenaMonitoring.AthenaMonitoringConf import AthenaMonManager
from AthenaMonitoring.DQMonFlags           import DQMonFlags
PixMonMan                     = AthenaMonManager( "PixelMonManager" )
PixMonMan.FileKey             = DQMonFlags.monManFileKey()
PixMonMan.ManualDataTypeSetup = DQMonFlags.monManManualDataTypeSetup()
PixMonMan.ManualRunLBSetup    = DQMonFlags.monManManualRunLBSetup()
PixMonMan.DataType            = DQMonFlags.monManDataType()
PixMonMan.Environment         = DQMonFlags.monManEnvironment()
PixMonMan.Run                 = DQMonFlags.monManRun()
PixMonMan.LumiBlock           = DQMonFlags.monManLumiBlock()
PixMonMan.AthenaMonTools     += [ PixelMainsMon ]

topSequence += PixMonMan
if (InDetFlags.doPrintConfigurables()):
  print PixMonMan
