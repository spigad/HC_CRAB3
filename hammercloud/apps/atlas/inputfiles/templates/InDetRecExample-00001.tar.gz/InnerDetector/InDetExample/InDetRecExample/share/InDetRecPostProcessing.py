
# ------------------------------------------------------------
#
# ----------- now we do post-processing
#
# ------------------------------------------------------------
#
# ------------ Primary Vertex finding
#

# prd asso needs to be set to the refitted tracks otherwise the shared hits in the summaries are wrong!
if (InDetFlags.doRefit() and not InDetFlags.doPattern()) and (InDetFlags.doVertexFinding() or InDetFlags.doParticleCreation()):
  from InDetTrackPRD_Association.InDetTrackPRD_AssociationConf import InDet__InDetTrackPRD_Association
  InDetRefit_PRD_Association = InDet__InDetTrackPRD_Association(name            = 'InDetRefit_PRD_Association',
                                                                AssociationTool = InDetPrdAssociationTool,
                                                                TracksName      = [ InDetKeys.RefittedTracks() ]) 
  topSequence += InDetRefit_PRD_Association
  if (InDetFlags.doPrintConfigurables()):
    print          InDetRefit_PRD_Association
  
if InDetFlags.doVertexFinding():
  if InDetFlags.primaryVertexSetup() == 'DefaultAdaptiveFinding' or InDetFlags.primaryVertexSetup() == 'AdaptiveFinding' or InDetFlags.primaryVertexSetup() == 'AdaptiveMultiFinding':
    #
    # load configured Seed finder
    #
    
    if (InDetFlags.doPrimaryVertex3DFinding()):
      from TrkVertexSeedFinderTools.TrkVertexSeedFinderToolsConf import Trk__CrossDistancesSeedFinder
      InDetVtxSeedFinder = Trk__CrossDistancesSeedFinder(name = "InDetCrossDistancesSeedFinder"
                                                         #Mode1dFinder = # default, no setting needed
                                                         )
    else:
      from TrkVertexSeedFinderTools.TrkVertexSeedFinderToolsConf import Trk__ZScanSeedFinder
      InDetVtxSeedFinder = Trk__ZScanSeedFinder(name = "InDetZScanSeedFinder"
                                                #Mode1dFinder = # default, no setting needed
                                                )
      
    ToolSvc += InDetVtxSeedFinder
    if (InDetFlags.doPrintConfigurables()):
      print      InDetVtxSeedFinder
        
    
    #
    # load Impact Point Factory
    #

    from TrkVertexFitterUtils.TrkVertexFitterUtilsConf import Trk__ImpactPoint3dEstimator
    InDetImpactPoint3dEstimator = Trk__ImpactPoint3dEstimator(name         = "InDetImpactPoint3dEstimator",
                                                              Extrapolator = InDetExtrapolator)
    ToolSvc += InDetImpactPoint3dEstimator
    if (InDetFlags.doPrintConfigurables()):
      print      InDetImpactPoint3dEstimator
            
    
    
    from TrkVertexFitterUtils.TrkVertexFitterUtilsConf import Trk__ImpactPoint3dAtaPlaneFactory
    InDetIp3dAtaPointFactory = Trk__ImpactPoint3dAtaPlaneFactory(name                   = "InDetIp3dAtaPointFactory",
                                                                 Extrapolator           = InDetExtrapolator,
                                                                 ImpactPoint3dEstimator = InDetImpactPoint3dEstimator)
    ToolSvc += InDetIp3dAtaPointFactory
    if (InDetFlags.doPrintConfigurables()):
      print      InDetIp3dAtaPointFactory
    #
    # load Configured Annealing Maker
    #
    from TrkVertexFitterUtils.TrkVertexFitterUtilsConf import Trk__DetAnnealingMaker
    InDetAnnealingMaker = Trk__DetAnnealingMaker(name = "InDetAnnealingMaker")
    InDetAnnealingMaker.SetOfTemperatures = [64.,16.,4.,2.,1.5,1.] # not default
    ToolSvc += InDetAnnealingMaker
    if (InDetFlags.doPrintConfigurables()):
      print      InDetAnnealingMaker

  #
  # load linearized track factory
  #
  from TrkVertexFitterUtils.TrkVertexFitterUtilsConf import Trk__FullLinearizedTrackFactory
  InDetLinFactory = Trk__FullLinearizedTrackFactory(name              = "InDetFullLinearizedTrackFactory",
                                                    Extrapolator      = InDetExtrapolator,
                                                    MagneticFieldTool = InDetMagField)
  ToolSvc += InDetLinFactory
  if (InDetFlags.doPrintConfigurables()):
    print      InDetLinFactory
    
  #
  # ------ load vertex fitter tool
  #
  if InDetFlags.primaryVertexSetup() == 'DefaultFastFinding':
    #
    # load fast Billoir fitter
    #
    from TrkVertexBilloirTools.TrkVertexBilloirToolsConf import Trk__FastVertexFitter
    InDetVxFitterTool = Trk__FastVertexFitter(name                   = "InDetFastVertexFitterTool",
                                              LinearizedTrackFactory = InDetLinFactory,
                                              Extrapolator           = InDetExtrapolator)

  elif InDetFlags.primaryVertexSetup() == 'DefaultFullFinding':
    #
    # load full billoir fitter
    #
    from TrkVertexBilloirTools.TrkVertexBilloirToolsConf import Trk__FullVertexFitter
    InDetVxFitterTool = Trk__FullVertexFitter(name                    = "InDetFullVertexFitterTool",
                                              LinearizedTrackFactory  = InDetLinFactory,
                                              Extrapolator            = InDetExtrapolator)

  elif InDetFlags.primaryVertexSetup() == 'DefaultKalmanFinding':
    #
    # case default finding with Kalman filter requested 
    #
    
    from TrkVertexFitters.TrkVertexFittersConf import Trk__SequentialVertexSmoother
    InDetVertexSmoother = Trk__SequentialVertexSmoother()
    ToolSvc += InDetVertexSmoother
    if (InDetFlags.doPrintConfigurables()):
      print      InDetVertexSmoother

    from TrkVertexFitters.TrkVertexFittersConf import Trk__SequentialVertexFitter
    InDetVxFitterTool = Trk__SequentialVertexFitter(name                   = "InDetSequentialVxFitterTool",
                                                    LinearizedTrackFactory = InDetLinFactory,
                                                    VertexSmoother         = InDetVertexSmoother
                                                    #VertexUpdator   = # no setting required 
                                                    )
    
  elif InDetFlags.primaryVertexSetup() == 'DefaultAdaptiveFinding' or InDetFlags.primaryVertexSetup() == 'AdaptiveFinding':
    #
    # load configured adaptive vertex fitter
    #
    from TrkVertexFitters.TrkVertexFittersConf import Trk__AdaptiveVertexFitter
    InDetVxFitterTool = Trk__AdaptiveVertexFitter(name                         = "InDetAdaptiveVxFitterTool",
                                                  SeedFinder                   = InDetVtxSeedFinder,
                                                  LinearizedTrackFactory       = InDetLinFactory,
                                                  ImpactPoint3dAtaPlaneFactory = InDetIp3dAtaPointFactory,
                                                  AnnealingMaker               = InDetAnnealingMaker)
    
  elif InDetFlags.primaryVertexSetup() == 'AdaptiveMultiFinding':
    #
    #load adaptive multi vertex fitter
    #
    from TrkVertexFitters.TrkVertexFittersConf import Trk__AdaptiveMultiVertexFitter
    InDetVxFitterTool = Trk__AdaptiveMultiVertexFitter(name                         = "InDetAdaptiveMultiVertexFitter",
                                                       LinearizedTrackFactory       = InDetLinFactory,
                                                       ImpactPoint3dAtaPlaneFactory = InDetIp3dAtaPointFactory,
                                                       AnnealingMaker               = InDetAnnealingMaker,
                                                       DoSmoothing                  = True) # false is default
                                                       
  elif InDetFlags.primaryVertexSetup() == 'DefaultVKalVrtFinding':
    #
    #load vkal fitter
    #
    from TrkVKalVrtFitter.TrkVKalVrtFitterConf import Trk__TrkVKalVrtFitter
    InDetVxFitterTool = Trk__TrkVKalVrtFitter(name = "InDetVKalVrtFitter")
                                                       
  ToolSvc += InDetVxFitterTool
  if (InDetFlags.doPrintConfigurables()):
    print      InDetVxFitterTool
  #
  # ----- load vertex finder tool
  #
  if not (InDetFlags.primaryVertexSetup() == 'AdaptiveFinding') and not (InDetFlags.primaryVertexSetup() == 'AdaptiveMultiFinding') and not (InDetFlags.primaryVertexSetup() == 'DefaultVKalVrtFinding'):
    #
    # load primary vertex finder tool
    #
    from InDetPriVxFinderTool.InDetPriVxFinderToolConf import InDet__InDetPriVxFinderTool
    InDetPriVxFinderTool = InDet__InDetPriVxFinderTool(name              = "InDetPriVxFinderTool",
                                                       VertexFitterTool  = InDetVxFitterTool,
                                                       TrackSelector     = InDetTrackSelectorTool,
                                                       useBeamConstraint = InDetFlags.useBeamConstraint())
    if jobproperties.Beam.zeroLuminosity():
      InDetPriVxFinderTool.enableMultipleVertices = 0;
    else:
      InDetPriVxFinderTool.enableMultipleVertices = 1;
                                                            
  elif InDetFlags.primaryVertexSetup() == 'AdaptiveFinding':
    #
    # load adaptive primary vertex finder
    #

    from InDetPriVxFinderTool.InDetPriVxFinderToolConf import InDet__InDetAdaptivePriVxFinderTool
    InDetPriVxFinderTool = InDet__InDetAdaptivePriVxFinderTool(name             = "InDetAdaptivePriVxFinderTool",
                                                               VertexFitterTool = InDetVxFitterTool,
                                                               TrackSelector    = InDetTrackSelectorTool
                                                               )
                                                            
  elif InDetFlags.primaryVertexSetup() == 'AdaptiveMultiFinding':
    #
    # load adaptive multi primary vertex finder
    #
    from InDetPriVxFinderTool.InDetPriVxFinderToolConf import InDet__InDetAdaptiveMultiPriVxFinderTool
    InDetPriVxFinderTool = InDet__InDetAdaptiveMultiPriVxFinderTool(name              = "InDetAdaptiveMultiPriVxFinderTool",
                                                                    SeedFinder        = InDetVtxSeedFinder,
                                                                    VertexFitterTool  = InDetVxFitterTool,
                                                                    TrackSelector     = InDetTrackSelectorTool,
                                                                    useBeamConstraint = InDetFlags.useBeamConstraint(),
                                                                    selectiontype     = 0,
                                                                    do3dSplitting     = InDetFlags.doPrimaryVertex3DFinding())
  
  elif InDetFlags.primaryVertexSetup() == 'DefaultVKalVrtFinding':
    #
    # load vkal vertex finder tool
    #
    from InDetVKalPriVxFinderTool.InDetVKalPriVxFinderTool import InDet__InDetVKalPriVxFinderTool
    InDetPriVxFinderTool = InDet__InDetVKalPriVxFinderTool(name                   = "InDetVKalPriVxFinder",
                                                           TrackSummaryTool       = InDetTrackSummaryTool,
                                                           FitterTool             = InDetVxFitterTool,
                                                           BeamConstraint         = 0)
    if InDetFlags.useBeamConstraint():
      InDetPriVxFinderTool.BeamConstraint = 1

  ToolSvc += InDetPriVxFinderTool
  if (InDetFlags.doPrintConfigurables()):
    print      InDetPriVxFinderTool
  #
  # load primary vertex finding algorithm and configure it 
  #
  from InDetPriVxFinder.InDetPriVxFinderConf import InDet__InDetPriVxFinder
  InDetPriVxFinder = InDet__InDetPriVxFinder(name                   = "InDetPriVxFinder",
                                             VertexFinderTool       = InDetPriVxFinderTool,
                                             TracksName             = InDetKeys.Tracks(),
                                             VxCandidatesOutputName = InDetKeys.PrimaryVertices())
  if InDetFlags.doRefit():
    InDetPriVxFinder.TracksName = InDetKeys.RefittedTracks()
    
  topSequence += InDetPriVxFinder
  if (InDetFlags.doPrintConfigurables()):
    print          InDetPriVxFinder

#
# ------------ Particle creation
#
if InDetFlags.doParticleCreation():
   #
   # load patricle creator tool
   #
   from TrkParticleCreator.TrkParticleCreatorConf import Trk__ParticleCreatorTool
   InDetParticleCreatorTool = Trk__ParticleCreatorTool(name             = "InDetParticleCreatorTool",
                                                       KeepParameters   = True,
                                                       Extrapolator     = InDetExtrapolator,
                                                       TrackSummaryTool = InDetTrackSummaryTool) # no shared hits here, it is cached

   # in case xKal _or_ (==XOR) iPat run STANDALONE (i.e. their tracks are in "Tracks" container) the
   # summary tool needs to be the shared hit one ... otherwise they lack shared hits again.
   # and the prd map needs to be filled as well!
   if (not (InDetFlags.doNewTracking() or InDetFlags.doTRTStandalone() or InDetFlags.doBackTracking() or InDetFlags.doBeamGas() or InDetFlags.doBeamHalo() or InDetFlags.doCosmics())):
     if (InDetFlags.doxKalman() ^ InDetFlags.doiPatRec()):
       InDetParticleCreatorTool.ForceTrackSummaryUpdate = True
       InDetParticleCreatorTool.TrackSummaryTool        = InDetTrackSummaryToolSharedHits

       from InDetTrackPRD_Association.InDetTrackPRD_AssociationConf import InDet__InDetTrackPRD_Association
       InDetPRD_Association_xKaliPatStandalone = InDet__InDetTrackPRD_Association(name            = 'InDetPRD_Association_xKaliPatStandalone',
                                                                                  AssociationTool = InDetPrdAssociationTool,
                                                                                  TracksName      = [ InDetKeys.Tracks() ]) 
       topSequence += InDetPRD_Association_xKaliPatStandalone
       if (InDetFlags.doPrintConfigurables()):
         print          InDetPRD_Association_xKaliPatStandalone

   ToolSvc += InDetParticleCreatorTool
   if (InDetFlags.doPrintConfigurables()):
     print      InDetParticleCreatorTool
   
   #
   # load the algorithm and configure it
   #
   from InDetParticleCreation.InDetParticleCreationConf import InDet__ParticleCreator
   InDetParticleCreation = InDet__ParticleCreator(name                     = "InDetParticleCreation",
                                                  ParticleCreatorTool      = InDetParticleCreatorTool,
                                                  TracksName               = InDetKeys.Tracks(),
                                                  TrackParticlesOutputName = InDetKeys.TrackParticles(),
                                                  PRDAssociationTool       = None ,  # does not do anything after caching: InDetPrdAssociationTool,
                                                  DoSharedHits             = False, # does not do anything after caching: InDetFlags.doSharedHits(),
                                                  VxCandidatesPrimaryName  = InDetKeys.PrimaryVertices())
   if InDetFlags.doRefit() and not InDetFlags.doPattern():
     InDetParticleCreation.TracksName = InDetKeys.RefittedTracks()
   topSequence += InDetParticleCreation
   if (InDetFlags.doPrintConfigurables()):
     print          InDetParticleCreation
   
   
#
# --- do we write Vertices and TrackParticles for all?
#
if InDetFlags.AODall():
  #
  # --- first reset the PRD association tool and fill it with iPat tracks and PRD's
  #
  if InDetFlags.doVertexFinding() or InDetFlags.doParticleCreation():
    from InDetTrackPRD_Association.InDetTrackPRD_AssociationConf import InDet__InDetTrackPRD_Association
    InDetIPat_PRD_Association = InDet__InDetTrackPRD_Association(name            = 'InDetIPat_PRD_Association',
                                                                  AssociationTool = InDetPrdAssociationTool,
                                                                  TracksName      = [ "ConvertedIPatTracks" ]) 
    topSequence += InDetIPat_PRD_Association
    if (InDetFlags.doPrintConfigurables()):
      print          InDetIPat_PRD_Association
  
  #
  # --- now do vertexing for iPat
  #
  if InDetFlags.doVertexFinding():
    from InDetPriVxFinder.InDetPriVxFinderConf import InDet__InDetPriVxFinder
    InDetIPatPriVxFinder = InDet__InDetPriVxFinder(name                   = "InDetIPatPriVxFinder",
                                                    VertexFinderTool       = InDetPriVxFinderTool,
                                                    TracksName             = "ConvertedIPatTracks",
                                                    VxCandidatesOutputName = InDetKeys.IPatPrimaryVertices())
    topSequence += InDetIPatPriVxFinder
    if (InDetFlags.doPrintConfigurables()):
      print          InDetIPatPriVxFinder
   
  #
  # --- now do particle creation for iPat
  #
  if InDetFlags.doParticleCreation():
    # iPat and xKal could share this tool ... easier for now to setup two instances
    from TrkParticleCreator.TrkParticleCreatorConf import Trk__ParticleCreatorTool
    InDetIPatParticleCreatorTool = Trk__ParticleCreatorTool(name             = "InDetIPatParticleCreatorTool",
                                                            KeepParameters   = True,
                                                            Extrapolator     = InDetExtrapolator,
                                                            TrackSummaryTool = InDetTrackSummaryToolSharedHits,
                                                            ForceTrackSummaryUpdate = True)
    ToolSvc += InDetIPatParticleCreatorTool
    if (InDetFlags.doPrintConfigurables()):
      print      InDetIPatParticleCreatorTool
       
    from InDetParticleCreation.InDetParticleCreationConf import InDet__ParticleCreator
    InDetIPatParticleCreation = InDet__ParticleCreator(name                     = "InDetIPatParticleCreation",
                                                       ParticleCreatorTool      = InDetIPatParticleCreatorTool,
                                                       TracksName               = "ConvertedIPatTracks",
                                                       PRDAssociationTool       = InDetPrdAssociationTool,
                                                       TrackParticlesOutputName = InDetKeys.IPatParticles(),
                                                       VxCandidatesPrimaryName  = InDetKeys.IPatPrimaryVertices())
    topSequence += InDetIPatParticleCreation
    if (InDetFlags.doPrintConfigurables()):
      print          InDetIPatParticleCreation
     
  # do this only if xKal is explicitely turned on!
  if InDetFlags.doxKalman():
    #
    # --- first reset the PRD association tool and fill it with xKal tracks and PRD's
    #
    if InDetFlags.doVertexFinding() or InDetFlags.doParticleCreation():
      from InDetTrackPRD_Association.InDetTrackPRD_AssociationConf import InDet__InDetTrackPRD_Association
      InDetXKal_PRD_Association = InDet__InDetTrackPRD_Association(name            = 'InDetXKal_PRD_Association',
                                                                  AssociationTool = InDetPrdAssociationTool,
                                                                  TracksName      = [ "ConvertedXKalmanTracks" ]) 
      topSequence += InDetXKal_PRD_Association
      if (InDetFlags.doPrintConfigurables()):
        print          InDetXKal_PRD_Association
    #
    # --- now do vertexing for XKal
    #
    if InDetFlags.doVertexFinding():
      from InDetPriVxFinder.InDetPriVxFinderConf import InDet__InDetPriVxFinder
      InDetXKalPriVxFinder = InDet__InDetPriVxFinder(name                   = "InDetXKalPriVxFinder",
                                                     VertexFinderTool       = InDetPriVxFinderTool,
                                                     TracksName             = "ConvertedXKalmanTracks",
                                                     VxCandidatesOutputName = InDetKeys.XKalPrimaryVertices())
      topSequence += InDetXKalPriVxFinder
      if (InDetFlags.doPrintConfigurables()):
        print          InDetXKalPriVxFinder
    
    #
    # --- now do particle creation for xKal
    #
    if InDetFlags.doParticleCreation():
      # iPat and xKal could share this tool ... easier for now to setup two instances
      from TrkParticleCreator.TrkParticleCreatorConf import Trk__ParticleCreatorTool
      InDetXKalParticleCreatorTool = Trk__ParticleCreatorTool(name             = "InDetXKalParticleCreatorTool",
                                                             KeepParameters   = True,
                                                             Extrapolator     = InDetExtrapolator,
                                                             TrackSummaryTool = InDetTrackSummaryToolSharedHits,
                                                             ForceTrackSummaryUpdate = True)
      ToolSvc += InDetXKalParticleCreatorTool
      if (InDetFlags.doPrintConfigurables()):
        print      InDetXKalParticleCreatorTool
       
      from InDetParticleCreation.InDetParticleCreationConf import InDet__ParticleCreator
      InDetXKalParticleCreation = InDet__ParticleCreator(name                     = "InDetXKalParticleCreation",
                                                         ParticleCreatorTool      = InDetXKalParticleCreatorTool,
                                                         TracksName               = "ConvertedXKalmanTracks",
                                                         PRDAssociationTool       = InDetPrdAssociationTool,
                                                         TrackParticlesOutputName = InDetKeys.XKalParticles(),
                                                         VxCandidatesPrimaryName  = InDetKeys.XKalPrimaryVertices())
      topSequence += InDetXKalParticleCreation
      if (InDetFlags.doPrintConfigurables()):
        print          InDetXKalParticleCreation
   
  #
  # --- set PRD asso tool back to its original state ...
  #
  if InDetFlags.doVertexFinding() or InDetFlags.doParticleCreation():
    from InDetTrackPRD_Association.InDetTrackPRD_AssociationConf import InDet__InDetTrackPRD_Association
    InDetReset_PRD_Association = InDet__InDetTrackPRD_Association(name            = 'InDetReset_PRD_Association',
                                                                  AssociationTool = InDetPrdAssociationTool,
                                                                  TracksName      = [ InDetKeys.UnslimmedTracks() ]) 
    topSequence += InDetReset_PRD_Association
    if (InDetFlags.doPrintConfigurables()):
      print          InDetReset_PRD_Association
   
#
# --- do truth for particle creation
#  
if InDetFlags.doParticleCreation() and InDetFlags.doTruth():
    
  from InDetTruthAlgs.InDetTruthAlgsConf import InDet__TrackParticleTruthMaker
  InDetTrackParticleTruthMaker = InDet__TrackParticleTruthMaker (name                         = "InDetTrackParticleTruthMaker",
                                                                 tracksName                   = InDetKeys.Tracks(),
                                                                 tracksTruthName              = InDetKeys.TracksTruth(),
                                                                 trackParticlesName           = InDetKeys.TrackParticles(),
                                                                 trackParticleTruthCollection = InDetKeys.TrackParticlesTruth())
  if InDetFlags.doRefit() and not InDetFlags.doPattern():
    InDetTrackParticleTruthMaker.tracksName      = InDetKeys.RefittedTracks()
    InDetTrackParticleTruthMaker.tracksTruthName = InDetKeys.RefittedTracksTruth()
  topSequence += InDetTrackParticleTruthMaker
  if (InDetFlags.doPrintConfigurables()):
    print          InDetTrackParticleTruthMaker
  #
  # --- do we write Vertices and TrackParticles for all ?
  #
  if InDetFlags.AODall():
    
    InDetIPatTrackParticleTruthMaker = InDet__TrackParticleTruthMaker (name                         = "InDetIPatTrackParticleTruthMaker",
                                                                       tracksName                   = "ConvertedIPatTracks",
                                                                       tracksTruthName              = "ConvertedIPatTracksTruth",
                                                                       trackParticlesName           = InDetKeys.IPatParticles(),
                                                                       trackParticleTruthCollection = InDetKeys.IPatParticlesTruth())
    topSequence += InDetIPatTrackParticleTruthMaker
    if (InDetFlags.doPrintConfigurables()):
      print          InDetIPatTrackParticleTruthMaker

    # only do this for xKalman if it has been explicitly turned on!
    if InDetFlags.doxKalman():
        InDetXKalTrackParticleTruthMaker = InDet__TrackParticleTruthMaker (name                         = "InDetXKalTrackParticleTruthMaker",
                                                                           tracksName                   = "ConvertedXKalmanTracks",
                                                                           tracksTruthName              = "ConvertedXKalmanTracksTruth",
                                                                           trackParticlesName           = InDetKeys.XKalParticles(),
                                                                           trackParticleTruthCollection = InDetKeys.XKalParticlesTruth())
        topSequence += InDetXKalTrackParticleTruthMaker
        if (InDetFlags.doPrintConfigurables()):
          print          InDetXKalTrackParticleTruthMaker

#
# ----------- V0 Finder Algorithm
#
if InDetFlags.doV0Finder() :
  #
  if InDetFlags.useV0Fitter():
    from TrkV0Fitter.TrkV0FitterConf import Trk__TrkV0VertexFitter
    InDetV0Fitter = Trk__TrkV0VertexFitter(name              = 'InDetV0Fitter',
                                           MaxIterations     = 10,
                                           Use_deltaR        = False,
                                           Extrapolator      = InDetExtrapolator,
                                           MagneticFieldTool = InDetMagField)
    ToolSvc += InDetV0Fitter
    #InDetV0Fitter.OutputLevel = DEBUG
    if (InDetFlags.doPrintConfigurables()):
      print      InDetV0Fitter
    #
    InDetVKVertexFitter  = None
    InDetKshortFitter    = None
    InDetLambdaFitter    = None
    InDetLambdabarFitter = None
  else:
    InDetV0Fitter   = None
    #    
    from TrkVKalVrtFitter.TrkVKalVrtFitterConf import Trk__TrkVKalVrtFitter
    InDetVKVertexFitter = Trk__TrkVKalVrtFitter(name                = "InDetVKVFitter",
                                                Extrapolator        = InDetExtrapolator,
                                                IterationNumber     = 30,
                                                MagFieldSvc         = InDetMagField,
                                                MakeExtendedVertex  = True,
                                                Constraint          = 0)
    ToolSvc += InDetVKVertexFitter
    if (InDetFlags.doPrintConfigurables()):
      print      InDetVKVertexFitter
    #
    from TrkVKalVrtFitter.TrkVKalVrtFitterConf import Trk__TrkVKalVrtFitter
    InDetKshortFitter = Trk__TrkVKalVrtFitter(name                = "InDetVKKVFitter",
                                              Extrapolator        = InDetExtrapolator,
                                              IterationNumber     = 30,
                                              MagFieldSvc         = InDetMagField,
                                              MakeExtendedVertex  = True,
                                              Constraint          = 1,
                                              InputParticleMasses = [139.57,139.57],
                                              MassForConstraint   = 497.672)
    ToolSvc += InDetKshortFitter
    if (InDetFlags.doPrintConfigurables()):
      print      InDetKshortFitter
    #
    from TrkVKalVrtFitter.TrkVKalVrtFitterConf import Trk__TrkVKalVrtFitter
    InDetLambdaFitter = Trk__TrkVKalVrtFitter(name                = "InDetVKLFitter",
                                              Extrapolator        = InDetExtrapolator,
                                              IterationNumber     = 30,
                                              MagFieldSvc         = InDetMagField,
                                              MakeExtendedVertex  = True,
                                              Constraint          = 1,
                                              InputParticleMasses = [938.272,139.57],
                                              MassForConstraint   = 1115.68)
    ToolSvc += InDetLambdaFitter
    if (InDetFlags.doPrintConfigurables()):
      print      InDetLambdaFitter
    #
    from TrkVKalVrtFitter.TrkVKalVrtFitterConf import Trk__TrkVKalVrtFitter
    InDetLambdabarFitter = Trk__TrkVKalVrtFitter(name                = "InDetVKLbFitter",
                                                 Extrapolator        = InDetExtrapolator,
                                                 IterationNumber     = 30,
                                                 MagFieldSvc         = InDetMagField,
                                                 MakeExtendedVertex  = True,
                                                 Constraint          = 1,
                                                 InputParticleMasses = [139.57,938.272],
                                                 MassForConstraint   = 1115.68)
    ToolSvc += InDetLambdabarFitter
    if (InDetFlags.doPrintConfigurables()):
      print      InDetLambdabarFitter
  #
  # --- we always need the gamma tool
  #
  from TrkVKalVrtFitter.TrkVKalVrtFitterConf import Trk__TrkVKalVrtFitter
  InDetGammaFitter = Trk__TrkVKalVrtFitter(name                = "InDetVKGFitter",
                                           Extrapolator        = InDetExtrapolator,
                                           IterationNumber     = 30,
                                           MagFieldSvc         = InDetMagField,
                                           Robustness          = 6,
                                           MakeExtendedVertex  = True,
                                           Constraint          = 12,
                                           InputParticleMasses = [0.511,0.511]
                                           )
  ToolSvc += InDetGammaFitter
  if (InDetFlags.doPrintConfigurables()):
    print      InDetGammaFitter

  # Track selector tool
  #
  from InDetTrackSelectorTool.InDetTrackSelectorToolConf import InDet__InDetConversionTrackSelectorTool
  InDetV0VxTrackSelector = InDet__InDetConversionTrackSelectorTool(name                = "InDetV0VxTrackSelector",
                                                                   TrackSummaryTool    = InDetTrackSummaryTool,
                                                                   Extrapolator        = InDetExtrapolator,
                                                                   maxTrtD0            = 20.,
                                                                   maxSiZ0             = 250.,
                                                                   significanceD0_Si   = 1.,
                                                                   significanceD0_Trt  = 0.5,
                                                                   significanceZ0_Trt  = 3.,
                                                                   minPt               = 500.0,
                                                                   IsConversion        = False)

  ToolSvc += InDetV0VxTrackSelector
  if (InDetFlags.doPrintConfigurables()):
    print      InDetV0VxTrackSelector

  # Vertex point estimator
  #
  from InDetConversionFinderTools.InDetConversionFinderToolsConf import InDet__VertexPointEstimator
  InDetV0VtxPointEstimator = InDet__VertexPointEstimator(name                   = "InDetV0VtxPointEstimator",
                                                         MaxTrkXYDiffAtVtx      = [20.,20.,20.],
                                                         MaxTrkZDiffAtVtx       = [100.,100.,100.],
                                                         MaxTrkXYValue          = [400.,400.,400.],
                                                         MinArcLength           = [-20.,-20.,-20.],
                                                         MaxArcLength           = [800.,800.,800.],
                                                         MaxChi2OfVtxEstimation = 2000.)
  ToolSvc += InDetV0VtxPointEstimator
  if (InDetFlags.doPrintConfigurables()):
    print      InDetV0VtxPointEstimator

  #
  # --- now configure the algorithm 
  # 
  from InDetV0Finder.InDetV0FinderConf import InDet__InDetV0Finder
  InDetV0Finder = InDet__InDetV0Finder(name                    = 'InDetV0Finder',
                                       TrackParticleCollection = InDetKeys.TrackParticles(),
                                       V0CandidatesOutputName  = InDetKeys.V0Candidates(),
                                       useV0Fitter             = InDetFlags.useV0Fitter(),
                                       VertexFitterTool        = InDetV0Fitter,
                                       VKVertexFitterTool      = InDetVKVertexFitter,
                                       KshortFitterTool        = InDetKshortFitter,
                                       LambdaFitterTool        = InDetLambdaFitter,
                                       LambdabarFitterTool     = InDetLambdabarFitter,
                                       GammaFitterTool         = InDetGammaFitter,
                                       TrackSelectorTool       = InDetV0VxTrackSelector,
                                       VertexPointEstimator    = InDetV0VtxPointEstimator,
                                       Extrapolator            = InDetExtrapolator,
                                       minsxy                  = 5.,
                                       maxsxy                  = 1000.,
                                       minVertProb             = 0.0001,
                                       minMassProb             = 0.0001)
  topSequence += InDetV0Finder
  if (InDetFlags.doPrintConfigurables()):
    print          InDetV0Finder

#
# ----------- Use Conversion Finder to find V0s ?
#
if InDetFlags.doSecVertexFinder():
  
  from TrkVKalVrtFitter.TrkVKalVrtFitterConf import Trk__TrkVKalVrtFitter
  InDetSecVxFitterTool = Trk__TrkVKalVrtFitter(name                = "InDetSecVxFitter",
                                               Extrapolator        = InDetExtrapolator,
                                               #MagFieldService     = "MagFieldAthenaSvc",
                                               IterationNumber     = 30,
                                               MagFieldSvc         = InDetMagField,
                                               Robustness          = 6,
                                               Constraint          = 0,
                                               InputParticleMasses = [139.57018,139.57018],
                                               MassForConstraint   = 497.672,
                                               VertexForConstraint = [0.,0.,0.],
                                               CovVrtForConstraint = [0.015*0.015,0.,0.015*0.015,0.,0.,10000.*10000.])
  ToolSvc += InDetSecVxFitterTool 
  if (InDetFlags.doPrintConfigurables()):
    print      InDetSecVxFitterTool

  # Distance of minimum approach utility
  #
  from TrkVertexSeedFinderUtils.TrkVertexSeedFinderUtilsConf import Trk__SeedNewtonTrkDistanceFinder
  InDetSecVxTrkDistanceFinder = Trk__SeedNewtonTrkDistanceFinder(name = 'InDetSecVxTrkDistanceFinder')
  ToolSvc += InDetSecVxTrkDistanceFinder 
  if (InDetFlags.doPrintConfigurables()):
    print      InDetSecVxTrkDistanceFinder

  # Helper Tool
  #
  from InDetConversionFinderTools.InDetConversionFinderToolsConf import InDet__ConversionFinderUtils
  InDetSecVxHelper = InDet__ConversionFinderUtils(name = "InDetSecVxFinderUtils")
  ToolSvc += InDetSecVxHelper
  if (InDetFlags.doPrintConfigurables()):
    print      InDetSecVxHelper

  # Track selector tool
  #
  from InDetTrackSelectorTool.InDetTrackSelectorToolConf import InDet__InDetConversionTrackSelectorTool
  InDetSecVxTrackSelector = InDet__InDetConversionTrackSelectorTool(name             = "InDetSecVxTrackSelector",
                                                                    TrackSummaryTool = InDetTrackSummaryTool,
                                                                    Extrapolator     = InDetExtrapolator, 
                                                                    maxSiD0          = 50.0,
                                                                    maxTrtD0         = 100.,
                                                                    maxSiZ0          = 10000.,  #350.0,
                                                                    maxTrtZ0         = 10000.,  #1400.,
                                                                    minPt            = 500.0,
                                                                    RatioCut1        = 0.0,
                                                                    RatioCut2        = 0.0,
                                                                    RatioCut3        = 0.0)
                                                               
  ToolSvc += InDetSecVxTrackSelector
  if (InDetFlags.doPrintConfigurables()):
    print      InDetSecVxTrackSelector

  # Track pairs selector
  #
  from InDetConversionFinderTools.InDetConversionFinderToolsConf import InDet__TrackPairsSelector
  InDetSecVxTrackPairsSelector = InDet__TrackPairsSelector(name                       = "InDetSecVxTrackPairsSelector",
                                                           ConversionFinderHelperTool = InDetSecVxHelper,
                                                           DistanceTool               = InDetSecVxTrkDistanceFinder,
                                                           MaxFirstHitRadius          = 500.,
                                                           MaxDistBetweenTracks       = [6.,90.,30.],
                                                           MaxEta                     = [0.5,0.9,0.4],
                                                           MaxInitDistance            = [350.,640.,80.])
  ToolSvc += InDetSecVxTrackPairsSelector
  if (InDetFlags.doPrintConfigurables()):
    print      InDetSecVxTrackPairsSelector

  # Vertex point estimator
  #
  from InDetConversionFinderTools.InDetConversionFinderToolsConf import InDet__VertexPointEstimator
  InDetSecVtxPointEstimator = InDet__VertexPointEstimator(name                   = "InDetSecVtxPointEstimator",
                                                          MaxTrkXYDiffAtVtx      = [6.,8.,2.],
                                                          MaxTrkZDiffAtVtx       = [80.,380.,80.],
                                                          MaxTrkXYValue          = [450.,650.,400.],
                                                          MinArcLength           = [30.,80.,350.],
                                                          MaxArcLength           = [600.,650.,680.],
                                                          MaxChi2OfVtxEstimation = 20.)
  ToolSvc += InDetSecVtxPointEstimator
  if (InDetFlags.doPrintConfigurables()):
    print      InDetSecVtxPointEstimator

  # Secondary Vertex post selector
  #
  from InDetConversionFinderTools.InDetConversionFinderToolsConf import InDet__ConversionPostSelector
  InDetSecVtxPostSelector = InDet__ConversionPostSelector(name             = "InDetSecVtxPostSelector",
                                                          MaxChi2PerTrack  = [40.,50.,25.],
                                                          MaxInvariantMass = [60.,50.,25.],
                                                          MinFitMomentum   = [2000.,2000.,2000.],
                                                          MinRadius        = [30.,35.,350.])
  ToolSvc += InDetSecVtxPostSelector
  if (InDetFlags.doPrintConfigurables()):
    print      InDetSecVtxPostSelector

  # Single track secondary vertex tool
  #
  from InDetConversionFinderTools.InDetConversionFinderToolsConf import InDet__SingleTrackConversionTool
  InDetSingleTrackSecVtx = InDet__SingleTrackConversionTool(name                       = "InDetSingleTrackSecVtxTool",
                                                            ConversionFinderHelperTool = InDetSecVxHelper,
                                                            TrackSummaryTool           = InDetTrackSummaryTool,
                                                            MinInitialHitRadius        = 70.,
                                                            MinRatioOfHLhits           = 0.0)
  ToolSvc += InDetSingleTrackSecVtx
  if (InDetFlags.doPrintConfigurables()):
    print      InDetSingleTrackSecVtx
  
  from InDetConversionFinderTools.InDetConversionFinderToolsConf import InDet__InDetConversionFinderTools
  InDetSecVtxFinderTool = InDet__InDetConversionFinderTools(name                       = "InDetSecVtxFinderTool",
                                                            VertexFitterTool           = InDetSecVxFitterTool,
                                                            TrackSelectorTool          = InDetSecVxTrackSelector,
                                                            TrackPairsSelector         = InDetSecVxTrackPairsSelector,
                                                            ConversionFinderHelperTool = InDetSecVxHelper,
                                                            VertexPointEstimator       = InDetSecVtxPointEstimator,
                                                            PostSelector               = InDetSecVtxPostSelector,
                                                            SingleTrackConversionTool  = InDetSingleTrackSecVtx,
                                                            Extrapolator               = InDetExtrapolator,
                                                            TrackParticleCollection    = InDetKeys.TrackParticles(),
                                                            RemoveTrtTracks            = True,
                                                            IsConversion               = False)
  ToolSvc += InDetSecVtxFinderTool
  if (InDetFlags.doPrintConfigurables()):
    print      InDetSecVtxFinderTool
  #
  from InDetConversionFinder.InDetConversionFinderConf import InDet__ConversionFinder
  InDetSecVtxFinder = InDet__ConversionFinder(name                      = "InDetSecVtxFinder",
                                              VertexFinderTool          = InDetSecVtxFinderTool,
                                              TracksName                = InDetKeys.TrackParticles(),
                                              #TracksName                = InDetKeys.Tracks(),
                                              InDetConversionOutputName = InDetKeys.SecVertices())
  topSequence += InDetSecVtxFinder
  if (InDetFlags.doPrintConfigurables()):
    print          InDetSecVtxFinder


#
# ----------- Conversion Finder
#
if InDetFlags.doConversions():
  #
  from TrkVKalVrtFitter.TrkVKalVrtFitterConf import Trk__TrkVKalVrtFitter
  InDetConversionVxFitterTool = Trk__TrkVKalVrtFitter(name                = "InDetConversionVxFitter",
                                                      Extrapolator        = InDetExtrapolator,
                                                      IterationNumber     = 30,
                                                      MakeExtendedVertex  = True,
                                                      MagFieldSvc         = InDetMagField,
                                                      Robustness          = 6,
                                                      Constraint          = 12,
                                                      InputParticleMasses = [0.511,0.511],
                                                      MassForConstraint   = 2.,
                                                      VertexForConstraint = [0.,0.,0.],
                                                      CovVrtForConstraint = [0.015*0.015,0.,0.015*0.015,0.,0.,10000.*10000.])
  ToolSvc += InDetConversionVxFitterTool 
  if (InDetFlags.doPrintConfigurables()):
    print      InDetConversionVxFitterTool

  # Distance of minimum approach utility
  #
  from TrkVertexSeedFinderUtils.TrkVertexSeedFinderUtilsConf import Trk__SeedNewtonTrkDistanceFinder
  InDetConversionTrkDistanceFinder = Trk__SeedNewtonTrkDistanceFinder(name = 'InDetConversionTrkDistanceFinder')
  ToolSvc += InDetConversionTrkDistanceFinder 
  if (InDetFlags.doPrintConfigurables()):
    print      InDetConversionTrkDistanceFinder

  # Straight line propagator needed to clean-up single track conversions
  #
  from TrkExSlPropagator.TrkExSlPropagatorConf import Trk__StraightLinePropagator as Propagator
  InDetConversionPropagator = Propagator(name = 'InDetConversionPropagator')
  ToolSvc += InDetConversionPropagator
  if (InDetFlags.doPrintConfigurables()):
    print      InDetConversionPropagator

  # Helper Tool
  #
  from InDetConversionFinderTools.InDetConversionFinderToolsConf import InDet__ConversionFinderUtils
  InDetConversionHelper = InDet__ConversionFinderUtils(name = "InDetConversionFinderUtils")
  ToolSvc += InDetConversionHelper
  if (InDetFlags.doPrintConfigurables()):
    print      InDetConversionHelper

  # Track selector tool
  #
  from InDetTrackSelectorTool.InDetTrackSelectorToolConf import InDet__InDetConversionTrackSelectorTool
  InDetConversionTrackSelector = InDet__InDetConversionTrackSelectorTool(name             = "InDetConversionTrackSelector",
                                                                         TrackSummaryTool = InDetTrackSummaryTool,
                                                                         Extrapolator     = InDetExtrapolator, 
                                                                         maxSiD0          = 50.0,
                                                                         maxTrtD0         = 100.,
                                                                         maxSiZ0          = 10000.,  #350.0,
                                                                         maxTrtZ0         = 10000.,  #1400.,
                                                                         minPt            = 500.0,
                                                                         RatioCut1        = 0.5,
                                                                         RatioCut2        = 0.1,
                                                                         RatioCut3        = 0.1)
                                                               
  ToolSvc += InDetConversionTrackSelector
  if (InDetFlags.doPrintConfigurables()):
    print      InDetConversionTrackSelector

  # Track pairs selector
  #
  from InDetConversionFinderTools.InDetConversionFinderToolsConf import InDet__TrackPairsSelector
  InDetConversionTrackPairsSelector = InDet__TrackPairsSelector(name                       = "InDetConversionTrackPairsSelector",
                                                                ConversionFinderHelperTool = InDetConversionHelper,
                                                                DistanceTool               = InDetConversionTrkDistanceFinder,
                                                                MaxFirstHitRadius          = 500.,
                                                                MaxDistBetweenTracks       = [6.,80.,30.],
                                                                MaxEta                     = [0.5,1.0,0.5],
                                                                MaxInitDistance            = [350.,600.,80.])
  ToolSvc += InDetConversionTrackPairsSelector
  if (InDetFlags.doPrintConfigurables()):
    print      InDetConversionTrackPairsSelector

  # Vertex point estimator
  #
  from InDetConversionFinderTools.InDetConversionFinderToolsConf import InDet__VertexPointEstimator
  InDetConversionVtxPointEstimator = InDet__VertexPointEstimator(name                   = "InDetConversionVtxPointEstimator",
                                                                    MaxTrkXYDiffAtVtx      = [4.,6.,2.],
                                                                    MaxTrkZDiffAtVtx       = [80.,380.,120.],
                                                                    MaxTrkXYValue          = [450.,500.,400.],
                                                                    MinArcLength           = [30.,60.,350.],
                                                                    MaxArcLength           = [500.,650.,680.],
                                                                    MaxChi2OfVtxEstimation = 20.)
  ToolSvc += InDetConversionVtxPointEstimator
  if (InDetFlags.doPrintConfigurables()):
    print      InDetConversionVtxPointEstimator

  # Conversion post selector
  #
  from InDetConversionFinderTools.InDetConversionFinderToolsConf import InDet__ConversionPostSelector
  InDetConversionPostSelector = InDet__ConversionPostSelector(name             = "InDetConversionPostSelector",
                                                              MaxChi2PerTrack  = [40.,100.,80.],
                                                              MaxInvariantMass = [60.,60.,30.],
                                                              MinFitMomentum   = [2000.,2000.,2000.],
                                                              MinRadius        = [30.,35.,250.],
                                                              MaxdR            = -250.)
  ToolSvc += InDetConversionPostSelector
  if (InDetFlags.doPrintConfigurables()):
    print      InDetConversionPostSelector

  # Single track conversion tool
  #
  from InDetConversionFinderTools.InDetConversionFinderToolsConf import InDet__SingleTrackConversionTool
  InDetSingleTrackConversion = InDet__SingleTrackConversionTool(name                       = "InDetSingleTrackConversionTool",
                                                                ConversionFinderHelperTool = InDetConversionHelper,
                                                                TrackSummaryTool           = InDetTrackSummaryTool,
                                                                MinInitialHitRadius        = 70.,
                                                                MinRatioOfHLhits           = 0.95)
  ToolSvc += InDetSingleTrackConversion
  if (InDetFlags.doPrintConfigurables()):
    print      InDetSingleTrackConversion
  
  from InDetConversionFinderTools.InDetConversionFinderToolsConf import InDet__InDetConversionFinderTools
  InDetConversionFinderTools = InDet__InDetConversionFinderTools(name                       = "InDetConversionFinderTools",
                                                                 VertexFitterTool           = InDetConversionVxFitterTool,
                                                                 TrackSelectorTool          = InDetConversionTrackSelector,
                                                                 TrackPairsSelector         = InDetConversionTrackPairsSelector,
                                                                 ConversionFinderHelperTool = InDetConversionHelper,
                                                                 VertexPointEstimator       = InDetConversionVtxPointEstimator,
                                                                 PostSelector               = InDetConversionPostSelector,
                                                                 SingleTrackConversionTool  = InDetSingleTrackConversion,
                                                                 Extrapolator               = InDetExtrapolator,
                                                                 TrackParticleCollection    = InDetKeys.TrackParticles(),
                                                                 RemoveTrtTracks            = False,
                                                                 IsConversion               = True)
  ToolSvc += InDetConversionFinderTools
  if (InDetFlags.doPrintConfigurables()):
    print      InDetConversionFinderTools

  #
  from InDetConversionFinder.InDetConversionFinderConf import InDet__ConversionFinder
  InDetConversionFinder = InDet__ConversionFinder(name                      = "InDetConversionFinder",
                                                  VertexFinderTool          = InDetConversionFinderTools,
                                                  TracksName                = InDetKeys.TrackParticles(),
                                                  InDetConversionOutputName = InDetKeys.Conversions())
  topSequence += InDetConversionFinder
  if (InDetFlags.doPrintConfigurables()):
    print          InDetConversionFinder

#
# ----------- Brem Fitter Algorithm
#
if InDetFlags.doBremFitAlg() :
  from InDetBremFitAlg.InDetBremFitAlgConf import InDet__BremFitAlg
  InDetBremFitAlg = InDet__BremFitAlg(name              = 'InDetBremFitAlg',
                                      # KinkFiner = ...,
                                      # Fitter    = InDetTrackFitter,
                                      TracksName        = InDetKeys.Tracks(),
                                      KinkOutputTracks  = 'KinkBremTracks',
                                      RefittedTrackPair = 'GsfBremTracks')
  topSequence += InDetBremFitAlg
  if (InDetFlags.doPrintConfigurables()):
    print          InDetBremFitAlg

# ------------------------------------------------------------
#
# ------------- Do we do statistics for tracks ?
#
# ------------------------------------------------------------
#
if InDetFlags.doStatistics():
  # for safety check that there are track collections in the list
  if len(TrackCollectionKeys) > 0:
    #
    # --- load statistics alg
    #
    from InDetRecStatistics.InDetRecStatisticsConf import InDet__InDetRecStatisticsAlg
    InDetRecStatistics = InDet__InDetRecStatisticsAlg (name                     = "InDetRecStatistics",
                                                      TrackCollectionKeys      = TrackCollectionKeys,
                                                      TrackTruthCollectionKeys = TrackCollectionTruthKeys,
                                                      PrintSecondary           = True,
                                                      MakeNtuple               = InDetFlags.doStatNtuple(),
                                                      TruthToTrackTool         = InDetTruthToTrack,
                                                      UseTrackSummary          = True,
                                                      SummaryTool              = InDetTrackSummaryToolSharedHits, # this is a bug !!!
                                                      maxEta                   = 2.5,
                                                      minPt                    = 2 * InDetCutValues.minPT())


    if InDetFlags.doCosmics():
      # change cuts for cosmics
      InDetRecStatistics.minPt                    = .001*GeV
      InDetRecStatistics.maxEta                   = 9999.
      InDetRecStatistics.maxRStartPrimary         = 9999999.
      InDetRecStatistics.maxRStartSecondary       = 9999999.
      InDetRecStatistics.maxZStartPrimary         = 9999999.
      InDetRecStatistics.maxZStartSecondary       = 9999999.
      InDetRecStatistics.minREndPrimary           = 0.
      InDetRecStatistics.minREndSecondary         = 0.
      InDetRecStatistics.minZEndPrimary           = 0.
      InDetRecStatistics.minZEndSecondary         = 0.




    topSequence += InDetRecStatistics
    if (InDetFlags.doPrintConfigurables()):
      print          InDetRecStatistics
    #
    from InDetTrackClusterAssValidation.InDetTrackClusterAssValidationConf import InDet__TrackClusterAssValidation
    InDetTrackClusterAssValidation = InDet__TrackClusterAssValidation(name                   = "InDetTrackClusterAssValidation",
                                                                      TracksLocation         = TrackCollectionKeys             ,
                                                                      SpacePointsPixelName   = InDetKeys.PixelSpacePoints()    ,
                                                                      SpacePointsSCTName     = InDetKeys.SCT_SpacePoints()     ,
                                                                      SpacePointsOverlapName = InDetKeys.OverlapSpacePoints()  ,
                                                                      MomentumCut            = 2 * InDetCutValues.minPT()      ,
                                                                      RapidityCut            = 2.0                             ,
                                                                      RadiusMin              = 0.                              ,
                                                                      RadiusMax              = 20.                             ,
                                                                      MinNumberClusters      = 6                               ,
                                                                      MinNumberClustersTRT   = 10                              ,
                                                                      MinNumberSpacePoints   = 3                               ,
                                                                      usePixel               = DetFlags.haveRIO.pixel_on()     ,
                                                                      useSCT                 = DetFlags.haveRIO.SCT_on()       ,
                                                                      useTRT                 = DetFlags.haveRIO.TRT_on()       )

    if InDetFlags.doCosmics():
      InDetTrackClusterAssValidation.MomentumCut = 500*MeV
      InDetTrackClusterAssValidation.RadiusMax = 9999999.0
      InDetTrackClusterAssValidation.RapidityCut = 9999.9
      InDetTrackClusterAssValidation.MinNumberClustersTRT = 0
      #InDetTrackClusterAssValidation.MinNumberClusters      = 0
      #InDetTrackClusterAssValidation.MinNumberClustersTRT   = 0
      #InDetTrackClusterAssValidation.MinNumberSpacePoints   = 0
  
    topSequence += InDetTrackClusterAssValidation
    if (InDetFlags.doPrintConfigurables()):
      print          InDetTrackClusterAssValidation
    #
    # --- do we do histograms ?
    #
    if InDetFlags.doStatNtuple():
      theApp.HistogramPersistency = "ROOT"
      NTupleSvc         =  Service( "NTupleSvc" )
      NTupleSvc.Output += [ "INDETRECSTAT DATAFILE='" + InDetKeys.StatNtupleName() + "'  TYP='ROOT'  OPT='NEW'" ]
  #
  # The following crashes on simulated cosmics (can't find the segments). Disable for now.
  if InDetFlags.doTrtSegments() and not InDetFlags.doCosmics(): 
    from InDetSegmentDriftCircleAssValidation.InDetSegmentDriftCircleAssValidationConf import InDet__SegmentDriftCircleAssValidation
    InDetSegmentDriftCircleAssValidation = InDet__SegmentDriftCircleAssValidation(name                 = "InDetSegmentDriftCircleAssValidation",
                                                                                  OrigTracksLocation   = InDetKeys.TRT_Segments()        ,
                                                                                  TRT_DriftCirclesName = InDetKeys.TRT_DriftCircles()    ,
                                                                                  pTmin                = InDetCutValues.minTRTonlyMinPt(),
                                                                                  Pseudorapidity       = 2.1                             ,
                                                                                  RadiusMin            = 0.                              ,
                                                                                  RadiusMax            = 20.                             ,
                                                                                  MinNumberDCs         = InDetCutValues.minTRTonly())
    topSequence += InDetSegmentDriftCircleAssValidation
    if (InDetFlags.doPrintConfigurables()):
      print          InDetSegmentDriftCircleAssValidation



