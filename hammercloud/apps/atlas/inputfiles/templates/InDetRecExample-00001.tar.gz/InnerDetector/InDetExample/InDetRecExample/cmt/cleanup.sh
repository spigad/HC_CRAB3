if test "${CMTROOT}" = ""; then
  CMTROOT=/afs/cern.ch/sw/contrib/CMT/v1r20p20070720; export CMTROOT
fi
. ${CMTROOT}/mgr/setup.sh
tempfile=`${CMTROOT}/mgr/cmt -quiet build temporary_name`
if test ! $? = 0 ; then tempfile=/tmp/cmt.$$; fi
${CMTROOT}/mgr/cmt cleanup -sh -pack=InDetRecExample -version=InDetRecExample-01-16-07-05 -path=/afs/cern.ch/user/e/elmsheus/athena/testarea/14.5.0.4/InnerDetector/InDetExample $* >${tempfile}; . ${tempfile}
/bin/rm -f ${tempfile}

