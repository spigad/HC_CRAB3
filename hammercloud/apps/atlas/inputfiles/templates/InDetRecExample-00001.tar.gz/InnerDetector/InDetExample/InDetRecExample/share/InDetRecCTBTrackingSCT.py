if InDetFlags.doTrackSegmentsSCT() and DetFlags.haveRIO.SCT_on():
    if InDetFlags.solenoidOn():
        MinNumberOfPointsOnTrack=4
    else:
        MinNumberOfPointsOnTrack=4

    if InDetFlags.materialInteractions():
        matEffects=2
    else:
        matEffects=0

    OutputTrackCollection = InDetKeys.SCTTracks_CTB()
    
    from SiCTBTracking.SiCTBTrackingConf import InDet__SiCTBTracking
    SCT_CTBTracking=InDet__SiCTBTracking(name = "SCT_CTBTracking",
                                         TrackFitter = InDetTrackFitter,
                                         ExtrapolatorName = InDetExtrapolator,
                                         Chi2cut_x = 10,
                                         Chi2cut_z = 50,
                                         MinNumberOfPointsOnTrack = MinNumberOfPointsOnTrack,
                                         MaxNumberOfPoints = 40,
                                         tracksname = OutputTrackCollection,
                                         tracksupname = OutputTrackCollection+"Up",
                                         trackslowname =  OutputTrackCollection+"Low",
                                         processPixels = False,
                                         processSCT = True,
                                         matEffects=matEffects,
                                         Magnet = InDetFlags.solenoidOn())
    topSequence += SCT_CTBTracking

    if (InDetFlags.doPrintConfigurables()):
        print          SCT_CTBTracking
