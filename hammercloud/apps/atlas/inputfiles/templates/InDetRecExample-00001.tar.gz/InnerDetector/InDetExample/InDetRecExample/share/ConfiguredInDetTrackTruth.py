# Blocking the include for after first inclusion of the InDetFlags.py module
include.block ('InDetRecExample/ConfiguredInDetTrackTruth.py')

# -------------------------------------------------------------------------
#
# ------- fragment to handle track truth association
#
# -------------------------------------------------------------------------

class  ConfiguredInDetTrackTruth:
    
    def __init__(self, Tracks = None, DetailedTruth = None, TracksTruth = None):

        from InDetRecExample.InDetJobProperties import InDetFlags
        from AthenaCommon.DetFlags import DetFlags
        from InDetRecExample.InDetKeys import InDetKeys
        #
        # get topSequence
        #
        from AthenaCommon.AlgSequence import AlgSequence
        topSequence = AlgSequence()
        #
        # Enable the detailed track truth
        #
        from InDetTruthAlgs.InDetTruthAlgsConf import InDet__InDetDetailedTrackTruthMaker
        DetailedTruthMaker = InDet__InDetDetailedTrackTruthMaker(name            = DetailedTruth+"Maker",
                                                          TrackCollectionName    = Tracks,
                                                          DetailedTrackTruthName = DetailedTruth,
                                                          TruthNamePixel         = InDetKeys.PixelClustersTruth(),
                                                          TruthNameSCT           = InDetKeys.SCT_ClustersTruth(),
                                                          TruthNameTRT           = InDetKeys.TRT_DriftCirclesTruth())
        # this is how the truth maker gets to know which detector is on ...
        if (not DetFlags.haveRIO.pixel_on()):
           DetailedTruthMaker.TruthNamePixel = ""
        if (not DetFlags.haveRIO.SCT_on()):
           DetailedTruthMaker.TruthNameSCT = ""
        # for cosmics, at the stage of SiPatternRecognition, the TRT truth information is not yet available
        if ((not DetFlags.haveRIO.TRT_on()) or
            (InDetFlags.doCosmics() and (DetailedTruth == "SiSPSeededTracksDetailedTruth" or DetailedTruth == "ResolvedTracksDetailedTruth"))):
           DetailedTruthMaker.TruthNameTRT = ""

        topSequence += DetailedTruthMaker
        if (InDetFlags.doPrintConfigurables()):
          print          DetailedTruthMaker        
        #
        # Detailed to old TrackTruth
        #
        from AthenaCommon.AppMgr import ToolSvc
        if InDetFlags.truthMatchStrategy() == 'TruthMatchRatio':
          from TrkTruthCreatorTools.TrkTruthCreatorToolsConf import Trk__TruthMatchRatio as InDetTruthMatchTool
        elif InDetFlags.truthMatchStrategy() == 'TruthMatchTanimoto':
          from TrkTruthCreatorTools.TrkTruthCreatorToolsConf import Trk__TruthMatchTanimoto as InDetTruthMatchTool
        else:
          print "ConfiguredInDetTrackTruth: error! InDetFlags.truthMatchStrategy must be TruthMatchRatio or TruthMatchTanimoto but is: "+InDetFlags.truthMatchStrategy()
        InDetTruthMatchSimilarityTool = InDetTruthMatchTool("InDetTruthMatchTool")
        InDetTruthMatchSimilarityTool.WeightPixel =  10.
        InDetTruthMatchSimilarityTool.WeightSCT   =   5.
        InDetTruthMatchSimilarityTool.WeightTRT   =   1.
        if not hasattr(ToolSvc, "InDetTruthMatchTool"):
          ToolSvc += InDetTruthMatchSimilarityTool
          if (InDetFlags.doPrintConfigurables()):
            print InDetTruthMatchSimilarityTool

        from TrkTruthAlgs.TrkTruthAlgsConf import TrackTruthSimilaritySelector
        InDetTruthSimilaritySelector = TrackTruthSimilaritySelector(name                     = TracksTruth+"Selector",
                                                                    DetailedTrackTruthName   = DetailedTruth,
                                                                    OutputName               = TracksTruth,
                                                                    TrackTruthSimilarityTool = InDetTruthMatchSimilarityTool)
        topSequence += InDetTruthSimilaritySelector
        if (InDetFlags.doPrintConfigurables()):
          print          InDetTruthSimilaritySelector
