if InDetFlags.doPRDFormation() and DetFlags.makeRIO.TRT_on():

    #
    # Tracking on uncalibrated hits to get the tracks for the phase calculation
    #
    from TRT_TrackSegmentsTool_xk.TRT_TrackSegmentsTool_xkConf import InDet__TRT_TrackSegmentsMaker_CTB
    InDetTRT_TrackSegmentsMakerCTBPhase = InDet__TRT_TrackSegmentsMaker_CTB(name= 'InDetTRTSegmentsMakerCTBPhase',
                                                                            TRTResolution = 99.,
                                                                            DriftCircleCut = 4.,
                                                                            TRTHitsOnTrack = 20,
                                                                            UseDriftTime=False,
                                                                            MagneticField=InDetFlags.solenoidOn(),
                                                                            TRT_ClustersContainer = InDetKeys.TRT_DriftCirclesUncalibrated())

    ToolSvc += InDetTRT_TrackSegmentsMakerCTBPhase
    if (InDetFlags.doPrintConfigurables()):
        print      InDetTRT_TrackSegmentsMakerCTBPhase






    from TRT_TrackSegmentsTool_xk.TRT_TrackSegmentsTool_xkConf import InDet__TRT_TrackSegmentsMaker_ECcosmics
    InDetTRT_TrackSegmentsMaker_ECphase = InDet__TRT_TrackSegmentsMaker_ECcosmics(name= 'InDetTRTSegmentsMaker_ECphase',
                                                                                  ToTCutLoose=9,
                                                                                  ToTCutTight=15.,
                                                                                  ToTCutUpper=40.,
                                                                                  ScaleFactorTube=4.,
                                                                                  MinDCperSeed = 7,
                                                                                  UseDriftTime=False,
                                                                                  Phase=True,
                                                                                  TRT_ClustersContainer=InDetKeys.TRT_DriftCirclesUncalibrated() )

    
    ToolSvc += InDetTRT_TrackSegmentsMaker_ECphase
    if (InDetFlags.doPrintConfigurables()):
        print      InDetTRT_TrackSegmentsMaker_ECphase
    
    from TRT_TrackSegmentsFinder.TRT_TrackSegmentsFinderConf import InDet__TRT_TrackSegmentsFinder
    InDetTRT_TrackSegmentsFinder_ECphase = InDet__TRT_TrackSegmentsFinder(name              = 'InDetTRTSegmentsFinder_ECphase',
                                                                          SegmentsLocation  = "TRT_Segments_ECphase",
                                                                          SegmentsMakerTool = InDetTRT_TrackSegmentsMaker_ECphase)
    topSequence += InDetTRT_TrackSegmentsFinder_ECphase
    if (InDetFlags.doPrintConfigurables()):
        print          InDetTRT_TrackSegmentsFinder_ECphase



    if InDetFlags.materialInteractions():
        matEffects=2
    else:
        matEffects=0


    # TRT standalone as well as Si extension
    from InDetCTBTracking.InDetCTBTrackingConf import InDet__TRTSeededTrackFinder_CTB
    OutputTrackCollection = "TRT_Calibration_Tracks"
    InDetTRTSeededTrackFinder_CTBPhase = InDet__TRTSeededTrackFinder_CTB(name="InDetTRTSeededTrackFinder_CTBPhase",
                                                        TrackFitter=InDetTrackFitterTRT,
                                                        SegmentsMakerTool=InDetTRT_TrackSegmentsMakerCTBPhase,
                                                        OutputTracks = OutputTrackCollection,
                                                        OutputTracksUp="TRT_Cosmic_TracksUpPhase",
                                                        OutputTracksLow="TRT_Cosmic_TracksLowPhase",
                                                        Chi2cut=100,
                                                        matEffects = 0, # does not yet work properly for TRT-only tracks
                                                        OutputSegments="SegmentsPhase",
                                                        OutputSegmentsUp="SegmentsPhaseUp",
                                                        OutputSegmentsLow="SegmentsPhaseLow")
    topSequence += InDetTRTSeededTrackFinder_CTBPhase
    if (InDetFlags.doPrintConfigurables()):
        print InDetTRTSeededTrackFinder_CTBPhase



    OutputTrackCollection = "SiExtended_Calibration_Tracks"
    from InDetCTBTracking.InDetCTBTrackingConf import InDet__InDetExtensionProcessor_CTB
    InDetExtensionProcessor_CTB_Phase = InDet__InDetExtensionProcessor_CTB(name = "InDetExtensionProcessor_CTB_Phase",
                                                                           TrackFitter = InDetTrackFitter,
                                                                           ExtensionTool = InDetTRTExtensionToolCosmicsPhase,
                                                                           InputTracksName = InDetCosmicSiTrackCollection,
                                                                           OutputTracks = OutputTrackCollection,
                                                                           OutputTracksLow=OutputTrackCollection+"Low",
                                                                           OutputTracksUp=OutputTrackCollection+"Up",
                                                                           Chi2cut = 5000,
                                                                           matEffects = matEffects)
    topSequence+= InDetExtensionProcessor_CTB_Phase
    if (InDetFlags.doPrintConfigurables()):
        print InDetExtensionProcessor_CTB_Phase



    #calculation of the event phase

    from InDetCosmicsEventPhase.InDetCosmicsEventPhaseConf import InDet__InDetCosmicsEventPhase
    InDetCosmicsEventPhase = InDet__InDetCosmicsEventPhase(name="InDetCosmicsEventPhase",
                                                           InputTracksName="TRT_Calibration_Tracks",
                                                           InputSegmentsName="TRT_Segments_ECphase",
                                                           UseTRTCalibration=True)

    topSequence += InDetCosmicsEventPhase
    if (InDetFlags.doPrintConfigurables()):
        print          InDetCosmicsEventPhase




    # now calibrate the hits

    from TRT_DriftFunctionTool.TRT_DriftFunctionToolConf import TRT_DriftFunctionTool
    InDetTRT_DriftFunctionTool = TRT_DriftFunctionTool(name = "InDetTRT_DriftFunctionTool",
                                                       AllowDataMCOverride = True,
                                                       ForceData = True)
    
    ToolSvc += InDetTRT_DriftFunctionTool
    if (InDetFlags.doPrintConfigurables()):
        print      InDetTRT_DriftFunctionTool


    from TRT_DriftCircleTool.TRT_DriftCircleToolConf import InDet__TRT_DriftCircleToolCosmics
    InDetTRT_DriftCircleToolCosmics = InDet__TRT_DriftCircleToolCosmics(name                 = "InDetTRT_DriftCircleToolCosmics",
                                                                        TRTDriftFunctionTool = InDetTRT_DriftFunctionTool,
                                                                        TrtDescrManageLocation = InDetKeys.TRT_Manager(),
                                                                        ComTimeName="TRT_Phase",
                                                                        ConditionsSummaryTool  = InDetTRTConditionsSummaryTool,
                                                                        UseConditionsStatus    = True)

    ToolSvc += InDetTRT_DriftCircleToolCosmics
    if (InDetFlags.doPrintConfigurables()):
        print   InDetTRT_DriftCircleToolCosmics  


    from InDetPrepRawDataFormation.InDetPrepRawDataFormationConf import InDet__TRT_RIO_Maker
    InDetTRT_RIO_MakerCosmics = InDet__TRT_RIO_Maker( name = "InDetTRT_RIO_MakerCosmics",
                                                      TRTRIOLocation = InDetKeys.TRT_DriftCircles() ,
                                                      TrtDescrManageLocation = InDetKeys.TRT_Manager(),
                                                      TRTRDOLocation         = InDetKeys.TRT_RDOs(),
                                                      TRT_DriftCircleTool = InDetTRT_DriftCircleToolCosmics)

    topSequence += InDetTRT_RIO_MakerCosmics
    if (InDetFlags.doPrintConfigurables()):
        print InDetTRT_RIO_MakerCosmics

    if InDetFlags.doTruth():
      from InDetTruthAlgs.InDetTruthAlgsConf import InDet__PRD_MultiTruthMaker
      InDetPRD_MultiTruthMakerTRT = InDet__PRD_MultiTruthMaker (name                        = 'InDetPRD_MultiTruthMakerTRT',
                                                                PixelClusterContainerName   = "",
                                                                SCTClusterContainerName     = "",
                                                                TRTDriftCircleContainerName = InDetKeys.TRT_DriftCircles(),
                                                                SimDataMapNamePixel         = "",
                                                                SimDataMapNameSCT           = "",
                                                                SimDataMapNameTRT           = InDetKeys.TRT_SDOs(),
                                                                TruthNamePixel              = "",
                                                                TruthNameSCT                = "",
                                                                TruthNameTRT                = InDetKeys.TRT_DriftCirclesTruth())
      topSequence += InDetPRD_MultiTruthMakerTRT
      if (InDetFlags.doPrintConfigurables()):
        print          InDetPRD_MultiTruthMakerTRT

