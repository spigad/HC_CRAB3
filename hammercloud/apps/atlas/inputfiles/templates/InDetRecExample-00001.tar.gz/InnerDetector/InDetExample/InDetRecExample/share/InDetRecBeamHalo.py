OutputTrackCollection = "ResolvedTracks"
from SiCTBTracking.SiCTBTrackingConf import InDet__SiCTBTracking
SiCTBTracking=InDet__SiCTBTracking(name="SiCTBTracking",
                                   TrackFitter=InDetTrackFitter,
                                   ExtrapolatorName=InDetExtrapolator,
                                   Chi2cut_x=25000,
                                   Chi2cut_y=250,
                                   Chi2cut_z=250,
                                   MinNumberOfPointsOnTrack=4,
                                   MaxNumberOfPoints=40,
                                   tracksname = OutputTrackCollection,
                                   Magnet = True,
                                   SkipNoiseClusters=False,
                                   Halo=True,
                                   processPixels=DetFlags.haveRIO.pixel_on(),
                                   processSCT=DetFlags.haveRIO.SCT_on(),
                                   matEffects=0)

topSequence += SiCTBTracking
if (InDetFlags.doPrintConfigurables()):
  print SiCTBTracking

InputTrackCollection = OutputTrackCollection

InDetSiSpacePointMakerTool.StripLengthTolerance = 0.05
InDetSiSpacePointMakerTool.UsePerpendicularProjection = True

InDetTrackFitter.TrackChi2PerNDFCut    = 9999999.
InDetTrackFitter.MaxIterations         = 30
InDetTrackFitter.SmartMaterialEffects  = False
InDetTrackFitter.OutlierCut=10

if InDetFlags.doTruth():
    #
    # set collection name for truth
    #
    InputTrackCollectionTruth = "ResolvedTracksTruthCollection"
    InputDetailedTrackTruth   = "ResolvedTracksDetailedTruth"
    #
    # set up the truth info for this container
    #
    include ("InDetRecExample/ConfiguredInDetTrackTruth.py")
    InDetTracksTruth = ConfiguredInDetTrackTruth(InputTrackCollection,
                                                 InputDetailedTrackTruth,
                                                 InputTrackCollectionTruth)
    #
    # add final output for statistics
    #
    TrackCollectionKeys      += [ InputTrackCollection ]
    TrackCollectionTruthKeys += [ InputTrackCollectionTruth ]

# output track collection
BeamHaloTrackCollection = InputTrackCollection

#
# ---------- TRT_TrackExtension
#
if InDetFlags.doTRTExtension() or DetFlags.haveRIO.TRT_on():

   #
   # Track extension to TRT algorithm
   #
   # set output extension map name
   #
   from TRT_TrackExtensionTool_xk.TRT_TrackExtensionTool_xkConf import InDet__TRT_TrackExtensionToolCosmics
   InDetTRTExtensionToolCosmics =  InDet__TRT_TrackExtensionToolCosmics(name                  = 'InDetTRT_ExtensionToolCosmics',
                                                                     Propagator        = InDetPropagator,
                                                                     Extrapolator      = InDetExtrapolator,
                                                                     RoadWidth=60)
                                                                  

   ToolSvc += InDetTRTExtensionToolCosmics
   if (InDetFlags.doPrintConfigurables()):
     print      InDetTRTExtensionToolCosmics 


#
# ------------ Track Extension Processor
#
if InDetFlags.doExtensionProcessor() or DetFlags.haveRIO.TRT_on():
   
   #
   OutputTrackCollection = "ExtendedTracks"


   from InDetCTBTracking.InDetCTBTrackingConf import InDet__InDetExtensionProcessor_CTB
   InDetCTBTracking = InDet__InDetExtensionProcessor_CTB(name = "InDetCTBTracking",

   #from InDetCTBTracking.InDetCTBTrackingConf import InDet__InDetCTBTracking
   #InDetCTBTracking = InDet__InDetCTBTracking(name = "InDetCTBTracking",
                                              TrackFitter = InDetTrackFitter,
 #                                             ExtrapolatorName = InDetExtrapolator,
                                              ExtensionTool = InDetTRTExtensionToolCosmics,
                                              InputTracksName = InputTrackCollection,
                                              OutputTracks = OutputTrackCollection,
                                              Chi2cut = 5000,
                                              matEffects = 0)
 #                                             OutputSegments="")
   topSequence+= InDetCTBTracking
   if (InDetFlags.doPrintConfigurables()):
     print InDetCTBTracking

   #
   # and set new input track collection
   #
   InputTrackCollection    = OutputTrackCollection

   #
   # ------------ Track truth.
   #
   if InDetFlags.doTruth():
      #
      # set collection name for truth
      #
      InputTrackCollectionTruth = "ExtendedTracksTruthCollection"
      InputDetailedTrackTruth   = "ExtendedTracksDetailedTruth"       
      #
      # set up the truth info for this container
      #
      include ("InDetRecExample/ConfiguredInDetTrackTruth.py")
      InDetBeamHaloTruth = ConfiguredInDetTrackTruth(InputTrackCollection,
                                                    InputDetailedTrackTruth,
                                                    InputTrackCollectionTruth)
      #
      # add final output for statistics
      #
      TrackCollectionKeys      += [ InputTrackCollection ]
      TrackCollectionTruthKeys += [ InputTrackCollectionTruth ]

   # output track collection
   BeamHaloTrackCollection = InputTrackCollection
