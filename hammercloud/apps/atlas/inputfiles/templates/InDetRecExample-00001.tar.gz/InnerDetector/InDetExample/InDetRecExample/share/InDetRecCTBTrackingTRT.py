if InDetFlags.doTrackSegmentsTRT() and DetFlags.haveRIO.TRT_on():
    from TRT_TrackSegmentsTool_xk.TRT_TrackSegmentsTool_xkConf import InDet__TRT_TrackSegmentsMaker_CTB
    InDetTRT_TrackSegmentsMaker_CTB = InDet__TRT_TrackSegmentsMaker_CTB(name= 'InDetTRTSegmentsMakerCTB',
                                                                       TRTResolution = 99.0,
                                                                       DriftCircleCut = 4.0,
                                                                       TRTHitsOnTrack = 20,
                                                                       MagneticField = InDetFlags.solenoidOn())

    
    ToolSvc += InDetTRT_TrackSegmentsMaker_CTB
    if (InDetFlags.doPrintConfigurables()):
        print      InDetTRT_TrackSegmentsMaker_CTB

    InputTrackCollection = "NONE"
    OutputTrackCollection = "TRT_Cosmic_Tracks"


    if InDetFlags.materialInteractions():
        matEffects=0 # does not yet work properly for TRT-only tracks
    else:
        matEffects=0


    from InDetCTBTracking.InDetCTBTrackingConf import InDet__TRTSeededTrackFinder_CTB
    TRTSeededTrackFinder_CTB = InDet__TRTSeededTrackFinder_CTB(name = "TRTSeededTrackFinder_CTB",
                                                               TrackFitter = InDetTrackFitter,
                                                               SegmentsMakerTool = InDetTRT_TrackSegmentsMaker_CTB,
                                                               AssociationTool = InDetPrdAssociationTool_CTB,
                                                               OutputTracks = OutputTrackCollection,
                                                               OutputTracksUp = OutputTrackCollection+'Up',
                                                               OutputTracksLow = OutputTrackCollection+'Low',
                                                               Chi2cut = 5000,
                                                               matEffects = matEffects) 
    print TRTSeededTrackFinder_CTB
    topSequence+= TRTSeededTrackFinder_CTB
    if (InDetFlags.doPrintConfigurables()):
        print TRTSeededTrackFinder_CTB


    #
    # track segments for EC
    #
    from TRT_TrackSegmentsTool_xk.TRT_TrackSegmentsTool_xkConf import InDet__TRT_TrackSegmentsMaker_ECcosmics
    InDetTRT_TrackSegmentsMaker_EC = InDet__TRT_TrackSegmentsMaker_ECcosmics(name= 'InDetTRTSegmentsMaker_EC',
                                                                             ToTCutLoose=9,
                                                                             ToTCutTight=15.,
                                                                             ToTCutUpper=40.,
                                                                             ScaleFactorTube=4.,
                                                                             MinDCperSeed = 7,
                                                                             UseDriftTime=False,
                                                                             TRT_ClustersContainer = InDetKeys.TRT_DriftCircles() )

    
    ToolSvc += InDetTRT_TrackSegmentsMaker_EC
    if (InDetFlags.doPrintConfigurables()):
        print      InDetTRT_TrackSegmentsMaker_EC
        
    from TRT_TrackSegmentsFinder.TRT_TrackSegmentsFinderConf import InDet__TRT_TrackSegmentsFinder
    InDetTRT_TrackSegmentsFinder_EC = InDet__TRT_TrackSegmentsFinder(name              = 'InDetTRTSegmentsFinder_EC',
                                                                     SegmentsLocation  = "TRT_Segments_EC",
                                                                     SegmentsMakerTool = InDetTRT_TrackSegmentsMaker_EC)
    topSequence += InDetTRT_TrackSegmentsFinder_EC
    if (InDetFlags.doPrintConfigurables()):
        print          InDetTRT_TrackSegmentsFinder_EC


    from TRT_SegmentsToTrack.TRT_SegmentsToTrackConf import InDet__TRT_SegmentsToTrack
    InDetTrkSegmenttoTrk_EC=InDet__TRT_SegmentsToTrack(name="InDetTRT_SegmentsToTrack_Endcap",
                                                       OutputTrackCollection = "SegmentTracks_EC",
                                                       OutputCombiCollection = "CombinedSegmentTracks_EC",
                                                       InputSegmentsCollection = "TRT_Segments_EC",
                                                       InputSCTCollection = "",
                                                       TrackFitter = InDetTrackFitter,
                                                       CombineSegments = True,
                                                       BarrelSegments = "InDetCosmic_Segments",
                                                       EndcapSegments = "TRT_Segments_EC",
                                                       MaterialEffects = False) # does not yet work properly for TRT-only tracks
            
    topSequence += InDetTrkSegmenttoTrk_EC
    if (InDetFlags.doPrintConfigurables()):
        print InDetTrkSegmenttoTrk_EC






    InputCollections = []
    InputCollections += [ "TRT_Cosmic_Tracks" ]
    InputCollections += [ "SegmentTracks_EC" ]
    InputCollections += [ "TRT_Barrel_EC" ]

    from TrkAmbiguitySolver.TrkAmbiguitySolverConf import Trk__TrkAmbiguitySolver
    InDetAmbiguitySolverTRT_CTB = Trk__TrkAmbiguitySolver(name               = 'InDetTRTAmbiSolver_CTB',
                                                          TrackInput         = InputCollections,
                                                          TrackOutput        = InDetKeys.TRTTracks_CTB(),
                                                          AmbiguityProcessor = InDetAmbiguityProcessorCosmics)
    topSequence += InDetAmbiguitySolverTRT_CTB
    if (InDetFlags.doPrintConfigurables()):
        print         InDetAmbiguitySolverTRT_CTB
        
