# ------------------------------------------------------------
#
# ----------- Data-Preparation stage
#
# ------------------------------------------------------------
#
# ----------- PrepRawData creation from Raw Data Objects
#
if InDetFlags.doPRDFormation():
   
   if DetFlags.makeRIO.pixel_on() or DetFlags.makeRIO.SCT_on():
      #
      # ClusterMakerTool (public), needed by Pixel and SCT Clusterization
      #
      from SiClusterizationTool.SiClusterizationToolConf import InDet__ClusterMakerTool
      InDetClusterMakerTool = InDet__ClusterMakerTool(name                = "InDetClusterMakerTool",
                                                      UsePixelCalibCondDB = DetFlags.makeRIO.pixel_on())
      ToolSvc += InDetClusterMakerTool
      if (InDetFlags.doPrintConfigurables()):
        print      InDetClusterMakerTool
      
   #
   # Pixel Clusterization
   #
   if DetFlags.makeRIO.pixel_on():
      #
      # MergedPixelTool (public)
      #
      from SiClusterizationTool.SiClusterizationToolConf import InDet__MergedPixelsTool
      InDetMergedPixelsTool = InDet__MergedPixelsTool(name          = "InDetMergedPixelsTool", 
                                                      globalPosAlg  = InDetClusterMakerTool)
      ToolSvc += InDetMergedPixelsTool
      if (InDetFlags.doPrintConfigurables()):
        print      InDetMergedPixelsTool
            
      #
      # PixelGangedAmbiguitiesFinder tool (public)
      #
      from SiClusterizationTool.SiClusterizationToolConf import InDet__PixelGangedAmbiguitiesFinder
      InDetPixelGangedAmbiguitiesFinder = InDet__PixelGangedAmbiguitiesFinder(name               = "InDetPixelGangedAmbiguitiesFinder")
      ToolSvc += InDetPixelGangedAmbiguitiesFinder
      if (InDetFlags.doPrintConfigurables()):
        print      InDetPixelGangedAmbiguitiesFinder
            
      #
      # PixelClusterization algorithm
      #
      from InDetPrepRawDataFormation.InDetPrepRawDataFormationConf import InDet__PixelClusterization
      InDetPixelClusterization = InDet__PixelClusterization(name                    = "InDetPixelClusterization",
                                                            clusteringTool          = InDetMergedPixelsTool,
                                                            gangedAmbiguitiesFinder = InDetPixelGangedAmbiguitiesFinder,
                                                            DetectorManagerName     = InDetKeys.PixelManager(), 
                                                            DataObjectName          = InDetKeys.PixelRDOs(),
                                                            ClustersName            = InDetKeys.PixelClusters())
      topSequence += InDetPixelClusterization
      if (InDetFlags.doPrintConfigurables()):
        print          InDetPixelClusterization
   
   #
   # SCT Clusterization
   #
   if DetFlags.makeRIO.SCT_on():
   
      #
      # SCT_ClusteringTool (public)
      #
      from SiClusterizationTool.SiClusterizationToolConf import InDet__SCT_ClusteringTool
      InDetSCT_ClusteringTool = InDet__SCT_ClusteringTool(name              = "InDetSCT_ClusteringTool",
                                                          globalPosAlg      = InDetClusterMakerTool,
                                                          conditionsService = InDetSCT_ConditionsSummarySvc)
      
      ToolSvc += InDetSCT_ClusteringTool
      if (InDetFlags.doPrintConfigurables()):
        print      InDetSCT_ClusteringTool
            
      #
      # SCT_ChannelStatusAlg (public)
      # 
      #from SCT_ConditionsAlgs.SCT_ConditionsAlgsConf import SCT_ChannelStatusAlg
      #InDetSCT_ChannelStatusAlg = SCT_ChannelStatusAlg(name = "InDetSCT_ChannelStatusAlg")
      #ToolSvc += InDetSCT_ChannelStatusAlg
      #print      InDetSCT_ChannelStatusAlg
      
      #
      # SCT_Clusterization algorithm
      #
      from InDetPrepRawDataFormation.InDetPrepRawDataFormationConf import InDet__SCT_Clusterization
      InDetSCT_Clusterization = InDet__SCT_Clusterization(name                    = "InDetSCT_Clusterization",
                                                          clusteringTool          = InDetSCT_ClusteringTool,
                                                          # ChannelStatus         = InDetSCT_ChannelStatusAlg,
                                                          DetectorManagerName     = InDetKeys.SCT_Manager(), 
                                                          DataObjectName          = InDetKeys.SCT_RDOs(),
                                                          ClustersName            = InDetKeys.SCT_Clusters(),
                                                          conditionsService       = InDetSCT_ConditionsSummarySvc,
                                                          FlaggedConditionService = InDetSCT_FlaggedConditionSvc)
      if InDetFlags.cutSCTOccupancy():
        InDetSCT_Clusterization.maxRDOs = 77
      else:
        InDetSCT_Clusterization.maxRDOs = 0
      topSequence += InDetSCT_Clusterization
      if (InDetFlags.doPrintConfigurables()):
        print          InDetSCT_Clusterization
   

#
# ----------- form SpacePoints from clusters in SCT and Pixels
#
if InDetFlags.doSpacePointFormation():
   #
   # SiSpacePointMakerTool (public)
   #
   from SiSpacePointTool.SiSpacePointToolConf import InDet__SiSpacePointMakerTool
   InDetSiSpacePointMakerTool = InDet__SiSpacePointMakerTool(name = "InDetSiSpacePointMakerTool")

   if InDetFlags.doCosmics():
      InDetSiSpacePointMakerTool.StripLengthTolerance = 0.05
      InDetSiSpacePointMakerTool.UsePerpendicularProjection = True


   ToolSvc += InDetSiSpacePointMakerTool
   if (InDetFlags.doPrintConfigurables()):
     print      InDetSiSpacePointMakerTool
   
   #
   # SiTrackerSpacePointFinder algorithm
   #
   from SiSpacePointFormation.SiSpacePointFormationConf import InDet__SiTrackerSpacePointFinder
   InDetSiTrackerSpacePointFinder = InDet__SiTrackerSpacePointFinder(name                   = "InDetSiTrackerSpacePointFinder",
                                                                     SiSpacePointMakerTool  = InDetSiSpacePointMakerTool,
                                                                     PixelsClustersName     = InDetKeys.PixelClusters(),
                                                                     SCT_ClustersName       = InDetKeys.SCT_Clusters(),
                                                                     SpacePointsPixelName   = InDetKeys.PixelSpacePoints(),
                                                                     SpacePointsSCTName     = InDetKeys.SCT_SpacePoints(),
                                                                     SpacePointsOverlapName = InDetKeys.OverlapSpacePoints(),
                                                                     ProcessPixels          = DetFlags.haveRIO.pixel_on(),
                                                                     ProcessSCTs            = DetFlags.haveRIO.SCT_on(),
                                                                     ProcessOverlaps        = DetFlags.haveRIO.SCT_on())

   if InDetFlags.doCosmics():
      InDetSiTrackerSpacePointFinder.ProcessOverlaps = False
      InDetSiTrackerSpacePointFinder.OverrideBeamSpot = True
      InDetSiTrackerSpacePointFinder.VertexZ = 0
      InDetSiTrackerSpacePointFinder.VertexX = 0
      InDetSiTrackerSpacePointFinder.VertexY = 99999999   
      InDetSiTrackerSpacePointFinder.OverlapLimitOpposite=5


   topSequence += InDetSiTrackerSpacePointFinder
   if (InDetFlags.doPrintConfigurables()):
     print          InDetSiTrackerSpacePointFinder


   if InDetFlags.doTruth():
      from InDetTruthAlgs.InDetTruthAlgsConf import InDet__PRD_MultiTruthMaker
      InDetPRD_MultiTruthMakerSi = InDet__PRD_MultiTruthMaker (name                        = 'InDetPRD_MultiTruthMakerSi',
                                                             PixelClusterContainerName   = InDetKeys.PixelClusters(),
                                                             SCTClusterContainerName     = InDetKeys.SCT_Clusters(),
                                                             TRTDriftCircleContainerName = "",
                                                             SimDataMapNamePixel         = InDetKeys.PixelSDOs(),
                                                             SimDataMapNameSCT           = InDetKeys.SCT_SDOs(),
                                                             SimDataMapNameTRT           = "",
                                                             TruthNamePixel              = InDetKeys.PixelClustersTruth(),
                                                             TruthNameSCT                = InDetKeys.SCT_ClustersTruth(),
                                                             TruthNameTRT                = "")
      # a bit complicated, but this is how the truth maker gets to know which detector is on
      if (not DetFlags.haveRIO.pixel_on()):
         InDetPRD_MultiTruthMakerSi.PixelClusterContainerName = ""
         InDetPRD_MultiTruthMakerSi.SimDataMapNamePixel = ""
         InDetPRD_MultiTruthMakerSi.TruthNamePixel = ""
      if (not DetFlags.haveRIO.SCT_on()):
         InDetPRD_MultiTruthMakerSi.SCTClusterContainerName = ""
         InDetPRD_MultiTruthMakerSi.SimDataMapNameSCT = ""
         InDetPRD_MultiTruthMakerSi.TruthNameSCT = ""

      topSequence += InDetPRD_MultiTruthMakerSi
      if (InDetFlags.doPrintConfigurables()):
        print          InDetPRD_MultiTruthMakerSi
