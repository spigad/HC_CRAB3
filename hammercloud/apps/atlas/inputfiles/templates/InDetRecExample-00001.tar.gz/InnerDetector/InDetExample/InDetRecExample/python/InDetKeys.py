##
## @file InDetRecExample/python/InDetKeys.py
## @purpose Python module to hold common flags to configure JobOptions
##

""" InDetContainerKeys
    Python module to hold storegate keys of InDet objects.

"""

__author__ = "A. Wildauer"
__version__= "$Revision: 1.15.2.2 $"
__doc__    = "InDetContainerKeys"

__all__    = [ "InDetKeyContainers" ]

# kindly stolen from AthenaCommonFlags from S. Binet and M. Gallas

##-----------------------------------------------------------------------------
## Import

from AthenaCommon.JobProperties import JobProperty, JobPropertyContainer
from AthenaCommon.JobProperties import jobproperties

##-----------------------------------------------------------------------------
## 1st step: define JobProperty classes
class PixelManager(JobProperty):
    """DetectorManager for Pixel"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'Pixel'

class SCT_Manager(JobProperty):
    """DetectorManager for SCT"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'SCT'

class TRT_Manager(JobProperty):
    """DetectorManager for TRT"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'TRT'

class PixelRDOs(JobProperty):
    """StoreGate key for pixel raw data objects"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'PixelRDOs'

class SCT_RDOs(JobProperty):
    """StoreGate key for SCT raw data objects"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'SCT_RDOs'

class TRT_RDOs(JobProperty):
    """StoreGate key for TRT raw data objects"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'TRT_RDOs'

class GangedPixelMap(JobProperty):
    """StoreGate key for ganged pixel map"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'PixelClusterAmbiguitiesMap'

class PixelSDOs(JobProperty):
    """StoreGate key for pixel simulated data object"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'PixelSDO_Map'

class SCT_SDOs(JobProperty):
    """StoreGate key for SCT simulated data object"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'SCT_SDO_Map'

class TRT_SDOs(JobProperty):
    """StoreGate key for TRT simulated data object"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'TRT_SDO_Map'

class PixelClusters(JobProperty):
    """StoreGate key for PixelClusters prep raw data"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'PixelClusters'

class SCT_Clusters(JobProperty):
    """StoreGate key for SCT_Clusters prep raw data"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'SCT_Clusters'

class TRT_DriftCircles(JobProperty):
    """StoreGate key for TRT_DriftCircles prep raw data"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'TRT_DriftCircles'

class TRT_DriftCirclesUncalibrated(JobProperty):
    """StoreGate key for uncalibrated TRT_DriftCircles  prep raw data (only for cosmics)"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'TRT_DriftCirclesUncalibrated'

class PixelClustersTruth(JobProperty):
    """StoreGate key for PixelClustersTruth"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'PRD_MultiTruthPixel'

class SCT_ClustersTruth(JobProperty):
    """StoreGate key for SCT_ClustersTruth"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'PRD_MultiTruthSCT'

class TRT_DriftCirclesTruth(JobProperty):
    """StoreGate key for TRT_DriftCirclesTruth"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'PRD_MultiTruthTRT'

class PixelSpacePoints(JobProperty):
    """StoreGate key for PixelSpacePoints"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'PixelSpacePoints'

class SCT_SpacePoints(JobProperty):
    """StoreGate key for SCT_SpacePoints"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'SCT_SpacePoints'

class OverlapSpacePoints(JobProperty):
    """StoreGate key for OverlapSpacePoints"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'OverlapSpacePoints'

class TRT_Segments(JobProperty):
    """StoreGate key for TRTSegments"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'TRTSegments'

class TRT_SegmentsTRT(JobProperty):
    """StoreGate key for TRTSegmentsTRT"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'TRTSegmentsTRT'

class AliasToTracks(JobProperty):
    """StoreGate key for AliasToTracks"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'none'

class Tracks(JobProperty):
    """StoreGate key for the final track collection"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'Tracks'

class DetailedTracksTruth(JobProperty):
    """StoreGate key for DetailedTrackTruth"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'DetailedTrackTruth'

class TracksTruth(JobProperty):
    """StoreGate key for TracksTruth"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'TrackTruthCollection'

class UnslimmedTracks(JobProperty):
    """StoreGate key for unslimmed final track collection"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'CombinedInDetTracks'

class UnslimmedDetailedTracksTruth(JobProperty):
    """StoreGate key for detailed track truth of final unslimmed track collection"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'CombinedInDetTracksDetailedTruth'

class UnslimmedTracksTruth(JobProperty):
    """StoreGate key for track truth of final unslimmed track collection"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'CombinedInDetTracksTruthCollection'

class ExtendedTracks(JobProperty):
    """StoreGate key for unslimmed inside out tracks"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'ExtendedTracks'

class ExtendedDetailedTracksTruth(JobProperty):
    """StoreGate key for detailed track truth of unslimmed inside out tracks"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'ExtendedTracksDetailedTruth'

class ExtendedTracksTruth(JobProperty):
    """StoreGate key for track truth of unslimmed inside out tracks"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'ExtendedTracksTruthCollection'

class RefittedTracks(JobProperty):
    """StoreGate key for refitted tracks"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'RefittedTracks'

class RefittedDetailedTracksTruth(JobProperty):
    """StoreGate key for detailed track truth of refitted tracks"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'RefittedTracksDetailedTruth'

class RefittedTracksTruth(JobProperty):
    """StoreGate key for track truth of refitted tracks"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'RefittedTracksTruthCollection'

class PixelTracks(JobProperty):
    """StoreGate key for pixel standalone tracks """
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'ResolvedPixelTracks'

class SCTTracks(JobProperty):
    """StoreGate key for SCT standalone tracks """
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'ResolvedSCTTracks'

class TRTTracks(JobProperty):
    """StoreGate key for TRT standalone tracks """
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'TRTStandaloneTRTTracks'

# CTB track collections
class PixelTracks_CTB(JobProperty):
    """StoreGate key for CTB pixel standalone tracks """
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'ResolvedPixelTracks_CTB'

class SCTTracks_CTB(JobProperty):
    """StoreGate key for CTB SCT standalone tracks """
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'ResolvedSCTTracks_CTB'

class TRTTracks_CTB(JobProperty):
    """StoreGate key for CTB TRT standalone tracks """
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'TRTStandaloneTRTTracks_CTB'

class UnslimmedTracks_CTB(JobProperty):
    """StoreGate key for CTB unslimmed final track collection"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'CombinedInDetTracks_CTB'


class PrimaryVertices(JobProperty):
    """StoreGate key for PrimaryVertices"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'VxPrimaryCandidate'

class TrackParticles(JobProperty):
    """StoreGate key for TrackParticles"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'TrackParticleCandidate'

class TrackParticlesTruth(JobProperty):
    """StoreGate key for TrackParticlesTruth"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'TrackParticleTruthCollection'

class IPatPrimaryVertices(JobProperty):
    """StoreGate key for IPatPrimaryVertices"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'IPatVxPrimaryCandidate'

class IPatParticles(JobProperty):
    """StoreGate key for IPatTrackParticles"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'IPatTrackParticleCandidate'

class IPatParticlesTruth(JobProperty):
    """StoreGate key for IPatTrackParticlesTruth"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'IPatTrackParticleTruthCollection'

class XKalPrimaryVertices(JobProperty):
    """StoreGate key for XKalPrimaryVertices"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'XKalVxPrimaryCandidate'

class XKalParticles(JobProperty):
    """StoreGate key for XKalTrackParticles"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'XKalTrackParticleCandidate'

class XKalParticlesTruth(JobProperty):
    """StoreGate key for XKalTrackParticlesTruth"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'XKalTrackParticleTruthCollection'

class V0Candidates(JobProperty):
    """StoreGate key for V0 candidates"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'V0Candidates'

class SecVertices(JobProperty):
    """StoreGate key for secondary (V0) vertices"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'SecVertices'

class Conversions(JobProperty):
    """StoreGate key for conversions"""
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = 'ConversionCandidate'

# output file keys
class trkValidationNtupleName(JobProperty):
    """Name of tracking validation ntuple file """
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = "TrkValidation.root"

class StatNtupleName(JobProperty):
    """Name of statistics ntuple """
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = "InDetRecStatistics.root"  
    
class StandardPlotHistName(JobProperty):
    """Name of Histogram file for making the Standard Performance Plots """
    statusOn     = True
    allowedTypes = ['str']
    StoredValue  = "InDetStandardPlots.root"
    

##-----------------------------------------------------------------------------
## 2nd step
## Definition of the InDet flag container
class InDetContainerKeys(JobPropertyContainer):
    """Container for the InDet flags
    """
    pass


##-----------------------------------------------------------------------------
## 3rd step
## adding the container to the general top-level container
jobproperties.add_Container(InDetContainerKeys)

##-----------------------------------------------------------------------------
## 4th step
## adding ID flags to the InDetContainerKeys container
jobproperties.InDetContainerKeys.add_JobProperty(PixelManager)
jobproperties.InDetContainerKeys.add_JobProperty(SCT_Manager)
jobproperties.InDetContainerKeys.add_JobProperty(TRT_Manager)
jobproperties.InDetContainerKeys.add_JobProperty(PixelRDOs)
jobproperties.InDetContainerKeys.add_JobProperty(SCT_RDOs)
jobproperties.InDetContainerKeys.add_JobProperty(TRT_RDOs)
jobproperties.InDetContainerKeys.add_JobProperty(GangedPixelMap)
jobproperties.InDetContainerKeys.add_JobProperty(PixelSDOs)
jobproperties.InDetContainerKeys.add_JobProperty(SCT_SDOs)
jobproperties.InDetContainerKeys.add_JobProperty(TRT_SDOs)
jobproperties.InDetContainerKeys.add_JobProperty(PixelClusters)
jobproperties.InDetContainerKeys.add_JobProperty(SCT_Clusters)
jobproperties.InDetContainerKeys.add_JobProperty(TRT_DriftCircles)
jobproperties.InDetContainerKeys.add_JobProperty(TRT_DriftCirclesUncalibrated)
jobproperties.InDetContainerKeys.add_JobProperty(PixelClustersTruth)
jobproperties.InDetContainerKeys.add_JobProperty(SCT_ClustersTruth)
jobproperties.InDetContainerKeys.add_JobProperty(TRT_DriftCirclesTruth)
jobproperties.InDetContainerKeys.add_JobProperty(PixelSpacePoints)
jobproperties.InDetContainerKeys.add_JobProperty(SCT_SpacePoints)
jobproperties.InDetContainerKeys.add_JobProperty(OverlapSpacePoints)
jobproperties.InDetContainerKeys.add_JobProperty(TRT_Segments)
jobproperties.InDetContainerKeys.add_JobProperty(TRT_SegmentsTRT)
jobproperties.InDetContainerKeys.add_JobProperty(AliasToTracks)
jobproperties.InDetContainerKeys.add_JobProperty(Tracks)
jobproperties.InDetContainerKeys.add_JobProperty(DetailedTracksTruth)
jobproperties.InDetContainerKeys.add_JobProperty(TracksTruth)
jobproperties.InDetContainerKeys.add_JobProperty(ExtendedTracks)
jobproperties.InDetContainerKeys.add_JobProperty(ExtendedDetailedTracksTruth)
jobproperties.InDetContainerKeys.add_JobProperty(ExtendedTracksTruth)
jobproperties.InDetContainerKeys.add_JobProperty(UnslimmedTracks)
jobproperties.InDetContainerKeys.add_JobProperty(UnslimmedDetailedTracksTruth)
jobproperties.InDetContainerKeys.add_JobProperty(UnslimmedTracksTruth)
jobproperties.InDetContainerKeys.add_JobProperty(RefittedTracks)
jobproperties.InDetContainerKeys.add_JobProperty(RefittedDetailedTracksTruth)
jobproperties.InDetContainerKeys.add_JobProperty(RefittedTracksTruth)
jobproperties.InDetContainerKeys.add_JobProperty(PixelTracks)
jobproperties.InDetContainerKeys.add_JobProperty(SCTTracks)
jobproperties.InDetContainerKeys.add_JobProperty(TRTTracks)
jobproperties.InDetContainerKeys.add_JobProperty(PixelTracks_CTB)
jobproperties.InDetContainerKeys.add_JobProperty(SCTTracks_CTB)
jobproperties.InDetContainerKeys.add_JobProperty(TRTTracks_CTB)
jobproperties.InDetContainerKeys.add_JobProperty(UnslimmedTracks_CTB)
jobproperties.InDetContainerKeys.add_JobProperty(PrimaryVertices)
jobproperties.InDetContainerKeys.add_JobProperty(TrackParticles)
jobproperties.InDetContainerKeys.add_JobProperty(TrackParticlesTruth)
jobproperties.InDetContainerKeys.add_JobProperty(IPatPrimaryVertices)
jobproperties.InDetContainerKeys.add_JobProperty(IPatParticles)
jobproperties.InDetContainerKeys.add_JobProperty(IPatParticlesTruth)
jobproperties.InDetContainerKeys.add_JobProperty(XKalPrimaryVertices)
jobproperties.InDetContainerKeys.add_JobProperty(XKalParticles)
jobproperties.InDetContainerKeys.add_JobProperty(XKalParticlesTruth)
jobproperties.InDetContainerKeys.add_JobProperty(V0Candidates)
jobproperties.InDetContainerKeys.add_JobProperty(SecVertices)
jobproperties.InDetContainerKeys.add_JobProperty(Conversions)

jobproperties.InDetContainerKeys.add_JobProperty(trkValidationNtupleName)
jobproperties.InDetContainerKeys.add_JobProperty(StatNtupleName)
jobproperties.InDetContainerKeys.add_JobProperty(StandardPlotHistName)


##-----------------------------------------------------------------------------
## 5th step
## short-cut for lazy people
## carefull: do not select InDetContainerKeys as a short name as well.
## otherwise problems with pickle
## Note: you still have to import it:
## >>> from InDetRecExample.InDetKeys import InDetKeys
InDetKeys = jobproperties.InDetContainerKeys
