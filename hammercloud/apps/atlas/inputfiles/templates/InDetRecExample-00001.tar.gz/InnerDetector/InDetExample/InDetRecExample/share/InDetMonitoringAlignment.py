## set to true in case you would like to write out your own InDetAlignMon.root
InDetAlignMonDoOutput = False

## Set to True if you want to run the TruthComparison
InDetAlignMonDoTruth = False

# Setup vertexing sequence without beam constraint.
# NOTE: Include the following BEFORE adding InDetAlignMonManager to topSequence.
# include('InDetAlignmentMonitoring/InDetAlignmentMonitoring_vertexing.py')

from InDetTrackHoleSearch.InDetTrackHoleSearchConf import InDet__InDetTrackHoleSearchTool
InDetAlignMonHoleSearch = InDet__InDetTrackHoleSearchTool(name = "InDetAlignMonHoleSearch",
                                                          Extrapolator = InDetExtrapolator,
                                                          SctSummarySvc = InDetSCT_ConditionsSummarySvc,
                                                          ExtendedListOfHoles = True)
if jobproperties.Beam.beamType()=='cosmics':
    InDetAlignMonHoleSearch.Cosmics =  True
ToolSvc += InDetAlignMonHoleSearch
if (InDetFlags.doPrintConfigurables()):
    print InDetAlignMonHoleSearch

## can alter track selection criteria used for the monitoring here
if not jobproperties.Beam.beamType()=='cosmics': #collisions and single beam running    
    from InDetTrackSelectorTool.InDetTrackSelectorToolConf import InDet__InDetDetailedTrackSelectorTool
    InDetAlignDetailedTrackSelectorTool = InDet__InDetDetailedTrackSelectorTool(name = "InDetAlignDetailedTrackSelectorTool",
                                                                                pTMin = 2000.0, #2 GeV
                                                                                IPd0Max = 100000.0, #no cut on d0 yet
                                                                                IPz0Max = 150.0, #actual cut is on sin(theta)*z0
                                                                                nHitBLayer = 0, #overriding default
                                                                                nHitPix = 0, #overriding default
                                                                                nHitSct = 0, #overriding default
                                                                                nHitSi = 0, #overriding default
                                                                                nHitTrt = 0, #overriding default
                                                                                nSharedSct = 0, #overriding default
                                                                                TrackSummaryTool = InDetTrackSummaryTool,
                                                                                Extrapolator = InDetExtrapolator)
    if jobproperties.Beam.beamType()=='singlebeam':
        InDetAlignDetailedTrackSelectorTool.pTMin = 0.0
        InDetAlignDetailedTrackSelectorTool.IPz0Max = 100000.0
    ToolSvc += InDetAlignDetailedTrackSelectorTool
    if (InDetFlags.doPrintConfigurables()):
        print InDetAlignDetailedTrackSelectorTool
else: #cosmics running
    from InDetTrackSelectorTool.InDetTrackSelectorToolConf import InDet__InDetCosmicTrackSelectorTool
    InDetAlignCosmicTrackSelectorTool = InDet__InDetCosmicTrackSelectorTool(name = "InDetAlignCosmicTrackSelectorTool",
                                                                            maxZ0 = 100000.0, #overriding default
                                                                            maxD0 = 100000.0, #overriding default
                                                                            minPt = 0.0, #overriding default
                                                                            numberOfTRTHits = 0, #overriding default
                                                                            numberOfSiliconHits = 0, #overriding default
                                                                            numberOfSiliconHitsTop = -1, #default
                                                                            numberOfSiliconHitsBottom = -1, #default
                                                                            TrackSummaryTool = InDetTrackSummaryTool)
    ToolSvc += InDetAlignCosmicTrackSelectorTool
    if (InDetFlags.doPrintConfigurables()):
        print InDetAlignCosmicTrackSelectorTool
        
    SiUpSiLowTrackSelectorTool = InDet__InDetCosmicTrackSelectorTool(name = "SiUpSiLowTrackSelectorTool",
                                                                     maxZ0 = 400.0, #overriding default
                                                                     maxD0 = 50.0, #overriding default
                                                                     minPt = 2000.0, #overriding default
                                                                     numberOfTRTHits = 0, #overriding default
                                                                     numberOfSiliconHits = 7, #overriding default
                                                                     numberOfSiliconHitsTop = -1, #default
                                                                     numberOfSiliconHitsBottom = -1, #default
                                                                     TrackSummaryTool = InDetTrackSummaryTool)
    ToolSvc += SiUpSiLowTrackSelectorTool
    if (InDetFlags.doPrintConfigurables()):
        print SiUpSiLowTrackSelectorTool


#all configuration of track selection cuts should be done using TrkSelectorTool above
from InDetAlignmentMonitoring.InDetAlignmentMonitoringConf import InDetAlignMon__TrackSelectionTool
if not jobproperties.Beam.beamType()=='cosmics': 
    InDetAlignMonTrackSelectionTool = InDetAlignMon__TrackSelectionTool(name = "InDetAlignMonTrackSelectionTool",
                                                                        #PassAllTracks = True, ## Uncomment this line to bypass track slection
                                                                        TrackSelectorTool = InDetAlignDetailedTrackSelectorTool)
else:
    InDetAlignMonTrackSelectionTool = InDetAlignMon__TrackSelectionTool(name = "InDetAlignMonTrackSelectionTool",
                                                                        #PassAllTracks = True, ## Uncomment this line to bypass track slection
                                                                        TrackSelectorTool = InDetAlignCosmicTrackSelectorTool)
    SiUpSiLowTrackSelectionTool = InDetAlignMon__TrackSelectionTool(name = "SiUpSiLowTrackSelectionTool",
                                                                    #PassAllTracks = True, ## Uncomment this line to bypass track slection
                                                                    TrackSelectorTool = SiUpSiLowTrackSelectorTool)
if jobproperties.Beam.beamType()=='singlebeam':
    InDetAlignMonTrackSelectionTool.PassAllTracks = True

ToolSvc += InDetAlignMonTrackSelectionTool    
if (InDetFlags.doPrintConfigurables()):
    print InDetAlignMonTrackSelectionTool

if InDetAlignMonDoTruth:
    from TrkTruthToTrack.TrkTruthToTrackConf import Trk__TruthToTrack
    InDetAlignTruthToTrackTool = Trk__TruthToTrack( name = "InDetAlignTruthToTrackTool",
                                                    Extrapolator = InDetExtrapolator )
    ToolSvc += InDetAlignTruthToTrackTool
    if (InDetFlags.doPrintConfigurables()):
        print InDetAlignTruthToTrackTool
        
    from InDetAlignmentMonitoring.InDetAlignmentMonitoringConf import IDAlignMonTruthComparison
    InDetAlignMonTruthComparison = IDAlignMonTruthComparison (name = "InDetAlignMonTruthComparison",
                                                              trackSelection = InDetAlignMonTrackSelectionTool,
                                                              tracksName = InDetKeys.ExtendedTracks(),
                                                              tracksTruthName =InDetKeys.ExtendedTracksTruth(),
                                                              TruthToTrackTool = InDetAlignTruthToTrackTool)
    ToolSvc += InDetAlignMonTruthComparison
    if (InDetFlags.doPrintConfigurables()):
        print InDetAlignMonTruthComparison


if jobproperties.Beam.beamType()=='cosmics' or jobproperties.Beam.beamType()=='singlebeam':
    print "InDetAlignmentMonitoring_InDetRec_jobOptions.py: cosmics or singlebeam beamType: don't run IDAlignMonSivsTRT, InDetAlignMonBeamSpot, IDAlignMonNtuple"
else:
    from InDetAlignmentMonitoring.InDetAlignmentMonitoringConf import IDAlignMonSivsTRT
    InDetAlignMonSivsTRT_noTrig = IDAlignMonSivsTRT (name = "InDetAlignMonSivsTRT_noTrig",
                                                     trackSelection = InDetAlignMonTrackSelectionTool)
    ToolSvc += InDetAlignMonSivsTRT_noTrig
    if (InDetFlags.doPrintConfigurables()):
        print InDetAlignMonSivsTRT_noTrig

    from InDetAlignmentMonitoring.InDetAlignmentMonitoringConf import InDetAlignMonBeamSpot
    InDetAlignMonBeamSpot_noTrig = InDetAlignMonBeamSpot (name = "InDetAlignMonBeamSpot_noTrig",
                                                          vxContainerName = InDetKeys.PrimaryVertices(),
                                                          vxContainerWithBeamConstraint = InDetFlags.useBeamConstraint())
    ToolSvc += InDetAlignMonBeamSpot_noTrig
    if (InDetFlags.doPrintConfigurables()):
        print InDetAlignMonBeamSpot_noTrig
        
    from InDetAlignmentMonitoring.InDetAlignmentMonitoringConf import IDAlignMonNtuple
    InDetAlignMonNtuple = IDAlignMonNtuple (name = "InDetAlignMonNtuple",
                                            tracksName = InDetKeys.ExtendedTracks(),
                                            tracksTruthName = InDetKeys.ExtendedTracksTruth())

from InDetAlignmentMonitoring.InDetAlignmentMonitoringConf import IDAlignMonResiduals
InDetAlignMonResiduals_noTrig = IDAlignMonResiduals (name = "InDetAlignMonResiduals_noTrig",
                                                     trackSelection = InDetAlignMonTrackSelectionTool,
                                                     Pixel_Manager = InDetKeys.PixelManager(),
                                                     SCT_Manager = InDetKeys.SCT_Manager(),
                                                     TRT_Manager = InDetKeys.TRT_Manager())  
if jobproperties.Beam.beamType()=='cosmics' or jobproperties.Beam.beamType()=='singlebeam':
    InDetAlignMonResiduals_noTrig.tracksName= InDetKeys.Tracks()
    #InDetAlignMonResiduals_noTrig.tracksName=InDetKeys.PixelTracks()
else:
    InDetAlignMonResiduals_noTrig.tracksName=InDetKeys.ExtendedTracks()
ToolSvc += InDetAlignMonResiduals_noTrig
if (InDetFlags.doPrintConfigurables()):
    print InDetAlignMonResiduals_noTrig

from InDetAlignmentMonitoring.InDetAlignmentMonitoringConf import IDAlignMonEfficiencies
InDetAlignMonEfficiencies_noTrig = IDAlignMonEfficiencies (name = "InDetAlignMonEfficiencies_noTrig",
                                                           trackSelection = InDetAlignMonTrackSelectionTool,
                                                           HoleSearch = InDetAlignMonHoleSearch,
                                                           Pixel_Manager = InDetKeys.PixelManager(),
                                                           SCT_Manager = InDetKeys.SCT_Manager(),
                                                           TRT_Manager = InDetKeys.TRT_Manager())    
if jobproperties.Beam.beamType()=='cosmics' or jobproperties.Beam.beamType()=='singlebeam':
    InDetAlignMonEfficiencies_noTrig.tracksName= InDetKeys.Tracks()
    #InDetAlignMonEfficiencies_noTrig.tracksName=InDetKeys.PixelTracks()
else:
    InDetAlignMonEfficiencies_noTrig.tracksName=InDetKeys.ExtendedTracks()                                                      
ToolSvc += InDetAlignMonEfficiencies_noTrig
if (InDetFlags.doPrintConfigurables()):
    print InDetAlignMonEfficiencies_noTrig

from InDetAlignmentMonitoring.InDetAlignmentMonitoringConf import IDAlignMonGenericTracks
InDetAlignMonGenericTracks_noTrig = IDAlignMonGenericTracks (name = "InDetAlignMonGenericTracks_noTrig",
                                                             trackSelection = InDetAlignMonTrackSelectionTool,
                                                             VxPrimContainerName = InDetKeys.PrimaryVertices())   
if jobproperties.Beam.beamType()=='cosmics' or jobproperties.Beam.beamType()=='singlebeam':
    InDetAlignMonGenericTracks_noTrig.tracksName=InDetKeys.Tracks()
    #InDetAlignMonGenericTracks_noTrig. tracksName=InDetKeys.PixelTracks()
else:
    InDetAlignMonGenericTracks_noTrig.tracksName=InDetKeys.ExtendedTracks()                                
ToolSvc += InDetAlignMonGenericTracks_noTrig
if (InDetFlags.doPrintConfigurables()):
    print InDetAlignMonGenericTracks_noTrig




if jobproperties.Beam.beamType()=='cosmics':
    from InDetAlignmentMonitoring.InDetAlignmentMonitoringConf import IDAlignMonTrackSegments
    InDetAlignMonTrackSegments_TRTUpLow = IDAlignMonTrackSegments ( name = "InDetAlignMonTrackSegments_TRTUpLow",
                                                                 InputTracksName = InDetKeys.Tracks(),
                                                                 #Combined Tracks
                                                                 UpperTracksName = "InDetCosmic_TracksUp",
                                                                 LowerTracksName = "InDetCosmic_TracksLow",
                                                                 #Si only Tracks
                                                                 #UpperTracksName = "Si_Cosmic_TracksUp",
                                                                 #LowerTracksName = "Si_Cosmic_TracksLow",
                                                                 #Not need yet
                                                                 #TrackSplitter         =  TrackSplitterTool,
                                                                 OutputLevel = ERROR )   
    ToolSvc += InDetAlignMonTrackSegments_TRTUpLow
    InDetAlignMonTrackSegments_PixSCT = IDAlignMonTrackSegments ( name = "InDetAlignMonTrackSegments_PixSCT",
                                                               InputTracksName =  InDetKeys.Tracks(),
                                                               #Combined Tracks
                                                               UpperTracksName = InDetKeys.PixelTracks(),
                                                               LowerTracksName = InDetKeys.SCTTracks(),
                                                               #Si only Tracks
                                                               #UpperTracksName = "Si_Cosmic_TracksUp",
                                                               #LowerTracksName = "Si_Cosmic_TracksLow",
                                                               #Not need yet
                                                               #TrackSplitter         =  TrackSplitterTool,
                                                               OutputLevel = ERROR )
    if InDetFlags.doCTBTracking():
        InDetAlignMonTrackSegments_PixSCT.UpperTracksName = InDetKeys.PixelTracks_CTB()
        InDetAlignMonTrackSegments_PixSCT.LowerTracksName = InDetKeys.SCTTracks_CTB()
    ToolSvc += InDetAlignMonTrackSegments_PixSCT
    InDetAlignMonTrackSegments_PixTRT = IDAlignMonTrackSegments ( name = "InDetAlignMonTrackSegments_PixTRT",
                                                               InputTracksName =  InDetKeys.Tracks(),
                                                               #Combined Tracks
                                                               UpperTracksName = InDetKeys.PixelTracks(),
                                                               LowerTracksName = InDetKeys.TRTTracks(),
                                                               #Si only Tracks
                                                               #UpperTracksName = "Si_Cosmic_TracksUp",
                                                               #LowerTracksName = "Si_Cosmic_TracksLow", #Not need yet
                                                               #TrackSplitter         =  TrackSplitterTool,
                                                               OutputLevel = ERROR )   
    if InDetFlags.doCTBTracking():
        InDetAlignMonTrackSegments_PixTRT.UpperTracksName = InDetKeys.PixelTracks_CTB()
        InDetAlignMonTrackSegments_PixTRT.LowerTracksName = InDetKeys.TRTTracks_CTB()
    ToolSvc += InDetAlignMonTrackSegments_PixTRT
    InDetAlignMonTrackSegments_SCTTRT = IDAlignMonTrackSegments ( name = "InDetAlignMonTrackSegments_SCTTRT",
                                                               InputTracksName =  InDetKeys.Tracks(),
                                                               #Combined Tracks
                                                               UpperTracksName = InDetKeys.SCTTracks(),
                                                               LowerTracksName = InDetKeys.TRTTracks(),
                                                               #Si only Tracks
                                                               #UpperTracksName = "Si_Cosmic_TracksUp",
                                                               #LowerTracksName = "Si_Cosmic_TracksLow",
                                                               #Not need yet
                                                               #TrackSplitter         =  TrackSplitterTool,
                                                               OutputLevel = ERROR )
    if InDetFlags.doCTBTracking():
        InDetAlignMonTrackSegments_SCTTRT.UpperTracksName = InDetKeys.SCTTracks_CTB()
        InDetAlignMonTrackSegments_SCTTRT.LowerTracksName = InDetKeys.TRTTracks_CTB()
    ToolSvc += InDetAlignMonTrackSegments_SCTTRT
    InDetAlignMonTrackSegments_SiUpLow = IDAlignMonTrackSegments ( name = "InDetAlignMonTrackSegments_SiUpLow",
                                                                InputTracksName =  InDetKeys.Tracks(),
                                                                #Combined Tracks
                                                                #UpperTracksName = "InDetCosmic_TracksUp",
                                                                #LowerTracksName = "InDetCosmic_TracksLow",
                                                                #Si only Tracks
                                                                UpperTracksName = "Si_Cosmic_TracksUp",
                                                                LowerTracksName = "Si_Cosmic_TracksLow",
                                                                #Not need yet
                                                                #TrackSplitter         =  TrackSplitterTool,
                                                                OutputLevel = ERROR )    
    ToolSvc += InDetAlignMonTrackSegments_SiUpLow


## only do trigger-aware monitoring if monTrigDecTool known by ToolSvc
#if DQMonFlags.useTrigger():
#    if not hasattr(ToolSvc, DQMonFlags.nameTrigDecTool()):
#        print "InDetAlignmentMonitoring_InDetRec_jobOptions.py: trigger decision tool not found, including it now"
if not hasattr(ToolSvc, 'monTrigDecTool'):
    print "InDetAlignmentMonitoring_InDetRec_jobOptions.py: trigger decision tool not found: don't run trigger-aware monitoring"  
elif jobproperties.Beam.beamType()=='cosmics' or jobproperties.Beam.beamType()=='singlebeam':
    print "InDetAlignmentMonitoring_InDetRec_jobOptions.py: cosmics or singlebeam beamType: don't run trigger-aware monitoring"
else:
    InDetAlignMonSivsTRT = IDAlignMonSivsTRT (name = "InDetAlignMonSivsTRT")
    InDetAlignMonResiduals = IDAlignMonResiduals (name = "InDetAlignMonResiduals",
                                                  trackSelection = InDetAlignMonTrackSelectionTool,
                                                  tracksName = InDetKeys.ExtendedTracks(),
                                                  Pixel_Manager = InDetKeys.PixelManager(),
                                                  SCT_Manager = InDetKeys.SCT_Manager(),
                                                  TRT_Manager = InDetKeys.TRT_Manager())   
    InDetAlignMonEfficiencies = IDAlignMonEfficiencies (name = "InDetAlignMonEfficiencies",
                                                        trackSelection = InDetAlignMonTrackSelectionTool,
                                                        tracksName = InDetKeys.ExtendedTracks(),
                                                        HoleSearch = InDetAlignMonHoleSearch,
                                                        Pixel_Manager = InDetKeys.PixelManager(),
                                                        SCT_Manager = InDetKeys.SCT_Manager(),
                                                        TRT_Manager = InDetKeys.TRT_Manager())    
    InDetAlignMonGenericTracks = IDAlignMonGenericTracks (name = "InDetAlignMonGenericTracks",
                                                          trackSelection = InDetAlignMonTrackSelectionTool,
                                                          tracksName = InDetKeys.ExtendedTracks(),
                                                          VxPrimContainerName = InDetKeys.PrimaryVertices())
    InDetAlignMonBeamSpot = InDetAlignMonBeamSpot (name = "InDetAlignMonBeamSpot",
                                                  vxContainerName = InDetKeys.PrimaryVertices(),
                                                  vxContainerWithBeamConstraint = InDetFlags.useBeamConstraint())

    ###########################
    InDetAlignMonSivsTRT.TrigDecisionTool         = monTrigDecTool
    InDetAlignMonResiduals.TrigDecisionTool       = monTrigDecTool
    InDetAlignMonEfficiencies.TrigDecisionTool    = monTrigDecTool
    InDetAlignMonGenericTracks.TrigDecisionTool   = monTrigDecTool
    InDetAlignMonBeamSpot.TrigDecisionTool         = monTrigDecTool
    ###########################
    InDetAlignMonSivsTRT.TriggerChain             = "J_minpt"
    InDetAlignMonResiduals.TriggerChain           = "J_minpt"
    InDetAlignMonEfficiencies.TriggerChain        = "J_minpt"
    InDetAlignMonGenericTracks.TriggerChain       = "J_minpt"
    InDetAlignMonBeamSpot.TriggerChain             = "J_minpt"
    ###########################
    InDetAlignMonSivsTRT.triggerChainName             = "Jet_MinBias_Trigger"
    InDetAlignMonResiduals.triggerChainName           = "Jet_MinBias_Trigger"
    InDetAlignMonEfficiencies.triggerChainName        = "Jet_MinBias_Trigger"
    InDetAlignMonGenericTracks.triggerChainName       = "Jet_MinBias_Trigger"
    InDetAlignMonBeamSpot.histFolder                   = "IDAlignMon/BeamSpot/Jet_MinBias_Trigger"
    ###########################
    ToolSvc += InDetAlignMonResiduals
    if (InDetFlags.doPrintConfigurables()):
        print InDetAlignMonResiduals
    ToolSvc += InDetAlignMonEfficiencies
    if (InDetFlags.doPrintConfigurables()):
        print InDetAlignMonEfficiencies
    ToolSvc += InDetAlignMonGenericTracks
    if (InDetFlags.doPrintConfigurables()):
        print InDetAlignMonGenericTracks
    ToolSvc += InDetAlignMonBeamSpot
    if (InDetFlags.doPrintConfigurables()):
        print InDetAlignMonBeamSpot
    ToolSvc += InDetAlignMonSivsTRT
    if (InDetFlags.doPrintConfigurables()):
        print InDetAlignMonSivsTRT
    ###########################


      
## add an AthenaMonManager algorithm to the list of algorithms to be ran
#from DataQualityTools.DQMonFlags import DQMonFlags
from AthenaMonitoring.DQMonFlags import DQMonFlags
from AthenaMonitoring.AthenaMonitoringConf import AthenaMonManager
InDetAlignMonManager = AthenaMonManager( name = "InDetAlignMonManager",
                                      FileKey = DQMonFlags.monManFileKey(),
                                      ManualDataTypeSetup = DQMonFlags.monManManualDataTypeSetup(),
                                      DataType            = DQMonFlags.monManDataType(),
                                      Environment         = DQMonFlags.monManEnvironment(),
                                      ManualRunLBSetup    = DQMonFlags.monManManualRunLBSetup(),
                                      Run                 = DQMonFlags.monManRun(),
                                      LumiBlock           = DQMonFlags.monManLumiBlock())
if jobproperties.Beam.beamType()=='cosmics':
    InDetAlignMonManager.DataType="cosmics"
    InDetAlignMonManager.AthenaMonTools += [ InDetAlignMonTrackSegments_TRTUpLow ]
    InDetAlignMonManager.AthenaMonTools += [ InDetAlignMonTrackSegments_PixSCT ]
    InDetAlignMonManager.AthenaMonTools += [ InDetAlignMonTrackSegments_PixTRT ]
    InDetAlignMonManager.AthenaMonTools += [ InDetAlignMonTrackSegments_SCTTRT ]
    InDetAlignMonManager.AthenaMonTools += [ InDetAlignMonTrackSegments_SiUpLow ]
elif jobproperties.Beam.beamType()=='collisions':
    InDetAlignMonManager.AthenaMonTools += [ InDetAlignMonSivsTRT_noTrig ]
    InDetAlignMonManager.AthenaMonTools += [ InDetAlignMonBeamSpot_noTrig ]
InDetAlignMonManager.AthenaMonTools += [ InDetAlignMonResiduals_noTrig ]
InDetAlignMonManager.AthenaMonTools += [ InDetAlignMonEfficiencies_noTrig ]
InDetAlignMonManager.AthenaMonTools += [ InDetAlignMonGenericTracks_noTrig ]


if InDetAlignMonDoTruth:
    InDetAlignMonManager.AthenaMonTools += [ InDetAlignMonTruthComparison ]
if not hasattr(ToolSvc, 'monTrigDecTool'):
    print "InDetAlignmentMonitoring_InDetRec_jobOptions.py: trigger decision tool not found: don't run trigger-aware monitoring" 
elif jobproperties.Beam.beamType()=='cosmics' or jobproperties.Beam.beamType()=='singlebeam':
    print "singlebeam or cosmics: don't run trigger-aware monitoring"
else:
    InDetAlignMonManager.AthenaMonTools += [ InDetAlignMonResiduals ]
    InDetAlignMonManager.AthenaMonTools += [ InDetAlignMonEfficiencies ]
    InDetAlignMonManager.AthenaMonTools += [ InDetAlignMonGenericTracks ]
    InDetAlignMonManager.AthenaMonTools += [ InDetAlignMonBeamSpot ]
    InDetAlignMonManager.AthenaMonTools += [ InDetAlignMonSivsTRT ]

## Setup the output histogram file(s):
if not hasattr(ServiceMgr, 'THistSvc'):
    from GaudiSvc.GaudiSvcConf import THistSvc
    ServiceMgr += THistSvc()
if InDetAlignMonDoOutput:
    THistSvc = Service( "THistSvc" )
    histOutput = "IDAlignMon DATAFILE='./IDAlignMon.root' OPT='RECREATE'"
    THistSvc.Output += [histOutput]
    InDetAlignMonManager.FileKey = "IDAlignMon"

topSequence += InDetAlignMonManager
if (InDetFlags.doPrintConfigurables()):
    print InDetAlignMonManager
