#--------------------------------------------------------------
#-- Job Options for TRT_Monitoring
#--------------------------------------------------------------
from AthenaMonitoring.DQMonFlags import DQMonFlags
from AthenaCommon.AthenaCommonFlags import athenaCommonFlags

#-------------------------------------------------------------
# Configure tools used by TRT_ConditionsSummaryTool
#-------------------------------------------------------------
from TRT_ConditionsTools.TRT_ConditionsToolsConf import TRT_ConditionsTestTool
MyTRT_ConditionsTestTool = TRT_ConditionsTestTool(
                                                   name='TRT_ConditionsTestTool')
ToolSvc += MyTRT_ConditionsTestTool
if (InDetFlags.doPrintConfigurables()):
  print MyTRT_ConditionsTestTool

#-------------------------------------------------------------
# Condifgure TRT_ConditionsSummaryTool
#-------------------------------------------------------------
from TRT_ConditionsTools.TRT_ConditionsToolsConf import TRT_ConditionsSummaryTool
MyTRT_ConditionsSummaryTool = TRT_ConditionsSummaryTool(
                                                         name     = 'TRT_ConditionsSummaryTool',
                                                         ToolList = [ MyTRT_ConditionsTestTool ])
ToolSvc += MyTRT_ConditionsSummaryTool
if (InDetFlags.doPrintConfigurables()):
  print MyTRT_ConditionsSummaryTool

#-------------------------------------------------------------
# Barrel Monitoring
#-------------------------------------------------------------
from TRT_Monitoring.TRT_MonitoringConf import TRT_Barrel_Monitoring_Tool
TRT_Barrel_Monitoring_Tool = TRT_Barrel_Monitoring_Tool (
                                                          name                         = "TRT_Barrel_Monitoring_Tool",
                                                          TRTRawDataObjectName         = "TRT_RDOs",
                                                          NumberOfEvents               = -1,
                                                          TRTTracksObjectName          = InDetKeys.TRTTracks(),
                                                          TrkSummaryTool               = InDetTrackSummaryTool,
                                                          #Geo_Summary_Provider         = debug,
                                                          #Rdo_BarrelStack_Provider     = expert,
                                                          #Rdo_Barrel_Provider          = shift,
                                                          #Rdo_BarrelCos_Provider       = shift,
                                                          #Track_Barrel_Provider        = shift,
                                                          #Track_BarrelDiag_Provider    = debug,
                                                          #Track_BarrelStack_Provider   = expet,
                                                          #Track_BarrelColl_Provider    = shift,
                                                          #Track_BarrelCos_Provider     = shift,
                                                          Map_Path                     = "../maps/",
                                                          #Map_Path                     = "../InnerDetector/InDetMonitoring/TRT_Monitoring/TRT_Monitoring-00-04-28/maps/",
                                                          #../InnerDetector/InDetMonitoring/TRT_Monitoring-00-04-21/maps/BARREL_C.dat
                                                          #../InnerDetector/InDetMonitoring/TRT_Monitoring-00-04-21/maps/BARREL_C.dat
                                                          #../InnerDetector/InDetMonitoring/TRT_Monitoring/TRT_Monitoring-00-04-21/maps/BARREL_C.dat
                                                          #../InnerDetector/InDetMonitoring/TRT_Monitoring/TRT_Monitoring-00-04-21/maps/
                                                          LE_TimeWindow_MIN            = 0,   #can be 0,1,or 2
                                                          LE_TimeWindow_MAX            = 24,  #can be 1,2 .. 24
                                                          LL_TimeWindow_MIN            = 0,   #can be 0,1,or 2
                                                          LL_TimeWindow_MAX            = 24,  #can be 1,2 .. 24
                                                          HL_TimeWindow_MIN            = 0,   #can be 0,1,or 2
                                                          HL_TimeWindow_MAX            = 3,   #can be 1,2,or 3
                                                          MIN_N_LL_Hits                = 10,  #default=10
                                                          MIN_TOT_Hits                 = 2,
                                                          NoiseSuppressionLevel_30pc   = False,
                                                          NoiseSuppressionMap          = False,
                                                          Debug                        = False,
                                                          maxDistToStraw               = 2.0,
                                                          DistanceToStraw              = 0.4,
                                                          LongToTCut                   = 9.375,
                                                          is_TRT_only_tracks           = True,
                                                          is_zero_mag_field            = True,
                                                          #Histogram Switches
                                                          doAside                      = True,
                                                          doCside                      = True,
                                                          doStraws                     = True,
                                                          doChips                      = True,
                                                          doShift                      = True,
                                                          doDiagnostic                 = True,
                                                          DoRDOsMon                    = True,
                                                          DoGeoMon                     = False,
                                                          DoTracksMon                  = True,
                                                          doExpert                     = athenaCommonFlags.isOnline())
if InDetFlags.doCTBTracking():
  TRT_Barrel_Monitoring_Tool.TRTTracksObjectName = InDetKeys.TRTTracks_CTB()
  
ToolSvc += TRT_Barrel_Monitoring_Tool
if (InDetFlags.doPrintConfigurables()):
     print TRT_Barrel_Monitoring_Tool

#-------------------------------------------------------------
# End Cap Monitoring
#-------------------------------------------------------------
from TRT_Monitoring.TRT_MonitoringConf import TRT_EndCap_Monitoring_Tool
TRT_EndCap_Monitoring_Tool = TRT_EndCap_Monitoring_Tool (
                                                         name                              = "TRT_EndCap_Monitoring_Tool",
                                                         DoRDOsMon                         = True,
                                                         DoGeoMon                          = False,
                                                         TRTRawDataObjectName              = "TRT_RDOs",
                                                         NumberOfEvents                    = -1,
                                                         DoTracksMon                       = True,
                                                         TRTTracksObjectName               = InDetKeys.TRTTracks(),
                                                         TrkSummaryTool                    = InDetTrackSummaryTool,
                                                         #Geo_Summary_Provider              = debug,
                                                         #Rdo_EndCapStack_Provider          = expert,
                                                         #Rdo_EndCap_Provider               = shift,
                                                         #Rdo_EndCapCos_Provider            = shift,
                                                         #Track_EndCap_Provider             = shift,
                                                         #Track_EndCapDiag_Provider         = debug,
                                                         #Track_EndCapStack_Provider        = expert,
                                                         #Track_EndCapColl_Provider         = shift,
                                                         #Track_EndCapCos_Provider          = shift,
                                                         Map_Path                          ="../maps/",
                                                         #Map_Path                           = "../InnerDetector/InDetMonitoring/TRT_Monitoring/TRT_Monitoring-00-04-21/maps/",
                                                         LE_TimeWindow_MIN                 = 0,   #can be 0,1,or 2
                                                         LE_TimeWindow_MAX                 = 24,  #can be 1,2 .. 24
                                                         LL_TimeWindow_MIN                 = 0,   #can be 0,1,or 2
                                                         LL_TimeWindow_MAX                 = 24,  #can be 1,2 .. 24
                                                         HL_TimeWindow_MIN                 = 0,   #can be 0,1,or 2
                                                         HL_TimeWindow_MAX                 = 3,   #can be 1,2,or 3
                                                         MIN_N_LL_Hits                     = 10,  #default=10
                                                         MIN_TOT_Hits                      = 2,
                                                         NoiseSuppressionLevel_30pc        = False,
                                                         NoiseSuppressionMap               = False,
                                                         Debug                             = False,

                                                         maxDistToStraw                    = 2.0,
                                                         DistanceToStraw                   = 0.4,
                                                         LongToTCut                        = 9.375,
                                                         is_TRT_only_tracks                = True,
                                                         is_zero_mag_field                 = True,

                                                         #Histogram Switches
                                                         doAside                           = True,
                                                         doCside                           = True,
                                                         doStraws                          = True,
                                                         doChips                           = True,
                                                         doExpert                          = athenaCommonFlags.isOnline(),
                                                         doShift                           = True,
                                                         doDiagnostic                      = True)
if InDetFlags.doCTBTracking():
  TRT_EndCap_Monitoring_Tool.TRTTracksObjectName = InDetKeys.TRTTracks_CTB()
  
ToolSvc += TRT_EndCap_Monitoring_Tool
if (InDetFlags.doPrintConfigurables()):
     print TRT_EndCap_Monitoring_Tool

#-------------------------------------------------------------
# add an AthenaMonManager algorithm to the list of algorithms to be ran
#-------------------------------------------------------------
from AthenaMonitoring.AthenaMonitoringConf import AthenaMonManager
TRTMonMan                     = AthenaMonManager( "TRTMonManager" )
TRTMonMan.FileKey             = DQMonFlags.monManFileKey()#"GLOBAL" #"stat"
TRTMonMan.ManualDataTypeSetup = DQMonFlags.monManManualDataTypeSetup()#True
TRTMonMan.DataType            = DQMonFlags.monManDataType()#"cosmics"
TRTMonMan.Environment         = DQMonFlags.monManEnvironment()#"user"
TRTMonMan.ManualRunLBSetup    = DQMonFlags.monManManualRunLBSetup()#True
TRTMonMan.Run                 = DQMonFlags.monManRun()#1
TRTMonMan.LumiBlock           = DQMonFlags.monManLumiBlock()#1
TRTMonMan.AthenaMonTools      = [ TRT_Barrel_Monitoring_Tool, TRT_EndCap_Monitoring_Tool ]
topSequence += TRTMonMan
if (InDetFlags.doPrintConfigurables()):
  print TRTMonMan
