#--------------------------------------------------------------
#
#
# InDetExample driving joboptions
#
#
#--------------------------------------------------------------

#--------------------------------------------------------------
# load ServiceMgr, ToolSvc, topSequence
#--------------------------------------------------------------

from AthenaCommon.AppMgr import theApp
from AthenaCommon.AppMgr import ServiceMgr
#
from AthenaCommon.AlgSequence import AlgSequence
topSequence = AlgSequence()
#
from AthenaCommon.AppMgr import ToolSvc

#--------------------------------------------------------------
# activate (memory/cpu) performance monitoring 
#--------------------------------------------------------------

if InDetFlags.doPerfMon():
  from PerfMonComps.PerfMonFlags import jobproperties
  jobproperties.PerfMonFlags.doMonitoring = True

#--------------------------------------------------------------
# change MessageSvc 
#--------------------------------------------------------------

# output level
ServiceMgr.MessageSvc.OutputLevel  = OutputLevel
# increase the number of letter reserved to the alg/tool name from 18 to 30
ServiceMgr.MessageSvc.Format       = "% F%40W%S%7W%R%T %0W%M"
# to change the default limit on number of message
ServiceMgr.MessageSvc.defaultLimit = 9999999  # all messages

#--------------------------------------------------------------
# Load POOL support, setup for reconstruction
#--------------------------------------------------------------

# --- GeoModel
from AtlasGeoModel import SetGeometryVersion
from AtlasGeoModel import GeoModelInit
# --- setup POOL access in ATHENA
if globalflags.InputFormat() == 'bytestream':
  # set up service
  include( "ByteStreamCnvSvc/BSEventStorageEventSelector_jobOptions.py" )
  # configure converters, including cabling
  include("InDetRecExample/InDetReadBS_jobOptions.py")
else:
  # set up pool reading
  import AthenaPoolCnvSvc.ReadAthenaPool

# ---- Beam Spot service
include("InDetBeamSpotService/BeamCondSvc.py")
# --- need MagneticField
include("BFieldAth/BFieldAth_jobOptions.py")
# --- particle property service
include("PartPropSvc/PartPropSvc.py")
# --- if truth, get corresponding POOL converters
if InDetFlags.doTruth():
  include("GeneratorObjectsAthenaPool/GeneratorObjectsAthenaPool_joboptions.py")

#------------------------------------------------------------
# Event Data Model Monitor
#------------------------------------------------------------

if doEdmMonitor:
  from TrkValAlgs.TrkValAlgsConf import Trk__EventDataModelMonitor
  InDetEdmMonitor = Trk__EventDataModelMonitor (name = 'InDetEdmMonitor')
  topSequence += InDetEdmMonitor
  if (InDetFlags.doPrintConfigurables()):
    print          InDetEdmMonitor

#--------------------------------------------------------------
# Load Inner Detector reconstruction
#--------------------------------------------------------------

if not (('doWriteBS' in dir() and doWriteBS)):
  include( "InDetRecExample/InDetRec_jobOptions.py" )

#--------------------------------------------------------------
# Load Inner Detector Monitoring, use the data quality flags for steering
#--------------------------------------------------------------
if InDetFlags.doMonitoringGlobal() or InDetFlags.doMonitoringPixel() or InDetFlags.doMonitoringSCT() or InDetFlags.doMonitoringTRT() or InDetFlags.doMonitoringAlignment():
  if not hasattr(ServiceMgr, 'THistSvc'):
      from GaudiSvc.GaudiSvcConf import THistSvc
      ServiceMgr += THistSvc()
  from AthenaMonitoring.DQMonFlags import DQMonFlags
  DQMonFlags.monManFileKey             = "GLOBAL"
  DQMonFlags.monManManualDataTypeSetup = True
  DQMonFlags.monManManualRunLBSetup    = True
  DQMonFlags.monManDataType            = "monteCarlo"
  DQMonFlags.monManEnvironment         = "user"
  DQMonFlags.monManRun                 = 1
  DQMonFlags.monManLumiBlock           = 1
  ServiceMgr.THistSvc.Output += [ DQMonFlags.monManFileKey()+" DATAFILE='monitoring.root' OPT='RECREATE'" ]
  include( "InDetRecExample/InDetMonitoring.py" )

# ------------------------------------------------------------
# switch off history service and no dump
# ------------------------------------------------------------

ServiceMgr.StoreGateSvc.ActivateHistory = False
ServiceMgr.StoreGateSvc.Dump            = False

# ------------------------------------------------------------
# get stack dump
# ------------------------------------------------------------

gbl.AthenaServices.SetFatalHandler(438)

#--------------------------------------------------------------
# run JiveXML for Atlantis event display
#--------------------------------------------------------------

if doJiveXML:
  include ("JiveXML/JiveXML_jobOptionBase.py")
  include ("JiveXML/DataTypes_InDet.py")
  if InDetFlags.doTruth():
    readG3 = False
    include ("JiveXML/DataTypes_Truth.py")
  
#--------------------------------------------------------------
# run VP1 (virtual point 1) event display
#--------------------------------------------------------------

if doVP1:
  from VP1Algs.VP1AlgsConf import VP1Alg
  topSequence += VP1Alg()

# ------------------------------------------------------------
# Use auditors
# ------------------------------------------------------------

if doAuditors:
  # --- load AuditorSvc
  from AthenaCommon.ConfigurableDb import getConfigurable
  # --- write out summary of the memory usage
  #   | number of events to be skip to detect memory leak
  #   | 20 is default. May need to be made larger for complete jobs.
  ServiceMgr.AuditorSvc += getConfigurable("ChronoAuditor")()
  # --- memory auditors
  MemStatAuditor = getConfigurable("MemStatAuditor")()
  MemStatAuditor.OutputLevel = WARNING
  ServiceMgr.AuditorSvc += MemStatAuditor
  # --- write out a short message upon entering or leaving each algorithm
  if doNameAuditor:
    ServiceMgr.AuditorSvc += getConfigurable("NameAuditor")()
  #
  theApp.AuditAlgorithms = True
  theApp.AuditServices   = True
  #  
  # --- Display detailed size and timing statistics for writing and reading
  if doWriteESD or doWriteAOD or ('doCopyRDO' in dir() and doCopyRDO):
    ServiceMgr.AthenaPoolCnvSvc.UseDetailChronoStat = True

# ------------------------------------------------------------
# write BS 
# ------------------------------------------------------------

if 'doWriteBS' in dir() and doWriteBS:
  # --- load writing BS file
  include ("InDetRecExample/InDetWriteBS_jobOptions.py")
  
# ------------------------------------------------------------
# persistency
# ------------------------------------------------------------

if doWriteESD or doWriteAOD or ('doCopyRDO' in dir() and doCopyRDO):
  # --- load setup
  from AthenaPoolCnvSvc.WriteAthenaPool import AthenaPoolOutputStream
  # --- check dictionary
  ServiceMgr.AthenaSealSvc.CheckDictionary = True
  # --- commit interval (test)
  ServiceMgr.AthenaPoolCnvSvc.CommitInterval = 10
  
  if doWriteESD:
    # --- create stream
    StreamESD            = AthenaPoolOutputStream ( "StreamESD" )
    StreamESD.OutputFile = "InDetRecESD.root"
    # --- save MC collection if truth turned on
    if InDetFlags.doTruth():
      StreamESD.ItemList += ["McEventCollection#*"]
    # ---- load list of objects
    include ( "InDetRecExample/WriteInDetESD.py" )
      
  if doWriteAOD:
    # --- create stream
    StreamAOD            = AthenaPoolOutputStream ( "StreamAOD" )
    StreamAOD.OutputFile = "InDetRecAOD.root"
    # --- save MC collection if truth turned on
    if InDetFlags.doTruth():
      StreamAOD.ItemList += ["McEventCollection#*"]
    # --- load list of objects
    include ( "InDetRecExample/WriteInDetAOD.py" )
  
  if 'doCopyRDO' in dir() and doCopyRDO:
    # --- create stream
    StreamRDO            = AthenaPoolOutputStream ( "StreamRDO" )
    StreamRDO.OutputFile = "InDetRecRDO.root"
    # --- add output to list
    StreamRDO.ItemList   +=  ['TRT_RDO_Container#*','SCT_RDO_Container#*','PixelRDO_Container#*']
    StreamRDO.ItemList   +=  ['InDetSimDataCollection#*','McEventCollection#*']
    # --- Force read
    StreamRDO.ForceRead  = TRUE;  #force read of output data objs
