# minPt cut for the trt stand alone tracking (it differs from ID tracking) 
TRTStandAloneMinPtCut = 1. * GeV 
#
# ----------- TRT Segment finding
#
# TRT seed maker
#
if not InDetFlags.doCosmics():
  from TRT_TrackSegmentsTool_xk.TRT_TrackSegmentsTool_xkConf import InDet__TRT_TrackSegmentsMaker_ATLxk
  InDetTRT_TrackSegmentsMakerTRT = InDet__TRT_TrackSegmentsMaker_ATLxk(name                    = 'InDetTRT_SeedsMakerTRT',
                                                                       TrtManagerLocation      = InDetKeys.TRT_Manager(),
                                                                       TRT_ClustersContainer   = InDetKeys.TRT_DriftCircles(),
                                                                       MagneticFieldMode       = 'MapSolenoid',
                                                                       MagneticTool            = InDetPatternMagField,
                                                                       PropagatorTool          = InDetPatternPropagator,
                                                                       TrackExtensionTool      = InDetTRTExtensionTool,
                                                                       RemoveNoiseDriftCircles = InDetFlags.removeTRTNoise(),
                                                                       UseAssosiationTool      = False,
                                                                       MinNumberDriftCircles   = 20,
                                                                       pTmin                   = TRTStandAloneMinPtCut) #InDetCutValues.minPT())
  ToolSvc += InDetTRT_TrackSegmentsMakerTRT
  if (InDetFlags.doPrintConfigurables()):
    print      InDetTRT_TrackSegmentsMakerTRT

else:
  #
  # cosmics barrel segments
  #
  from TRT_TrackSegmentsTool_xk.TRT_TrackSegmentsTool_xkConf import InDet__TRT_TrackSegmentsMaker_BarrelCosmics
  InDetTRT_TrackSegmentsMaker_BarrelCosmics = InDet__TRT_TrackSegmentsMaker_BarrelCosmics(name= 'InDetTRTSegmentsMaker_BarrelCosmics',
                                                                                          IsMagneticFieldOn=InDetFlags.solenoidOn(),
                                                                                          MinimalNumberOfTRTHits=20)
  
  ToolSvc += InDetTRT_TrackSegmentsMaker_BarrelCosmics 
  if (InDetFlags.doPrintConfigurables()):
    print      InDetTRT_TrackSegmentsMaker_BarrelCosmics 


#
# TRT track reconstruction
#
from TRT_TrackSegmentsFinder.TRT_TrackSegmentsFinderConf import InDet__TRT_TrackSegmentsFinder
InDetTRT_TrackSegmentsFinderTRT = InDet__TRT_TrackSegmentsFinder(name              = 'InDetTRT_TrackSegmentsFinderTRT')

if not InDetFlags.doCosmics():
  InDetTRT_TrackSegmentsFinderTRT.SegmentsLocation  = InDetKeys.TRT_SegmentsTRT()
  InDetTRT_TrackSegmentsFinderTRT.SegmentsMakerTool = InDetTRT_TrackSegmentsMakerTRT
else:
  InDetTRT_TrackSegmentsFinderTRT.SegmentsLocation  = "TRT_Segments_BarrelCosmics"
  InDetTRT_TrackSegmentsFinderTRT.SegmentsMakerTool = InDetTRT_TrackSegmentsMaker_BarrelCosmics
  
topSequence += InDetTRT_TrackSegmentsFinderTRT
if (InDetFlags.doPrintConfigurables()):
  print          InDetTRT_TrackSegmentsFinderTRT


#
# set up special Scoring Tool for standalone TRT tracks (could reuse the one from standalone ...)
#
from InDetTrackScoringTools.InDetTrackScoringToolsConf import InDet__InDetTrtTrackScoringTool
InDetTRT_StandaloneScoringToolTRT = InDet__InDetTrtTrackScoringTool(name            = 'InDetTRT_StandaloneScoringToolTRT',
                                                                    SummaryTool     = InDetTrackSummaryTool,
                                                                    useAmbigFcn     = True,
                                                                    useSigmaChi2    = False,
                                                                    maxEta          = 2.1,
                                                                    PtMin           = 0.5*GeV,
                                                                    minTRTonTrk     = 20)
ToolSvc += InDetTRT_StandaloneScoringToolTRT
if (InDetFlags.doPrintConfigurables()):
  print      InDetTRT_StandaloneScoringToolTRT

#
# TRT standalone tracks algorithm
#
if not InDetFlags.doCosmics():
  from TRT_StandaloneTrackFinder.TRT_StandaloneTrackFinderConf import InDet__TRT_StandaloneTrackFinder
  InDetTRT_StandaloneTrackFinderTRT = InDet__TRT_StandaloneTrackFinder(name                  = 'InDetTRT_StandaloneTrackFinderTRT',
                                                                       RefitterTool          = InDetTrackFitterTRT,
                                                                       ScoringTool           = InDetTRT_StandaloneScoringToolTRT,
                                                                       Extrapolator          = InDetExtrapolator,
                                                                       FinalRefit            = True,
                                                                       UseAssociationTool    = True,
                                                                       MinNumDriftCircles    = 20,
                                                                       MaxSharedHitsFraction = InDetCutValues.maxTRTonlyShared(),
                                                                       InputSegmentsLocation = InDetKeys.TRT_SegmentsTRT(),
                                                                       OutputTracksLocation  = InDetKeys.TRTTracks(),
                                                                       SuppressHoleSearch    = True)
  topSequence += InDetTRT_StandaloneTrackFinderTRT
  if (InDetFlags.doPrintConfigurables()):
    print          InDetTRT_StandaloneTrackFinderTRT

else: 
  from TRT_SegmentsToTrack.TRT_SegmentsToTrackConf import InDet__TRT_SegmentsToTrack
  InDetTrkSegmenttoTrk=InDet__TRT_SegmentsToTrack(name="InDetTRT_SegmentsToTrack_Barrel",
                                                  OutputTrackCollection = "SegmentTracks_BarrelCosmics_NewT",
                                                  InputSegmentsCollection = "TRT_Segments_BarrelCosmics",
                                                  TrackFitter=InDetTrackFitter,
                                                  MinNHit = InDetCutValues.minTRTonTrkCosmics(),
                                                  InputSCTCollection = "",
                                                  MaterialEffects=False) # does not yet work properly
  
  topSequence += InDetTrkSegmenttoTrk
  if (InDetFlags.doPrintConfigurables()):
      print InDetTrkSegmenttoTrk


if InDetFlags.doCosmics():
    #
    # cosmic track segments for EC
    #
    # run EC standalone only if not already run in CTB tracking
    if not InDetFlags.doCTBTracking():
      from TRT_TrackSegmentsTool_xk.TRT_TrackSegmentsTool_xkConf import InDet__TRT_TrackSegmentsMaker_ECcosmics
      InDetTRT_TrackSegmentsMaker_EC = InDet__TRT_TrackSegmentsMaker_ECcosmics(name= 'InDetTRTSegmentsMaker_EC',
                                                                               ToTCutLoose=9,
                                                                               ToTCutTight=15.,
                                                                               ToTCutUpper=40.,
                                                                               ScaleFactorTube=4.,
                                                                               MinDCperSeed = 7,
                                                                               UseDriftTime=False,
                                                                               TRT_ClustersContainer=InDetKeys.TRT_DriftCircles() )
      
      
      ToolSvc += InDetTRT_TrackSegmentsMaker_EC
      if (InDetFlags.doPrintConfigurables()):
        print      InDetTRT_TrackSegmentsMaker_EC
        
      from TRT_TrackSegmentsFinder.TRT_TrackSegmentsFinderConf import InDet__TRT_TrackSegmentsFinder
      InDetTRT_TrackSegmentsFinder_EC = InDet__TRT_TrackSegmentsFinder(name              = 'InDetTRTSegmentsFinder_EC',
                                                                       SegmentsLocation  = "TRT_Segments_EC",
                                                                       SegmentsMakerTool = InDetTRT_TrackSegmentsMaker_EC)
      topSequence += InDetTRT_TrackSegmentsFinder_EC
      if (InDetFlags.doPrintConfigurables()):
        print          InDetTRT_TrackSegmentsFinder_EC

    #
    # now merge the NewT cosmic barrel segments with the EC ones
    from TRT_SegmentsToTrack.TRT_SegmentsToTrackConf import InDet__TRT_SegmentsToTrack
    InDetTrkSegmenttoTrk_EC_NewT=InDet__TRT_SegmentsToTrack(name="InDetTRT_SegmentsToTrack_Endcap_NewT",
                                                            OutputTrackCollection = "SegmentTracks_EC_NewT",
                                                            BarrelEndcapTracks = "SegmentTracks_Combined_Barrel_EC_NewT",
                                                            OutputCombiCollection = "notused_EC_TRT",
                                                            InputSegmentsCollection = "TRT_Segments_EC",
                                                            InputSCTCollection = "",
                                                            TrackFitter = InDetTrackFitter,
                                                            MinNHit = InDetCutValues.minTRTonTrkCosmics(),
                                                            CombineSegments = True,
                                                            BarrelSegments = "TRT_Segments_BarrelCosmics",
                                                            EndcapSegments = "TRT_Segments_EC",
                                                            MaterialEffects = False) # does not yet work properly
    
    topSequence += InDetTrkSegmenttoTrk_EC_NewT
    if (InDetFlags.doPrintConfigurables()):
      print InDetTrkSegmenttoTrk_EC_NewT
        

    # ambiguity-solve the cosmic TRT only tracks into one output collection
    from TrkAmbiguitySolver.TrkAmbiguitySolverConf import Trk__TrkAmbiguitySolver
    InDetAmbiguitySolver_TRTStandaloneTRT = Trk__TrkAmbiguitySolver(name               = 'InDetAmbiguitySolver_TRTStandaloneTRT',
                                                                 TrackInput         = [ "SegmentTracks_BarrelCosmics_NewT",
                                                                                        "SegmentTracks_EC_NewT",
                                                                                        "SegmentTracks_Combined_Barrel_EC_NewT" ],
                                                                 TrackOutput        = InDetKeys.TRTTracks(),
                                                                 AmbiguityProcessor = InDetAmbiguityProcessorCosmics)
    
    topSequence += InDetAmbiguitySolver_TRTStandaloneTRT
    if (InDetFlags.doPrintConfigurables()):
      print          InDetAmbiguitySolver_TRTStandaloneTRT
    

#
#
# ------------ Track truth.
#
if InDetFlags.doTruth():
    #
    # set collection name for truth
    #
    TRTStandaloneTRTTracksTruth           = "TRTStandaloneTRTTracksTruthCollection"
    DetailedTRTStandaloneTRTTracksTruth   = "TRTStandaloneTRTTracksDetailedTruth"       
    #
    # set up the truth info for this container
    #
    include ("InDetRecExample/ConfiguredInDetTrackTruth.py")
    InDetTracksTruth = ConfiguredInDetTrackTruth(InDetKeys.TRTTracks(),
                                                 DetailedTRTStandaloneTRTTracksTruth,
                                                 TRTStandaloneTRTTracksTruth)
    #
    # add final output for statistics
    #
    TrackCollectionKeys      += [ InDetKeys.TRTTracks() ]
    TrackCollectionTruthKeys += [ TRTStandaloneTRTTracksTruth ]

