# ------------------------------------------------------------
#
# ----------- 2nd iteration, outside in tracking
#
# ------------------------------------------------------------

#
# ---------- TRT Seeded Tracking
#
if InDetFlags.doTRTSeededTrackFinder():
   #
   # TRT seeded space points seed maker
   #
   if InDetFlags.loadTRTSeededSPFinder():
      from TRT_SeededSpacePointFinderTool.TRT_SeededSpacePointFinderToolConf import InDet__TRT_SeededSpacePointFinder_ATL
      InDetTRT_SeededSpacePointFinder =  InDet__TRT_SeededSpacePointFinder_ATL(name                   = 'InDetTRT_SeededSpFinder'  ,
                                                                               MagneticTool           = InDetPatternMagField       ,
                                                                               SpacePointsSCTName     = InDetKeys.SCT_SpacePoints(),
                                                                               SpacePointsOverlapName = InDetKeys.OverlapSpacePoints(),
                                                                               AssociationTool        = InDetPrdAssociationTool    ,
                                                                               UseAssociationTool     = InDetFlags.doNewTracking(), # use association tool if forward tracking
                                                                               NeighborSearch         = True,
                                                                               LoadFull               = False,
                                                                               DoCosmics              = InDetFlags.doCosmics())

   elif InDetFlags.loadSimpleTRTSeededSPFinder():
      from RegionSelector.RegSelSvcDefault import RegSelSvcDefault
      InDetRegSelSvc = RegSelSvcDefault()
      ServiceMgr += InDetRegSelSvc
      if (InDetFlags.doPrintConfigurables()):
        print         InDetRegSelSvc
      from TRT_SeededSpacePointFinderTool.TRT_SeededSpacePointFinderToolConf import InDet__SimpleTRT_SeededSpacePointFinder_ATL
      InDetTRT_SeededSpacePointFinder =  InDet__SimpleTRT_SeededSpacePointFinder_ATL(name                   = 'InDetTRT_SeededSpFinder'  ,
                                                                                     SpacePointsSCTName     = InDetKeys.SCT_SpacePoints(),
                                                                                     SpacePointsOverlapName = InDetKeys.OverlapSpacePoints(),
                                                                                     PerigeeCut             = 1000.,
                                                                                     DirectionPhiCut        = .3,
                                                                                     DirectionEtaCut        = 1.,
                                                                                     MaxHoles               = 2,
                                                                                     AssociationTool        = InDetPrdAssociationTool,
                                                                                     RestrictROI            = True)
   # if new tracking is off then no association tool is to be used!
   if not InDetFlags.doNewTracking():
      InDetTRT_SeededSpacePointFinder.AssociationTool = None 
   
   ToolSvc += InDetTRT_SeededSpacePointFinder
   if (InDetFlags.doPrintConfigurables()):
     print      InDetTRT_SeededSpacePointFinder
   #
   # Silicon det elements road maker tool
   #
   from SiDetElementsRoadTool_xk.SiDetElementsRoadTool_xkConf import InDet__SiDetElementsRoadMaker_xk
   InDetTRT_SeededSiRoadMaker = InDet__SiDetElementsRoadMaker_xk(name               = 'InDetTRT_SeededSiRoad'  ,
                                                                 PropagatorTool     = InDetPatternPropagator   ,
                                                                 MagneticTool       = InDetPatternMagField     ,
                                                                 PixManagerLocation = InDetKeys.PixelManager() ,
                                                                 SCTManagerLocation = InDetKeys.SCT_Manager()  ,
                                                                 RoadWidth          = 35.,
                                                                 MaxStep            = 20.)                       # NOT DEFAULT ?
   if InDetFlags.doCosmics():
      InDetTRT_SeededSiRoadMaker.RoadWidth = 50
      
   ToolSvc += InDetTRT_SeededSiRoadMaker
   if (InDetFlags.doPrintConfigurables()):
     print      InDetTRT_SeededSiRoadMaker
   #
   # TRT seeded back tracking tool
   #
   from TRT_SeededTrackFinderTool.TRT_SeededTrackFinderToolConf import InDet__TRT_SeededTrackFinder_ATL
   InDetTRT_SeededTrackTool =  InDet__TRT_SeededTrackFinder_ATL(name                     = 'InDetTRT_SeededTrackMaker',
                                                                MagneticTool             = InDetPatternMagField,
                                                                PropagatorTool           = InDetPatternPropagator,
                                                                UpdatorTool              = InDetPatternUpdator,
                                                                RoadTool                 = InDetTRT_SeededSiRoadMaker,
                                                                SeedTool                 = InDetTRT_SeededSpacePointFinder,
                                                                CombinatorialTrackFinder = InDetSiComTrackFinder,
                                                                pTmin                    = InDetCutValues.minPT(),
                                                                ConsistentSeeds          = True,
                                                                #BremCorrection           = True,
                                                                BremCorrection           = False,
                                                                UseAssociationTool       = InDetFlags.doNewTracking())
   if InDetFlags.doCosmics():
      InDetTRT_SeededTrackTool.pTmin = InDetCutValues.minPTCosmics()
      InDetTRT_SeededTrackTool.nWClustersMin            = 0
      InDetTRT_SeededTrackTool.nHolesMax                = 3
      InDetTRT_SeededTrackTool.nHolesGapMax             = 2
      InDetTRT_SeededTrackTool.Xi2max                   = 30.0
      InDetTRT_SeededTrackTool.Xi2maxNoAdd              = 60.0
      
   ToolSvc   += InDetTRT_SeededTrackTool
   if (InDetFlags.doPrintConfigurables()):
     print        InDetTRT_SeededTrackTool
   #
   # Output key for the finder
   #
   OutputSiExtendedTracks = "TRTSeededTracks"
   #
   # TRT seeded back tracking algorithm
   #
   from TRT_SeededTrackFinder.TRT_SeededTrackFinderConf import InDet__TRT_SeededTrackFinder
   InDetTRT_SeededTrackFinder = InDet__TRT_SeededTrackFinder(name                  = 'InDetTRT_SeededTrackFinder',
                                                             RefitterTool          = InDetTrackFitter,
                                                             TrackTool             = InDetTRT_SeededTrackTool,
                                                             TrackExtensionTool    = InDetTRTExtensionTool,
                                                             TrtExtension          = True,
                                                             FinalRefit            = False,
                                                             FinalStatistics       = False,
                                                             OutputSegments        = False,
                                                             InputSegmentsLocation = InDetKeys.TRT_Segments(),
                                                             OutputTracksLocation  = OutputSiExtendedTracks)
   if InDetFlags.doCosmics():
      InDetTRT_SeededTrackFinder.InputSegmentsLocation = "TRT_Segments_BarrelCosmics_TRTstandalone"
      InDetTRT_SeededTrackFinder.TrackExtensionTool = InDetTRTExtensionToolCosmics
      
   #InDetTRT_SeededTrackFinder.OutputLevel = VERBOSE
   topSequence += InDetTRT_SeededTrackFinder
   if (InDetFlags.doPrintConfigurables()):
     print          InDetTRT_SeededTrackFinder
   #
   #
   # ------------ Track truth.
   #
   if InDetFlags.doTruth():
      #
      # set collection name for truth
      #
      SiExtendedTracksTruth     = "TRTSeededTracksTruthCollection"
      DetailedSiExtendedTruth   = "TRTSeededTracksDetailedTruth"       
      #
      # set up the truth info for this container
      #
      include ("InDetRecExample/ConfiguredInDetTrackTruth.py")
      InDetTracksTruth = ConfiguredInDetTrackTruth(OutputSiExtendedTracks,
                                                   DetailedSiExtendedTruth,
                                                   SiExtendedTracksTruth)
      #
      # add final output for statistics
      #
      TrackCollectionKeys      += [ OutputSiExtendedTracks ]
      TrackCollectionTruthKeys += [ SiExtendedTracksTruth ]

if InDetFlags.doResolveBackTracks():
   #
   # set up special Scoring Tool for TRT seeded tracks
   #
   if not InDetFlags.doCosmics():
      from InDetTrackScoringTools.InDetTrackScoringToolsConf import InDet__InDetAmbiScoringTool
      InDetTRT_SeededScoringTool = InDet__InDetAmbiScoringTool(name               = 'InDetTRT_SeededScoringTool',
                                                               Extrapolator       = InDetExtrapolator,
                                                               SummaryTool        = InDetTrackSummaryTool,
                                                               useTRT_AmbigFcn    = InDetFlags.doNewTracking(),
                                                               useAmbigFcn        = not InDetFlags.doNewTracking(),
                                                               minPt              = InDetCutValues.minPT(),
                                                               maxRPhiImp         = InDetCutValues.maxSecondaryImpact(),
                                                               maxZImp            = InDetCutValues.maxZImpact(),
                                                               maxEta             = InDetCutValues.maxEta(),
                                                               minSiClusters      = InDetCutValues.minSecondaryClusters(),
                                                               maxSiHoles         = InDetCutValues.maxSecondaryHoles(),
                                                               maxDoubleHoles     = InDetCutValues.maxSecondaryDoubleHoles(),
                                                               minTRTonTrk        = InDetCutValues.minSecondaryTRTonTrk(),
                                                               useSigmaChi2       = False) # do not use it
      
      ToolSvc += InDetTRT_SeededScoringTool
      if (InDetFlags.doPrintConfigurables()):
         print      InDetTRT_SeededScoringTool
      
   #
   # Load selection tool
   #
   from InDetAmbiTrackSelectionTool.InDetAmbiTrackSelectionToolConf import InDet__InDetAmbiTrackSelectionTool
   InDetTRT_SeededAmbiTrackSelectionTool = InDet__InDetAmbiTrackSelectionTool(name                = 'InDetTRT_SeededAmbiTrackSelectionTool',
                                                                              AssociationTool     =  InDetPrdAssociationTool,
                                                                              minScoreShareTracks = -1., # off !
                                                                              minHits             = InDetCutValues.minSecondaryClusters(),
                                                                              minNotShared        = InDetCutValues.minSecondarySiNotShared(),
                                                                              maxShared           = InDetCutValues.maxSecondaryShared(),
                                                                              minTRTHits          = InDetCutValues.minSecondaryTRTonTrk())
   if InDetFlags.doCosmics():
      InDetTRT_SeededAmbiTrackSelectionTool.Cosmics = True
      
   ToolSvc += InDetTRT_SeededAmbiTrackSelectionTool
   if (InDetFlags.doPrintConfigurables()):
     print      InDetTRT_SeededAmbiTrackSelectionTool
   #
   # load Ambiguity Processor
   #
   from TrkAmbiguityProcessor.TrkAmbiguityProcessorConf import Trk__SimpleAmbiguityProcessorTool
   InDetTRT_SeededAmbiguityProcessor = Trk__SimpleAmbiguityProcessorTool(name               = 'InDetTRT_SeededAmbiguityProcessor',
                                                                         Fitter             = InDetTrackFitter,          
                                                                         SelectionTool      = InDetTRT_SeededAmbiTrackSelectionTool,
                                                                         RefitPrds          = not InDetFlags.refitROT(),
                                                                         SuppressTrackFit   = False,
                                                                         SuppressHoleSearch = False)
   if not InDetFlags.doCosmics():
      InDetTRT_SeededAmbiguityProcessor.ScoringTool        = InDetTRT_SeededScoringTool
   else:
      InDetTRT_SeededAmbiguityProcessor.ScoringTool        = InDetScoringToolCosmics_TRT
      
   if InDetFlags.materialInteractions():
      InDetTRT_SeededAmbiguityProcessor.MatEffects = 3
   else:
      InDetTRT_SeededAmbiguityProcessor.MatEffects = 0
   #
   ToolSvc += InDetTRT_SeededAmbiguityProcessor
   if (InDetFlags.doPrintConfigurables()):
     print      InDetTRT_SeededAmbiguityProcessor
   #
   # load the algorithm
   #
   ResolvedSiExtendedTracks = "ResolvedTRTSeededTracks"
   #
   from TrkAmbiguitySolver.TrkAmbiguitySolverConf import Trk__TrkAmbiguitySolver
   InDetTRT_SeededAmbiguitySolver = Trk__TrkAmbiguitySolver(name               = 'InDetTRT_SeededAmbiguitySolver',
                                                            TrackInput         = [ OutputSiExtendedTracks ],
                                                            TrackOutput        = ResolvedSiExtendedTracks,
                                                            AmbiguityProcessor = InDetTRT_SeededAmbiguityProcessor)
   topSequence += InDetTRT_SeededAmbiguitySolver
   if (InDetFlags.doPrintConfigurables()):
     print          InDetTRT_SeededAmbiguitySolver
   #
   # ------------ Track truth.
   #
   if InDetFlags.doTruth():
      #
      # set collection name for truth
      #
      ResolvedSiExtendedTracksTruth   = "ResolvedTRTSeededTracksTruthCollection"
      ResolvedDetailedSiExtendedTruth = "ResolvedTRTSeededTracksDetailedTruth"       
      #
      # set up the truth info for this container
      #
      include ("InDetRecExample/ConfiguredInDetTrackTruth.py")
      InDetTracksTruth = ConfiguredInDetTrackTruth(ResolvedSiExtendedTracks,
                                                   ResolvedDetailedSiExtendedTruth,
                                                   ResolvedSiExtendedTracksTruth)
      #
      # add final output for statistics
      #
      TrackCollectionKeys      += [ ResolvedSiExtendedTracks ]
      TrackCollectionTruthKeys += [ ResolvedSiExtendedTracksTruth ]

