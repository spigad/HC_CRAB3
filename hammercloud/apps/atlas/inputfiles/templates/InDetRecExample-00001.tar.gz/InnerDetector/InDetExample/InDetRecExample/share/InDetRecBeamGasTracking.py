# ------------------------------------------------------------
#
# ----------- now we do the RTF tracking
#
# ------------------------------------------------------------
#
# get list of already associated hits (always do this, even if no other tracking ran before)
#
from InDetTrackPRD_Association.InDetTrackPRD_AssociationConf import InDet__InDetTrackPRD_Association
InDetBeamGasPRD_Association = InDet__InDetTrackPRD_Association(name            = 'InDetBeamGasPRD_Association',
                                                               AssociationTool = InDetPrdAssociationTool,
                                                               TracksName      = list(InputCombinedInDetTracks)) 
topSequence += InDetBeamGasPRD_Association
if (InDetFlags.doPrintConfigurables()):
  print          InDetBeamGasPRD_Association

#
# ----------- SiSPSeededTrackFinder for low momentum tracks
#
if InDetFlags.doSiSPSeededTrackFinder():
   #
   # Space points seeds maker
   #
   from SiSpacePointsSeedTool_xk.SiSpacePointsSeedTool_xkConf import InDet__SiSpacePointsSeedMaker_BeamGas
   InDetSiSpacePointsSeedMakerBeamGas = InDet__SiSpacePointsSeedMaker_BeamGas(name                   = 'InDetSpSeedsMakerBeamGas',
                                                                                MagneticTool           = InDetPatternMagField,
                                                                                pTmin                  = InDetCutValues.minBeamGasPT(),
                                                                                maxdImpact             = InDetCutValues.maxPrimaryImpactBeamGas(),
                                                                                maxZ                   = InDetCutValues.maxZImpactBeamGas(),
                                                                                minZ                   = -InDetCutValues.maxZImpactBeamGas(),
                                                                                SpacePointsPixelName   = InDetKeys.PixelSpacePoints(),
                                                                                SpacePointsSCTName     = InDetKeys.SCT_SpacePoints(),
                                                                                SpacePointsOverlapName = InDetKeys.OverlapSpacePoints(),
                                                                                UseAssociationTool     = True,
                                                                                AssociationTool        = InDetPrdAssociationTool)
   ToolSvc += InDetSiSpacePointsSeedMakerBeamGas
   if (InDetFlags.doPrintConfigurables()):
     print      InDetSiSpacePointsSeedMakerBeamGas

   #
   # Local track finding using space point seed
   #
   from SiTrackMakerTool_xk.SiTrackMakerTool_xkConf import InDet__SiTrackMaker_xk
   InDetSiTrackMakerBeamGas = InDet__SiTrackMaker_xk(name                     = 'InDetSiTrackMakerBeamGas',
                                                     MagneticTool             = InDetPatternMagField,
                                                     RoadTool                 = InDetSiDetElementsRoadMaker,
                                                     CombinatorialTrackFinder = InDetSiComTrackFinder,
                                                     pTmin                    = InDetCutValues.minBeamGasPT(),
                                                     nClustersMin             = 3, # was InDetCutValues.minClustersBeamGas(),
                                                     nWeightedClustersMin     = 6, # and this is new
                                                     nHolesMax                = InDetCutValues.maxHolesBeamGas(),
                                                     nHolesGapMax             = 2, # was 2
                                                     SeedsFilterLevel         = 2,
                                                     UseAssociationTool       = True)

   ToolSvc += InDetSiTrackMakerBeamGas
   if (InDetFlags.doPrintConfigurables()):
     print      InDetSiTrackMakerBeamGas
   
   #
   # set output track collection name
   OutputTrackCollection = "SiSPSeededTracksBeamGas"
   
   #
   # Setup Track finder using space points seeds
   #
   from SiSPSeededTrackFinder.SiSPSeededTrackFinderConf import InDet__SiSPSeededTrackFinder
   InDetSiSPSeededTrackFinderBeamGas = InDet__SiSPSeededTrackFinder(name           = 'InDetSiSpTrackFinderBeamGas',
                                                                  SeedsTool      = InDetSiSpacePointsSeedMakerBeamGas,
                                                                  ZvertexTool    = None, 
                                                                  TrackTool      = InDetSiTrackMakerBeamGas,
                                                                  TracksLocation = OutputTrackCollection,
                                                                  useZvertexTool = False)
   topSequence += InDetSiSPSeededTrackFinderBeamGas
   if (InDetFlags.doPrintConfigurables()):
     print          InDetSiSPSeededTrackFinderBeamGas

   #
   # set input collection for next algorithm
   #
   InputTrackCollection = OutputTrackCollection
    
   if InDetFlags.doTruth():
      #
      # set collection name for truth
      #
      InputTrackCollectionTruth = "SiSPSeededTracksBeamGasTruthCollection"
      InputDetailedTrackTruth   = "SiSPSeededTracksBeamGasDetailedTruth"
      #
      # set up the truth info for this container
      #
      include ("InDetRecExample/ConfiguredInDetTrackTruth.py")
      InDetTracksTruth = ConfiguredInDetTrackTruth(InputTrackCollection,
                                                   InputDetailedTrackTruth,
                                                   InputTrackCollectionTruth)
      #
      # add final output for statistics
      #
      TrackCollectionKeys      += [ InputTrackCollection ]
      TrackCollectionTruthKeys += [ InputTrackCollectionTruth ]
#
# ---------- Ambiguity solving
#
if InDetFlags.doAmbiSolving():
   #
   # load InnerDetector TrackSelectionTool
   #
   ## This is currently the same as NewTracking version, but may need lowPt tuning.
   from InDetAmbiTrackSelectionTool.InDetAmbiTrackSelectionToolConf import InDet__InDetAmbiTrackSelectionTool
   InDetAmbiTrackSelectionToolBeamGas = InDet__InDetAmbiTrackSelectionTool(name            = 'InDetAmbiTrackSelectionToolBeamGas',
                                                                         AssociationTool = InDetPrdAssociationTool,
                                                                         minHits         = InDetCutValues.minClustersBeamGas(),
                                                                         minNotShared    = InDetCutValues.minSiNotShared(),
                                                                         maxShared       = InDetCutValues.maxShared(),
                                                                         minTRTHits      = 0 ) # used for Si only tracking !!!
   ToolSvc += InDetAmbiTrackSelectionToolBeamGas
   if (InDetFlags.doPrintConfigurables()):
     print      InDetAmbiTrackSelectionToolBeamGas
   #
   # set up Scoring Tool
   #
   from InDetTrackScoringTools.InDetTrackScoringToolsConf import InDet__InDetAmbiScoringTool
   InDetAmbiScoringToolBeamGas = InDet__InDetAmbiScoringTool(name           = 'InDetAmbiScoringToolBeamGas',
                                                           Extrapolator   = InDetExtrapolator,
                                                           SummaryTool    = InDetTrackSummaryTool,
                                                           useAmbigFcn    = True,
                                                           useTRT_AmbigFcn= False,
                                                           minPt          = InDetCutValues.minBeamGasPT(),
                                                           maxRPhiImp     = InDetCutValues.maxPrimaryImpactBeamGas(),
                                                           maxZImp        = InDetCutValues.maxZImpactBeamGas(),
                                                           maxEta         = InDetCutValues.maxEta(),
                                                           minSiClusters  = InDetCutValues.minClustersBeamGas(),
                                                           maxSiHoles     = InDetCutValues.maxHolesBeamGas(),
                                                           maxDoubleHoles = InDetCutValues.maxDoubleHoles(),
                                                           minTRTonTrk    = 0,    # no TRT here
                                                           useSigmaChi2   = True) # Thijs turn it off
                                                           # useSigmaChi2   = True) # use it for Si only
   #InDetAmbiScoringToolBeamGas.OutputLevel = VERBOSE
   ToolSvc += InDetAmbiScoringToolBeamGas
   if (InDetFlags.doPrintConfigurables()):
     print      InDetAmbiScoringToolBeamGas
   #
   # load Ambiguity Processor
   #
   from TrkAmbiguityProcessor.TrkAmbiguityProcessorConf import Trk__SimpleAmbiguityProcessorTool
   InDetAmbiguityProcessorBeamGas = Trk__SimpleAmbiguityProcessorTool(name          = 'InDetAmbiguityProcessorBeamGas',
                                                                    ScoringTool   = InDetAmbiScoringToolBeamGas,
                                                                    Fitter        = InDetTrackFitter,
                                                                    SelectionTool = InDetAmbiTrackSelectionToolBeamGas,
                                                                    RefitPrds     = not InDetFlags.refitROT())
   if InDetFlags.materialInteractions():
      InDetAmbiguityProcessorBeamGas.MatEffects = 3
   else:
      InDetAmbiguityProcessorBeamGas.MatEffects = 0

   ToolSvc += InDetAmbiguityProcessorBeamGas
   if (InDetFlags.doPrintConfigurables()):
     print      InDetAmbiguityProcessorBeamGas
   #
   # set output track name
   #
   OutputTrackCollection = "ResolvedTracksBeamGas"
   #
   # configure Ambiguity solver
   #
   from TrkAmbiguitySolver.TrkAmbiguitySolverConf import Trk__TrkAmbiguitySolver
   InDetAmbiguitySolverBeamGas = Trk__TrkAmbiguitySolver(name               = 'InDetAmbiguitySolverBeamGas',
                                                       TrackInput         = [ InputTrackCollection ],
                                                       TrackOutput        = OutputTrackCollection,
                                                       AmbiguityProcessor = InDetAmbiguityProcessorBeamGas)
   topSequence += InDetAmbiguitySolverBeamGas
   if (InDetFlags.doPrintConfigurables()):
     print          InDetAmbiguitySolverBeamGas

   #
   # Input of the next algorithm
   #
   InputTrackCollection = OutputTrackCollection

   if InDetFlags.doTruth():
      #
      # set collection name for truth
      #
      InputTrackCollectionTruth = "ResolvedTracksBeamGasTruthCollection"
      InputDetailedTrackTruth   = "ResolvedTracksBeamGasDetailedTruth"      
      #
      # set up the truth info for this container
      #
      include ("InDetRecExample/ConfiguredInDetTrackTruth.py")
      InDetTracksTruth = ConfiguredInDetTrackTruth(InputTrackCollection,
                                                   InputDetailedTrackTruth,
                                                   InputTrackCollectionTruth)
      #
      # add final output for statistics
      #
      TrackCollectionKeys      += [ InputTrackCollection ]
      TrackCollectionTruthKeys += [ InputTrackCollectionTruth ]

   # output track collection
   BeamGasTrackCollection = InputTrackCollection

#    
# ---------- TRT_TrackExtension
#
if InDetFlags.doTRTExtension():
      
   #
   # Track extension to TRT algorithm
   #
   # set output extension map name
   OutputExtendedTracks = "ExtendedTracksMapBeamGas"
   #
   from TRT_TrackExtensionAlg.TRT_TrackExtensionAlgConf import InDet__TRT_TrackExtensionAlg
   InDetTRTExtensionBeamGas = InDet__TRT_TrackExtensionAlg (name                   = 'InDetTRT_ExtensionBeamGas',
                                                          TrackExtensionTool     = InDetTRTExtensionTool,
                                                          InputTracksLocation    = InputTrackCollection,
                                                          ExtendedTracksLocation = OutputExtendedTracks   )
   topSequence += InDetTRTExtensionBeamGas
   if (InDetFlags.doPrintConfigurables()):
     print          InDetTRTExtensionBeamGas
   
#
# ------------ Track Extension Processor
#
if InDetFlags.doExtensionProcessor():
   
   if InDetFlags.trtExtensionType() is 'DAF' :
      #
      # DAF Fitter setup
      #
      from TrkCompetingRIOsOnTrackTool.TrkCompetingRIOsOnTrackToolConf import Trk__CompetingRIOsOnTrackTool
      InDetCompetingRotCreatorBeamGas =  Trk__CompetingRIOsOnTrackTool( name                        = 'InDetCompetingRotCreatorBeamGas',
                                                                      ToolForCompPixelClusters    = None,      # default
                                                                      ToolForCompSCT_Clusters     = None,      # default
                                                                      ToolForCompTRT_DriftCircles = InDetCompetingTRT_DC_Tool )
      ToolSvc += InDetCompetingRotCreatorBeamGas
      if (InDetFlags.doPrintConfigurables()):
        print      InDetCompetingRotCreatorBeamGas
      #
      from TrkDeterministicAnnealingFilter.TrkDeterministicAnnealingFilterConf import Trk__DeterministicAnnealingFilter
      InDetExtensionFitterBeamGas =  Trk__DeterministicAnnealingFilter( name = 'InDetDAFBeamGas',
                                                                              ToolForExtrapolation           = InDetExtrapolator,
                                                                              ToolForCompetingROTsCreation   = InDetCompetingRotCreatorBeamGas,
                                                                              ToolForUpdating                = InDetPatternUpdator,
                                                                              AnnealingScheme                = [200., 81., 9., 4., 1., 1., 1.],
                                                                              DropOutlierCutValue            = 1.E-7,
                                                                              OutlierCutValue                = 0.01 )
      ToolSvc += InDetExtensionFitterBeamGas
      if (InDetFlags.doPrintConfigurables()):
        print      InDetExtensionFitterBeamGas
   else:
      InDetExtensionFitterBeamGas = InDetTrackFitter
   #
   # load scoring for extension
   #
   from InDetTrackScoringTools.InDetTrackScoringToolsConf import InDet__InDetAmbiScoringTool
   InDetExtenScoringToolBeamGas = InDet__InDetAmbiScoringTool(name           = 'InDetExtenScoringToolBeamGas',
                                                       Extrapolator   = InDetExtrapolator,
                                                       SummaryTool    = InDetTrackSummaryTool,
                                                       useAmbigFcn    = True,
                                                       useTRT_AmbigFcn= False,
                                                       minPt          = InDetCutValues.minBeamGasPT(),
                                                       maxRPhiImp     = InDetCutValues.maxPrimaryImpactBeamGas(),
                                                       maxZImp        = InDetCutValues.maxZImpactBeamGas(),
                                                       maxEta         = InDetCutValues.maxEta(),
                                                       minSiClusters  = InDetCutValues.minClustersBeamGas(),
                                                       maxSiHoles     = InDetCutValues.maxHolesBeamGas(),
                                                       maxDoubleHoles = InDetCutValues.maxDoubleHoles(),
                                                       minTRTonTrk    = InDetCutValues.minTRTonTrkBeamGas(),
                                                       useSigmaChi2   = False) # do not use it for extension
   ToolSvc += InDetExtenScoringToolBeamGas
   if (InDetFlags.doPrintConfigurables()):
     print      InDetExtenScoringToolBeamGas
   #
   # set output track collection name
   #
   OutputTrackCollection = "ExtendedTracksBeamGas"
   #
   # get configured track extension processor
   #
   from InDetExtensionProcessor.InDetExtensionProcessorConf import InDet__InDetExtensionProcessor   
   InDetExtensionProcessorBeamGas = InDet__InDetExtensionProcessor ( name               = "InDetExtensionProcessorBeamGas",
                                                              TrackName          = InputTrackCollection,
                                                              ExtensionMap       = OutputExtendedTracks,
                                                              NewTrackName       = OutputTrackCollection,
                                                              TrackFitter        = InDetExtensionFitterBeamGas,
                                                              ScoringTool        = InDetExtenScoringToolBeamGas,
                                                              suppressHoleSearch = False,  # does not work properly
                                                              RefitPrds          = not (InDetFlags.refitROT() or (InDetFlags.trtExtensionType() is 'DAF')))
   if InDetFlags.materialInteractions():
      InDetExtensionProcessorBeamGas.matEffects = 3 # default in code is 4!!
   else :
      InDetExtensionProcessorBeamGas.matEffects = 0
   
   topSequence += InDetExtensionProcessorBeamGas
   if (InDetFlags.doPrintConfigurables()):
     print          InDetExtensionProcessorBeamGas
   #
   # and set new input track collection
   #
   InputTrackCollection    = OutputTrackCollection

   #
   # ------------ Track truth.
   #
   if InDetFlags.doTruth():
      #
      # set collection name for truth
      #
      InputTrackCollectionTruth = "ExtendedTracksBeamGasTruthCollection"
      InputDetailedTrackTruth   = "ExtendedTracksBeamGasDetailedTruth"       
      #
      # set up the truth info for this container
      #
      include ("InDetRecExample/ConfiguredInDetTrackTruth.py")
      InDetBeamGasTruth = ConfiguredInDetTrackTruth(InputTrackCollection,
                                                    InputDetailedTrackTruth,
                                                    InputTrackCollectionTruth)
      #
      # add final output for statistics
      #
      TrackCollectionKeys      += [ InputTrackCollection ]
      TrackCollectionTruthKeys += [ InputTrackCollectionTruth ]

   # output track collection
   BeamGasTrackCollection = InputTrackCollection
   
