#######################################################
#                                                     #
# LVL1 & BC ID monitoring - only for real data        #
#                                                     #
#######################################################
from InDetGlobalMonitoring.InDetGlobalMonitoringConf import InDetGlobalSynchMonTool
InDetGlobalSynchMonTool = InDetGlobalSynchMonTool( name          = "InDetGlobalSynchMonTool",
                                                   histoPathBase = "/GLOBAL",
                                                   sct_robs_JO   = 92, # 86, 
                                                   trt_robs_JO   = 192, 
                                                   pix_robs_JO   = 132,
                                                   checkRate     = 2000)
ToolSvc += InDetGlobalSynchMonTool
if (InDetFlags.doPrintConfigurables()):
    print InDetGlobalSynchMonTool

####################################################
#                                                  #
# NOISE OCCUPANCY MONITORING TOOL                  #
#                                                  #
####################################################
from InDetGlobalMonitoring.InDetGlobalMonitoringConf import InDetGlobalNoiseOccupancyMonTool
InDetGlobalNoiseOccupancyMonTool=InDetGlobalNoiseOccupancyMonTool( name          = "InDetGlobalNoiseOccupancyMonTool",
                                                                   checkRate     = 2000,
                                                                   trtMax        = 0.15,
                                                                   sctMax        = 0.003,
                                                                   pixelMax      = 0.0002,
                                                                   doBarrel      = True,
                                                                   doECA         = True,
                                                                   doECC         = True,
                                                                   phiModB       = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31],
                                                                   phiModECA     = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31],
                                                                   phiModECC     = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31],
                                                                   doData        = True)

if jobproperties.Beam.beamType()=='cosmics':
    InDetGlobalNoiseOccupancyMonTool.checkRate = 2000
    InDetGlobalNoiseOccupancyMonTool.trtMax    = 0.1
    InDetGlobalNoiseOccupancyMonTool.sctMax    = 0.001
    InDetGlobalNoiseOccupancyMonTool.pixelMax  = 0.000001

ToolSvc += InDetGlobalNoiseOccupancyMonTool
if (InDetFlags.doPrintConfigurables()):
    print InDetGlobalNoiseOccupancyMonTool

####################################################
#                                                  #
# NUMBER OF HITS AND RESIDUALS MONITORING          #
#                                                  #
####################################################
from InDetGlobalMonitoring.InDetGlobalMonitoringConf import InDetGlobalHitsMonTool
InDetGlobalHitsMonTool=InDetGlobalHitsMonTool( name          ="InDetGlobalHitsMonTool",
                                               #doMC          = False,
                                               #pTMC          = 10000.,
                                               #doOffline     = False,
                                               checkRate     = 2000,
                                               doBarrel      = True,
                                               doECA         = True,
                                               doECC         = True)

ToolSvc += InDetGlobalHitsMonTool
if (InDetFlags.doPrintConfigurables()):
    print InDetGlobalHitsMonTool

##################################################
#                                                #
# TRACK MONITORING                               #
#                                                #
##################################################
from InDetGlobalMonitoring.InDetGlobalMonitoringConf import InDetGlobalTrackMonTool
InDetGlobalTrackMonTool=InDetGlobalTrackMonTool( name          = "InDetGlobalTrackMonTool",
                                                 histoPathBase = "/GLOBAL",
                                                 #doOffline     = True,
                                                 trackMax      = 1000,
                                                 trackBin      = 100,
                                                 d0Max         = 100,
                                                 z0Max         = 2000,
                                                 perEvent      = 100,
                                                 doBarrel      = True,
                                                 doECC         = True,
                                                 doECA         = True,
                                                 checkRate     = 1000,
                                                 isCosmicsRun  = False)

if jobproperties.Beam.beamType()=='cosmics':
    InDetGlobalTrackMonTool.trackMax = 10
    InDetGlobalTrackMonTool.trackBin = 10
    InDetGlobalTrackMonTool.d0Max = 500
    InDetGlobalTrackMonTool.z0Max = 3000
    InDetGlobalTrackMonTool.isCosmicsRun = True

ToolSvc += InDetGlobalTrackMonTool
if (InDetFlags.doPrintConfigurables()):
    print InDetGlobalTrackMonTool

####################################################
#                                                  #
# CLUSTER TOOL                                     #
#                                                  #
####################################################
from InDetGlobalMonitoring.InDetGlobalMonitoringConf import InDetGlobalClusterMonTool
InDetGlobalClusterMonTool=InDetGlobalClusterMonTool( name          = "InDetGlobalClusterMonTool",
                                                     histoPathBase = "/GLOBAL",
                                                     tracks = InDetKeys.UnslimmedTracks(),
                                                     doOffline     = False,
                                                     Detector      = "ID")
if InDetFlags.doCTBTracking():
    InDetGlobalClusterMonTool.tracks = InDetKeys.UnslimmedTracks_CTB()

ToolSvc += InDetGlobalClusterMonTool
if (InDetFlags.doPrintConfigurables()):
    print InDetGlobalClusterMonTool

####################################################
#                                                  #
# InDetGlobalManager top algorithm                 #
#                                                  #
####################################################
from AthenaMonitoring.DQMonFlags import DQMonFlags
from InDetGlobalMonitoring.InDetGlobalMonitoringConf import InDetGlobalManager
InDetGlobalManager=InDetGlobalManager( name                = "InDetGlobalManager",
                                       Extrapolator        = InDetExtrapolator,
                                       Propagator          = InDetPropagator,
                                       TRT_DriftCircleName = InDetKeys.TRT_DriftCircles(),
                                       FileKey             = DQMonFlags.monManFileKey(),
                                       ManualDataTypeSetup = DQMonFlags.monManManualDataTypeSetup(),
                                       ManualRunLBSetup    = DQMonFlags.monManManualRunLBSetup(),
                                       DataType            = DQMonFlags.monManDataType(),
                                       Environment         = DQMonFlags.monManEnvironment(),
                                       Run                 = DQMonFlags.monManRun(),
                                       LumiBlock           = DQMonFlags.monManLumiBlock(),
                                       doTopBottom         =  True,
                                       AthenaMonTools      = [ InDetGlobalSynchMonTool, InDetGlobalNoiseOccupancyMonTool, InDetGlobalHitsMonTool, InDetGlobalTrackMonTool, InDetGlobalClusterMonTool])

if InDetFlags.doCTBTracking():
    InDetGlobalManager.PixelTrackName      = InDetKeys.PixelTracks_CTB()
    InDetGlobalManager.SCTTrackName        = InDetKeys.SCTTracks_CTB()
    InDetGlobalManager.TRTTrackName        = InDetKeys.TRTTracks_CTB()
    InDetGlobalManager.CombinedTrackName   = InDetKeys.UnslimmedTracks_CTB()
else:
    InDetGlobalManager.PixelTrackName      = InDetKeys.PixelTracks()
    InDetGlobalManager.SCTTrackName        = InDetKeys.SCTTracks()
    InDetGlobalManager.TRTTrackName        = InDetKeys.TRTTracks()
    InDetGlobalManager.CombinedTrackName   = InDetKeys.UnslimmedTracks()

topSequence+=InDetGlobalManager
if (InDetFlags.doPrintConfigurables()):
    print InDetGlobalManager
