# Blocking the include for after first inclusion of the InDetFlags.py module
include.block ('InDetRecExample/ConfiguredInDetCutValues.py')

#########################################################################
# InDetCutValues
#########################################################################
# Python Setup Class for InnerDetector reconstruction
#
# Author: Wolfgang.Liebig@cern.ch
#
#########################################################################

import AthenaCommon.SystemOfUnits as Units
class ConfiguredInDetCutValues :

  def __init__ (self,                 
                minPT                   = None,
                minLowPT                = None ,
                maxLowPT                = None,
                maxPrimaryImpact        = None,
                maxZImpact              = None,
                maxEta                  = None,
                minClusters             = None,
                minClustersLowPt        = None,
                minSiNotShared          = None,
                maxShared               = None,
                maxHoles                = None,
                maxHolesLowPt           = None,
                maxDoubleHoles          = None,
                minTRTonTrk             = None,
                maxSecondaryImpact      = None,
                minSecondaryClusters    = None,
                minSecondarySiNotShared = None,
                maxSecondaryShared      = None,
                maxSecondaryHoles       = None,
                maxSecondaryDoubleHoles = None,
                minSecondaryTRTonTrk    = None,
                
                minTRTonly              = None,
                maxTRTonlyShared        = None,
                minTRTonlyMinPt         = None,
                
                minBeamGasPT            = 500,
                maxPrimaryImpactBeamGas = 300,
                maxZImpactBeamGas       = 2000,
                minClustersBeamGas      = 6,
                maxHolesBeamGas         = 3,
                minTRTonTrkBeamGas      = 5,
                
                minPTCosmics            = 500,
                maxPrimaryImpactCosmics = 1000,
                maxZImpactCosmics       = 10000,
                minClustersCosmics      = 4,
                nWeightedClustersMin    = 8,  # 2 * nPixelHits + nSCTHits
                maxHolesCosmics         = 3,
                minTRTonTrkCosmics      = 15): 
      
      from AthenaCommon.GlobalFlags import globalflags
      from AthenaCommon.BeamFlags import jobproperties

      # --- all tracks

      if minPT == None :
          self.__minPT = self.__default_minPT(jobproperties.Beam.numberOfCollisions() >= 10.0)
      else:
          self.__minPT = minPT

      if minLowPT == None :
          self.__minLowPT = 0.100 * Units.GeV
      else:
          self.__minLowPT = minLowPT

      if maxLowPT == None :
          self.__maxLowPT = self.__default_minPT(jobproperties.Beam.numberOfCollisions() >= 10.0) + 0.2 * Units.GeV # some overlap
      else:
          self.__maxLowPT = maxLowPT
          
      if minBeamGasPT == None :
          self.__minBeamGasPT = 0.500 * Units.GeV
      else:
          self.__minBeamGasPT = minBeamGasPT

      if maxZImpact == None :
          self.__maxZImpact = 250. * Units.mm
      else:
          self.__maxZImpact = maxZImpact

      if maxZImpactBeamGas == None :
          self.__maxZImpactBeamGas = 250. * Units.mm
      else:
          self.__maxZImpactBeamGas = maxZImpactBeamGas

      if maxEta == None :
          self.__maxEta = 2.7
      else:
          self.__maxEta = maxEta

      if minClustersLowPt == None :
          self.__minClustersLowPt = 5
      else:
          self.__minClustersLowPt = minClustersLowPt

      if maxHolesLowPt == None :
          self.__maxHolesLowPt = 4
      else:
          self.__maxHolesLowPt = maxHolesLowPt

      if minClustersBeamGas == None :
          self.__minClustersBeamGas = 5
      else:
          self.__minClustersBeamGas = minClustersBeamGas

      if maxHolesBeamGas == None :
          self.__maxHolesBeamGas = 4
      else:
          self.__maxHolesBeamGas = maxHolesBeamGas
      # --- primary tracks

      if maxPrimaryImpact == None :
          self.__maxPrimaryImpact = self.__default_maxPriImpact(jobproperties.Beam.numberOfCollisions() >= 10.0)
      else:
          self.__maxPrimaryImpact = maxPrimaryImpact

      if maxPrimaryImpactBeamGas == None :
          self.__maxPrimaryImpactBeamGas = self.__default_maxPriImpact(jobproperties.Beam.numberOfCollisions() >= 10.0)
      else:
          self.__maxPrimaryImpactBeamGas = maxPrimaryImpactBeamGas

      if minClusters == None :
          self.__minClusters = 7
          from AthenaCommon.DetFlags    import DetFlags
          # set some cut values according to which detectors are on (a bit of a hack for now)
          if ( DetFlags.haveRIO.pixel_on() and not DetFlags.haveRIO.SCT_on() ):
            self.__minClusters = 3
          elif ( DetFlags.haveRIO.SCT_on() and not DetFlags.haveRIO.pixel_on() ):
            self.__minClusters = 6
      else:
          self.__minClusters = minClusters

      if minSiNotShared == None :
          self.__minSiNotShared = 4
      else:
          self.__minSiNotShared = minSiNotShared

      if maxShared == None :
          self.__maxShared = 3
      else:
          self.__maxShared = maxShared

      if maxHoles == None :
          self.__maxHoles = 5
      else:
          self.__maxHoles = maxHoles

      if maxDoubleHoles == None :
          self.__maxDoubleHoles = 2
      else:
          self.__maxDoubleHoles = maxDoubleHoles

      if minTRTonTrk == None :
          self.__minTRTonTrk = 9
      else:
          self.__minTRTonTrk = minTRTonTrk

      if minTRTonTrkBeamGas == None :
          self.__minTRTonTrkBeamGas = 9
      else:
          self.__minTRTonTrkBeamGas = minTRTonTrkBeamGas

      # --- secondary tracks

      if maxSecondaryImpact == None :
          self.__maxSecondaryImpact = self.__default_maxSecImpact(jobproperties.Beam.numberOfCollisions() >= 10.0)
      else:
          self.__maxSecondaryImpact = maxSecondaryImpact

      if minSecondaryClusters == None :
          self.__minSecondaryClusters = 4
      else:
          self.__minSecondaryClusters = minSecondaryClusters

      if minSecondarySiNotShared == None :
          self.__minSecondarySiNotShared = 4
      else:
          self.__minSecondarySiNotShared = minSecondarySiNotShared

      if maxSecondaryShared == None :
          self.__maxSecondaryShared = 2
      else:
          self.__maxSecondaryShared = maxSecondaryShared

      if maxSecondaryHoles == None :
          self.__maxSecondaryHoles = 2
      else:
          self.__maxSecondaryHoles = maxSecondaryHoles

      if maxSecondaryDoubleHoles == None :
          self.__maxSecondaryDoubleHoles = 1
      else:
          self.__maxSecondaryDoubleHoles = maxSecondaryDoubleHoles

      if minSecondaryTRTonTrk == None :
          self.__minSecondaryTRTonTrk = 10
      else:
          self.__minSecondaryTRTonTrk = minSecondaryTRTonTrk

      # --- TRT only

      if minTRTonly == None :
          self.__minTRTonly = 15
      else:
          self.__minTRTonly = minTRTonly

      if maxTRTonlyShared == None :
          self.__maxTRTonlyShared = 0.3
      else:
          self.__maxTRTonlyShared = maxTRTonlyShared

      if minTRTonlyMinPt == None :
          self.__minTRTonlyMinPt = 0.5 * Units.GeV
      else:
          self.__minTRTonlyMinPt = minTRTonlyMinPt

      if minPTCosmics == None :
          self.__minPTCosmics = 0.500 * Units.GeV
      else:
          self.__minPTCosmics = minPTCosmics

      if maxZImpactCosmics == None :
          self.__maxZImpactCosmics = 250. * Units.mm
      else:
          self.__maxZImpactCosmics = maxZImpactCosmics

      if minClustersCosmics == None :
          self.__minClustersCosmics = 5
      else:
          self.__minClustersCosmics = minClustersCosmics

      if nWeightedClustersMin == None :
          self.__nWeightedClustersMin = 8
      else:
          self.__nWeightedClustersMin = nWeightedClustersMin

      if maxHolesCosmics == None :
          self.__maxHolesCosmics = 4
      else:
          self.__maxHolesCosmics = maxHolesCosmics

      if maxPrimaryImpactCosmics == None :
          self.__maxPrimaryImpactCosmics = self.__default_maxPriImpact(jobproperties.Beam.numberOfCollisions() >= 10.0)
      else:
          self.__maxPrimaryImpactCosmics = maxPrimaryImpactCosmics

      if minTRTonTrkCosmics == None :
          self.__minTRTonTrkCosmics = 9
      else:
          self.__minTRTonTrkCosmics = minTRTonTrkCosmics
# ----------------------------------------------------------------------------
# --- private methods !
# ----------------------------------------------------------------------------
  def __default_minPT(self, highlumi):
      if highlumi:   # high lumi
          return 1.0 * Units.GeV
      else:
          return 0.5 * Units.GeV

  def __default_maxPriImpact(self, highlumi):
      if highlumi:
        return  2.0 * Units.mm    # high lumi
      else:          
        return 10.0 * Units.mm    # low lumi

  def __default_maxSecImpact(self, highlumi):
      if highlumi:
          return  20.0 * Units.mm    # high lumi
      else:          
          return 100.0 * Units.mm    # low lumi

# ----------------------------------------------------------------------------
# --- set methods for lumi switch
# ----------------------------------------------------------------------------
  def changeLumi(self, lumiMode) :
      self.__highlumi = (lumiMode == "high")
      self.__minPT              = self.__default_minPT(self.__highlumi)
      self.__maxPrimaryImpact   = self.__default_maxPriImpact(self.__highlumi)
      self.__maxPrimaryImpactBeamGas   = self.__default_maxPriImpact(self.__highlumi)
      self.__maxSecondaryImpact = self.__default_maxSecImpact(self.__highlumi)


# ----------------------------------------------------------------------------
# --- return methods for the cut values - the main purpose of this class
# ----------------------------------------------------------------------------

  def minPT( self ) :
      return self.__minPT

  def minLowPT( self ) :
      return self.__minLowPT

  def maxLowPT( self ) :
      return self.__maxLowPT

  def minBeamGasPT( self ) :
      return self.__minBeamGasPT

  def maxPrimaryImpact( self ) :
      return self.__maxPrimaryImpact

  def maxPrimaryImpactBeamGas( self ) :
      return self.__maxPrimaryImpactBeamGas

  def maxSecondaryImpact( self ) :
      return self.__maxSecondaryImpact

  def maxZImpact( self ) :
      return self.__maxZImpact

  def maxZImpactBeamGas( self ) :
      return self.__maxZImpactBeamGas

  def maxEta( self ) :
      return self.__maxEta

  def minClusters( self ) :
      return self.__minClusters
  
  def minClustersLowPt( self ) :
      return self.__minClustersLowPt

  def minClustersBeamGas( self ) :
      return self.__minClustersBeamGas

  def minSecondaryClusters( self ) :
      return self.__minSecondaryClusters

  def minSiNotShared( self ) :
      return self.__minSiNotShared

  def minSecondarySiNotShared( self ) :
      return self.__minSecondarySiNotShared

  def maxShared( self ) :
      return self.__maxShared

  def maxSecondaryShared( self ) :
      return self.__maxSecondaryShared

  def maxHoles( self ) :
      return self.__maxHoles

  def maxHolesLowPt( self ) :
      return self.__maxHolesLowPt

  def maxHolesBeamGas( self ) :
      return self.__maxHolesBeamGas

  def maxSecondaryHoles( self ) :
      return self.__maxSecondaryHoles

  def maxDoubleHoles( self ) :
      return self.__maxDoubleHoles

  def maxSecondaryDoubleHoles( self ) :
      return self.__maxSecondaryDoubleHoles

  def minTRTonTrk( self ) :
      return self.__minTRTonTrk

  def minTRTonTrkBeamGas( self ) :
      return self.__minTRTonTrkBeamGas

  def minSecondaryTRTonTrk( self ) :
      return self.__minSecondaryTRTonTrk

  def minTRTonly( self ) :
      return self.__minTRTonly

  def maxTRTonlyShared( self ) :
      return self.__maxTRTonlyShared

  def minTRTonlyMinPt( self ) :
      return self.__minTRTonlyMinPt

  def minPTCosmics( self ) :
      return self.__minPTCosmics

  def maxPrimaryImpactCosmics( self ) :
      return self.__maxPrimaryImpactCosmics

  def maxZImpactCosmics( self ) :
      return self.__maxZImpactCosmics

  def minClustersCosmics( self ) :
      return self.__minClustersCosmics

  def nWeightedClustersMin( self ) :
      return self.__nWeightedClustersMin

  def maxHolesCosmics( self ) :
      return self.__maxHolesCosmics

  def minTRTonTrkCosmics( self ) :
      return self.__minTRTonTrkCosmics

  def printInfo( self ) :
    print '****** Inner Detector Track Reconstruction Cuts ************************************'
    print '*'
    print '* min pT                      : ', self.__minPT, ' MeV'
    print '* min pT for low pT tracking  : ', self.__minLowPT, ' MeV'
    print '* max pT for low pT tracking  : ', self.__maxLowPT, ' MeV'
    print '* max Z IP                    : ', self.__maxZImpact, ' mm'
    print '* max eta                     : ', self.__maxEta
    print '*'
    print '* max Rphi IP (primaries)     : ', self.__maxPrimaryImpact, ' mm'
    print '* min number of clusters      :  ', self.__minClusters
    print '* min number of clusters low pT: ', self.__minClustersLowPt
    print '* min number of NOT shared    :  ', self.__minSiNotShared
    print '* max number of shared        :  ', self.__maxShared
    print '* max number of holes         :  ', self.__maxHoles
    print '* max number of holes low pT  :  ', self.__maxHolesLowPt
    print '* max number of double holes  :  ', self.__maxDoubleHoles
    print '* min TRT on track extension  :  ', self.__minTRTonTrk
    print '*'
    print '* max RphiIP (sec. tracks)    :  ', self.__maxSecondaryImpact, ' mm (IPat for now)'
    print '* min number of clusters      :  ', self.__minSecondaryClusters
    print '* min number of NOT shared    :  ', self.__minSecondarySiNotShared
    print '* max number of shared        :  ', self.__maxSecondaryShared
    print '* max number of holes         :  ', self.__maxSecondaryHoles
    print '* max number of double holes  :  ', self.__maxSecondaryDoubleHoles
    print '* min TRT on track            :  ', self.__minSecondaryTRTonTrk
    print '*'  
    print '* min TRT only hits           :  ', self.__minTRTonly
    print '* max TRT shared fraction     :  ', self.__maxTRTonlyShared
    print '* min TRT only min pt         :  ', self.__minTRTonlyMinPt, ' MeV'
    print '*'  
    print '* min pT for BeamGas tracking : ', self.__minBeamGasPT, ' MeV'
    print '* max Rphi IP BeamGas (primaries): ', self.__maxPrimaryImpactBeamGas, ' mm'
    print '* max Z IP BeamGas               : ', self.__maxZImpactBeamGas, ' mm'
    print '* min number of clusters BeamGas: ', self.__minClustersBeamGas
    print '* max number of holes BeamGas :  ', self.__maxHolesBeamGas
    print '* min TRT on track extension BG:  ', self.__minTRTonTrkBeamGas
    
    print '*' 
    print '* min pT for Cosmics tracking : ', self.__minPTCosmics, ' MeV'
    print '* max Rphi IP Cosmics (primaries): ', self.__maxPrimaryImpactCosmics, ' mm'
    print '* max Z IP Cosmics               : ', self.__maxZImpactCosmics, ' mm'
    print '* min number of clusters Cosmics: ', self.__minClustersCosmics
    print '* min number of weighted clusters : ', self.__nWeightedClustersMin
    print '* max number of holes Cosmics :  ', self.__maxHolesCosmics
    print '* min TRT on track extension BG:  ', self.__minTRTonTrkCosmics
    print '*'  
    print '************************************************************************************'

