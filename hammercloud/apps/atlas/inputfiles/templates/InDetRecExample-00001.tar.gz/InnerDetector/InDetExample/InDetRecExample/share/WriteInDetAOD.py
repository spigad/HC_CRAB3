#+++++++++++++++++ Beginning of WriteInDetAOD.py

if not 'InDetKeys' in dir():
   #
   # --- setup StoreGate keys (JobProperties!)
   #
   print "InDetRec_jobOptions: InDetKeys not set before - I import them now"
   from InDetRecExample.InDetKeys import InDetKeys
   #InDetKeys.lock_JobProperties()

InDetAODList = []

# Add Vertices and Particles.
# -----------------------------
InDetAODList+=["VxContainer#"+InDetKeys.PrimaryVertices()]
InDetAODList+=["V0Container#"+InDetKeys.V0Candidates()]
InDetAODList+=["VxContainer#"+InDetKeys.SecVertices()]
InDetAODList+=["VxContainer#"+InDetKeys.Conversions()]
InDetAODList+=["Rec::TrackParticleContainer#"+InDetKeys.TrackParticles()]
InDetAODList+=["TrackParticleTruthCollection#"+InDetKeys.TrackParticlesTruth()]

# if AODall is on the iPat and xKal (if on) are written to ESD/AOD
if InDetFlags.AODall():
   InDetAODList+=["VxContainer#"+InDetKeys.IPatPrimaryVertices()]
   InDetAODList+=["Rec::TrackParticleContainer#"+InDetKeys.IPatParticles()]
   InDetAODList+=["TrackParticleTruthCollection#"+InDetKeys.IPatParticlesTruth()]
   InDetAODList+=["VxContainer#"+InDetKeys.XKalPrimaryVertices()]
   InDetAODList+=["Rec::TrackParticleContainer#"+InDetKeys.XKalParticles()]
   InDetAODList+=["TrackParticleTruthCollection#"+InDetKeys.XKalParticlesTruth()]

# next is only for InDetRecExample stand alone! RecExCommon uses InDetAODList directly
StreamAOD.ItemList += InDetAODList 
#+++++++++++++++++ End of WriteInDetAOD.py
