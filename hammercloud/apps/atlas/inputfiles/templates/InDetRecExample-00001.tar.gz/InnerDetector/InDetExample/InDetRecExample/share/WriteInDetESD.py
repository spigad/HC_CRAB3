#+++++++++++++++++ Beginning of WriteInDetESD.py
# Writes out all InDet ESD Data

if not 'InDetKeys' in dir():
   #
   # --- setup StoreGate keys
   #
   print "InDetRec_jobOptions: InDetKeys not set - setting to defaults"
   from InDetRecExample.InDetKeys import InDetKeys
   #InDetKeys.lock_JobProperties()

InDetESDList = []

# Save BCM rdos:
InDetESDList+=["BCM_RDO_Container#BCM_RDOs"]


# In case of cosmics we save the RDOs as well
if rec.Commissioning():
   InDetESDList+=['PixelRDO_Container#'+InDetKeys.PixelRDOs(),'SCT_RDO_Container#'+InDetKeys.SCT_RDOs(),'TRT_RDO_Container#'+InDetKeys.TRT_RDOs(),
                  'ComTime#TRT_Phase']


# Save PRD.
# ---------
InDetESDList+=["InDet::SCT_ClusterContainer#"+InDetKeys.SCT_Clusters()]
InDetESDList+=["InDet::PixelClusterContainer#"+InDetKeys.PixelClusters()]
InDetESDList+=["InDet::TRT_DriftCircleContainer#"+InDetKeys.TRT_DriftCircles()]

# add tracks
# ----------
#
# this is a hack for validating the NewT Cosmics tracks!!!!
if (InDetFlags.doCosmics() and InDetFlags.doNewTracking() and InDetFlags.doCTBTracking()):
   InDetESDList+=["TrackCollection#"+InDetKeys.UnslimmedTracks()]
   
if InDetKeys.AliasToTracks() == 'none':
   InDetESDList+=["TrackCollection#"+InDetKeys.Tracks()]
else:
   InDetESDList+=["TrackCollection#"+InDetKeys.AliasToTracks()]

if rec.Commissioning():
   InDetESDList+=["TrackCollection#"+InDetKeys.PixelTracks()]
   InDetESDList+=["TrackCollection#"+InDetKeys.SCTTracks()]
   InDetESDList+=["TrackCollection#"+InDetKeys.TRTTracks()]

if InDetFlags.doCTBTracking():
   InDetESDList+=["TrackCollection#"+InDetKeys.PixelTracks_CTB()]
   InDetESDList+=["TrackCollection#"+InDetKeys.SCTTracks_CTB()]
   InDetESDList+=["TrackCollection#"+InDetKeys.TRTTracks_CTB()]
   

# Save PixelGangedAmbiguities
# ---------------------------
InDetESDList+=["InDet::PixelGangedClusterAmbiguities#PixelClusterAmbiguitiesMap"]

# Add TRT Segments (only if standalone is off).
# -----------------
if not InDetFlags.doTRTStandalone():
   InDetESDList+=["Trk::SegmentCollection#"+InDetKeys.TRT_Segments()]

if InDetFlags.doTruth():
    # Save (Detailed) Track Truth
    # ---------------------------
    InDetESDList+=["TrackTruthCollection#"+InDetKeys.TracksTruth()]
    InDetESDList+=["DetailedTrackTruthCollection#"+InDetKeys.DetailedTracksTruth()]

    # save PRD MultiTruth. 
    # --------------------
    InDetESDList+=["PRD_MultiTruthCollection#"+InDetKeys.PixelClustersTruth()] 
    InDetESDList+=["PRD_MultiTruthCollection#"+InDetKeys.SCT_ClustersTruth()]
    InDetESDList+=["PRD_MultiTruthCollection#"+InDetKeys.TRT_DriftCirclesTruth()]

# Add Vertices and Particles.
# -----------------------------
if InDetFlags.doVertexFinding():
    InDetESDList+=["VxContainer#"+InDetKeys.PrimaryVertices()]
if InDetFlags.doV0Finder():
    InDetESDList+=["V0Container#"+InDetKeys.V0Candidates()]
if InDetFlags.doSecVertexFinder():
    InDetESDList+=["VxContainer#"+InDetKeys.SecVertices()]
if InDetFlags.doConversions():
    InDetESDList+=["VxContainer#"+InDetKeys.Conversions()]
if InDetFlags.doParticleCreation():
    InDetESDList+=["Rec::TrackParticleContainer#"+InDetKeys.TrackParticles()]
    if InDetFlags.doTruth():
        InDetESDList+=["TrackParticleTruthCollection#"+InDetKeys.TrackParticlesTruth()]

# if AODall is on the iPat and xKal (if on) are written to ESD/AOD
if InDetFlags.AODall():
    InDetESDList+=["VxContainer#"+InDetKeys.IPatPrimaryVertices()]
    InDetESDList+=["Rec::TrackParticleContainer#"+InDetKeys.IPatParticles()]
    InDetESDList+=["TrackParticleTruthCollection#"+InDetKeys.IPatParticlesTruth()]
    InDetESDList+=["VxContainer#"+InDetKeys.XKalPrimaryVertices()]
    InDetESDList+=["Rec::TrackParticleContainer#"+InDetKeys.XKalParticles()]
    InDetESDList+=["TrackParticleTruthCollection#"+InDetKeys.XKalParticlesTruth()]
    
InDetESDList+=['InDetBSErrContainer#PixelByteStreamErrs']
InDetESDList+=['InDetBSErrContainer#SCT_ByteStreamErrs']
InDetESDList+=['TRT_BSErrContainer#TRT_ByteStreamErrs']
InDetESDList+=['TRT_BSIdErrContainer#TRT_ByteStreamIdErrs']

# next is only for InDetRecExample stand alone! RecExCommon uses InDetESDList directly
StreamESD.ItemList += InDetESDList
#+++++++++++++++++ End of WriteInDetESD.py
