if DetFlags.haveRIO.pixel_on():
    #
    # Load PixelConditionsServices
    #
    include( "PixelConditionsServices/PixelCalibSvc_jobOptions.py" )
    include( "PixelConditionsServices/SpecialPixelMapSvc_jobOptions.py" )
    if InDetFlags.useDCS():
        include( "PixelConditionsServices/PixelDCSSvc_jobOptions.py" )
        # Setup Lorentz angle calculation to use DCS.
        from SiLorentzAngleSvc.LorentzAngleSvcSetup import lorentzAngleSvc
        if (globalflags.DataSource() == 'data'):
            lorentzAngleSvc.pixel.ForceUseDB = True
    include( "PixelConditionsServices/PixelByteStreamErrorsSvc_jobOptions.py" )
    include( "PixelConditionsServices/PixelRecoDb_jobOptions.py" )
    
if DetFlags.haveRIO.SCT_on():
    #
    # Load SCT Conditions Services
    #

    # Load folders that have to exist for both MC and Data
    if not conddb.folderRequested('/SCT/DAQ/Configuration/Chip'):
        conddb.addFolder("SCT","/SCT/DAQ/Configuration/Chip")
    if not conddb.folderRequested('/SCT/DAQ/Configuration/Module'):
        conddb.addFolder("SCT","/SCT/DAQ/Configuration/Module")

    if not conddb.folderRequested('/SCT/DAQ/Configuration/MUR'):
        conddb.addFolder("SCT","/SCT/DAQ/Configuration/MUR")
    
    if not conddb.folderRequested('/SCT/Derived/Monitoring'):
        conddb.addFolder("SCT","/SCT/Derived/Monitoring")
        
        
    # Load condtions service
    from SCT_ConditionsServices.SCT_ConditionsServicesConf import SCT_ConditionsSummarySvc
    InDetSCT_ConditionsSummarySvc = SCT_ConditionsSummarySvc(name = "InDetSCT_ConditionsSummarySvc")
    ServiceMgr += InDetSCT_ConditionsSummarySvc

    # Load conditions configuration service
    from SCT_ConditionsServices.SCT_ConditionsServicesConf import SCT_ConfigurationConditionsSvc
    InDetSCT_ConfigurationConditionsSvc = SCT_ConfigurationConditionsSvc(name = "InDetSCT_ConfigurationConditionsSvc")
    ServiceMgr += InDetSCT_ConfigurationConditionsSvc

    # Load flagged condition service
    from SCT_ConditionsServices.SCT_ConditionsServicesConf import SCT_FlaggedConditionSvc
    InDetSCT_FlaggedConditionSvc = SCT_FlaggedConditionSvc(name = "InDetSCT_FlaggedConditionSvc")
    ServiceMgr += InDetSCT_FlaggedConditionSvc

    
    # Load conditions Monitoring service
    from SCT_ConditionsServices.SCT_ConditionsServicesConf import SCT_MonitorConditionsSvc
    InDetSCT_MonitorConditionsSvc = SCT_MonitorConditionsSvc(name = "InDetSCT_MonitorConditionsSvc")
    ServiceMgr += InDetSCT_MonitorConditionsSvc
    InDetSCT_MonitorConditionsSvc.OutputLevel = INFO
    InDetSCT_MonitorConditionsSvc.WriteCondObjs = False
    InDetSCT_MonitorConditionsSvc.RegisterIOV   = False
    InDetSCT_MonitorConditionsSvc.ReadWriteCool = True
    
    # Requested to be commented out by Pat until the DB is fixed for real data
    InDetSCT_ConditionsSummarySvc.ConditionsServices=["InDetSCT_ConfigurationConditionsSvc","InDetSCT_FlaggedConditionSvc", "InDetSCT_MonitorConditionsSvc"]
    if (InDetFlags.doPrintConfigurables()):
        print InDetSCT_ConditionsSummarySvc

    # Setup Lorentz angle calculation to use DCS.
    # Not actually using DCS yet but rather temperature and voltage from joboptions.
    if InDetFlags.useDCS():
        from SiLorentzAngleSvc.LorentzAngleSvcSetup import lorentzAngleSvc
        if (globalflags.DataSource() == 'data'):
            lorentzAngleSvc.sct.ForceUseDB = True
            
if DetFlags.makeRIO.TRT_on():
    #
    # Load TRT Conditions Services
    #
    #load folders that have to exist for both MC and Data
    if not conddb.folderRequested('/TRT/Calib/RT'):
      conddb.addFolder("TRT","/TRT/Calib/RT" )   
    if not conddb.folderRequested('/TRT/Calib/T0'):
      conddb.addFolder("TRT","/TRT/Calib/T0" ) 

    InDetTRTConditionsTools=[]
    
    from TRT_ConditionsTools.TRT_ConditionsToolsConf import TRTStrawStatusSummaryTool
    InDetTRTStrawStatusSummaryTool = TRTStrawStatusSummaryTool(name = "InDetTRTStrawStatusSummaryTool")
    
    ToolSvc += InDetTRTStrawStatusSummaryTool
    if (InDetFlags.doPrintConfigurables()):
      print      InDetTRTStrawStatusSummaryTool

    
    InDetTRTConditionsTools.append(InDetTRTStrawStatusSummaryTool)

    conddb.addFolder("TRT","/TRT/Cond/Status")
    conddb.addFolder("TRT","/TRT/Cond/StatusPermanent<tag>TrtStrawStatusPerm-02_test</tag>")
    if (globalflags.InputFormat() == 'bytestream' and globalflags.DataSource() == 'data'):
      if InDetFlags.useDCS():
          conddb.addFolder('DCS_OFL',"/TRT/DCS/HV/BARREL <cache>600</cache>")
          conddb.addFolder('DCS_OFL',"/TRT/DCS/HV/ENDCAPA <cache>600</cache>")
          conddb.addFolder('DCS_OFL',"/TRT/DCS/HV/ENDCAPC <cache>600</cache>")

      from TRT_ConditionsTools.TRT_ConditionsToolsConf import TRT_DAQ_ConditionsTool
      InDetTRT_DAQ_ConditionsTool = TRT_DAQ_ConditionsTool(name="InDetTRT_DAQ_ConditionsTool",
                                                            EventInfoKey = "ByteStreamEventInfo",
                                                            TRTDAQDbConnectionString = "oracle://ATLAS_COOLPROD/ATLAS_COOLONL_TRT"
                                                            )
      ToolSvc += InDetTRT_DAQ_ConditionsTool
      if (InDetFlags.doPrintConfigurables()):
        print InDetTRT_DAQ_ConditionsTool

      #InDetTRTConditionsTools.append(InDetTRT_DAQ_ConditionsTool)

      from TRT_ConditionsTools.TRT_ConditionsToolsConf import TRT_HWMappingTool
      InDetTRT_HWMappingTool = TRT_HWMappingTool(name="InDetTRT_HW_MappingTool")

      ToolSvc += InDetTRT_HWMappingTool
      if (InDetFlags.doPrintConfigurables()):
        print InDetTRT_HWMappingTool

      if InDetFlags.useDCS():
        from TRT_ConditionsTools.TRT_ConditionsToolsConf import TRT_DCS_ConditionsTool
        InDetTRT_DCS_ConditionsTool = TRT_DCS_ConditionsTool(name="InDetTRT_DCS_ConditionsTool",
                                                              HWMapTool = InDetTRT_HWMappingTool,
                                                              #OutputLevel = VERBOSE,
                                                              EventInfoKey = "ByteStreamEventInfo",
                                                              DoIOVChecking = True,
                                                              IOVmaxLength = 7*24*60*60,
                                                              #FallBackOnCOOLChanNames = False,
                                                              )
        ToolSvc += InDetTRT_DCS_ConditionsTool
        if (InDetFlags.doPrintConfigurables()):
            print      InDetTRT_DCS_ConditionsTool

        InDetTRTConditionsTools.append(InDetTRT_DCS_ConditionsTool)

    from TRT_ConditionsTools.TRT_ConditionsToolsConf import TRT_ConditionsSummaryTool
    InDetTRTConditionsSummaryTool = TRT_ConditionsSummaryTool(name = "InDetTRTConditionsSummaryTool",
                                                              ToolList=InDetTRTConditionsTools)
    ToolSvc += InDetTRTConditionsSummaryTool
    if (InDetFlags.doPrintConfigurables()):  
      print      InDetTRTConditionsSummaryTool

    from TRT_ConditionsServices.TRT_ConditionsServicesConf import TRT_ConditionsSummarySvc
    InDetTRTConditionsSummaryService = TRT_ConditionsSummarySvc(name="InDetTRTConditionsSummaryService",
                                                                ToolList=InDetTRTConditionsTools)
    ServiceMgr += InDetTRTConditionsSummaryService
    if (InDetFlags.doPrintConfigurables()):
      print         InDetTRTConditionsSummaryService 
