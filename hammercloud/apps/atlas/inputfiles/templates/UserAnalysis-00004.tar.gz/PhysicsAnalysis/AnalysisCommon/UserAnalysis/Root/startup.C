{
Cintex::Enable();
//if ( !TClassTable::GetDict("User::TruthParticle") ) {
gSystem->Load("libMathCore");
gSystem->Load("libUserAnalysisEventDict");
gSystem->Load("libUserAnalysisEvent");
gSystem->SetIncludePath("-I/afs/cern.ch/user/k/ketevi/public/analysis/rel_5/PhysicsAnalysis/AnalysisCommon/UserAnalysisEvent");
}


