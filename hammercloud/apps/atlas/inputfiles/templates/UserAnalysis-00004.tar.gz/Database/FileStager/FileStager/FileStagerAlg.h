#ifndef FILESTAGERALG_H
#define FILESTAGERALG_H

#include "GaudiKernel/Algorithm.h"
#include "GaudiKernel/IIncidentListener.h"

#include <string>
#include <vector>

class StoreGateSvc;
class TStopwatch;
class TH1D;

/////////////////////////////////////////////////////////////////////////////

class FileStagerAlg : public Algorithm, 
                      public IIncidentListener {

public:
  FileStagerAlg( const std::string& name, ISvcLocator* pSvcLocator );
  ~FileStagerAlg(); 

  StatusCode initialize();
  StatusCode execute();
  StatusCode finalize();

  void handle(const Incident& inc);

private:

  void configStager();
  void loadStager();
  void releasePrevFile();
  void setupNextFile();

  int  m_pipeLength;
  bool m_verbose;
  bool m_verboseWait;
  bool m_firstFileAlreadyStaged;
  std::string m_treeName;
  std::string m_infilePrefix;
  std::string m_outfilePrefix;
  std::string m_cpCommand;
  std::string m_baseTmpdir;
  std::string m_logfileDir;
  bool m_keepLogfiles;
  bool m_storeStats;
  std::vector< std::string > m_cpArg;
  std::vector< std::string > m_inCollection;
  std::vector< std::string > m_outCollection;

  int _numEventsInFile;
  int _event;
  std::vector< std::string >::iterator _fItr;
  std::string _prevFile;

  TStopwatch* _stopwatch;
  double _waittime;
  TH1D* _waithist;
};

#endif // FILESTAGERALG_H
