void SETUP()
{
  gSystem->Load("BaseTree_ttbar_C.so");
}
