prun --exec "echo %IN | sed 's/,/\n/g'>  input.txt; ./runPanda.sh" \
   --noBuild   --excludeFile=".svn" \
   --nFiles=3 --site=ANALY_BNL_ATLAS_1 \
   --inDS=data11_7TeV.00180241.physics_Muons.merge.NTUP_TOP.f368_m812_p530_p532_tid334576_00\
   --outDS=user.flegger.data11_7TeV-00180242-ttbar_D3PD.test.V4444 
