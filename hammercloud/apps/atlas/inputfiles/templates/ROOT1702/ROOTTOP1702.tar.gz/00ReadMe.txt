This is a D3PD-ntuple-based ttbar reconstruction example to demonstrate:

  - how to write analysis code suitable for running on non-Proof ROOT, 
    ProofLite and Proof.

  - how to communicate between client and Proof master/workers. There are 
    at least 4 ways to achieve that:

      1) via TProof::SetParameter(), but not available for non-Proof ROOT.

      2) via shell environmental variable

      3) via option in TChain::Process or TDSet::Proces()

      4) via a file shipped with TProof::UploadPackage()

    This example manifests all the above ways except the first one.

  - how to write out selected events, create a new tree, and histograms 
    suitable for all cases of non-Proof ROOT, ProofLite and Proof.

  - using TProofOutputFile in order to be able to merge a user ROOT 
    file in Proof.

  - how to override ROOT version on Proof master/worker nodes.

  - how to write out the log file on Proof master/worker nodes.


Other useful features:
=====================

  1. ntuple structure class "BaseTree_ttbar" is separted from 
     the main analysis class "ttbarSel". It would be regenerated 
     automatically during running the root script "run_chain-ttbarSel.C" 
     via TTree::MakeSelector(). So your main analysis code is untouched 
     unless the used variables are changed in the ntuple.

  2. convenient way to control the mode among 
     "NonProof","Proof", or "ProofLite".

  3. showing wall/cpu time consumption on all Proof master/worker nodes
     as well as on client machine.

  4. parameters for event selection criteria are read from a text file 
     and are later written into the output root file for bookkeeping purpose.
     So you need not change your analysis code to change event selection cuts.

  5. you can use option in TChain::Process() to control 
     the printout in your code and 
     writing out the old tree "selTree" for selected events.

  6. the choice of jet flavour weight is chosen in ttbarSel::Notify()
     by "my_jet_flavor_weight" in file "ttbarSel.h".

  7. some indice to jet, leptons in old tree will be written out 
     only when the writing of the old tree "selTree" is enabled.

  8. how to set sub-merger is provided, but is commented out.
     It is quite helpful in case your merging stage takes a long time.
     But some old ROOT versions (<5.28.00) may not work with this option.

Code components
===============
  - 00ReadMe.txt           # this guide
  - run_chain-ttbarSel.C   # main ROOT control macro
  - ttbarSel.h             # header file of analysis class "ttbarSel"
  - ttbarSel..C            # where main analysis code is
  - BaseTree_ttbar/BaseTree_ttbar.{h,C}
                           # base class defining the input tree structure
  - BaseTree_ttbar/PROOF-INF/SETUP.C
                           # initial setup script at Proof workers
  - BaseTree_ttbar/ttbarSel-Cuts.txt
                           # cut-related parameters


About ttbar reconstruction
==========================
  This analysis reconstructs ttbar via the mode (W_1b)(W_2b), where 
W_1 decays to lepton+neutrino, and W_2 decays to 2 jets. The neutrino is 
constructed using the constraint on W mass and assuming the missing overall 
transverse momentum is neutrino transverse momentum.


Output
======
   This analysis writes out a new TTree for ttbar objects, and related 
histograms. Optinally it also write the old TTree for those survived events, 
which can be turned off via "NO_selTree" in TChain::Process option.
   The cut parameters are also written as TPaveText into the output root file.


Input
=====
   ttbar D3PD ntuple such as dataset 
data10_7TeV.00166198.physics_JetTauEtmiss.merge.NTUP_TOP.r1774_p327_p333_p379_p386_tid242065_00


How to run
==========
 Step-1: Set up ROOT environment at client machine
 Step-2: Get the dataset.
         If your ntuple structure is different from that in BaseTree_ttbar,
         you need recreate BaseTree_ttbar.{h,C}.
 Step-3: In "run_chain-ttbarSel.C", change the name of Proof server,
         the way to setting up same ROOT version at worker nodes,
         and the input to TChain.
 Step-4: Choose your running mode in "run_chain-ttbarSel.C".
         You had better try "NonProof" mode first with a few events.
 Step-5: Then run "root -l run_chain-ttbarSel.C".

