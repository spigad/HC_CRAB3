#!/bin/bash
root -q -b -l run_chain-ttbarSel.C
