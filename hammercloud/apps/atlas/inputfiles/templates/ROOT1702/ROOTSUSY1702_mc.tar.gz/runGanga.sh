#!/bin/bash
root -l -b runGanga.C
