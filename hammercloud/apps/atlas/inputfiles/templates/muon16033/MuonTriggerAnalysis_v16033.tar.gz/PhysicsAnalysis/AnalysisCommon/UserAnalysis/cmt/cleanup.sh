if test "${CMTROOT}" = ""; then
  CMTROOT=/afs/cern.ch/atlas/software/releases/16.0.3/CMT/v1r22; export CMTROOT
fi
. ${CMTROOT}/mgr/setup.sh
cmtUserAnalysistempfile=`${CMTROOT}/mgr/cmt -quiet build temporary_name`
if test ! $? = 0 ; then cmtUserAnalysistempfile=/tmp/cmt.$$; fi
${CMTROOT}/mgr/cmt cleanup -sh -pack=UserAnalysis -version=UserAnalysis-00-10-12 -path=/afs/cern.ch/user/e/elmsheus/athena/testarea/16.0.3.3/PhysicsAnalysis/AnalysisCommon $* >${cmtUserAnalysistempfile}
if test $? != 0 ; then
  echo >&2 "${CMTROOT}/mgr/cmt cleanup -sh -pack=UserAnalysis -version=UserAnalysis-00-10-12 -path=/afs/cern.ch/user/e/elmsheus/athena/testarea/16.0.3.3/PhysicsAnalysis/AnalysisCommon $* >${cmtUserAnalysistempfile}"
  cmtcleanupstatus=2
  /bin/rm -f ${cmtUserAnalysistempfile}
  unset cmtUserAnalysistempfile
  return $cmtcleanupstatus
fi
cmtcleanupstatus=0
. ${cmtUserAnalysistempfile}
if test $? != 0 ; then
  cmtcleanupstatus=2
fi
/bin/rm -f ${cmtUserAnalysistempfile}
unset cmtUserAnalysistempfile
return $cmtcleanupstatus

