#include <sstream>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <vector>

#include "TSystem.h"
#include "TTree.h"
#include "TBranch.h"
#include "TString.h"
#include "TCanvas.h"
#include "TKey.h"
#include "TFile.h"
#include "TClassTable.h"
#include "TStopwatch.h"

#include "UserAnalysisEvent/TrackParticle.h"
#include "UserAnalysisEvent/CaloCluster.h"
#include "UserAnalysisEvent/Electron.h"
#include "UserAnalysisEvent/Photon.h"
#include "UserAnalysisEvent/Muon.h"
#include "UserAnalysisEvent/TauJet.h"
#include "UserAnalysisEvent/ParticleJet.h"
#include "UserAnalysisEvent/TruthParticle.h"
#include "UserAnalysisEvent/MissingET.h"

using namespace User;

void EventTime () {

  TFile *  f = new TFile("/afs/cern.ch/user/k/ketevi/scratch0/Tutorial/12.0.2/data/SAN.root");
  TTree *  tree = (TTree*)gDirectory->Get("CollectionTree");

  /** TrackParticle */
  std::vector<TrackParticle> * pTrack=0;
  tree->SetBranchAddress("TrackParticleCandidate",&pTrack);
  TBranch * trackBranch = tree->GetBranch("TrackParticleCandidate");

  /** CaloClusters */
  std::vector<CaloCluster> * pLArClusterEM=0;
  tree->SetBranchAddress("LArClusterEM",&pLArClusterEM);
  TBranch * clusEMBranch = tree->GetBranch("LArClusterEM");

  std::vector<CaloCluster> * pLArClusterEM37=0;
  tree->SetBranchAddress("LArClusterEM37",&pLArClusterEM37);
  TBranch * clusEM37Branch = tree->GetBranch("LArClusterEM37");

  std::vector<CaloCluster> * pLArClusterEMSofte=0;
  tree->SetBranchAddress("LArClusterEMSofte",&pLArClusterEMSofte);
  TBranch * clusEMSofteBranch = tree->GetBranch("LArClusterEMSofte");

  std::vector<CaloCluster> * pCombinedCluster=0;
  tree->SetBranchAddress("CombinedCluster",&pCombinedCluster);
  TBranch * combinedClusterBranch = tree->GetBranch("CombinedCluster");

  std::vector<CaloCluster> * pEMTopoCluster=0;
  tree->SetBranchAddress("EMTopoCluster",&pEMTopoCluster);
  TBranch * clusEMTopoClusterBranch = tree->GetBranch("EMTopoCluster");

  std::vector<CaloCluster> * pCaloCalTopoCluster=0;
  tree->SetBranchAddress("CaloCalTopoCluster",&pCaloCalTopoCluster);
  TBranch * clusCaloCalTopoClusterBranch = tree->GetBranch("CaloCalTopoCluster");

  std::vector<User::CaloCluster> * pLArClusterEMgam35=0;
  tree->SetBranchAddress("LArClusterEMgam35",&pLArClusterEMgam35);
  TBranch * clusEMgam35Branch = tree->GetBranch("LArClusterEMgam35");

  std::vector<User::CaloCluster> * pLArClusterEMgam=0;
  tree->SetBranchAddress("LArClusterEMgam",&pLArClusterEMgam);
  TBranch * clusEMgamBranch = tree->GetBranch("LArClusterEMgam");

  /** Electron */
  std::vector<Electron> * pElectron=0;
  tree->SetBranchAddress("ElectronCollection",&pElectron);
  TBranch * elecBranch = tree->GetBranch("ElectronCollection");

  /** Photon */
  std::vector<Photon> * pPhoton=0;
  tree->SetBranchAddress("PhotonCollection",&pPhoton);
  TBranch * photBranch = tree->GetBranch("PhotonCollection");

  /** Muon */
  std::vector<Muon> * pMuon=0;
  tree->SetBranchAddress("StacoMuonCollection",&pMuon);
  TBranch * muonBranch = tree->GetBranch("StacoMuonCollection");

  /** TauJet */
  std::vector<TauJet> * pTauJet=0;
  tree->SetBranchAddress("TauJetCollection",&pTauJet);
  TBranch * tauJetBranch = tree->GetBranch("TauJetCollection");

  /** ParticleJet */
  std::vector<ParticleJet> * pJet=0;
  tree->SetBranchAddress("ConeTowerParticleJets",&pJet);
  TBranch * jetBranch = tree->GetBranch("ConeTowerParticleJets");

  /** TruthParticle */
  std::vector<TruthParticle> * pTruth=0;
  tree->SetBranchAddress("SpclMC",&pTruth);
  TBranch * truthBranch = tree->GetBranch("SpclMC");

  /** MissingET */
  MissingET * pMissingET=0;
  tree->SetBranchAddress("MET_FINAL_Muonboy",&pMissingET);
  TBranch * metBranch = tree->GetBranch("MET_FINAL_Muonboy");

  Long64_t nentries = tree->GetEntriesFast();
  double nbytes = 0; 
  
  TStopwatch timer;
  timer.Start();
  for (Long64_t jentry=0; jentry<nentries;jentry++) {

    nbytes += trackBranch->GetEntry(jentry);
    nbytes += clusEMBranch->GetEntry(jentry);      
    nbytes += clusEM37Branch->GetEntry(jentry);     
    nbytes += clusEMSofteBranch->GetEntry(jentry);  
    nbytes += combinedClusterBranch->GetEntry(jentry);  
    nbytes += clusEMTopoClusterBranch->GetEntry(jentry);  
    nbytes += clusEMgam35Branch->GetEntry(jentry);   
    nbytes += clusEMgamBranch->GetEntry(jentry);     
    nbytes += clusCaloCalTopoClusterBranch->GetEntry(jentry); 
    nbytes += elecBranch->GetEntry(jentry);  
    nbytes += muonBranch->GetEntry(jentry); 
    nbytes += photBranch->GetEntry(jentry);       
    nbytes += tauJetBranch->GetEntry(jentry);       
    nbytes += jetBranch->GetEntry(jentry);      
    nbytes += metBranch->GetEntry(jentry);   
       
    //nbytes += truthBranch->GetEntry(jentry); 

    //nbytes += tree->GetEntry(jentry);

  }  
  timer.Stop();
  double kbytes = 0.001*nbytes;
  double rtime = timer.RealTime();
  double ctime = timer.CpuTime();
  std::cout << "You have read " << nentries << " Events with " << kbytes << " kb total" << std::endl;
  std::cout << "RealTime and CpuTime in seconds = " << rtime << " " << ctime << endl;

  f->Close();
  
  return;
  
}
