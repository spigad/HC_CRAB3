#Thu Dec  1 14:29:32 2011
"""Automatically generated. DO NOT EDIT please"""
from GaudiKernel.GaudiHandles import *
from GaudiKernel.Proxy.Configurable import *

class UserAnalysisPreparationTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'UserSelectionTool' : PublicToolHandle('UserAnalysisSelectionTool'), # GaudiHandle
    'InputContainerKeys' : [  ], # list
    'OutputContainerKeys' : [  ], # list
    'IsAtlfastData' : False, # bool
  }
  _propertyDocDct = { 
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(UserAnalysisPreparationTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'UserAnalysisUtils'
  def getType( self ):
      return 'UserAnalysisPreparationTool'
  pass # class UserAnalysisPreparationTool

class UserAnalysisSelectionTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'IsAtlfastData' : False, # bool
    'CaloClusterE' : 1000.0, # float
    'TrackParticlePt' : 1000.0, # float
    'ElectronPt' : 10000.0, # float
    'ElectronEta' : 2.5, # float
    'ElectronIsEMFlag' : 'Loose', # str
    'ElectronIsEM' : 0, # int
    'AuthorEgammaOnly' : False, # bool
    'ElectronEtaWindowCut' : False, # bool
    'ElectronEtaWindow' : 0.075, # float
    'ElectronEtaWindowCenter' : 1.445, # float
    'DoElectronIsolation' : True, # bool
    'ElectronIsolationConeIndex' : 1, # int
    'ElectronIsolationEt' : 10000.0, # float
    'NormalizedElectronIsolationEt' : 0.2, # float
    'PhotonPt' : 10000.0, # float
    'PhotonEta' : 3.2, # float
    'PhotonIsEM' : 0.0, # float
    'MuonPt' : 3000.0, # float
    'MuonEta' : 2.7, # float
    'DoMuonIsolation' : True, # bool
    'MuonIsolationConeIndex' : 1, # int
    'MuonIsolationEt' : 10000.0, # float
    'UseMatchChi2' : False, # bool
    'MuonMatchChi2' : 100.0, # float
    'NormalizedMuonIsolationEt' : 0.2, # float
    'egDetailContainerName' : 'egDetailAOD', # str
    'TauJetPt' : 20000.0, # float
    'TauJetEta' : 2.5, # float
    'TauJetLikelihood' : -6.0, # float
    'TauEleBDTCut' : 0.5, # float
    'JetPt' : 20000.0, # float
    'JetEta' : 5.0, # float
    'BJetLikelihood' : 6.0, # float
  }
  _propertyDocDct = { 
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(UserAnalysisSelectionTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'UserAnalysisUtils'
  def getType( self ):
      return 'UserAnalysisSelectionTool'
  pass # class UserAnalysisSelectionTool

class UserAnalysisOverlapCheckingTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'AnalysisTools' : PrivateToolHandle('AnalysisTools'), # GaudiHandle
    'OverlapDeltaR' : 0.2, # float
    'OverlapDeltaRWithJets' : 0.3, # float
  }
  _propertyDocDct = { 
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(UserAnalysisOverlapCheckingTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'UserAnalysisUtils'
  def getType( self ):
      return 'UserAnalysisOverlapCheckingTool'
  pass # class UserAnalysisOverlapCheckingTool

class UserAnalysisOverlapRemovalTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'UserSelectionTool' : PublicToolHandle('UserAnalysisSelectionTool'), # GaudiHandle
    'UserOverlapCheckingTool' : PublicToolHandle('UserAnalysisOverlapCheckingTool'), # GaudiHandle
    'InputContainerKeys' : [  ], # list
    'IsAtlfastData' : False, # bool
    'OuputObjectKey' : 'FinalStateObjects', # str
    'OutputLeptonKey' : 'FinalStateLeptons', # str
    'OutputPhotonKey' : 'FinalStatePhotons', # str
    'OutputElectronKey' : 'FinalStateElectrons', # str
    'OutputMuonKey' : 'FinalStateMuons', # str
    'OutputTauJetKey' : 'FinalStateTauJets', # str
    'OutputCalloClusterKey' : 'FinalStateCaloClusters', # str
    'OutputTrackParticleKey' : 'FinalStateTrackParticles', # str
    'OutputJetKey' : 'FinalStateJets', # str
    'OutputBJetKey' : 'FinalStateBJets', # str
    'OutputLightJetKey' : 'FinalStateLightJets', # str
    'RemoveOverlapInSameContainer' : True, # bool
  }
  _propertyDocDct = { 
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(UserAnalysisOverlapRemovalTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'UserAnalysisUtils'
  def getType( self ):
      return 'UserAnalysisOverlapRemovalTool'
  pass # class UserAnalysisOverlapRemovalTool
