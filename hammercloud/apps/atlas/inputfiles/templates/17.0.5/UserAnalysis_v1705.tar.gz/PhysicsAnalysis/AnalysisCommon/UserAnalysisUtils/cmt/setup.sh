# echo "setup UserAnalysisUtils UserAnalysisUtils-02-02-13 in /data/etp1/elmsheus/athena/17.0.5-hello/PhysicsAnalysis/AnalysisCommon"

if test "${CMTROOT}" = ""; then
  CMTROOT=/cvmfs/atlas.cern.ch/repo/sw/software/i686-slc5-gcc43-opt/17.0.5/CMT/v1r23; export CMTROOT
fi
. ${CMTROOT}/mgr/setup.sh
cmtUserAnalysisUtilstempfile=`${CMTROOT}/mgr/cmt -quiet build temporary_name`
if test ! $? = 0 ; then cmtUserAnalysisUtilstempfile=/tmp/cmt.$$; fi
${CMTROOT}/mgr/cmt setup -sh -pack=UserAnalysisUtils -version=UserAnalysisUtils-02-02-13 -path=/data/etp1/elmsheus/athena/17.0.5-hello/PhysicsAnalysis/AnalysisCommon  -quiet -without_version_directory -no_cleanup $* >${cmtUserAnalysisUtilstempfile}
if test $? != 0 ; then
  echo >&2 "${CMTROOT}/mgr/cmt setup -sh -pack=UserAnalysisUtils -version=UserAnalysisUtils-02-02-13 -path=/data/etp1/elmsheus/athena/17.0.5-hello/PhysicsAnalysis/AnalysisCommon  -quiet -without_version_directory -no_cleanup $* >${cmtUserAnalysisUtilstempfile}"
  cmtsetupstatus=2
  /bin/rm -f ${cmtUserAnalysisUtilstempfile}
  unset cmtUserAnalysisUtilstempfile
  return $cmtsetupstatus
fi
cmtsetupstatus=0
. ${cmtUserAnalysisUtilstempfile}
if test $? != 0 ; then
  cmtsetupstatus=2
fi
/bin/rm -f ${cmtUserAnalysisUtilstempfile}
unset cmtUserAnalysisUtilstempfile
return $cmtsetupstatus

