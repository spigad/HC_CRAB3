def main():
    import user
    import ROOT
    import PyCintex
    outF = ROOT.TFile('out1.root','recreate')
    import AthenaROOTAccess.transientTree
    CollectionTree = ROOT.AthenaROOTAccess.TChainROOTAccess('CollectionTree')
    CollectionTree.Add('xo.pool.root')
    tt = AthenaROOTAccess.transientTree.makeTree(CollectionTree)
    for i in range(tt.GetEntries()):
        tt.GetEntry(i)
        photons = tt.PhotonAODCollection
        print [e.eta() for e in photons]
if __name__ == "__main__":
    main()

