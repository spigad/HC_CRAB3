#!/bin/bash
root -l -b runGangaTTreeCache.C
