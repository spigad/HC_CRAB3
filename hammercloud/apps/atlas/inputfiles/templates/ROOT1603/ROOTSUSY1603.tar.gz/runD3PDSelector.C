#include <string>
#include <vector>
#include <iostream>
#include <stdlib.h>

#include "TROOT.h"
#include "TFile.h"
#include "TTree.h"
#include "TChain.h"
#include "TBranch.h"
#include "TFileCollection.h"

#include <fstream> 


//to run in ROOT: .x runD3PDSelector.C
void runD3PDSelector(int mode) {


  bool proof = false ; // mode == 1
  
  if (mode == 1) {
    cout << "Proof enabled" <<endl;
    proof = true;
  } 


  std::vector<TString> filename; 

  TString path = "/data/etp1/SUSYD3PD/SUSYD3PDMaker_0614/mc/";

//SU4
  filename.push_back("group10.phys-susy.SUSYD3PD.mc09_7TeV.106484.SU4_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V2/*.root");
/* filename.push_back("user.Jetson.SUSYD3PD.mc09_7TeV.106400.SU4_jimmy_susy.merge.AOD.e496_s765_s767_r1302_r1306.000614.V1.101005131053/*.root");
    

// Jx 
/*  filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.105009.J0_pythia_jetjet.merge.AOD.e468_s766_s767_r1303_r1306.000614.V2/*.root");
  filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.105010.J1_pythia_jetjet.merge.AOD.e468_s766_s767_r1303_r1306.000614.V2/*.root");
  filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.105011.J2_pythia_jetjet.merge.AOD.e468_s766_s767_r1303_r1306.000614.V2/*.root");
  filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.105012.J3_pythia_jetjet.merge.AOD.e468_s766_s767_r1303_r1306.000614.V2/*.root");
  filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.105013.J4_pythia_jetjet.merge.AOD.e468_s766_s767_r1303_r1306.000614.V2/*.root");
  filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.105014.J5_pythia_jetjet.merge.AOD.e468_s766_s767_r1303_r1306.000614.V2/*.root");
  filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.105015.J6_pythia_jetjet.merge.AOD.e468_s766_s767_r1303_r1306.000614.V2/*.root");
  
// Wbb
  filename.push_back("user.andreas.SUSYD3PD.mc09_7TeV.106280.AlpgenJimmyWbbNp0_pt20.merge.AOD.e524_s765_s767_r1302_r1306.000614.V1/*.root");
  filename.push_back("user.andreas.SUSYD3PD.mc09_7TeV.106281.AlpgenJimmyWbbNp1_pt20.merge.AOD.e524_s765_s767_r1302_r1306.000614.V1/*.root");
  filename.push_back("user.andreas.SUSYD3PD.mc09_7TeV.106282.AlpgenJimmyWbbNp2_pt20.merge.AOD.e524_s765_s767_r1302_r1306.000614.V1/*.root");
  filename.push_back("user.andreas.SUSYD3PD.mc09_7TeV.106283.AlpgenJimmyWbbNp3_pt20.merge.AOD.e524_s765_s767_r1302_r1306.000614.V1/*.root");

// Jx muon
  filename.push_back("user.andreas.SUSYD3PD.mc09_7TeV.109276.J0_pythia_jetjet_1muon.merge.AOD.e534_s765_s767_r1302_r1306.000614.V1/*.root");
  filename.push_back("user.andreas.SUSYD3PD.mc09_7TeV.109277.J1_pythia_jetjet_1muon.merge.AOD.e534_s765_s767_r1302_r1306.000614.V1/*.root");
  filename.push_back("user.andreas.SUSYD3PD.mc09_7TeV.109278.J2_pythia_jetjet_1muon.merge.AOD.e534_s765_s767_r1302_r1306.000614.V1/*.root");
  filename.push_back("user.andreas.SUSYD3PD.mc09_7TeV.109279.J3_pythia_jetjet_1muon.merge.AOD.e534_s765_s767_r1302_r1306.000614.V1/*.root");
  filename.push_back("user.andreas.SUSYD3PD.mc09_7TeV.109280.J4_pythia_jetjet_1muon.merge.AOD.e534_s765_s767_r1302_r1306.000614.V1/*.root");
  filename.push_back("user.andreas.SUSYD3PD.mc09_7TeV.109281.J5_pythia_jetjet_1muon.merge.AOD.e534_s765_s767_r1302_r1306.000614.V1/*.root");
  filename.push_back("user.andreas.SUSYD3PD.mc09_7TeV.209435.J6_pythia_jetjet_1muon.merge.AOD.e534_s765_s767_r1302_r1306.000614.V1/*.root");

// Z jets
  filename.push_back("user.JESunderm.SUSYD3PD.mc09_7TeV.107650.AlpgenJimmyZeeNp0_pt20.merge.AOD.e529_s765_s767_r1302_r1306.000614.V1.ANALY_PIC/*.root");
  filename.push_back("user.JESunderm.SUSYD3PD.mc09_7TeV.107651.AlpgenJimmyZeeNp1_pt20.merge.AOD.e529_s765_s767_r1302_r1306.000614.V1.ANALY_ARC/*.root");
  filename.push_back("user.JESunderm.SUSYD3PD.mc09_7TeV.107652.AlpgenJimmyZeeNp2_pt20.merge.AOD.e529_s765_s767_r1302_r1306.000614.V1.ANALY_RRC-KI/*.root");
  filename.push_back("user.JESunderm.SUSYD3PD.mc09_7TeV.107653.AlpgenJimmyZeeNp3_pt20.merge.AOD.e529_s765_s767_r1302_r1306.000614.V1.ANALY_ARC/*.root");
  filename.push_back("user.JESunderm.SUSYD3PD.mc09_7TeV.107654.AlpgenJimmyZeeNp4_pt20.merge.AOD.e529_s765_s767_r1302_r1306.000614.V1.ANALY_RRC-KI/*.root");
  filename.push_back("user.JESunderm.SUSYD3PD.mc09_7TeV.107655.AlpgenJimmyZeeNp5_pt20.merge.AOD.e529_s765_s767_r1302_r1306.000614.V1.ANALY_ARC/*.root");
  filename.push_back("user.JESunderm.SUSYD3PD.mc09_7TeV.107660.AlpgenJimmyZmumuNp0_pt20.merge.AOD.e529_s765_s767_r1302_r1306.000614.V1.ANALY_ARC/*.root");
  filename.push_back("user.JESunderm.SUSYD3PD.mc09_7TeV.107661.AlpgenJimmyZmumuNp1_pt20.merge.AOD.e529_s765_s767_r1302_r1306.000614.V1.ANALY_ARC/*.root");
  filename.push_back("user.JESunderm.SUSYD3PD.mc09_7TeV.107662.AlpgenJimmyZmumuNp2_pt20.merge.AOD.e529_s765_s767_r1302_r1306.000614.V1.ANALY_ARC/*.root");
  filename.push_back("user.JESunderm.SUSYD3PD.mc09_7TeV.107663.AlpgenJimmyZmumuNp3_pt20.merge.AOD.e529_s765_s767_r1302_r1306.000614.V1.ANALY_PIC/*.root");
  filename.push_back("user.JESunderm.SUSYD3PD.mc09_7TeV.107664.AlpgenJimmyZmumuNp4_pt20.merge.AOD.e529_s765_s767_r1302_r1306.000614.V1.ANALY_IHEP/*.root");
  filename.push_back("user.JESunderm.SUSYD3PD.mc09_7TeV.107665.AlpgenJimmyZmumuNp5_pt20.merge.AOD.e529_s765_s767_r1302_r1306.000614.V1.ANALY_RRC-KI/*.root");
  filename.push_back("user.JESunderm.SUSYD3PD.mc09_7TeV.107670.AlpgenJimmyZtautauNp0_pt20.merge.AOD.e529_s765_s767_r1302_r1306.000614.V1.ANALY_RRC-KI/*.root");
  filename.push_back("user.JESunderm.SUSYD3PD.mc09_7TeV.107671.AlpgenJimmyZtautauNp1_pt20.merge.AOD.e529_s765_s767_r1302_r1306.000614.V1.ANALY_RRC-KI/*.root");
  filename.push_back("user.JESunderm.SUSYD3PD.mc09_7TeV.107672.AlpgenJimmyZtautauNp2_pt20.merge.AOD.e529_s765_s767_r1302_r1306.000614.V1.ANALY_RRC-KI/*.root");
  filename.push_back("user.JESunderm.SUSYD3PD.mc09_7TeV.107673.AlpgenJimmyZtautauNp3_pt20.merge.AOD.e529_s765_s767_r1302_r1306.000614.V1.ANALY_RRC-KI/*.root");
  filename.push_back("user.JESunderm.SUSYD3PD.mc09_7TeV.107674.AlpgenJimmyZtautauNp4_pt20.merge.AOD.e529_s765_s767_r1302_r1306.000614.V1.ANALY_RRC-KI/*.root");
  filename.push_back("user.JESunderm.SUSYD3PD.mc09_7TeV.107675.AlpgenJimmyZtautauNp5_pt20.merge.AOD.e529_s765_s767_r1302_r1306.000614.V1.ANALY_CERN/*.root");

// W jets
  filename.push_back("user.StephanHorner.SUSYD3PD.mc09_7TeV.107680.AlpgenJimmyWenuNp0_pt20.merge.AOD.e511_s765_s767_r1302_r1306.000614.V1.ANALY_PIC/*.root");
  filename.push_back("user.StephanHorner.SUSYD3PD.mc09_7TeV.107681.AlpgenJimmyWenuNp1_pt20.merge.AOD.e511_s765_s767_r1302_r1306.000614.V2.ANALY_PIC/*.root");
  filename.push_back("user.StephanHorner.SUSYD3PD.mc09_7TeV.107682.AlpgenJimmyWenuNp2_pt20.merge.AOD.e511_s765_s767_r1302_r1306.000614.V1.ANALY_RRC-KI/*.root");
  filename.push_back("user.StephanHorner.SUSYD3PD.mc09_7TeV.107683.AlpgenJimmyWenuNp3_pt20.merge.AOD.e511_s765_s767_r1302_r1306.000614.V1.ANALY_RRC-KI/*.root");
  filename.push_back("user.StephanHorner.SUSYD3PD.mc09_7TeV.107684.AlpgenJimmyWenuNp4_pt20.merge.AOD.e511_s765_s767_r1302_r1306.000614.V1.ANALY_RRC-KI/*.root");
  filename.push_back("user.StephanHorner.SUSYD3PD.mc09_7TeV.107685.AlpgenJimmyWenuNp5_pt20.merge.AOD.e511_s765_s767_r1302_r1306.000614.V1.ANALY_RRC-KI/*.root");
  filename.push_back("user.StephanHorner.SUSYD3PD.mc09_7TeV.107690.AlpgenJimmyWmunuNp0_pt20.merge.AOD.e511_s765_s767_r1302_r1306.000614.V1.ANALY_RRC-KI/*.root");
  filename.push_back("user.StephanHorner.SUSYD3PD.mc09_7TeV.107691.AlpgenJimmyWmunuNp1_pt20.merge.AOD.e511_s765_s767_r1302_r1306.000614.V1.ANALY_RRC-KI/*.root");
  filename.push_back("user.StephanHorner.SUSYD3PD.mc09_7TeV.107692.AlpgenJimmyWmunuNp2_pt20.merge.AOD.e511_s765_s767_r1302_r1306.000614.V1.ANALY_RRC-KI/*.root");
  filename.push_back("user.StephanHorner.SUSYD3PD.mc09_7TeV.107693.AlpgenJimmyWmunuNp3_pt20.merge.AOD.e511_s765_s767_r1302_r1306.000614.V1.ANALY_RRC-KI/*.root");
  filename.push_back("user.StephanHorner.SUSYD3PD.mc09_7TeV.107694.AlpgenJimmyWmunuNp4_pt20.merge.AOD.e511_s765_s767_r1302_r1306.000614.V1.ANALY_RRC-KI/*.root");
  filename.push_back("user.StephanHorner.SUSYD3PD.mc09_7TeV.107695.AlpgenJimmyWmunuNp5_pt20.merge.AOD.e511_s765_s767_r1302_r1306.000614.V1.ANALY_RRC-KI/*.root");
  filename.push_back("user.StephanHorner.SUSYD3PD.mc09_7TeV.107700.AlpgenJimmyWtaunuNp0_pt20.merge.AOD.e511_s765_s767_r1302_r1306.000614.V2.ANALY_PIC/*.root");
  filename.push_back("user.StephanHorner.SUSYD3PD.mc09_7TeV.107701.AlpgenJimmyWtaunuNp1_pt20.merge.AOD.e511_s765_s767_r1302_r1306.000614.V1.ANALY_RRC-KI/*.root");
  filename.push_back("user.StephanHorner.SUSYD3PD.mc09_7TeV.107702.AlpgenJimmyWtaunuNp2_pt20.merge.AOD.e511_s765_s767_r1302_r1306.000614.V1.ANALY_RRC-KI/*.root");
  filename.push_back("user.StephanHorner.SUSYD3PD.mc09_7TeV.107703.AlpgenJimmyWtaunuNp3_pt20.merge.AOD.e511_s765_s767_r1302_r1306.000614.V1.ANALY_RRC-KI/*.root");
  filename.push_back("user.StephanHorner.SUSYD3PD.mc09_7TeV.107704.AlpgenJimmyWtaunuNp4_pt20.merge.AOD.e511_s765_s767_r1302_r1306.000614.V1.ANALY_RRC-KI/*.root");
  filename.push_back("user.StephanHorner.SUSYD3PD.mc09_7TeV.107705.AlpgenJimmyWtaunuNp5_pt20.merge.AOD.e511_s765_s767_r1302_r1306.000614.V2.ANALY_IFIC/*.root");

//ttbar
  filename.push_back("user.trave.SUSYD3PD.mc09_7TeV.105200.T1_McAtNlo_Jimmy.merge.AOD.e510_s765_s767_r1302_r1306.000614.V1.ANALY_IHEP/*.root");
  filename.push_back("user.trave.SUSYD3PD.mc09_7TeV.105204.TTbar_FullHad_McAtNlo_Jimmy.merge.AOD.e540_s765_s767_r1302_r1306.000614.V2.ANALY_IHEP/*.root");

//Diboson
  filename.push_back("user.Jetson.SUSYD3PD.mc09_7TeV.105985.WW_Herwig.merge.AOD.e521_s765_s767_r1302_r1306.000614.V1/*.root");
  filename.push_back("user.Jetson.SUSYD3PD.mc09_7TeV.105986.ZZ_Herwig.merge.AOD.e521_s765_s767_r1302_r1306.000614.V2/*.root");

//DY
  filename.push_back("user.BorgeKileGjelsten.SUSYD3PD.mc09_7TeV.108319.PythiaDrellYan_mumu.merge.AOD.e518_s765_s767_r1302_r1306.000614.V1.ANALY_FREIBURG//*.root");
  filename.push_back("user.BorgeKileGjelsten.SUSYD3PD.mc09_7TeV.108320.PythiaDrellYan_ee.merge.AOD.e518_s765_s767_r1302_r1306.000614.V1.ANALY_IFIC/*.root");
  filename.push_back("user.BorgeKileGjelsten.SUSYD3PD.mc09_7TeV.108321.PythiaDrellYanLowM_mu3.merge.AOD.e518_s765_s767_r1302_r1306.000614.V1.ANALY_MWT2/*.root");
  filename.push_back("user.BorgeKileGjelsten.SUSYD3PD.mc09_7TeV.108322.PythiaDrellYanLowM_ee3.merge.AOD.e518_s765_s767_r1302_r1306.000614.V2.ANALY_IFIC/*.root");
  filename.push_back("user.Jetson.SUSYD3PD.mc09_7TeV.105987.WZ_Herwig.merge.AOD.e521_s765_s767_r1302_r1306.000614.V2/*.root"); 
*/

// MSUGRA 
/*
path += "SUGRA_tanbeta3_grid/";
filename.push_back("group10.phys-susy.SUSYD3PD.mc09_7TeV.114036.SU_1160_250_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("group10.phys-susy.SUSYD3PD.mc09_7TeV.114152.SU_440_310_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114013.SU_1000_100_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V4/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114014.SU_1000_130_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114015.SU_1000_160_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114016.SU_1000_190_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V4/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114017.SU_1000_220_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114018.SU_1000_250_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114019.SU_1000_280_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114020.SU_1000_310_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114021.SU_1000_340_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114022.SU_1080_100_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114023.SU_1080_130_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114024.SU_1080_160_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114025.SU_1080_190_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114026.SU_1080_220_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114027.SU_1080_250_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114028.SU_1080_280_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114029.SU_1080_310_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114030.SU_1080_340_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114031.SU_1160_100_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114032.SU_1160_130_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114033.SU_1160_160_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114034.SU_1160_190_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114035.SU_1160_220_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114037.SU_1160_280_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114038.SU_1160_310_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114039.SU_1160_340_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114040.SU_120_100_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114041.SU_120_115_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114042.SU_120_130_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114043.SU_120_145_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114044.SU_120_160_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114045.SU_120_175_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114046.SU_120_190_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114047.SU_120_205_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114048.SU_120_220_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114049.SU_120_250_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114050.SU_120_280_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114051.SU_120_310_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114052.SU_120_340_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114053.SU_160_100_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114054.SU_160_115_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114055.SU_160_130_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114056.SU_160_145_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114057.SU_160_160_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114058.SU_160_175_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114059.SU_160_190_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114060.SU_160_205_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114061.SU_160_220_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114062.SU_200_100_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114063.SU_200_115_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114064.SU_200_130_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114065.SU_200_145_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114066.SU_200_160_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114067.SU_200_175_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114068.SU_200_190_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114069.SU_200_205_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114070.SU_200_220_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114071.SU_200_250_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114072.SU_200_280_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114073.SU_200_310_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114074.SU_200_340_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114075.SU_240_100_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114076.SU_240_115_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114077.SU_240_130_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114078.SU_240_145_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114079.SU_240_160_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114080.SU_240_175_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114081.SU_240_190_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114082.SU_240_205_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114083.SU_240_220_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114084.SU_280_100_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114085.SU_280_115_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114086.SU_280_130_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114087.SU_280_145_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114088.SU_280_160_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114089.SU_280_175_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114090.SU_280_190_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114091.SU_280_205_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114092.SU_280_220_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114093.SU_280_250_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114094.SU_280_280_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114095.SU_280_310_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114096.SU_280_340_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114097.SU_320_100_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114098.SU_320_115_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114099.SU_320_130_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114100.SU_320_145_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114101.SU_320_160_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114102.SU_320_175_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114103.SU_320_190_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114104.SU_320_205_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114105.SU_320_220_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114106.SU_360_100_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114107.SU_360_115_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114108.SU_360_130_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114109.SU_360_145_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114110.SU_360_160_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114111.SU_360_175_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114112.SU_360_190_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114113.SU_360_205_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114114.SU_360_220_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114115.SU_360_250_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114116.SU_360_280_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114117.SU_360_310_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114118.SU_360_340_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114119.SU_400_100_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114120.SU_400_115_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114121.SU_400_130_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114122.SU_400_145_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114123.SU_400_160_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114124.SU_400_175_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V2/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114125.SU_400_190_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114126.SU_400_205_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114127.SU_400_220_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114128.SU_40_100_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114129.SU_40_115_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114130.SU_40_130_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114131.SU_40_145_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114132.SU_40_160_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114133.SU_40_175_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114134.SU_40_190_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114135.SU_40_205_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114136.SU_40_220_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114137.SU_40_250_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114138.SU_40_280_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114139.SU_40_310_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114140.SU_40_340_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114141.SU_440_100_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114142.SU_440_115_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114143.SU_440_130_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114144.SU_440_145_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114145.SU_440_160_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114146.SU_440_175_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114147.SU_440_190_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114148.SU_440_205_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V4/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114149.SU_440_220_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114150.SU_440_250_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114151.SU_440_280_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114153.SU_440_340_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114154.SU_520_100_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114155.SU_520_130_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114156.SU_520_160_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114157.SU_520_190_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114158.SU_520_220_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114159.SU_520_250_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114160.SU_520_280_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114161.SU_520_310_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114162.SU_520_340_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114163.SU_600_100_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114164.SU_600_130_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114165.SU_600_160_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114166.SU_600_190_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114167.SU_600_220_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114168.SU_600_250_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114169.SU_600_280_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114170.SU_600_310_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114171.SU_600_340_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V2/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114172.SU_680_100_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V2/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114173.SU_680_130_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114174.SU_680_160_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114175.SU_680_190_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114176.SU_680_220_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114177.SU_680_250_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114178.SU_680_280_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114179.SU_680_310_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114180.SU_680_340_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V2/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114181.SU_760_100_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114182.SU_760_130_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114183.SU_760_160_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114184.SU_760_190_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114185.SU_760_220_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114186.SU_760_250_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114187.SU_760_280_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114188.SU_760_310_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114189.SU_760_340_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114190.SU_80_100_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114191.SU_80_115_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114192.SU_80_130_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114193.SU_80_145_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114194.SU_80_160_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114195.SU_80_175_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114196.SU_80_190_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114197.SU_80_205_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114198.SU_80_220_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114199.SU_840_100_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114200.SU_840_130_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114201.SU_840_160_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114202.SU_840_190_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114203.SU_840_220_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114204.SU_840_250_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114205.SU_840_280_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114206.SU_840_310_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114207.SU_840_340_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114208.SU_920_100_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114209.SU_920_130_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114210.SU_920_160_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114211.SU_920_190_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114212.SU_920_220_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114213.SU_920_250_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114214.SU_920_280_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114215.SU_920_310_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");
filename.push_back("user.ctopfel.SUSYD3PD.mc09_7TeV.114216.SU_920_340_0_3_herwigpp_susy.merge.AOD.e542_s765_s767_r1302_r1306.000614.V1/*.root*");


/*
path = "/data/etp/thomas.andreas.mueller/data/D3PD/MSSM-lepton-grid/";
   
filename.push_back("mc09_7TeV.114217.MSSM24_000_jimmy_susy.merge.NTUP_SUSY.e556_s765_s767_r1302_r1306_p305_tid188574_00/*.root*");
filename.push_back("mc09_7TeV.114218.MSSM24_001_jimmy_susy.merge.NTUP_SUSY.e556_s765_s767_r1302_r1306_p305_tid188575_00/*.root*");
filename.push_back("mc09_7TeV.114219.MSSM24_002_jimmy_susy.merge.NTUP_SUSY.e556_s765_s767_r1302_r1306_p305_tid188576_00/*.root*");
filename.push_back("mc09_7TeV.114220.MSSM24_003_jimmy_susy.merge.NTUP_SUSY.e556_s765_s767_r1302_r1306_p305_tid188577_00/*.root*");
filename.push_back("mc09_7TeV.114221.MSSM24_004_jimmy_susy.merge.NTUP_SUSY.e556_s765_s767_r1302_r1306_p305_tid188578_00/*.root*");
filename.push_back("mc09_7TeV.114222.MSSM24_005_jimmy_susy.merge.NTUP_SUSY.e556_s765_s767_r1302_r1306_p305_tid188579_00/*.root*");
filename.push_back("mc09_7TeV.114223.MSSM24_006_jimmy_susy.merge.NTUP_SUSY.e556_s765_s767_r1302_r1306_p305_tid188580_00/*.root*");
filename.push_back("mc09_7TeV.114224.MSSM24_007_jimmy_susy.merge.NTUP_SUSY.e556_s765_s767_r1302_r1306_p305_tid188581_00/*.root*");
filename.push_back("mc09_7TeV.114225.MSSM24_008_jimmy_susy.merge.NTUP_SUSY.e556_s765_s767_r1302_r1306_p305_tid188582_00/*.root*");
filename.push_back("mc09_7TeV.114226.MSSM24_009_jimmy_susy.merge.NTUP_SUSY.e556_s765_s767_r1302_r1306_p305_tid188583_00/*.root*");
filename.push_back("mc09_7TeV.114227.MSSM24_010_jimmy_susy.merge.NTUP_SUSY.e556_s765_s767_r1302_r1306_p305_tid188584_00/*.root*");
filename.push_back("mc09_7TeV.114228.MSSM24_011_jimmy_susy.merge.NTUP_SUSY.e556_s765_s767_r1302_r1306_p305_tid188585_00/*.root*");
filename.push_back("mc09_7TeV.114229.MSSM24_012_jimmy_susy.merge.NTUP_SUSY.e556_s765_s767_r1302_r1306_p305_tid188586_00/*.root*");
filename.push_back("mc09_7TeV.114230.MSSM24_013_jimmy_susy.merge.NTUP_SUSY.e556_s765_s767_r1302_r1306_p305_tid188587_00/*.root*");
filename.push_back("mc09_7TeV.114231.MSSM24_014_jimmy_susy.merge.NTUP_SUSY.e556_s765_s767_r1302_r1306_p305_tid188588_00/*.root*");
filename.push_back("mc09_7TeV.114232.MSSM24_015_jimmy_susy.merge.NTUP_SUSY.e556_s765_s767_r1302_r1306_p305_tid188589_00/*.root*");
filename.push_back("mc09_7TeV.114233.MSSM24_016_jimmy_susy.merge.NTUP_SUSY.e556_s765_s767_r1302_r1306_p305_tid188590_00/*.root*");
filename.push_back("mc09_7TeV.114234.MSSM24_017_jimmy_susy.merge.NTUP_SUSY.e556_s765_s767_r1302_r1306_p305_tid188591_00/*.root*");
filename.push_back("mc09_7TeV.114235.MSSM24_018_jimmy_susy.merge.NTUP_SUSY.e556_s765_s767_r1302_r1306_p305_tid188592_00/*.root*");
filename.push_back("mc09_7TeV.114236.MSSM24_019_jimmy_susy.merge.NTUP_SUSY.e556_s765_s767_r1302_r1306_p305_tid188593_00/*.root*");
filename.push_back("mc09_7TeV.114237.MSSM24_020_jimmy_susy.merge.NTUP_SUSY.e556_s765_s767_r1302_r1306_p305_tid189994_00/*.root*");
filename.push_back("mc09_7TeV.114238.MSSM24_021_jimmy_susy.merge.NTUP_SUSY.e556_s765_s767_r1302_r1306_p305_tid189995_00/*.root*");
filename.push_back("mc09_7TeV.114239.MSSM24_022_jimmy_susy.merge.NTUP_SUSY.e556_s765_s767_r1302_r1306_p305_tid189996_00/*.root*");
filename.push_back("mc09_7TeV.114240.MSSM24_023_jimmy_susy.merge.NTUP_SUSY.e556_s765_s767_r1302_r1306_p305_tid189997_00/*.root*");
filename.push_back("mc09_7TeV.114241.MSSM24_024_jimmy_susy.merge.NTUP_SUSY.e556_s765_s767_r1302_r1306_p305_tid189998_00/*.root*");
filename.push_back("mc09_7TeV.114242.MSSM24_025_jimmy_susy.merge.NTUP_SUSY.e556_s765_s767_r1302_r1306_p305_tid189999_00/*.root*");
filename.push_back("mc09_7TeV.114243.MSSM24_026_jimmy_susy.merge.NTUP_SUSY.e556_s765_s767_r1302_r1306_p305_tid190000_00/*.root*");
filename.push_back("mc09_7TeV.114244.MSSM24_027_jimmy_susy.merge.NTUP_SUSY.e556_s765_s767_r1302_r1306_p305_tid190001_00/*.root*");
filename.push_back("mc09_7TeV.114245.MSSM24_028_jimmy_susy.merge.NTUP_SUSY.e556_s765_s767_r1302_r1306_p305_tid190002_00/*.root*");
filename.push_back("mc09_7TeV.114246.MSSM24_029_jimmy_susy.merge.NTUP_SUSY.e556_s765_s767_r1302_r1306_p305_tid190003_00/*.root*");         
*/  
// DATA 
/*
path = "/data/etp/zhuangxa/trimmed/";
   
//filename.push_back("Egamma/user.xuai.SUSYD3PD.data10_7TeV.periodE.physics_Egamma.t0pro04_v01.DAOD_SUSY.000614.TRIMMED.13.11/*.root*"); 
//filename.push_back("Egamma/user.xuai.SUSYD3PD.data10_7TeV.periodF.physics_Egamma.t0pro04_v01.DAOD_SUSY.000614.TRIMMED.14.1/*.root*"); 
//filename.push_back("Egamma/user.xuai.SUSYD3PD.data10_7TeV.periodG.physics_Egamma.t0pro04_v01.DAOD_SUSY.000614.TRIMMED.13.11/*.root*"); 
//filename.push_back("Egamma/user.xuai.SUSYD3PD.data10_7TeV.periodH.physics_Egamma.t0pro04_v01.DAOD_SUSY.000614.TRIMMED.13.11/*.root*"); 
//filename.push_back("Muon/user.xuai.SUSYD3PD.data10_7TeV.periodE.physics_Muons.t0pro04_v01.DAOD_SUSY.000614.TRIMMED.14.1/*.root*"); 
filename.push_back("Muon/user.xuai.SUSYD3PD.data10_7TeV.periodF.physics_Muons.t0pro04_v01.DAOD_SUSY.000614.TRIMMED.14.1/*.root*"); 
//filename.push_back("Muon/user.xuai.SUSYD3PD.data10_7TeV.periodG.physics_Muons.t0pro04_v01.DAOD_SUSY.000614.TRIMMED.14.1/*.root*"); 
//filename.push_back("Muon/user.xuai.SUSYD3PD.data10_7TeV.periodH.physics_Muons.t0pro04_v01.DAOD_SUSY.000614.TRIMMED.14.1/*.root*"); 
/*
path = "dcap://lcg-lrz-dcache.grid.lrz-muenchen.de:22125//pnfs/lrz-muenchen.de/data/atlas/dq2/atlaslocalgroupdisk/group10/phys-susy/SUSYD3PD/";
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00049.root");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00010.root");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00052.root.1");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00008.root");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00037.root");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00054.root.2");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00031.root");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00007.root");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00048.root.2");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00056.root");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00039.root");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00013.root");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00028.root");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00027.root");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00043.root");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00021.root.1");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00005.root");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00018.root");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00057.root");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00045.root");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00003.root");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00038.root");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00030.root");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00016.root");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00026.root");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00050.root");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00009.root");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00024.root");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00034.root");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00029.root");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00046.root");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00051.root.2");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00002.root");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00035.root");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00025.root.1");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00020.root.1");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00042.root");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00047.root.1");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00033.root");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00041.root");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00011.root");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00053.root.2");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00032.root");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00036.root");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00022.root");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00023.root");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00055.root.2");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00044.root");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00040.root");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00006.root.1");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00014.root");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00019.root.1");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00015.root");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00004.root");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00001.root");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00017.root");
filename.push_back("group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2/group10.phys-susy.SUSYD3PD.data10_7TeV.00162882.physics_Muons.merge.AOD.f287_m588.V2.1_D2PDSUSY_V1.000614.V2.D3PD._00012.root");
*/
   
   TChain* c; 

  cout << "Processing files: "<<filename.size()<<endl;

  
for (int i = 0; i < filename.size() ; i++){
    
  c = new TChain("susy");
    
  cout << "Opening "<<path+filename[i]<<endl;
  c->Add(path+filename[i]);


/********** PROOF *********/
  if (proof){  
    p = TProof::Open(""); 
//    p->SetParallel(4);
    c->SetProof();
  }

//  c->Add(filename[i]);
  c->Process("D3PDSelector.C+O");
  c->Delete();

  cout << "done processing file "<<(i+1)<<endl;
}//end loop over all files
 
 
  //to run on not slimmed D3PDs
/*
  TChain* c; 
      
  c = new TChain("susy");
  
//  c->Add("/data/etp1/flegger/user.BorgeKileGjelsten.SUSYD3PD.mc09_7TeV.108319.PythiaDrellYan_mumu.merge.AOD.e518_s765_s767_r1302_r1306.000505.V1/*.root");
//  c->Add("/data/etp1/flegger/user.BorgeKileGjelsten.SUSYD3PD.mc09_7TeV.108320.PythiaDrellYan_ee.merge.AOD.e518_s765_s767_r1302_r1306.000505.V1/*.root");
//  c->Add("/data/etp1/flegger/user.BorgeKileGjelsten.SUSYD3PD.mc09_7TeV.108321.PythiaDrellYanLowM_mu3.merge.AOD.e518_s765_s767_r1302_r1306.000504.V2/*.root");
//  c->Add("/data/etp1/flegger/user.BorgeKileGjelsten.SUSYD3PD.mc09_7TeV.108322.PythiaDrellYanLowM_ee3.merge.AOD.e518_s765_s767_r1302_r1306.000504.V2/*.root");



  c->Process("D3PDSelector.C+");
  c->Delete();
*/
  
cout << "All done!"<<endl;
 
}



