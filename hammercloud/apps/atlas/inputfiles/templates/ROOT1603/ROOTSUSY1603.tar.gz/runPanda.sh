#!/bin/bash
root -l -b runPanda.C
