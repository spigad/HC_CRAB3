#!/bin/bash
export S3_ACCESS_ID=system:test
export S3_ACCESS_KEY=testroot
root -l -b runGanga.C
