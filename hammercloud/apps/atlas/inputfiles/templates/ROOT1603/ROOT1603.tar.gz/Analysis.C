#include <iostream>
#include <exception>
#include "Analysis.h"
#include "TGraph.h"
#include "TMarker.h"
#include "TCanvas.h"
#include "TText.h"
#include "TBox.h"
#include "TMatrixDSym.h"
#include "TMatrixDSymEigen.h"
#include "TLorentzVector.h"

#define KEEP_EVENT 0 //used in Pre_OPS_OR
#define SKIP_EVENT 1

int trig_el = 0;
int trig_mu = 0;

int nbevents;
int final_cutflow[12];
bool verbose = false;
const float Z_mass = 91187;

const char *name_cutflow[]={"no cut","crack veto","preselection","Z veto","transv mass > m_W","MET > 60 GeV", "1 jet with pt > 100 GeV ","  ","  ","  "," "," "};

using namespace std;


/* Here is the place where histograms and variables such as cutflows should be defined */

Analysis::Analysis(D3PDSelector * inst)
{
  //Constructor. The constructor is called from SlaveBegin in the D3PDSelector
  
  m_sel = inst; //MANDATORY. The D3PDSelector Object must be known to the Analysis Class.

  //
  grlR = new Root::TGoodRunsListReader();
  //string sname = "/nobackup/etp2/elmsheus/athena/16.0.2-fe/WW_GRL_periods_A-I.xml";
  string sname = "WW_GRL_periods_A-I.xml";
  cout << "XML to load: " << sname.c_str() << endl;
  grlR->SetXMLFile(sname.c_str());
  grlR->Interpret();
  grl = grlR->GetMergedGoodRunsList();
  grl.Summary();

  //The selector class needs to know which are the prefixes for the particles objects.
  m_sel->SetElectronContainerPrefix("el");
  m_sel->SetMuonContainerPrefix("mu_staco");
  //m_sel->SetJetContainerPrefix("jet_AntiKt4H1Topo");
  m_sel->SetJetContainerPrefix("jet_antikt4h1topo");
  //m_sel->SetPhotonContainerPrefix("ph");
  
  // Let's create a histogram and register it with the D3PD Class
  meff = new TH1F("meff4","meff4",2000,0,4000);  

  // Electrons
  n_e = new TH1F("n_e","n_e", 10, -0.5, 9.5);  

  pt_e = new TH1F("pt_e","pt_e", 100, 0., 100.);  
  pt_e_1 = new TH1F("pt_e_1","pt_e_1", 100, 0., 100.);  
  pt_e_2 = new TH1F("pt_e_2","pt_e_2", 100, 0., 100.);  
  pt_e_cl = new TH1F("pt_e_cl","pt_e_cl", 100,0., 100.);  

  eta_e = new TH1F("eta_e","eta_e", 60 ,-3., 3.);  
  phi_e = new TH1F("phi_e","phi_e", 32 , -3.1415, 3.1414);  

  pt_e_trig = new TH1F("pt_e_trig","pt_e_trig", 100,0., 100.);  

  invmass_ee = new TH1F("invmass_ee","invmass_ee", 50,0., 150.);  

  // Muons
  n_mu = new TH1F("n_mu","n_mu", 10, -0.5, 9.5);  

  pt_mu_trig = new TH1F("pt_mu_trig","pt_mu_trig", 100,0., 100.);  
  pt_mu = new TH1F("pt_mu","pt_mu", 100, 0., 100. );  
  pt_mu_1 = new TH1F("pt_mu_1","pt_mu_1", 100, 0., 100.);  
  pt_mu_2 = new TH1F("pt_mu_2","pt_mu_2", 100, 0., 100.);  

  eta_mu = new TH1F("eta_mu","eta_mu", 60 ,-3., 3.);  
  phi_mu = new TH1F("phi_mu","phi_mu", 32 , -3.1415, 3.1414);  

  invmass_mumu = new TH1F("invmass_mumu","invmass_mumu", 50,0., 150.);  

  // Jets
  n_jets = new TH1F("n_jets","n_jets", 10, -0.5, 9.5);  
  jet_RelPosUncert = new TH1F("jet_RelPosUncert","jet_RelPosUncert", 100, -0.5, 0.5);  
  jet_RelNegUncert = new TH1F("jet_RelNegUncert","jet_RelNegUncert", 100, -0.5, 0.5);  

  //Creating the histogram. Remember the name you give it (meff4), you will later retrieve it in the static method postAnalysis(TSelectorList* fOutput)
  
  m_sel->AddTObject(meff); 

  m_sel->AddTObject(n_e); 
  m_sel->AddTObject(pt_e); 
  m_sel->AddTObject(pt_e_1); 
  m_sel->AddTObject(pt_e_2); 
  m_sel->AddTObject(pt_e_cl); 
  m_sel->AddTObject(eta_e); 
  m_sel->AddTObject(phi_e); 
  m_sel->AddTObject(pt_e_trig); 
  m_sel->AddTObject(invmass_ee); 

  m_sel->AddTObject(n_mu); 
  m_sel->AddTObject(pt_mu_trig); 
  m_sel->AddTObject(pt_mu); 
  m_sel->AddTObject(pt_mu_1); 
  m_sel->AddTObject(pt_mu_2); 
  m_sel->AddTObject(eta_mu); 
  m_sel->AddTObject(phi_mu); 
  m_sel->AddTObject(invmass_mumu); 

  m_sel->AddTObject(n_jets); 
  m_sel->AddTObject(jet_RelPosUncert); 
  m_sel->AddTObject(jet_RelNegUncert ); 

  //Registering the histogram with the D3PDSelector
  // WHY?
  // When using Proof, the D3PD Selecter adds this Object to the OutputList
  // Proof automatically merges these Objects at the end, and you get the Ouput list in the static method   postAnalysis(TSelectorList* fOutput)


  //resetting cutflow variables
  nbevents = 0;
  for (int cf = 0; cf < 12 ; cf++) m_cutflow[cf] = 0;
  for (int cf = 0; cf < 12 ; cf++) final_cutflow[cf] = 0;

  //myUncertainty = new MultijetJESUncertaintyProvider("AntiKt4H1TopoJets");
  //myUncertainty->init();

}

/* Here is if you want to know what happens before object preselection (for example access to original variables in the ROOT ntuple) */
 
unsigned int Analysis::Pre_OPS_OR(Long64_t entry)
{
  
  //(void)entry; //avoid compiler warnings
   
  // Method executed from Process in D3PDSelector, before OPS and OR
  if (entry % 1000 == 0) cout << "Processing event "<< entry << endl;

  runNumber = m_sel->GetScalarVal<int>("RunNumber");  
  eventNumber = m_sel->GetScalarVal<int>("EventNumber");  
  lumiBlockNumber = m_sel->GetScalarVal<int>("lbn"); 

  // Check GRL
  if (!grl.HasRunLumiBlock(runNumber, lumiBlockNumber)) {
    if (verbose) cout << "GRL skip event" << endl;
    return SKIP_EVENT; 
  }

  //gettign mc event weight
  double mc_event_weight = 0;
  //try {
  //  std::vector<double> mcevt_weight = m_sel->GetRawVector< std::vector<double> >( "mcevt_weight" );
  //  mc_event_weight = mcevt_weight.at(0);
  //} catch (exception& e) {
  //  cout << "mcevt_weight not in ntuple!" << endl;
  //}


  m_cutflow[0] += (int)mc_event_weight; //cutflow entry for no cut 
  final_cutflow[0] = m_cutflow[0];
  nbevents++;  

  std::string trig_name_el = "EF_e10_medium"; 
  trig_el = m_sel->GetScalarVal<int>(trig_name_el);

  std::string trig_name_mu = "L1_MU6"; 
  trig_mu = m_sel->GetScalarVal<int>(trig_name_mu);

  /*
  if (trig_el) {
    std::cout << "triggered" << std::endl;
  }
  else {
    std::cout << "not triggered" << std::endl;
  }
  */

  return KEEP_EVENT; 

}

/* Here is if you want to know what happens AFTER object preselection but BEFORE overlap removal */


unsigned int Analysis::Between_OPS_and_OR(Long64_t entry) 
{
   (void)entry; //avoid compiler warnings

   // otx and crack veto
   //int run = 999999;  // use latest OTX map
   int run = runNumber;  // for data 

   //egammaOQ::LoadOQMaps(run);

   return KEEP_EVENT;
}

/* Here comes your analysis code, AFTER object preselection and overlap removal.
   The objects saved after OPS and OR have 'Fin' (final) in the name */


void Analysis::doAnalysis(Long64_t entry)
{
  
  if (verbose)  std::cout << "Entry " << entry << " in Analysis (after OPS and OR) " << std::endl;

  //Now we perform cutflow study
  
  //MC Weight 
  double mc_event_weight = 0;
  //try {
  //  std::vector<double> mcevt_weight = m_sel->GetRawVector< std::vector<double> >( "mcevt_weight" );
  //  mc_event_weight = mcevt_weight.at(0);
  //} catch (exception& e) {
  //  cout << "mcevt_weight not in ntuple!" << endl;
  //  }

  //end Weight
  
  m_cutflow[1]+= (int)mc_event_weight; //events after OPS and OR
  final_cutflow[1] = m_cutflow[1];
  
  unsigned int n_ele = m_sel->GetFinSizeByType("ELE"); //final electrons 
  unsigned int n_muo = m_sel->GetFinSizeByType("MUO"); //final muons
  unsigned int n_jet = m_sel->GetFinSizeByType("JET"); //final jets

  // Electrons =================================================================
  float ele_pt[n_ele];
  float ele_charge[n_ele];
  int e1_ch = 0; 
  int e2_ch = 0;
  int e_ch = 0;

  TLorentzVector e(0,0,0,0); 
  TLorentzVector e1(0,0,0,0); 
  TLorentzVector e2(0,0,0,0); 
  
  if (n_ele){

    n_e->Fill(n_ele);
    
    for (unsigned int i = 0; i < n_ele; i++){
      float eta_cl = m_sel->GetFinValByType<float>("ELE", "_cl_eta", i);
      float E_cl = m_sel->GetFinValByType<float>("ELE", "_cl_E", i);
      float theta_cl = 2*atan(exp(-eta_cl));
      float pt_cl = E_cl * sin(theta_cl);

      pt_e_cl->Fill(pt_cl/1000.);

      ele_pt[i] = m_sel->GetFinValByType<float>("ELE", "_pt", i); 
      ele_charge[i] = m_sel->GetFinValByType<float>("ELE", "_charge", i); 

      pt_e->Fill(ele_pt[i]/1000.);
      if (trig_el) {
	pt_e_trig->Fill(ele_pt[i]/1000.);

      }

      e.SetPxPyPzE( m_sel->GetFinValByType<float>("ELE", "_px",i),
		     (m_sel->GetFinValByType<float>("ELE", "_py", i)),
		     (m_sel->GetFinValByType<float>("ELE", "_pz", i)),
		     (m_sel->GetFinValByType<float>("ELE", "_E", i)));  
      e_ch = ele_charge[i];

      if (e.Pt()>e1.Pt()) {
	 e2 = e1;
	 e1 = e;

	 e2_ch = e1_ch;
	 e1_ch = e_ch;

       }
       else if((e.Pt()>e2.Pt()) && (e.Pt() < e1.Pt())) {
	 e2 = e;
	 e2_ch = e_ch;

       }
    }

    if (e1.Pt()>0) {
      pt_e_1->Fill(e1.Pt()/1000.);
      eta_e->Fill(e1.Eta());
      phi_e->Fill(e1.Phi());
    }

    if (e2.Pt()>0) { 
      pt_e_2->Fill(e2.Pt()/1000.);
      eta_e->Fill(e2.Eta());
      phi_e->Fill(e2.Phi());

    }

    if (e1_ch*e2_ch == -1 ) {
      invmass_ee->Fill((e1+e2).M()/1000.);
    }

  }

  // Muons =============================================================
  float muo_pt[n_muo];
  float muo_charge[n_muo];
  int mu1_ch = 0;
  int mu2_ch = 0;
  int mu_ch = 0;

  TLorentzVector mu(0,0,0,0); 
  TLorentzVector mu1(0,0,0,0); 
  TLorentzVector mu2(0,0,0,0); 

  if (n_muo){

    n_mu->Fill(n_muo);
    
    for (unsigned int i = 0; i < n_muo; i++){

      muo_pt[i] = m_sel->GetFinValByType<float>("MUO", "_pt", i); 
      muo_charge[i] = m_sel->GetFinValByType<float>("MUO", "_charge", i); 

      pt_mu->Fill(muo_pt[i]/1000.);
      if (trig_mu) {
	pt_mu_trig->Fill(muo_pt[i]/1000.);

      }

      mu.SetPxPyPzE( m_sel->GetFinValByType<float>("MUO", "_px",i),
		     (m_sel->GetFinValByType<float>("MUO", "_py", i)),
		     (m_sel->GetFinValByType<float>("MUO", "_pz", i)),
		     (m_sel->GetFinValByType<float>("MUO", "_E", i)));  
      mu_ch = muo_charge[i];

      if (mu.Pt()>mu1.Pt()) {
	 mu2 = mu1;
	 mu1 = mu;

	 mu2_ch = mu1_ch;
	 mu1_ch = mu_ch;

       }
       else if((mu.Pt()>mu2.Pt()) && (mu.Pt() < mu1.Pt())) {
	 mu2 = mu;
	 mu2_ch = mu_ch;

       }
    }

    if (mu1.Pt()>0) {
      pt_mu_1->Fill(mu1.Pt()/1000.);
      eta_mu->Fill(mu1.Eta());
      phi_mu->Fill(mu1.Phi());
    }

    if (mu2.Pt()>0) { 
      pt_mu_2->Fill(mu2.Pt()/1000.);
      eta_mu->Fill(mu2.Eta());
      phi_mu->Fill(mu2.Phi());

    }

    if (mu1_ch*mu2_ch == -1. ) {
      invmass_mumu->Fill((mu1+mu2).M()/1000.);
    }

  }

  // Jets =============================================================

  if (n_jet) {
    float jet_pt[n_jet];
    float jet_eta;

    n_jets->Fill(n_jet);

    for (unsigned int i = 0; i < n_jet; i++){

      jet_pt[i] = m_sel->GetFinValByType<float>("JET", "_pt", i); 
      jet_eta = m_sel->GetFinValByType<float>("JET", "_eta", i); 

      //cout << jet_pt[i]  << " " << jet_eta << endl;

      //jet_RelPosUncert->Fill( myUncertainty->getRelPosUncert(jet_pt[i], jet_eta));
      //jet_RelNegUncert->Fill( myUncertainty->getRelNegUncert(jet_pt[i], jet_eta));

    }
  }

  //Preselection Cut
  m_cutflow[2]+= (int)mc_event_weight; // cut on number of leptons
  final_cutflow[2] = m_cutflow[2];


  //  Z Veto 

  m_cutflow[3]+= (int)mc_event_weight; 
  final_cutflow[3] = m_cutflow[3];

 
  // Transverse mass
  
  
  m_cutflow[4]+= (int)mc_event_weight; 
  final_cutflow[4] = m_cutflow[4];

  // MET cut

 
  m_cutflow[5]+= (int)mc_event_weight; 
  final_cutflow[5] = m_cutflow[5];
  
  //Jet cuts
  

  m_cutflow[6]+= (int)mc_event_weight; 
  final_cutflow[6] = m_cutflow[6];

  
  //Fill histogram
  
  m_meff = 1000.;
  meff->Fill(m_meff);


}


void Analysis::finalizeEvent(Long64_t entry)
{

  if (verbose){
    std::cout << "Cutflow after Event " << entry << " for two lepton selection "  << std::endl;
    for (int cf = 0; cf < 12 ; cf++)  
      std::cout << "Cut " << cf << ": " <<  m_cutflow[cf] << std::endl;
  }

  return;

}

/* After the analysis: retrieve histograms and draw them or save them in a file */

/*static*/ void Analysis::postAnalysis (TSelectorList* fOutput)
{
  // (void)fOutput; //avoid compiler warnings

  TFile *histofile = new TFile("histos.root","RECREATE");
  
  //Lets get our meff4 plot from above (which at this stage will be merged)
  TH1F * dada = (TH1F*)fOutput->FindObject("meff4")->Clone();

  // Electrons
  TH1F * dada1 = (TH1F*)fOutput->FindObject("n_e")->Clone();

  cout << dada1->GetMean() << endl;

  TH1F * dada2 = (TH1F*)fOutput->FindObject("pt_e")->Clone();
  TH1F * dada3 = (TH1F*)fOutput->FindObject("pt_e_trig")->Clone();
  TH1F * dada4 = (TH1F*)fOutput->FindObject("invmass_ee")->Clone();

  TH1F *pt_e_eff = new TH1F("pt_e_eff","pt_e_eff", 100, 0., 100.);  

  TH1F * dada5 = (TH1F*)fOutput->FindObject("pt_e_1")->Clone();
  TH1F * dada6 = (TH1F*)fOutput->FindObject("pt_e_2")->Clone();
  TH1F * dada7 = (TH1F*)fOutput->FindObject("eta_e")->Clone();
  TH1F * dada8 = (TH1F*)fOutput->FindObject("phi_e")->Clone();

  TH1F * dada9 = (TH1F*)fOutput->FindObject("pt_e_cl")->Clone();

  dada2->Sumw2();
  dada3->Sumw2();

  pt_e_eff->Divide(dada3,dada2,1.,1.,"B");

  // Muons
  TH1F * damu1 = (TH1F*)fOutput->FindObject("n_mu")->Clone();

  //cout << damu1->GetMean() << endl;

  TH1F * damu2 = (TH1F*)fOutput->FindObject("pt_mu")->Clone();
  TH1F * damu3 = (TH1F*)fOutput->FindObject("pt_mu_trig")->Clone();
  TH1F * damu4 = (TH1F*)fOutput->FindObject("invmass_mumu")->Clone();

  TH1F *pt_mu_eff = new TH1F("pt_mu_eff","pt_mu_eff", 100, 0., 100.);  

  TH1F * damu5 = (TH1F*)fOutput->FindObject("pt_mu_1")->Clone();
  TH1F * damu6 = (TH1F*)fOutput->FindObject("pt_mu_2")->Clone();
  TH1F * damu7 = (TH1F*)fOutput->FindObject("eta_mu")->Clone();
  TH1F * damu8 = (TH1F*)fOutput->FindObject("phi_mu")->Clone();

  damu2->Sumw2();
  damu3->Sumw2();

  pt_mu_eff->Divide(damu3,damu2,1.,1.,"B");
 
  // Jets
  TH1F * dajet1 = (TH1F*)fOutput->FindObject("n_jets")->Clone();
  TH1F * dajet2 = (TH1F*)fOutput->FindObject("jet_RelPosUncert")->Clone();
  TH1F * dajet3 = (TH1F*)fOutput->FindObject("jet_RelNegUncert")->Clone();
 
  //We create a Canvas
  TCanvas *can1 = new TCanvas("Electrons","Electrons", 1200, 800);
  can1->Divide(4,3);

  TCanvas *can2 = new TCanvas("Muons","Muons", 1200, 800);
  can2->Divide(4,3);

  TCanvas *can3 = new TCanvas("Jets","Jets", 1200, 800);
  can3->Divide(4,3);

  //And eventually we draw the meff plot.
  can1->cd(1);
  dada1->Draw();
  
  can1->cd(2);
  dada2->Draw();

  can1->cd(3);
  dada3->Draw();

  can1->cd(4);
  pt_e_eff->Draw();

  can1->cd(5);
  dada4->Draw();

  can1->cd(6);
  dada5->Draw();

  can1->cd(7);
  dada6->Draw();

  can1->cd(8);
  dada7->Draw();

  can1->cd(9);
  dada8->Draw();

  can1->cd(10);
  dada9->Draw();

  can1->cd(11);
  dada->Draw();

  //can1->Update();
  //can1->Show();

  // Canvas can2
  can2->cd(1);
  damu1->Draw();
  
  can2->cd(2);
  damu2->Draw();

  can2->cd(3);
  damu3->Draw();

  can2->cd(4);
  pt_mu_eff->Draw();

  can2->cd(5);
  damu4->Draw();

  can2->cd(6);
  damu5->Draw();

  can2->cd(7);
  damu6->Draw();

  can2->cd(8);
  damu7->Draw();

  can2->cd(9);
  damu8->Draw();

  //can2->Update();
  //can2->Show();

  // Canvas can3
  can3->cd(1);
  dajet1->Draw();
  
  can3->cd(2);
  dajet2->Draw();

  can3->cd(3);
  dajet3->Draw();

  histofile->Write();
  histofile->Close();

  std::cout << "Final Cutflow after "<<nbevents<<" events for two lepton selection "  << std::endl;
  
  
  for (int cf = 0; cf < 12; cf++)
  {
    std::cout << "Cut " << cf << ": " <<  final_cutflow[cf] << "               "<< name_cutflow[cf]<<std::endl;
  }
  


  
  return;

}


