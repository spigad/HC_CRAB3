#define KEEP 0
#define REJECT 1
#define PRE_SKIP_EVENT 2

#include "robustIsEMDefs.C"


class MyObjectPreSelection : public ObjectPreSelection
{

  public:

    MyObjectPreSelection(D3PDSelector* inst) : ObjectPreSelection(inst) {};
    //Mandatory

 
    void objectPreSelectionOrder()
    {
      //In this method which is called by the D3PD Selector, we define the order of how to execute 
      //the Object Preselection
      
      //We can do multiple iterations by giving an integer argument to the method.
      //This can later be reused to differentiate between the iterations
      //This is not used in the OPS example, but in the OR example
      
      do_Electron(1);
      do_Muon(1);
      do_Jet(1);
      //do_Photon(1);
      
    }

    unsigned int Electron_OPS(ObjAccess* ele, unsigned int  iteration)
    {
      (void)iteration; //avoid compiler warnings
      
      //The OPS methods return 0 if the obejct is to be kept, and 1 if it is to be rejected

      //Checking author (must be 1 or 3)
      //we can access any variable. However DO NOT CROSS-ACCESS different particle types, e.g. accessing muon variables in the Electron OPS method. This will mess up the internal ordering!!!
      
      //see
      // https://twiki.cern.ch/twiki/bin/view/AtlasProtected/SusyObjectDefintions

      
      int author = ele->GetValue<int>("_author");
      //if (author!=1 && author !=3) return REJECT;
      if  (!(author==1 || author == 3)) return REJECT;

      //float pt = ele->GetValue<float>("_pt");
      //if ( fabs(pt) <= 10000. ) return REJECT;

      float eta = ele->GetValue<float>("_cl_eta");
      if ( fabs(eta) >= 2.47 ) return REJECT;

      float phi = ele->GetValue<float>("_cl_phi");

      float E = ele->GetValue<float>("_cl_E");

      float theta = 2*atan(exp(-eta));
      float pt = E * sin(theta);
      if ( fabs(pt) <= 10000. ) return REJECT;

      // B-layer hits
      int expHitBLayer = ele->GetValue<int>("_expectHitInBLayer");
      //int nBLHits = ele->GetValue<int>("_nBLHits");
      //if (expHitBLayer && nBLHits == 0) return REJECT;

      //isRobustMedium or isRobusterTight          
      int isEM    = ele->GetValue<int>("_isEM");
      float cl_E  = ele->GetValue<float>("_cl_E");
      float etas2 = ele->GetValue<float>("_etas2");
      float Reta  = ele->GetValue<float>("_reta");
      float w2    = ele->GetValue<float>("_weta2");      
      float eT    = cl_E / cosh(etas2);

      //if (!(isRobustLoose( isEM,  etas2,  eT,  Reta, w2 ))) return REJECT;  
      //if (!(isRobustMedium( isEM,  etas2,  eT,  Reta, w2 ))) return REJECT;  
      if (!(isRobusterTight( isEM, expHitBLayer, etas2,  eT,  Reta, w2 ))) return REJECT;  

      // otx veto
      int RunNumber = m_selector->GetScalarVal<Int_t>("RunNumber");
      if ((RunNumber <= 150000)||(RunNumber >= 200000)){
      	int RunNumber = 999999; 
      }

      if (egammaOQ::checkOQClusterElectron(RunNumber, eta, phi)==3) return REJECT;

      // electron crack region veto 
      if (fabs(eta) > 1.37 &&  fabs(eta) < 1.52) return PRE_SKIP_EVENT;

      // impact parameter significance w.r.t primary vertex
      float trackd0pv    = ele->GetValue<float>("_trackd0pv");
      float tracksigd0pv = ele->GetValue<float>("_tracksigd0pv");
      
      if (fabs(trackd0pv / tracksigd0pv) >= 10) return REJECT;
      
      // Isolation
      float etcone30 = ele->GetValue<float>("_Etcone30");
      if (etcone30 >= 6000.) return REJECT;
     
      // INSERT CUTS HERE !!!      
      //if (cut is not satidfied) return REJECT;

      return KEEP;
    }

    unsigned int Muon_OPS(ObjAccess* muo, unsigned int  iteration)
    {
      (void)iteration; //avoid compiler warnings

      // Muon ID+MS and matching quality
      int isComMuo = muo->GetValue<int>("_isCombinedMuon");
      if (!isComMuo) return REJECT;

      float matchchi2 = muo->GetValue<float>("_matchchi2");
      if ( matchchi2 > 100. || matchchi2 < 0.) return REJECT;

      // pt
      float pt = muo->GetValue<float>("_pt");
      if ( pt <= 10000. ) return REJECT;

      // isolation
      float ptcone20 = muo->GetValue<float>("_ptcone20");
      if ( ptcone20/pt >= 0.1 ) return REJECT;
      
      // eta
      float eta = muo->GetValue<float>("_eta");
      if ( fabs(eta) >= 2.4 ) return REJECT;

      // MS and ID pt 
      float me_qoverp = muo->GetValue<float>("_me_qoverp");
      float me_theta = muo->GetValue<float>("_me_theta");
      float id_qoverp = muo->GetValue<float>("_id_qoverp");
      float id_theta = muo->GetValue<float>("_id_theta");

      float pt_ms = fabs(1.0/(me_qoverp) * sin((me_theta)));
      float pt_id = fabs(1.0/(id_qoverp) * sin((id_theta)));

      if ((abs(pt_ms - pt_id) > 15.*1000.) or (pt_ms < 10.*1000.)) return REJECT;

      // reject cosmics
      //float z0 = muo->GetValue<float>("_z0_exPV");
      //float cov_d0 = muo->GetValue<float>("_cov_d0_exPV");
      //float d0 = muo->GetValue<float>("_d0_exPV");
      //if (fabs(z0) >= 10. || cov_d0 > 0. && fabs(d0/sqrt(cov_d0)) >= 5.) return REJECT;

      // impact parameter significance wrt. Primary Vertex
      float id_d0_exPV = muo->GetValue<float>("_id_d0_exPV");
      float trackcov_d0 = muo->GetValue<float>("_trackcov_d0");
      
      if ( fabs(id_d0_exPV / sqrt(trackcov_d0)) >= 10.) return REJECT;

      // INSERT CUTS HERE !!!
      //if (cut is not satidfied) return REJECT;

       return KEEP;    
    }

    unsigned int Jet_OPS(ObjAccess* jet, unsigned int  iteration)
    {
      (void)iteration; //avoid compiler warnings

      //float eta = jet->GetValue<float>("_eta");
      //float pt = jet->GetValue<float>("_pt");

      float eta = jet->GetValue<float>("_emscale_eta");
      if ( fabs(eta) >= 3.0 ) return REJECT;

      float jes = jet->GetValue<float>("_EMJES");
      float pt = (jet->GetValue<float>("_emscale_pt"));      

      if (jes == 0.) {
	cout << "ERROR jet jes during preselection "<< jes <<endl;
      }

      pt = jes *pt;

      if ( fabs(pt) <= 20000. ) return REJECT;
      if (pt < 20000.) cout << "ERROR jet pt during preselection "<< pt << endl;
   
      // INSERT CUTS HERE !!!      
      //if (cut is not satidfied) return REJECT;
       
       
       return KEEP;    
    }

/*
    unsigned int Photon_OPS(ObjAccess* pho, unsigned int  iteration)
    {
        
      return KEEP;
    }
*/



};

