#include <iostream>
#include "Analysis.h"
#include "TGraph.h"
#include "TMarker.h"
#include "TCanvas.h"
#include "TText.h"
#include "TBox.h"
#include "TMatrixDSym.h"
#include "TMatrixDSymEigen.h"

#define KEEP_EVENT 0 //used in Pre_OPS_OR
#define SKIP_EVENT 1

#define NJETS 2
#define JETPT1_CUT 30000
#define JETPT2_CUT 20000
#define ETMISS_CUT 30000
#define ETMISSMEFF_CUT 0.3
#define INVMASS_CUT 5000

int nbevents;
int final_cutflow[12];
bool verbose = false;

using namespace std;

Analysis::Analysis(D3PDSelector * inst)
{
  //Constructor. The constructor is called from SlaveBegin in the D3PDSelector
  
  m_sel = inst; //MANDATORY. The D3PDSelector Object must be known to the Analysis Class.


  //The selector class needs to know which are the prefixes for the particles objects.
  m_sel->SetElectronContainerPrefix("el");
  m_sel->SetMuonContainerPrefix("mu");
  m_sel->SetJetContainerPrefix("jet");
  m_sel->SetPhotonContainerPrefix("ph");
  
  // Let's create a histogram and register it with the D3PD Class
  meff = new TH1F("meff4","meff4",2000,0,4000);  
  //Creating the histogram. Remember the name you give it (meff4), you will later retrieve it in the static method postAnalysis(TSelectorList* fOutput)
  
  m_sel->AddTObject(meff); 
  //Registering the histogram with the D3PDSelector
  // WHY?
  // When using Proof, the D3PD Selecter adds this Object to the OutputList
  // Proof automatically merges these Objects at the end, and you get the Ouput list in the static method   postAnalysis(TSelectorList* fOutput)


  //resetting cutflow variables
  nbevents = 0;
  for (int cf = 0; cf < 12 ; cf++) m_cutflow[cf] = 0;
  for (int cf = 0; cf < 12 ; cf++) final_cutflow[cf] = 0;
  
}
 
unsigned int Analysis::Pre_OPS_OR(Long64_t entry)
{
   (void)entry; //avoid compiler warnings
   
  // Method executed from Process in D3PDSelector, before OPS and OR
  
  //gettign mc event weight
  std::vector<double> mcevt_weight = m_sel->GetRawVector< std::vector<double> >( "mcevt_weight" );
  double mc_event_weight = mcevt_weight.at(0);

  m_cutflow[0] += (int)mc_event_weight; //cutflow entry for no cut 
  final_cutflow[0] = m_cutflow[0];
  nbevents++;  

//for event 189, we draw a eta/phi plot before OPS. 
/*  if (entry == 7076)
  {
    drawEtaPhi(entry,1); 
    //Drawing at this stage only works if we are not using PROOF
  }
*/  
  
  return KEEP_EVENT; 

}



unsigned int Analysis::Between_OPS_and_OR(Long64_t entry) 
{
   (void)entry; //avoid compiler warnings
   
  //Method called Between OPS and OR
//for event 189, we draw a eta/phi plot before OPS. 
/*  if (entry == 7076)
  {
    drawEtaPhi(entry,2);//for event 189, we draw a eta/phi plot between OPS and OR
    //Drawing at this stage only works if we are not using PROOF
  }
*/
  return KEEP_EVENT;
}

// not the quickest sorting algorithm...
void Analysis::sort(float *lep_pt, float *lep_px, float *lep_py, float *lep_pz, float *lep_e, float *lep_isMuon, float *lep_charge, unsigned int n_leptons)
{
  float tmp_pt, tmp_px, tmp_py, tmp_pz, tmp_e, tmp_isMuon, tmp_charge;
  
  for(unsigned int i=0;i<n_leptons;i++){
    for(unsigned int j=i+1;j<n_leptons;j++){
      if(lep_pt[i]<lep_pt[j]){
        
	//swap
	tmp_pt = lep_pt[i];
        tmp_px = lep_px[i];
        tmp_py = lep_py[i];
        tmp_pz = lep_pz[i];
        tmp_e  = lep_e[i];
	tmp_isMuon = lep_isMuon[i];
	tmp_charge = lep_charge[i];
	
        lep_pt[i] = lep_pt[j];
        lep_px[i] = lep_px[j];
        lep_py[i] = lep_py[j];
        lep_pz[i] = lep_pz[j];
        lep_e[i]  = lep_e[j];
	lep_isMuon[i] = lep_isMuon[j];
	lep_charge[i] = lep_charge[j];
	
        lep_pt[j] = tmp_pt;
        lep_px[j] = tmp_px;
        lep_py[j] = tmp_py;
        lep_pz[j] = tmp_pz;
        lep_e[j]  = tmp_e;
	lep_isMuon[j] = tmp_isMuon;
	lep_charge[j] = tmp_charge;
      }
    }
  }   
}

void Analysis::doAnalysis(Long64_t entry)
{
  
  if (verbose)  std::cout << "Entry " << entry << " in Analysis (after OPS and OR) " << std::endl;

  //Finally the Analysis method, called just after OR
  //First, I'll show you how to get variables. What are the available variables and their type?
  //You can either check with a TBrowser, but this code also outputs all variables at the beginning of the Analysis when running without proof!
  
  //This version of the D3PD reader was designed to support multiple type of e.g. jet objects
  //In the constructor of this class, you told the Selector which prefix to use for jet etc.
  //data needs to be fetched specifiying the type, eg. ELE, MUO, JET, PHO. internally, the selector will translate to the correct prefix. The advantage is, that when the prefix changes, not the whole code needs to be be changed.
  //if you don't want to take advantage of this thing (but then you loose the built-in overlap removal and ops), you can always get the data via GetRawVal(..) and GetRawVector(...)
   
  
  //What is the smartest way to get the number of electrons? (See RECOMMENDED)
  //Since the number of electron candidates is different before OPS, between OPS and OR, and after OR, we need to be careful. 
  //First, lets get the original number of electrons before OPS
/*
  unsigned int number_of_electrons_in_ntuple = m_sel->GetSizeByType("ELE"); //RECOMMENDED
  unsigned int number_of_muons_in_ntuple = m_sel->GetSizeByType("MUO"); //RECOMMENDED
  unsigned int number_of_jets_in_ntuple = m_sel->GetSizeByType("JET"); //RECOMMENDED
  unsigned int number_of_photons_in_ntuple = m_sel->GetSizeByType("PHO"); //RECOMMENDED

  if (verbose) {
    std::cout << "#mu(before) " << number_of_muons_in_ntuple <<  std::endl;
    std::cout << "#jet(before) " << number_of_jets_in_ntuple <<  std::endl;
    std::cout << "#ph(before) " << number_of_photons_in_ntuple <<  std::endl;
  }
  
  //We would like to Access the values after OPS and OR.
  //We can do this by calling the GetFin...ByType-type (Like GetFinal...) methods
  unsigned int number_of_electrons_clean = m_sel->GetFinSizeByType("ELE"); //RECOMMENDED. 
  unsigned int number_of_muons_in_ntuple_clean = m_sel->GetFinSizeByType("MUO"); //RECOMMENDED
  unsigned int number_of_jets_in_ntuple_clean = m_sel->GetFinSizeByType("JET"); //RECOMMENDED
  unsigned int number_of_photons_in_ntuple_clean = m_sel->GetFinSizeByType("PHO"); //RECOMMENDED

  if (verbose) {
    std::cout << "#mu(after) " << number_of_muons_in_ntuple_clean <<  std::endl;
    std::cout << "#jet(after) " << number_of_jets_in_ntuple_clean <<  std::endl;
    std::cout << "#ph(after) " << number_of_photons_in_ntuple_clean <<  std::endl;
  }
*/

  //I would like to loop over the electron eta values before and after the OPS/OR. How do I do that?
  //we already got the sizes (number of elements, so we will do a loop:
/*
  for (unsigned int it_before=0; it_before < number_of_electrons_in_ntuple; it_before ++)
  {
    if (verbose) std::cout << "El before OPS/OR at position " << it_before << " has eta " << m_sel->GetValByType<float>("ELE", "_eta", it_before) << std::endl;
    // Notice the method Name: GetValByType.
    // Here we need to tell the program what value type we expect. This we can do with this template-like call: GetValByType<float>. 
    // The parameters for the call are:
    // - Object Type: ELE (can use ELE, MUO, JET, PHO) : tells the programm to get the electron-type variables
    // - "_eta" : tells the program to get _eta variable, internally, the prefix is prepended, and the correct variable (el_eta in this case) is accessed
    // index, the index in the electron array
    
  }
  
  //now let's do the same with the electron objects after OPS/OR

  for (unsigned int it_after=0; it_after < number_of_electrons_clean; it_after ++)
  {
    if (verbose) std::cout << "El after OPS/OR at position " << it_after << " has eta " << m_sel->GetFinValByType<float>("ELE", "_eta", it_after) << std::endl;
    // Notice the method Name. We have GetFinValByType, as opposed To GetValByType above.
    //parameters are the same
  }
*/  
/*  
  // I don't like that, I'd rather work with vectors!
  // Fine. Here's the way to work with vectors
  // Lets suppose you want to get the muon px before and after OPS/OR
  unsigned int size_bf; 
  std::vector<float> muon_px_bf = m_sel->GetVectorByType< std::vector<float> >("MUO","_px", &size_bf);
  //Please not that we must declare what kind we want to have returned, in this example its a vector of floats. 
  //Parameters are again the object type, then the variable (without prefix).
  //The third parametr is optional and is a pointer to and integer. If given, it will be the size of the array.
  //This way you can get the size in one go.
  
  
  //and after the OPS/OR 
//  unsigned int size_af;
  std::vector<float> muon_px_af = m_sel->GetFinVectorByType< std::vector<float> >("MUO","_px");
  //not again the difference in the method names: GetVectorByType vs GetFinVectorByType
*/ 
//for event 189, we draw a eta/phi plot after OPS and OR
/*  if (entry == 7076)
  {
    drawEtaPhi(entry,3); //for event 189, we draw a eta/phi plot after OPS and OR
  }
*/


  //there is also the possibility to get four vectors (TLorentzVector).
  //(internally, the program consults pt,eta,E, and phi to fill them)
/*  
  if (number_of_jets_in_ntuple_clean > 0)
  {

  	TLorentzVector jetone_before_OPS_OR = m_sel->GetFourVecByType("JET", 0);
	  TLorentzVector jetone_after_OPS_OR = m_sel->GetFinFourVecByType("JET", 0);
	  //WARNING, you will probably not get the same jets!
	  
	  if (verbose) std::cout << "jet[0] px (before OPS_OR) " << jetone_before_OPS_OR.Px() << std::endl;
	  if (verbose) std::cout << "jet[0] px (after OPS_OR) " << jetone_after_OPS_OR.Px() << std::endl;

  }
*/


  //Let's do some useful stuff. Let's calculate meff4
/*
  //First we get the pt container for the jets (Notice: We now get the Fin-type values)
  unsigned int jcsize = 0;
  std::vector<float> jet_pt = m_sel->GetFinVectorByType< std::vector<float> >("JET", "_pt", &jcsize );
  
  if (jcsize>=4) //if we have enough jets...
  {
    //we sum four jet pt's...
    float ptsum = jet_pt.at(0) + jet_pt.at(1) + jet_pt.at(2) + jet_pt.at(3);
    //get the missing et...
    float met = m_sel->GetScalarVal<float>("MET_RefFinal_et");
    //sum the two...
    float MEFF = ptsum + met;
    MEFF/=1000;
  
    //..and fill the histogram
    meff->Fill(MEFF);
  }
*/

  //Final comment: with the "Get..BYType", you are bound to the Objects defined (JET, ELE, MUO, PHO). 
  //You can always get the raw values or vectorsfrom the ntuple with the follwoing methods
  //NOTE: overlap removel and OPS will not be applied to these objects
/*  
  if (jcsize>0)
  {
    float jet_phi = m_sel->GetRawVal< float >("jet_phi", 0); //get the first entry of jet_phi container 
  	std::cout << "leading jet_phi " << jet_phi << std::endl;
    //NOTE: Full container name must be specified!!
    //NOTE: Don't forget template arguement (float or whatever type the variable has)
  }
  
  std::vector< float > mu_eta = m_sel->GetRawVector< std::vector<float> >("mu_eta");
  //NOTE: Don't forget to gie full contianer name and template type argument!
  
  //GetRawVector can be used for any type, also vect of vect of int
  vector<vector<int> > out = m_sel->GetRawVector< vector<vector<int> > >("mc_children");
  for (unsigned int z = 0; z < out.size(); z++)
	{
		vector<int> la = out.at(z);
		for (unsigned int x = 0; x< la.size(); x++)
		{
			std::cout << "[" << z << "][" << x << "]:" << la.at(x) << std::endl;
		}
	} 
	
*/

  //Now we perform cutflow study
  
  //MC Weight 
  std::vector<double> mcevt_weight = m_sel->GetRawVector< std::vector<double> >( "mcevt_weight" );
  double mc_event_weight = mcevt_weight.at(0);
  //end Weight
  
  m_cutflow[1]+= (int)mc_event_weight; //events after crack veto
  final_cutflow[1] = m_cutflow[1];
  
  unsigned int n_ele = m_sel->GetFinSizeByType("ELE"); //final electrons 
  unsigned int n_muo = m_sel->GetFinSizeByType("MUO"); //final muons

  if (n_ele + n_muo < 2) return ; //2 or more lepton cut (pt 10,10)
  

  float lep_pt[n_ele+n_muo] ;
  float lep_px[n_ele+n_muo] ;
  float lep_py[n_ele+n_muo] ;
  float lep_pz[n_ele+n_muo] ;
  float lep_e[n_ele+n_muo] ;
  float lep_isMuon[n_ele+n_muo];
  float lep_charge[n_ele+n_muo];	   
  
  if (n_ele){
    
    for (unsigned int i = 0; i < n_ele; i++){
      lep_pt[i] = m_sel->GetFinValByType<float>("ELE", "_pt", i);
      lep_px[i] = m_sel->GetFinValByType<float>("ELE", "_px", i);
      lep_py[i] = m_sel->GetFinValByType<float>("ELE", "_py", i);
      lep_pz[i] = m_sel->GetFinValByType<float>("ELE", "_pz", i);
      lep_e[i]  = m_sel->GetFinValByType<float>("ELE", "_E", i);
    
      //m_lep[i] = m_sel->GetFinFourVecByType("ELE",i);
      lep_charge[i] =  m_sel->GetFinValByType<float>("ELE", "_charge", i);
      lep_isMuon[i] = 0.;
          	
      if (!((lep_charge[i]==-1.)||(lep_charge[i]==1.) )) 
        std::cout << "ERROR charge["<<i<<"] "<<lep_charge[i]<<std::endl;
 
    }  
  }
  
  if (n_muo) {
  
    for (unsigned int i = 0; i < n_muo; i++){
      lep_pt[i+n_ele] = m_sel->GetFinValByType<float>("MUO", "_pt", i);
      lep_px[i+n_ele] = m_sel->GetFinValByType<float>("MUO", "_px", i);
      lep_py[i+n_ele] = m_sel->GetFinValByType<float>("MUO", "_py", i);
      lep_pz[i+n_ele] = m_sel->GetFinValByType<float>("MUO", "_pz", i);
      lep_e[i+n_ele]  = m_sel->GetFinValByType<float>("MUO", "_E", i);
    
      //m_lep[i] = m_sel->GetFinFourVecByType("MUO",i);
      lep_charge[i+n_ele] =  m_sel->GetFinValByType<float>("MUO", "_charge", i);
      lep_isMuon[i+n_ele] = 1.; 
      
      if (!((lep_charge[i]==-1.)||(lep_charge[i]==1.) )) 
        std::cout << "ERROR charge["<<i<<"] "<<lep_charge[i+n_ele]<<std::endl;
    }
  }

  //sort lepton pt in descending order
  unsigned int n_leptons=n_ele+n_muo;
  
  if (verbose) 
    for (unsigned int i = 0; i < (n_leptons); i++) {
    	std::cout << "before sorting, pt["<<i<<"] "<<lep_pt[i]<<std::endl;
    	std::cout << "before sorting, charge["<<i<<"] "<<lep_charge[i]<<std::endl;    
    } 
    
  sort( &lep_pt[0], &lep_px[0], &lep_py[0], &lep_pz[0], &lep_e[0], &lep_isMuon[0], &lep_charge[0], n_leptons);
  
  if (verbose) 
    for (unsigned int i = 0; i < (n_leptons); i++) std::cout << "after sorting, pt["<<i<<"] "<<lep_pt[i]<<std::endl;

  //Lepton Cut
  m_cutflow[2]+= (int)mc_event_weight; // cut on number of leptons
  final_cutflow[2] = m_cutflow[2];

  //Jet cuts
  unsigned int n_jet = m_sel->GetFinSizeByType("JET");
  
  if (n_jet < NJETS) return ; 
  
  m_cutflow[3]+= (int)mc_event_weight; // four jets required
  final_cutflow[3] = m_cutflow[3];
  
  TLorentzVector jet1 = m_sel->GetFinFourVecByType("JET",0);
  TLorentzVector jet2 = m_sel->GetFinFourVecByType("JET",1);
  
  if (jet1.Pt() < JETPT1_CUT ) return ;
  if (jet2.Pt() < JETPT2_CUT ) return ;

  m_cutflow[4]+= (int)mc_event_weight; //jet pt cuts
  final_cutflow[4] = m_cutflow[4];

  //ST preparation
  float sumpx2 = 0;
  float sumpy2 = 0;
  float sumpxpy = 0;
  
  for (unsigned int i = 0; i < n_leptons ; i++){
  
    sumpx2 += lep_px[i]*lep_px[i];
    sumpy2 += lep_py[i]*lep_py[i];
    sumpxpy += lep_px[i]*lep_py[i];
  }

  for (unsigned int zz = 0; zz < n_jet ; zz++){
  
    TLorentzVector jetx = m_sel->GetFinFourVecByType("JET", zz);
    if ( jetx.Pt()>20000 && fabs(jetx.Eta()) < 2.5 )
    {
       sumpx2+=jetx.Px()*jetx.Px();
       sumpy2+=jetx.Py()*jetx.Py();
       sumpxpy+=jetx.Px()*jetx.Py();
    }
   
  }
 
  //dPhi MET Jets
  float met = m_sel->GetScalarVal<float>("MET_RefFinal_et");

  if (met <= ETMISS_CUT) 
    return;
 
  m_cutflow[5]+= (int)mc_event_weight; //MET cut
  final_cutflow[5] = m_cutflow[5];
  if (verbose) 
    for (unsigned int i = 0; i < (n_leptons); i++) std::cout << "lepton pt["<<i<<"] "<<lep_pt[i]<<std::endl;
  
  float sum_lepton_pt = 0.;
  
  for (unsigned int i = 0; i < (n_leptons); i++) sum_lepton_pt+= lep_pt[i];
    
  m_meff = jet1.Pt() + jet2.Pt() + sum_lepton_pt + met;  // two leptons
  
  if (verbose) std::cout << "meff "<<m_meff<<" meff*"<<ETMISSMEFF_CUT<<" "<<(m_meff*ETMISSMEFF_CUT)<<" MET "<<met<<std::endl;
  
  //Fill histogram
  meff->Fill(m_meff/=1000);

  if (met<=ETMISSMEFF_CUT*m_meff) return ; 
  if (verbose) std::cout << "meff cut passed"<<std::endl;

  m_cutflow[6]+= (int)mc_event_weight; //Meff MET ratio cut
  final_cutflow[6] = m_cutflow[6];

  //Transverse Sphericity
  double TSP = Analysis::CalcTranSphericity(sumpx2,sumpy2,sumpxpy);
  if (TSP <= 0.2) return ; 

  m_cutflow[7]+= (int)mc_event_weight; //ST cut
  final_cutflow[7] = m_cutflow[7];

  float met_phi = m_sel->GetScalarVal<float>("MET_RefFinal_phi");

  if ( deltaR(0,jet1.Phi(),0,met_phi) < 0.2 ) return ;
  if ( deltaR(0,jet2.Phi(),0,met_phi) < 0.2 ) return ;
  
  m_cutflow[8]+= (int)mc_event_weight; //dRPhiMEt cut
  final_cutflow[8] = m_cutflow[8];
  

  //Calculate invariant mass 2 leading leptons
  float invmass = sqrt((lep_e[0]+lep_e[1])*(lep_e[0]+lep_e[1]) - (lep_px[0]+lep_px[1])*(lep_px[0]+lep_px[1]) - (lep_py[0]+lep_py[1])*(lep_py[0]+lep_py[1]) -
     (lep_pz[0]+lep_pz[1])*(lep_pz[0]+lep_pz[1]) );
  
  if (verbose) std::cout << "invmass "<<invmass<<std::endl;  

  if ( invmass < INVMASS_CUT ) return ;
  
  m_cutflow[9]+= (int)mc_event_weight; 
  final_cutflow[9] = m_cutflow[9];

  // SS  (Same sign)
  if ((lep_charge[0]*lep_charge[1])==1.){ 
    m_cutflow[10]+= (int)mc_event_weight; 
    final_cutflow[10] = m_cutflow[10];
  }
  
  

}


void Analysis::finalizeEvent(Long64_t entry)
{

  if (verbose){
    std::cout << "Cutflow after Event " << entry << " for two lepton selection "  << std::endl;
    for (int cf = 0; cf < 12 ; cf++)  
      std::cout << "Cut " << cf << ": " <<  m_cutflow[cf] << std::endl;
  }

  return;

}


/*static*/ void Analysis::postAnalysis (TSelectorList* fOutput)
{
  // (void)fOutput; //avoid compiler warnings
  
  //This method is declared as static in the header file
  //Why?
  //This comes from the fact that PROOF calls the method Terminate (which then calls this method) on the master thread.
  //However, when running PROOF, the code above usually runs in Slave Threads. 
  //The master thread (which is running when the computer gets here), doesn't have acces to the member variables in the slave threads.
  
  //All you can do here is get Objects from fOutput-List and Draw them or save them to a file
  
  //Lets get our meff4 plot from above (which at this stage will be merged)
  TH1F * dada = (TH1F*)fOutput->FindObject("meff4")->Clone();
  
  //We create a Canvas
  new TCanvas("Show","Show", 800, 600);
  
  //And eventually we draw the meff plot.
  dada->Draw();
  

  std::cout << "Final Cutflow after "<<nbevents<<" events for two lepton selection "  << std::endl;
 
  for (int cf = 0; cf < 12; cf++)
  {
    std::cout << "Cut " << cf << ": " <<  final_cutflow[cf] << std::endl;
  }
  
  
  return;

}


double Analysis::CalcTranSphericity(double sumpx2,double sumpy2,double sumpxpy){
   double marray[4];
   for(int i=0;i<4;i++){
     marray[i]=0;
   }
   marray[0]=sumpx2;
   marray[1]=sumpxpy;
   marray[2]=sumpxpy;
   marray[3]=sumpy2;
      
   // use root matrix to find eigenvalues...
   TMatrixDSym matrix(2);  
   matrix.SetMatrixArray(marray);
   
   TMatrixDSymEigen eigen(matrix); 
   TVectorD E = eigen.GetEigenValues();   
  
   // from the babar sphericity code...
   double lambda1 = 0;
   double lambda2 = 0;
   
   if(E[0] < E[1]){
     lambda1 = E[0];
     lambda2 = E[1];
   }else{
     lambda1 = E[1];
     lambda2 = E[0];
   }
 
   double ST = 0;
   ST = 2*lambda1/( lambda1 + lambda2);
   return ST;
 }



void Analysis::drawEtaPhi(Long64_t entry, int id)
  {
      //This is a custom unction which takes mu, el, and jet eta and phi and plots them
      //return;
  
      //first we need to create some distinct Canvas names
      char tr[100];
      sprintf(tr, "top_%lld_%d", entry, id);
        
      //std::cout << "Pre_OPS_OR " << tr << std::endl;
      
      //Create a TGraph, add some Bogus Points (Tgraph doesn't like to be empty) and set the borders
      TGraph * tmp = new TGraph();
      tmp->SetPoint(1,-6,-4);
      tmp->SetPoint(2,6,4);
      tmp->GetXaxis()->SetLimits(-6,6);
      tmp->GetXaxis()->SetRangeUser(-6,6);
      tmp->GetXaxis()->SetTitle("eta");
      tmp->GetYaxis()->SetLimits(-3.2,3.2);
      tmp->GetYaxis()->SetRangeUser(-3.2,3.2);
      tmp->GetYaxis()->SetTitle("phi");
  
      //Create a new smallCanvas
      TCanvas* bla = new TCanvas(tr,tr,600,600);
      bla->SetTitle(tr);
      //bla->SetTitle("EtaPhi");
      //Draw the Graph
      tmp->Draw("AP*");
  
      TBox* b1 = new TBox(1.37, -3.15, 1.52, 3.15);
      TBox* b2 = new TBox(-1.37, -3.15, -1.52, 3.15);
  
      b1->Draw("SAME");
      b2->Draw("SAME");
  
      //We are using TMarkers with different shapes. Jets are triangles, muons are circles and electrons are suqares
      //Start with muons
      unsigned int size_mu;
      //Get the vectors eta and phi
      std::vector<float> mu_eta = m_sel->GetFinVectorByType< std::vector<float> >("MUO","_eta", &size_mu);
      std::vector<float> mu_phi = m_sel->GetFinVectorByType< std::vector<float> >("MUO","_phi");
      std::vector<float> mu_pT = m_sel->GetFinVectorByType< std::vector<float> >("MUO","_pt");
      //loops over the vector and create TMarkers at the eta and phi coordinates
      for (unsigned int a = 0; a<size_mu; a++)
      {
        TMarker * zaza = new TMarker(mu_eta.at(a), mu_phi.at(a), 24);
        zaza->SetMarkerSize(2); //One could set the size acording to pt.
        zaza->SetMarkerColor(4); //
        
        zaza->Draw(); //Plot the Marker
        
        
        char tmp[100] = "";
        float pt = mu_pT.at(a);
        sprintf(tmp, "%.1f", pt/1000.);
        
        TText * tmptext = new TText(mu_eta.at(a) +0.27, mu_phi.at(a) -0.1, std::string(tmp).c_str() );
        tmptext->SetTextSize(0.03);
        tmptext->Draw();
        
      }
      
      //same for jet
  
      unsigned int size_jet;
      std::vector<float> jet_eta = m_sel->GetFinVectorByType< std::vector<float> >("JET","_eta",&size_jet);
      std::vector< float> jet_phi = m_sel->GetFinVectorByType<  std::vector<float> >("JET","_phi");
      std::vector< float> jet_pt = m_sel->GetFinVectorByType<  std::vector<float> >("JET","_pt");
      for (unsigned int a = 0; a<size_jet; a++)
      {
        TMarker * zaza = new TMarker(jet_eta.at(a), jet_phi.at(a), 23);
        zaza->SetMarkerSize(2);
        zaza->SetMarkerColor(2);
        
        zaza->Draw();

        char tmp[100] = "";
        float pt = jet_pt.at(a);
        sprintf(tmp, "%.1f", pt/1000.);
        
        TText * tmptext = new TText(jet_eta.at(a) - 0.2, jet_phi.at(a) +0.2, std::string(tmp).c_str() );
        tmptext->SetTextSize(0.03);
        tmptext->Draw();

      }
      
      //and electrons
      
      unsigned int size_el;
      std::vector< float> el_eta = m_sel->GetFinVectorByType< std::vector<float> >("ELE","_eta", &size_el);
      std::vector< float> el_phi = m_sel->GetFinVectorByType<  std::vector<float> >("ELE","_phi");
      std::vector< float> el_pT = m_sel->GetFinVectorByType<  std::vector<float> >("ELE","_pt");
      for (unsigned int a = 0; a<size_el; a++)
      {
        TMarker * zaza = new TMarker(el_eta.at(a), el_phi.at(a), 25);
        zaza->SetMarkerSize(2);
        zaza->SetMarkerColor(3);
        
        zaza->Draw();

        char tmp[100] = "";
        float pt = el_pT.at(a);
        sprintf(tmp, "%.1f", pt/1000.);
        
        TText * tmptext = new TText(el_eta.at(a) +0.27, el_phi.at(a) -0.1, std::string(tmp).c_str() );
        tmptext->SetTextSize(0.03);
        tmptext->Draw();

      }
  
  }
