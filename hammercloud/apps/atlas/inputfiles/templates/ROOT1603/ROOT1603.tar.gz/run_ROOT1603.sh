#!/bin/bash
root -l -b runD3PDSelector.C
