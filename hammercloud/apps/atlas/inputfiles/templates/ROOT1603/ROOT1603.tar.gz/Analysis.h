#ifndef Analysis_h
#define Analysis_h

#include <iostream>
#include <TH1F.h>
#include "checkOQ.C"
//#include "MultijetJESUncertaintyProvider.h"
//#include "MultijetJESUncertaintyProvider.C"
#include "GoodRunsLists/TGoodRunsList.h"
#include "GoodRunsLists/TGoodRunsListReader.h"

class Analysis
{

  public:
    //Constructors
    Analysis(D3PDSelector * inst); //Constructor with D3PD Selector Object

    //Destructor
    virtual ~Analysis() {}; //default destructor

    //Analysis Methods
    virtual unsigned int Pre_OPS_OR(Long64_t entry);
    virtual unsigned int Between_OPS_and_OR(Long64_t entry);
    virtual void doAnalysis(Long64_t entry);
    virtual void finalizeEvent(Long64_t entry);

    //helper method
    
    //static postAnalysis method (Drawing/Saving)
    static void postAnalysis (TSelectorList* fOutput);
            
    //Example TH1F
    TH1F* meff;
    TH1F* n_e;
    TH1F* pt_e;
    TH1F* pt_e_1;
    TH1F* pt_e_2;
    TH1F* pt_e_cl;
    TH1F* eta_e;
    TH1F* phi_e;
    TH1F* pt_e_trig;
    TH1F* invmass_ee;

    TH1F* n_mu;
    TH1F* pt_mu_trig;
    TH1F* pt_mu;
    TH1F* pt_mu_1;
    TH1F* pt_mu_2;
    TH1F* invmass_mumu;
    TH1F* eta_mu;
    TH1F* phi_mu;

    TH1F* n_jets;
    TH1F* jet_RelPosUncert;
    TH1F* jet_RelNegUncert;

    // Useful global vars
    int eventNumber, runNumber, lumiBlockNumber;
    Root::TGoodRunsList grl;
    Root::TGoodRunsListReader* grlR;

    //MultijetJESUncertaintyProvider* myUncertainty;

  protected:
    D3PDSelector * m_sel;
    int m_cutflow[12];

    float m_meff; //value used in cuts do stoe meeff, so we don't need to calculate again in Analysis
    TLorentzVector m_lep;
    float m_lep_charge;

};

#endif

