#define KEEP 0
#define REJECT 1
#define PRE_SKIP_EVENT 2


class MyObjectPreSelection : public ObjectPreSelection
{

  public:

    MyObjectPreSelection(D3PDSelector* inst) : ObjectPreSelection(inst) {};
    //Mandatory

 
    void objectPreSelectionOrder()
    {
      //In this method which is called by the D3PD Selector, we define the order of how to execute 
      //the Object Preselection
      
      //We can do multiple iterations by giving an integer argument to the method.
      //This can later be reused to differentiate between the iterations
      //This is not used in the OPS example, but in the OR example
      
      do_Electron(1);
      do_Muon(1);
      do_Jet(1);
      //do_Photon(1);
      
    }

    unsigned int Electron_OPS(ObjAccess* ele, unsigned int  iteration)
    {
      (void)iteration; //avoid compiler warnings
      
      //The OPS methods return 0 if the obejct is to be kept, and 1 if it is to be rejected

      //Checking author (must be 1 or 3)
      //we can access any variable. However DO NOT CROSS-ACCESS different particle types, e.g. accessing muon variables in the Electron OPS method. This will mess up the internal ordering!!!
      
      //see
      // https://twiki.cern.ch/twiki/bin/view/AtlasProtected/SusyObjectDefintions
      
      //
      

      int author = ele->GetValue<int>("_author");
      if (author!=1 && author !=3) return REJECT;


      int medium = ele->GetValue<int>("_medium");
      if (medium == 0) return REJECT;


      float pt = ele->GetValue<float>("_pt");
      if ( fabs(pt) <= 10000. ) return REJECT;
       

      float eta = ele->GetValue<float>("_eta");
      if ( fabs(eta) >= 2.5 ) return REJECT;

      if (fabs(eta) > 1.37 &&  fabs(eta) < 1.52) return PRE_SKIP_EVENT; //electron crack veto

      float etcone20 = ele->GetValue<float>("_Etcone20");
      if (etcone20 >= 10000.) return REJECT;
             
      return KEEP;
    }

    unsigned int Muon_OPS(ObjAccess* muo, unsigned int  iteration)
    {
      (void)iteration; //avoid compiler warnings

      int isComMuo = muo->GetValue<int>("_isCombinedMuon");
      if (!isComMuo) return REJECT;

      float etcone20 = muo->GetValue<float>("_etcone20");
      if ( etcone20 >= 10000. ) return REJECT;

      float matchchi2 = muo->GetValue<float>("_matchchi2");
      if ( matchchi2 > 100. || matchchi2 < 0.) return REJECT;
      
      float eta = muo->GetValue<float>("_eta");
      if ( fabs(eta) >= 2.5 ) return REJECT;

      float pt = muo->GetValue<float>("_pt");
      if ( pt <= 10000. ) return REJECT;
       

       return KEEP;    
    }

    unsigned int Jet_OPS(ObjAccess* jet, unsigned int  iteration)
    {
      (void)iteration; //avoid compiler warnings

      float eta = jet->GetValue<float>("_eta");
      if ( fabs(eta) >= 2.5 ) return REJECT;

      float pt = jet->GetValue<float>("_pt");
      if ( fabs(pt) <= 20000. ) return REJECT;
    
       return KEEP;    
    }

/*
    unsigned int Photon_OPS(ObjAccess* pho, unsigned int  iteration)
    {
        
      return KEEP;
    }
*/



};

