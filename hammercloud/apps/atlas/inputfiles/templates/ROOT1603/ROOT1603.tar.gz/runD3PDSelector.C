#include <string>
#include <vector>
#include <iostream>
#include <stdlib.h>

#include "TROOT.h"
#include "TFile.h"
#include "TTree.h"
#include "TChain.h"
#include "TBranch.h"
#include "TFileCollection.h"

#include <fstream> 
#include <iostream>

//to run in ROOT: .x runD3PDSelector.C

//void runD3PDSelector(std::vector<std::string> inputFile) {
void runD3PDSelector() {

  gROOT->SetStyle("Plain");

  bool useProof = false;

  if (useProof) {

    gSystem->Load("libMatrix.so");
    gSystem->Load("/nobackup/etp2/elmsheus/athena/16.0.2-fe/GoodRunsListsLib.so");

    //TProof *p = TProof::Open("");
    TProof *p = TProof::Open(gSystem->GetFromPipe("pod-info -c"));

    gROOT->ProcessLine(".L D3PDSelector.C+O");
    gProof->Exec("gSystem->Load(\"/nobackup/etp2/elmsheus/athena/16.0.2-fe/D3PDSelector_C.so\")");
    gProof->Exec("gSystem->Load(\"/nobackup/etp2/elmsheus/athena/16.0.2-fe/GoodRunsListsLib.so\")");

    p->Process("/default/Johannes.Elmsheuser/user10.HaijunYang.data10_7TeV.PeriodABC_L1Calo.NTUP_SMEW.DiLeptonSkim.RobustLoose.D3PD_v15.6.13.2|/default/Johannes.Elmsheuser/user10.HaijunYang.data10_7TeV.PeriodD_L1Calo.NTUP_SMEW.DiLeptonSkim.RobustLoose.D3PD_v15.6.13.2|/default/Johannes.Elmsheuser/user10.HaijunYang.data10_7TeV.PeriodE_Egamma.NTUP_SMEW.DiLeptonSkim.RobustLoose.D3PD_v15.6.13.2|/default/Johannes.Elmsheuser/user10.HaijunYang.data10_7TeV.PeriodF_Egamma.NTUP_SMEW.DiLeptonSkim.RobustLoose.D3PD_v15.6.13.2|/default/Johannes.Elmsheuser/user10.HaijunYang.data10_7TeV.PeriodG1_Egamma.NTUP_SMEW.DiLeptonSkim.RobustLoose.D3PD_v15.6.13.2|/default/Johannes.Elmsheuser/user10.HaijunYang.data10_7TeV.PeriodG2_Egamma.NTUP_SMEW.DiLeptonSkim.RobustLoose.D3PD_v15.6.13.2|/default/Johannes.Elmsheuser/user10.HaijunYang.data10_7TeV.PeriodG3_Egamma.NTUP_SMEW.DiLeptonSkim.RobustLoose.D3PD_v15.6.13.2|/default/Johannes.Elmsheuser/user10.HaijunYang.data10_7TeV.PeriodG4_Egamma.NTUP_SMEW.DiLeptonSkim.RobustLoose.D3PD_v15.6.13.2|/default/Johannes.Elmsheuser/user10.HaijunYang.data10_7TeV.PeriodG5_Egamma.NTUP_SMEW.DiLeptonSkim.RobustLoose.D3PD_v15.6.13.2|/default/Johannes.Elmsheuser/user10.HaijunYang.data10_7TeV.PeriodG6_Egamma.NTUP_SMEW.DiLeptonSkim.RobustLoose.D3PD_v15.6.13.2|/default/Johannes.Elmsheuser/user10.HaijunYang.data10_7TeV.PeriodH1_Egamma.NTUP_SMEW.DiLeptonSkim.RobustLoose.D3PD_v15.6.13.2|/default/Johannes.Elmsheuser/user10.HaijunYang.data10_7TeV.PeriodH2_Egamma.NTUP_SMEW.DiLeptonSkim.RobustLoose.D3PD_v15.6.13.2|/default/Johannes.Elmsheuser/user10.HaijunYang.data10_7TeV.PeriodI1_Egamma.NTUP_SMEW.DiLeptonSkim.RobustLoose.D3PD_v15.6.13.2|/default/Johannes.Elmsheuser/user10.HaijunYang.data10_7TeV.PeriodI2_Egamma.NTUP_SMEW.DiLeptonSkim.RobustLoose.D3PD_v15.6.13.2", "D3PDSelector.C+O");

  } 
  else {

    gSystem->Load("libMatrix.so");
    gSystem->Load("GoodRunsListsLib_SL5.so");
    //gSystem->Load("/nobackup/etp2/elmsheus/athena/16.0.2-fe/GoodRunsListsLib.so");

    const char* inputFile = "input.txt";

    TChain *c = new TChain("wwd3pd","");
    //TChain *c = new TChain("susy","");
    TFileCollection* fc = new TFileCollection("mylist", "mylist",inputFile);
    c->AddFileInfoList((TCollection*)fc->GetList());

    int nentries = c->GetEntries();
    std::cout << "Total  number of entries in chain (after all the files) " <<  nentries << std::endl;

    //c->SetProof();
    c->Process("D3PDSelector.C+O");

    // Create AthSummary.txt for the pilot
    ofstream outf("AthSummary.txt"); 
    outf << "Files read: " << fc->GetNFiles() << std::endl; 
    outf << "Events Read: " << nentries << std::endl; 
    outf << "{ \"events\":{\"read\":" << nentries << "} "  << "}" << std::endl;
    outf.close();
    system("cp AthSummary.txt ..");

    c->Delete();

  }

  gApplication->Terminate();

}


int main(int argc, char **argv) {

  std::string argStr;

  // split by '\n'
  std::ifstream ifs("input.txt");

  std::vector<std::string> fileList;

  while (std::getline(ifs,argStr)) {
    for (size_t i=0,n; i <= argStr.length(); i=n+1) {
      n = argStr.find_first_of('\n',i);
      if (n == std::string::npos)
        n = argStr.length();
      std::string tmp = argStr.substr(i,n-i);
      fileList.push_back(tmp);
    }
  }


  runD3PDSelector(fileList);



}
