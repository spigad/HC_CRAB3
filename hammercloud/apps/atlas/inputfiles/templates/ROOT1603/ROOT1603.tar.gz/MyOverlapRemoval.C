#include <math.h>

#define KEEP_BOTH 0 
#define KEEP_FIRST 2
#define KEEP_SECOND 1
#define REJECT_FIRST 1
#define REJECT_SECOND 2
#define REJECT_BOTH 3


//helper function
float deltaR(float eta1, float phi1, float eta2, float phi2)
{
  float diffphi = phi1 - phi2;
  while (fabs(diffphi) > M_PI) diffphi += ( diffphi > 0 ) ? -2*M_PI : 2*M_PI;
  
  float tmp = pow(eta1 - eta2 ,2) + pow(diffphi ,2);
  float deltaR = sqrt(tmp);
  return deltaR;
}


class MyOverlapRemoval : public OverlapRemoval
{
 public:
  //Constructor, Mandatory
  MyOverlapRemoval(D3PDSelector* inst) : OverlapRemoval(inst) {};  

 
  void overlapRemovalOrder()
  {
    //In this method, we may define the order in which the OR is done
    //we can have multiple iterations, idnicated by the parameter

    do_Electron_Jet(1); //First do Electron vs Jet
    //do_Muon_Jet(1); // Then do muon vs jet
    do_Electron_Jet(2); // Again do Electorn vs Jet
    
    do_Muon_Electron(1);
    do_Electron_Electron(1);
    
    //Available:

    /*    
    do_Electron_Jet(unsigned int iteration);
    do_Muon_Jet(unsigned int  iteration);
    do_Photon_Jet(unsigned int  iteration);
    do_Muon_Electron(unsigned int  iteration);
    do_Photon_Electron(unsigned int  iteration);
    do_Photon_Muon(unsigned int  iteration);
    */
    
    
  }
 
 
 
 //the actualy overlap removal methods
 //availabel are:
 
 /*
     //--VS Jet
    unsigned int ElectronJet_OR(ObjAccess* ele, ObjAccess* jet, unsigned int iteration);  
    unsigned int MuonJet_OR(ObjAccess* muo, ObjAccess* jet, unsigned int iteration);
    unsigned int PhotonJet_OR(ObjAccess* pho, ObjAccess* jet, unsigned int iteration);
  
    //--VS Electron
    unsigned int MuonElectron_OR(ObjAccess* muo, ObjAccess* ele,  unsigned int iteration);
    unsigned int PhotonElectron_OR(ObjAccess* pho, ObjAccess* ele,  unsigned int iteration);
    
    //--VS Muon
    unsigned int PhotonMuon_OR(ObjAccess* pho, ObjAccess* muo,  unsigned int iteration);

 */
 
  unsigned int ElectronJet_OR(ObjAccess* ele, ObjAccess* jet, unsigned int iteration)
  {
    //Example Electron vs Jet
  
    
    //First Getting eta and phi of electron and jet
    float ele_eta = ele->GetValue<float>("_cl_eta");
    float ele_phi = ele->GetValue<float>("_cl_phi");

    float ele_pt = ele->GetValue<float>("_pt");

    if (ele_pt < 10000.) cout << "ERROR electron pt during overlap removal "<< ele_pt <<endl;

    //float jet_eta = jet->GetValue<float>("_eta");
    //float jet_phi = jet->GetValue<float>("_phi");
    
    float jet_eta = jet->GetValue<float>("_emscale_eta");
    float jet_phi = jet->GetValue<float>("_emscale_phi");

    float jet_pt = ( jet->GetValue<float>("_emscale_pt")); 
    float jes = jet->GetValue<float>("_EMJES");
    
    //fix jes
    //EMJESFixer jetEMJESfixer;
    //if (jes ==0.) jes = jetEMJESfixer.fixAntiKt4H1Topo(jet_pt,jet_eta);
    jet_pt = jes * jet_pt;
    
    if (jet_pt < 20000.) cout << "ERROR jet pt during overlap removal "<< jet_pt <<endl;
    if (jet_eta >= 3.0)   cout << "ERROR jet eta during overlap removal "<< jet_eta <<endl;

    
    //calculating deltaR
    float dR = deltaR(ele_eta, ele_phi, jet_eta, jet_phi);

    //Iteration 1 handling
    if (iteration == 1)
    {
      if (dR < 0.3) 
      {
        // First and Second refer to the order in the method name. Here, first means Electron, second means Jet
        return KEEP_FIRST; // OR return REJECT_SECOND;
      } 
    }
    
    //Iteration 2 handling
    //if (iteration == 2)
    //{
    //  if (dR > 0.2 && dR < 0.4) 
    //  {
    //    return KEEP_SECOND;// OR return REJECT_FIRST;
    //  }
    //}
    
    return KEEP_BOTH; //keep both if nothing happened
  }
 
 
 
  unsigned int MuonJet_OR(ObjAccess* muo, ObjAccess* jet, unsigned int /*iteration*/)
  {
    float muo_eta = muo->GetValue<float>("_eta");
    float muo_phi = muo->GetValue<float>("_phi");

    //float jet_eta = jet->GetValue<float>("_eta");
    //float jet_phi = jet->GetValue<float>("_phi");
    float jet_eta = jet->GetValue<float>("_emscale_eta");
    float jet_phi = jet->GetValue<float>("_emscale_phi");
    
    float dR = deltaR(muo_eta,muo_phi,jet_eta,jet_phi);
    
    float muo_pt = muo->GetValue<float>("_pt");
    if (muo_pt < 10000.) cout << "ERROR muon pt during overlap removal "<< muo_pt <<endl;
    
    //std::cout << " mu_jet dR " << dR << std::endl;

    if (dR < 0.4 ) return REJECT_FIRST;
    
    
    return KEEP_BOTH;
  }
   
  unsigned int MuonElectron_OR(ObjAccess* muo, ObjAccess* ele,  unsigned int /*iteration*/)
  {
    //cout << "in Overlap removal muon electron "<< endl;
    float muo_eta = muo->GetValue<float>("_eta");
    float muo_phi = muo->GetValue<float>("_phi");

    float ele_eta = ele->GetValue<float>("_cl_eta");
    float ele_phi = ele->GetValue<float>("_cl_phi");
    
    float dR = deltaR(muo_eta,muo_phi,ele_eta,ele_phi);
    
    //if dR < 0.1 keep muon
    if (dR < 0.1 ) {
      //cout << "removing an electron, keeping the muon "<<endl;
      return KEEP_FIRST;
    }
    return KEEP_BOTH;
    
  }
  
  unsigned int ElectronElectron_OR(ObjAccess* ele1, ObjAccess* ele2,  unsigned int /*iteration*/)
  {
    
    //cout << "in Overlap removal electron electron "<< endl;
    float ele1_eta = ele1->GetValue<float>("_cl_eta");
    float ele1_phi = ele1->GetValue<float>("_cl_phi");
    float ele1_pt  = ele1->GetValue<float>("_pt");

    float ele2_eta = ele2->GetValue<float>("_cl_eta");
    float ele2_phi = ele2->GetValue<float>("_cl_phi");
    float ele2_pt  = ele2->GetValue<float>("_pt");
    
    float dR = deltaR(ele1_eta, ele1_phi, ele2_eta, ele2_phi);
    //cout << "ele1_pt "<<ele1_pt<< " ele2_pt "<<ele2_pt<< " dR "<<dR <<endl;
    //if dR < 0.1 keep muon
    if (dR < 0.1 ) {
    
      if (ele1_pt > ele2_pt){
        //cout << "removing an electron 2 "<<endl;
        return KEEP_FIRST;
      } else if (ele1_pt < ele2_pt){ 
        //cout << "removing electron 1 "<<endl;
        return KEEP_SECOND;	
      }	
    }
    
    return KEEP_BOTH;
    
  }
  

};
