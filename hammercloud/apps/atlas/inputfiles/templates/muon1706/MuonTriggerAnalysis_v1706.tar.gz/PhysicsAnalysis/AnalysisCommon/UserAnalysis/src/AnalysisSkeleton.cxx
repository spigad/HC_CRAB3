
#include "GaudiKernel/MsgStream.h"
#include "GaudiKernel/AlgFactory.h"
#include "GaudiKernel/IToolSvc.h"

#include "StoreGate/StoreGateSvc.h"

#include "McParticleEvent/TruthParticleContainer.h"

#include "GaudiKernel/ITHistSvc.h"
#include "TTree.h"

#include "UserAnalysis/AnalysisSkeleton.h"

#include "TrigConfL1Data/TriggerItem.h"
#include "AnalysisTriggerEvent/LVL1_ROI.h"
#include "AnalysisTriggerEvent/Muon_ROI.h"
#include "TrigMuonEvent/MuonFeature.h"
#include "TrigMuonEvent/MuonFeatureContainer.h"
#include "TrigMuonEvent/CombinedMuonFeature.h"
#include "TrigMuonEvent/CombinedMuonFeatureContainer.h"
#include "TrigMuonEvent/TrigMuonEFContainer.h"
#include "muonEvent/MuonContainer.h"

#include <algorithm>
#include <math.h>
#include <functional>
#include <iostream>



static const double mZ = 91.19*GeV;
static const int  MAX_PARTICLES = 20;

using namespace Analysis;

/////////////////////////////////////////////////////////////////////////////////////
/// Constructors

AnalysisSkeleton::AnalysisSkeleton(const std::string& name,
				   ISvcLocator* pSvcLocator) : CBNT_AthenaAwareBase(name, pSvcLocator),
							       m_analysisTools( "AnalysisTools", this ),
							       m_trigDec("Trig::TrigDecisionTool"){
  /** switches to control the analysis through job options */

  /////////////// Remove this if not needed //////////////////////////////////////////
  /// This is here only for distributed analysis example

  declareProperty( "AnalysisTools", m_analysisTools );
  declareProperty("MCParticleContainer", m_truthParticleContainerName = "SpclMC");

  /** the cuts - default values - to be modified in job options */

  declareProperty("DeltaRMatchCut", m_deltaRMatchCut = 0.5);
  declareProperty("DeltaRMatchCutLOW", m_deltaRMatchCutLOW = 0.5);
  declareProperty("DeltaRMatchCutL1", m_deltaRMatchCutL1 = 0.5);
  declareProperty("MaxDeltaR", m_maxDeltaR = 0.9999);
  declareProperty("PlateauStep", m_PlateauStep = 5000);
  declareProperty("doMCTruth", m_doTruth = true);
  declareProperty("doTrigDec", m_doTrigDec = false);
  declareProperty( "TrigDecisionTool",            m_trigDec, 
		   "The tool to access TrigDecision");



  ///////////////// Remove the above if not needed ///////////////////////////////////

  }



/////////////////////////////////////////////////////////////////////////////////////
/// Destructor - check up memory allocation
/// delete any memory allocation on the heap

AnalysisSkeleton::~AnalysisSkeleton() {}

////////////////////////////////////////////////////////////////////////////////////
/// Initialize
/// initialize StoreGate
/// get a handle on the analysis tools
/// book histograms

StatusCode AnalysisSkeleton::CBNT_initializeBeforeEventLoop() {
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "Initializing AnalysisSkeleton (before eventloop)" << endreq;

  // retrieve trigger decision tool
  // needs to be done before the first run/event since a number of
  // BeginRun/BeginEvents are registered by dependent services
  if(m_doTrigDec){
    StatusCode sc = m_trigDec.retrieve();
    if ( sc.isFailure() ){
      mLog << MSG::ERROR << "Can't get handle on TrigDecisionTool" << endreq;
      return sc;
    }
    mLog << MSG::INFO << "Get handle on TrigDecisionTool" << endreq;
  } 

  return StatusCode::SUCCESS;

}

StatusCode AnalysisSkeleton::CBNT_initialize() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << "Initializing AnalysisSkeleton" << endreq;

  /** get a handle of StoreGate for access to the Event Store */
  StatusCode sc = service("StoreGateSvc", m_storeGate);
  if (sc.isFailure()) {
     mLog << MSG::ERROR
          << "Unable to retrieve pointer to StoreGateSvc"
          << endreq;
     return sc;
  }
  
  /// get a handle on the analysis tools
  sc = m_analysisTools.retrieve();
  if ( sc.isFailure() ) {
      mLog << MSG::ERROR << "Can't get handle on analysis tools" << endreq;
      return sc;
  }

  /** get a handle on the NTuple and histogramming service */
  sc = service("THistSvc", m_thistSvc);
  if (sc.isFailure()) {
     mLog << MSG::ERROR
          << "Unable to retrieve pointer to THistSvc"
          << endreq;
     return sc;
  }

  if ( m_doTrigDec ) {
    /// retrieve trigger decision tool
    sc = m_trigDec.retrieve();
    if ( sc.isFailure() ){
      mLog << MSG::ERROR << "Can't get handle on TrigDecisionTool" << endreq;
      return sc;
    } else     mLog << MSG::INFO << "TrigDecisionTool retrieved!" << endreq;
    
    // get L1 trigger items
    std::vector< std::string >  TrigL1Items = m_trigDec->getListOfTriggers("L1_.*");    
    //    const std::vector<const TrigConf::TriggerItem*> TrigL1Items = m_trigDec->getL1ConfigurationItems();
    std::vector<std::string>::const_iterator iter= TrigL1Items.begin();
    std::vector<std::string>::const_iterator iterEnd = TrigL1Items.end();
    for (; iter!=iterEnd; ++iter) {
      std::string L1name = (*iter);
      mLog << MSG::INFO  << "L1 Trigger Item " << L1name  << " defined  " << endreq;
      //store L1 names
      m_triggerItemsL1.insert(std::map<std::string,int>::value_type(L1name,0));
    }
    
    // get HLT trigger items
    std::vector< std::string >  TrigL2Items = m_trigDec->getListOfTriggers("L2_.*");    
    iter= TrigL2Items.begin();
    iterEnd = TrigL2Items.end();
    for (; iter!=iterEnd; ++iter) {
      std::string L2name = (*iter);
      mLog << MSG::INFO  << "L2 Trigger Item " << L2name  << " defined  " << endreq;
      //store L2 names
      m_triggerItemsL2.insert(std::map<std::string,int>::value_type(L2name,0));
    }
    std::vector< std::string >  TrigEFItems = m_trigDec->getListOfTriggers("EF_.*");    
    iter= TrigEFItems.begin();
    iterEnd = TrigEFItems.end();
    for (; iter!=iterEnd; ++iter) {
      std::string EFname = (*iter);
      mLog << MSG::INFO  << "EF Trigger Item " << EFname  << " defined  " << endreq;
      //store L2 names
      m_triggerItemsEF.insert(std::map<std::string,int>::value_type(EFname,0));
    }
  }

  /////////////////////// To be removed if not needed /////////////////////////


  /** Athena-Aware NTuple (AAN) - this is the recommended option for users */

  /** now add branches and leaves to the AAN tree */

   //    addBranch("NElectrons",   m_aan_size, "NElectrons/i");
//      addBranch("ElectronEta",   m_aan_eta);
//      addBranch("ElectronPt",    m_aan_pt);
//     addBranch("ElecPtRatio",   m_aan_elecetres);

  /// ROOT histograms ---------------------------------------

  sc = bookHistos();
  if ( sc.isFailure() ){
    mLog << MSG::ERROR << "Can't book histograms" << endreq;
      return sc;
  }
 
    /// end ROOT Histograms ------------------------------------------

  ////////////////////// The above to be removed if not needed ////////////////////


    m_NfakeSA=0;
    m_NfakeCB=0;
    m_NfakeSA_tmef=0;
    m_NfakeCB_tmef=0;
    m_NfakeSA_mu6=0;
    m_NfakeCB_mu6=0;
    m_NfakeSA_tmef_mu6=0;
    m_NfakeCB_tmef_mu6=0;
    m_NfakeSA_mu20=0;
    m_NfakeCB_mu20=0;
    m_NfakeSA_tmef_mu20=0;
    m_NfakeCB_tmef_mu20=0;

  
  return StatusCode::SUCCESS;
}		 

///////////////////////////////////////////////////////////////////////////////////
/// Finalize - delete any memory allocation from the heap

StatusCode AnalysisSkeleton::CBNT_finalize() {
  MsgStream mLog( messageService(), name() );
  
 mLog << MSG::INFO  << "Level-1 Triggers defined: " << m_triggerItemsL1.size() << endreq;
 int il1 = 0;
 std::map<std::string,int>::iterator iter;
 for (iter = m_triggerItemsL1.begin(); iter!= m_triggerItemsL1.end(); ++iter) {
   mLog << MSG::INFO  <<"Number " << il1 << " : Events passing " << iter->first << ": " << iter->second << endreq;
   m_h_l1item_all->Fill(il1,iter->second);
   std::string tmp_trigLevel =  iter->first.substr(0,5);
   if (tmp_trigLevel == "L1_MU") m_h_l1item->Fill(il1,iter->second);
   if (tmp_trigLevel == "L1_2M") m_h_l1item->Fill(il1,iter->second);
   il1++;
 }
 
 mLog << MSG::INFO  << "Level-2 Triggers: " << m_triggerItemsL2.size()<<endreq;
 int il2 = 0;
 for (iter= m_triggerItemsL2.begin(); iter!= m_triggerItemsL2.end(); ++iter) {
   mLog << MSG::INFO  << "Number " << il2 << ": Events passing " << iter->first << ": " << iter->second << endreq;
   m_h_l2item_all->Fill(il2,iter->second);
   std::string tmp_trigLevel =  iter->first.substr(0,5);
   if (tmp_trigLevel == "L2_mu") m_h_l2item->Fill(il2,iter->second);
   if (tmp_trigLevel == "L2_2m") m_h_l2item->Fill(il2,iter->second);
   il2++;
 }
 
 mLog << MSG::INFO  << "EF Triggers: "  << m_triggerItemsEF.size()<<endreq;
 int ief = 0;
 for (iter= m_triggerItemsEF.begin(); iter!= m_triggerItemsEF.end(); ++iter) {
   mLog << MSG::INFO  << "Number " << ief  <<" : Events passing " << iter->first << ": " << iter->second << endreq;
   m_h_efitem_all->Fill(ief,iter->second);
   std::string tmp_trigLevel =  iter->first.substr(0,5);
   if (tmp_trigLevel == "EF_mu") m_h_efitem->Fill(ief,iter->second);
   if (tmp_trigLevel == "EF_2m") m_h_efitem->Fill(ief,iter->second);
   ief++;
 }

 mLog << MSG::INFO  << "======= >Fakes: "  <<endreq;
 mLog << MSG::INFO  
      << "mu0 : EF SA = " << m_NfakeSA 
      << ", EF CB = " << m_NfakeCB 
      << ", EF TMEF SA = " << m_NfakeSA_tmef 
      << ", EF TMEF CB = " << m_NfakeCB_tmef 
      <<endreq;
 mLog << MSG::INFO  
      << "mu6 : EF SA = " << m_NfakeSA_mu6 
      << ", EF CB = " << m_NfakeCB_mu6 
      << ", EF TMEF SA = " << m_NfakeSA_tmef_mu6 
      << ", EF TMEF CB = " << m_NfakeCB_tmef_mu6 
      <<endreq;
 mLog << MSG::INFO  
      << "mu20 : EF SA = " << m_NfakeSA_mu20 
      << ", EF CB = " << m_NfakeCB_mu20
      << ", EF TMEF SA = " << m_NfakeSA_tmef_mu20 
      << ", EF TMEF CB = " << m_NfakeCB_tmef_mu20
      <<endreq;

 return StatusCode::SUCCESS;
 
}

///////////////////////////////////////////////////////////////////////////////////
/// Clear - clear CBNT members
StatusCode AnalysisSkeleton::CBNT_clear() {
  /// For Athena-Aware NTuple

  //  m_aan_size = 0;
  // m_aan_eta->clear();
  // m_aan_pt->clear();
  // m_aan_elecetres->clear();

  return StatusCode::SUCCESS;
}

//////////////////////////////////////////////////////////////////////////////////
/// Execute - on event by event

StatusCode AnalysisSkeleton::CBNT_execute() {
  MsgStream mLog( messageService(), name() );
  
  mLog << MSG::INFO << "in execute()" << endreq;

  /// remove the lines if not needed for your analysis
  /// they are here to exercice the Distributed Analysis

  ////////////////// To Be removed if NOT needed ////////////////////////////////

  StatusCode sc;
  sc = dumpMuonTrigger();
  if (sc.isFailure()) {
    mLog << MSG::ERROR << "Muon trigger dump failed" << endreq;
    return StatusCode::SUCCESS;
  }
  
  sc = fakeProb();
  if (sc.isFailure()) {
    mLog << MSG::ERROR << "fake prob failed" << endreq;
    return StatusCode::SUCCESS;
  }
  
  
  //  sc = dumpMuonTrigger_noTruth();
  //if (sc.isFailure()) {
  //mLog << MSG::ERROR << "Muon trigger notruth dump failed" << endreq;
  //return StatusCode::SUCCESS;
  //}
  
  sc = wrtOffline();
  if (sc.isFailure()) {
    mLog << MSG::ERROR << "no wrtOffline" << endreq;
    return StatusCode::SUCCESS;
  }

  sc=trackParticleAnalysis(); 
  if (sc.isFailure()) {
    mLog << MSG::ERROR << "no trackParticleAnal" << endreq;
    return StatusCode::SUCCESS;
  }
  

   if(m_doTrigDec){
     sc = trigDec();
     if (sc.isFailure()) {
       mLog << MSG::ERROR << "tri dec func failed" << endreq;
       return StatusCode::SUCCESS;
     }
   }
  


  return StatusCode::SUCCESS;
}


StatusCode AnalysisSkeleton::wrtOffline() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << " ################ START of wrt offline #####################" << endreq;
  StatusCode sc;


  const Analysis::MuonContainer* muonCont;
  std::string muonKey = "MuidMuonCollection";
  sc = m_storeGate->retrieve( muonCont, muonKey);
  if(sc.isFailure())
    mLog << MSG::WARNING
	 << "Container of muon particle with key " << muonKey << " not found in Store Gate"
	 << endreq;
  
  /// iterators over the container 
  //------------------------------
  Analysis::MuonContainer::const_iterator contItr  = muonCont->begin();
  Analysis::MuonContainer::const_iterator contItrE = muonCont->end();
  
  mLog << MSG::DEBUG << "============ Muon particle list ============" << endreq;
  
  unsigned int nEFSA=0;
  unsigned int nEFCB=0;
  for (; contItr != contItrE; ++contItr) {
    
    mLog << MSG::DEBUG << "Muon : " 
	 << " eta = " << (*contItr)->eta()
	 << " phi = " << (*contItr)->phi()
	 << " pt  = " << fabs((*contItr)->pt())  
	 << " Standalone  = " << (*contItr)->isStandAloneMuon()  
	 << " Combined  = " << (*contItr)->isCombinedMuon()  
      //<< " Low pt  = " << (*contItr)->isLowPtReconstructedMuon()  
	 << endreq;
       if( (*contItr)->isStandAloneMuon() ) nEFSA++;
       if( (*contItr)->isCombinedMuon() ) nEFCB++;
       if( !(*contItr)->isCombinedMuon() ) continue;

       double eta = (*contItr)->eta();
       double phi = (*contItr)->phi();
       if(fabs((*contItr)->eta())<1.05){
	 m_h_pt_offmuon_b->Fill(fabs((*contItr)->pt()) );
       } else {
	 m_h_pt_offmuon_e->Fill(fabs((*contItr)->pt()) );
       } 
       m_h_eta_offmuon->Fill((*contItr)->eta() );
       
       ////////////////////////////////////////////////////////////////
       ///////////////////////////////////////////////////////////////
       //LVL1 - Muon 
       ///////////////////////////////////////////////////////////////
       const DataHandle<LVL1_ROI> lvl1ROI;
       
       if( (  sc = m_storeGate->retrieve(lvl1ROI, "LVL1_ROI") ).isFailure() ) {
	 mLog << MSG::FATAL << "LVL1_ROI   not found in StoreGate" << endreq;
	 return  StatusCode::SUCCESS;
       }
       Muon_ROI l1muon;
       double deltaR = 1000;
       bool isFound = matchL1(deltaR,l1muon,lvl1ROI,eta,phi);
       mLog << MSG::DEBUG << "Match with L1 isFound =  " << isFound << endreq;
       if (isFound)    mLog << MSG::DEBUG << "Match with L1  muon RoI : pt= " << l1muon.pt()
			    << " DR = " << deltaR
			    << endreq;
       if(isFound && deltaR<m_deltaRMatchCut) {

	 if(fabs((*contItr)->eta())<1.05){
	   m_h_ptl1_vs_ptoffmuon_b->Fill(l1muon.pt()/1000, fabs((*contItr)->pt()));  
	   if(l1muon.pt()>5000) m_h_pt_offmuon_matched_l1_b_mu6->Fill(fabs((*contItr)->pt()) );
	   if(l1muon.pt()>8000) m_h_pt_offmuon_matched_l1_b_mu10->Fill(fabs((*contItr)->pt()));
	   if(l1muon.pt()>10000) m_h_pt_offmuon_matched_l1_b_mu11->Fill(fabs((*contItr)->pt()));
	   if(l1muon.pt()>15000) m_h_pt_offmuon_matched_l1_b_mu20->Fill(fabs((*contItr)->pt()));
	   if(l1muon.pt()>20000) m_h_pt_offmuon_matched_l1_b_mu40->Fill(fabs((*contItr)->pt()));
	   
	 } else {

	   m_h_ptl1_vs_ptoffmuon_e->Fill(l1muon.pt()/1000, fabs((*contItr)->pt()));  
	   if(l1muon.pt()>5000) m_h_pt_offmuon_matched_l1_e_mu6->Fill(fabs((*contItr)->pt()));
	   if(l1muon.pt()>8000) m_h_pt_offmuon_matched_l1_e_mu10->Fill(fabs((*contItr)->pt()));
	   if(l1muon.pt()>10000) m_h_pt_offmuon_matched_l1_e_mu11->Fill(fabs((*contItr)->pt()));
	   if(l1muon.pt()>15000) m_h_pt_offmuon_matched_l1_e_mu20->Fill(fabs((*contItr)->pt()));
	   if(l1muon.pt()>20000) m_h_pt_offmuon_matched_l1_e_mu40->Fill(fabs((*contItr)->pt()));
	 }
	 m_h_eta_offmuon_matched_l1->Fill( (*contItr)->eta(), 1.);
	 bool isFoundL2SA;
	 double deltaRL2SA;
	 //    int index = -1;
	 MuonFeature  l2muon;
	 float etal1 = l1muon.eta();
	 float phil1 = l1muon.phi();
	 const MuonFeatureContainer * muonFeatureContainer;
	 sc = m_storeGate->retrieve(muonFeatureContainer);
	 if (sc.isFailure()) {
	   mLog << MSG::DEBUG
		<< "No AOD MuonFeature container found in TDS"
		<< endreq;
	   return  StatusCode::SUCCESS;
	 } else {
	   mLog << MSG::DEBUG
		<< " MuonFeature container found in TDS with size " << muonFeatureContainer->size() 
		<< endreq;
	   isFoundL2SA = matchL2SA(deltaRL2SA,l2muon,muonFeatureContainer,etal1,phil1);
	 }

	 mLog << MSG::DEBUG << "wrt offline L2 SA isFound =  " << isFound << endreq;
	 if (isFoundL2SA)    mLog << MSG::DEBUG << "wrt offline Match with L2 SA muon RoI : pt= " 
				  << l2muon.pt()*1000.
				  << " DR = " << deltaRL2SA
				  << endreq;
	 if(isFoundL2SA && deltaRL2SA<m_deltaRMatchCut) {
	   if(fabs( (*contItr)->eta() )<1.05){
	     m_h_pt_offmuon_matched_l2sa_b->Fill(fabs((*contItr)->pt()));
	     if(fabs(l2muon.pt()*1000.)>5400) m_h_pt_offmuon_matched_l2sa_b_mu6->Fill(fabs((*contItr)->pt()) );
	     if(fabs(l2muon.pt()*1000.)>17500) m_h_pt_offmuon_matched_l2sa_b_mu20->Fill(fabs((*contItr)->pt()) );
	     m_h_phi_offmuon_matched_l2sa_b->Fill( (*contItr)->phi(), 1.);
	   } else {
	     m_h_pt_offmuon_matched_l2sa_e->Fill(fabs((*contItr)->pt()));
	     if(fabs(l2muon.pt()*1000.)>4900) m_h_pt_offmuon_matched_l2sa_e_mu6->Fill(fabs((*contItr)->pt()) );
	     if(fabs(l2muon.pt()*1000.)>17800) m_h_pt_offmuon_matched_l2sa_e_mu20->Fill(fabs((*contItr)->pt()) );
	     m_h_phi_offmuon_matched_l2sa_e->Fill( (*contItr)->phi(), 1.);   }
	   m_h_eta_offmuon_matched_l2sa->Fill( (*contItr)->eta(), 1.);
	 }

	 bool isFoundL2CB;
	 double deltaRL2CB;
	 //    int index = -1;
	 CombinedMuonFeature  cl2muon;
	 float cetal1 = l1muon.eta();
	 float cphil1 = l1muon.phi();
	 const CombinedMuonFeatureContainer * cmuonFeatureContainer;
	 sc = m_storeGate->retrieve(cmuonFeatureContainer);
	 if (sc.isFailure()) {
	   mLog << MSG::DEBUG
		<< "No AOD CombinedMuonFeature container found in TDS"
		<< endreq;
	   return  StatusCode::SUCCESS;
	 } else {
	   mLog << MSG::DEBUG
		<< "AOD CombinedMuonFeature container found in TDS with size " << cmuonFeatureContainer->size()
		<< endreq;
	   isFoundL2CB = matchL2CB(deltaRL2CB,cl2muon,cmuonFeatureContainer,cetal1,cphil1);
	 }
	
	 mLog << MSG::DEBUG << "wrt offline L2 CB isFound =  " << isFound << endreq;
	 
	 if(isFoundL2CB && deltaRL2CB<m_deltaRMatchCut) {
	   if(fabs((*contItr)->eta())<1.05){
	     m_h_pt_offmuon_matched_l2cb_b->Fill(fabs((*contItr)->pt()));
	     if(fabs(cl2muon.pt())>5800) m_h_pt_offmuon_matched_l2cb_b_mu6->Fill(fabs((*contItr)->pt()) );
	     if(fabs(cl2muon.pt())>19500) m_h_pt_offmuon_matched_l2cb_b_mu20->Fill(fabs((*contItr)->pt()) );
	     m_h_phi_offmuon_matched_l2cb_b->Fill( (*contItr)->phi(), 1.);
	   } else {
	     m_h_pt_offmuon_matched_l2cb_e->Fill(fabs((*contItr)->pt()));
	     if(fabs(cl2muon.pt())>5700) m_h_pt_offmuon_matched_l2cb_e_mu6->Fill(fabs((*contItr)->pt()) );
	     if(fabs(cl2muon.pt())>18500) m_h_pt_offmuon_matched_l2cb_e_mu20->Fill(fabs((*contItr)->pt()) );
	     m_h_phi_offmuon_matched_l2cb_e->Fill( (*contItr)->phi(), 1.);
	   }
	   m_h_eta_offmuon_matched_l2cb->Fill( (*contItr)->eta(), 1.);
	 }
	 
       }
  }//loop on offline muons
  
  //  if(nEFSA>1) return StatusCode::SUCCESS;
    
  return StatusCode::SUCCESS;
}


bool 
AnalysisSkeleton::matchL1 (double &deltaR, Muon_ROI &l1muon, const DataHandle<LVL1_ROI> lvl1ROI, const double eta, const double phi) const
{
  
  MsgStream mLog( messageService(), name() );
  
  deltaR = 10000.; // big value
  bool l_return = false;
  
  std::vector<int> roi_already_recorded;
  mLog << MSG::DEBUG << " =============== L1 successfully retrieved ============== " << endreq;  
  mLog << MSG::DEBUG << " L1 muon size " <<  lvl1ROI->getMuonROIs().size() << endreq;  
  
  for( LVL1_ROI::muons_type::const_iterator contItr =  lvl1ROI->getMuonROIs().begin(); 
       contItr !=  lvl1ROI->getMuonROIs().end(); ++contItr) {
    
    mLog << MSG::DEBUG << " -----------------> LVL1 muon RoI : eta = " << contItr->eta() 
	 << " phi = " << contItr->phi()
	 << " pt = " << contItr->pt() 
	 << endreq;
    double rtu = DR(*contItr,eta,phi);
    if ( rtu < deltaR ){
      l1muon = Muon_ROI(contItr->getROIWord(),contItr->eta(),contItr->phi(),contItr->getThrName(), contItr->getThrValue());
      deltaR = rtu;
      l_return = true;
    }
  }
  
  return l_return;
  
}

double 
AnalysisSkeleton::DR (const Muon_ROI &p1, const double & v_eta, const double & v_phi)  const 
{
  double phi1 = (p1.phi()>M_PI) ? p1.phi()-2*M_PI : p1.phi();
  double phi2 = (v_phi>M_PI) ? v_phi-2*M_PI : v_phi;
  double dphi = fabs(phi1-phi2);
  if(dphi>M_PI) dphi = 2*M_PI-dphi;
  double deta = p1.eta() - v_eta;
  return sqrt(dphi*dphi+deta*deta);
}


StatusCode AnalysisSkeleton::dumpMuonTrigger() {

  
  MsgStream mLog( messageService(), name() );
  mLog << MSG::DEBUG << " ################ START of Trigger Muon Dump ###################" << endreq;
  StatusCode sc;

  const double THR4 = 4000;  
  const double THR5 = 5000;  
  const double THR6 = 6000;  
  const double THR11 = 11000;  
  const double THR20 = 20000;  
  const double THR40 = 40000;  
  const float RESF = 1000;
  const int ABS_PDG = 13;


  //L1
  const DataHandle<LVL1_ROI> lvl1ROI;
  if( (  sc = m_storeGate->retrieve(lvl1ROI, "LVL1_ROI") ).isFailure() ) {
    mLog << MSG::FATAL << "LVL1_ROI   not found in StoreGate" << endreq;
    return  StatusCode::SUCCESS;
  }
  mLog << MSG::DEBUG << " =============== L1 successfully retrieved ============== " << endreq;  
  for( LVL1_ROI::muons_type::const_iterator l1Itr =  lvl1ROI->getMuonROIs().begin(); 
       l1Itr !=  lvl1ROI->getMuonROIs().end(); ++l1Itr) {
    
    mLog << MSG::DEBUG << "LVL1 muon RoI : eta = " << l1Itr->eta() 
	 << " phi = " << l1Itr->phi()
	 << " pt = " << l1Itr->pt() 
	 << endreq;
    if(fabs(l1Itr->eta()<1.05)){
      m_h_muonpt_l1_b->Fill( l1Itr->pt(), 1.);
      m_h_muonphi_l1_b->Fill( l1Itr->phi(), 1.);
    } else {
      m_h_muonpt_l1_e->Fill( l1Itr->pt(), 1.);
      m_h_muonphi_l1_e->Fill( l1Itr->phi(), 1.);
    }
    m_h_muoneta_l1->Fill( l1Itr->eta(), 1.);
  }

  //Truth
  mLog << MSG::DEBUG << " ============ Loading Truth  =============="  << endreq;
  
  const TruthParticleContainer* truthTDS;
  sc=m_storeGate->retrieve( truthTDS, m_truthParticleContainerName );
  //  sc=m_storeGate->retrieve( truthTDS );
  if( sc.isFailure()  ||  !truthTDS ) {
    mLog << MSG::WARNING
	 << "Container of truth particle not found in Store Gate"
	 << endreq; 
    return StatusCode::SUCCESS;
  } else {
    mLog << MSG::DEBUG << "Truth container successfully retrieved" << endreq;
    
    /// iterators over the container 
    TruthParticleContainer::const_iterator contItr  = truthTDS->begin();
    TruthParticleContainer::const_iterator contItrE = truthTDS->end();
    //    mLog << MSG::DEBUG << "============ Truth particle list ============" << endreq;
    
    for (unsigned int sgId=0; contItr!=contItrE; ++contItr, ++sgId) {    
      
      if((*contItr)->status()!=1) continue;
      if( fabs((*contItr)->pdgId()) != 13) continue;
      if ((*contItr)->barcode() > 1000000 ) continue;
      
      int mother_id=0;
      if((*contItr)->nParents()) mother_id = (*contItr)->mother()->pdgId();
      
      // dump for debug
      mLog << MSG::DEBUG 
	   << "=================> SG sgId = " << sgId
	   << " PDG id = "  << (*contItr)->pdgId() 
	   << " status = " << (*contItr)->status() 
	   << " barcode = " << (*contItr)->barcode()
	   << " mother = " << mother_id
	   << " eta = " << (*contItr)->eta()
	   << " phi = " << (*contItr)->phi()
	   << " pt  = " << fabs((*contItr)->pt())  
	// << " ( px, py, pz, m ) = "
	//	 << "( " << fabs((*contItr)->px())  
	// << " ," << fabs((*contItr)->py())  
	// << " ," << fabs((*contItr)->pz())  
	   << " m = " << fabs((*contItr)->m())  
	// << " )" 
	   << endreq;

      if(fabs((*contItr)->pt()) < 1000.) continue;

      if(fabs((*contItr)->pt()) < 4000.) m_deltaRMatchCut = m_deltaRMatchCutLOW;
      
      if(fabs((*contItr)->pt() )> THR4+m_PlateauStep )  m_h_MCeta_4->Fill((*contItr)->eta(),1.);
      if(fabs((*contItr)->pt() )> THR6+m_PlateauStep )  m_h_MCeta_6->Fill((*contItr)->eta(),1.);
      if(fabs((*contItr)->pt() )> THR20+m_PlateauStep )  m_h_MCeta_20->Fill((*contItr)->eta(),1.);
      if(fabs((*contItr)->pt() )> THR40+m_PlateauStep )  m_h_MCeta_40->Fill((*contItr)->eta(),1.);

      if(fabs( (*contItr)->eta() ) < 1.05){
	m_h_MCpt_b->Fill(fabs((*contItr)->pt() ),1.);
      } else if(fabs((*contItr)->eta()) < 2.5 && fabs((*contItr)->eta()) > 1.05)  {
	m_h_MCpt_e->Fill(fabs((*contItr)->pt() ),1.);
      }
      
      float eta = (*contItr)->eta();
      float phi = (*contItr)->phi();
          

      Muon_ROI l1muon;
      double deltaR = 1000;
      bool isFound = matchL1(deltaR,l1muon,lvl1ROI,eta,phi);
      mLog << MSG::DEBUG << "Match with L1 isFound =  " << isFound << endreq;
      if (isFound)    mLog << MSG::DEBUG << "Match with L1  muon RoI : pt= " << l1muon.pt() 
			   << " eta = " << l1muon.eta() 
			   << " phi = " << l1muon.phi()  
			   << " DR = " << deltaR
			   << endreq;
      if(!isFound) continue;
      m_h_DR_l1->Fill(deltaR,1) ;
      if(deltaR>m_deltaRMatchCutL1){
	mLog << MSG::DEBUG << "DR too high !!! "    << endreq;
	continue;
      }
      //      if(fabs( l1muon.eta() )<1.05){
      if(fabs( eta )<1.05){
	m_h_muonpt_l1_b_truth->Fill(fabs((*contItr)->pt()),1.);
	if( l1muon.pt() > THR5)       m_h_muonpt_l1_b_truth_6->Fill(fabs((*contItr)->pt()),1.);
	if( l1muon.pt() > THR11)       m_h_muonpt_l1_b_truth_20->Fill(fabs((*contItr)->pt()),1.);
	if( l1muon.pt() > THR20)       m_h_muonpt_l1_b_truth_40->Fill(fabs((*contItr)->pt()),1.);
      } else {
	m_h_muonpt_l1_e_truth->Fill(fabs((*contItr)->pt()),1.);
	if( l1muon.pt() > THR5)       m_h_muonpt_l1_e_truth_6->Fill(fabs((*contItr)->pt()),1.);
	if( l1muon.pt() > THR11)       m_h_muonpt_l1_e_truth_20->Fill(fabs((*contItr)->pt()),1.);
	if( l1muon.pt() > THR20)       m_h_muonpt_l1_e_truth_40->Fill(fabs((*contItr)->pt()),1.);
    }
      m_h_muoneta_l1->Fill( l1muon.eta(), 1.);
      
      if(fabs((*contItr)->pt()) > THR4+m_PlateauStep )  m_h_muoneta_l1_truth->Fill((*contItr)->eta(),1.);
      if(fabs((*contItr)->pt()) > THR6+m_PlateauStep )  m_h_muoneta_l1_truth_6->Fill((*contItr)->eta(),1.);
      if(fabs((*contItr)->pt()) > THR20+m_PlateauStep )  m_h_muoneta_l1_truth_20->Fill((*contItr)->eta(),1.);
      if(fabs((*contItr)->pt()) > THR40+m_PlateauStep )  m_h_muoneta_l1_truth_40->Fill((*contItr)->eta(),1.);
      
      
      
      ///////////////////////////////////////////////////////////////////////
      //L2 MuonSA
      ////////////////////////////////////////////////////////////////////
      // get iterators to all containers of type MuonFeature
      bool isFoundL2SA = false;
      //      double deltaR;
      //    int index = -1;
      MuonFeature  l2muon;
      //      const DataHandle<MuonFeatureContainer> muonFeatureContainer;
      const MuonFeatureContainer * muonFeatureContainer;
      sc = m_storeGate->retrieve(muonFeatureContainer);
      if (sc.isFailure()) {
	mLog << MSG::DEBUG
	   << "No AOD MuonFeature container found in TDS"
	     << endreq;
	return  StatusCode::SUCCESS;
      } else {
	mLog << MSG::DEBUG
	     << " MuonFeature container found in TDS with size " << muonFeatureContainer->size() 
	     << endreq;
      	isFoundL2SA = matchL2SA(deltaR,l2muon,muonFeatureContainer,eta,phi);
      }

      mLog << MSG::DEBUG << "L2 SA isFound =  " << isFoundL2SA << endreq;
      if (isFoundL2SA)    mLog << MSG::DEBUG << "Match with L2 SA muon RoI : pt= " << l2muon.pt()*1000.
			       << " DR = " << deltaR
			       << endreq;

      
      if(isFoundL2SA) m_h_DR_l2ms->Fill(deltaR,1) ;
      if(!isFoundL2SA) continue;
      if(deltaR>m_deltaRMatchCut) continue;
      double ptRatio = fabs(l2muon.pt())*1000./fabs((*contItr)->pt());
      if( ptRatio>2 || ptRatio<0 ) {
	mLog << MSG::WARNING << "****** Pt Ratio :   " << ptRatio << endreq;	
      }
      

      if(isFoundL2SA && deltaR<m_deltaRMatchCut) {
	if(ptRatio < 10  &&  ptRatio>0 ){
	  if(fabs((*contItr)->pt())<5000.)       mLog << MSG::WARNING << "low pt muon selected !!!  " << endreq;
	  if(fabs((*contItr)->eta()) <1.05  ) {
	    m_h_muonpt_l2ms_b_truth->Fill(fabs((*contItr)->pt()),1.);
	    if( fabs(l2muon.pt())*1000 > 5400)       m_h_muonpt_l2ms_b_truth_6->Fill(fabs((*contItr)->pt()),1.);
	    if( fabs(l2muon.pt())*1000 > 17500)       m_h_muonpt_l2ms_b_truth_20->Fill(fabs((*contItr)->pt()),1.);
	    if( fabs(l2muon.pt())*1000 > THR40-RESF*10.)       m_h_muonpt_l2ms_b_truth_40->Fill(fabs((*contItr)->pt()),1.);
	  } else {
	    m_h_muonpt_l2ms_e_truth->Fill(fabs((*contItr)->pt()),1.);
	    if( fabs(l2muon.pt())*1000 > 4900)       m_h_muonpt_l2ms_e_truth_6->Fill(fabs((*contItr)->pt()),1.);
	    if( fabs(l2muon.pt())*1000 > 17800)       m_h_muonpt_l2ms_e_truth_20->Fill(fabs((*contItr)->pt()),1.);
	    if( fabs(l2muon.pt())*1000 > THR40-RESF*10.)       m_h_muonpt_l2ms_e_truth_40->Fill(fabs((*contItr)->pt()),1.);
	}
	  
	  //	if(fabs((*contItr)->pt()) > THR4+m_PlateauStep )  
	  m_h_muoneta_l2ms_truth->Fill((*contItr)->eta(),1.);
	  if(fabs((*contItr)->pt()) > THR6+m_PlateauStep )  m_h_muoneta_l2ms_truth_6->Fill((*contItr)->eta(),1.);
	  if(fabs((*contItr)->pt()) > THR20+m_PlateauStep )  m_h_muoneta_l2ms_truth_20->Fill((*contItr)->eta(),1.);
	if(fabs((*contItr)->pt()) > THR40+m_PlateauStep )  m_h_muoneta_l2ms_truth_40->Fill((*contItr)->eta(),1.);
	
	m_h_ptres_vs_pt_l2ms->Fill(fabs(1./l2muon.pt())/fabs((*contItr)->pt()) , fabs( (*contItr)->pt()) );
	
	}
      }

      ///////////////////////////////////////////////////////////////////////
      //L2 MuonCB
      ////////////////////////////////////////////////////////////////////
      // get iterators to all containers of type MuonFeature
      bool isFoundL2CB = false;
      //      double deltaR;
      //    int index = -1;
      CombinedMuonFeature  cl2muon;
      const CombinedMuonFeatureContainer * cmuonFeatureContainer;
      sc = m_storeGate->retrieve(cmuonFeatureContainer);
      if (sc.isFailure()) {
	mLog << MSG::DEBUG
	   << "No AOD CombinedMuonFeature container found in TDS"
	     << endreq;
	return  StatusCode::SUCCESS;
      } else {
	mLog << MSG::DEBUG
	     << "AOD CombinedMuonFeature container found in TDS with size " << cmuonFeatureContainer->size()
	     << endreq;
	isFoundL2CB = matchL2CB(deltaR,cl2muon,cmuonFeatureContainer,eta,phi);
      }
      mLog << MSG::DEBUG << "L2 CB isFound =  " << isFoundL2CB << endreq;
      if (isFoundL2CB)    mLog << MSG::DEBUG << "Match with L2 CB muon RoI : pt= " << cl2muon.pt()
			       << " DR = " << deltaR
			       << endreq;
      if(isFoundL2CB) m_h_DR_l2cb->Fill(deltaR,1) ;
      if(!isFoundL2CB) continue;
      if(deltaR>m_deltaRMatchCut) continue;
      ptRatio = fabs(cl2muon.pt())/fabs((*contItr)->pt());
      if( ptRatio>2 || ptRatio<0 ) {
	mLog << MSG::WARNING << "****** Pt Ratio :   " << ptRatio << endreq;	
      }


      if(deltaR<m_deltaRMatchCut) {
	if(ptRatio < 2 &&  ptRatio>0 ){
	  if(fabs((*contItr)->pt())<5000.)       mLog << MSG::WARNING << "low pt muon selected !!!  " << endreq;
	  if(fabs((*contItr)->eta()) <1.05  ) {
	    m_h_muonpt_l2cb_b_truth->Fill(fabs((*contItr)->pt()),1.);
	    if( fabs(cl2muon.pt()) > 5800)       m_h_muonpt_l2cb_b_truth_6->Fill(fabs((*contItr)->pt()),1.);
	    if( fabs(cl2muon.pt()) > 19500)       m_h_muonpt_l2cb_b_truth_20->Fill(fabs((*contItr)->pt()),1.);
	    if( fabs(cl2muon.pt()) > THR40-RESF*10.)       m_h_muonpt_l2cb_b_truth_40->Fill(fabs((*contItr)->pt()),1.);
	  } else {
	    m_h_muonpt_l2cb_e_truth->Fill(fabs((*contItr)->pt()),1.);
	    if( fabs(cl2muon.pt()) > 5700)       m_h_muonpt_l2cb_e_truth_6->Fill(fabs((*contItr)->pt()),1.);
	    if( fabs(cl2muon.pt()) > 18500)       m_h_muonpt_l2cb_e_truth_20->Fill(fabs((*contItr)->pt()),1.);
	    if( fabs(cl2muon.pt()) > THR40-RESF*10.)       m_h_muonpt_l2cb_e_truth_40->Fill(fabs((*contItr)->pt()),1.);
	  }
	  
	  //if(fabs((*contItr)->pt()) > THR4+m_PlateauStep ) 
	  m_h_muoneta_l2cb_truth->Fill((*contItr)->eta(),1.);
	  if(fabs((*contItr)->pt()) > THR6+m_PlateauStep )  m_h_muoneta_l2cb_truth_6->Fill((*contItr)->eta(),1.);
	  if(fabs((*contItr)->pt()) > THR20+m_PlateauStep )  m_h_muoneta_l2cb_truth_20->Fill((*contItr)->eta(),1.);
	  if(fabs((*contItr)->pt()) > THR40+m_PlateauStep )  m_h_muoneta_l2cb_truth_40->Fill((*contItr)->eta(),1.);
	  
	}
	m_h_ptres_vs_pt_l2cb->Fill(fabs(1./cl2muon.pt())/fabs((*contItr)->pt()) , fabs( (*contItr)->pt()) );
      }
      
      //EF - Muon
      bool isFoundEFMS = false;
      TrigMuonEF efmuon;
      double deltaRMS = 100000.;
      const DataHandle< TrigMuonEFContainer > trigMuon;
      //const DataHandle< TrigMuonEFContainer > trigMuon_ms;
      //const DataHandle< TrigMuonEFContainer > trigMuon_sa;
      const DataHandle< TrigMuonEFContainer > lastTrigMuon;
      sc = m_storeGate->retrieve(trigMuon,lastTrigMuon);
      if (sc.isFailure()) {
	mLog << MSG::DEBUG << "No TrigMuonEFContainer found" << endreq;
	return  StatusCode::SUCCESS;
      }  else {
	mLog << MSG::DEBUG << "TrigMuonEFContainers retrieved" << endreq;
	isFoundEFMS = matchEF(deltaRMS,efmuon,trigMuon,lastTrigMuon,eta,phi, 0);
	
      
	mLog << MSG::DEBUG << "EF MS isFound =  " << isFoundEFMS << endreq;
	//if(!isFoundEFMS) continue ;
	if (isFoundEFMS)  mLog << MSG::DEBUG << "Match with EF MS muon RoI : pt= " << efmuon.pt()
			       << " DR = " << deltaRMS
			       << endreq;
	
	
	if(isFoundEFMS) m_h_DR_efms->Fill(deltaRMS,1) ;
	
	if(isFoundEFMS && deltaRMS<m_deltaRMatchCut) {
	  if(fabs((*contItr)->eta()) <1.05  ) {
	    m_h_muonpt_efms_b_truth->Fill(fabs((*contItr)->pt()),1.);
	    if( fabs(1./efmuon.iPt()) > THR6)       m_h_muonpt_efms_b_truth_6->Fill(fabs((*contItr)->pt()),1.);
	    if( fabs(1./efmuon.iPt()) > THR20)       m_h_muonpt_efms_b_truth_20->Fill(fabs((*contItr)->pt()),1.);
	    if( fabs(1./efmuon.iPt()) > THR40)       m_h_muonpt_efms_b_truth_40->Fill(fabs((*contItr)->pt()),1.);
	  } else {
	    m_h_muonpt_efms_e_truth->Fill(fabs((*contItr)->pt()),1.);
	    if( fabs(1./efmuon.iPt()) > THR6)       m_h_muonpt_efms_e_truth_6->Fill(fabs((*contItr)->pt()),1.);
	    if( fabs(1./efmuon.iPt()) > THR20)       m_h_muonpt_efms_e_truth_20->Fill(fabs((*contItr)->pt()),1.);
	    if( fabs(1./efmuon.iPt()) > THR40)       m_h_muonpt_efms_e_truth_40->Fill(fabs((*contItr)->pt()),1.);
	  }
	  
	  if(fabs((*contItr)->pt()) > THR4+m_PlateauStep )  m_h_muoneta_efms_truth->Fill((*contItr)->eta(),1.);
	  if(fabs((*contItr)->pt()) > THR6+m_PlateauStep )  m_h_muoneta_efms_truth_6->Fill((*contItr)->eta(),1.);
	  if(fabs((*contItr)->pt()) > THR20+m_PlateauStep )  m_h_muoneta_efms_truth_20->Fill((*contItr)->eta(),1.);
	  if(fabs((*contItr)->pt()) > THR40+m_PlateauStep )  m_h_muoneta_efms_truth_40->Fill((*contItr)->eta(),1.);
	} 
      }


      //TM SA
      double deltaRSA = 100000.;
      bool isFoundEFSA = false;
      const DataHandle< TrigMuonEFContainer > trigMuon_sa;
      sc = m_storeGate->retrieve(trigMuon_sa,lastTrigMuon);
      if (sc.isFailure()) {
	mLog << MSG::DEBUG << "No TrigMuonEFContainer found" << endreq;
	return  StatusCode::SUCCESS;
      }  else {
	isFoundEFSA = matchEF(deltaRSA,efmuon,trigMuon_sa,lastTrigMuon,eta,phi, 1);
	mLog << MSG::DEBUG << "EF SA isFound =  " << isFoundEFSA << endreq;
	if (isFoundEFSA)  mLog << MSG::DEBUG << "Match with EF SA muon RoI : pt= " << efmuon.pt()
			       << " DR = " << deltaRSA
			       << endreq;
	
	
	if(isFoundEFSA) m_h_DR_efsa->Fill(deltaRSA,1) ;

	ptRatio = fabs(efmuon.pt())/fabs((*contItr)->pt());
	if( ptRatio>2 || ptRatio<0 ) {
	  mLog << MSG::WARNING << "****** TM SA Pt Ratio :   " << ptRatio << endreq;	
	}

	
	if(isFoundEFSA && deltaRSA<m_deltaRMatchCut) {
	  if(ptRatio < 2 &&  ptRatio>0 ){
	    if(fabs((*contItr)->pt())<5000.)       mLog << MSG::WARNING << "EF SA low pt muon selected !!!  " << endreq;
	    
	    if(fabs((*contItr)->eta()) <1.05  ) {
	      m_h_muonpt_efsa_b_truth->Fill(fabs((*contItr)->pt()),1.);
	      if( fabs(1./efmuon.iPt()) > THR6)       m_h_muonpt_efsa_b_truth_6->Fill(fabs((*contItr)->pt()),1.);
	      if( fabs(1./efmuon.iPt()) > THR20)       m_h_muonpt_efsa_b_truth_20->Fill(fabs((*contItr)->pt()),1.);
	      if( fabs(1./efmuon.iPt()) > THR40)       m_h_muonpt_efsa_b_truth_40->Fill(fabs((*contItr)->pt()),1.);
	    } else {
	      m_h_muonpt_efsa_e_truth->Fill(fabs((*contItr)->pt()),1.);
	      if( fabs(1./efmuon.iPt()) > THR6)       m_h_muonpt_efsa_e_truth_6->Fill(fabs((*contItr)->pt()),1.);
	      if( fabs(1./efmuon.iPt()) > THR20)       m_h_muonpt_efsa_e_truth_20->Fill(fabs((*contItr)->pt()),1.);
	      if( fabs(1./efmuon.iPt()) > THR40)       m_h_muonpt_efsa_e_truth_40->Fill(fabs((*contItr)->pt()),1.);
	    }
	    
	    //if(fabs((*contItr)->pt()) > THR4+m_PlateauStep )  
	    m_h_muoneta_efsa_truth->Fill((*contItr)->eta(),1.);
	    if(fabs((*contItr)->pt()) > THR6+m_PlateauStep )  m_h_muoneta_efsa_truth_6->Fill((*contItr)->eta(),1.);
	    if(fabs((*contItr)->pt()) > THR20+m_PlateauStep )  m_h_muoneta_efsa_truth_20->Fill((*contItr)->eta(),1.);
	  if(fabs((*contItr)->pt()) > THR40+m_PlateauStep )  m_h_muoneta_efsa_truth_40->Fill((*contItr)->eta(),1.);
	  }
	  m_h_ptres_vs_pt_efsa->Fill(fabs(1./efmuon.iPt())/fabs((*contItr)->pt()) , fabs( (*contItr)->pt()) );
	}
      }
      
      //TMEF SA
      double deltaRSA_tmef = 100000.;
      bool isFoundEFSA_tmef = false;
      const DataHandle< TrigMuonEFContainer > trigMuon_sa_tmef;
      sc = m_storeGate->retrieve(trigMuon_sa_tmef,lastTrigMuon);
      if (sc.isFailure()) {
	mLog << MSG::DEBUG << "No TrigMuonEFContainer found" << endreq;
	return  StatusCode::SUCCESS;
      }  else {
	isFoundEFSA_tmef = matchEF(deltaRSA_tmef,efmuon,trigMuon_sa_tmef,lastTrigMuon,eta,phi, 4);
	mLog << MSG::DEBUG << "EF SA TMEF isFound =  " << isFoundEFSA_tmef << endreq;
	if (isFoundEFSA_tmef)  mLog << MSG::DEBUG << "Match with EF SA TMEF muon RoI : pt= " << efmuon.pt()
			       << " DR = " << deltaRSA_tmef
			       << endreq;
	
	
	if(isFoundEFSA_tmef) m_h_DR_efsa_tmef->Fill(deltaRSA_tmef,1) ;
	ptRatio = fabs(efmuon.pt())/fabs((*contItr)->pt());
	if( ptRatio>2 || ptRatio<0 ) {
	  mLog << MSG::WARNING << "****** TMEF SA Pt Ratio :   " << ptRatio << endreq;	
	}
	
	
	if(isFoundEFSA_tmef && deltaRSA_tmef<m_deltaRMatchCut) {
	  if(ptRatio < 2 &&  ptRatio>0 ){
	    if(fabs((*contItr)->pt())<5000.)       mLog << MSG::WARNING << "EF SA low pt muon selected !!!  " << endreq;
	    if(fabs((*contItr)->eta()) <1.05  ) {
	      m_h_muonpt_efsa_b_truth_tmef->Fill(fabs((*contItr)->pt()),1.);
	      if( fabs(1./efmuon.iPt()) > THR6)       m_h_muonpt_efsa_b_truth_6_tmef->Fill(fabs((*contItr)->pt()),1.);
	      if( fabs(1./efmuon.iPt()) > THR20)       m_h_muonpt_efsa_b_truth_20_tmef->Fill(fabs((*contItr)->pt()),1.);
	      if( fabs(1./efmuon.iPt()) > THR40)       m_h_muonpt_efsa_b_truth_40_tmef->Fill(fabs((*contItr)->pt()),1.);
	    } else {
	      m_h_muonpt_efsa_e_truth_tmef->Fill(fabs((*contItr)->pt()),1.);
	      if( fabs(1./efmuon.iPt()) > THR6)       m_h_muonpt_efsa_e_truth_6_tmef->Fill(fabs((*contItr)->pt()),1.);
	      if( fabs(1./efmuon.iPt()) > THR20)       m_h_muonpt_efsa_e_truth_20_tmef->Fill(fabs((*contItr)->pt()),1.);
	      if( fabs(1./efmuon.iPt()) > THR40)       m_h_muonpt_efsa_e_truth_40_tmef->Fill(fabs((*contItr)->pt()),1.);
	    }
	    
	    //	  if(fabs((*contItr)->pt()) > THR4+m_PlateauStep )  m_h_muoneta_efsa_truth_tmef->Fill((*contItr)->eta(),1.);
	    m_h_muoneta_efsa_truth_tmef->Fill((*contItr)->eta(),1.);
	    if(fabs((*contItr)->pt()) > THR6+m_PlateauStep )  m_h_muoneta_efsa_truth_6_tmef->Fill((*contItr)->eta(),1.);
	    if(fabs((*contItr)->pt()) > THR20+m_PlateauStep )  m_h_muoneta_efsa_truth_20_tmef->Fill((*contItr)->eta(),1.);
	    if(fabs((*contItr)->pt()) > THR40+m_PlateauStep )  m_h_muoneta_efsa_truth_40_tmef->Fill((*contItr)->eta(),1.);
	  

	  }
	  m_h_ptres_vs_pt_efsa_tmef->Fill(fabs(1./efmuon.iPt())/fabs((*contItr)->pt()) , fabs( (*contItr)->pt()) );
	}
      }      

      double deltaRCB = 100000.;
      bool isFoundEFCB = false;
      const DataHandle< TrigMuonEFContainer > trigMuon_cb;
      sc = m_storeGate->retrieve(trigMuon_cb,lastTrigMuon);
      if (sc.isFailure()) {
	mLog << MSG::DEBUG << "No TrigMuonEFContainer found" << endreq;
	return  StatusCode::SUCCESS;
      }  else {
	isFoundEFCB = matchEF(deltaRCB,efmuon,trigMuon_cb,lastTrigMuon,eta,phi, 101);
	mLog << MSG::DEBUG << "EF CB isFound =  " << isFoundEFCB << endreq;
	if (isFoundEFCB)  mLog << MSG::DEBUG << "Match with EF CB muon RoI : pt= " << efmuon.pt()
			       << " DR = " << deltaRCB
			       << endreq;
	
	
	if(isFoundEFCB) m_h_DR_efcb->Fill(deltaRCB,1) ;
	ptRatio = fabs(efmuon.pt())/fabs((*contItr)->pt());
	if( ptRatio>2 || ptRatio<0 ) {
	  mLog << MSG::WARNING << "****** CB Pt Ratio :   " << ptRatio << endreq;	
	}
	

	if(isFoundEFCB && deltaRCB<m_deltaRMatchCut) {
	  if(ptRatio < 2 &&  ptRatio>0 ){
	    if(fabs((*contItr)->pt())<5000.)       mLog << MSG::WARNING << "EF CB low pt muon selected !!!  " << endreq;
	    if(fabs((*contItr)->eta()) <1.05  ) {
	      m_h_muonpt_efcb_b_truth->Fill(fabs((*contItr)->pt()),1.);
	      if( fabs(1./efmuon.iPt()) > THR6)       m_h_muonpt_efcb_b_truth_6->Fill(fabs((*contItr)->pt()),1.);
	      if( fabs(1./efmuon.iPt()) > THR20)       m_h_muonpt_efcb_b_truth_20->Fill(fabs((*contItr)->pt()),1.);
	      if( fabs(1./efmuon.iPt()) > THR40)       m_h_muonpt_efcb_b_truth_40->Fill(fabs((*contItr)->pt()),1.);
	    } else {
	      m_h_muonpt_efcb_e_truth->Fill(fabs((*contItr)->pt()),1.);
	      if( fabs(1./efmuon.iPt()) > THR6)       m_h_muonpt_efcb_e_truth_6->Fill(fabs((*contItr)->pt()),1.);
	      if( fabs(1./efmuon.iPt()) > THR20)       m_h_muonpt_efcb_e_truth_20->Fill(fabs((*contItr)->pt()),1.);
	      if( fabs(1./efmuon.iPt()) > THR40)       m_h_muonpt_efcb_e_truth_40->Fill(fabs((*contItr)->pt()),1.);
	    }
	    
	    //	  if(fabs((*contItr)->pt()) > THR4+m_PlateauStep )  m_h_muoneta_efcb_truth->Fill((*contItr)->eta(),1.);
	    m_h_muoneta_efcb_truth->Fill((*contItr)->eta(),1.);
	    if(fabs((*contItr)->pt()) > THR6+m_PlateauStep )  m_h_muoneta_efcb_truth_6->Fill((*contItr)->eta(),1.);
	    if(fabs((*contItr)->pt()) > THR20+m_PlateauStep )  m_h_muoneta_efcb_truth_20->Fill((*contItr)->eta(),1.);
	    if(fabs((*contItr)->pt()) > THR40+m_PlateauStep )  m_h_muoneta_efcb_truth_40->Fill((*contItr)->eta(),1.);
	  } 
	  m_h_ptres_vs_pt_efcb->Fill(fabs(1./efmuon.iPt())/fabs((*contItr)->pt()) , fabs( (*contItr)->pt()) );
	}

      }

      
      //TMEF CB
      double deltaRCB_tmef = 100000.;
      bool isFoundEFCB_tmef = false;
      const DataHandle< TrigMuonEFContainer > trigMuon_cb_tmef;
      sc = m_storeGate->retrieve(trigMuon_cb_tmef,lastTrigMuon);
      if (sc.isFailure()) {
	mLog << MSG::DEBUG << "No TrigMuonEFContainer found" << endreq;
	return  StatusCode::SUCCESS;
      }  else {
	isFoundEFCB_tmef = matchEF(deltaRCB_tmef,efmuon,trigMuon_cb_tmef,lastTrigMuon,eta,phi, 5);
	mLog << MSG::DEBUG << "EF CB TMEF isFound =  " << isFoundEFCB_tmef << endreq;
	if (isFoundEFCB_tmef)  mLog << MSG::DEBUG << "Match with EF CB TMEF muon RoI : pt= " << efmuon.pt()
			       << " DR = " << deltaRCB_tmef
			       << endreq;
	
	
	if(isFoundEFCB_tmef) m_h_DR_efcb_tmef->Fill(deltaRCB_tmef,1) ;
	ptRatio = fabs(efmuon.pt())/fabs((*contItr)->pt());
	if( ptRatio>2 || ptRatio<0 ) {
	  mLog << MSG::WARNING << "****** CB Pt Ratio :   " << ptRatio << endreq;	
	}
	

	if(isFoundEFCB_tmef && deltaRCB_tmef<m_deltaRMatchCut) {
	    if(ptRatio < 2 &&  ptRatio>0 ){
	      if(fabs((*contItr)->pt())<5000.)       mLog << MSG::WARNING << "EF CB low pt muon selected !!!  " << endreq;
	      if(fabs((*contItr)->eta()) <1.05  ) {
		m_h_muonpt_efcb_b_truth_tmef->Fill(fabs((*contItr)->pt()),1.);
		if( fabs(1./efmuon.iPt()) > THR6)       m_h_muonpt_efcb_b_truth_6_tmef->Fill(fabs((*contItr)->pt()),1.);
		if( fabs(1./efmuon.iPt()) > THR20)       m_h_muonpt_efcb_b_truth_20_tmef->Fill(fabs((*contItr)->pt()),1.);
		if( fabs(1./efmuon.iPt()) > THR40)       m_h_muonpt_efcb_b_truth_40_tmef->Fill(fabs((*contItr)->pt()),1.);
	      } else {
		m_h_muonpt_efcb_e_truth_tmef->Fill(fabs((*contItr)->pt()),1.);
		if( fabs(1./efmuon.iPt()) > THR6)       m_h_muonpt_efcb_e_truth_6_tmef->Fill(fabs((*contItr)->pt()),1.);
		if( fabs(1./efmuon.iPt()) > THR20)       m_h_muonpt_efcb_e_truth_20_tmef->Fill(fabs((*contItr)->pt()),1.);
		if( fabs(1./efmuon.iPt()) > THR40)       m_h_muonpt_efcb_e_truth_40_tmef->Fill(fabs((*contItr)->pt()),1.);
	      }
	      
	      //	  if(fabs((*contItr)->pt()) > THR4+m_PlateauStep )  m_h_muoneta_efcb_truth_tmef->Fill((*contItr)->eta(),1.);
	      m_h_muoneta_efcb_truth_tmef->Fill((*contItr)->eta(),1.);
	      if(fabs((*contItr)->pt()) > THR6+m_PlateauStep )  m_h_muoneta_efcb_truth_6_tmef->Fill((*contItr)->eta(),1.);
	      if(fabs((*contItr)->pt()) > THR20+m_PlateauStep )  m_h_muoneta_efcb_truth_20_tmef->Fill((*contItr)->eta(),1.);
	      if(fabs((*contItr)->pt()) > THR40+m_PlateauStep )  m_h_muoneta_efcb_truth_40_tmef->Fill((*contItr)->eta(),1.);
	    }
	    m_h_ptres_vs_pt_efcb_tmef->Fill(fabs(1./efmuon.iPt())/fabs((*contItr)->pt()) , fabs( (*contItr)->pt()) );
	}

      }


    }//end MC loop
  }


  mLog <<MSG::DEBUG << "==========END of TrigMuon DUMP===========" << endreq;

  return StatusCode::SUCCESS;
  
}


StatusCode AnalysisSkeleton::fakeProb() {


  MsgStream mLog( messageService(), name() );
  mLog << MSG::DEBUG << "================ Fakes ========== " << endreq;

  const TruthParticleContainer* truthTDS;
  StatusCode  sc=m_storeGate->retrieve( truthTDS, m_truthParticleContainerName );
  //  sc=m_storeGate->retrieve( truthTDS );
  if( sc.isFailure()  ||  !truthTDS ) {
    mLog << MSG::WARNING
	 << "Container of truth particle not found in Store Gate"
	 << endreq; 
    return StatusCode::SUCCESS;
  } else mLog << MSG::DEBUG << "Truth container successfully retrieved" << endreq;
  TruthParticleContainer::const_iterator contItr  = truthTDS->begin();
  TruthParticleContainer::const_iterator contItrE = truthTDS->end();
  //    mLog << MSG::DEBUG << "============ Truth particle list ============" << endreq;
  
  for (unsigned int sgId=0; contItr!=contItrE; ++contItr, ++sgId) {    
    
    if((*contItr)->status()!=1) continue;
    if( fabs((*contItr)->pdgId()) != 13) continue;
    if ((*contItr)->barcode() > 1000000 ) continue;

    int mother_id=0;
    if((*contItr)->nParents()) mother_id = (*contItr)->mother()->pdgId();
    
    // dump for debug
    mLog << MSG::DEBUG 
	 << "=================> SG sgId = " << sgId
	 << " PDG id = "  << (*contItr)->pdgId() 
	 << " status = " << (*contItr)->status() 
	 << " barcode = " << (*contItr)->barcode()
	 << " mother = " << mother_id
	 << " eta = " << (*contItr)->eta()
	 << " phi = " << (*contItr)->phi()
	 << " pt  = " << fabs((*contItr)->pt())  
      // << " ( px, py, pz, m ) = "
      //	 << "( " << fabs((*contItr)->px())  
      // << " ," << fabs((*contItr)->py())  
      // << " ," << fabs((*contItr)->pz())  
	 << " m = " << fabs((*contItr)->m())  
      // << " )" 
	 << endreq;
    
  }


  const MuonFeatureContainer * muonFeatureContainer;
  sc = m_storeGate->retrieve(muonFeatureContainer);
  if (sc.isFailure()) {
    mLog << MSG::DEBUG
	 << "No AOD MuonFeature container found in TDS"
	 << endreq;
    return  StatusCode::SUCCESS;
  } else {
    mLog << MSG::DEBUG
	 << " MuonFeature container found in TDS with size " << muonFeatureContainer->size() 
	 << endreq;
    //  isFoundL2SA = matchL2SA(deltaR,l2muon,muonFeatureContainer,eta,phi);
  }

  std::vector<double> eta_already_recorded, phi_already_recorded;
  bool already_recorded;
  std::vector<int> roi_already_recorded_l2ms;
  MuonFeatureContainer::const_iterator muonFeatureIt  = muonFeatureContainer->begin();
  MuonFeatureContainer::const_iterator muonFeatureEnd  = muonFeatureContainer->end();
  for (; muonFeatureIt != muonFeatureEnd; muonFeatureIt++) {
    
    //    std::string contName = muonFeatureIt.key();
    // if( contName.find("HLTAutoKey") != std::string::npos) { 
    
   
    mLog << MSG::DEBUG << " LVL2 MuonFeature :  " 
	 << " eta = " << (*muonFeatureIt)->eta()
	 << " phi = " << (*muonFeatureIt)->phi()
	 << " pt  = " << fabs((*muonFeatureIt)->pt()*1000)  
	 << endreq;
    
    
    if(fabs((*muonFeatureIt)->pt()) < 0.0001) {
      mLog << MSG::DEBUG << "skipping pt NULL"<< endreq;
      continue;
      }
    
    already_recorded = false;
    for(int i=0; i<(int)eta_already_recorded.size(); i++) {
      if(fabs(eta_already_recorded[i] - (*muonFeatureIt)->eta()) < 0.00001 &&
	 fabs(phi_already_recorded[i] - (*muonFeatureIt)->phi()) < 0.00001)
	already_recorded = true;
    }
    if(already_recorded) {
      //mLog << MSG::DEBUG << "skipping "<< endreq;
      continue;
    }
    eta_already_recorded.push_back((*muonFeatureIt)->eta());
    phi_already_recorded.push_back((*muonFeatureIt)->phi());
    double pt = fabs((*muonFeatureIt)->pt()*1000);
    float eta = (*muonFeatureIt)->eta();
    float phi = (*muonFeatureIt)->phi();
    double deltaR = 100000.;
    bool isFound = matchEF(deltaR, truthTDS,eta,phi);
    
    mLog << MSG::DEBUG << " Fake deltaR = " <<  deltaR
	 << endreq;
    if(!isFound || deltaR>m_deltaRMatchCut) {
      mLog << MSG::DEBUG << "================> Fake pt = " << pt 
	   << ", eta = " << eta 
	   << ", phi =" << phi 
	   <<  endreq;
	   m_h_ptfakeSAL2->Fill(fabs(pt));
	   m_h_etafakeSAL2->Fill(eta);
	   m_h_phifakeSAL2->Fill(phi);
    }
  }

  ////////////////////////////////////////////////////////////////////////////////
  const CombinedMuonFeatureContainer * cmuonFeatureContainer;
  sc = m_storeGate->retrieve(cmuonFeatureContainer);
  if (sc.isFailure()) {
    mLog << MSG::DEBUG
	 << "No AOD CombinedMuonFeature container found in TDS"
	 << endreq;
    return  StatusCode::SUCCESS;
  } else {
    mLog << MSG::DEBUG
	 << "AOD CombinedMuonFeature container found in TDS with size " << cmuonFeatureContainer->size()
	 << endreq;
  }

 std::vector<double> eta_already_recordedcb, phi_already_recordedcb;
 bool already_recordedcb;
 std::vector<int> roi_already_recorded_l2cb;
 CombinedMuonFeatureContainer::const_iterator cmuonFeatureIt  = cmuonFeatureContainer->begin();
 CombinedMuonFeatureContainer::const_iterator cmuonFeatureEnd  = cmuonFeatureContainer->end();  
 for (; cmuonFeatureIt != cmuonFeatureEnd; cmuonFeatureIt++) {
   
   //    std::string contName = muonFeatureIt.key();
   //    if( contName.find("HLTAutoKey") != std::string::npos) { 
   
   mLog << MSG::DEBUG << " CB LVL2 MuonFeature :  " 
	<< " eta = " << (*cmuonFeatureIt)->eta()
	<< " phi = " << (*cmuonFeatureIt)->phi()
	<< " pt  = " << fabs((*cmuonFeatureIt)->pt())  
	<< endreq;
   
   
   if(fabs((*cmuonFeatureIt)->pt()) < 0.0001) {
     mLog << MSG::DEBUG << "skipping pt NULL"<< endreq;
     continue;
   }
   
   already_recordedcb = false;
   for(int i=0; i<(int)eta_already_recordedcb.size(); i++) {
     if(fabs(eta_already_recordedcb[i] - (*cmuonFeatureIt)->eta()) < 0.00001 &&
	fabs(phi_already_recordedcb[i] - (*cmuonFeatureIt)->phi()) < 0.00001)
       already_recordedcb = true;
   }
   if(already_recordedcb) {
     //	mLog << MSG::DEBUG << "skipping "<< endreq;
     continue;
   }
   eta_already_recordedcb.push_back((*cmuonFeatureIt)->eta());
   phi_already_recordedcb.push_back((*cmuonFeatureIt)->phi());

   double pt = fabs((*cmuonFeatureIt)->pt());
   float eta = (*cmuonFeatureIt)->eta();
   float phi = (*cmuonFeatureIt)->phi();
   double deltaR = 100000.;
   bool isFound = matchEF(deltaR, truthTDS,eta,phi);
   
   mLog << MSG::DEBUG << " Fake deltaR = " <<  deltaR
	<< endreq;
   if(!isFound || deltaR>m_deltaRMatchCut) {
     mLog << MSG::DEBUG << "================> Fake pt = " << pt 
	  << ", eta = " << eta 
	  << ", phi =" << phi 
	  <<  endreq;
     m_h_ptfakeCBL2->Fill(fabs(pt));
     m_h_etafakeCBL2->Fill(eta);
     m_h_phifakeCBL2->Fill(phi);
   }
   
 }


  /////////////////////////////////////////////////////////////////////////
  const DataHandle< TrigMuonEFContainer > trigMuon;
  const DataHandle< TrigMuonEFContainer > lastTrigMuon;
  sc = m_storeGate->retrieve(trigMuon,lastTrigMuon);
  if (sc.isFailure()) {
    mLog << MSG::DEBUG << "No TrigMuonEFContainer found" << endreq;
    return  StatusCode::SUCCESS;
  }
  
  for (int i=0; trigMuon != lastTrigMuon; ++trigMuon, ++i) {
    
    //    mLog << MSG::DEBUG << "================ Looking at TrigMuonEFContainer " << i << endreq;
    
    TrigMuonEFContainer::const_iterator MuonItr  = trigMuon->begin();
    TrigMuonEFContainer::const_iterator MuonItrE = trigMuon->end();
    
    std::vector<double> eta_already_recorded, phi_already_recorded;
    std::vector<int> muoncode_already_recorded;
    bool already_recorded;
    for (int j=0; MuonItr != MuonItrE; ++MuonItr, ++j ) {
      
      
      float theta = atan(1./(*MuonItr)->cotTh());
      float eta = std::log(tan(.5*fabs(theta)));
      if (theta>0) eta=-eta;
      float phi = (*MuonItr)->phi();
      float pt = 1./(*MuonItr)->iPt();
       
      already_recorded = false;
      for(int i=0; i<(int)eta_already_recorded.size(); i++) {
	if(fabs(eta_already_recorded[i] - eta) < 0.00001 &&
	   fabs(phi_already_recorded[i] - (*MuonItr)->phi()) < 0.00001 &&
	   muoncode_already_recorded[i]-(*MuonItr)->MuonCode()< 0.00001)
	  already_recorded = true;
      }
      if(already_recorded) {
	//mLog << MSG::DEBUG << "skipping "<< endreq;
	continue;
      }
      eta_already_recorded.push_back(eta);
      phi_already_recorded.push_back(phi);
      muoncode_already_recorded.push_back((*MuonItr)->MuonCode());
      

       
       double deltaR = 100000.;
       bool isFound = matchEF(deltaR, truthTDS,eta,phi);

       mLog << MSG::DEBUG << " pt=  " << pt 
	    << ", eta = " << eta 
	    << ", phi =" << phi 
	    << ", muoncode = " << (*MuonItr)->MuonCode()<< endreq;
       mLog << MSG::DEBUG << " Fake deltaR = " <<  deltaR
	    << endreq;
       if(!isFound || deltaR>m_deltaRMatchCut) {
	 mLog << MSG::DEBUG << "================> Fake pt = " << pt 
	      << ", eta = " << eta 
	      << ", phi =" << phi 
	      << ", muoncode = " << (*MuonItr)->MuonCode()<< endreq;
	 if((*MuonItr)->MuonCode() == 1) {
	   m_h_ptfakeSA->Fill(fabs(pt));
	   m_h_etafakeSA->Fill(eta);
	   m_h_phifakeSA->Fill(phi);
	   m_NfakeSA++;
	   if(fabs(pt)>5800)  m_NfakeSA_mu6++;
	   if(fabs(pt)>19300)  m_NfakeSA_mu20++;
	 } else if ((*MuonItr)->MuonCode() == 4){
	  m_h_ptfakeSA_tmef->Fill(fabs(pt));
	  m_h_etafakeSA_tmef->Fill(eta);
	  m_h_phifakeSA_tmef->Fill(phi);
	   m_NfakeSA_tmef++;
	   if(fabs(pt)>5800)  m_NfakeSA_tmef_mu6++;
	   if(fabs(pt)>19300)  m_NfakeSA_tmef_mu20++;
	 } else if ((*MuonItr)->MuonCode() == 5){
	   m_h_ptfakeCB_tmef->Fill(fabs(pt));
	   m_h_etafakeCB_tmef->Fill(eta);
	   m_h_phifakeCB_tmef->Fill(phi);
	   m_NfakeCB_tmef++;
	   if(fabs(pt)>5800)  m_NfakeCB_tmef_mu6++;
	   if(fabs(pt)>19300)  m_NfakeCB_tmef_mu20++;
	 } else if ((*MuonItr)->MuonCode() >99){
	   m_h_ptfakeCB->Fill(fabs(pt));
	   m_h_etafakeCB->Fill(eta);
	   m_h_phifakeCB->Fill(phi);
	   m_NfakeCB++;
	   if(fabs(pt)>5800)  m_NfakeCB_mu6++;
	   if(fabs(pt)>19300)  m_NfakeCB_mu20++;
	 }
       }
    }
  }
  return StatusCode::SUCCESS;
}
   

bool
AnalysisSkeleton::matchL2SA(double &deltaR, MuonFeature & l2muon, const MuonFeatureContainer *  muonFeatureCont,
			    float &etal1, float &phil1) const
{
  MsgStream mLog( messageService(), name() );

  deltaR = 10000.; // big value
  int l_idx = 0;
  bool l_return = false;
  
  std::vector<double> eta_already_recorded, phi_already_recorded;
  bool already_recorded;
  std::vector<int> roi_already_recorded_l2ms;
  MuonFeatureContainer::const_iterator muonFeatureIt  = muonFeatureCont->begin();
  MuonFeatureContainer::const_iterator muonFeatureEnd  = muonFeatureCont->end();
  for (; muonFeatureIt != muonFeatureEnd; muonFeatureIt++) {
    
    //    std::string contName = muonFeatureIt.key();
    // if( contName.find("HLTAutoKey") != std::string::npos) { 
      
      mLog << MSG::DEBUG << " =============== MuonFeature successfully retrieved ============== " << endreq;
      mLog << MSG::DEBUG << " LVL2 MuonFeature :  " 
	   << " eta = " << (*muonFeatureIt)->eta()
	   << " phi = " << (*muonFeatureIt)->phi()
	   << " pt  = " << fabs((*muonFeatureIt)->pt()*1000)  
	   << endreq;
      
      
      if(fabs((*muonFeatureIt)->pt()) < 0.0001) {
	mLog << MSG::DEBUG << "skipping pt NULL"<< endreq;
	continue;
      }
      
      already_recorded = false;
      for(int i=0; i<(int)eta_already_recorded.size(); i++) {
	if(fabs(eta_already_recorded[i] - (*muonFeatureIt)->eta()) < 0.00001 &&
	     fabs(phi_already_recorded[i] - (*muonFeatureIt)->phi()) < 0.00001)
	  already_recorded = true;
      }
      if(already_recorded) {
	//mLog << MSG::DEBUG << "skipping "<< endreq;
	continue;
      }
      eta_already_recorded.push_back((*muonFeatureIt)->eta());
      phi_already_recorded.push_back((*muonFeatureIt)->phi());
      
      double rtu = DR(*muonFeatureIt,etal1,phil1);
      if ( rtu < deltaR )
	{
	  l2muon  =  MuonFeature((*muonFeatureIt)->saddress(),(*muonFeatureIt)->pt(), (*muonFeatureIt)->radius(),
				    (*muonFeatureIt)->eta(),(*muonFeatureIt)->phi(),(*muonFeatureIt)->dir_phi(),(*muonFeatureIt)->zeta(),
				    (*muonFeatureIt)->dir_zeta(), (*muonFeatureIt)->beta());
	  deltaR = rtu;
	  l_return = true;
	}
	++l_idx;
	// }
  }//loop on L2mufast
  
  
  return l_return;
  
}

bool
AnalysisSkeleton::matchL2CB(double &deltaR, CombinedMuonFeature & l2muon, const CombinedMuonFeatureContainer * muonFeatureCont,
			      float &etal1, float &phil1) const 
{
  MsgStream mLog( messageService(), name() );

  deltaR = 10000.; // big value
  int l_idx = 0;
  bool l_return = false;
  
  std::vector<double> eta_already_recorded, phi_already_recorded;
  bool already_recorded;
  std::vector<int> roi_already_recorded_l2ms;
  CombinedMuonFeatureContainer::const_iterator muonFeatureIt  = muonFeatureCont->begin();
  CombinedMuonFeatureContainer::const_iterator muonFeatureEnd  = muonFeatureCont->end();  
  for (; muonFeatureIt != muonFeatureEnd; muonFeatureIt++) {
    
    //    std::string contName = muonFeatureIt.key();
    //    if( contName.find("HLTAutoKey") != std::string::npos) { 
      
      mLog << MSG::DEBUG << " =============== CB MuonFeature successfully retrieved ============== " << endreq;
      mLog << MSG::DEBUG << " CB LVL2 MuonFeature :  " 
      	   << " eta = " << (*muonFeatureIt)->eta()
	   << " phi = " << (*muonFeatureIt)->phi()
	   << " pt  = " << fabs((*muonFeatureIt)->pt())  
	   << endreq;
      
      
      if(fabs((*muonFeatureIt)->pt()) < 0.0001) {
	mLog << MSG::DEBUG << "skipping pt NULL"<< endreq;
	continue;
      }
      
      already_recorded = false;
      for(int i=0; i<(int)eta_already_recorded.size(); i++) {
	if(fabs(eta_already_recorded[i] - (*muonFeatureIt)->eta()) < 0.00001 &&
	     fabs(phi_already_recorded[i] - (*muonFeatureIt)->phi()) < 0.00001)
	  already_recorded = true;
      }
      if(already_recorded) {
	//	mLog << MSG::DEBUG << "skipping "<< endreq;
	continue;
      }
      eta_already_recorded.push_back((*muonFeatureIt)->eta());
      phi_already_recorded.push_back((*muonFeatureIt)->phi());

      
      
      double rtu = DR(*muonFeatureIt,etal1,phil1);
      if ( rtu < deltaR ){
	l2muon  =  CombinedMuonFeature((*muonFeatureIt)->pt(), (*muonFeatureIt)->sigma_pt(),
				       (*muonFeatureIt)->muFastTrackLink(),(*muonFeatureIt)->IDTrackLink());
	deltaR = rtu;
	l_return = true;
      }
      ++l_idx;
      //    }
  }//loop on L2mufast
  
  
  return l_return;
  
}


bool
AnalysisSkeleton::matchEF(double &deltaR, const TruthParticleContainer*& truthTDS,
			    float &etal2, float &phil2) const
{

  MsgStream mLog( messageService(), name() );
  deltaR = 10000.; // big value
  int l_idx = 0;
  bool l_return = false;

  /// iterators over the container 
  TruthParticleContainer::const_iterator contItr  = truthTDS->begin();
  TruthParticleContainer::const_iterator contItrE = truthTDS->end();
  //    mLog << MSG::DEBUG << "============ Truth particle list ============" << endreq;
  
  for (unsigned int sgId=0; contItr!=contItrE; ++contItr, ++sgId) {    
    
    if((*contItr)->status()!=1) continue;
    if( fabs((*contItr)->pdgId()) != 13) continue;
    if ((*contItr)->barcode() > 1000000 ) continue;

    double rtu = DR(*contItr,etal2,phil2);
    if ( rtu < deltaR )
      {
	deltaR = rtu;
	l_return = true;
      }
    ++l_idx;
    
  }

  return l_return; 
  
}


bool
AnalysisSkeleton::matchEF(double &deltaR, TrigMuonEF & muon, const DataHandle<TrigMuonEFContainer>& trigMuon,
			    const DataHandle<TrigMuonEFContainer>& lastTrigMuon, 
			    float &etal2, float &phil2, int muonCode) const
{

  MsgStream mLog( messageService(), name() );
  deltaR = 10000.; // big value
  int l_idx = 0;
  bool l_return = false;




  for (int i=0; trigMuon != lastTrigMuon; ++trigMuon, ++i) {
    
    //    mLog << MSG::DEBUG << "================ Looking at TrigMuonEFContainer " << i << endreq;
      
    TrigMuonEFContainer::const_iterator MuonItr  = trigMuon->begin();
    TrigMuonEFContainer::const_iterator MuonItrE = trigMuon->end();

    std::vector<double> eta_already_recorded, phi_already_recorded;
    std::vector<int> muoncode_already_recorded;
    bool already_recorded;
    for (int j=0; MuonItr != MuonItrE; ++MuonItr, ++j ) {

      int muoncode_tmp = (*MuonItr)->MuonCode();
      if((*MuonItr)->MuonCode()>100) muoncode_tmp =101;

      double theta = atan(1./(*MuonItr)->cotTh());
      double eta = std::log(tan(.5*fabs(theta)));
      if (theta>0) eta=-eta;

      already_recorded = false;
      for(int i=0; i<(int)eta_already_recorded.size(); i++) {
	if(fabs(eta_already_recorded[i] - eta) < 0.00001 &&
	   fabs(phi_already_recorded[i] - (*MuonItr)->phi()) < 0.00001 &&
	   muoncode_already_recorded[i]-(*MuonItr)->MuonCode()< 0.00001)
	  already_recorded = true;
      }
      if(already_recorded) {
	mLog << MSG::DEBUG << "skipping "<< endreq;
	continue;
      }
      eta_already_recorded.push_back(eta);
      phi_already_recorded.push_back((*MuonItr)->phi());
      muoncode_already_recorded.push_back((*MuonItr)->MuonCode());
      
      mLog <<MSG::DEBUG << "muonCode() : " << (*MuonItr)->MuonCode()
	   << ", roi:  " << (*MuonItr)->RoINum()
	   << ", pt= " << 1./(*MuonItr)->iPt() 
	   << ", phi=  " << (*MuonItr)->phi() 
	   << ", eta=  " << eta << endreq;


      if(muonCode!=muoncode_tmp) continue;
        
      if(muoncode_tmp==1){
	m_h_muonpt_sa->Fill(fabs(1./(*MuonItr)->iPt()));
	m_h_muoneta_sa->Fill(eta);
	m_h_muonphi_sa->Fill((*MuonItr)->phi() );
	m_h_pt_vs_eta_efsa->Fill(fabs(1./(*MuonItr)->iPt()),eta);
      } else if (muoncode_tmp==101){
	m_h_muonpt_cb->Fill(fabs(1./(*MuonItr)->iPt()));
	m_h_muoneta_cb->Fill(eta);
	m_h_muonphi_cb->Fill((*MuonItr)->phi() );
	m_h_pt_vs_eta_efcb->Fill(fabs(1./(*MuonItr)->iPt()),eta);
	if (fabs(1./(*MuonItr)->iPt()) < 20000) mLog << MSG::WARNING << " low pt muon pt =    "
						    << 1./(*MuonItr)->iPt() << " eta " <<  eta << endreq;

      } else if (muoncode_tmp==4){
	m_h_muonpt_sa_tmef->Fill(fabs(1./(*MuonItr)->iPt()));
	m_h_muoneta_sa_tmef->Fill(eta);
	m_h_muonphi_sa_tmef->Fill((*MuonItr)->phi() );
      } else if (muoncode_tmp==5) {
	m_h_muonpt_cb_tmef->Fill(fabs(1./(*MuonItr)->iPt()));
	m_h_muoneta_cb_tmef->Fill(eta);
	m_h_muonphi_cb_tmef->Fill((*MuonItr)->phi() );
      }

      
      //      if(muonCode<100){//
      //	if((*MuonItr)->MuonCode() != muonCode ) continue;
      // } else if((*MuonItr)->MuonCode() != muonCode && (*MuonItr)->MuonCode() != muonCode+10) {
      //	continue;
      // }
      //      mLog <<MSG::DEBUG << "------ Looking at TrigMuonEF " << j << endreq;
      
      


      double rtu = DR(*MuonItr,etal2,phil2);
      if ( rtu < deltaR )
	{
	  muon  =  TrigMuonEF((*MuonItr)->iPt(), (*MuonItr)->cotTh(), (*MuonItr)->phi(),  (*MuonItr)->m() );
	  deltaR = rtu;
	  l_return = true;
	}
	++l_idx;
    }
  }//loop on EF muons
  
  
  return l_return;
  
}



bool 
AnalysisSkeleton::matchR (const double eta, const double phi, const TruthParticleContainer *coll, int &index, 
	     double &deltaR, const int & pdg, const bool genOnly=true) const
  {
  deltaR = 10000.; // big value
  bool l_return = false;
  int l_idx = 0;
  TruthParticleContainer::const_iterator it  = coll->begin();
  TruthParticleContainer::const_iterator itE = coll->end();
  if ( genOnly ) {
      for (; it != itE; ++it)
	{
	  if((*it)->status()==1){
	    if ( (*it)->barcode() < 1000000 ) // only generator particles
	      {
		if ( ( fabs((*it)->pdgId()) == fabs(pdg)) || pdg==0 )
		  {
		    //		    std::cout << fabs(pdg) << " " << fabs((*it)->pdgId()) << std::endl;
		    double rtu = DR(*it,eta,phi);
		    if ( rtu < deltaR )
		      {
			index  = l_idx;
			deltaR = rtu;
			l_return = true;
		      }
		  }
	      }
	  }
	  ++l_idx;
	}
      return l_return;
    }
  return l_return;
}

double 
AnalysisSkeleton::DR (const TruthParticle *p1, const double & v_eta, const double & v_phi)  const 
{
  double phi1 = (p1->phi()>M_PI) ? p1->phi()-2*M_PI : p1->phi();
  double phi2 = (v_phi>M_PI) ? v_phi-2*M_PI : v_phi;
  double dphi = fabs(phi1-phi2);
  if(dphi>M_PI) dphi = 2*M_PI-dphi;
  double deta = p1->eta() - v_eta;
  return sqrt(dphi*dphi+deta*deta);
}



double 
AnalysisSkeleton::DR (MuonFeature *  p1, const double & v_eta, const double & v_phi)  const 
{
  double phi1 = (p1->phi()>M_PI) ? p1->phi()-2*M_PI : p1->phi();
  double phi2 = (v_phi>M_PI) ? v_phi-2*M_PI : v_phi;
  double dphi = fabs(phi1-phi2);
  if(dphi>M_PI) dphi = 2*M_PI-dphi;
  double deta = p1->eta() - v_eta;
  return sqrt(dphi*dphi+deta*deta);
}

double 
AnalysisSkeleton::DR (CombinedMuonFeature * p1, const double & v_eta, const double & v_phi)  const 
{
  double phi1 = (p1->phi()>M_PI) ? p1->phi()-2*M_PI : p1->phi();
  double phi2 = (v_phi>M_PI) ? v_phi-2*M_PI : v_phi;
  double dphi = fabs(phi1-phi2);
  if(dphi>M_PI) dphi = 2*M_PI-dphi;
  double deta = p1->eta() - v_eta;
  return sqrt(dphi*dphi+deta*deta);
}

double 
AnalysisSkeleton::DR (const TrigMuonEF *p1, const double & v_eta, const double & v_phi)  const 
{
  double phi1 = (p1->phi()>M_PI) ? p1->phi()-2*M_PI : p1->phi();
  double phi2 = (v_phi>M_PI) ? v_phi-2*M_PI : v_phi;
  double dphi = fabs(phi1-phi2);
  if(dphi>M_PI) dphi = 2*M_PI-dphi;
  double deta = p1->eta() - v_eta;
  return sqrt(dphi*dphi+deta*deta);
}

StatusCode AnalysisSkeleton::trigDec() {

  MsgStream mLog( messageService(), name() );
  mLog << MSG::DEBUG << " ############## START of trigger Decision Dump #############################" << endreq;  


  std::vector< std::string >  L1Items = m_trigDec->getListOfTriggers("L1_.*");    
  std::vector<std::string>::const_iterator it;
  for(it= L1Items.begin(); it!= L1Items.end(); ++it) { // Loop over trigger items
    //    if (!*it) continue;
    std::string name = (*it);  
    //    mLog << MSG::DEBUG << "L1 trigger "<< name << endreq;  
    if (m_trigDec->isPassed(name)) {
      std::string name = (*it);
      //      mLog << MSG::DEBUG << "is passed " << endreq;  
      std::map<std::string,int>::iterator itmap = m_triggerItemsL1.find(name);
      m_triggerItemsL1[name] = itmap->second + 1;
    }
    //    mLog << MSG::DEBUG << "not passed "  << endreq;  
  }

  std::vector< std::string >  L2Items = m_trigDec->getListOfTriggers("L2_.*");    
  std::vector<std::string>::const_iterator it2;
  for(it2= L2Items.begin(); it2!= L2Items.end(); ++it2) { // Loop over trigger items
    //    if (!*it2) continue;
    std::string name = (*it2);  
    //    mLog << MSG::DEBUG << "L1 trigger "<< name << endreq;  
    if (m_trigDec->isPassed(name)) {
      std::string name = (*it2);
      //      mLog << MSG::DEBUG << "is passed " << endreq;  
      std::map<std::string,int>::iterator itmap = m_triggerItemsL2.find(name);
      m_triggerItemsL2[name] = itmap->second + 1;
    }
    //    mLog << MSG::DEBUG << "not passed "  << endreq;  
  }

  std::vector< std::string >  EFItems = m_trigDec->getListOfTriggers("EF_.*");    
  std::vector<std::string>::const_iterator it3;
  for(it3= L2Items.begin(); it3!= EFItems.end(); ++it3) { // Loop over trigger items
    //    if (!*it3) continue;
    std::string name = (*it3);  
    //    mLog << MSG::DEBUG << "L1 trigger "<< name << endreq;  
    if (m_trigDec->isPassed(name)) {
      std::string name = (*it3);
      //      mLog << MSG::DEBUG << "is passed " << endreq;  
      std::map<std::string,int>::iterator itmap = m_triggerItemsEF.find(name);
      m_triggerItemsEF[name] = itmap->second + 1;
    }
    //    mLog << MSG::DEBUG << "not passed "  << endreq;  
  }

 
  return StatusCode::SUCCESS;

}


StatusCode AnalysisSkeleton::trackParticleAnalysis(){
  StatusCode sc;
  
  MsgStream log( messageService(), name() );
 
 

  // Get TrackParticles from StoreGate
  const Rec::TrackParticleContainer* importedTrkColl;
  sc = m_storeGate->retrieve(importedTrkColl,"TrackParticleCandidate");
  if (sc.isFailure() || 0 == importedTrkColl) {
    log << MSG::ERROR << "No TrackParticle Collection found in StoreGate" << endreq;
    importedTrkColl=0; 
    return sc;
  } else   log << MSG::INFO << " trackaprticle imported with size " <<  importedTrkColl->size() << endreq;

  DataVector<Rec::TrackParticle>::const_iterator collIter(importedTrkColl->begin());
  DataVector<Rec::TrackParticle>::const_iterator collEnd(importedTrkColl->end());
  for ( ; collIter!=collEnd; ++collIter){
    /* Retrieve the perigee parameters from the TrackParticle */
    const Trk::MeasuredPerigee* aMeasPer;
    aMeasPer= (*collIter)->measuredPerigee();
    m_h_trkphi->Fill(aMeasPer->parameters()[Trk::phi]);
    m_h_trketa->Fill(aMeasPer->parameters()[Trk::theta]);
    m_h_trkpt->Fill(aMeasPer->parameters()[Trk::qOverP]);
    // log << MSG::INFO << "d_0 of the track: " << aMeasPer->parameters()[Trk::d0] << endreq;
  }


  return sc;

}

StatusCode AnalysisSkeleton::bookHistos(){


  StatusCode sc;

  MsgStream mLog( messageService(), name() );

  //Truth 
  m_h_MCeta_4 = new TH1F("h_MCeta_4","MC eta mu ",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_MCeta_4",m_h_MCeta_4);
  m_h_MCeta_6 = new TH1F("h_MCeta_6","MC eta mu ",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_MCeta_6",m_h_MCeta_6);
  m_h_MCeta_20 = new TH1F("h_MCeta_20","MC eta mu ",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_MCeta_20",m_h_MCeta_20);
  m_h_MCeta_40 = new TH1F("h_MCeta_40","MC eta mu ",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_MCeta_40",m_h_MCeta_40);

  m_h_MCphi_b = new TH1F("h_MCphi_b","MC phi b mu ",70,-3.2,3.2) ;
  sc = m_thistSvc->regHist("/AANT/Muon/h_MCphi_b",m_h_MCphi_b);
  m_h_MCphi_e = new TH1F("h_MCphi_e","MC phi e mu ",70,-3.2,3.2);
  sc = m_thistSvc->regHist("/AANT/Muon/h_MCphi_e",m_h_MCphi_e);
  m_h_MCpt = new TH1F("h_MCpt","MC pt mu ",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_MCpt",m_h_MCpt);
  
  m_h_MCpt_b = new TH1F("h_MCpt_b","MC pt b mu ",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_MCpt_b",m_h_MCpt_b);
  m_h_MCpt_b_4 = new TH1F("h_MCpt_b_4","MC pt b mu ",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_MCpt_b_4",m_h_MCpt_b_4);
  m_h_MCpt_b_6 = new TH1F("h_MCpt_b_6","MC pt b mu ",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_MCpt_b_6",m_h_MCpt_b_6);
  m_h_MCpt_b_20 = new TH1F("h_MCpt_b_20","MC pt b mu ",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_MCpt_b_20",m_h_MCpt_b_20);
  m_h_MCpt_b_40 = new TH1F("h_MCpt_b_40","MC pt b mu ",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_MCpt_b_40",m_h_MCpt_b_40);
  
  m_h_MCpt_e = new TH1F("h_MCpt_e","MC pt e mu ",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_MCpt_e",m_h_MCpt_e);
  
  m_h_muonpt_l1_b     = new TH1F("muon_pt_l1_b","pt mu l1 b",50,0,50.*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/muon_pt_l1_b",m_h_muonpt_l1_b);
  m_h_muonpt_l1_e     = new TH1F("muon_pt_l1_e","pt mu l1 e",50,0,50.*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/muon_pt_l1_e",m_h_muonpt_l1_e);
  m_h_muoneta_l1    = new TH1F("muon_eta_l1","eta mu l1",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/muon_eta_l1",m_h_muoneta_l1);
  m_h_muonphi_l1_b    = new TH1F("muon_phi_l1_b","phi mu l1 b",70,-3.2,3.2);
  sc = m_thistSvc->regHist("/AANT/Muon/muon_phi_l1_b",m_h_muonphi_l1_b);
  m_h_muonphi_l1_e    = new TH1F("muon_phi_l1_e","phi mu l1 e",70,-3.2,3.2);
  sc = m_thistSvc->regHist("/AANT/Muon/muon_phi_l1_e",m_h_muonphi_l1_e);
  
  
  m_h_DR_l1    = new TH1F("DR_l1","delta R l1 ",70,0,5);
  sc = m_thistSvc->regHist("/AANT/Muon/DR_l1",m_h_DR_l1);
  m_h_muonpt_l1_b_truth = new TH1F("h_muonpt_l1_b_truth","l1 pt b mu ",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_l1_b_truth",m_h_muonpt_l1_b_truth);
  m_h_muonpt_l1_e_truth =new TH1F("h_muonpt_l1_e_truth","l1 pt e mu ",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_l1_e_truth",m_h_muonpt_l1_e_truth) ;
  
  m_h_muonpt_l1_b_truth_6 = new TH1F("h_muonpt_l1_b_truth_6","l1 pt b mu 6",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_l1_b_truth_6",m_h_muonpt_l1_b_truth_6);
  m_h_muonpt_l1_e_truth_6 =new TH1F("h_muonpt_l1_e_truth_6","l1 pt e mu 6",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_l1_e_truth_6",m_h_muonpt_l1_e_truth_6) ;
  
  m_h_muonpt_l1_b_truth_20 = new TH1F("h_muonpt_l1_b_truth_20","l1 pt b mu 20",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_l1_b_truth_20",m_h_muonpt_l1_b_truth_20);
  m_h_muonpt_l1_e_truth_20 =new TH1F("h_muonpt_l1_e_truth_20","l1 pt e mu 20 ",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_l1_e_truth_20",m_h_muonpt_l1_e_truth_20) ;
  
  m_h_muonpt_l1_b_truth_40 = new TH1F("h_muonpt_l1_b_truth_40","l1 pt b mu 40",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_l1_b_truth_40",m_h_muonpt_l1_b_truth_40);
  m_h_muonpt_l1_e_truth_40 =new TH1F("h_muonpt_l1_e_truth_40","l1 pt e mu 40 ",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_l1_e_truth_40",m_h_muonpt_l1_e_truth_40) ;
  

  m_h_muoneta_l1_truth =  new TH1F("h_muoneta_l1_truth","l1 eta mu ",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muoneta_l1_truth",m_h_muoneta_l1_truth);
  
  m_h_muoneta_l1_truth_6 =  new TH1F("h_muoneta_l1_truth_6","l1 eta mu 6",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muoneta_l1_truth_6",m_h_muoneta_l1_truth_6);
  m_h_muoneta_l1_truth_20 =  new TH1F("h_muoneta_l1_truth_20","l1 eta mu 20",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muoneta_l1_truth_20",m_h_muoneta_l1_truth_20);
  m_h_muoneta_l1_truth_40 =  new TH1F("h_muoneta_l1_truth_40","l1 eta mu 40",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muoneta_l1_truth_40",m_h_muoneta_l1_truth_40);
  
  
  m_h_muonpt_l2ms     = new TH1F("muon_pt_l2ms","pt mu l2ms",50,0,100.*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/muon_pt_l2ms",m_h_muonpt_l2ms);
  m_h_muonptVSeta_l2ms     = new TH2F("muon_ptVSeta_l2ms","pt vs eta mu l2ms",50,0,50.*GeV, 70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/muon_ptVSeta_l2ms",m_h_muonptVSeta_l2ms);
  m_h_muoneta_l2ms    = new TH1F("muon_eta_l2ms","eta mu l2ms",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/muon_eta_l2ms",m_h_muoneta_l2ms);
  m_h_muonphi_l2ms    = new TH1F("muon_phi_l2ms","phi mu l2ms",70,-3.2,3.2);
  sc = m_thistSvc->regHist("/AANT/Muon/muon_phi_l2ms",m_h_muonphi_l2ms);
  
  m_h_DR_l2ms    = new TH1F("DR_l2ms","delta R l2 ms ",70,0,5);
  sc = m_thistSvc->regHist("/AANT/Muon/DR_l2ms",m_h_DR_l2ms);
  
  m_h_muonpt_l2ms_b_truth = new TH1F("h_muonpt_l2ms_b_truth","l1 pt b mu ",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_l2ms_b_truth",m_h_muonpt_l2ms_b_truth);
  m_h_muonpt_l2ms_e_truth =new TH1F("h_muonpt_l2ms_e_truth","l1 pt e mu ",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_l2ms_e_truth",m_h_muonpt_l2ms_e_truth) ;
    
  m_h_muonpt_l2ms_b_truth_6 = new TH1F("h_muonpt_l2ms_b_truth_6","l1 pt b mu 6",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_l2ms_b_truth_6",m_h_muonpt_l2ms_b_truth_6);
  m_h_muonpt_l2ms_e_truth_6 =new TH1F("h_muonpt_l2ms_e_truth_6","l1 pt e mu 6",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_l2ms_e_truth_6",m_h_muonpt_l2ms_e_truth_6) ;
  
  m_h_muonpt_l2ms_b_truth_20 = new TH1F("h_muonpt_l2ms_b_truth_20","l1 pt b mu 20",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_l2ms_b_truth_20",m_h_muonpt_l2ms_b_truth_20);
  m_h_muonpt_l2ms_e_truth_20 =new TH1F("h_muonpt_l2ms_e_truth_20","l1 pt e mu 20 ",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_l2ms_e_truth_20",m_h_muonpt_l2ms_e_truth_20) ;

  m_h_muonpt_l2ms_b_truth_40 = new TH1F("h_muonpt_l2ms_b_truth_40","l1 pt b mu 40",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_l2ms_b_truth_40",m_h_muonpt_l2ms_b_truth_40);
  m_h_muonpt_l2ms_e_truth_40 =new TH1F("h_muonpt_l2ms_e_truth_40","l1 pt e mu 40 ",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_l2ms_e_truth_40",m_h_muonpt_l2ms_e_truth_40) ;
  
  
  m_h_muoneta_l2ms_truth =  new TH1F("h_muoneta_l2ms_truth","l1 eta mu ",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muoneta_l2ms_truth",m_h_muoneta_l2ms_truth);
  
  m_h_muoneta_l2ms_truth_6 =  new TH1F("h_muoneta_l2ms_truth_6","l1 eta mu 6",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muoneta_l2ms_truth_6",m_h_muoneta_l2ms_truth_6);
  m_h_muoneta_l2ms_truth_20 =  new TH1F("h_muoneta_l2ms_truth_20","l1 eta mu 20",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muoneta_l2ms_truth_20",m_h_muoneta_l2ms_truth_20);
  m_h_muoneta_l2ms_truth_40 =  new TH1F("h_muoneta_l2ms_truth_40","l1 eta mu 40",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muoneta_l2ms_truth_40",m_h_muoneta_l2ms_truth_40);
  m_h_ptres_vs_pt_l2ms    = new TH2F("m_h_ptres_vs_pt_l2ms","pt res vs pt",50,0,2, 100,0,200*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_ptres_vs_pt_l2ms",m_h_ptres_vs_pt_l2ms );    

    
  m_h_muonpt_l2cb     = new TH1F("muon_pt_l2cb","pt mu l2cb",50,0,100.*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/muon_pt_l2cb",m_h_muonpt_l2cb);
  m_h_muoneta_l2cb    = new TH1F("muon_eta_l2cb","eta mu l2cb",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/muon_eta_l2cb",m_h_muoneta_l2cb);
  m_h_muonphi_l2cb    = new TH1F("muon_phi_l2cb","phi mu l2cb",70,-3.2,3.2);
  sc = m_thistSvc->regHist("/AANT/Muon/muon_phi_l2cb",m_h_muonphi_l2cb);
  
  m_h_DR_l2cb    = new TH1F("DR_l2cb","delta R l2 ms ",70,0,5);
  sc = m_thistSvc->regHist("/AANT/Muon/DR_l2cb",m_h_DR_l2cb);
  
  m_h_muonpt_l2cb_b_truth = new TH1F("h_muonpt_l2cb_b_truth","l1 pt b mu ",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_l2cb_b_truth",m_h_muonpt_l2cb_b_truth);
  m_h_muonpt_l2cb_e_truth =new TH1F("h_muonpt_l2cb_e_truth","l1 pt e mu ",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_l2cb_e_truth",m_h_muonpt_l2cb_e_truth) ;
  
  m_h_muonpt_l2cb_b_truth_6 = new TH1F("h_muonpt_l2cb_b_truth_6","l1 pt b mu 6",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_l2cb_b_truth_6",m_h_muonpt_l2cb_b_truth_6);
  m_h_muonpt_l2cb_e_truth_6 =new TH1F("h_muonpt_l2cb_e_truth_6","l1 pt e mu 6",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_l2cb_e_truth_6",m_h_muonpt_l2cb_e_truth_6) ;
  
  m_h_muonpt_l2cb_b_truth_20 = new TH1F("h_muonpt_l2cb_b_truth_20","l1 pt b mu 20",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_l2cb_b_truth_20",m_h_muonpt_l2cb_b_truth_20);
  m_h_muonpt_l2cb_e_truth_20 =new TH1F("h_muonpt_l2cb_e_truth_20","l1 pt e mu 20 ",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_l2cb_e_truth_20",m_h_muonpt_l2cb_e_truth_20) ;
  
  m_h_muonpt_l2cb_b_truth_40 = new TH1F("h_muonpt_l2cb_b_truth_40","l1 pt b mu 40",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_l2cb_b_truth_40",m_h_muonpt_l2cb_b_truth_40);
  m_h_muonpt_l2cb_e_truth_40 =new TH1F("h_muonpt_l2cb_e_truth_40","l1 pt e mu 40 ",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_l2cb_e_truth_40",m_h_muonpt_l2cb_e_truth_40) ;
  

  m_h_muoneta_l2cb_truth =  new TH1F("h_muoneta_l2cb_truth","l1 eta mu ",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muoneta_l2cb_truth",m_h_muoneta_l2cb_truth);
  
  m_h_muoneta_l2cb_truth_6 =  new TH1F("h_muoneta_l2cb_truth_6","l1 eta mu 6",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muoneta_l2cb_truth_6",m_h_muoneta_l2cb_truth_6);
  m_h_muoneta_l2cb_truth_20 =  new TH1F("h_muoneta_l2cb_truth_20","l1 eta mu 20",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muoneta_l2cb_truth_20",m_h_muoneta_l2cb_truth_20);
  m_h_muoneta_l2cb_truth_40 =  new TH1F("h_muoneta_l2cb_truth_40","l1 eta mu 40",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muoneta_l2cb_truth_40",m_h_muoneta_l2cb_truth_40);
  m_h_ptres_vs_pt_l2cb    = new TH2F("m_h_ptres_vs_pt_l2cb","pt res vs pt",50,0,2, 100,0,200*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_ptres_vs_pt_l2cb",m_h_ptres_vs_pt_l2cb );    


  m_h_muonpt_ms     = new TH1F("muon_pt_ms","pt mu ms",50,0,100.*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/muon_pt_ms",m_h_muonpt_ms);
  m_h_muoneta_ms    = new TH1F("muon_eta_ms","eta mu ms",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/muon_eta_ms",m_h_muoneta_ms);
  m_h_muonphi_ms    = new TH1F("muon_phi_ms","phi mu ms",70,-3.2,3.2);
  sc = m_thistSvc->regHist("/AANT/Muon/muon_phi_ms",m_h_muonphi_ms);
  
  m_h_DR_efms    = new TH1F("DR_efms","delta R l2 ms ",70,0,5);
  sc = m_thistSvc->regHist("/AANT/Muon/DR_efms",m_h_DR_efms);
  
  m_h_muonpt_efms_b_truth = new TH1F("h_muonpt_efms_b_truth","l1 pt b mu ",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_efms_b_truth",m_h_muonpt_efms_b_truth);
  m_h_muonpt_efms_e_truth =new TH1F("h_muonpt_efms_e_truth","l1 pt e mu ",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_efms_e_truth",m_h_muonpt_efms_e_truth) ;
  
  m_h_muonpt_efms_b_truth_6 = new TH1F("h_muonpt_efms_b_truth_6","l1 pt b mu 6",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_efms_b_truth_6",m_h_muonpt_efms_b_truth_6);
  m_h_muonpt_efms_e_truth_6 =new TH1F("h_muonpt_efms_e_truth_6","l1 pt e mu 6",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_efms_e_truth_6",m_h_muonpt_efms_e_truth_6) ;
  
  m_h_muonpt_efms_b_truth_20 = new TH1F("h_muonpt_efms_b_truth_20","l1 pt b mu 20",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_efms_b_truth_20",m_h_muonpt_efms_b_truth_20);
  m_h_muonpt_efms_e_truth_20 =new TH1F("h_muonpt_efms_e_truth_20","l1 pt e mu 20 ",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_efms_e_truth_20",m_h_muonpt_efms_e_truth_20) ;
  
  m_h_muonpt_efms_b_truth_40 = new TH1F("h_muonpt_efms_b_truth_40","l1 pt b mu 40",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_efms_b_truth_40",m_h_muonpt_efms_b_truth_40);
  m_h_muonpt_efms_e_truth_40 =new TH1F("h_muonpt_efms_e_truth_40","l1 pt e mu 40 ",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_efms_e_truth_40",m_h_muonpt_efms_e_truth_40) ;
  
  
  m_h_muoneta_efms_truth =  new TH1F("h_muoneta_efms_truth","l1 eta mu ",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muoneta_efms_truth",m_h_muoneta_efms_truth);
  
  m_h_muoneta_efms_truth_6 =  new TH1F("h_muoneta_efms_truth_6","l1 eta mu 6",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muoneta_efms_truth_6",m_h_muoneta_efms_truth_6);
  m_h_muoneta_efms_truth_20 =  new TH1F("h_muoneta_efms_truth_20","l1 eta mu 20",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muoneta_efms_truth_20",m_h_muoneta_efms_truth_20);
  m_h_muoneta_efms_truth_40 =  new TH1F("h_muoneta_efms_truth_40","l1 eta mu 40",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muoneta_efms_truth_40",m_h_muoneta_efms_truth_40);
  
  m_h_muonpt_sa     = new TH1F("h_muon_pt_sa","pt mu sa",50,0,100.*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muon_pt_sa",m_h_muonpt_sa);
  m_h_muoneta_sa    = new TH1F("h_muon_eta_sa","eta mu sa",70,-3.2,3.2);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muon_eta_sa",m_h_muoneta_sa);
  m_h_muonphi_sa    = new TH1F("h_muon_phi_sa","phi mu sa",70,-3.2,3.2);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muon_phi_sa",m_h_muonphi_sa);
  
  m_h_DR_efsa    = new TH1F("DR_efsa","delta R l2 ms ",70,0,5);
  sc = m_thistSvc->regHist("/AANT/Muon/DR_efsa",m_h_DR_efsa);
  m_h_muonpt_efsa_b_truth = new TH1F("h_muonpt_efsa_b_truth","l1 pt b mu ",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_efsa_b_truth",m_h_muonpt_efsa_b_truth);
  m_h_muonpt_efsa_e_truth =new TH1F("h_muonpt_efsa_e_truth","l1 pt e mu ",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_efsa_e_truth",m_h_muonpt_efsa_e_truth) ;
  m_h_muonpt_efsa_b_truth_6 = new TH1F("h_muonpt_efsa_b_truth_6","l1 pt b mu 6",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_efsa_b_truth_6",m_h_muonpt_efsa_b_truth_6);
  m_h_muonpt_efsa_e_truth_6 =new TH1F("h_muonpt_efsa_e_truth_6","l1 pt e mu 6",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_efsa_e_truth_6",m_h_muonpt_efsa_e_truth_6) ;
  m_h_muonpt_efsa_b_truth_20 = new TH1F("h_muonpt_efsa_b_truth_20","l1 pt b mu 20",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_efsa_b_truth_20",m_h_muonpt_efsa_b_truth_20);
  m_h_muonpt_efsa_e_truth_20 =new TH1F("h_muonpt_efsa_e_truth_20","l1 pt e mu 20 ",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_efsa_e_truth_20",m_h_muonpt_efsa_e_truth_20) ;
  m_h_muonpt_efsa_b_truth_40 = new TH1F("h_muonpt_efsa_b_truth_40","l1 pt b mu 40",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_efsa_b_truth_40",m_h_muonpt_efsa_b_truth_40);
  m_h_muonpt_efsa_e_truth_40 =new TH1F("h_muonpt_efsa_e_truth_40","l1 pt e mu 40 ",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_efsa_e_truth_40",m_h_muonpt_efsa_e_truth_40) ;
  m_h_muoneta_efsa_truth =  new TH1F("h_muoneta_efsa_truth","l1 eta mu ",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muoneta_efsa_truth",m_h_muoneta_efsa_truth);
  m_h_muoneta_efsa_truth_6 =  new TH1F("h_muoneta_efsa_truth_6","l1 eta mu 6",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muoneta_efsa_truth_6",m_h_muoneta_efsa_truth_6);
  m_h_muoneta_efsa_truth_20 =  new TH1F("h_muoneta_efsa_truth_20","l1 eta mu 20",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muoneta_efsa_truth_20",m_h_muoneta_efsa_truth_20);
  m_h_muoneta_efsa_truth_40 =  new TH1F("h_muoneta_efsa_truth_40","l1 eta mu 40",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muoneta_efsa_truth_40",m_h_muoneta_efsa_truth_40);
  m_h_ptres_vs_pt_efsa    = new TH2F("m_h_ptres_vs_pt_efsa","pt res vs pt",50,0,2, 100,0,200*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_ptres_vs_pt_efsa",m_h_ptres_vs_pt_efsa );    
  m_h_muonpt_safake = new TH1F("h_muonpt_safake","EF pt",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_safake",m_h_muonpt_safake);

  m_h_pt_vs_eta_efsa    = new TH2F("h_pt_vs_eta_efsa","pt res vs pt",100,0,100*GeV, 100,-3,3);
  sc = m_thistSvc->regHist("/AANT/Muon/h_pt_vs_eta_efsa",m_h_pt_vs_eta_efsa );    
  
  //SA TMEF
  
  m_h_muonpt_sa_tmef      = new TH1F("h_muon_pt_sa_tmef ","pt mu sa",50,0,100.*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muon_pt_sa_tmef ",m_h_muonpt_sa_tmef );
  m_h_muoneta_sa_tmef     = new TH1F("h_muon_eta_sa_tmef ","eta mu sa",70,-3.2,3.2);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muon_eta_sa_tmef ",m_h_muoneta_sa_tmef );
  m_h_muonphi_sa_tmef     = new TH1F("h_muon_phi_sa_tmef ","phi mu sa",70,-3.2,3.2);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muon_phi_sa_tmef ",m_h_muonphi_sa_tmef );
  
  
  m_h_DR_efsa_tmef    = new TH1F("DR_efsa_tmef","delta R l2 ms ",70,0,5);
  sc = m_thistSvc->regHist("/AANT/Muon/DR_efsa_tmef",m_h_DR_efsa_tmef);
  m_h_muonpt_efsa_b_truth_tmef = new TH1F("h_muonpt_efsa_b_truth_tmef","l1 pt b mu ",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_efsa_b_truth_tmef",m_h_muonpt_efsa_b_truth_tmef);
  m_h_muonpt_efsa_e_truth_tmef =new TH1F("h_muonpt_efsa_e_truth_tmef","l1 pt e mu ",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_efsa_e_truth_tmef",m_h_muonpt_efsa_e_truth_tmef) ;
  m_h_muonpt_efsa_b_truth_6_tmef = new TH1F("h_muonpt_efsa_b_truth_6_tmef","l1 pt b mu 6",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_efsa_b_truth_6_tmef",m_h_muonpt_efsa_b_truth_6_tmef);
  m_h_muonpt_efsa_e_truth_6_tmef =new TH1F("h_muonpt_efsa_e_truth_6_tmef","l1 pt e mu 6",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_efsa_e_truth_6_tmef",m_h_muonpt_efsa_e_truth_6_tmef) ;
  m_h_muonpt_efsa_b_truth_20_tmef = new TH1F("h_muonpt_efsa_b_truth_20_tmef","l1 pt b mu 20",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_efsa_b_truth_20_tmef",m_h_muonpt_efsa_b_truth_20_tmef);
  m_h_muonpt_efsa_e_truth_20_tmef =new TH1F("h_muonpt_efsa_e_truth_20_tmef","l1 pt e mu 20 ",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_efsa_e_truth_20_tmef",m_h_muonpt_efsa_e_truth_20_tmef) ;
  m_h_muonpt_efsa_b_truth_40_tmef = new TH1F("h_muonpt_efsa_b_truth_40_tmef","l1 pt b mu 40",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_efsa_b_truth_40_tmef",m_h_muonpt_efsa_b_truth_40_tmef);
  m_h_muonpt_efsa_e_truth_40_tmef =new TH1F("h_muonpt_efsa_e_truth_40_tmef","l1 pt e mu 40 ",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_efsa_e_truth_40_tmef",m_h_muonpt_efsa_e_truth_40_tmef) ;
  m_h_muoneta_efsa_truth_tmef =  new TH1F("h_muoneta_efsa_truth_tmef","l1 eta mu ",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muoneta_efsa_truth_tmef",m_h_muoneta_efsa_truth_tmef);
  m_h_muoneta_efsa_truth_6_tmef =  new TH1F("h_muoneta_efsa_truth_6_tmef","l1 eta mu 6",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muoneta_efsa_truth_6_tmef",m_h_muoneta_efsa_truth_6_tmef);
  m_h_muoneta_efsa_truth_20_tmef =  new TH1F("h_muoneta_efsa_truth_20_tmef","l1 eta mu 20",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muoneta_efsa_truth_20_tmef",m_h_muoneta_efsa_truth_20_tmef);
  m_h_muoneta_efsa_truth_40_tmef =  new TH1F("h_muoneta_efsa_truth_40_tmef","l1 eta mu 40",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muoneta_efsa_truth_40_tmef",m_h_muoneta_efsa_truth_40_tmef);
  m_h_ptres_vs_pt_efsa_tmef    = new TH2F("m_h_ptres_vs_pt_efsa_tmef","pt res vs pt",50,0,2, 100,0,200*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_ptres_vs_pt_efsa_tmef",m_h_ptres_vs_pt_efsa_tmef );    
  m_h_muonpt_safake_tmef = new TH1F("h_muonpt_safake_tmef","EF pt",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_safake_tmef",m_h_muonpt_safake_tmef);

  ///CB 
  m_h_muonpt_cb     = new TH1F("h_muon_pt_cb","pt mu cb",50,0,100.*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muon_pt_cb",m_h_muonpt_cb);
  m_h_muoneta_cb    = new TH1F("h_muon_eta_cb","eta mu cb",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muon_eta_cb",m_h_muoneta_cb);
  m_h_muonphi_cb    = new TH1F("h_muon_phi_cb","phi mu cb",70,-3.2,3.2);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muon_phi_cb",m_h_muonphi_cb);
  
  m_h_DR_efcb    = new TH1F("DR_efcb","delta R l2 ms ",70,0,5);
  sc = m_thistSvc->regHist("/AANT/Muon/DR_efcb",m_h_DR_efcb);
  
  m_h_muonpt_efcb_b_truth = new TH1F("h_muonpt_efcb_b_truth","l1 pt b mu ",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_efcb_b_truth",m_h_muonpt_efcb_b_truth);
  m_h_muonpt_efcb_e_truth =new TH1F("h_muonpt_efcb_e_truth","l1 pt e mu ",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_efcb_e_truth",m_h_muonpt_efcb_e_truth) ;
  
  m_h_muonpt_efcb_b_truth_6 = new TH1F("h_muonpt_efcb_b_truth_6","l1 pt b mu 6",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_efcb_b_truth_6",m_h_muonpt_efcb_b_truth_6);
  m_h_muonpt_efcb_e_truth_6 =new TH1F("h_muonpt_efcb_e_truth_6","l1 pt e mu 6",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_efcb_e_truth_6",m_h_muonpt_efcb_e_truth_6) ;
  
  m_h_muonpt_efcb_b_truth_20 = new TH1F("h_muonpt_efcb_b_truth_20","l1 pt b mu 20",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_efcb_b_truth_20",m_h_muonpt_efcb_b_truth_20);
  m_h_muonpt_efcb_e_truth_20 =new TH1F("h_muonpt_efcb_e_truth_20","l1 pt e mu 20 ",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_efcb_e_truth_20",m_h_muonpt_efcb_e_truth_20) ;
  
  m_h_muonpt_efcb_b_truth_40 = new TH1F("h_muonpt_efcb_b_truth_40","l1 pt b mu 40",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_efcb_b_truth_40",m_h_muonpt_efcb_b_truth_40);
  m_h_muonpt_efcb_e_truth_40 =new TH1F("h_muonpt_efcb_e_truth_40","l1 pt e mu 40 ",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_efcb_e_truth_40",m_h_muonpt_efcb_e_truth_40) ;
  
  
  m_h_muoneta_efcb_truth =  new TH1F("h_muoneta_efcb_truth","l1 eta mu ",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muoneta_efcb_truth",m_h_muoneta_efcb_truth);
  
  m_h_muoneta_efcb_truth_6 =  new TH1F("h_muoneta_efcb_truth_6","l1 eta mu 6",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muoneta_efcb_truth_6",m_h_muoneta_efcb_truth_6);
  m_h_muoneta_efcb_truth_20 =  new TH1F("h_muoneta_efcb_truth_20","l1 eta mu 20",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muoneta_efcb_truth_20",m_h_muoneta_efcb_truth_20);
  m_h_muoneta_efcb_truth_40 =  new TH1F("h_muoneta_efcb_truth_40","l1 eta mu 40",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muoneta_efcb_truth_40",m_h_muoneta_efcb_truth_40);
  
  m_h_ptres_vs_pt_efcb    = new TH2F("m_h_ptres_vs_pt_efcb","pt res vs pt",50,0,2, 100,0,200*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_ptres_vs_pt_efcb",m_h_ptres_vs_pt_efcb );
  
  m_h_muonpt_cbfake = new TH1F("h_muonpt_cbfake","EF pt",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_cbfake",m_h_muonpt_cbfake);

  m_h_pt_vs_eta_efcb    = new TH2F("h_pt_vs_eta_efcb","pt  vs eta",100,0,100*GeV, 100,-3,3);
  sc = m_thistSvc->regHist("/AANT/Muon/h_pt_vs_eta_efcb",m_h_pt_vs_eta_efcb );    
  
  
  
  //CB TMEF
  m_h_muonpt_cb_tmef      = new TH1F("h_muon_pt_cb_tmef ","pt mu cb",50,0,100.*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muon_pt_cb_tmef ",m_h_muonpt_cb_tmef );
  m_h_muoneta_cb_tmef     = new TH1F("h_muon_eta_cb_tmef ","eta mu sa",70,-3.2,3.2);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muon_eta_cb_tmef ",m_h_muoneta_cb_tmef );
  m_h_muonphi_cb_tmef     = new TH1F("h_muon_phi_cb_tmef ","phi mu sa",70,-3.2,3.2);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muon_phi_cb_tmef ",m_h_muonphi_cb_tmef );
   
  
  m_h_DR_efcb_tmef    = new TH1F("DR_efcb_tmef","delta R l2 ms ",70,0,5);
  sc = m_thistSvc->regHist("/AANT/Muon/DR_efcb_tmef",m_h_DR_efcb_tmef);
  m_h_muonpt_efcb_b_truth_tmef = new TH1F("h_muonpt_efcb_b_truth_tmef","l1 pt b mu ",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_efcb_b_truth_tmef",m_h_muonpt_efcb_b_truth_tmef);
  m_h_muonpt_efcb_e_truth_tmef =new TH1F("h_muonpt_efcb_e_truth_tmef","l1 pt e mu ",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_efcb_e_truth_tmef",m_h_muonpt_efcb_e_truth_tmef) ;
  m_h_muonpt_efcb_b_truth_6_tmef = new TH1F("h_muonpt_efcb_b_truth_6_tmef","l1 pt b mu 6",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_efcb_b_truth_6_tmef",m_h_muonpt_efcb_b_truth_6_tmef);
  m_h_muonpt_efcb_e_truth_6_tmef =new TH1F("h_muonpt_efcb_e_truth_6_tmef","l1 pt e mu 6",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_efcb_e_truth_6_tmef",m_h_muonpt_efcb_e_truth_6_tmef) ;
  m_h_muonpt_efcb_b_truth_20_tmef = new TH1F("h_muonpt_efcb_b_truth_20_tmef","l1 pt b mu 20",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_efcb_b_truth_20_tmef",m_h_muonpt_efcb_b_truth_20_tmef);
  m_h_muonpt_efcb_e_truth_20_tmef =new TH1F("h_muonpt_efcb_e_truth_20_tmef","l1 pt e mu 20 ",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_efcb_e_truth_20_tmef",m_h_muonpt_efcb_e_truth_20_tmef) ;
  m_h_muonpt_efcb_b_truth_40_tmef = new TH1F("h_muonpt_efcb_b_truth_40_tmef","l1 pt b mu 40",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_efcb_b_truth_40_tmef",m_h_muonpt_efcb_b_truth_40_tmef);
  m_h_muonpt_efcb_e_truth_40_tmef =new TH1F("h_muonpt_efcb_e_truth_40_tmef","l1 pt e mu 40 ",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_efcb_e_truth_40_tmef",m_h_muonpt_efcb_e_truth_40_tmef) ;
  m_h_muoneta_efcb_truth_tmef =  new TH1F("h_muoneta_efcb_truth_tmef","l1 eta mu ",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muoneta_efcb_truth_tmef",m_h_muoneta_efcb_truth_tmef);
  m_h_muoneta_efcb_truth_6_tmef =  new TH1F("h_muoneta_efcb_truth_6_tmef","l1 eta mu 6",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muoneta_efcb_truth_6_tmef",m_h_muoneta_efcb_truth_6_tmef);
  m_h_muoneta_efcb_truth_20_tmef =  new TH1F("h_muoneta_efcb_truth_20_tmef","l1 eta mu 20",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muoneta_efcb_truth_20_tmef",m_h_muoneta_efcb_truth_20_tmef);
  m_h_muoneta_efcb_truth_40_tmef =  new TH1F("h_muoneta_efcb_truth_40_tmef","l1 eta mu 40",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muoneta_efcb_truth_40_tmef",m_h_muoneta_efcb_truth_40_tmef);
  m_h_ptres_vs_pt_efcb_tmef    = new TH2F("m_h_ptres_vs_pt_efcb_tmef","pt res vs pt",50,0,2, 100,0,200*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_ptres_vs_pt_efcb_tmef",m_h_ptres_vs_pt_efcb_tmef );    
  m_h_muonpt_cbfake_tmef = new TH1F("h_muonpt_cbfake_tmef","EF pt",50, 0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_cbfake_tmef",m_h_muonpt_cbfake_tmef);
    
  //offline1
  //m_h_muonpt_rec_cb_b = new TH1F("m_h_muonpt_rec_cb_b","rec cb pt b",50, 0,100*GeV);
  //sc = m_thistSvc->regHist("/AANT/Muon/m_h_muonpt_rec_cb_b",m_h_muonpt_rec_cb_b);
  //m_h_muonpt_rec_cb_e = new TH1F("m_h_muonpt_rec_cb_e","rec cb pt e",50, 0,100*GeV);
  //sc = m_thistSvc->regHist("/AANT/Muon/m_h_muonpt_rec_cb_e",m_h_muonpt_rec_cb_e);
  

  //no truth
  //L1
  m_h_muonpt_l1_b_nt     = new TH1F("h_muonpt_l1_b_nt","pt mu l1 b",50,0,50.*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_l1_b_nt",m_h_muonpt_l1_b_nt);
  m_h_muonpt_l1_e_nt     = new TH1F("h_muonpt_l1_e_nt","pt mu l1 e",50,0,50.*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_l1_e_nt",m_h_muonpt_l1_e_nt);
  m_h_muoneta_l1_nt    = new TH1F("h_muoneta_l1_nt","eta mu l1",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muoneta_l1_nt",m_h_muoneta_l1_nt);
  m_h_muonphi_l1_b_nt    = new TH1F("h_muonphi_l1_b_nt","phi mu l1 b",70,-3.2,3.2);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonphi_l1_b_nt",m_h_muonphi_l1_b_nt);
  m_h_muonphi_l1_e_nt    = new TH1F("h_muonphi_l1_e_nt","phi mu l1 e",70,-3.2,3.2);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonphi_l1_e_nt",m_h_muonphi_l1_e_nt);
  
  //L2 sa with match with L1
  m_h_muonpt_l1_b_nt_matched_l2sa     = new TH1F("h_muon_pt_l1_b_nt_matched_l2sa","pt mu l1 b",50,0,100.*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muon_pt_l1_b_nt_matched_l2sa",m_h_muonpt_l1_b_nt_matched_l2sa);
  m_h_muonpt_l1_e_nt_matched_l2sa     = new TH1F("h_muon_pt_l1_e_nt_matched_l2sa","pt mu l1 e",50,0,100.*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muon_pt_l1_e_nt_matched_l2sa",m_h_muonpt_l1_e_nt_matched_l2sa);
  m_h_muoneta_l1_nt_matched_l2sa    = new TH1F("h_muon_eta_l1_nt_matched_l2sa","eta mu l1",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muon_eta_l1_nt_matched_l2sa",m_h_muoneta_l1_nt_matched_l2sa);
  m_h_muonphi_l1_b_nt_matched_l2sa    = new TH1F("h_muon_phi_l1_b_nt_matched_l2sa","phi mu l1 b",70,-3.2,3.2);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muon_phi_l1_b_nt_matched_l2sa",m_h_muonphi_l1_b_nt_matched_l2sa);
  m_h_muonphi_l1_e_nt_matched_l2sa    = new TH1F("h_muon_phi_l1_e_nt_matched_l2sa","phi mu l1 e",70,-3.2,3.2);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muon_phi_l1_e_nt_matched_l2sa",m_h_muonphi_l1_e_nt_matched_l2sa);
  //L2 CB with match with L1
  m_h_muonpt_l1_b_nt_matched_l2cb     = new TH1F("h_muon_pt_l1_b_nt_matched_l2cb","pt mu l1 b",50,0,100.*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muon_pt_l1_b_nt_matched_l2cb",m_h_muonpt_l1_b_nt_matched_l2cb);
  m_h_muonpt_l1_e_nt_matched_l2cb     = new TH1F("h_muon_pt_l1_e_nt_matched_l2cb","pt mu l1 e",50,0,100.*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muon_pt_l1_e_nt_matched_l2cb",m_h_muonpt_l1_e_nt_matched_l2cb);
  m_h_muoneta_l1_nt_matched_l2cb    = new TH1F("h_muon_eta_l1_nt_matched_l2cb","eta mu l1",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muon_eta_l1_nt_matched_l2cb",m_h_muoneta_l1_nt_matched_l2cb);
  m_h_muonphi_l1_b_nt_matched_l2cb    = new TH1F("h_muon_phi_l1_b_nt_matched_l2cb","phi mu l1 b",70,-3.2,3.2);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muon_phi_l1_b_nt_matched_l2cb",m_h_muonphi_l1_b_nt_matched_l2cb);
  m_h_muonphi_l1_e_nt_matched_l2cb    = new TH1F("h_muon_phi_l1_e_nt_matched_l2cb","phi mu l1 e",70,-3.2,3.2);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muon_phi_l1_e_nt_matched_l2cb",m_h_muonphi_l1_e_nt_matched_l2cb);

  // L1 vs L2 
  m_h_ptl1_vs_ptl2_l2sa_b    = new TH2F("m_h_ptl1_vs_ptl2sa_b","pt l1 res vs pt l2 b",50,0,50, 100,0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_ptl1_vs_ptl2sa_b", m_h_ptl1_vs_ptl2_l2sa_b );
  m_h_ptl1_vs_ptl2_l2cb_b    = new TH2F("m_h_ptl1_vs_ptl2cb_b","pt l1 res vs pt l2 b",50,0,50, 100,0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_ptl1_vs_ptl2cb_b", m_h_ptl1_vs_ptl2_l2cb_b );
  m_h_ptl1_vs_ptl2_l2sa_e    = new TH2F("m_h_ptl1_vs_ptl2sa_e","pt l1 res vs pt l2 e",50,0,50, 100,0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_ptl1_vs_ptl2_sa_e", m_h_ptl1_vs_ptl2_l2sa_e );
  m_h_ptl1_vs_ptl2_l2cb_e    = new TH2F("m_h_ptl1_vs_ptl2cb_e","pt l1 res vs pt l2 e",50,0,50, 100,0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_ptl1_vs_ptl2cb_e", m_h_ptl1_vs_ptl2_l2cb_e );
  
  //L2  no match with L1
  m_h_muonpt_b_nt_l2sa     = new TH1F("h_muon_pt_b_nt_l2sa","pt mu l1 b",50,0,100.*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muon_pt_b_nt_l2sa",m_h_muonpt_b_nt_l2sa);
  m_h_muonpt_e_nt_l2sa     = new TH1F("h_muon_pt_e_nt_l2sa","pt mu l1 e",50,0,100.*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muon_pt_e_nt_l2sa",m_h_muonpt_e_nt_l2sa);
  m_h_muoneta_nt_l2sa    = new TH1F("h_muon_eta_nt_l2sa","eta mu l1",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muon_eta_nt_l2sa",m_h_muoneta_nt_l2sa);
  m_h_muonphi_b_nt_l2sa    = new TH1F("h_muon_phi_b_nt_l2sa","phi mu l1 b",70,-3.2,3.2);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muon_phi_b_nt_l2sa",m_h_muonphi_b_nt_l2sa);
  m_h_muonphi_e_nt_l2sa    = new TH1F("h_muon_phi_e_nt_l2sa","phi mu l1 e",70,-3.2,3.2);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muon_phi_e_nt_l2sa",m_h_muonphi_e_nt_l2sa);

  m_h_muonpt_b_nt_l2cb     = new TH1F("h_muon_pt_b_nt_l2cb","pt mu l1 b",50,0,100.*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muon_pt_b_nt_l2cb",m_h_muonpt_b_nt_l2cb);
  m_h_muonpt_e_nt_l2cb     = new TH1F("h_muon_pt_e_nt_l2cb","pt mu l1 e",50,0,100.*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muon_pt_e_nt_l2cb",m_h_muonpt_e_nt_l2cb);
  m_h_muoneta_nt_l2cb    = new TH1F("h_muon_eta_nt_l2cb","eta mu l1",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muon_eta_nt_l2cb",m_h_muoneta_nt_l2cb);
  m_h_muonphi_b_nt_l2cb    = new TH1F("h_muon_phi_b_nt_l2cb","phi mu l1 b",70,-3.2,3.2);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muon_phi_b_nt_l2cb",m_h_muonphi_b_nt_l2cb);
  m_h_muonphi_e_nt_l2cb    = new TH1F("h_muon_phi_e_nt_l2cb","phi mu l1 e",70,-3.2,3.2);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muon_phi_e_nt_l2cb",m_h_muonphi_e_nt_l2cb);


    
  //EF matched to L2CB
  m_h_muonpt_l2_b_nt_matched_efsa     = new TH1F("h_muonpt_l2_b_nt_matched_efsa","pt mu l1 b",50,0,100.*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_l2_b_nt_matched_efsa",m_h_muonpt_l2_b_nt_matched_efsa);
  m_h_muonpt_l2_e_nt_matched_efsa     = new TH1F("h_muonpt_l2_e_nt_matched_efsa","pt mu l1 e",50,0,100.*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_l2_e_nt_matched_efsa",m_h_muonpt_l2_e_nt_matched_efsa);
  m_h_muoneta_l2_nt_matched_efsa    = new TH1F("h_muoneta_l2_nt_matched_efsa","eta mu l1",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muoneta_l2_nt_matched_efsa",m_h_muoneta_l2_nt_matched_efsa);
  m_h_muonphi_l2_b_nt_matched_efsa    = new TH1F("h_muonphi_l2_b_nt_matched_efsa","phi mu l1 b",70,-3.2,3.2);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonphi_l2_b_nt_matched_efsa",m_h_muonphi_l2_b_nt_matched_efsa);
  m_h_muonphi_l2_e_nt_matched_efsa    = new TH1F("h_muonphi_l2_e_nt_matched_efsa","phi mu l1 e",70,-3.2,3.2);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonphi_l2_e_nt_matched_efsa",m_h_muonphi_l2_e_nt_matched_efsa);
  
  m_h_muonpt_l2_b_nt_matched_efcb     = new TH1F("h_muonpt_l2_b_nt_matched_efcb","pt mu l1 b",50,0,100.*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_l2_b_nt_matched_efcb",m_h_muonpt_l2_b_nt_matched_efcb);
  m_h_muonpt_l2_e_nt_matched_efcb     = new TH1F("h_muonpt_l2_e_nt_matched_efcb","pt mu l1 e",50,0,100.*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonpt_l2_e_nt_matched_efcb",m_h_muonpt_l2_e_nt_matched_efcb);
  m_h_muoneta_l2_nt_matched_efcb    = new TH1F("h_muoneta_l2_nt_matched_efcb","eta mu l1",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muoneta_l2_nt_matched_efcb",m_h_muoneta_l2_nt_matched_efcb);
  m_h_muonphi_l2_b_nt_matched_efcb    = new TH1F("h_muonphi_l2_b_nt_matched_efcb","phi mu l1 b",70,-3.2,3.2);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muo_phi_l2_b_nt_matched_efcb",m_h_muonphi_l2_b_nt_matched_efcb);
  m_h_muonphi_l2_e_nt_matched_efcb    = new TH1F("h_muonphi_l2_e_nt_matched_efcb","phi mu l1 e",70,-3.2,3.2);
  sc = m_thistSvc->regHist("/AANT/Muon/h_muonphi_l2_e_nt_matched_efcb",m_h_muonphi_l2_e_nt_matched_efcb);

  //wrt offline
  m_h_pt_offmuon_b = new TH1F("h_pt_offmuon_b","pt offmuon_b",50,0,100.*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_pt_offmuon_b",m_h_pt_offmuon_b);
  m_h_pt_offmuon_e = new TH1F("h_pt_offmuon_e","pt offmuon_e",50,0,100.*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_pt_offmuon_e",m_h_pt_offmuon_e);
  m_h_eta_offmuon        = new TH1F("h_eta_offmuon","eta offline mu ",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_eta_offmuon",m_h_eta_offmuon);

  m_h_pt_offmuon_matched_l1_b_mu6 = new TH1F("h_pt_offmuon_matched_l1_b_mu6","pt offmuon matched with l1 b",50,0,100.*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_pt_offmuon_matched_l1_b_mu6",m_h_pt_offmuon_matched_l1_b_mu6);
  m_h_pt_offmuon_matched_l1_b_mu10 = new TH1F("h_pt_offmuon_matched_l1_b_mu10","pt offmuon matched with l1 b",50,0,100.*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_pt_offmuon_matched_l1_b_mu10",m_h_pt_offmuon_matched_l1_b_mu10);
  m_h_pt_offmuon_matched_l1_b_mu11 = new TH1F("h_pt_offmuon_matched_l1_b_mu11","pt offmuon matched with l1 b",50,0,100.*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_pt_offmuon_matched_l1_b_mu11",m_h_pt_offmuon_matched_l1_b_mu11);
  m_h_pt_offmuon_matched_l1_b_mu20 = new TH1F("h_pt_offmuon_matched_l1_b_mu20","pt offmuon matched with l1 b",50,0,100.*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_pt_offmuon_matched_l1_b_mu20",m_h_pt_offmuon_matched_l1_b_mu20);
  m_h_pt_offmuon_matched_l1_b_mu40 = new TH1F("h_pt_offmuon_matched_l1_b_mu40","pt offmuon matched with l1 b",50,0,100.*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_pt_offmuon_matched_l1_b_mu40",m_h_pt_offmuon_matched_l1_b_mu40);
  m_h_pt_offmuon_matched_l1_e_mu6 = new TH1F("h_pt_offmuon_matched_l1_e_mu6","pt offmuon matched with l1 e",50,0,100.*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_pt_offmuon_matched_l1_e_mu6",m_h_pt_offmuon_matched_l1_e_mu6);
  m_h_pt_offmuon_matched_l1_e_mu10 = new TH1F("h_pt_offmuon_matched_l1_e_mu10","pt offmuon matched with l1 e",50,0,100.*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_pt_offmuon_matched_l1_e_mu10",m_h_pt_offmuon_matched_l1_e_mu10);
  m_h_pt_offmuon_matched_l1_e_mu11 = new TH1F("h_pt_offmuon_matched_l1_e_mu11","pt offmuon matched with l1 e",50,0,100.*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_pt_offmuon_matched_l1_e_mu11",m_h_pt_offmuon_matched_l1_e_mu11);
  m_h_pt_offmuon_matched_l1_e_mu20 = new TH1F("h_pt_offmuon_matched_l1_e_mu20","pt offmuon matched with l1 e",50,0,100.*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_pt_offmuon_matched_l1_e_mu20",m_h_pt_offmuon_matched_l1_e_mu20);
  m_h_pt_offmuon_matched_l1_e_mu40 = new TH1F("h_pt_offmuon_matched_l1_e_mu40","pt offmuon matched with l1 e",50,0,100.*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_pt_offmuon_matched_l1_e_mu40",m_h_pt_offmuon_matched_l1_e_mu40);
  m_h_eta_offmuon_matched_l1     = new TH1F("h_eta_offmuon_matched_l1","eta offline mu matched with l2sa",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_eta_offmuon_matched_l1",m_h_eta_offmuon_matched_l1);

  m_h_ptl1_vs_ptoffmuon_b   = new TH2F("h_ptl1_vs_ptoffmuon_b","pt l1 vs pt offmuon b",50,0,50, 100,0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_ptl1_vs_ptoffmuon_b", m_h_ptl1_vs_ptoffmuon_b );
  m_h_ptl1_vs_ptoffmuon_e   = new TH2F("h_ptl1_vs_ptoffmuon_e","pt l1 vs pt offmuon e",50,0,50, 100,0,100*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_ptl1_vs_ptoffmuon_e", m_h_ptl1_vs_ptoffmuon_e );
  
  m_h_pt_offmuon_matched_l2sa_b    = new TH1F("h_pt_offmuon_matched_l2sa_b","pt offmuon matched with l2sa b",50,0,100.*GeV);
  m_h_pt_offmuon_matched_l2sa_b_mu6    = new TH1F("h_pt_offmuon_matched_l2sa_b_mu6","pt offmuon matched with l2sa b mu6 ",50,0,100.*GeV);
  m_h_pt_offmuon_matched_l2sa_b_mu20    = new TH1F("h_pt_offmuon_matched_l2sa_b_mu20","pt offmuon matched with l2sa b mu20 ",50,0,100.*GeV);
  m_h_phi_offmuon_matched_l2sa_b   = new TH1F("h_phi_offmuon_matched_l2sa_b","phi offmuon matched with l2sa b",50,0,100.*GeV);
  m_h_pt_offmuon_matched_l2sa_e    = new TH1F("h_pt_offmuon_matched_l2sa_e","pt offmuon matched with l2sa e",50,0,100.*GeV);
  m_h_pt_offmuon_matched_l2sa_e_mu6    = new TH1F("h_pt_offmuon_matched_l2sa_e_mu6","pt offmuon matched with l2sa e mu6 ",50,0,100.*GeV);
  m_h_pt_offmuon_matched_l2sa_e_mu20    = new TH1F("h_pt_offmuon_matched_l2sa_e_mu20","pt offmuon matched with l2sa e mu20 ",50,0,100.*GeV);
  m_h_phi_offmuon_matched_l2sa_e   = new TH1F("h_phi_offmuon_matched_l2sa_e","phi offmuon matched with l2sa e",50,0,100.*GeV);
  m_h_eta_offmuon_matched_l2sa     = new TH1F("h_eta_offmuon_matched_l2sa","eta offline mu matched with l2sa",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_pt_offmuon_matched_l2sa_b",m_h_pt_offmuon_matched_l2sa_b);
  sc = m_thistSvc->regHist("/AANT/Muon/h_pt_offmuon_matched_l2sa_b_mu6",m_h_pt_offmuon_matched_l2sa_b_mu6);
  sc = m_thistSvc->regHist("/AANT/Muon/h_pt_offmuon_matched_l2sa_b_mu20",m_h_pt_offmuon_matched_l2sa_b_mu20);
  sc = m_thistSvc->regHist("/AANT/Muon/h_phi_offmuon_matched_l2sa_b",m_h_phi_offmuon_matched_l2sa_b);
  sc = m_thistSvc->regHist("/AANT/Muon/h_pt_offmuon_matched_l2sa_e",m_h_pt_offmuon_matched_l2sa_e);
  sc = m_thistSvc->regHist("/AANT/Muon/h_pt_offmuon_matched_l2sa_e_mu6",m_h_pt_offmuon_matched_l2sa_e_mu6);
  sc = m_thistSvc->regHist("/AANT/Muon/h_pt_offmuon_matched_l2sa_e_mu20",m_h_pt_offmuon_matched_l2sa_e_mu20);
  sc = m_thistSvc->regHist("/AANT/Muon/h_phi_offmuon_matched_l2sa_e",m_h_phi_offmuon_matched_l2sa_e);
  sc = m_thistSvc->regHist("/AANT/Muon/h_eta_offmuon_matched_l2sa",m_h_eta_offmuon_matched_l2sa);

  m_h_pt_offmuon_matched_l2cb_b    = new TH1F("h_pt_offmuon_matched_l2cb_b","pt offmuon matched with l2cb b",50,0,100.*GeV);
  m_h_pt_offmuon_matched_l2cb_b_mu6    = new TH1F("h_pt_offmuon_matched_l2cb_b_mu6","pt offmuon matched with l2cb b mu6 ",50,0,100.*GeV);
  m_h_pt_offmuon_matched_l2cb_b_mu20    = new TH1F("h_pt_offmuon_matched_l2cb_b_mu20","pt offmuon matched with l2cb b mu20 ",50,0,100.*GeV);
  m_h_phi_offmuon_matched_l2cb_b   = new TH1F("h_phi_offmuon_matched_l2cb_b","phi offmuon matched with l2cb b",50,0,100.*GeV);
  m_h_pt_offmuon_matched_l2cb_e    = new TH1F("h_pt_offmuon_matched_l2cb_e","pt offmuon matched with l2cb e",50,0,100.*GeV);
  m_h_pt_offmuon_matched_l2cb_e_mu6    = new TH1F("h_pt_offmuon_matched_l2cb_e_mu6","pt offmuon matched with l2cb e mu6 ",50,0,100.*GeV);
  m_h_pt_offmuon_matched_l2cb_e_mu20    = new TH1F("h_pt_offmuon_matched_l2cb_e_mu20","pt offmuon matched with l2cb e mu20 ",50,0,100.*GeV);
  m_h_phi_offmuon_matched_l2cb_e   = new TH1F("h_phi_offmuon_matched_l2cb_e","phi offmuon matched with l2cb e",50,0,100.*GeV);
  m_h_eta_offmuon_matched_l2cb     = new TH1F("h_eta_offmuon_matched_l2cb","eta offline mu matched with l2cb",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_pt_offmuon_matched_l2cb_b",m_h_pt_offmuon_matched_l2cb_b);
  sc = m_thistSvc->regHist("/AANT/Muon/h_pt_offmuon_matched_l2cb_b_mu6",m_h_pt_offmuon_matched_l2cb_b_mu6);
  sc = m_thistSvc->regHist("/AANT/Muon/h_pt_offmuon_matched_l2cb_b_mu20",m_h_pt_offmuon_matched_l2cb_b_mu20);
  sc = m_thistSvc->regHist("/AANT/Muon/h_phi_offmuon_matched_l2cb_b",m_h_phi_offmuon_matched_l2cb_b);
  sc = m_thistSvc->regHist("/AANT/Muon/h_pt_offmuon_matched_l2cb_e",m_h_pt_offmuon_matched_l2cb_e);
  sc = m_thistSvc->regHist("/AANT/Muon/h_pt_offmuon_matched_l2cb_e_mu6",m_h_pt_offmuon_matched_l2cb_e_mu6);
  sc = m_thistSvc->regHist("/AANT/Muon/h_pt_offmuon_matched_l2cb_e_mu20",m_h_pt_offmuon_matched_l2cb_e_mu20);
  sc = m_thistSvc->regHist("/AANT/Muon/h_phi_offmuon_matched_l2cb_e",m_h_phi_offmuon_matched_l2cb_e);
  sc = m_thistSvc->regHist("/AANT/Muon/h_eta_offmuon_matched_l2cb",m_h_eta_offmuon_matched_l2cb);
  
  //DecToo histos
  
  m_h_l1item =  new TH1F("m_h_l1item","L1 items" ,350,0,350);
  sc = m_thistSvc->regHist("/AANT/Muon/h_l1item",m_h_l1item);
  m_h_l2item =  new TH1F("m_h_l2item","L2 items" ,350,0,350);
  sc = m_thistSvc->regHist("/AANT/Muon/h_l2item",m_h_l2item);
  m_h_efitem =  new TH1F("m_h_efitem","EF items" ,350,0,350);
  sc = m_thistSvc->regHist("/AANT/Muon/h_efitem",m_h_efitem);
  
  m_h_l1item_all =  new TH1F("m_h_l1item_all","L1 item_alls" ,350,0,350);
  sc = m_thistSvc->regHist("/AANT/Muon/h_l1item_all",m_h_l1item_all);
  m_h_l2item_all =  new TH1F("m_h_l2item_all","L2 item_alls" ,350,0,350);
  sc = m_thistSvc->regHist("/AANT/Muon/h_l2item_all",m_h_l2item_all);
  m_h_efitem_all =  new TH1F("m_h_efitem_all","EF item_alls" ,350,0,350);
  sc = m_thistSvc->regHist("/AANT/Muon/h_efitem_all",m_h_efitem_all);
    

  //fakes
  
  m_h_ptfakeSAL2 = new TH1F("h_ptfakeSAL2","L2 pt offmuon not matched with truth",50,0,100.*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_ptfakeSAL2",m_h_ptfakeSAL2);
  m_h_etafakeSAL2 = new TH1F("h_etafakeSAL2 ","L2 eta offmuon not matched with truth",70,-3.0,3.0);;
  sc = m_thistSvc->regHist("/AANT/Muon/h_etafakeSAL2",m_h_etafakeSAL2);
  m_h_phifakeSAL2 = new TH1F("h_phifakeSAL2","L2 phi offmuon not matched with truth",70,-3.2,3.2);;
  sc = m_thistSvc->regHist("/AANT/Muon/h_phifakeSAL2",m_h_phifakeSAL2);
  
  m_h_ptfakeCBL2 = new TH1F("h_ptfakeCBL2","L2 pt offmuon not matched with truth",50,0,100.*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_ptfakeCBL2",m_h_ptfakeCBL2);
  m_h_etafakeCBL2 = new TH1F("h_etafakeCBL2 ","L2 eta offmuon not matched with truth",70,-3.0,3.0);;
  sc = m_thistSvc->regHist("/AANT/Muon/h_etafakeCBL2",m_h_etafakeCBL2);
  m_h_phifakeCBL2 = new TH1F("h_phifakeCBL2","L2 phi offmuon not matched with truth",70,-3.2,3.2);;
  sc = m_thistSvc->regHist("/AANT/Muon/h_phifakeCBL2",m_h_phifakeCBL2);
  

  m_h_ptfakeSA = new TH1F("h_ptfakeSA","pt offmuon not matched with truth",50,0,100.*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_ptfakeSA",m_h_ptfakeSA);
  m_h_etafakeSA = new TH1F("h_etafakeSA","eta offmuon not matched with truth",70,-3.0,3.0);;
  sc = m_thistSvc->regHist("/AANT/Muon/h_etafakeSA",m_h_etafakeSA);
  m_h_phifakeSA = new TH1F("h_phifakeSA","phi offmuon not matched with truth",70,-3.2,3.2);;
  sc = m_thistSvc->regHist("/AANT/Muon/h_phifakeSA",m_h_phifakeSA);
  
  m_h_ptfakeCB = new TH1F("h_ptfakeCB","pt offmuon not matched with truth",50,0,100.*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_ptfakeCB",m_h_ptfakeCB);
  m_h_etafakeCB = new TH1F("h_etafakeCB","eta offmuon not matched with truth",70,-3.0,3.0);;
  sc = m_thistSvc->regHist("/AANT/Muon/h_etafakeCB",m_h_etafakeCB);
  m_h_phifakeCB = new TH1F("h_phifakeCB","phi offmuon not matched with truth",70,-3.2,3.2);;
  sc = m_thistSvc->regHist("/AANT/Muon/h_phifakeCB",m_h_phifakeCB);
  
  m_h_ptfakeSA_tmef = new TH1F("h_ptfakeSA_tmef","pt offmuon not matched with truth",50,0,100.*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_ptfakeSA_tmef",m_h_ptfakeSA_tmef);
  m_h_etafakeSA_tmef = new TH1F("h_etafakeSA_tmef","eta offmuon not matched with truth",70,-3.0,3.0);;
  sc = m_thistSvc->regHist("/AANT/Muon/h_etafakeSA_tmef",m_h_etafakeSA_tmef);
  m_h_phifakeSA_tmef = new TH1F("h_phifakeSA_tmef","phi offmuon not matched with truth",70,-3.2,3.2);;
  sc = m_thistSvc->regHist("/AANT/Muon/h_phifakeSA",m_h_phifakeSA_tmef);
  
  m_h_ptfakeCB_tmef = new TH1F("h_ptfakeCB_tmef","pt offmuon not matched with truth",50,0,100.*GeV);
  sc = m_thistSvc->regHist("/AANT/Muon/h_ptfakeCB_tmef",m_h_ptfakeCB_tmef);
  m_h_etafakeCB_tmef = new TH1F("h_etafakeCB_tmef","eta offmuon not matched with truth",70,-3.0,3.0);;
  sc = m_thistSvc->regHist("/AANT/Muon/h_etafakeCB_tmef",m_h_etafakeCB_tmef);
  m_h_phifakeCB_tmef = new TH1F("h_phifakeCB_tmef","phi offmuon not matched with truth",70,-3.2,3.2);;
  sc = m_thistSvc->regHist("/AANT/Muon/h_phifakeCB_tmef",m_h_phifakeCB_tmef);

  m_h_trketa = new TH1F("h_trketa","trk eta ",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_trketa",m_h_trketa);
  m_h_trkphi = new TH1F("h_trkphi","trk phi ",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_trkphi",m_h_trkphi);
  m_h_trkpt = new TH1F("h_trkpt","trk pt ",70,-3.0,3.0);
  sc = m_thistSvc->regHist("/AANT/Muon/h_trkpt",m_h_trkpt);
    
  if (sc.isFailure()) { 
    mLog << MSG::ERROR << "ROOT Hist registration failed" << endreq; 
    return sc; 
  } else  mLog << MSG::INFO << "histograms registered correclty "  << endreq;
  
  return sc;

}
