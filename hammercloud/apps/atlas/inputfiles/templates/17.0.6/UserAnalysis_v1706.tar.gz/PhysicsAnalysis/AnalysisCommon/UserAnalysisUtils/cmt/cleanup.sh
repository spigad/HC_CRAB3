# echo "cleanup UserAnalysisUtils UserAnalysisUtils-02-02-13 in /data/etp1/elmsheus/athena/17.0.6-user/PhysicsAnalysis/AnalysisCommon"

if test "${CMTROOT}" = ""; then
  CMTROOT=/cvmfs/atlas.cern.ch/repo/sw/software/i686-slc5-gcc43-opt/17.0.6/CMT/v1r23; export CMTROOT
fi
. ${CMTROOT}/mgr/setup.sh
cmtUserAnalysisUtilstempfile=`${CMTROOT}/mgr/cmt -quiet build temporary_name`
if test ! $? = 0 ; then cmtUserAnalysisUtilstempfile=/tmp/cmt.$$; fi
${CMTROOT}/mgr/cmt cleanup -sh -pack=UserAnalysisUtils -version=UserAnalysisUtils-02-02-13 -path=/data/etp1/elmsheus/athena/17.0.6-user/PhysicsAnalysis/AnalysisCommon  -quiet -without_version_directory $* >${cmtUserAnalysisUtilstempfile}
if test $? != 0 ; then
  echo >&2 "${CMTROOT}/mgr/cmt cleanup -sh -pack=UserAnalysisUtils -version=UserAnalysisUtils-02-02-13 -path=/data/etp1/elmsheus/athena/17.0.6-user/PhysicsAnalysis/AnalysisCommon  -quiet -without_version_directory $* >${cmtUserAnalysisUtilstempfile}"
  cmtcleanupstatus=2
  /bin/rm -f ${cmtUserAnalysisUtilstempfile}
  unset cmtUserAnalysisUtilstempfile
  return $cmtcleanupstatus
fi
cmtcleanupstatus=0
. ${cmtUserAnalysisUtilstempfile}
if test $? != 0 ; then
  cmtcleanupstatus=2
fi
/bin/rm -f ${cmtUserAnalysisUtilstempfile}
unset cmtUserAnalysisUtilstempfile
return $cmtcleanupstatus

