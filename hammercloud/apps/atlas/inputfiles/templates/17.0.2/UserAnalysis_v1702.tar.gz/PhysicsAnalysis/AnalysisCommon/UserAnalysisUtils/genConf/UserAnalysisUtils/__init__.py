## Hook for UserAnalysisUtils genConf module
