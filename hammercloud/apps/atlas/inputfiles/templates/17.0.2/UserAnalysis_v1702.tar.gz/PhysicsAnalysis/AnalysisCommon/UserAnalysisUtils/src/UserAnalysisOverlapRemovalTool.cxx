/*****************************************************************************
Name    : UserAnalysisPreparationTool.cxx
Package : offline/PhysicsAnalysis/AnalysisCommon/UserAnalysisUtils
Author  : Ketevi A. Assamagan
Created : November 2007
Purpose : User Analysis Overlap Removal - see UserAnalysisOverlapRemovalTool.h for details
*****************************************************************************/

#include "GaudiKernel/MsgStream.h"
#include "GaudiKernel/GaudiException.h"
#include "GaudiKernel/Property.h"

// Accessing data:
#include "CLHEP/Units/PhysicalConstants.h"

// User Tools
#include "UserAnalysisUtils/UserAnalysisOverlapRemovalTool.h"

#include "muonEvent/Muon.h"
#include "egammaEvent/Electron.h"
#include "egammaEvent/Photon.h"
#include "CaloEvent/CaloCluster.h"
#include "Particle/TrackParticle.h"
#include "tauEvent/TauJet.h"
#include "JetEvent/Jet.h"

#include <sstream>
#include <iomanip>
#include <iostream>

using namespace Analysis;
using namespace Rec;
using namespace std;

//------------------------------------------------------------------------------
UserAnalysisOverlapRemovalTool::UserAnalysisOverlapRemovalTool( const std::string& type,
                                                                const std::string& name, 
                                                                const IInterface* parent )
  : AlgTool( type, name, parent ),
    m_userSelectionTool ( "UserAnalysisSelectionTool"),
    m_userOverlapCheckingTool ( "UserAnalysisOverlapCheckingTool") {

  declareInterface<UserAnalysisOverlapRemovalTool>( this );

  declareProperty("UserSelectionTool",       m_userSelectionTool);
  declareProperty("UserOverlapCheckingTool", m_userOverlapCheckingTool);
  declareProperty("InputContainerKeys",      m_inputContainerKeys);
  declareProperty("IsAtlfastData",           m_isAtlfast=false);

  declareProperty("OuputObjectKey",         m_outputObjectKey        = "FinalStateObjects");
  declareProperty("OutputLeptonKey",        m_outputLeptonKey        = "FinalStateLeptons");
  declareProperty("OutputPhotonKey",        m_outputPhotonKey        = "FinalStatePhotons");
  declareProperty("OutputElectronKey",      m_outputElectronKey      = "FinalStateElectrons");
  declareProperty("OutputMuonKey",          m_outputMuonKey          = "FinalStateMuons");
  declareProperty("OutputTauJetKey",        m_outputTauJetKey        = "FinalStateTauJets");
  declareProperty("OutputCalloClusterKey",  m_outputCaloClusterKey   = "FinalStateCaloClusters");
  declareProperty("OutputTrackParticleKey", m_outputTrackParticleKey = "FinalStateTrackParticles");
  declareProperty("OutputJetKey",           m_outputJetKey           = "FinalStateJets");
  declareProperty("OutputBJetKey",          m_outputBJetKey          = "FinalStateBJets");
  declareProperty("OutputLightJetKey",      m_outputLightJetKey      = "FinalStateLightJets");
  declareProperty("RemoveOverlapInSameContainer", m_removeOverlapInSameContainer=true);

  /** initialize counters */
  m_numElectrons      = std::make_pair(0,0);
  m_numPhotons        = std::make_pair(0,0);
  m_numMuons          = std::make_pair(0,0);
  m_numTauJets        = std::make_pair(0,0);
  m_numJets           = std::make_pair(0,0);
  m_numBJets          = std::make_pair(0,0);
  m_numLightJets      = std::make_pair(0,0);
  m_numTrackParticles = std::make_pair(0,0);
  m_numCaloClusters   = std::make_pair(0,0);
  
}

//------------------------------------------------------------------------------
StatusCode UserAnalysisOverlapRemovalTool::initialize() {

  m_log = new MsgStream(msgSvc(), name());
  *m_log << MSG::DEBUG << "in initialize()" << endreq;
  m_debug = m_log->level() <= MSG::DEBUG;
  m_verbose = m_log->level() <= MSG::VERBOSE;

  /** get a handle of StoreGate for access to the Event Store */
  StatusCode sc = service("StoreGateSvc", m_storeGate);
  if (sc.isFailure()) {
     *m_log << MSG::ERROR
            << "Unable to retrieve pointer to StoreGateSvc"
            << endreq;
     return sc;
  }

  /// get a handle on the selection tools
  sc = m_userSelectionTool.retrieve();
  if ( sc.isFailure() ) {
      *m_log << MSG::ERROR << "Can't get handle on analysis selection tool" << endreq;
      return sc;
  }

  sc = m_userOverlapCheckingTool.retrieve();
  if ( sc.isFailure() ) {
      *m_log << MSG::ERROR << "Can't get handle on analysis overlap checking tool" << endreq;
      return sc;
  }

  return StatusCode::SUCCESS;
}

//------------------------------------------------------------------------------
StatusCode UserAnalysisOverlapRemovalTool::finalize() {

  if ( m_debug ) *m_log << MSG::DEBUG << "in finalize()" << endreq;
 
  this->summarize();

  delete m_log;

  return StatusCode::SUCCESS;
}

//------------------------------------------------------------------------------
UserAnalysisOverlapRemovalTool::~UserAnalysisOverlapRemovalTool()
{}

//-------------------------------------------------------------------------------
StatusCode UserAnalysisOverlapRemovalTool::execute() {
  if ( m_debug ) *m_log << MSG::DEBUG << "in execute()" << endreq;

  /** check if the execute is already called or not 
      in one job, execute should be called once for each event */
  if ( this->isExecuted() ) {
    *m_log << MSG::WARNING << "overlapRemovalTool->execute() already called for the event in this job" << endreq;
    return StatusCode::SUCCESS; 
  }

  /** prepare the container for selection and overlap removal */
  StatusCode sc = this->prepareContainers();
  if ( sc.isFailure() ) return sc;
 
  /** now object preparation with overlap removal */
  for ( unsigned int i=0; i<m_inputContainerKeys.size(); ++i ) {

    string::size_type loc = m_inputContainerKeys[i].find( "Electron", 0);
    if( loc != string::npos ) sc = this->electronPreparation( m_inputContainerKeys[i] );

    loc = m_inputContainerKeys[i].find( "Photon", 0);
    if( loc != string::npos ) sc = this->photonPreparation( m_inputContainerKeys[i] );

    loc = m_inputContainerKeys[i].find( "Muon", 0);
    if( loc != string::npos ) sc = this->muonPreparation( m_inputContainerKeys[i] );

    std::string tau = "Tau";
    if ( m_isAtlfast ) tau = "TauJet";
    loc = m_inputContainerKeys[i].find( tau, 0);
    if( loc != string::npos ) sc = this->tauJetPreparation( m_inputContainerKeys[i] );

    std::string jet = "Jets";
    if ( m_isAtlfast ) jet = "Jet";
    loc = m_inputContainerKeys[i].find( jet, 0);
    if( loc != string::npos ) sc = this->jetPreparation( m_inputContainerKeys[i] );

    loc = m_inputContainerKeys[i].find( "Track", 0);
    if( loc != string::npos ) sc = this->trackParticlePreparation( m_inputContainerKeys[i] );

    loc = m_inputContainerKeys[i].find( "Cluster", 0);
    if( loc != string::npos ) sc = this->caloClusterPreparation( m_inputContainerKeys[i] );

    if ( sc.isFailure() ) return sc;

  }

  /** lock the containers so that they are no longer modified */
  sc = this->lockContainers();
  if ( sc.isFailure() ) return sc;

  if ( m_debug ) this->print();

  return StatusCode::SUCCESS;
}

//-------------------------------------------------------------------------------
const INavigable4MomentumCollection * UserAnalysisOverlapRemovalTool::finalStateObjects() {
  if ( m_debug ) *m_log << MSG::DEBUG << "in finalStateObjects()" << endreq;
  const INavigable4MomentumCollection * container = 0;
  StatusCode sc = m_storeGate->retrieve(container, m_outputObjectKey);
  if ( sc.isFailure() || container ==0 )
     *m_log << MSG::ERROR << "Final State objects not found" << endreq;
  return container;
}

const PhotonContainer * UserAnalysisOverlapRemovalTool::finalStatePhotons() {
  if ( m_debug ) *m_log << MSG::DEBUG << "in finalStatePhotons()" << endreq;
  const PhotonContainer * container = 0;
  StatusCode sc = m_storeGate->retrieve(container, m_outputPhotonKey);
  if ( sc.isFailure() || container ==0 )
     *m_log << MSG::ERROR << "Final State Photons not found" << endreq;
  return container;
}

const ElectronContainer * UserAnalysisOverlapRemovalTool::finalStateElectrons() {
  if ( m_debug ) *m_log << MSG::DEBUG << "in finalStateElectrons()" << endreq;
  const ElectronContainer * container = 0;
  StatusCode sc = m_storeGate->retrieve(container, m_outputElectronKey);
  if ( sc.isFailure() || container ==0 )
     *m_log << MSG::ERROR << "Final State Electrons not found" << endreq;
  return container;
}

const MuonContainer * UserAnalysisOverlapRemovalTool::finalStateMuons() {
  if ( m_debug ) *m_log << MSG::DEBUG << "in finalStateMuons()" << endreq;
  const MuonContainer * container = 0;
  StatusCode sc = m_storeGate->retrieve(container, m_outputMuonKey);
  if ( sc.isFailure() || container ==0 )
     *m_log << MSG::ERROR << "Final State Muons not found" << endreq;
  return container;
}

const INavigable4MomentumCollection * UserAnalysisOverlapRemovalTool::finalStateLeptons() {
  if ( m_debug ) *m_log << MSG::DEBUG << "in finalStateLeptons()" << endreq;
  const INavigable4MomentumCollection * container = 0;
  StatusCode sc = m_storeGate->retrieve(container, m_outputLeptonKey);
  if ( sc.isFailure() || container ==0 )
     *m_log << MSG::ERROR << "Final State Leptons not found" << endreq;
  return container;
}

const TauJetContainer * UserAnalysisOverlapRemovalTool::finalStateTauJets() {
  if ( m_debug ) *m_log << MSG::DEBUG << "in finalStateTauJets()" << endreq;
  const TauJetContainer * container = 0;
  StatusCode sc = m_storeGate->retrieve(container, m_outputTauJetKey);
  if ( sc.isFailure() || container ==0 )
     *m_log << MSG::ERROR << "Final State TauJets not found" << endreq;
  return container;
}

const JetCollection * UserAnalysisOverlapRemovalTool::finalStateJets() {
  if ( m_debug ) *m_log << MSG::DEBUG << "in finalStateJets()" << endreq;
  const JetCollection * container = 0;
  StatusCode sc = m_storeGate->retrieve(container, m_outputJetKey);
  if ( sc.isFailure() || container ==0 )
     *m_log << MSG::ERROR << "Final State Jets not found" << endreq;
  return container;
}

const JetCollection * UserAnalysisOverlapRemovalTool::finalStateBJets() {
  if ( m_debug ) *m_log << MSG::DEBUG << "in finalStateBJets()" << endreq;
  const JetCollection * container = 0;
  StatusCode sc = m_storeGate->retrieve(container, m_outputBJetKey);
  if ( sc.isFailure() || container ==0 )
     *m_log << MSG::ERROR << "Final State BJets not found" << endreq;
  return container;
}

const JetCollection * UserAnalysisOverlapRemovalTool::finalStateLightJets() {
  if ( m_debug ) *m_log << MSG::DEBUG << "in finalStateLightJets()" << endreq;
  const JetCollection * container = 0;
  StatusCode sc = m_storeGate->retrieve(container, m_outputLightJetKey);
  if ( sc.isFailure() || container ==0 )
     *m_log << MSG::ERROR << "Final State Light Jets not found" << endreq;
  return container;
}

const TrackParticleContainer * UserAnalysisOverlapRemovalTool::finalStateTrackParticles() {
  if ( m_debug ) *m_log << MSG::DEBUG << "in finalStateTrackParticles()" << endreq;
  const TrackParticleContainer * container = 0;
  StatusCode sc = m_storeGate->retrieve(container, m_outputTrackParticleKey);
  if ( sc.isFailure() || container ==0 )
     *m_log << MSG::ERROR << "Final State TrackParticles not found" << endreq;
  return container;
}

const CaloClusterContainer * UserAnalysisOverlapRemovalTool::finalStateCaloClusters() {
  if ( m_debug ) *m_log << MSG::DEBUG << "in finalStateCaloClusters()" << endreq;
  const CaloClusterContainer * container = 0;
  StatusCode sc = m_storeGate->retrieve(container, m_outputCaloClusterKey);
  if ( sc.isFailure() || container ==0 )
     *m_log << MSG::ERROR << "Final State CaloClusters not found" << endreq;
  return container;
}

  /** container preparation */
StatusCode UserAnalysisOverlapRemovalTool::electronPreparation( std::string key ) {
  if ( m_debug ) *m_log << MSG::DEBUG << "in electronPreparation() " << endreq;
  StatusCode sc = StatusCode::SUCCESS;

  INavigable4MomentumCollection * particles = this->allParticles();
  if ( !particles ) return sc;

  INavigable4MomentumCollection * leptons = this->allLeptons();
  if ( !leptons ) return sc;

  ElectronContainer * electrons = this->allElectrons();
  if ( !electrons ) return sc;

  const ElectronContainer * aod_electrons = 0;
  sc = m_storeGate->retrieve( aod_electrons, key );
  if ( sc.isFailure() ) {
    *m_log << MSG::WARNING << "No Existing ESD/AOD/DPD electron container found: key = " << key << endreq;
    return sc;
  }
  if ( m_debug ) *m_log << MSG::DEBUG << "Initial ElectronContainer size is " << aod_electrons->size() << endreq;
  m_numElectrons.first += aod_electrons->size();

  /// iterators over the container 
  ElectronContainer::const_iterator elecItr  = aod_electrons->begin();
  ElectronContainer::const_iterator elecItrE = aod_electrons->end();

  for (; elecItr != elecItrE; ++elecItr) {

    /** if this is the first particle, just put it in */ 
    if ( particles->size() == 0 ) {
       particles->push_back( *elecItr );
       leptons->push_back( *elecItr );
       electrons->push_back( *elecItr );
    }   
    /** check for the overlap and save non overlapping ones */
    else {
      INavigable4MomentumCollection::const_iterator nav4MomItr  = particles->begin();
      INavigable4MomentumCollection::const_iterator nav4MomItrE = particles->end();
      bool overlap = false;
      for (; nav4MomItr != nav4MomItrE; ++nav4MomItr) {
          /** overlap checking */
          const Electron * electron = dynamic_cast<const Electron*>(*nav4MomItr);
          if ( !electron || ( electron && m_removeOverlapInSameContainer ) )  
             overlap = m_userOverlapCheckingTool->overlap(*elecItr, *nav4MomItr);

          /** get out of the loop as soon as an overlap is found */
          if ( overlap ) break;
      }

      /** if no overlap then save */  
      if ( !overlap ) { 
         particles->push_back( *elecItr ); 
         leptons->push_back( *elecItr ); 
         electrons->push_back( *elecItr );
      }
    }
  }

  m_numElectrons.second += electrons->size();

  return sc;
}

StatusCode UserAnalysisOverlapRemovalTool::photonPreparation( std::string key ) {
  if ( m_debug ) *m_log << MSG::DEBUG << "in photonPreparation() " << endreq;
  StatusCode sc = StatusCode::SUCCESS;

  INavigable4MomentumCollection * particles = this->allParticles();
  if ( !particles ) return sc;

  PhotonContainer * photons = this->allPhotons();
  if ( !photons ) return sc;

  const PhotonContainer * aod_photons = 0;
  sc = m_storeGate->retrieve( aod_photons, key );
  if ( sc.isFailure() ) {
    *m_log << MSG::WARNING << "No Existing ESD/AOD/DPD photon container found: key = " << key << endreq;
    return sc;
  }
  if ( m_debug ) *m_log << MSG::DEBUG << "Initial PhotonContainer size is " << aod_photons->size() << endreq;
  m_numPhotons.first += aod_photons->size();

  /// iterators over the container 
  PhotonContainer::const_iterator photItr  = aod_photons->begin();
  PhotonContainer::const_iterator photItrE = aod_photons->end();

  for (; photItr != photItrE; ++photItr) {

    /** if this is the first particle, just put it in */ 
    if ( particles->size() == 0 ) {
       particles->push_back( *photItr );
       photons->push_back( *photItr );
    }   
    /** check for the overlap and save non overlapping ones */
    else {
      INavigable4MomentumCollection::const_iterator nav4MomItr  = particles->begin();
      INavigable4MomentumCollection::const_iterator nav4MomItrE = particles->end();
      bool overlap = false;
      for (; nav4MomItr != nav4MomItrE; ++nav4MomItr) {
          /** overlap checking */
          const Photon * photon = dynamic_cast<const Photon*>(*nav4MomItr);
          if ( !photon || ( photon && m_removeOverlapInSameContainer ) )  
             overlap = m_userOverlapCheckingTool->overlap(*photItr, *nav4MomItr);

          /** get out of the loop as soon as an overlap is found */
          if ( overlap ) break;
      }

      /** if no overlap then save */  
      if ( !overlap ) { 
         particles->push_back( *photItr );  
         photons->push_back( *photItr );
      }
    }
  }

  m_numPhotons.second += photons->size();

  return sc;
}

StatusCode UserAnalysisOverlapRemovalTool::muonPreparation( std:: string key ) {
  if ( m_debug ) *m_log << MSG::DEBUG << "in muonPreparation() " << endreq;
  StatusCode sc = StatusCode::SUCCESS;

  INavigable4MomentumCollection * particles = this->allParticles();
  if ( !particles ) return sc;

  MuonContainer * muons = this->allMuons();
  if ( !muons ) return sc;

  const MuonContainer * aod_muons = 0;
  sc = m_storeGate->retrieve( aod_muons, key );
  if ( sc.isFailure() ) {
    *m_log << MSG::WARNING << "No Existing ESD/AOD/DPD muon container found: key = " << key << endreq;
    return sc; 
  }
  if ( m_debug ) *m_log << MSG::DEBUG << "Initial MuonContainer size is " << aod_muons->size() << endreq;
  m_numMuons.first += aod_muons->size();

  /// iterators over the container 
  MuonContainer::const_iterator muonItr  = aod_muons->begin();
  MuonContainer::const_iterator muonItrE = aod_muons->end();

  for (; muonItr != muonItrE; ++muonItr) {

    /** if this is the first particle, just put it in */ 
    if ( particles->size() == 0 ) {
      particles->push_back( *muonItr );
       muons->push_back( *muonItr );
    }   
    /** check for the overlap and save non overlapping ones */
    else {
      INavigable4MomentumCollection::const_iterator nav4MomItr  = particles->begin();
      INavigable4MomentumCollection::const_iterator nav4MomItrE = particles->end();
      bool overlap = false;
      for (; nav4MomItr != nav4MomItrE; ++nav4MomItr) {
          /** overlap checking */
          const Analysis::Muon * muon = dynamic_cast<const Analysis::Muon*>(*nav4MomItr);
          if ( !muon || ( muon && m_removeOverlapInSameContainer ) )  
             overlap = m_userOverlapCheckingTool->overlap(*muonItr, *nav4MomItr);

          /** get out of the loop as soon as an overlap is found */
          if ( overlap ) break;
      }

      /** if no overlap then save */  
      if ( !overlap ) { 
         particles->push_back( *muonItr ); 
         muons->push_back( *muonItr );
      }
    }
  }

  m_numMuons.second += muons->size();

  return sc;
}

StatusCode UserAnalysisOverlapRemovalTool::tauJetPreparation( std::string key ) {
  if ( m_debug ) *m_log << MSG::DEBUG << "in tauJetPreparation() " << endreq;
  StatusCode sc = StatusCode::SUCCESS;

  INavigable4MomentumCollection * particles = this->allParticles();
  if ( !particles ) return sc;

  TauJetContainer * tauJets = this->allTauJets();
  if ( !tauJets ) return sc;

  const TauJetContainer * aod_tauJets = 0;
  sc = m_storeGate->retrieve( aod_tauJets, key );
  if ( sc.isFailure() ) {
    *m_log << MSG::WARNING << "No Existing ESD/AOD/DPD tauJet container found: key = " << key << endreq;
    return sc;
  }
  if ( m_debug ) *m_log << MSG::DEBUG << "initial TauJetContainer size is " << aod_tauJets->size() << endreq;
  m_numTauJets.first += aod_tauJets->size();

  /// iterators over the container 
  TauJetContainer::const_iterator tauJetItr  = aod_tauJets->begin();
  TauJetContainer::const_iterator tauJetItrE = aod_tauJets->end();

  for (; tauJetItr != tauJetItrE; ++tauJetItr) {

    /** if this is the first particle, just put it in */ 
    if ( particles->size() == 0 ) {
      particles->push_back( *tauJetItr );
       tauJets->push_back( *tauJetItr );
    }   
    /** check for the overlap and save non overlapping ones */
    else {
      INavigable4MomentumCollection::const_iterator nav4MomItr  = particles->begin();
      INavigable4MomentumCollection::const_iterator nav4MomItrE = particles->end();
      bool overlap = false;
      for (; nav4MomItr != nav4MomItrE; ++nav4MomItr) {
          /** overlap checking */
          const TauJet * taujet = dynamic_cast<const TauJet*>(*nav4MomItr);
          if ( !taujet || ( taujet && m_removeOverlapInSameContainer ) )  
             overlap = m_userOverlapCheckingTool->overlap(*tauJetItr, *nav4MomItr);

          /** get out of the loop as soon as an overlap is found */
          if ( overlap ) break;
      }

      /** if no overlap then save */  
      if ( !overlap ) { 
         particles->push_back( *tauJetItr ); 
         tauJets->push_back( *tauJetItr );
      }
    }
  }

  m_numTauJets.second += tauJets->size();

  return sc;
}

StatusCode UserAnalysisOverlapRemovalTool::jetPreparation( std::string key ) {
  if ( m_debug ) *m_log << MSG::DEBUG << "in jetPreparation() " << endreq;
  StatusCode sc = StatusCode::SUCCESS;

  INavigable4MomentumCollection * particles = this->allParticles();
  if ( !particles ) return sc;

  JetCollection * jets = this->allJets();
  if ( !jets ) return sc;

  JetCollection * bJets = this->allBJets();
  if ( !bJets ) return sc;

  JetCollection * lightJets = this->allLightJets();
  if ( !lightJets ) return sc;

  const JetCollection * aod_jets = 0;
  sc = m_storeGate->retrieve( aod_jets, key );
  if ( sc.isFailure() ) {
    *m_log << MSG::WARNING << "No Existing ESD/AOD/DPD jet container found: key = " << key << endreq;
    return sc;
  }
  if ( m_debug ) *m_log << MSG::DEBUG << "Initial JetCollection size is " << aod_jets->size() << endreq;
  m_numJets.first      += aod_jets->size();
  m_numBJets.first     += aod_jets->size();
  m_numLightJets.first += aod_jets->size();

  /// iterators over the container 
  JetCollection::const_iterator jetItr  = aod_jets->begin();
  JetCollection::const_iterator jetItrE = aod_jets->end();

  for (; jetItr != jetItrE; ++jetItr) {
    /** check if this jet passes pre-selection */
    /** if this is the first particle, just put it in */ 
    if ( particles->size() == 0 ) {
       particles->push_back( *jetItr );
       jets->push_back( *jetItr );
       if ( m_userSelectionTool->isBJet( *jetItr ) ) bJets->push_back( *jetItr);
       else lightJets->push_back( *jetItr );
    }   
    /** check for the overlap and save non overlapping ones */
    else {
      INavigable4MomentumCollection::const_iterator nav4MomItr  = particles->begin();
      INavigable4MomentumCollection::const_iterator nav4MomItrE = particles->end();
      bool overlap = false;
      for (; nav4MomItr != nav4MomItrE; ++nav4MomItr) {
          /** overlap checking */
          const Jet * jet = dynamic_cast<const Jet*>(*nav4MomItr);
          if ( !jet || ( jet && m_removeOverlapInSameContainer ) )  
             overlap = m_userOverlapCheckingTool->overlap(*jetItr, *nav4MomItr);
          /** get out of the loop as soon as an overlap is found */
          if ( overlap ) break;
      }

      /** if no overlap then save */  
      if ( !overlap ) { 
	particles->push_back( *jetItr );
	jets->push_back( *jetItr );
	if ( m_userSelectionTool->isBJet( *jetItr ) ) bJets->push_back( *jetItr);
	else lightJets->push_back( *jetItr );
      }
    }
  }

  m_numJets.second      += jets->size();
  m_numBJets.second     += bJets->size();
  m_numLightJets.second += lightJets->size();

  return sc;
}

StatusCode UserAnalysisOverlapRemovalTool::trackParticlePreparation( std::string key ) {
  if ( m_debug ) *m_log << MSG::DEBUG << "in trackParticlePreparation() " << endreq;
  StatusCode sc = StatusCode::SUCCESS;

  INavigable4MomentumCollection * particles = this->allParticles();
  if ( !particles ) return sc;

  TrackParticleContainer * trackParticles = this->allTrackParticles();
  if ( !trackParticles ) return sc;

  const TrackParticleContainer * aod_trackParticles = 0;
  sc = m_storeGate->retrieve( aod_trackParticles, key );
  if ( sc.isFailure() ) {
    *m_log << MSG::WARNING << "No ESD/AOD/DPD TrackParticle container found: key = " << key << endreq;
    return sc;
  }
  if ( m_debug ) *m_log << MSG::DEBUG << "Initial TrackParticleContainer size is " << aod_trackParticles->size() << endreq;
  m_numTrackParticles.first += aod_trackParticles->size();

  /// iterators over the container 
  TrackParticleContainer::const_iterator trackParticleItr  = aod_trackParticles->begin();
  TrackParticleContainer::const_iterator trackParticleItrE = aod_trackParticles->end();

  for (; trackParticleItr != trackParticleItrE; ++trackParticleItr) {
    /** if this is the first particle, just put it in */ 
    if ( particles->size() == 0 ) {
      particles->push_back( *trackParticleItr );
       trackParticles->push_back( *trackParticleItr );
    }   
    /** check for the overlap and save non overlapping ones */
    else {
      INavigable4MomentumCollection::const_iterator nav4MomItr  = particles->begin();
      INavigable4MomentumCollection::const_iterator nav4MomItrE = particles->end();
      bool overlap = false; 
      for (; nav4MomItr != nav4MomItrE; ++nav4MomItr) {
          /** overlap checking */
          const TrackParticle * trackparticle = dynamic_cast<const TrackParticle*>(*nav4MomItr);
          if ( !trackparticle || ( trackparticle && m_removeOverlapInSameContainer ) )  
             overlap = m_userOverlapCheckingTool->overlap(*trackParticleItr, *nav4MomItr);
          /** get out of the loop as soon as an overlap is found */
          if ( overlap ) break;
      }

      /** if no overlap then save */  
      if ( !overlap ) { 
         particles->push_back( *trackParticleItr ); 
         trackParticles->push_back( *trackParticleItr );
      }
    }
  }
  
  m_numTrackParticles.second += trackParticles->size();

  return sc;
}

StatusCode UserAnalysisOverlapRemovalTool::caloClusterPreparation( std::string key ) {
  if ( m_debug ) *m_log << MSG::DEBUG << "in caloClusterPreparation() " << endreq;
  StatusCode sc = StatusCode::SUCCESS;

  INavigable4MomentumCollection * particles = this->allParticles();
  if ( !particles ) return sc;

  CaloClusterContainer * caloClusters = this->allCaloClusters();
  if ( !caloClusters ) return sc;

  const CaloClusterContainer * aod_caloClusters = 0;
  sc = m_storeGate->retrieve( aod_caloClusters, key );
  if ( sc.isFailure() ) {
    *m_log << MSG::WARNING << "No Existing ESD/AOD/DPD CaloCluster container found: key = " << key << endreq;
    return sc;
  }
  if ( m_debug ) *m_log << MSG::DEBUG << "Initial CaloClusterContainer size is " << aod_caloClusters->size() << endreq;
  m_numCaloClusters.first += aod_caloClusters->size();

  /// iterators over the container 
  CaloClusterContainer::const_iterator caloClusterItr  = aod_caloClusters->begin();
  CaloClusterContainer::const_iterator caloClusterItrE = aod_caloClusters->end();

  for (; caloClusterItr != caloClusterItrE; ++caloClusterItr) {
    /** check if this caloCluster passes pre-selection */
    if ( !m_userSelectionTool->isSelected( *caloClusterItr ) ) continue;

    /** if this is the first particle, just put it in */ 
    if ( particles->size() == 0 ) {
      particles->push_back( *caloClusterItr );
       caloClusters->push_back( *caloClusterItr );
    }   
    /** check for the overlap and save non overlapping ones */
    else {
      INavigable4MomentumCollection::const_iterator nav4MomItr  = particles->begin();
      INavigable4MomentumCollection::const_iterator nav4MomItrE = particles->end();
      bool overlap = false;
      for (; nav4MomItr != nav4MomItrE; ++nav4MomItr) {
          /** overlap checking */
          const CaloCluster * cluster = dynamic_cast<const CaloCluster*>(*nav4MomItr);
          if ( !cluster || ( cluster && m_removeOverlapInSameContainer ) )  
             overlap = m_userOverlapCheckingTool->overlap(*caloClusterItr, *nav4MomItr);
          /** get out of the loop as soon as an overlap is found */
          if ( overlap ) break;
      }

      /** if no overlap then save */  
      if ( !overlap ) { 
         particles->push_back( *caloClusterItr ); 
         caloClusters->push_back( *caloClusterItr );
      } 
    }
  }

  m_numCaloClusters.second += caloClusters->size();

  return sc;
}

INavigable4MomentumCollection * UserAnalysisOverlapRemovalTool::allParticles() {
  if ( m_debug ) *m_log << MSG::DEBUG << "in allObjects()" << endreq;
  INavigable4MomentumCollection * container = 0;
  StatusCode sc = m_storeGate->retrieve(container, m_outputObjectKey);
  if ( sc.isFailure() || container ==0 )
     *m_log << MSG::ERROR << "Final State objects not found" << endreq;
  return container;
}

INavigable4MomentumCollection * UserAnalysisOverlapRemovalTool::allLeptons() {
  if ( m_debug ) *m_log << MSG::DEBUG << "in allLeptons()" << endreq;
  INavigable4MomentumCollection * container = 0;
  StatusCode sc = m_storeGate->retrieve(container, m_outputLeptonKey);
  if ( sc.isFailure() || container ==0 )
     *m_log << MSG::ERROR << "Final State leptons not found" << endreq;
  return container;

}

PhotonContainer * UserAnalysisOverlapRemovalTool::allPhotons() {
  if ( m_debug ) *m_log << MSG::DEBUG << "in allPhotons()" << endreq;
  PhotonContainer * container = 0;
  StatusCode sc = m_storeGate->retrieve(container, m_outputPhotonKey);
  if ( sc.isFailure() || container ==0 )
     *m_log << MSG::ERROR << "Final State Photons not found" << endreq;
  return container;
}

MuonContainer * UserAnalysisOverlapRemovalTool::allMuons() {
  if ( m_debug ) *m_log << MSG::DEBUG << "in allMuons()" << endreq;
  MuonContainer * container = 0;
  StatusCode sc = m_storeGate->retrieve(container, m_outputMuonKey);
  if ( sc.isFailure() || container ==0 )
     *m_log << MSG::ERROR << "Final State Muons not found" << endreq;
  return container;
}

ElectronContainer * UserAnalysisOverlapRemovalTool::allElectrons() {
  if ( m_debug ) *m_log << MSG::DEBUG << "in allElectrons()" << endreq;
  ElectronContainer * container = 0;
  StatusCode sc = m_storeGate->retrieve(container, m_outputElectronKey);
  if ( sc.isFailure() || container ==0 )
     *m_log << MSG::ERROR << "Final State Electrons not found" << endreq;
  return container;
}

TauJetContainer * UserAnalysisOverlapRemovalTool::allTauJets() {
  if ( m_debug ) *m_log << MSG::DEBUG << "in allTauJets()" << endreq;
  TauJetContainer * container = 0;
  StatusCode sc = m_storeGate->retrieve(container, m_outputTauJetKey);
  if ( sc.isFailure() || container ==0 )
     *m_log << MSG::ERROR << "Final State TauJets not found" << endreq;
  return container;
}

JetCollection * UserAnalysisOverlapRemovalTool::allJets() {
  if ( m_debug ) *m_log << MSG::DEBUG << "in allJets()" << endreq;
  JetCollection * container = 0;
  StatusCode sc = m_storeGate->retrieve(container, m_outputJetKey);
  if ( sc.isFailure() || container ==0 )
     *m_log << MSG::ERROR << "Final State Jets not found" << endreq;
  return container;
}

JetCollection * UserAnalysisOverlapRemovalTool::allBJets() {
  if ( m_debug ) *m_log << MSG::DEBUG << "in allBJets()" << endreq;
  JetCollection * container = 0;
  StatusCode sc = m_storeGate->retrieve(container, m_outputBJetKey);
  if ( sc.isFailure() || container ==0 )
     *m_log << MSG::ERROR << "Final State BJets not found" << endreq;
  return container;
}

JetCollection * UserAnalysisOverlapRemovalTool::allLightJets() {
  if ( m_debug ) *m_log << MSG::DEBUG << "in allLightJets()" << endreq;
  JetCollection * container = 0;
  StatusCode sc = m_storeGate->retrieve(container, m_outputLightJetKey);
  if ( sc.isFailure() || container ==0 )
     *m_log << MSG::ERROR << "Final State Light Jets not found" << endreq;
  return container;
}

TrackParticleContainer * UserAnalysisOverlapRemovalTool::allTrackParticles() {
  if ( m_debug ) *m_log << MSG::DEBUG << "in allTrackParticles()" << endreq;
  TrackParticleContainer * container = 0;
  StatusCode sc = m_storeGate->retrieve(container, m_outputTrackParticleKey);
  if ( sc.isFailure() || container ==0 )
     *m_log << MSG::ERROR << "Final State TrackParticles not found" << endreq;
  return container;
}

CaloClusterContainer * UserAnalysisOverlapRemovalTool::allCaloClusters() {
  if ( m_debug ) *m_log << MSG::DEBUG << "in allCaloClusters()" << endreq;
  CaloClusterContainer * container = 0;
  StatusCode sc = m_storeGate->retrieve(container, m_outputCaloClusterKey);
  if ( sc.isFailure() || container ==0 )
     *m_log << MSG::ERROR << "Final State CaloClusters not found" << endreq;
  return container;
}

//-------------------------------------------------------------------------------
StatusCode UserAnalysisOverlapRemovalTool::prepareContainers() {
  if ( m_debug ) *m_log << MSG::DEBUG << "in prepareContainers()" << endreq;

  /** create an empty container of all particles and record it */
  CaloClusterContainer * caloClusters = new CaloClusterContainer( SG::VIEW_ELEMENTS );
  StatusCode sc = m_storeGate->record ( caloClusters, m_outputCaloClusterKey);
  if ( sc.isFailure() ) {
    *m_log << MSG::WARNING << "Not able to create a collection of CaloClusters in StoreGate: key= " << m_outputCaloClusterKey << endreq;
     return sc;
  }

  /** create an empty container of TrackParticles and record it */
  TrackParticleContainer * trackParticles = new TrackParticleContainer( SG::VIEW_ELEMENTS );
  sc = m_storeGate->record ( trackParticles, m_outputTrackParticleKey);
  if ( sc.isFailure() ) {
    *m_log << MSG::WARNING << "Not able to create a collection of TrackParticles in StoreGate: key= " << m_outputTrackParticleKey << endreq;
     return sc;
  }

  /** create an empty container of all particles and record it */
  INavigable4MomentumCollection * particles = new INavigable4MomentumCollection( SG::VIEW_ELEMENTS );
  sc = m_storeGate->record ( particles, m_outputObjectKey);
  if ( sc.isFailure() ) {
    *m_log << MSG::WARNING << "Not able to create a collection of particles in StoreGate: key=  " << m_outputObjectKey << endreq;
     return sc; 
  }
  
  /** create an empty container of all leptons and record it */
  INavigable4MomentumCollection * leptons = new INavigable4MomentumCollection( SG::VIEW_ELEMENTS );
  sc = m_storeGate->record ( leptons, m_outputLeptonKey);
  if ( sc.isFailure() ) {
    *m_log << MSG::WARNING << "Not able to create a collection of leptons in StoreGate: key= " << m_outputLeptonKey << endreq;
     return sc;
  }

  /** create an empty container of all electrons and record it */
  ElectronContainer * electrons = new ElectronContainer( SG::VIEW_ELEMENTS );
  sc = m_storeGate->record ( electrons, m_outputElectronKey);
  if ( sc.isFailure() ) {
    *m_log << MSG::WARNING << "Not able to create a collection of electrons in StoreGate: key= " << m_outputElectronKey << endreq;
     return sc;
  }

  /** create an empty container of all photons and record it */
  PhotonContainer * photons = new PhotonContainer( SG::VIEW_ELEMENTS );
  sc = m_storeGate->record ( photons, m_outputPhotonKey);
  if ( sc.isFailure() ) {
    *m_log << MSG::WARNING << "Not able to create a collection of photons in StoreGate: key= " << m_outputPhotonKey << endreq;
     return sc;
  }

  /** create an empty container of all muons and record it */
  MuonContainer * muons = new MuonContainer( SG::VIEW_ELEMENTS );
  sc = m_storeGate->record ( muons, m_outputMuonKey);
  if ( sc.isFailure() ) {
    *m_log << MSG::WARNING << "Not able to create a collection of muons in StoreGate: key= " << m_outputMuonKey << endreq;
     return sc;
  }

  /** create an empty container of all tauJets and record it */
  TauJetContainer * tauJets = new TauJetContainer( SG::VIEW_ELEMENTS );
  sc = m_storeGate->record ( tauJets, m_outputTauJetKey);
  if ( sc.isFailure() ) {
    *m_log << MSG::WARNING << "Not able to create a collection of tau jets in StoreGate: key= " << m_outputTauJetKey << endreq;
     return sc;
  }

  /** create an empty container of all jets and record it */
  JetCollection * jets = new JetCollection( SG::VIEW_ELEMENTS );
  sc = m_storeGate->record ( jets, m_outputJetKey);
  if ( sc.isFailure() ) {
    *m_log << MSG::WARNING << "Not able to create a collection of jets in StoreGate: key= " << m_outputJetKey << endreq;
     return sc;
  }

  /** create an empty container of b-jets and record it */
  JetCollection * bjets = new JetCollection( SG::VIEW_ELEMENTS );
  sc = m_storeGate->record ( bjets, m_outputBJetKey);
  if ( sc.isFailure() ) {
    *m_log << MSG::WARNING << "Not able to create a collection of b-jets in StoreGate: key= " << m_outputBJetKey << endreq;
     return sc;
  }

  /** create an empty container of light (non b-jet) jets and record it */
  JetCollection * lightJets = new JetCollection( SG::VIEW_ELEMENTS );
  sc = m_storeGate->record ( lightJets, m_outputLightJetKey);
  if ( sc.isFailure() ) {
    *m_log << MSG::WARNING << "Not able to create a collection of lightJets in StoreGate: key= " << m_outputLightJetKey << endreq;
     return sc;
  }

  return StatusCode::SUCCESS;
}

//-------------------------------------------------------------------------------
StatusCode UserAnalysisOverlapRemovalTool::lockContainers() {
  if ( m_debug ) *m_log << MSG::DEBUG << "in lockContainers()" << endreq;

  /** lock the contianer so it is not modified downstream by anyone else */
  StatusCode sc = m_storeGate->setConst( this->allParticles() );
  if ( sc.isFailure() ) *m_log << MSG::WARNING << "Not able to lock the container of particles " << endreq;

  sc = m_storeGate->setConst( this->allLeptons() );
  if ( sc.isFailure() ) *m_log << MSG::WARNING << "Not able to lock the container of leptons " << endreq;

  sc = m_storeGate->setConst( this->allElectrons() );
  if ( sc.isFailure() ) *m_log << MSG::WARNING << "Not able to lock the container of electrons " << endreq;

  sc = m_storeGate->setConst( this->allPhotons() );
  if ( sc.isFailure() ) *m_log << MSG::WARNING << "Not able to lock the container of photons " << endreq;

  sc = m_storeGate->setConst( this->allMuons() );
  if ( sc.isFailure() ) *m_log << MSG::WARNING << "Not able to lock the container of muons " << endreq;

  sc = m_storeGate->setConst( this->allTauJets() );
  if ( sc.isFailure() ) *m_log << MSG::WARNING << "Not able to lock the container of tauJets " << endreq;

  sc = m_storeGate->setConst( this->allJets() );
  if ( sc.isFailure() ) *m_log << MSG::WARNING << "Not able to lock the container of jets " << endreq;

  sc = m_storeGate->setConst( this->allBJets() );
  if ( sc.isFailure() ) *m_log << MSG::WARNING << "Not able to lock the container of b-jets " << endreq;

  sc = m_storeGate->setConst( this->allLightJets() );
  if ( sc.isFailure() ) *m_log << MSG::WARNING << "Not able to lock the container of light Jets " << endreq;

  sc = m_storeGate->setConst( this->allTrackParticles() );
  if ( sc.isFailure() ) *m_log << MSG::WARNING << "Not able to lock the container of trackParticles " << endreq;

  sc = m_storeGate->setConst( this->allCaloClusters() );
  if ( sc.isFailure() ) *m_log << MSG::WARNING << "Not able to lock the container of calo clusters " << endreq;

  return sc;
}

//-----------------------------------------------------------------------------------------------
void UserAnalysisOverlapRemovalTool::print() {
  *m_log << MSG::DEBUG << "in print() " << endreq;

  /** Get the container of pre-selected Electrons */
  const ElectronContainer * electrons = this->finalStateElectrons();
  *m_log << MSG::DEBUG << "Number of Pre-selected Electrons is " << electrons->size() << endreq;

  /** Get the container of pre-selected Photons */
  const PhotonContainer * photons = this->finalStatePhotons();
  *m_log << MSG::DEBUG << "Number of Pre-selected Photons is " << photons->size() << endreq;

  /** Get the container of pre-selected Muons */
  const MuonContainer * muons = this->finalStateMuons();
  *m_log << MSG::DEBUG << "Number of Pre-selected Muons is " << muons->size() << endreq;

  /** Get the container of pre-selected TauJets */
  const TauJetContainer * tauJets = this->finalStateTauJets();
  *m_log << MSG::DEBUG << "Number of Pre-selected TauJets is " << tauJets->size() << endreq;

  /** Get the container of pre-selected Jets */
  const JetCollection * jets = this->finalStateJets();
  *m_log << MSG::DEBUG << "Number of Pre-selected Jets is " << jets->size() << endreq;

  /** Get the container of pre-selected B-tagged Jets */
  const JetCollection * bjets = this->finalStateBJets();
  *m_log << MSG::DEBUG << "Number of Pre-selected b-Jets is " << bjets->size() << endreq;

  /** Get the container of pre-selected non b-jets */
  const JetCollection * lightJets = this->finalStateLightJets();
  *m_log << MSG::DEBUG << "Number of Pre-selected LightJets is " << lightJets->size() << endreq;

  /** Get the container of pre-selected TrackParticles */
  const TrackParticleContainer * trackParticles = this->finalStateTrackParticles();
  *m_log << MSG::DEBUG << "Number of Pre-selected TrackParticles is " << trackParticles->size() << endreq;

  /** Get the container of pre-selected CaloClusters */
  const CaloClusterContainer * caloClusters = this->finalStateCaloClusters();
  *m_log << MSG::DEBUG << "Number of Pre-selected CaloClusters is " << caloClusters->size() << endreq;

  /** Get the container of pre-selected leptons (electrons, muons) */
  const INavigable4MomentumCollection * leptons = this->finalStateLeptons();
  *m_log << MSG::DEBUG << "Number of Pre-selected Leptons is " << leptons->size() << endreq;

  /** Get the container of ALL pre-selected objects */
  const INavigable4MomentumCollection * allObjects = this->finalStateObjects();
  *m_log << MSG::DEBUG << "Number of Pre-selected final State Objects is " << allObjects->size() << endreq;

}

//---------------------------------------------------------------------------------------------------------
void UserAnalysisOverlapRemovalTool::summarize() {
  *m_log << MSG::INFO << "in summarize() " << endreq;

  *m_log << MSG::INFO << "Summary Pre-selected/Overlap Removed Events ###################" << endreq;
  *m_log << MSG::INFO << "---------------------------------------------------------------" << endreq;
  *m_log << MSG::INFO << "Pre-selected Electrons             = " << std::setw(10) << m_numElectrons.first 
                      << "   Overlap-removed Electrons       = " << std::setw(10) << m_numElectrons.second << endreq;
  *m_log << MSG::INFO << "Pre-selected Photons               = " << std::setw(10) << m_numPhotons.first 
                      << "   Overlap-removed Photons         = " << std::setw(10) << m_numPhotons.second << endreq;
  *m_log << MSG::INFO << "Pre-selected pMuons                = " << std::setw(10) << m_numMuons.first 
                      << "    Overlap-removed Muons          = " << std::setw(10) << m_numMuons.second << endreq;
  *m_log << MSG::INFO << "Pre-selected TauJets               = " << std::setw(10) << m_numTauJets.first  
                      << "    Overlap-removed TauJets        = " << std::setw(10) << m_numTauJets.second << endreq;
  *m_log << MSG::INFO << "Pre-selected Jets                  = " << std::setw(10) << m_numJets.first 
                      << "    Overlap-removed Jets           = " << std::setw(10) << m_numJets.second << endreq;
  *m_log << MSG::INFO << "Pre-selected BJets                 = " << std::setw(10) << m_numBJets.first  
                      << "    Overlap-removed BJets          = " << std::setw(10) << m_numBJets.second << endreq;
  *m_log << MSG::INFO << "Pre-selected LightJets             = " << std::setw(10) << m_numLightJets.first
                      << "    Overlpa-removed LightJets      = " << std::setw(10) << m_numLightJets.second << endreq;
  *m_log << MSG::INFO << "Pre-selected TrackParticles        = " << std::setw(10) << m_numTrackParticles.first
                      << "    Overlap-removed TrackParticles = " << std::setw(10) << m_numTrackParticles.second << endreq;
  *m_log << MSG::INFO << "Pre-selected CaloClusters          = " << std::setw(10) << m_numCaloClusters.first
                      << "   Overlap-removed CaloClusters    = " << std::setw(10) << m_numCaloClusters.second << endreq;
}

//-----------------------------------------------------------------------------------------------------------
bool UserAnalysisOverlapRemovalTool::isExecuted() {
  *m_log << MSG::DEBUG << "in isExecuted() " << endreq;
  return m_storeGate->contains<INavigable4MomentumCollection>( m_outputObjectKey );
}

