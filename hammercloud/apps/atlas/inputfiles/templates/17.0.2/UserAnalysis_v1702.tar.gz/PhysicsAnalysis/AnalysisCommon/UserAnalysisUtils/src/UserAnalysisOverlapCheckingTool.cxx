/*****************************************************************************
Name    : UserAnalysisOverlapCheckingTool.cxx
Package : offline/PhysicsAnalysis/AnalysisCommon/UserAnalysisUtils
Author  : Ketevi A. Assamagan
Created : November 2007
Purpose : User Analysis Overlap Checking - see UserAnalysisOverlapCheckingTool.h for details
*****************************************************************************/

#include "GaudiKernel/MsgStream.h"
#include "GaudiKernel/GaudiException.h"
#include "GaudiKernel/Property.h"

// Accessing data:
#include "CLHEP/Units/PhysicalConstants.h"

// User Tools
#include "UserAnalysisUtils/UserAnalysisOverlapCheckingTool.h"

#include <sstream>
#include <iomanip>
#include <iostream>

using namespace Analysis;
using namespace Rec;
using namespace std;

//------------------------------------------------------------------------------
UserAnalysisOverlapCheckingTool::UserAnalysisOverlapCheckingTool( const std::string& type,
                                                                  const std::string& name, 
                                                                  const IInterface* parent )
  : AlgTool( type, name, parent ),
    m_analysisTools( "AnalysisTools", this ) {

  declareInterface<UserAnalysisOverlapCheckingTool>( this );

  declareProperty( "AnalysisTools", m_analysisTools );
  declareProperty("OverlapDeltaR",          m_deltaR=0.2);
  declareProperty("OverlapDeltaRWithJets",  m_deltaRWithJets=0.3);

}

//------------------------------------------------------------------------------
StatusCode UserAnalysisOverlapCheckingTool::initialize() {

  m_log = new MsgStream(msgSvc(), name());
  *m_log << MSG::DEBUG << "in initialize()" << endreq;
  m_debug = m_log->level() <= MSG::DEBUG;
  m_verbose = m_log->level() <= MSG::VERBOSE;

  /** get a handle of StoreGate for access to the Event Store */
  StatusCode sc = service("StoreGateSvc", m_storeGate);
  if (sc.isFailure()) {
     *m_log << MSG::ERROR
            << "Unable to retrieve pointer to StoreGateSvc"
            << endreq;
     return sc;
  }

  /// get a handle on the analysis tools
  sc = m_analysisTools.retrieve();
  if ( sc.isFailure() ) {
      *m_log << MSG::ERROR << "Can't get handle on analysis tools" << endreq;
      return sc;
  }

  return StatusCode::SUCCESS;
}

//------------------------------------------------------------------------------
StatusCode UserAnalysisOverlapCheckingTool::finalize() {

  if ( m_debug ) *m_log << MSG::DEBUG << "in finalize()" << endreq;
 
  delete m_log;

  return StatusCode::SUCCESS;
}

//------------------------------------------------------------------------------
UserAnalysisOverlapCheckingTool::~UserAnalysisOverlapCheckingTool()
{}



