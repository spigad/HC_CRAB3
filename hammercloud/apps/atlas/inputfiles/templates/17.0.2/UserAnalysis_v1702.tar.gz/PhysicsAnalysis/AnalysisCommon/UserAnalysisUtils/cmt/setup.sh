# echo "setup UserAnalysisUtils UserAnalysisUtils-02-02-08 in /data/etp1/elmsheus/athena/17.0.2/PhysicsAnalysis/AnalysisCommon"

if test "${CMTROOT}" = ""; then
  CMTROOT=/opt/atlas/software/manageTier3SW/ATLASLocalRootBase/Athena/i686_slc5_gcc43_opt/17.0.2/CMT/v1r23; export CMTROOT
fi
. ${CMTROOT}/mgr/setup.sh
cmtUserAnalysisUtilstempfile=`${CMTROOT}/mgr/cmt -quiet build temporary_name`
if test ! $? = 0 ; then cmtUserAnalysisUtilstempfile=/tmp/cmt.$$; fi
${CMTROOT}/mgr/cmt setup -sh -pack=UserAnalysisUtils -version=UserAnalysisUtils-02-02-08 -path=/data/etp1/elmsheus/athena/17.0.2/PhysicsAnalysis/AnalysisCommon  -quiet -without_version_directory -no_cleanup $* >${cmtUserAnalysisUtilstempfile}
if test $? != 0 ; then
  echo >&2 "${CMTROOT}/mgr/cmt setup -sh -pack=UserAnalysisUtils -version=UserAnalysisUtils-02-02-08 -path=/data/etp1/elmsheus/athena/17.0.2/PhysicsAnalysis/AnalysisCommon  -quiet -without_version_directory -no_cleanup $* >${cmtUserAnalysisUtilstempfile}"
  cmtsetupstatus=2
  /bin/rm -f ${cmtUserAnalysisUtilstempfile}
  unset cmtUserAnalysisUtilstempfile
  return $cmtsetupstatus
fi
cmtsetupstatus=0
. ${cmtUserAnalysisUtilstempfile}
if test $? != 0 ; then
  cmtsetupstatus=2
fi
/bin/rm -f ${cmtUserAnalysisUtilstempfile}
unset cmtUserAnalysisUtilstempfile
return $cmtsetupstatus

