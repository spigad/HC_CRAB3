/*****************************************************************************
Name    : UserAnalysisPreparationTool.cxx
Package : offline/PhysicsAnalysis/AnalysisCommon/UserAnalysisUtils
Author  : Ketevi A. Assamagan
Created : November 2007
Purpose : User Analysis Preparation - see UserAnalysisPreparationTool.h for details
*****************************************************************************/

#include "GaudiKernel/MsgStream.h"
#include "GaudiKernel/GaudiException.h"
#include "GaudiKernel/Property.h"

// Accessing data:
#include "CLHEP/Units/PhysicalConstants.h"

// User Tools
#include "UserAnalysisUtils/UserAnalysisPreparationTool.h"

#include <sstream>
#include <iomanip>
#include <iostream>

using namespace Analysis;
using namespace Rec;
using namespace std;

//------------------------------------------------------------------------------
UserAnalysisPreparationTool::UserAnalysisPreparationTool( const std::string& type,
                                                          const std::string& name, 
                                                          const IInterface* parent )
  : AlgTool( type, name, parent ),
    m_userSelectionTool ( "UserAnalysisSelectionTool" ) {

  declareInterface<UserAnalysisPreparationTool>( this );

  declareProperty("UserSelectionTool",      m_userSelectionTool);
  declareProperty("InputContainerKeys",     m_inputContainerKeys);
  declareProperty("OutputContainerKeys",    m_outputContainerKeys);
  declareProperty("IsAtlfastData",          m_isAtlfast=false);

  /** initialize counters */
  m_numElectrons      = std::make_pair(0,0);
  m_numPhotons        = std::make_pair(0,0);
  m_numMuons          = std::make_pair(0,0);
  m_numTauJets        = std::make_pair(0,0);
  m_numJets           = std::make_pair(0,0);
  m_numTrackParticles = std::make_pair(0,0);
  m_numCaloClusters   = std::make_pair(0,0);
  m_first             = true;
}

//------------------------------------------------------------------------------
StatusCode UserAnalysisPreparationTool::initialize() {

  m_log = new MsgStream(msgSvc(), name());
  *m_log << MSG::DEBUG << "in initialize()" << endreq;
  m_debug = m_log->level() <= MSG::DEBUG;
  m_verbose = m_log->level() <= MSG::VERBOSE;

  /** get a handle of StoreGate for access to the Event Store */
  StatusCode sc = service("StoreGateSvc", m_storeGate);
  if (sc.isFailure()) {
     *m_log << MSG::ERROR
            << "Unable to retrieve pointer to StoreGateSvc"
            << endreq;
     return sc;
  }

  /// get a handle on the selection tools
  sc = m_userSelectionTool.retrieve();
  if ( sc.isFailure() ) {
      *m_log << MSG::ERROR << "Can't get handle on analysis selection tool" << endreq;
      return sc;
  }

  return StatusCode::SUCCESS;
}

//------------------------------------------------------------------------------
StatusCode UserAnalysisPreparationTool::finalize() {

  if ( m_debug ) *m_log << MSG::DEBUG << "in finalize()" << endreq;
 
  this->summarize();

  delete m_log;

  return StatusCode::SUCCESS;
}

//------------------------------------------------------------------------------
UserAnalysisPreparationTool::~UserAnalysisPreparationTool()
{}

//-------------------------------------------------------------------------------
StatusCode UserAnalysisPreparationTool::execute() {
  if ( m_debug ) *m_log << MSG::DEBUG << "in execute()" << endreq;

  /** check that the input and the output containers are defined */
  StatusCode sc = StatusCode::SUCCESS;

  if ( m_first ) {
     if ( m_outputContainerKeys.size() != m_inputContainerKeys.size() ) {
        *m_log << MSG::FATAL << "Input/Output container mis-match: please fix job options" << endreq;
        return StatusCode::FAILURE;
     }
     if ( m_outputContainerKeys.size() == 0 ) {
        *m_log << MSG::ERROR << "You should input at least one container : please fix job options" << endreq;
        return StatusCode::FAILURE;
     }
  }

  /** now object preparation with selection */
  for ( unsigned int i=0; i<m_inputContainerKeys.size(); ++i ) {

    string::size_type loc = m_inputContainerKeys[i].find( "Electron", 0);
    if ( loc != string::npos ) { 
       if ( m_first ) m_outputElectronKey = m_outputContainerKeys[i]; 
       sc = this->electronPreparation( m_inputContainerKeys[i] );
    }

    loc = m_inputContainerKeys[i].find( "Photon", 0);
    if ( loc != string::npos ) {
       if ( m_first ) m_outputPhotonKey = m_outputContainerKeys[i];       
       sc = this->photonPreparation( m_inputContainerKeys[i] );
    }

    loc = m_inputContainerKeys[i].find( "Muon", 0);
    if ( loc != string::npos ) {
       if ( m_first ) m_outputMuonKey = m_outputContainerKeys[i];       
       sc = this->muonPreparation( m_inputContainerKeys[i] );
    }

    std::string tau = "Tau";
    if ( m_isAtlfast ) tau = "TauJet";
    loc = m_inputContainerKeys[i].find( tau, 0);
    if ( loc != string::npos ) { 
      if ( m_first ) m_outputTauJetKey = m_outputContainerKeys[i];
      sc = this->tauJetPreparation( m_inputContainerKeys[i] );
    }

    std::string jet = "Jets";
    if ( m_isAtlfast ) jet = "Jet";
    loc = m_inputContainerKeys[i].find( jet, 0);
    if ( loc != string::npos ) { 
       if ( m_first ) m_outputJetKey = m_outputContainerKeys[i];
       sc = this->jetPreparation( m_inputContainerKeys[i] );
    }

    loc = m_inputContainerKeys[i].find( "Track", 0);
    if ( loc != string::npos ) { 
       if ( m_first ) m_outputTrackParticleKey = m_outputContainerKeys[i]; 
       sc = this->trackParticlePreparation( m_inputContainerKeys[i] );
    }

    loc = m_inputContainerKeys[i].find( "Cluster", 0);
    if ( loc != string::npos ) { 
       if ( m_first ) m_outputCaloClusterKey = m_outputContainerKeys[i];
       sc = this->caloClusterPreparation( m_inputContainerKeys[i] );
    }
    if ( sc.isFailure() ) return sc;
  }

  if ( m_debug ) this->print();
  m_first = false;

  return StatusCode::SUCCESS;
}

//-------------------------------------------------------------------------------
const PhotonContainer * UserAnalysisPreparationTool::selectedPhotons() {
  if ( m_debug ) *m_log << MSG::DEBUG << "in selectedPhotons()" << endreq;
  const PhotonContainer * container = 0;
  StatusCode sc = m_storeGate->retrieve(container, m_outputPhotonKey);
  if ( sc.isFailure() || container ==0 )
     *m_log << MSG::ERROR << "Final State Photons not found" << endreq;
  return container;
}

const ElectronContainer * UserAnalysisPreparationTool::selectedElectrons() {
  if ( m_debug ) *m_log << MSG::DEBUG << "in selectedElectrons()" << endreq;
  const ElectronContainer * container = 0;
  StatusCode sc = m_storeGate->retrieve(container, m_outputElectronKey);
  if ( sc.isFailure() || container ==0 )
     *m_log << MSG::ERROR << "Final State Electrons not found" << endreq;
  return container;
}

const MuonContainer * UserAnalysisPreparationTool::selectedMuons() {
  if ( m_debug ) *m_log << MSG::DEBUG << "in selectedMuons()" << endreq;
  const MuonContainer * container = 0;
  StatusCode sc = m_storeGate->retrieve(container, m_outputMuonKey);
  if ( sc.isFailure() || container ==0 )
     *m_log << MSG::ERROR << "Final State Muons not found" << endreq;
  return container;
}

const TauJetContainer * UserAnalysisPreparationTool::selectedTauJets() {
  if ( m_debug ) *m_log << MSG::DEBUG << "in selectedTauJets()" << endreq;
  const TauJetContainer * container = 0;
  StatusCode sc = m_storeGate->retrieve(container, m_outputTauJetKey);
  if ( sc.isFailure() || container ==0 )
     *m_log << MSG::ERROR << "Final State TauJets not found" << endreq;
  return container;
}

const JetCollection * UserAnalysisPreparationTool::selectedJets() {
  if ( m_debug ) *m_log << MSG::DEBUG << "in selectedJets()" << endreq;
  const JetCollection * container = 0;
  StatusCode sc = m_storeGate->retrieve(container, m_outputJetKey);
  if ( sc.isFailure() || container ==0 )
     *m_log << MSG::ERROR << "Final State Jets not found" << endreq;
  return container;
}

const TrackParticleContainer * UserAnalysisPreparationTool::selectedTrackParticles() {
  if ( m_debug ) *m_log << MSG::DEBUG << "in selectedTrackParticles()" << endreq;
  const TrackParticleContainer * container = 0;
  StatusCode sc = m_storeGate->retrieve(container, m_outputTrackParticleKey);
  if ( sc.isFailure() || container ==0 )
     *m_log << MSG::ERROR << "Final State TrackParticles not found" << endreq;
  return container;
}

const CaloClusterContainer * UserAnalysisPreparationTool::selectedCaloClusters() {
  if ( m_debug ) *m_log << MSG::DEBUG << "in selectedCaloClusters()" << endreq;
  const CaloClusterContainer * container = 0;
  StatusCode sc = m_storeGate->retrieve(container, m_outputCaloClusterKey);
  if ( sc.isFailure() || container ==0 )
     *m_log << MSG::ERROR << "Final State CaloClusters not found" << endreq;
  return container;
}

  /** container preparation */
StatusCode UserAnalysisPreparationTool::electronPreparation( std::string key ) {
  if ( m_debug ) *m_log << MSG::DEBUG << "in electronPreparation() " << endreq;
  StatusCode sc = StatusCode::SUCCESS;

  /** create an empty container of all electrons and record it */
  ElectronContainer * electrons = new ElectronContainer( SG::VIEW_ELEMENTS );
  sc = m_storeGate->record ( electrons, m_outputElectronKey );
  if ( sc.isFailure() ) {
    *m_log << MSG::WARNING << "Not able to create a collection of electrons in StoreGate: key= " << m_outputElectronKey << endreq;
     return sc;
  }

  const ElectronContainer * aod_electrons = 0;
  sc = m_storeGate->retrieve( aod_electrons, key );
  if ( sc.isFailure() ) {
    *m_log << MSG::WARNING << "No ESD/AOD/DPD electron container found: key = " << key << endreq;
    return sc;
  }
  if ( m_debug ) *m_log << MSG::DEBUG << "AOD ElectronContainer size is " << aod_electrons->size() << endreq;
  m_numElectrons.first += aod_electrons->size();

  /// iterators over the container 
  ElectronContainer::const_iterator elecItr  = aod_electrons->begin();
  ElectronContainer::const_iterator elecItrE = aod_electrons->end();

  for (; elecItr != elecItrE; ++elecItr) {
    if ( m_userSelectionTool->isSelected( *elecItr ) ) electrons->push_back( *elecItr );
  }
  m_numElectrons.second += electrons->size();

  sc = m_storeGate->setConst( electrons );
  if ( sc.isFailure() ) *m_log << MSG::WARNING << "Not able to lock the container of electrons " << endreq;
  
  return sc;
}

StatusCode UserAnalysisPreparationTool::photonPreparation( std::string key ) {
  if ( m_debug ) *m_log << MSG::DEBUG << "in photonPreparation() " << endreq;
  StatusCode sc = StatusCode::SUCCESS;

  /** create an empty container of all photons and record it */
  PhotonContainer * photons = new PhotonContainer( SG::VIEW_ELEMENTS );
  sc = m_storeGate->record ( photons, m_outputPhotonKey );
  if ( sc.isFailure() ) {
    *m_log << MSG::WARNING << "Not able to create a collection of photons in StoreGate: key= " << m_outputPhotonKey << endreq;
     return sc;
  }

  const PhotonContainer * aod_photons = 0;
  sc = m_storeGate->retrieve( aod_photons, key );
  if ( sc.isFailure() ) {
    *m_log << MSG::WARNING << "No ESD/AOD/DPD photon container found: key = " << key << endreq;
    return sc;
  }
  if ( m_debug ) *m_log << MSG::DEBUG << "AOD PhotonContainer size is " << aod_photons->size() << endreq;
  m_numPhotons.first += aod_photons->size();

  /// iterators over the container 
  PhotonContainer::const_iterator photItr  = aod_photons->begin();
  PhotonContainer::const_iterator photItrE = aod_photons->end();

  /** check if this electron passes pre-selection */
  for (; photItr != photItrE; ++photItr) {
    if ( m_userSelectionTool->isSelected( *photItr ) ) photons->push_back( *photItr );
  }
  m_numPhotons.second += photons->size();

  sc = m_storeGate->setConst( photons );
  if ( sc.isFailure() ) *m_log << MSG::WARNING << "Not able to lock the container of photons " << endreq;

  return sc;
}

StatusCode UserAnalysisPreparationTool::muonPreparation( std::string key ) {
  if ( m_debug ) *m_log << MSG::DEBUG << "in muonPreparation() " << endreq;
  StatusCode sc = StatusCode::SUCCESS;

  /** create an empty container of all muons and record it */
  MuonContainer * muons = new MuonContainer( SG::VIEW_ELEMENTS );
  sc = m_storeGate->record ( muons, m_outputMuonKey );
  if ( sc.isFailure() ) {
    *m_log << MSG::WARNING << "Not able to create a collection of muons in StoreGate: key= " << m_outputMuonKey << endreq;
     return sc;
  }

  const MuonContainer * aod_muons = 0;
  sc = m_storeGate->retrieve( aod_muons, key );
  if ( sc.isFailure() ) {
    *m_log << MSG::WARNING << "No ESD/AOD/DPD muon container found: key = " << key << endreq;
    return sc; 
  }
  if ( m_debug ) *m_log << MSG::DEBUG << "AOD MuonContainer size is " << aod_muons->size() << endreq;
  m_numMuons.first += aod_muons->size();

  /// iterators over the container 
  MuonContainer::const_iterator muonItr  = aod_muons->begin();
  MuonContainer::const_iterator muonItrE = aod_muons->end();

  /** check if this muon passes pre-selection */
  for (; muonItr != muonItrE; ++muonItr) {
    if ( m_userSelectionTool->isSelected( *muonItr ) ) muons->push_back( *muonItr );
  }  
  m_numMuons.second += muons->size();

  sc = m_storeGate->setConst( muons );
  if ( sc.isFailure() ) *m_log << MSG::WARNING << "Not able to lock the container of muons " << endreq;

  return sc;
}

StatusCode UserAnalysisPreparationTool::tauJetPreparation( std::string key ) {
  if ( m_debug ) *m_log << MSG::DEBUG << "in tauJetPreparation() " << endreq;
  StatusCode sc = StatusCode::SUCCESS;

  /** create an empty container of all tauJets and record it */
  TauJetContainer * tauJets = new TauJetContainer( SG::VIEW_ELEMENTS );
  sc = m_storeGate->record ( tauJets, m_outputTauJetKey );
  if ( sc.isFailure() ) {
    *m_log << MSG::WARNING << "Not able to create a collection of tau jets in StoreGate: key= " << m_outputTauJetKey << endreq;
     return sc;
  }

  const TauJetContainer * aod_tauJets = 0;
  sc = m_storeGate->retrieve( aod_tauJets, key );
  if ( sc.isFailure() ) {
    *m_log << MSG::WARNING << "No ESD/AOD/DPD tauJet container found: key = " << key << endreq;
    return sc;
  }
  if ( m_debug ) *m_log << MSG::DEBUG << "AOD TauJetContainer size is " << aod_tauJets->size() << endreq;
  m_numTauJets.first += aod_tauJets->size();

  /// iterators over the container 
  TauJetContainer::const_iterator tauJetItr  = aod_tauJets->begin();
  TauJetContainer::const_iterator tauJetItrE = aod_tauJets->end();

  /** check if this tauJet passes pre-selection */
  for (; tauJetItr != tauJetItrE; ++tauJetItr) {
    if ( m_userSelectionTool->isSelected( *tauJetItr ) ) tauJets->push_back( *tauJetItr );
  }
  m_numTauJets.second += tauJets->size();

  sc = m_storeGate->setConst( tauJets );
  if ( sc.isFailure() ) *m_log << MSG::WARNING << "Not able to lock the container of tauJets " << endreq;

  return sc;
}

StatusCode UserAnalysisPreparationTool::jetPreparation( std::string key ) {
  if ( m_debug ) *m_log << MSG::DEBUG << "in jetPreparation() " << endreq;
  StatusCode sc = StatusCode::SUCCESS;

  /** create an empty container of all jets and record it */
  JetCollection * jets = new JetCollection( SG::VIEW_ELEMENTS );
  sc = m_storeGate->record ( jets, m_outputJetKey );
  if ( sc.isFailure() ) {
    *m_log << MSG::WARNING << "Not able to create a collection of jets in StoreGate: key= " << m_outputJetKey << endreq;
     return sc;
  }

  const JetCollection * aod_jets = 0;
  sc = m_storeGate->retrieve( aod_jets, key );
  if ( sc.isFailure() ) {
    *m_log << MSG::WARNING << "No ESD/AOD/DPD jet container found: key = " << key << endreq;
    return sc;
  }
  if ( m_debug ) *m_log << MSG::DEBUG << "AOD JetCollection size is " << aod_jets->size() << endreq;
  m_numJets.first      += aod_jets->size();

  /// iterators over the container 
  JetCollection::const_iterator jetItr  = aod_jets->begin();
  JetCollection::const_iterator jetItrE = aod_jets->end();

  /** check if this jet passes pre-selection */
  for (; jetItr != jetItrE; ++jetItr) {
    if ( m_userSelectionTool->isSelected( *jetItr ) ) jets->push_back( *jetItr );
  }
  m_numJets.second      += jets->size();

  sc = m_storeGate->setConst( jets );
  if ( sc.isFailure() ) *m_log << MSG::WARNING << "Not able to lock the container of jets " << endreq;

  return sc;
}

StatusCode UserAnalysisPreparationTool::trackParticlePreparation( std::string key ) {
  if ( m_debug ) *m_log << MSG::DEBUG << "in trackParticlePreparation() " << endreq;
  StatusCode sc = StatusCode::SUCCESS;

  /** create an empty container of TrackParticles and record it */
  TrackParticleContainer * trackParticles = new TrackParticleContainer( SG::VIEW_ELEMENTS );
  sc = m_storeGate->record ( trackParticles, m_outputTrackParticleKey );
  if ( sc.isFailure() ) {
    *m_log << MSG::WARNING << "Not able to create a collection of TrackParticles in StoreGate: key= " << m_outputTrackParticleKey << endreq;
     return sc;
  }

  const TrackParticleContainer * aod_trackParticles = 0;
  sc = m_storeGate->retrieve( aod_trackParticles, key );
  if ( sc.isFailure() ) {
    *m_log << MSG::WARNING << "No ESD/AOD/DPD trackParticle container found: key = " << key << endreq;
    return sc;
  }
  if ( m_debug ) *m_log << MSG::DEBUG << "AOD TrackParticleContainer size is " << aod_trackParticles->size() << endreq;
  m_numTrackParticles.first += aod_trackParticles->size();

  /// iterators over the container 
  TrackParticleContainer::const_iterator trackParticleItr  = aod_trackParticles->begin();
  TrackParticleContainer::const_iterator trackParticleItrE = aod_trackParticles->end();

  /** check if this trackParticle passes pre-selection */
  for (; trackParticleItr != trackParticleItrE; ++trackParticleItr) {
    if ( m_userSelectionTool->isSelected( *trackParticleItr ) ) trackParticles->push_back( *trackParticleItr );
  }
  m_numTrackParticles.second += trackParticles->size();

  sc = m_storeGate->setConst( trackParticles );
  if ( sc.isFailure() ) *m_log << MSG::WARNING << "Not able to lock the container of trackParticles " << endreq;

  return sc;
}

StatusCode UserAnalysisPreparationTool::caloClusterPreparation( std::string key ) {
  if ( m_debug ) *m_log << MSG::DEBUG << "in caloClusterPreparation() " << endreq;

  /** create an empty container of all particles and record it */
  CaloClusterContainer * caloClusters = new CaloClusterContainer( SG::VIEW_ELEMENTS );
  StatusCode sc = m_storeGate->record ( caloClusters, m_outputCaloClusterKey );
  if ( sc.isFailure() ) {
    *m_log << MSG::WARNING << "Not able to create a collection of CaloClusters in StoreGate: key= " << m_outputCaloClusterKey << endreq;
     return sc;
  }

  const CaloClusterContainer * aod_caloClusters = 0;
  sc = m_storeGate->retrieve( aod_caloClusters, key );
  if ( sc.isFailure() ) {
    *m_log << MSG::WARNING << "No ESD/AOD/DPD caloCluster container found: key = " << key << endreq;
    return sc;
  }
  if ( m_debug ) *m_log << MSG::DEBUG << "AOD CaloClusterContainer size is " << aod_caloClusters->size() << endreq;
  m_numCaloClusters.first += aod_caloClusters->size();

  /// iterators over the container 
  CaloClusterContainer::const_iterator caloClusterItr  = aod_caloClusters->begin();
  CaloClusterContainer::const_iterator caloClusterItrE = aod_caloClusters->end();

  /** check if this caloCluster passes pre-selection */
  for (; caloClusterItr != caloClusterItrE; ++caloClusterItr) {
    if ( m_userSelectionTool->isSelected( *caloClusterItr ) ) caloClusters->push_back( *caloClusterItr );
  }
  m_numCaloClusters.second += caloClusters->size();

  sc = m_storeGate->setConst( caloClusters );
  if ( sc.isFailure() ) *m_log << MSG::WARNING << "Not able to lock the container of calo clusters " << endreq;

  return sc;
}

//-----------------------------------------------------------------------------------------------
void UserAnalysisPreparationTool::print() {
  *m_log << MSG::DEBUG << "in print() " << endreq;

  /** Get the container of pre-selected Electrons */
  const ElectronContainer * electrons = this->selectedElectrons();
  if(electrons) *m_log << MSG::DEBUG << "Number of Pre-selected Electrons is " << electrons->size() << endreq;

  /** Get the container of pre-selected Photons */
  const PhotonContainer * photons = this->selectedPhotons();
  if(photons) *m_log << MSG::DEBUG << "Number of Pre-selected Photons is " << photons->size() << endreq;

  /** Get the container of pre-selected Muons */
  const MuonContainer * muons = this->selectedMuons();
  if(muons)*m_log << MSG::DEBUG << "Number of Pre-selected Muons is " << muons->size() << endreq;

  /** Get the container of pre-selected TauJets */
  const TauJetContainer * tauJets = this->selectedTauJets();
  if(tauJets) *m_log << MSG::DEBUG << "Number of Pre-selected TauJets is " << tauJets->size() << endreq;

  /** Get the container of pre-selected Jets */
  const JetCollection * jets = this->selectedJets();
  if(jets) *m_log << MSG::DEBUG << "Number of Pre-selected Jets is " << jets->size() << endreq;

  /** Get the container of pre-selected TrackParticles */
  const TrackParticleContainer * trackParticles = this->selectedTrackParticles();
  if(trackParticles) *m_log << MSG::DEBUG << "Number of Pre-selected TrackParticles is " << trackParticles->size() << endreq;

  /** Get the container of pre-selected CaloClusters */
  const CaloClusterContainer * caloClusters = this->selectedCaloClusters();
  if(caloClusters) *m_log << MSG::DEBUG << "Number of Pre-selected CaloClusters is " << caloClusters->size() << endreq;

}

//---------------------------------------------------------------------------------------------------------
void UserAnalysisPreparationTool::summarize() {
  *m_log << MSG::INFO << "in summarize() " << endreq;

  *m_log << MSG::INFO << "Summary of Reconstructed Events/pre-selected events ############" << endreq;
  *m_log << MSG::INFO << "---------------------------------------------------------------" << endreq;
  *m_log << MSG::INFO << "Reconstructed Electrons        = " << std::setw(10) << m_numElectrons.first 
                      << "   Pre-selected Electrons      = " << std::setw(10) << m_numElectrons.second << endreq;
  *m_log << MSG::INFO << "Reconstructed Photons          = " << std::setw(10) << m_numPhotons.first 
                      << "   Pre-selected Photons        = " << std::setw(10) << m_numPhotons.second << endreq;
  *m_log << MSG::INFO << "Reconstructed Muons            = " << std::setw(10) << m_numMuons.first 
                      << "   Pre-selected Muons          = " << std::setw(10) << m_numMuons.second << endreq;
  *m_log << MSG::INFO << "Reconstructed TauJets          = " << std::setw(10) << m_numTauJets.first  
                      << "   Pre-selected TauJets        = " << std::setw(10) << m_numTauJets.second << endreq;
  *m_log << MSG::INFO << "Reconstructed Jets             = " << std::setw(10) << m_numJets.first 
                      << "   Pre-selected Jets           = " << std::setw(10) << m_numJets.second << endreq;
  *m_log << MSG::INFO << "Reconstructed TrackParticles   = " << std::setw(10) << m_numTrackParticles.first
                      << "   Pre-selected TrackParticles = " << std::setw(10) << m_numTrackParticles.second << endreq;
  *m_log << MSG::INFO << "Reconstructed CaloClusters     = " << std::setw(10) << m_numCaloClusters.first
                      << "   Pre-selected CaloClusters   = " << std::setw(10) << m_numCaloClusters.second << endreq;
}


