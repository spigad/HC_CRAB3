// dear emacs, this is -*- C++ -*-

#include "egammaEvent/egammaParamDefs.h"
#include "egammaEvent/egammaPIDdefs.h"
#include "egammaEvent/EMAmbiguityToolDefs.h"
