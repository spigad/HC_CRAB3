#ifdef __CINT__

#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;
#pragma link C++ nestedclass;

#include "egammaEvent/egammaPIDdefs.h"
#pragma link C++ defined_in "egammaEvent/egammaPIDdefs.h";

#endif
