export ROOTCOREGRID=1 && $1/RootCore/scripts/grid_compile_config.sh $1 && source $1/RootCore/scripts/setup.sh && $ROOTCOREDIR/scripts/compile.sh
