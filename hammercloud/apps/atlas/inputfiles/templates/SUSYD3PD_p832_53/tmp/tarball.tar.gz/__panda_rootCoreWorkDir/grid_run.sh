export ROOTCOREGRID=1 && $1/RootCore/scripts/grid_run_config.sh $1 && source $1/RootCore/scripts/setup.sh
