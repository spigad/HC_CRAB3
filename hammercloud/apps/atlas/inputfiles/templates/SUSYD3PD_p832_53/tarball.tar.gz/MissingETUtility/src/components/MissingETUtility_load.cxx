//
//    Load file for ATHENA
//



#include "GaudiKernel/LoadFactoryEntries.h"

LOAD_FACTORY_ENTRIES(MissingETUtility)
