# Add the top algorithm to be run 
from AthenaCommon.AlgSequence import AlgSequence,AthSequencer
job = AlgSequence()
job += AthSequencer("ModSequence1")

# Uncomment the following lines to use the GRL selection
# Make sure that the xml filename, and the name of the GRL are correctly defined.
#from GoodRunsLists.GoodRunsListsConf import *
#ToolSvc += GoodRunsListSelectorTool()
#GoodRunsListSelectorTool.GoodRunsListVec = [ 'data10_7TeV.periodB.153565-155160_LBSUMM_DetStatus-v03-repro04-01_data-all_7TeV.xml' ]
#from GoodRunsListsUser.GoodRunsListsUserConf import *
#job.ModSequence1 += GRLTriggerSelectorAlg('GRLTriggerAlg1')
#job.ModSequence1.GRLTriggerAlg1.GoodRunsListArray = ['all_7TeV']


from AthExRegTutorial.AthExRegTutorialConf import SimpleAnalysisSkeleton
job.ModSequence1 += SimpleAnalysisSkeleton( "SimpleAnalysisSkeleton" )

# User's input parameters
job.ModSequence1.SimpleAnalysisSkeleton.muonContainerName = "MuidMuonCollection"
job.ModSequence1.SimpleAnalysisSkeleton.muonPtCut = 2000.0
job.ModSequence1.SimpleAnalysisSkeleton.muonEtaCut = 2.7
job.ModSequence1.SimpleAnalysisSkeleton.muonMass = 105.66


# Set output level threshold (2=DEBUG, 3=INFO, 4=WARNING, 5=ERROR, 6=FATAL )
job.ModSequence1.SimpleAnalysisSkeleton.OutputLevel = INFO

# produce ROOT ntuple using THistSvc
from AthenaCommon.AppMgr import ServiceMgr
if not hasattr(ServiceMgr, 'THistSvc'):
  from GaudiSvc.GaudiSvcConf import THistSvc
  ServiceMgr += THistSvc()
ServiceMgr.THistSvc.Output+=[ "ATHEXREGTUTORIAL DATAFILE='AnalysisSkeleton.root' OPT='RECREATE'"]
