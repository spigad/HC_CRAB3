#include "AthExRegTutorial/SimpleAnalysisSkeleton.h"

#include "GaudiKernel/DeclareFactoryEntries.h"

DECLARE_ALGORITHM_FACTORY( SimpleAnalysisSkeleton )

DECLARE_FACTORY_ENTRIES( AthExRegTutorial ) {
  DECLARE_ALGORITHM( SimpleAnalysisSkeleton )
}

