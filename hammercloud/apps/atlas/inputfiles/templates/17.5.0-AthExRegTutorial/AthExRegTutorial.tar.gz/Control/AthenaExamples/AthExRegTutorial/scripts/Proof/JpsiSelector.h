//////////////////////////////////////////////////////////
// This class has been automatically generated on
// Wed Oct 13 17:17:37 2010 by ROOT version 5.26/00d
// from TTree JPSI/JPSI
// found on file: /afs/cern.ch/atlas/maxidisk/d36/proofInput/file_00002.ntuple.root
//////////////////////////////////////////////////////////

#ifndef JpsiSelector_h
#define JpsiSelector_h

#include <TROOT.h>
#include <TChain.h>
#include <TFile.h>
#include <TSelector.h>
#include "TH1F.h"
#include <vector>
#include "TTree.h"
#include "TFile.h"
#include "TProofOutputFile.h"
#include "TString.h"
#include "TObjArray.h"
#include "TSystem.h"
#include <iostream>
#include "TCanvas.h"

using namespace std;

class JpsiSelector : public TSelector {
public :
   TTree          *fChain;   //!pointer to the analyzed TTree or TChain

   // Declaration of leaf types
   Int_t           JPSI_eventNumber;
   Int_t           JPSI_lumiBlock;
   Int_t           JPSI_runNumber;
   vector<double>  *JPSI_PV_X;
   vector<double>  *JPSI_PV_Y;
   vector<double>  *JPSI_PV_Z;
   vector<string>  *JPSI_label;
   vector<int>     *JPSI_PV_type;
   vector<int>     *JPSI_PV_index;
   Double_t        JPSI_TRUEPV_X;
   Double_t        JPSI_TRUEPV_Y;
   Double_t        JPSI_TRUEPV_Z;
   Int_t           JPSI_charge;
   Bool_t          JPSI_isSignal;
   Double_t        JPSI_VTX_pt;
   Double_t        JPSI_VTX_ptError;
   Int_t           JPSI_index;
   Double_t        JPSI_VTX_xposition;
   Double_t        JPSI_VTX_yposition;
   Double_t        JPSI_VTX_zposition;
   Double_t        JPSI_VTX_xxPosCov;
   Double_t        JPSI_VTX_xyPosCov;
   Double_t        JPSI_VTX_xzPosCov;
   Double_t        JPSI_VTX_yyPosCov;
   Double_t        JPSI_VTX_yzPosCov;
   Double_t        JPSI_VTX_zzPosCov;
   Double_t        JPSI_VTX_chi2;
   Int_t           JPSI_VTX_NDF;
   Double_t        JPSI_VTX_mass;
   Double_t        JPSI_VTX_massError;
   Double_t        JPSI_VTX_px;
   Double_t        JPSI_VTX_py;
   Double_t        JPSI_VTX_pz;
   Double_t        JPSI_VTX_pxMassHyp;
   Double_t        JPSI_VTX_pyMassHyp;
   Double_t        JPSI_VTX_pzMassHyp;
   Double_t        JPSI_VTX_rapidity;
   Double_t        JPSI_VTX_thetaStar;
   Double_t        JPSI_VTX_cosThetaStar;
   Double_t        JPSI_VTX_phiStar;
   vector<double>  *JPSI_VTX_refTrksPx;
   vector<double>  *JPSI_VTX_refTrksPy;
   vector<double>  *JPSI_VTX_refTrksPz;
   vector<double>  *JPSI_VTX_lxy;
   vector<double>  *JPSI_VTX_lxyError;
   vector<double>  *JPSI_VTX_tau;
   vector<double>  *JPSI_VTX_tauError;
   vector<double>  *JPSI_VTX_tauMassHyp;
   vector<double>  *JPSI_VTX_tauErrorMassHyp;
   vector<double>  *JPSI_VTX_tauCorrected;
   vector<double>  *JPSI_VTX_tauErrorCorrected;
   vector<double>  *JPSI_VTX_cosTheta;
   vector<double>  *JPSI_VTX_cosThetaXY;
   vector<double>  *JPSI_VTX_massTauCov;
   vector<double>  *JPSI_VTX_refPVx;
   vector<double>  *JPSI_VTX_refPVy;
   vector<double>  *JPSI_VTX_refPVz;
   vector<double>  *JPSI_TRKS_px;
   vector<double>  *JPSI_TRKS_py;
   vector<double>  *JPSI_TRKS_pz;
   vector<double>  *JPSI_TRKS_d0;
   vector<double>  *JPSI_TRKS_z0;
   vector<int>     *JPSI_TRKS_index;
   vector<double>  *JPSI_TRUE_TRKS_px;
   vector<double>  *JPSI_TRUE_TRKS_py;
   vector<double>  *JPSI_TRUE_TRKS_pz;
   vector<double>  *JPSI_TRUE_TRKS_e;
   vector<double>  *JPSI_MUONS_pt;
   vector<double>  *JPSI_MUONS_eta;
   vector<int>     *JPSI_MUONS_index;
   Double_t        JPSI_TRUTH_px;
   Double_t        JPSI_TRUTH_py;
   Double_t        JPSI_TRUTH_pz;
   Double_t        JPSI_TRUTH_e;
   Int_t           JPSI_TRUTH_pdgID;
   Double_t        JPSI_TRUTH_vtxX;
   Double_t        JPSI_TRUTH_vtxY;
   Double_t        JPSI_TRUTH_vtxZ;

   // List of branches
   TBranch        *b_JPSI_eventNumber;   //!
   TBranch        *b_JPSI_lumiBlock;   //!
   TBranch        *b_JPSI_runNumber;   //!
   TBranch        *b_JPSI_PV_X;   //!
   TBranch        *b_JPSI_PV_Y;   //!
   TBranch        *b_JPSI_PV_Z;   //!
   TBranch        *b_JPSI_label;   //!
   TBranch        *b_JPSI_PV_type;   //!
   TBranch        *b_JPSI_PV_index;   //!
   TBranch        *b_JPSI_TRUEPV_X;   //!
   TBranch        *b_JPSI_TRUEPV_Y;   //!
   TBranch        *b_JPSI_TRUEPV_Z;   //!
   TBranch        *b_JPSI_charge;   //!
   TBranch        *b_JPSI_isSignal;   //!
   TBranch        *b_JPSI_VTX_pt;   //!
   TBranch        *b_JPSI_VTX_ptError;   //!
   TBranch        *b_JPSI_index;   //!
   TBranch        *b_JPSI_VTX_xposition;   //!
   TBranch        *b_JPSI_VTX_yposition;   //!
   TBranch        *b_JPSI_VTX_zposition;   //!
   TBranch        *b_JPSI_VTX_xxPosCov;   //!
   TBranch        *b_JPSI_VTX_xyPosCov;   //!
   TBranch        *b_JPSI_VTX_xzPosCov;   //!
   TBranch        *b_JPSI_VTX_yyPosCov;   //!
   TBranch        *b_JPSI_VTX_yzPosCov;   //!
   TBranch        *b_JPSI_VTX_zzPosCov;   //!
   TBranch        *b_JPSI_VTX_chi2;   //!
   TBranch        *b_JPSI_VTX_NDF;   //!
   TBranch        *b_JPSI_VTX_mass;   //!
   TBranch        *b_JPSI_VTX_massError;   //!
   TBranch        *b_JPSI_VTX_px;   //!
   TBranch        *b_JPSI_VTX_py;   //!
   TBranch        *b_JPSI_VTX_pz;   //!
   TBranch        *b_JPSI_VTX_pxMassHyp;   //!
   TBranch        *b_JPSI_VTX_pyMassHyp;   //!
   TBranch        *b_JPSI_VTX_pzMassHyp;   //!
   TBranch        *b_JPSI_VTX_rapidity;   //!
   TBranch        *b_JPSI_VTX_thetaStar;   //!
   TBranch        *b_JPSI_VTX_cosThetaStar;   //!
   TBranch        *b_JPSI_VTX_phiStar;   //!
   TBranch        *b_JPSI_VTX_refTrksPx;   //!
   TBranch        *b_JPSI_VTX_refTrksPy;   //!
   TBranch        *b_JPSI_VTX_refTrksPz;   //!
   TBranch        *b_JPSI_VTX_lxy;   //!
   TBranch        *b_JPSI_VTX_lxyError;   //!
   TBranch        *b_JPSI_VTX_tau;   //!
   TBranch        *b_JPSI_VTX_tauError;   //!
   TBranch        *b_JPSI_VTX_tauMassHyp;   //!
   TBranch        *b_JPSI_VTX_tauErrorMassHyp;   //!
   TBranch        *b_JPSI_VTX_tauCorrected;   //!
   TBranch        *b_JPSI_VTX_tauErrorCorrected;   //!
   TBranch        *b_JPSI_VTX_cosTheta;   //!
   TBranch        *b_JPSI_VTX_cosThetaXY;   //!
   TBranch        *b_JPSI_VTX_massTauCov;   //!
   TBranch        *b_JPSI_VTX_refPVx;   //!
   TBranch        *b_JPSI_VTX_refPVy;   //!
   TBranch        *b_JPSI_VTX_refPVz;   //!
   TBranch        *b_JPSI_TRKS_px;   //!
   TBranch        *b_JPSI_TRKS_py;   //!
   TBranch        *b_JPSI_TRKS_pz;   //!
   TBranch        *b_JPSI_TRKS_d0;   //!
   TBranch        *b_JPSI_TRKS_z0;   //!
   TBranch        *b_JPSI_TRKS_index;   //!
   TBranch        *b_JPSI_TRUE_TRKS_px;   //!
   TBranch        *b_JPSI_TRUE_TRKS_py;   //!
   TBranch        *b_JPSI_TRUE_TRKS_pz;   //!
   TBranch        *b_JPSI_TRUE_TRKS_e;   //!
   TBranch        *b_JPSI_MUONS_pt;   //!
   TBranch        *b_JPSI_MUONS_eta;   //!
   TBranch        *b_JPSI_MUONS_index;   //!
   TBranch        *b_JPSI_TRUTH_px;   //!
   TBranch        *b_JPSI_TRUTH_py;   //!
   TBranch        *b_JPSI_TRUTH_pz;   //!
   TBranch        *b_JPSI_TRUTH_e;   //!
   TBranch        *b_JPSI_TRUTH_pdgID;   //!
   TBranch        *b_JPSI_TRUTH_vtxX;   //!
   TBranch        *b_JPSI_TRUTH_vtxY;   //!
   TBranch        *b_JPSI_TRUTH_vtxZ;   //!

   JpsiSelector(TTree * /*tree*/ =0) { }
   virtual ~JpsiSelector() { }
   virtual Int_t   Version() const { return 2; }
   virtual void    Begin(TTree *tree);
   virtual void    SlaveBegin(TTree *tree);
   virtual void    Init(TTree *tree);
   virtual Bool_t  Notify();
   virtual Bool_t  Process(Long64_t entry);
   virtual Int_t   GetEntry(Long64_t entry, Int_t getall = 0) { return fChain ? fChain->GetTree()->GetEntry(entry, getall) : 0; }
   virtual void    SetOption(const char *option) { fOption = option; }
   virtual void    SetObject(TObject *obj) { fObject = obj; }
   virtual void    SetInputList(TList *input) { fInput = input; }
   virtual TList  *GetOutputList() const { return fOutput; }
   virtual void    SlaveTerminate();
   virtual void    Terminate();
  // user histograms, etc...  
  TH1F *hJpsiMass;;
  TH1F *hMuPosPt;

  // for the tree
  TProofOutputFile * fProofFile;
  TFile *fFile;
  TTree * trJpsi;

   ClassDef(JpsiSelector,0);
};

#endif

#ifdef JpsiSelector_cxx
void JpsiSelector::Init(TTree *tree)
{
   // The Init() function is called when the selector needs to initialize
   // a new tree or chain. Typically here the branch addresses and branch
   // pointers of the tree will be set.
   // It is normally not necessary to make changes to the generated
   // code, but the routine can be extended by the user if needed.
   // Init() will be called many times when running on PROOF
   // (once per file to be processed).

   // Set object pointer
   JPSI_PV_X = 0;
   JPSI_PV_Y = 0;
   JPSI_PV_Z = 0;
   JPSI_label = 0;
   JPSI_PV_type = 0;
   JPSI_PV_index = 0;
   JPSI_VTX_refTrksPx = 0;
   JPSI_VTX_refTrksPy = 0;
   JPSI_VTX_refTrksPz = 0;
   JPSI_VTX_lxy = 0;
   JPSI_VTX_lxyError = 0;
   JPSI_VTX_tau = 0;
   JPSI_VTX_tauError = 0;
   JPSI_VTX_tauMassHyp = 0;
   JPSI_VTX_tauErrorMassHyp = 0;
   JPSI_VTX_tauCorrected = 0;
   JPSI_VTX_tauErrorCorrected = 0;
   JPSI_VTX_cosTheta = 0;
   JPSI_VTX_cosThetaXY = 0;
   JPSI_VTX_massTauCov = 0;
   JPSI_VTX_refPVx = 0;
   JPSI_VTX_refPVy = 0;
   JPSI_VTX_refPVz = 0;
   JPSI_TRKS_px = 0;
   JPSI_TRKS_py = 0;
   JPSI_TRKS_pz = 0;
   JPSI_TRKS_d0 = 0;
   JPSI_TRKS_z0 = 0;
   JPSI_TRKS_index = 0;
   JPSI_TRUE_TRKS_px = 0;
   JPSI_TRUE_TRKS_py = 0;
   JPSI_TRUE_TRKS_pz = 0;
   JPSI_TRUE_TRKS_e = 0;
   JPSI_MUONS_pt = 0;
   JPSI_MUONS_eta = 0;
   JPSI_MUONS_index = 0;
   // Set branch addresses and branch pointers
   if (!tree) return;
   fChain = tree;
   fChain->SetMakeClass(1);

   fChain->SetBranchAddress("JPSI_eventNumber", &JPSI_eventNumber, &b_JPSI_eventNumber);
   fChain->SetBranchAddress("JPSI_lumiBlock", &JPSI_lumiBlock, &b_JPSI_lumiBlock);
   fChain->SetBranchAddress("JPSI_runNumber", &JPSI_runNumber, &b_JPSI_runNumber);
   fChain->SetBranchAddress("JPSI_PV_X", &JPSI_PV_X, &b_JPSI_PV_X);
   fChain->SetBranchAddress("JPSI_PV_Y", &JPSI_PV_Y, &b_JPSI_PV_Y);
   fChain->SetBranchAddress("JPSI_PV_Z", &JPSI_PV_Z, &b_JPSI_PV_Z);
   fChain->SetBranchAddress("JPSI_label", &JPSI_label, &b_JPSI_label);
   fChain->SetBranchAddress("JPSI_PV_type", &JPSI_PV_type, &b_JPSI_PV_type);
   fChain->SetBranchAddress("JPSI_PV_index", &JPSI_PV_index, &b_JPSI_PV_index);
   fChain->SetBranchAddress("JPSI_TRUEPV_X", &JPSI_TRUEPV_X, &b_JPSI_TRUEPV_X);
   fChain->SetBranchAddress("JPSI_TRUEPV_Y", &JPSI_TRUEPV_Y, &b_JPSI_TRUEPV_Y);
   fChain->SetBranchAddress("JPSI_TRUEPV_Z", &JPSI_TRUEPV_Z, &b_JPSI_TRUEPV_Z);
   fChain->SetBranchAddress("JPSI_charge", &JPSI_charge, &b_JPSI_charge);
   fChain->SetBranchAddress("JPSI_isSignal", &JPSI_isSignal, &b_JPSI_isSignal);
   fChain->SetBranchAddress("JPSI_VTX_pt", &JPSI_VTX_pt, &b_JPSI_VTX_pt);
   fChain->SetBranchAddress("JPSI_VTX_ptError", &JPSI_VTX_ptError, &b_JPSI_VTX_ptError);
   fChain->SetBranchAddress("JPSI_index", &JPSI_index, &b_JPSI_index);
   fChain->SetBranchAddress("JPSI_VTX_xposition", &JPSI_VTX_xposition, &b_JPSI_VTX_xposition);
   fChain->SetBranchAddress("JPSI_VTX_yposition", &JPSI_VTX_yposition, &b_JPSI_VTX_yposition);
   fChain->SetBranchAddress("JPSI_VTX_zposition", &JPSI_VTX_zposition, &b_JPSI_VTX_zposition);
   fChain->SetBranchAddress("JPSI_VTX_xxPosCov", &JPSI_VTX_xxPosCov, &b_JPSI_VTX_xxPosCov);
   fChain->SetBranchAddress("JPSI_VTX_xyPosCov", &JPSI_VTX_xyPosCov, &b_JPSI_VTX_xyPosCov);
   fChain->SetBranchAddress("JPSI_VTX_xzPosCov", &JPSI_VTX_xzPosCov, &b_JPSI_VTX_xzPosCov);
   fChain->SetBranchAddress("JPSI_VTX_yyPosCov", &JPSI_VTX_yyPosCov, &b_JPSI_VTX_yyPosCov);
   fChain->SetBranchAddress("JPSI_VTX_yzPosCov", &JPSI_VTX_yzPosCov, &b_JPSI_VTX_yzPosCov);
   fChain->SetBranchAddress("JPSI_VTX_zzPosCov", &JPSI_VTX_zzPosCov, &b_JPSI_VTX_zzPosCov);
   fChain->SetBranchAddress("JPSI_VTX_chi2", &JPSI_VTX_chi2, &b_JPSI_VTX_chi2);
   fChain->SetBranchAddress("JPSI_VTX_NDF", &JPSI_VTX_NDF, &b_JPSI_VTX_NDF);
   fChain->SetBranchAddress("JPSI_VTX_mass", &JPSI_VTX_mass, &b_JPSI_VTX_mass);
   fChain->SetBranchAddress("JPSI_VTX_massError", &JPSI_VTX_massError, &b_JPSI_VTX_massError);
   fChain->SetBranchAddress("JPSI_VTX_px", &JPSI_VTX_px, &b_JPSI_VTX_px);
   fChain->SetBranchAddress("JPSI_VTX_py", &JPSI_VTX_py, &b_JPSI_VTX_py);
   fChain->SetBranchAddress("JPSI_VTX_pz", &JPSI_VTX_pz, &b_JPSI_VTX_pz);
   fChain->SetBranchAddress("JPSI_VTX_pxMassHyp", &JPSI_VTX_pxMassHyp, &b_JPSI_VTX_pxMassHyp);
   fChain->SetBranchAddress("JPSI_VTX_pyMassHyp", &JPSI_VTX_pyMassHyp, &b_JPSI_VTX_pyMassHyp);
   fChain->SetBranchAddress("JPSI_VTX_pzMassHyp", &JPSI_VTX_pzMassHyp, &b_JPSI_VTX_pzMassHyp);
   fChain->SetBranchAddress("JPSI_VTX_rapidity", &JPSI_VTX_rapidity, &b_JPSI_VTX_rapidity);
   fChain->SetBranchAddress("JPSI_VTX_thetaStar", &JPSI_VTX_thetaStar, &b_JPSI_VTX_thetaStar);
   fChain->SetBranchAddress("JPSI_VTX_cosThetaStar", &JPSI_VTX_cosThetaStar, &b_JPSI_VTX_cosThetaStar);
   fChain->SetBranchAddress("JPSI_VTX_phiStar", &JPSI_VTX_phiStar, &b_JPSI_VTX_phiStar);
   fChain->SetBranchAddress("JPSI_VTX_refTrksPx", &JPSI_VTX_refTrksPx, &b_JPSI_VTX_refTrksPx);
   fChain->SetBranchAddress("JPSI_VTX_refTrksPy", &JPSI_VTX_refTrksPy, &b_JPSI_VTX_refTrksPy);
   fChain->SetBranchAddress("JPSI_VTX_refTrksPz", &JPSI_VTX_refTrksPz, &b_JPSI_VTX_refTrksPz);
   fChain->SetBranchAddress("JPSI_VTX_lxy", &JPSI_VTX_lxy, &b_JPSI_VTX_lxy);
   fChain->SetBranchAddress("JPSI_VTX_lxyError", &JPSI_VTX_lxyError, &b_JPSI_VTX_lxyError);
   fChain->SetBranchAddress("JPSI_VTX_tau", &JPSI_VTX_tau, &b_JPSI_VTX_tau);
   fChain->SetBranchAddress("JPSI_VTX_tauError", &JPSI_VTX_tauError, &b_JPSI_VTX_tauError);
   fChain->SetBranchAddress("JPSI_VTX_tauMassHyp", &JPSI_VTX_tauMassHyp, &b_JPSI_VTX_tauMassHyp);
   fChain->SetBranchAddress("JPSI_VTX_tauErrorMassHyp", &JPSI_VTX_tauErrorMassHyp, &b_JPSI_VTX_tauErrorMassHyp);
   fChain->SetBranchAddress("JPSI_VTX_tauCorrected", &JPSI_VTX_tauCorrected, &b_JPSI_VTX_tauCorrected);
   fChain->SetBranchAddress("JPSI_VTX_tauErrorCorrected", &JPSI_VTX_tauErrorCorrected, &b_JPSI_VTX_tauErrorCorrected);
   fChain->SetBranchAddress("JPSI_VTX_cosTheta", &JPSI_VTX_cosTheta, &b_JPSI_VTX_cosTheta);
   fChain->SetBranchAddress("JPSI_VTX_cosThetaXY", &JPSI_VTX_cosThetaXY, &b_JPSI_VTX_cosThetaXY);
   fChain->SetBranchAddress("JPSI_VTX_massTauCov", &JPSI_VTX_massTauCov, &b_JPSI_VTX_massTauCov);
   fChain->SetBranchAddress("JPSI_VTX_refPVx", &JPSI_VTX_refPVx, &b_JPSI_VTX_refPVx);
   fChain->SetBranchAddress("JPSI_VTX_refPVy", &JPSI_VTX_refPVy, &b_JPSI_VTX_refPVy);
   fChain->SetBranchAddress("JPSI_VTX_refPVz", &JPSI_VTX_refPVz, &b_JPSI_VTX_refPVz);
   fChain->SetBranchAddress("JPSI_TRKS_px", &JPSI_TRKS_px, &b_JPSI_TRKS_px);
   fChain->SetBranchAddress("JPSI_TRKS_py", &JPSI_TRKS_py, &b_JPSI_TRKS_py);
   fChain->SetBranchAddress("JPSI_TRKS_pz", &JPSI_TRKS_pz, &b_JPSI_TRKS_pz);
   fChain->SetBranchAddress("JPSI_TRKS_d0", &JPSI_TRKS_d0, &b_JPSI_TRKS_d0);
   fChain->SetBranchAddress("JPSI_TRKS_z0", &JPSI_TRKS_z0, &b_JPSI_TRKS_z0);
   fChain->SetBranchAddress("JPSI_TRKS_index", &JPSI_TRKS_index, &b_JPSI_TRKS_index);
   fChain->SetBranchAddress("JPSI_TRUE_TRKS_px", &JPSI_TRUE_TRKS_px, &b_JPSI_TRUE_TRKS_px);
   fChain->SetBranchAddress("JPSI_TRUE_TRKS_py", &JPSI_TRUE_TRKS_py, &b_JPSI_TRUE_TRKS_py);
   fChain->SetBranchAddress("JPSI_TRUE_TRKS_pz", &JPSI_TRUE_TRKS_pz, &b_JPSI_TRUE_TRKS_pz);
   fChain->SetBranchAddress("JPSI_TRUE_TRKS_e", &JPSI_TRUE_TRKS_e, &b_JPSI_TRUE_TRKS_e);
   fChain->SetBranchAddress("JPSI_MUONS_pt", &JPSI_MUONS_pt, &b_JPSI_MUONS_pt);
   fChain->SetBranchAddress("JPSI_MUONS_eta", &JPSI_MUONS_eta, &b_JPSI_MUONS_eta);
   fChain->SetBranchAddress("JPSI_MUONS_index", &JPSI_MUONS_index, &b_JPSI_MUONS_index);
   fChain->SetBranchAddress("JPSI_TRUTH_px", &JPSI_TRUTH_px, &b_JPSI_TRUTH_px);
   fChain->SetBranchAddress("JPSI_TRUTH_py", &JPSI_TRUTH_py, &b_JPSI_TRUTH_py);
   fChain->SetBranchAddress("JPSI_TRUTH_pz", &JPSI_TRUTH_pz, &b_JPSI_TRUTH_pz);
   fChain->SetBranchAddress("JPSI_TRUTH_e", &JPSI_TRUTH_e, &b_JPSI_TRUTH_e);
   fChain->SetBranchAddress("JPSI_TRUTH_pdgID", &JPSI_TRUTH_pdgID, &b_JPSI_TRUTH_pdgID);
   fChain->SetBranchAddress("JPSI_TRUTH_vtxX", &JPSI_TRUTH_vtxX, &b_JPSI_TRUTH_vtxX);
   fChain->SetBranchAddress("JPSI_TRUTH_vtxY", &JPSI_TRUTH_vtxY, &b_JPSI_TRUTH_vtxY);
   fChain->SetBranchAddress("JPSI_TRUTH_vtxZ", &JPSI_TRUTH_vtxZ, &b_JPSI_TRUTH_vtxZ);
}

Bool_t JpsiSelector::Notify()
{
   // The Notify() function is called when a new file is opened. This
   // can be either for a new TTree in a TChain or when when a new TTree
   // is started when using PROOF. It is normally not necessary to make changes
   // to the generated code, but the routine can be extended by the
   // user if needed. The return value is currently not used.

   return kTRUE;
}

#endif // #ifdef JpsiSelector_cxx
