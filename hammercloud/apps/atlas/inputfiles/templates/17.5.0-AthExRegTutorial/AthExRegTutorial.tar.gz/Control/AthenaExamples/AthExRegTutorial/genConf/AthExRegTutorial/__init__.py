## Hook for AthExRegTutorial genConf module
