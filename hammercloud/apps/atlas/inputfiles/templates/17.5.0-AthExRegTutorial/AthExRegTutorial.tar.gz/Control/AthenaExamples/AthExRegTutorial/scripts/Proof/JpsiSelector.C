#define JpsiSelector_cxx
// The class definition in JpsiSelector.h has been generated automatically
// by the ROOT utility TTree::MakeSelector(). This class is derived
// from the ROOT class TSelector. For more information on the TSelector
// framework see $ROOTSYS/README/README.SELECTOR or the ROOT User Manual.

// The following methods are defined in this file:
//    Begin():        called every time a loop on the tree starts,
//                    a convenient place to create your histograms.
//    SlaveBegin():   called after Begin(), when on PROOF called only on the
//                    slave servers.
//    Process():      called for each event, in this function you decide what
//                    to read and fill your histograms.
//    SlaveTerminate: called at the end of the loop on the tree, when on PROOF
//                    called only on the slave servers.
//    Terminate():    called at the end of the loop on the tree,
//                    a convenient place to draw/fit your histograms.
//
// To use this file, try the following session on your Tree T:
//
// Root > T->Process("JpsiSelector.C")
// Root > T->Process("JpsiSelector.C","some options")
// Root > T->Process("JpsiSelector.C+")
//

#include "JpsiSelector.h"
#include <TH2.h>
#include <TStyle.h>


void JpsiSelector::Begin(TTree * /*tree*/)
{
   // The Begin() function is called at the start of the query.
   // When running with PROOF Begin() is only called on the client.
   // The tree argument is deprecated (on PROOF 0 is passed).

   TString option = GetOption();

}

void JpsiSelector::SlaveBegin(TTree * /*tree*/)
{
   // The SlaveBegin() function is called after the Begin() function.
   // When running with PROOF SlaveBegin() is called on each slave server.
   // The tree argument is deprecated (on PROOF 0 is passed).

   TString option = GetOption();

  // create a new histogram
  hJpsiMass = new TH1F("hJpsiMass", "Di-muon invariant mass", 200, 2., 5.);
 // add it to the list of items to be merged in the output
  fOutput->Add(hJpsiMass);

  // 'magic' lines to allow merging of an output root file
  TNamed *out = (TNamed *) fInput->FindObject("PROOF_OUTPUTFILE_LOCATION");
  Info("SlaveBegin", "PROOF_OUTPUTFILE_LOCATION: %s", (out ? out->GetTitle() : "undef"));
  fProofFile = new TProofOutputFile("SimpleNtuple.root", (out ? out->GetTitle() : "M"));
  out = (TNamed *) fInput->FindObject("PROOF_OUTPUTFILE");
  if (out) fProofFile->SetOutputFileName(out->GetTitle());

  // Open the file                                                                                                     
  TDirectory *savedir = gDirectory;
  fFile = fProofFile->OpenFile("RECREATE");
  if (fFile && fFile->IsZombie()) SafeDelete(fFile);
  savedir->cd();

  // Cannot continue                                                                                                   
  if (!fFile) {
    Info("SlaveBegin", "could not create '%s': instance is invalid!", fProofFile->GetName());
    return;
  }

  // create the output TTree 
  trJpsi = new TTree("trJpsi","Demo ntuple");
  trJpsi->SetDirectory(fFile);
  trJpsi->AutoSave();

  // add the branches to the output tree
  trJpsi->Branch("mJpsi", &JPSI_VTX_mass);
  trJpsi->Branch("ptJpsi", &JPSI_VTX_pt);


}

Bool_t JpsiSelector::Process(Long64_t entry)
{
   // The Process() function is called for each entry in the tree (or possibly
   // keyed object in the case of PROOF) to be processed. The entry argument
   // specifies which entry in the currently loaded tree is to be processed.
   // It can be passed to either JpsiSelector::GetEntry() or TBranch::GetEntry()
   // to read either all or the required parts of the data. When processing
   // keyed objects with PROOF, the object is already loaded and is available
   // via the fObject pointer.
   //
   // This function should contain the "body" of the analysis. It can contain
   // simple or elaborate selection criteria, run algorithms on the data
   // of the event and typically fill histograms.
   //
   // The processing can be stopped by calling Abort().
   //
   // Use fStatus to set the return value of TTree::Process().
   //
   // The return value is currently not used.
  fChain->GetTree()->GetEntry(entry);

  hJpsiMass->Fill(JPSI_VTX_mass*1e-3); // fill the di-muon mass in GeV

  // apply some selections
  if ( JPSI_charge !=0 ) {
    return kTRUE;
  }
  
  trJpsi->Fill();

   return kTRUE;
}

void JpsiSelector::SlaveTerminate()
{
   // The SlaveTerminate() function is called after all entries or objects
   // have been processed. When running with PROOF SlaveTerminate() is called
   // on each slave server.
  if (fFile) {
    fFile->Print();
    fFile->ls();
    Bool_t cleanup = kFALSE;
    TDirectory *savedir = gDirectory;
    cout << "SaveDir: " << gDirectory->GetName() << endl;
    gDirectory->Print();
    if (trJpsi->GetEntries() > 0) {
      fFile->cd();
      //  trPsi->Write();                                                                                           
      // trPsi->Print();                                                                                            
      trJpsi->Write();
      trJpsi->Print();
      hJpsiMass->Write();

      fProofFile->Print();
      fOutput->Add(fProofFile);
    } else {
      cleanup = kTRUE;
    }
    trJpsi->SetDirectory(0);
    gDirectory = savedir;
    fFile->Close();
    // Cleanup, if needed                                                                                           
    if (cleanup) {
      cout << "Performing file cleanuip" << endl;
      TUrl uf(*(fFile->GetEndpointUrl()));
      SafeDelete(fFile);
      gSystem->Unlink(uf.GetFile());
      SafeDelete(fProofFile);
    }
  }

}

void JpsiSelector::Terminate()
{
   // The Terminate() function is the last function to be called during
   // a query. It always runs on the client, it can be used to present
   // the results graphically or save the results to file.
  // get the output file
  // Get the ntuple form the file
  if ((fProofFile =
       dynamic_cast<TProofOutputFile*>(fOutput->FindObject("SimpleNtuple.root")))) {
    
    TString outputFile(fProofFile->GetOutputFileName());
    TString outputName(fProofFile->GetName());
    TString outputDir(fProofFile->GetDir());
    outputName += ".root";
    Printf("outputFile: %s", outputFile.Data());
    
    // Read the ntuple from the file
    fFile = TFile::Open(outputFile);
    if (fFile) {
      Printf("Managed to open file: %s", outputFile.Data());
      trJpsi = (TTree *) fFile->Get("trJpsi");
      fFile->ls();
    } else {
      Error("Terminate", "could not open file: %s", outputFile.Data());
    }
    if (!fFile) return; 
    
  } else {
    Error("Terminate", "TProofOutputFile not found");
    return;
  }
  
  if (!trJpsi) {
    cout << "Couldn't open Ntuple JPsi" << endl;
  }

  TH1F * h1(0); // simple pointer to use for drawing
  h1 = dynamic_cast<TH1F*>(fOutput->FindObject("hJpsiMass"));

  TCanvas * c1 = new TCanvas;
  c1->Divide(2,1);
  c1->cd(1);
  if (h1) {
    h1->Draw("e");
  }
  c1->cd(2);
  if ( trJpsi) {
    trJpsi->Draw("mJpsi/1e3");
    c1->cd(2)->SetLogy(1);
    c1->cd(2)->Update();
  }

}
