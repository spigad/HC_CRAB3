#ifndef SIMPLE_ANALYSIS_SKELETON_H
#define SIMPLE_ANALYSIS_SKELETON_H
/////////////////////////////////////////////////////////////////////////////////////////////////////
/// Name    : SimpleAnalysisSkeleton.h
/// Based on code from 
/// Package : offline/PhysicsAnalysis/AnalysisCommon/UserAnalysis
/// Author  : Ketevi A. Assamagan
/// Created : July 2004
///
/// DESCRIPTION:
///
/// This class is an analysis skeleton - The user can implement his analysis here
/// This class is also used for the demonstration of the distributed analysis
/// Some electron histograms are used for the distributed case. The user may
/// remove the histograms and the electron stuff if not needed.
/// Note: the single algorithm structure as an analysis code does not scale
/// For detailed analysis examples, look in SVN: PhysicsAnalysis/AnalysisCommon/AnalysisExamples/
/// Ketevi A. Assamagan on June 9, 2004
///
///////////////////////////////////////////////////////////////////////////////////////////////////////
#include <sstream>                                      // C++ utilities
#include <string>
#include <algorithm>
#include <fstream>

#include "TFile.h"					// ROOT stuff
#include "TNtuple.h"
#include "TROOT.h"
#include "TH1D.h"

#include "AthenaBaseComps/AthAlgorithm.h"

#include "GaudiKernel/MsgStream.h"              // Athena stuff
#include "GaudiKernel/ISvcLocator.h"
#include "GaudiKernel/ToolHandle.h"
#include "GaudiKernel/ObjectVector.h"

#include "StoreGate/StoreGateSvc.h"             // Storegate stuff
#include "StoreGate/DataHandle.h"
#include "AthenaKernel/DefaultKey.h"

#include "GaudiKernel/ToolHandle.h"
#include "GaudiKernel/Algorithm.h"
#include "GaudiKernel/ObjectVector.h"

#include "muonEvent/MuonContainer.h"            // Physics objects containers

class ITHistSvc; // forward declaration of histogramming (and TTree) service.


class SimpleAnalysisSkeleton : public AthAlgorithm  {

 public:

   SimpleAnalysisSkeleton(const std::string& name, ISvcLocator* pSvcLocator);
   ~SimpleAnalysisSkeleton();

   StatusCode initialize();
   StatusCode finalize();
   StatusCode execute();
   StatusCode beginRun();
   StatusCode endRun();
   void initializeBranches();
   void clearBranches(); 

 private:

   /** a handle on Store Gate for access to the Event Store */
   StoreGateSvc* m_storeGate;

   /** the key of the Muon Container to retrieve from the AOD */
   std::string m_muonContainerName; 

   /** user cuts  */ 
 
   double m_muonPtCut;
   double m_muonEtaCut;
   double m_muonMass;
  // N-tuple branches
  std::vector<double>* m_jpsiInvMass;
  std::vector<double>* m_muonPt;
  std::vector<double>* m_muonEta;

  // Tree object and output file to store results
  TTree* m_theTree; 
  TH1D  *m_dimuonMass;
  ITHistSvc * m_thistSvc; // used for interface with output root data
};

#endif // SIMPLE_ANALYSIS_SKELETON_H

