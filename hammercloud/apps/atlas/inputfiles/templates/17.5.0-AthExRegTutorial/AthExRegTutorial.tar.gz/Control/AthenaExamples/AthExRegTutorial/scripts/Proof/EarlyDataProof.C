// -------------------------------------------------------------------------
// Skeleton ROOT program for reading the n-tuple made by the B-physics tools with PROOF
// There are two parts to this code. This file that runs the job, and the file XXX
// Where the selection and plots, etc... are performed
// -------------------------------------------------------------------------

// to run in root:  
// [1]  .L EarlyDataProof.C+
// [2]  doAnalysis( "<rootFiles directory>" )

// if you want to run your own proof analysis.
// create a TSelector-derived class, then in this file change the line
//   chProof->Process(workingDir+"/JpsiSelector.C+");
// to point to the new code that you created.

#include<iostream>
#include "TROOT.h"
#include "TStyle.h"
#include "TCanvas.h"
#include <TList.h>
#include <TString.h>
#include <TSystemDirectory.h>
#include "TH1F.h"
#include "TH2F.h"
#include "TChain.h"
#include "TProof.h"
#include "TEnv.h"
#include "TRegexp.h"

// #include "getProof.C"  // this is found in $ROOTSYS/tutorials/proof . copy to the local directory

namespace {
  std::vector<TString> getFileNames(TString dirName,TString pattern = "user*root")
  {
    // get the full path filenames for dirName/<pattern>/<filepattern>

    // make sure we have the full path (may not work across xrootd etc...)
    gSystem->ExpandPathName(dirName);
    if (! gSystem->IsAbsoluteFileName(dirName.Data())){
      TString workingDir = gSystem->WorkingDirectory();
      dirName = workingDir +"/" + dirName;
    }
      
    TSystemDirectory dir(pattern,dirName);
    TList *files = dir.GetListOfFiles();
    TString fileName;
    std::vector<TString> theNames;
    if(files) {
      TIter next(files);
      TSystemFile *file;
      while ((file=(TSystemFile*)next())) {
        fileName = file->GetName();
        if (fileName=="." || fileName=="..") continue;
        theNames.push_back(dirName +"/"+fileName);
        //cout << (*theNames.rbegin()) << endl;
      }
    }
    return theNames;
  }
  
}

int doAnalysis(TString inputDir,TString inputPattern="user*root") {
  
  
  // Style setting
  gROOT->Reset();
  gROOT->ProcessLine("#include <vector>");
  gROOT->SetStyle("Plain");
  gStyle->SetFillColor(0);
  gStyle->SetFuncColor(kRed);
  gStyle->SetFuncWidth(1);
  gStyle->SetOptStat(111111);
  gStyle->SetOptFit(111111);

  
  //load the Proof stuff
  // assumes we are running our own manager
  
  // Get the PROOF Session
  // TProof *proof = getProof("proof://localhost:11093", 1, "/tmp/proof", "ask");
  TProof *proof = TProof::Open("workers=2");
  if (!proof) {
    Printf("runProof: could not start/attach a PROOF session");
    return 1;
  }

  // Have constant progress reporting based on estimated info
  proof->SetParameter("PROOF_RateEstimation", "average");

  // Tell root to add the current directory to the search path, so that NtupleReader can be found from the worker nodes.
  TString workingDir = gSystem->WorkingDirectory();
  proof->AddIncludePath(workingDir.Data()) ;
  
  // set output location to LOCAL
  proof->AddInput(new TNamed("PROOF_OUTPUTFILE_LOCATION", "LOCAL"));
  proof->AddInput(new TNamed("PROOF_OUTPUTFILE", (workingDir+"/TestNtuple.root").Data()));
  

  // input root files
  std::vector<TString> fileNames = getFileNames(inputDir,inputPattern);
  
  // Assume we want to loop over all JPSI candidates
  TChain * chProof = new TChain("JPSI");
  for ( std::vector<TString>::const_iterator it = fileNames.begin(); it != fileNames.end(); ++it) {
    chProof->Add(*it);
  }
  std::cout << "Added Files: " << std::endl;
  chProof->ls();
  chProof->SetProof();

  
  // run the analysis
  chProof->Process(workingDir+"/JpsiSelector.C++");
  
  return 0;
}


