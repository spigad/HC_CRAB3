# echo "cleanup AthExRegTutorial AthExRegTutorial-00-00-05 in /data/etp1/elmsheus/athena/17.5.0-ex/Control/AthenaExamples"

if test "${CMTROOT}" = ""; then
  CMTROOT=/cvmfs/atlas.cern.ch/repo/sw/software/x86_64-slc5-gcc43-opt/17.5.0/CMT/v1r23; export CMTROOT
fi
. ${CMTROOT}/mgr/setup.sh
cmtAthExRegTutorialtempfile=`${CMTROOT}/mgr/cmt -quiet build temporary_name`
if test ! $? = 0 ; then cmtAthExRegTutorialtempfile=/tmp/cmt.$$; fi
${CMTROOT}/mgr/cmt cleanup -sh -pack=AthExRegTutorial -version=AthExRegTutorial-00-00-05 -path=/data/etp1/elmsheus/athena/17.5.0-ex/Control/AthenaExamples  -quiet -without_version_directory $* >${cmtAthExRegTutorialtempfile}
if test $? != 0 ; then
  echo >&2 "${CMTROOT}/mgr/cmt cleanup -sh -pack=AthExRegTutorial -version=AthExRegTutorial-00-00-05 -path=/data/etp1/elmsheus/athena/17.5.0-ex/Control/AthenaExamples  -quiet -without_version_directory $* >${cmtAthExRegTutorialtempfile}"
  cmtcleanupstatus=2
  /bin/rm -f ${cmtAthExRegTutorialtempfile}
  unset cmtAthExRegTutorialtempfile
  return $cmtcleanupstatus
fi
cmtcleanupstatus=0
. ${cmtAthExRegTutorialtempfile}
if test $? != 0 ; then
  cmtcleanupstatus=2
fi
/bin/rm -f ${cmtAthExRegTutorialtempfile}
unset cmtAthExRegTutorialtempfile
return $cmtcleanupstatus

