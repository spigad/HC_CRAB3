// SimpleAnalysisSkeleton.cxx

#include "AthExRegTutorial/SimpleAnalysisSkeleton.h"

#include "GaudiKernel/ITHistSvc.h"


//////////////////////////////////////////////////////////////
// CONSTRUCTOR
SimpleAnalysisSkeleton::SimpleAnalysisSkeleton(const std::string& name,
  ISvcLocator* pSvcLocator) : AthAlgorithm(name, pSvcLocator)
{
  
  // Declare user-defined properties from jobOpts - cuts and vertexing methods etc
  declareProperty("muonPtCut", m_muonPtCut);
  declareProperty("muonEtaCut", m_muonEtaCut);
  declareProperty("muonMass", m_muonMass);
  declareProperty("muonContainerName", m_muonContainerName);
}

//////////////////////////////////////////////////////////////
// DESTRUCTOR
SimpleAnalysisSkeleton::~SimpleAnalysisSkeleton() {}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 

StatusCode SimpleAnalysisSkeleton::initialize() {

  ATH_MSG_INFO("in initialize()");

  //locate the StoreGateSvc and initialize our local ptr
  StatusCode sc = service("StoreGateSvc", m_storeGate);
  if (!sc.isSuccess() || 0 == m_storeGate) 
    ATH_MSG_ERROR("Could not find StoreGateSvc");

 
  // INITIALIZE THE N-TUPLE HERE
  initializeBranches();
  if ((service("THistSvc", m_thistSvc)).isFailure()){
    msg(MSG::FATAL) << "THistSvc service not found" << endreq;
    return StatusCode::FAILURE;
  }
  m_theTree = new TTree("MYTREE","MYTREE");
  m_theTree->Branch("DiMuonInvariantMass", &m_jpsiInvMass);
  m_theTree->Branch("MuonPt", &m_muonPt); 
  m_theTree->Branch("MuonEta", &m_muonEta);
  if (StatusCode::SUCCESS == m_thistSvc->regTree("/ATHEXREGTUTORIAL/MYTREE",m_theTree)) {
    msg(MSG::INFO) << "Booked module ntuple " << endreq;
  } else {
    msg(MSG::ERROR) << "Unable to register module ntuple " <<endreq;
  }  
  // create a histogram
  m_dimuonMass = new TH1D("h_diMuonMass","M(#mu#mu); M(#mu#mu) [MeV/c^{2}]; Di-muon candidates / (20 MeV/c^{2})",100,2e3,4e3);
  if (StatusCode::SUCCESS != m_thistSvc->regHist("/ATHEXREGTUTORIAL/h_diMuonMass",m_dimuonMass)) {
    msg(MSG::ERROR) << "Unable to register module histogram " <<endreq;
  }

  return StatusCode::SUCCESS;
  
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 

StatusCode SimpleAnalysisSkeleton::execute() {

  // THIS IS WHERE YOU WRITE YOUR ANALYSIS ALGORITHM

  ATH_MSG_DEBUG("in execute()");

 // This is necessary to avoid vectors from accumulating  
 clearBranches();

 // RETRIEVE MUONS FROM STOREGATE
 const Analysis::MuonContainer* importedMuonColl;
 StatusCode sc = m_storeGate->retrieve(importedMuonColl,m_muonContainerName);
 if (sc.isFailure() ) {
    ATH_MSG_WARNING("No Muon Collection of type " << m_muonContainerName << " found in StoreGate");
    importedMuonColl=0;
 }else{
    ATH_MSG_DEBUG("You have " << importedMuonColl->size() << " muons in this event");
 } 

 // FOR ALL MUONS WITH PT,ETA SATISFYING YOUR CUTS, COPY INTO A NEW VECTOR
 // TRACKS AND PUT INTO A VECTOR
 typedef std::vector<const Analysis::Muon*> MuonVector;
 MuonVector muonVector;
 Analysis::MuonContainer::const_iterator muonIter;
 for (muonIter=importedMuonColl->begin(); muonIter!=importedMuonColl->end(); ++muonIter) {
	bool isGoodMuon = false;
	double pt = fabs((*muonIter)->pt());
	double eta = fabs((*muonIter)->eta());
	m_muonPt->push_back(pt);
	m_muonEta->push_back(eta);
	if ( (*muonIter)->isCombinedMuon()  ) isGoodMuon = true;
	if ( (pt > m_muonPtCut) && (eta < m_muonEtaCut) && isGoodMuon ) {
		muonVector.push_back(*muonIter);
	}
 }   

 // LOOP OVER THE MUONS AND MAKE ALL OPPOSITELY CHARGED PAIRS
 // USING THE ASSOCIATED TRACK PARAMETERS
 MuonVector::iterator outerMuonIter;
 MuonVector::iterator innerMuonIter;
 std::vector<MuonVector> muonPairs;
 for (outerMuonIter=muonVector.begin(); outerMuonIter!=muonVector.end(); ++outerMuonIter) {
	const Rec::TrackParticle* track1 = (*outerMuonIter)->track();
	if (track1==NULL) continue;
	for (innerMuonIter=(outerMuonIter+1);innerMuonIter!=muonVector.end();innerMuonIter++){ 
		const Rec::TrackParticle* track2 = (*innerMuonIter)->track();
		if (track2==NULL) continue;
		double qOverP1 = track1->measuredPerigee()->parameters()[Trk::qOverP];
		double qOverP2 = track2->measuredPerigee()->parameters()[Trk::qOverP];
		if ( qOverP1*qOverP2 > 0.0 ) continue;
		MuonVector tmpPair;
		tmpPair.push_back(*innerMuonIter);
		tmpPair.push_back(*outerMuonIter);
		muonPairs.push_back(tmpPair);
		tmpPair.clear();
	}
 }

 // LOOP OVER THE MUON PAIRS AND CALCULATE THE INVARIANT MASS IN EACH CASE
 // INSERT INTO THE NTUPLE
 std::vector<MuonVector>::iterator pairIter;
 for (pairIter=muonPairs.begin(); pairIter!=muonPairs.end(); ++pairIter) {
	double pxSum = (*pairIter)[0]->px() + (*pairIter)[1]->px();
	double pySum = (*pairIter)[0]->py() + (*pairIter)[1]->py(); 
	double pzSum = (*pairIter)[0]->pz() + (*pairIter)[1]->pz();
	double eSum = (*pairIter)[0]->e() + (*pairIter)[1]->e(); 
	double invMass = sqrt(eSum*eSum - pxSum*pxSum - pySum*pySum - pzSum*pzSum);
	m_jpsiInvMass->push_back(invMass);
  if (invMass > 2e3 && invMass < 4e3) 
    m_dimuonMass->Fill(invMass);
 }

 // Fill the tree with the results
 m_theTree->Fill();

// END OF ANALYSIS
  
  return StatusCode::SUCCESS;
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 

StatusCode SimpleAnalysisSkeleton::finalize() {

  ATH_MSG_DEBUG("in finalize()");

  // Summary of analysis can go here

  // print a summary of the tree
  m_theTree->Print(); 

  return StatusCode::SUCCESS;
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 

StatusCode SimpleAnalysisSkeleton::beginRun() {

  ATH_MSG_DEBUG("In beginRun"); 
  return StatusCode::SUCCESS;

}


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 

StatusCode SimpleAnalysisSkeleton::endRun() {

  ATH_MSG_DEBUG("At the end of the run");

  return StatusCode::SUCCESS;

}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 

// This is needed to empty n-tuple branches using vectors, to avoid accumulation
// of events 
void SimpleAnalysisSkeleton::clearBranches() {

  m_muonPt->clear();
  m_muonEta->clear();
  m_jpsiInvMass->clear();
        
  return;

}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 


// initializes vector branches of ntuple

void SimpleAnalysisSkeleton::initializeBranches(void) {

  m_muonPt = new std::vector<double>;
  m_muonEta = new std::vector<double>;
  m_jpsiInvMass = new std::vector<double>;

  return;

} 
 

// **************************************************************************
// **************************************************************************
