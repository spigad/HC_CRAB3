#!/bin/bash
./gridscript.sh $1
