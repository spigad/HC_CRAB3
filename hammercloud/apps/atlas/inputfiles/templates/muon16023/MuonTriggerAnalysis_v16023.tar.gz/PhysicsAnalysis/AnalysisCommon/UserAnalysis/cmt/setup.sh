# echo "Setting UserAnalysis UserAnalysis-00-10-12 in /data/etp2/elmsheus/athena/16.0.2.3/PhysicsAnalysis/AnalysisCommon"

if test "${CMTROOT}" = ""; then
  CMTROOT=/opt/atlas/software/manageTier3SW/ATLASLocalRootBase/Athena/i686_slc5_gcc43_opt/16.0.2/CMT/v1r22; export CMTROOT
fi
. ${CMTROOT}/mgr/setup.sh
cmtUserAnalysistempfile=`${CMTROOT}/mgr/cmt -quiet build temporary_name`
if test ! $? = 0 ; then cmtUserAnalysistempfile=/tmp/cmt.$$; fi
${CMTROOT}/mgr/cmt setup -sh -pack=UserAnalysis -version=UserAnalysis-00-10-12 -path=/data/etp2/elmsheus/athena/16.0.2.3/PhysicsAnalysis/AnalysisCommon  -no_cleanup $* >${cmtUserAnalysistempfile}
if test $? != 0 ; then
  echo >&2 "${CMTROOT}/mgr/cmt setup -sh -pack=UserAnalysis -version=UserAnalysis-00-10-12 -path=/data/etp2/elmsheus/athena/16.0.2.3/PhysicsAnalysis/AnalysisCommon  -no_cleanup $* >${cmtUserAnalysistempfile}"
  cmtsetupstatus=2
  /bin/rm -f ${cmtUserAnalysistempfile}
  unset cmtUserAnalysistempfile
  return $cmtsetupstatus
fi
cmtsetupstatus=0
. ${cmtUserAnalysistempfile}
if test $? != 0 ; then
  cmtsetupstatus=2
fi
/bin/rm -f ${cmtUserAnalysistempfile}
unset cmtUserAnalysistempfile
return $cmtsetupstatus

