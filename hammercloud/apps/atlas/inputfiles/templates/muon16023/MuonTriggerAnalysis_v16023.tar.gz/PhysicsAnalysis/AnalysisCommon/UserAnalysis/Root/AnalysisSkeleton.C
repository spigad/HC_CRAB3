// The class definition in AnalysisSkeleton.h has been generated automatically
// by the ROOT utility TTree::MakeSelector(). This class is derived
// from the ROOT class TSelector. For more information on the TSelector
// framework see $ROOTSYS/README/README.SELECTOR or the ROOT User Manual.

// The following methods are defined in this file:
//    Begin():        called everytime a loop on the tree starts,
//                    a convenient place to create your histograms.
//    SlaveBegin():   called after Begin(), when on PROOF called only on the
//                    slave servers.
//    Process():      called for each event, in this function you decide what
//                    to read and fill your histograms.
//    SlaveTerminate: called at the end of the loop on the tree, when on PROOF
//                    called only on the slave servers.
//    Terminate():    called at the end of the loop on the tree,
//                    a convenient place to draw/fit your histograms.
//
// To use this file, try the following session on your Tree T:
//
// Root > T->Process("AnalysisSkeleton.C")
// Root > T->Process("AnalysisSkeleton.C","some options")
// Root > T->Process("AnalysisSkeleton.C+")
//

/******************************************************************************
Author: Ketevi A. Assamagan
Date: December 2006
Questions and comments: ketevi@bnl.gov
******************************************************************************/

#include "AnalysisSkeleton.h"
#include <TH2.h>
#include <TStyle.h>
#include <TCanvas.h>
#include <TMath.h>
/** constructor */
AnalysisSkeleton::AnalysisSkeleton(TTree * tree)
{
  this->Reset();
  if (tree) {
    std::cout << "Number of Events to process = " << tree->GetEntriesFast() << std::endl;
    this->Init(tree);
  }
}

/** initialize pointers - it is your responsibility to delete these
    objects to avoid memory leak - the cleanup method */
void AnalysisSkeleton::Reset() 
{ 
  /** Reconstructed Vertices */
  m_recVertex             = new std::vector<RecVertex>;
  
  /** Inner Det TrackParticle */
  m_innerDetTrack         = new std::vector<TrackParticle>;

  /** Muon TrackParticles */
  m_muonSpectrometerTrack = new std::vector<TrackParticle>;
  m_muonExTrack           = new std::vector<TrackParticle>;
  m_muonCombinedTrack     = new std::vector<TrackParticle>;
  m_muonLowPtTrack        = new std::vector<TrackParticle>;

  /** Calorimeter clusters */
  m_lArClusterEM          = new std::vector<CaloCluster>;
  m_lArClusterEM37        = new std::vector<CaloCluster>;
  m_lArClusterEMSofte     = new std::vector<CaloCluster>;
  m_combinedCluster       = new std::vector<CaloCluster>;
  m_emTopoCluster         = new std::vector<CaloCluster>;
  m_caloCalTopoCluster    = new std::vector<CaloCluster>;
  m_lArClusterEMgam35     = new std::vector<CaloCluster>;
  m_lArClusterEMgam       = new std::vector<CaloCluster>;
  
  /** Electron */
  m_electron              = new std::vector<Electron>;
  
  /** Photon */
  m_photon                = new std::vector<Photon>;
  
  /** Muon */
  m_muon                  = new std::vector<Muon>;
  
  /** TauJet */
  m_tauJet                = new std::vector<TauJet>;

  /** ParticleJet */
  m_particleJet           = new std::vector<ParticleJet>;

  /** Missing ET */
  m_missingEt=0;

  /** TruthParticle */
  m_truthParticle         = new std::vector<TruthParticle>;

  /** Truth ParticleJet */
  m_truthParticleJet      = new std::vector<ParticleJet>;

  /** Truth Missing ET */
  m_truthMissingEt=0;

  /** non overlapping containers */
  m_nonOverlappingPhoton      = new std::vector<Photon>;
  m_nonOverlappingElectron    = new std::vector<Electron>;
  m_nonOverlappingMuon        = new std::vector<Muon>; 
  m_nonOverlappingTauJet      = new std::vector<TauJet>;
  m_nonOverlappingParticleJet = new std::vector<ParticleJet>;

}

/** desctructor */
AnalysisSkeleton::~AnalysisSkeleton() {
  this->Cleanup();
}

/** delete the memory allocated on the heap
    histograms are not deleted */
void AnalysisSkeleton::Cleanup() {

  /** Reconstructed Vertices */
  delete m_recVertex;

  /** Inner Det TrackParticle */
  delete m_innerDetTrack;

  /** Muon TrackParticles */
  delete m_muonSpectrometerTrack;

  delete m_muonExTrack;

  delete m_muonCombinedTrack;

  delete m_muonLowPtTrack;

  /** Calorimeter clusters */
  delete m_lArClusterEM;

  delete m_lArClusterEM37;

  delete m_lArClusterEMSofte;

  delete m_combinedCluster;

  delete m_emTopoCluster;

  delete m_caloCalTopoCluster;

  delete m_lArClusterEMgam35;

  delete m_lArClusterEMgam;

  /** Electron */
  delete m_electron;

  /** Photon */
  delete m_photon;

  /** Muon */
  delete m_muon;

  /** TauJet */
  delete m_tauJet;

  /** ParticleJet */
  delete m_particleJet;

  /** TruthParticle */
  delete m_truthParticle;

  /** Truth ParticleJet */
  delete m_truthParticleJet;

  /** non overlapping containers */
  delete m_nonOverlappingPhoton;
  delete m_nonOverlappingElectron;
  delete m_nonOverlappingMuon; 
  delete m_nonOverlappingTauJet;
  delete m_nonOverlappingParticleJet;
}

void AnalysisSkeleton::Init(TTree *tree)
{
   // The Init() function is called when the selector needs to initialize
   // a new tree or chain. Typically here the branch addresses of the tree
   // will be set. It is normaly not necessary to make changes to the
   // generated code, but the routine can be extended by the user if needed.
   // Init() will be called many times when running with PROOF.

   if (tree == 0) return;
   fChain = tree;

   //fChain->SetMakeClass(1);

   /** set TBranch addresses */

   fChain->SetBranchAddress("RunNumber",&m_runNumber);
   fChain->SetBranchAddress("EventNumber",&m_eventNumber);
   fChain->SetBranchAddress("StreamESD_ref",&m_streamESD_ref);
   fChain->SetBranchAddress("Stream1_ref",m_stream1_ref);
   fChain->SetBranchAddress("Token",m_token);
   fChain->SetBranchAddress("Run",&m_run);
   fChain->SetBranchAddress("Event",&m_event);
   fChain->SetBranchAddress("Time",&m_time);
   fChain->SetBranchAddress("Weight",&m_weight);
   fChain->SetBranchAddress("IEvent",&m_iEvent);

   /** Reconstructed Vertices */
   fChain->SetBranchAddress("VxPrimaryCandidate", &m_recVertex);

   /** Inner Det TrackParticle */
   fChain->SetBranchAddress("TrackParticleCandidate", &m_innerDetTrack);

   /** Muon TrackParticles */
   fChain->SetBranchAddress("MuonboyMuonSpectroOnlyTrackParticles", &m_muonSpectrometerTrack);
   fChain->SetBranchAddress("MuonboyTrackParticles", &m_muonExTrack);
   fChain->SetBranchAddress("StacoTrackParticles", &m_muonCombinedTrack);
   fChain->SetBranchAddress("MuTagTrackParticles", &m_muonLowPtTrack);

   /** Calorimeter clusters */
   fChain->SetBranchAddress("LArClusterEM", &m_lArClusterEM);
   fChain->SetBranchAddress("LArClusterEM37", &m_lArClusterEM37);
   fChain->SetBranchAddress("LArClusterEMSofte", &m_lArClusterEMSofte);
   fChain->SetBranchAddress("CombinedCluster", &m_combinedCluster);
   fChain->SetBranchAddress("EMTopoCluster", &m_emTopoCluster);
   fChain->SetBranchAddress("CaloCalTopoCluster", &m_caloCalTopoCluster);
   fChain->SetBranchAddress("LArClusterEMgam35", &m_lArClusterEMgam35);
   fChain->SetBranchAddress("LArClusterEMgam", &m_lArClusterEMgam);

   /** Electron */
   fChain->SetBranchAddress("ElectronCollection", &m_electron);

   /** Photon */
   fChain->SetBranchAddress("PhotonCollection", &m_photon);

   /** Muon */
   fChain->SetBranchAddress("StacoMuonCollection", &m_muon);

   /** TauJet */
   fChain->SetBranchAddress("TauJetCollection", &m_tauJet);

   /** ParticleJet */
   fChain->SetBranchAddress("ConeTowerParticleJets", &m_particleJet);

   /** Missing ET */
   fChain->SetBranchAddress("MET_Final_Muonboy", &m_missingEt);

   /** TruthParticle */
   fChain->SetBranchAddress("SpclMC", &m_truthParticle);

   /** Truth ParticleJet */
   fChain->SetBranchAddress("ConeTruthParticleJets", &m_truthParticleJet);

   /** Truth Missing ET */
   fChain->SetBranchAddress("MET_Truth", &m_truthMissingEt);

   /** retrieve branch pointers */
   this->Notify();
}

Bool_t AnalysisSkeleton::Notify()
{
  // The Notify() function is called when a new file is opened. This
  // can be either for a new TTree in a TChain or when when a new TTree
  // is started when using PROOF. Typically here the branch pointers
  // will be retrieved. It is normaly not necessary to make changes
  // to the generated code, but the routine can be extended by the
  // user if needed.

  // Get branch pointers
  m_runNumberBranch     = fChain->GetBranch("RunNumber");
  m_eventNumberBranch   = fChain->GetBranch("EventNumber");
  m_streamESD_refBranch = fChain->GetBranch("StreamESD_ref");
  m_stream1_refBranch   = fChain->GetBranch("Stream1_ref");
  m_tokenBranch         = fChain->GetBranch("Token");
  m_runBranch           = fChain->GetBranch("Run");
  m_eventBranch         = fChain->GetBranch("Event");
  m_timeBranch          = fChain->GetBranch("Time");
  m_weightBranch        = fChain->GetBranch("Weight");
  m_iEventBranch        = fChain->GetBranch("IEvent");
  
  /** Reconstructed Vertices */
  m_recVertexBranch = fChain->GetBranch("VxPrimaryCandidate");
  
  /** Inner Det TrackParticle */
  m_innerDetTrackBranch = fChain->GetBranch("TrackParticleCandidate");
  
  /** Muon TrackParticles */
  m_muonSpectrometerTrackBranch = fChain->GetBranch("MuonboyMuonSpectroOnlyTrackParticles");
  
  m_muonExTrackBranch = fChain->GetBranch("MuonboyTrackParticles");
  
  m_muonCombinedTrackBranch = fChain->GetBranch("StacoTrackParticles");

  m_muonLowPtTrackBranch = fChain->GetBranch("MuTagTrackParticles");
  
  /** Calorimeter clusters */
  m_lArClusterEMBranch = fChain->GetBranch("LArClusterEM");
  
  m_lArClusterEM37Branch = fChain->GetBranch("LArClusterEM37");
  
  m_lArClusterEMSofteBranch = fChain->GetBranch("LArClusterEMSofte");
  
  m_combinedClusterBranch = fChain->GetBranch("CombinedCluster");
  
  m_emTopoClusterBranch = fChain->GetBranch("EMTopoCluster");
  
  m_caloCalTopoClusterBranch = fChain->GetBranch("CaloCalTopoCluster");
  
  m_lArClusterEMgam35Branch = fChain->GetBranch("LArClusterEMgam35");
  
  m_lArClusterEMgamBranch = fChain->GetBranch("LArClusterEMgam");
  
  /** Electron */
  m_electronBranch = fChain->GetBranch("ElectronCollection");
  
  /** Photon */
  m_photonBranch = fChain->GetBranch("PhotonCollection");
   
  /** Muon */
  m_muonBranch = fChain->GetBranch("StacoMuonCollection");
  
  /** TauJet */
  m_tauJetBranch = fChain->GetBranch("TauJetCollection");
  
  /** ParticleJet */
  m_particleJetBranch = fChain->GetBranch("ConeTowerParticleJets");
  
  /** Missing ET */
  m_missingEtBranch = fChain->GetBranch("MET_Final_Muonboy");
  
  /** TruthParticle */
  m_truthParticleBranch = fChain->GetBranch("SpclMC");
  
  /** Truth ParticleJet */
  m_truthParticleJetBranch = fChain->GetBranch("ConeTruthParticleJets");
  
  /** Truth Missing ET */
  m_truthMissingEtBranch = fChain->GetBranch("MET_Truth");

  return kTRUE;
}

void AnalysisSkeleton::Begin(TTree *tree)
{
  // The Begin() function is called at the start of the query.
  // When running with PROOF Begin() is only called on the client.
  // The tree argument is deprecated (on PROOF 0 is passed).

  /** Print the tree information */
  tree->Print();

  TString option = GetOption();

  /** book or rebook the user histograms */
  m_electronPt                           = new TH1F ("ElectronPT", "ElectronPT", 100, 0, 250);
  m_electronEta                          = new TH1F ("ElectronEta", "ElectornEta", 100, -3.5, 3.5);
  m_electronPhi                          = new TH1F ("ElectronPhi", "ElectronPhi", 100, -3.15, 3.15);
  m_electronEoverP                       = new TH1F ("ElectronEoverP", "ElectronEoverP", 100, 0, 3);
  m_electronIsolationEt                  = new TH1F ("ElectronIsolationET", "ElectronIsolationET", 100, 0, 50);
  m_electronIsEM                         = new TH1F ("ElectronIsEM", "ElectronIsEM", 4096, 0, 4095);
  m_softElectronIsEM                     = new TH1F ("SoftElectronIsEM", "SoftElectronIsEM", 4096, 0, 4095);
  m_electronAuthor                       = new TH1F ("ElectronAuthor", "ElectronAuthor", 5, -0.5, 4.5);
  m_electronNumberOfPixelHits            = new TH1F ("NumberOfPixelHits", "NumberOfPixelHits", 45, -0.5, 14.5);
  m_electronNumberOfSCTHits              = new TH1F ("NumberOfSCTHits", "NumberOfSCTHits", 50, -0.5, 19.5);
  m_electronNumberOfTRTHits              = new TH1F ("NumberOfTRTHits", "NumberOfTRTHits", 50, -0.5, 49.5);
  m_electronNumberOfTRTHighThresholdHits = new TH1F ("NumberOfTRTHighThresholdHits", "NumberOfTRTHighThresholdHits", 50, -0.5, 19.5);
  m_electronNumberOfBLayerHits           = new TH1F ("NumberOfBLayerHits", "NumberOfBLayerHits", 50, -0.5, 19.5);

  m_mcElectronEta                        = new TH1F ("McElectronEta", "McElectronEta", 100, -3.5, 3.5);
  m_electronDeltaRMatch                  = new TH1F ("DeltaRMatch", "DeltaRMatch", 100, 0, 1);
  m_electronPtRatio                      = new TH1F ("PtRatio", "PtRatio", 100, 0, 2);

}

void AnalysisSkeleton::SlaveBegin(TTree *tree)
{
   // The SlaveBegin() function is called after the Begin() function.
   // When running with PROOF SlaveBegin() is called on each slave server.
   // The tree argument is deprecated (on PROOF 0 is passed).

   this->Init(tree);

   TString option = GetOption();

}

Bool_t AnalysisSkeleton::Process(Long64_t entry)
{
   // The Process() function is called for each entry in the tree (or possibly
   // keyed object in the case of PROOF) to be processed. The entry argument
   // specifies which entry in the currently loaded tree is to be processed.
   // It can be passed to either TTree::GetEntry() or TBranch::GetEntry()
   // to read either all or the required parts of the data. When processing
   // keyed objects with PROOF, the object is already loaded and is available
   // via the fObject pointer.
   //
   // This function should contain the "body" of the analysis. It can contain
   // simple or elaborate selection criteria, run algorithms on the data
   // of the event and typically fill histograms.

   // WARNING when a selector is used with a TChain, you must use
   //  the pointer to the current TTree to call GetEntry(entry).
   //  The entry is always the local entry number in the current tree.
   //  Assuming that fChain is the pointer to the TChain being processed,
   //  use fChain->GetTree()->GetEntry(entry).

   /** read the event - the user should customize this method for the TBranches to read.
       Do not read the entire TTree if not need. Read ONLY the TBranches that you need 
       for faster processing of the data. */
   this->readEvent(entry);

   /** do overlap removal: this will create the following non overlapping collections:
       m_nonOverlappingPhoton
       m_nonOverlappingElectron
       m_nonOverlappingMuon
       m_nonOverlappingTauJet
       m_nonOverlappingParticleJet
       Some pre-selections are done before removal overlaps. The user should
       customize the selection criteria and the overlap removal. 
   */
   this->removeOverlaps(entry);

   /** Loop over Electrons and do something */
   std::vector<Electron>::const_iterator elecItr  = m_electron->begin();
   std::vector<Electron>::const_iterator elecItrE = m_electron->end();
   for (; elecItr != elecItrE; ++elecItr) {

     m_electronPt->Fill( (*elecItr).pt()/GeV );
     m_electronEta->Fill( (*elecItr).eta() );
     m_electronPhi->Fill( (*elecItr).phi() );

     m_electronAuthor->Fill( (*elecItr).author() );
     if ( (*elecItr).author() == electronParameters::AuthorSofte) 
       m_softElectronIsEM->Fill( (*elecItr).isEM_softElectron() );     
      else
       m_electronIsEM->Fill( (*elecItr).isEM() );

     m_electronIsolationEt->Fill( (*elecItr).parameter(electronParameters::etcone40)/GeV );

     /** Access to more Electron data */
     m_electronNumberOfPixelHits->Fill( (*elecItr).numberOfPixelHits() );
     m_electronNumberOfSCTHits->Fill( (*elecItr).numberOfSCTHits() );
     m_electronNumberOfTRTHits->Fill( (*elecItr).numberOfTRTHits() );
     m_electronNumberOfTRTHighThresholdHits->Fill( (*elecItr).numberOfTRTHighThresholdHits() );
     m_electronNumberOfBLayerHits->Fill( (*elecItr).numberOfBLayerHits() );

     /** Electron selection */
     if ( !this->selectElectron (*elecItr) ) continue;

     /** The Electron Track */
     const TrackParticle * track = (*elecItr).track();

     /** The Electron Cluster */
     const CaloCluster * cluster = (*elecItr).cluster();

     /** The E over P over the Electron */
     if ( cluster && track) {
       double e_over_p = cluster->e() / track->p();
       m_electronEoverP->Fill( e_over_p );
     }

     /** match to Monte carlo Truth */
     double deltaR;
     unsigned int index;
     if ( this->matchToTruth( (*elecItr), deltaR, index, m_truthParticle ) ) {
       m_mcElectronEta->Fill ( (m_truthParticle->at(index)).eta() );
       m_electronDeltaRMatch->Fill ( deltaR );
       m_electronPtRatio->Fill( (*elecItr).pt() / (m_truthParticle->at(index)).pt() ) ;
     }
   }

   return kTRUE;
}

void AnalysisSkeleton::SlaveTerminate()
{
   // The SlaveTerminate() function is called after all entries or objects
   // have been processed. When running with PROOF SlaveTerminate() is called
   // on each slave server.

}

void AnalysisSkeleton::Terminate()
{
  // The Terminate() function is the last function to be called during
  // a query. It always runs on the client, it can be used to present
  // the results graphically or save the results to file.
  
  TCanvas * canvas = new TCanvas("Electron","AnalysisSkeleton",800,800);
  canvas->Divide(2,2);

  canvas->cd(1);
  m_electronEoverP->Draw();
  canvas->cd(2);
  m_electronIsolationEt->Draw();
  canvas->cd(3);
  m_electronIsEM->Draw();
  canvas->cd(4);
  m_electronNumberOfPixelHits->Draw();

  //canvas->SaveAs("AnalysisSkeleton.gif");

}

/** read the event */
void AnalysisSkeleton::readEvent (Long64_t entry) 
{
   /** Read reconstructed vertices for current event */
   m_recVertexBranch->GetEntry(entry);

   /** Read TrackParticles for current event */
   m_innerDetTrackBranch->GetEntry(entry);
   m_muonSpectrometerTrackBranch->GetEntry(entry);
   m_muonExTrackBranch->GetEntry(entry);
   m_muonCombinedTrackBranch->GetEntry(entry);
   m_muonLowPtTrackBranch->GetEntry(entry);

   /** Read calorimeter Clusters */
   m_lArClusterEMBranch->GetEntry(entry);
   m_lArClusterEM37Branch->GetEntry(entry);
   m_lArClusterEMSofteBranch->GetEntry(entry);
   m_combinedClusterBranch->GetEntry(entry);
   m_emTopoClusterBranch->GetEntry(entry);
   m_caloCalTopoClusterBranch->GetEntry(entry);
   m_lArClusterEMgam35Branch->GetEntry(entry);
   m_lArClusterEMgamBranch->GetEntry(entry);

   /** Read reconstructed particles */
   m_electronBranch->GetEntry(entry);
   m_photonBranch->GetEntry(entry);
   m_muonBranch->GetEntry(entry);
   m_tauJetBranch->GetEntry(entry);
   m_particleJetBranch->GetEntry(entry);
   m_missingEtBranch->GetEntry(entry);

   /** Read the MC Truth */
   m_truthParticleBranch->GetEntry(entry);
   m_truthParticleJetBranch->GetEntry(entry);
   m_truthMissingEtBranch->GetEntry(entry);
}

/** find a match to mC Truth. Return the deltaR of the match and 
    the index to the matched truth particle */
bool AnalysisSkeleton::matchToTruth ( const IParticle& particle, double& deltaR, 
				      unsigned int& index, const std::vector<TruthParticle>* mcTruth )
{
  double big = 1.0e+20;
  bool foundMatch = false;
  deltaR = big;
  index = 999999;

  std::vector<TruthParticle>::const_iterator itr  = mcTruth->begin();
  std::vector<TruthParticle>::const_iterator itrE = mcTruth->end();
  unsigned int iPart = 0;
  for (; itr != itrE; ++itr, ++iPart ) {
    double deta = particle.eta()-(*itr).eta();
    double dphi = particle.phi()-(*itr).phi();
    //big = particle.hlv().DeltaR( (*itr).hlv() ); 
    big = TMath::Sqrt( deta*deta + dphi*dphi );
    if ( (big < deltaR) && (particle.pdgId() == (*itr).pdgId()) ) {
      deltaR = big;
      foundMatch = true;
      index = iPart;
    }
  }
  return foundMatch;
}

bool AnalysisSkeleton::matchToTruth ( const ParticleJet& jet, double& deltaR, 
				      unsigned int& index, const std::vector<TruthParticle>* mcTruth ) 
{
  double big = 1.0e+20;
  bool foundMatch = false;
  deltaR = big;
  index = 999999;

  std::vector<TruthParticle>::const_iterator itr  = mcTruth->begin();
  std::vector<TruthParticle>::const_iterator itrE = mcTruth->end();
  unsigned int iPart = 0;
  for (; itr != itrE; ++itr, ++iPart ) {
    //big = jet.hlv().DeltaR( (*itr).hlv() );
    double deta = jet.eta()-(*itr).eta();
    double dphi = jet.phi()-(*itr).phi(); 
    big = TMath::Sqrt( deta*deta + dphi*dphi );
    if ( big < deltaR ) {
      deltaR = big;
      foundMatch = true;
      index = iPart;
    }
  }
  return foundMatch;
}

/** TrackParticle selection */
bool AnalysisSkeleton::selectTrackParticle ( const TrackParticle& track )
{
  bool isSelected  = true;

  bool goodPt      = track.pt() > 10.0*GeV;
  bool isIsolated  = this->isTrackIsolated( track );

  const TrackSummary* summary = track.trackSummary();

  int pix = summary->get(numberOfPixelHits);
  int sct = summary->get(numberOfSCTHits);
  int trt = summary->get(numberOfTRTHits);
  int htr = summary->get(numberOfTRTHighThresholdHits);

  bool pixHit = pix > 0;
  bool sctHit = sct > 0;
  bool trtHit = trt > 0;
  bool htrHit = htr > 0;
  
  isSelected       = goodPt && isIsolated && pixHit && sctHit && trtHit && htrHit;

  return isSelected;
}

/** CaloCluster selection */
bool AnalysisSkeleton::selectCaloCluster   ( const CaloCluster& cluster )
{
  bool isSelected = true;

  bool goodEnergy = cluster.e() > 10.0*GeV;
  isSelected = goodEnergy;

  return isSelected;
}

/** Electron selection */
bool AnalysisSkeleton::selectElectron      ( const Electron& electron )
{
  bool isSelected        = true;

  bool egamma            = electron.author() == electronParameters::AuthorEgamma ||
    electron.author() == electronParameters::AuthorEgammaSofte;
  bool softe             = electron.author() == electronParameters::AuthorSofte;
  bool goodPt            = electron.pt() > 10.0*GeV;
  bool showerShape       = electron.isEM()%16 == 0;
  bool isCaloIsolated    = electron.parameter(electronParameters::etcone40) < 10.0*GeV;
  bool goodTrack         = this->selectTrackParticle ( *electron.track() );
  bool trackMatch        = fabs(electron.parameter(electronParameters::EoverP)-1) < 0.5;

  //bool transitionRadiate = electron.isEM() && 0x0400; // bit number 11

  /** common selection */
  bool commonSelect = goodPt && goodTrack && isCaloIsolated;

  /** egamma highPt reconstruction */
  bool egammaSelect = commonSelect && egamma && showerShape && trackMatch;

  /** electron lowPt reconstruction */
  bool softeSelect  = commonSelect && softe && electron.isEM_softElectron()==0;

  /** for better efficiency select either candidate */
  isSelected = egammaSelect || softeSelect;

  return isSelected;
}

/** Photon selection */
bool AnalysisSkeleton::selectPhoton        ( const Photon& photon )
{
  bool isSelected        = true;

  bool goodPt            = photon.pt() > 10.0*GeV; 
  bool showerShape       = photon.isEM()%16 == 0;
  bool isCaloIsolated    = photon.parameter(photonParameters::etcone40) < 10.0*GeV; 

  isSelected = goodPt && showerShape && isCaloIsolated;

  return isSelected;
}

/** Muon selection */
bool AnalysisSkeleton::selectMuon          ( const Muon& muon )
{
  bool isSelected = true;

  bool goodPt         = muon.pt() > 6.0*GeV; // Unit in MeV
  bool isBestMatch    = muon.bestMatch();
  bool fitChi2        = muon.fitChi2OverDoF() < 10.0;
  bool matchChi2      = muon.matchChi2OverDoF() < 10.0;
  bool goodInDetTrack = (muon.hasInDetTrackParticle()) ? this->selectTrackParticle ( *muon.inDetTrackParticle() ) : false; 
  bool isIsolated     = muon.parameter(muonParameters::etcone40) < 10.0*GeV;

  /** combined track - look at ratio of pt's */
  double pRatio = 0.0;
  if ( muon.isCombinedMuon() ) {
    const TrackParticle * extrapolatedTrack  = muon.muonExtrapolatedTrackParticle();
    const TrackParticle * innerDetectorTrack = muon.inDetTrackParticle();
    pRatio = extrapolatedTrack->p() / innerDetectorTrack->p();
  }
  bool goodRatio = fabs(pRatio-1.0) < 0.20;

  /** common tests for all muon candidates */
  bool commonTest = goodPt && fitChi2 && isIsolated;

  /** standalone muon outside Inner Detector accpetance */
  bool isStandAlone = muon.isStandAloneMuon() && commonTest && fabs(muon.eta()) > 2.5;

  /** lowPt candidates not picked up but the normal reconstruction */
  bool isLowPt      = muon.isLowPt() && commonTest && goodInDetTrack;

  /** successfully combined Muon Spectrometer tracks with Inner Detector tracks */
  bool isCombined   = isBestMatch && commonTest && goodInDetTrack && goodRatio && matchChi2;

  /** for best efficiency, select all types of non-overlapping muons */
  isSelected = isCombined || isStandAlone || isLowPt;

  return isSelected;
}

/** TauJet selection */
bool AnalysisSkeleton::selectTauJet        ( const TauJet& tauJet )
{
  bool isSelected = true;

  bool goodPt            = tauJet.pt() > 20.0*GeV;
  int ntracks            = tauJet.numTrack();
  bool oneThreePrung     = ntracks == 1 || ntracks == 3;
  bool likelihood        = tauJet.parameter(tauJetParameters::logLikelihoodRatio) > -6;
  bool goodCharge        = fabs( tauJet.charge() ) == 1;
  bool isolationFraction = tauJet.parameter(tauJetParameters::isolationFraction) > 0;
  double pti = tauJet.parameter(tauJetParameters::etEMCalib)+
    tauJet.parameter(tauJetParameters::etHadCalib);
  bool hadronicFraction  = tauJet.parameter(tauJetParameters::etHadCalib) > 0.10*pti;

  isSelected = goodPt && oneThreePrung && likelihood && goodCharge && hadronicFraction && isolationFraction;
 
  return isSelected;
}

/** Jet selection */
bool AnalysisSkeleton::selectParticleJet   ( const ParticleJet& jet )
{
  bool isSelected = true;
 
  bool goodPt = jet.pt() > 15.0*GeV;

  /** total hadronic sampling energy fraction */
  const JetConstituent jc = jet.jetConstituent(); 
  double etem  = 0.0;
  double ethad = 0.0;
  CaloSampling caloSampling;
  for (unsigned int i=0; i<CaloSampling::Unknown; i++){
    CaloSampling::CaloSample sample = static_cast<CaloSampling::CaloSample>(i);
    if ( caloSampling.isEMSampling( sample ) )  etem  += jc.energyInSample( sample ); 
    if ( caloSampling.isHADSampling( sample ) ) ethad += jc.energyInSample( sample ); 
  }
  bool goodSamplingFraction = ( ethad/(etem+ethad) ) > 0.10;

  isSelected = goodPt && goodSamplingFraction;
  
  return isSelected;
}

/** b-tagged jet selection */
bool AnalysisSkeleton::selectBTaggedJet   ( const ParticleJet& jet )
{
  bool isSelected = false;

  bool taggingWeight = jet.weight() > 0.90; 

  isSelected = taggingWeight;

  return isSelected;
}

/** Track isolation */
bool AnalysisSkeleton::isTrackIsolated     ( const TrackParticle& track )
{
  bool isIsolated = true;

  bool isolationPt = 0.0;

  double deltaR = 0.2;
  std::vector<TrackParticle>::const_iterator trackItr  = m_innerDetTrack->begin();
  std::vector<TrackParticle>::const_iterator trackItrE = m_innerDetTrack->end();
  for (; trackItr != trackItrE; ++trackItr) {
    double thisDeltaR = track.hlv().DeltaR ( (*trackItr).hlv() );
    if ( thisDeltaR < deltaR ) isolationPt += (*trackItr).pt();
  }
  isolationPt -= track.pt();

  isIsolated = isolationPt < 10*GeV;

  return isIsolated;

}

/** remove the overlaps and construct non-overlapping containers 
    the user may customize this, changing the order of the overlap
    removal. This methods will create the non-overlapping collections
    called:

    m_nonOverlappingPhoton
    m_nonOverlappingElectron
    m_nonOverlappingMuon 
    m_nonOverlappingTauJet
    M_nonOverlappingParticleJet

*/
void AnalysisSkeleton::removeOverlaps(Long64_t entry) 
{

  /** clear the containers */
  this->clear();

  /** we start with the muons, the combined muons, that is, the muons with
      Muon Spectrometer track matched successfully to Inner Detector track 
      with good matching criteria. And also the lowPt muons We will come back 
      to the standalone */
  this->muonOverlaps();
  
  /** now we check the photons. First we check for deltaR overlaps with muons, then
      we check that for converted photons, the converted tracks are not already used
      in muon combined reconstruction */
  this->photonOverlaps();

  /** now we get to the electrons. We check first for deltaR overlaps with muons and photons.
      Then we check that the electron track has not already been used in the combined muon 
      reconstruction and that the electron is not from a converted photon. By construction, 
      from the egamma reconstruction, the electron and photon do not overlap with the 
      requirement of track-match (electron) or not (photon) to a CaloCluster: we therefore
      do not check the electron/photon cluster overlap anymore */
  this->electronOverlaps();

  /** now the tauJet. We do the same thing: deltaR overlap checking first with the previous collections
      then checking that the tauJet tracks and caloCluster are not already used */
  this->tauJetOverlaps();

  /** now the particleJets. We check that the muon, electron, photon, tauJet tracks and clusters are
      not constutients of Jets and that the electron and the muon are not contituents of jets */
  this->particleJetOverlaps();

  /** finally, the standalone muon overlaps - these are muon outside the Inner Detector acceptance
      check that they do not overlap with jets or they are not constituents of jets */
  this->standAloneMuonOverlaps();

  /** sanity check */
  if ( entry < 100 ) {
    std::cout << "/**************************** Event Number " << entry << std::endl;
    std::cout << "Total Muons, Selected Muons, Non overlapping Muons             = " << m_muon->size() << " " << m_nmuons << " " << m_nonOverlappingMuon->size() << std::endl;
    std::cout << "Total Photons, Selected Photons, Non overlapping Photons       = " << m_photon->size() << " " << m_nphotons << " " << m_nonOverlappingPhoton->size() << std::endl;
    std::cout << "Total Electrons, Selected Electrons, Non overlapping Electrons = " << m_electron->size() << " " << m_nelectrons << " " << m_nonOverlappingElectron->size() << std::endl;
    std::cout << "Total TauJets, Selected TauJets, Non overlapping TauJets       = " << m_tauJet->size() << " " << m_ntauJets << " " << m_nonOverlappingTauJet->size() << std::endl;
    std::cout << "Total Jets, Selected Jets, Non overlapping Jets                = " << m_particleJet->size() << " " << m_njets << " " << m_nonOverlappingParticleJet->size() << std::endl;
    std::cout << " " << std::endl;
  }
}

/** clear the containers for the next event */
void AnalysisSkeleton::clear() 
{
  m_nonOverlappingPhoton->clear();
  m_nonOverlappingElectron->clear();
  m_nonOverlappingMuon->clear();
  m_nonOverlappingTauJet->clear();
  m_nonOverlappingParticleJet->clear();

  m_nmuons      = 0;
  m_nelectrons  = 0;
  m_nphotons    = 0;
  m_ntauJets    = 0;
  m_njets       = 0;
}

/** the muons are the first objects to be tested */
void AnalysisSkeleton::muonOverlaps() 
{
   std::vector<Muon>::const_iterator muonItr  = m_muon->begin();
   std::vector<Muon>::const_iterator muonItrE = m_muon->end();
   for (; muonItr != muonItrE; ++muonItr) {
     bool isSelected = this->selectMuon(*muonItr);
     if ( isSelected ) m_nmuons++; 
     if ( isSelected && !(*muonItr).isStandAloneMuon() ) 
       m_nonOverlappingMuon->push_back( *muonItr );
   }
}

/** now we deal with the photon. By default, the photons do not overlap with
    the electron by the requirements of !trackMatch during AOD making */
void AnalysisSkeleton::photonOverlaps() 
{
   std::vector<Photon>::const_iterator photonItr  = m_photon->begin();
   std::vector<Photon>::const_iterator photonItrE = m_photon->end();
   for (; photonItr != photonItrE; ++photonItr) {
     bool isSelected = this->selectPhoton(*photonItr);
     if ( isSelected ) m_nphotons++;
     if ( !isSelected ) continue;

     /** check for non deltaR overlap with the Muon - this should already be the case 
	 isolated photon. Check also that for converted photons, the converted tracks
	 are not used by the muons */
     if ( m_nonOverlappingMuon->size() == 0 ) {
       m_nonOverlappingPhoton->push_back( *photonItr );
       continue;
     }
     
     /** deltaR photon/muon and check of overlapping tracks (converted photons) */ 
     const TrackParticle * track1 = (*photonItr).track(0);
     const TrackParticle * track2 = (*photonItr).track(1);
     bool checkDeltaR = true;
     bool checkTrack  = true;
     std::vector<Muon>::const_iterator muonItr  = m_nonOverlappingMuon->begin();
     std::vector<Muon>::const_iterator muonItrE = m_nonOverlappingMuon->end();
     for (; muonItr != muonItrE; ++muonItr) {
       double deltaR = (*photonItr).hlv().DeltaR( (*muonItr).hlv() );
       if (deltaR < OverlapDeltaR) checkDeltaR = false;
       const TrackParticle * muonTrack = (*muonItr).inDetTrackParticle();
       if ( track1 == muonTrack || track2 == muonTrack ) checkTrack = false;
       if ( checkDeltaR == false || checkTrack == false ) break;
     }
     if ( checkDeltaR && checkTrack) m_nonOverlappingPhoton->push_back( *photonItr );
   }
}

/** now we deal with the electron Check that there is no overlap with muons and photons
    and that the electron track is not by the muon reconstruction, and that the electron
    is not from a converted photon */
void AnalysisSkeleton::electronOverlaps()
{
   std::vector<Electron>::const_iterator electronItr  = m_electron->begin();
   std::vector<Electron>::const_iterator electronItrE = m_electron->end();
   for (; electronItr != electronItrE; ++electronItr) {
     bool isSelected = this->selectElectron(*electronItr);
     if ( isSelected ) m_nelectrons++;
     if ( !isSelected ) continue;
     if ( m_nonOverlappingPhoton->size() == 0 && m_nonOverlappingMuon->size() == 0 ) {
       m_nonOverlappingElectron->push_back( *electronItr );
       continue;
     }

     /** DeltaR electron/muon and check for overlapping track */
     const TrackParticle * track = (*electronItr).track();
     bool muonDeltaR = true;
     bool muonTrack  = true;
     std::vector<Muon>::const_iterator muonItr  = m_nonOverlappingMuon->begin();
     std::vector<Muon>::const_iterator muonItrE = m_nonOverlappingMuon->end();
     for (; muonItr != muonItrE; ++muonItr) {
       double deltaR = (*electronItr).hlv().DeltaR( (*muonItr).hlv() );
       if (deltaR < OverlapDeltaR) muonDeltaR = false;
       const TrackParticle * muonTrack = (*muonItr).inDetTrackParticle();
       if ( track == muonTrack ) muonTrack = false;
       if ( muonDeltaR == false || muonTrack == false ) break;
     }

     /** DeltaR electron/photon - check for overlapping track and caloCluster */
     bool photonDeltaR  = true;
     bool photonTrack   = true;
     std::vector<Photon>::const_iterator photonItr  = m_nonOverlappingPhoton->begin();
     std::vector<Photon>::const_iterator photonItrE = m_nonOverlappingPhoton->end();
     for (; photonItr != photonItrE; ++photonItr) {
       double deltaR = (*electronItr).hlv().DeltaR( (*photonItr).hlv() );
       if (deltaR < OverlapDeltaR) photonDeltaR = false;
       const TrackParticle * photonTrack1 = (*photonItr).track(0);
       const TrackParticle * photonTrack2 = (*photonItr).track(1);
       if ( track == photonTrack1 || track == photonTrack2 ) photonTrack = false;
       if ( photonDeltaR == false || photonTrack == false ) break;
     }
     if ( photonDeltaR && photonTrack && muonDeltaR && muonTrack ) 
       m_nonOverlappingElectron->push_back( *electronItr ); 
   }
}

/** now we deal with the tauJet. Check that there is no overlap with muons, photons
    and electrons, and that the tauJet tracks and caloCluster are not used by the 
    muon reconstruction, the electron reconstruction and that tauJet tracks  are not 
    from a converted photon */
void AnalysisSkeleton::tauJetOverlaps()
{
   std::vector<TauJet>::const_iterator tauJetItr  = m_tauJet->begin();
   std::vector<TauJet>::const_iterator tauJetItrE = m_tauJet->end();
   for (; tauJetItr != tauJetItrE; ++tauJetItr) {
     bool isSelected = this->selectTauJet(*tauJetItr);
     if ( isSelected ) m_ntauJets++;
     if ( !isSelected ) continue;
     if ( m_nonOverlappingPhoton->size() == 0 && m_nonOverlappingMuon->size() == 0 
	  && m_nonOverlappingElectron->size() == 0 ) {
       m_nonOverlappingTauJet->push_back( *tauJetItr );
       continue;
     }

     /** number of tauJet Tracks */
     int numTrack = (*tauJetItr).numTrack();

     /** DeltaR tauJet/muon and check for overlapping track */
     bool muonDeltaR = true;
     bool muonTrack  = true;
     for (int i=0; i<numTrack; ++i) {
       const TrackParticle * track = (*tauJetItr).track(i);
       std::vector<Muon>::const_iterator muonItr  = m_nonOverlappingMuon->begin();
       std::vector<Muon>::const_iterator muonItrE = m_nonOverlappingMuon->end();
       for (; muonItr != muonItrE; ++muonItr) {
	 double deltaR = (*tauJetItr).hlv().DeltaR( (*muonItr).hlv() );
	 if (deltaR < OverlapDeltaR) muonDeltaR = false;
	 const TrackParticle * muonTrack = (*muonItr).inDetTrackParticle();
	 if ( track == muonTrack ) muonTrack = false;
	 if ( muonDeltaR == false || muonTrack == false ) break;
       }
       if ( muonDeltaR == false || muonTrack == false ) break;
     }

     /** DeltaR tauJet/photon - check for overlapping track and caloCluster */
     bool photonDeltaR  = true;
     bool photonTrack   = true;
     for (int i=0; i<numTrack; ++i) {
       const TrackParticle * track = (*tauJetItr).track(i);
       std::vector<Photon>::const_iterator photonItr  = m_nonOverlappingPhoton->begin();
       std::vector<Photon>::const_iterator photonItrE = m_nonOverlappingPhoton->end();
       for (; photonItr != photonItrE; ++photonItr) {
	 double deltaR = (*tauJetItr).hlv().DeltaR( (*photonItr).hlv() );
	 if (deltaR < OverlapDeltaR) photonDeltaR = false;
	 const TrackParticle * photonTrack1 = (*photonItr).track(0);
	 const TrackParticle * photonTrack2 = (*photonItr).track(1);
	 if ( track == photonTrack1 || track == photonTrack2 ) photonTrack = false;
	 if ( photonDeltaR == false || photonTrack == false ) break;
       }
       if ( photonDeltaR == false || photonTrack == false ) break;
     }

     /** DeltaR tauJet/electron - check for overlapping track and caloCluster */
     bool electronDeltaR  = true;
     bool electronTrack   = true;
     for (int i=0; i<numTrack; ++i) {
       const TrackParticle * track = (*tauJetItr).track(i);
       std::vector<Electron>::const_iterator electronItr  = m_nonOverlappingElectron->begin();
       std::vector<Electron>::const_iterator electronItrE = m_nonOverlappingElectron->end();
       for (; electronItr != electronItrE; ++electronItr) {
	 double deltaR = (*tauJetItr).hlv().DeltaR( (*electronItr).hlv() );
	 if (deltaR < OverlapDeltaR) electronDeltaR = false;
	 const TrackParticle * elecTrack = (*electronItr).track();
	 if ( track == elecTrack ) electronTrack = false;
	 if ( electronDeltaR == false || electronTrack == false ) break;
       }
       if ( electronDeltaR == false || electronTrack == false ) break;
     }

     /** check for tauJet/Electron clusters - tauJet/photon cluster check not necessary
	 since electron/photon do not overlap and the TauJet cluster is required to has
         associated tracks */
     double clusterCheck = true;
     const CaloCluster * tauCluster = (*tauJetItr).cluster();
     std::vector<Electron>::const_iterator electronItr  = m_nonOverlappingElectron->begin();
     std::vector<Electron>::const_iterator electronItrE = m_nonOverlappingElectron->end();
     for (; electronItr != electronItrE; ++electronItr) {
       const CaloCluster * electronCluster = (*electronItr).cluster();
       double deltaR = this->deltaR( tauCluster, electronCluster );
       if ( deltaR < OverlapDeltaR || tauCluster == electronCluster ) clusterCheck = false;
       if ( !clusterCheck ) break;
     }

     /** save this non overlapping tauJet */
     if ( muonDeltaR && muonTrack && photonDeltaR && photonTrack && electronDeltaR && electronTrack
	  && clusterCheck ) m_nonOverlappingTauJet->push_back( *tauJetItr );
   }
}

/** now to deal with the jets - check for deltaR overlaps with all the above: 
    electron, photon, muon and tauJet. Check also that electron, photon, muon, 
    tauJet tracks are not in jets - same for clusters, and also that electron 
    and muon are not constituents of jets */
void AnalysisSkeleton::particleJetOverlaps() 
{
   std::vector<ParticleJet>::const_iterator jetItr  = m_particleJet->begin();
   std::vector<ParticleJet>::const_iterator jetItrE = m_particleJet->end();
   for (; jetItr != jetItrE; ++jetItr) {
     bool isSelected = this->selectParticleJet(*jetItr);
     if ( isSelected ) m_njets++;
     if ( !isSelected ) continue;
     if ( m_nonOverlappingPhoton->size() == 0 && m_nonOverlappingMuon->size() == 0 
	  && m_nonOverlappingElectron->size() == 0 && m_nonOverlappingTauJet->size() == 0 ) {
       m_nonOverlappingParticleJet->push_back( *jetItr );
       continue;
     }

     /** DeltaR particleJet/muon */
     bool muonDeltaR = true;
     std::vector<Muon>::const_iterator muonItr  = m_nonOverlappingMuon->begin();
     std::vector<Muon>::const_iterator muonItrE = m_nonOverlappingMuon->end();
     for (; muonItr != muonItrE; ++muonItr) {
       double deltaR = (*jetItr).hlv().DeltaR( (*muonItr).hlv() );
       if (deltaR < OverlapDeltaR) muonDeltaR = false;
       if ( !muonDeltaR ) break;
     }
     if ( !muonDeltaR ) continue;

     /** DeltaR particleJet/electron */
     bool elecDeltaR = true;
     std::vector<Electron>::const_iterator elecItr  = m_nonOverlappingElectron->begin();
     std::vector<Electron>::const_iterator elecItrE = m_nonOverlappingElectron->end();
     for (; elecItr != elecItrE; ++elecItr) {
       double deltaR = (*jetItr).hlv().DeltaR( (*elecItr).hlv() );
       if (deltaR < OverlapDeltaR) elecDeltaR = false;
       if ( !elecDeltaR ) break;
     }
     if ( !elecDeltaR ) continue;

     /** DeltaR particleJet/photon */
     bool photDeltaR = true;
     std::vector<Photon>::const_iterator photItr  = m_nonOverlappingPhoton->begin();
     std::vector<Photon>::const_iterator photItrE = m_nonOverlappingPhoton->end();
     for (; photItr != photItrE; ++photItr) {
       double deltaR = (*jetItr).hlv().DeltaR( (*photItr).hlv() );
       if (deltaR < OverlapDeltaR) photDeltaR = false;
       if ( !photDeltaR ) break;
     }
     if ( !photDeltaR ) continue;

     /** DeltaR particleJet/tauJet */
     bool tauDeltaR = true;
     std::vector<TauJet>::const_iterator tauItr  = m_nonOverlappingTauJet->begin();
     std::vector<TauJet>::const_iterator tauItrE = m_nonOverlappingTauJet->end();
     for (; tauItr != tauItrE; ++tauItr) {
       double deltaR = (*jetItr).hlv().DeltaR( (*tauItr).hlv() );
       if (deltaR < OverlapDeltaR) tauDeltaR = false;
       if ( !tauDeltaR ) break;
     }
     if ( !tauDeltaR ) continue;

     /** check for overlap in track constituents */
     bool trackCheck = true;
     const TrackConstituents trackC = (*jetItr).trackConstituents();
     std::vector<const TrackParticle*>* theTracks = trackC.tracks();
     std::vector<const TrackParticle*>::const_iterator trackItr  = theTracks->begin();
     std::vector<const TrackParticle*>::const_iterator trackItrE = theTracks->end();
     for (; trackItr != trackItrE; ++trackItr ) {

       std::vector<Muon>::const_iterator muonItr  = m_nonOverlappingMuon->begin();
       std::vector<Muon>::const_iterator muonItrE = m_nonOverlappingMuon->end();
       for (; muonItr != muonItrE; ++muonItr) {
	 const TrackParticle * muonTrack = (*muonItr).inDetTrackParticle();
	 if ( muonTrack == *trackItr ) {
	   trackCheck = false;
	   break;
	 }
       }
       if ( !trackCheck ) break;

       std::vector<Electron>::const_iterator elecItr  = m_nonOverlappingElectron->begin();
       std::vector<Electron>::const_iterator elecItrE = m_nonOverlappingElectron->end();
       for (; elecItr != elecItrE; ++elecItr) {
	 const TrackParticle * elecTrack = (*elecItr).track();
	 if ( elecTrack == *trackItr ) {
	   trackCheck = false;
	   break;
	 }
       }
       if ( !trackCheck ) break;

       std::vector<Photon>::const_iterator photItr  = m_nonOverlappingPhoton->begin();
       std::vector<Photon>::const_iterator photItrE = m_nonOverlappingPhoton->end();
       for (; photItr != photItrE; ++photItr) {
	 const TrackParticle * track1 = (*photItr).track(0);
	 const TrackParticle * track2 = (*photItr).track(1);
	 if ( track1 == *trackItr || track2 == *trackItr ) {
	   trackCheck = false;
	   break;
	 }
       }
       if ( !trackCheck ) break;

       std::vector<TauJet>::const_iterator tauItr  = m_nonOverlappingTauJet->begin();
       std::vector<TauJet>::const_iterator tauItrE = m_nonOverlappingTauJet->end();
       for (; tauItr != tauItrE; ++tauItr) {
	 int numTrack = (*tauItr).numTrack();
	 for (int i=0; i<numTrack; ++i) {
	   const TrackParticle * track = (*tauItr).track(i);
	   if ( track == *trackItr ) {
	     trackCheck = false;
	     break;
	   }
	 }
	 if ( !trackCheck ) break;
       }
       if ( !trackCheck ) break;
     }
     if ( !trackCheck ) continue;

     /** now check for cluster overlaps */
     bool clusterCheck = true;
     const CaloClusterConstituents clusterC = (*jetItr).clusterConstituents();
     std::vector<const CaloCluster*>* theClusters = clusterC.clusters();
     std::vector<const CaloCluster*>::const_iterator clusterItr  = theClusters->begin();
     std::vector<const CaloCluster*>::const_iterator clusterItrE = theClusters->end();
     for (; clusterItr != clusterItrE; ++clusterItr ) {

       std::vector<Electron>::const_iterator elecItr  = m_nonOverlappingElectron->begin();
       std::vector<Electron>::const_iterator elecItrE = m_nonOverlappingElectron->end();
       for (; elecItr != elecItrE; ++elecItr) {
	 const CaloCluster * elecCluster = (*elecItr).cluster();
	 double dR = this->deltaR( (*clusterItr), elecCluster );
	 if ( elecCluster == (*clusterItr) || dR < OverlapDeltaR ) {
	   clusterCheck = false;
	   break;
	 }
       }
       if ( !clusterCheck ) break;

       std::vector<Photon>::const_iterator photItr  = m_nonOverlappingPhoton->begin();
       std::vector<Photon>::const_iterator photItrE = m_nonOverlappingPhoton->end();
       for (; photItr != photItrE; ++photItr) {
	 const CaloCluster * photCluster = (*photItr).cluster();
	 double dR = this->deltaR( (*clusterItr), photCluster );
	 if ( photCluster == (*clusterItr) || dR < OverlapDeltaR ) {
	   clusterCheck = false;
	   break;
	 }
       }
       if ( !clusterCheck ) break;

       std::vector<TauJet>::const_iterator tauItr  = m_nonOverlappingTauJet->begin();
       std::vector<TauJet>::const_iterator tauItrE = m_nonOverlappingTauJet->end();
       for (; tauItr != tauItrE; ++tauItr) {
	 const CaloCluster * tauCluster = (*tauItr).cluster();
	 double dR = this->deltaR( (*clusterItr), tauCluster );
	 if ( tauCluster == (*clusterItr) || dR < OverlapDeltaR ) {
	   clusterCheck = false;
	   break;
	 }
       }
       if ( !clusterCheck ) break;

     }

     if ( !clusterCheck ) continue;

     /** save this non overlapping jet */
     m_nonOverlappingParticleJet->push_back( *jetItr );
   }
}

/** add the standalone muon tracks that are non-overlapping in the abs(eta) > 2.5,
    that is outside the Inner Detector acceptance */
void AnalysisSkeleton::standAloneMuonOverlaps()
{
  std::vector<Muon>::const_iterator muonItr  = m_muon->begin();
  std::vector<Muon>::const_iterator muonItrE = m_muon->end();
  for (; muonItr != muonItrE; ++muonItr) {
    bool jetDeltaR = true;
    if ( this->selectMuon(*muonItr) && (*muonItr).isStandAloneMuon() && fabs((*muonItr).eta()) > 2.5 ) {
      std::vector<ParticleJet>::const_iterator jetItr  = m_nonOverlappingParticleJet->begin();
      std::vector<ParticleJet>::const_iterator jetItrE = m_nonOverlappingParticleJet->end();
      for (; jetItr != jetItrE; ++jetItr) {
	double deltaR = (*muonItr).hlv().DeltaR( (*jetItr).hlv() );
	if (deltaR < OverlapDeltaR) jetDeltaR = false;
	if ( !jetDeltaR ) break;
      }
    } else jetDeltaR = false;
    if ( jetDeltaR ) m_nonOverlappingMuon->push_back( *muonItr );
  }
}

/** simple tools for deltaR */
double AnalysisSkeleton::deltaR ( const IParticle * particle1, const IParticle * particle2 ) 
{
  if ( particle1 && particle2 ) return this->deltaR( *particle1, *particle2 );
  else return 9999999.0;
}

/** simple tool for deltaR */
double AnalysisSkeleton::deltaR ( const IParticle & particle1, const IParticle & particle2 )
{
  double deta = particle1.eta() - particle2.eta();
  double dphi = particle1.phi() - particle2.phi();
  double dR = sqrt( deta*deta + dphi*dphi );
  return dR;
}

