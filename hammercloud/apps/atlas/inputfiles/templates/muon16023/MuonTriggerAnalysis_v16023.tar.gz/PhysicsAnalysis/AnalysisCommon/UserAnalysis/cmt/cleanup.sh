if test "${CMTROOT}" = ""; then
  CMTROOT=/opt/atlas/software/manageTier3SW/ATLASLocalRootBase/Athena/i686_slc5_gcc43_opt/16.0.2/CMT/v1r22; export CMTROOT
fi
. ${CMTROOT}/mgr/setup.sh
cmtUserAnalysistempfile=`${CMTROOT}/mgr/cmt -quiet build temporary_name`
if test ! $? = 0 ; then cmtUserAnalysistempfile=/tmp/cmt.$$; fi
${CMTROOT}/mgr/cmt cleanup -sh -pack=UserAnalysis -version=UserAnalysis-00-10-12 -path=/data/etp2/elmsheus/athena/16.0.2.3/PhysicsAnalysis/AnalysisCommon $* >${cmtUserAnalysistempfile}
if test $? != 0 ; then
  echo >&2 "${CMTROOT}/mgr/cmt cleanup -sh -pack=UserAnalysis -version=UserAnalysis-00-10-12 -path=/data/etp2/elmsheus/athena/16.0.2.3/PhysicsAnalysis/AnalysisCommon $* >${cmtUserAnalysistempfile}"
  cmtcleanupstatus=2
  /bin/rm -f ${cmtUserAnalysistempfile}
  unset cmtUserAnalysistempfile
  return $cmtcleanupstatus
fi
cmtcleanupstatus=0
. ${cmtUserAnalysistempfile}
if test $? != 0 ; then
  cmtcleanupstatus=2
fi
/bin/rm -f ${cmtUserAnalysistempfile}
unset cmtUserAnalysistempfile
return $cmtcleanupstatus

