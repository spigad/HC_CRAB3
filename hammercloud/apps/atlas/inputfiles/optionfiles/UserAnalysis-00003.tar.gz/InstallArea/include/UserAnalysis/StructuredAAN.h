#ifndef USERANALYSIS_STRUCTUREDAAN_H
#define USERANALYSIS_STRUCTUREDAAN_H
/////////////////////////////////////////////////////////////////////////////////////////////////////
/// Name    : StructuredNTuple.h
/// Package : offline/PhysicsAnalysis/AnalysisCommon/UserAnalysis
/// Author  : Ketevi A. Assamagan
/// Created : August 2006
///
/// DESCRIPTION:
///   Create Structured ATHENA-Aware NTuple
///
///////////////////////////////////////////////////////////////////////////////////////////////////////

#include "GaudiKernel/Algorithm.h"

#include <string>
#include <vector>

class UserSANToolBase;

class StructuredAAN : public Algorithm  {

 public:

   StructuredAAN(const std::string& name, ISvcLocator* pSvcLocator);
   ~StructuredAAN();

   virtual StatusCode initialize();
   virtual StatusCode finalize();
   virtual StatusCode execute();

 private:

   /** tool instance names and list */
   std::vector<std::string>      m_toolNames;      
   std::vector<UserSANToolBase*> m_tools;
};

#endif // USERANALYSIS_STRUCTUREDAAN_H

