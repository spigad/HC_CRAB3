ServiceMgr.EventSelector.InputCollections = [ '/tmp/elmsheus/mc08.106021.PythiaWmunu_1Lepton.recon.AOD.e352_s462_r541_tid025934/AOD.025934._00029.pool.root.1',
                                              'AOD.025934._00098.pool.root.1',
                                              'AOD.025934._00135.pool.root.1',  'AOD.025934._00196.pool.root.1',
                                              
..                             AOD.025934._00039.pool.root.1  AOD.025934._00099.pool.root.1  AOD.025934._00156.pool.root.1  AOD.025934._00204.pool.root.1
AOD.025934._00006.pool.root.1  AOD.025934._00063.pool.root.1  AOD.025934._00104.pool.root.1  AOD.025934._00161.pool.root.1  AOD.025934._00227.pool.root.1
AOD.025934._00013.pool.root.1  AOD.025934._00064.pool.root.1  AOD.025934._00116.pool.root.1  AOD.025934._00177.pool.root.1
AOD.025934._00028.pool.root.1  AOD.025934._00077.pool.root.1  AOD.025934._00117.pool.root.1  AOD.025934._00180.pool.root.1' ]
