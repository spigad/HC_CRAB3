#include <sstream>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>

#include "TTree.h"
#include "TString.h"
#include "TCanvas.h"
#include "TKey.h"
#include "TFile.h"
#include "TStreamerInfo.h"

void PrintFileInfo(TFile * f);

void checkfile (TString fileName)
{
  TFile * f = TFile::Open(fileName);
  PrintFileInfo(f);
  TIter next(f->GetListOfKeys());
  TKey *key;
  std::cout.width(7); std::cout << " Events";
      std::cout.setf(std::ios::right);
      std::cout.setf(std::ios::fixed);

  std::cout.width(20); std::cout << "Size(mem) kB"; 
  std::cout.width(20); std::cout << "Size(zip) kB"; 
  std::cout.unsetf(std::ios::right);
  std::cout.unsetf(std::ios::fixed);
  std::cout << "\t\t Name of Object" << std::endl; 

  while ((key=(TKey*)next()))
  {
    key=(TKey*)next();
      //std::cout << key->GetName() << " \t \t " 
    //<< key->GetObjlen() << "  ";
    //std::cout << key->GetNbytes() << "  " << key->Sizeof() << std::endl;
    //TObject * ob = key->ReadObj();
    TTree * tt = (TTree*)key->ReadObj();
    TString tempName=key->GetName();
    if (tt!=0 &&  tempName.Sizeof()>12 )  
    {
      TString keyName=tempName(14,40);
      std::cout.width(7); std::cout << tt->GetEntries();
      std::cout.setf(std::ios::right);
      std::cout.setf(std::ios::fixed);
      std::cout.precision(3);
      std::cout.width(20); std::cout << tt->GetTotBytes()/1000.;
      std::cout.width(20); std::cout << tt->GetZipBytes()/1000.;
      std::cout.unsetf(std::ios::right);
      std::cout.unsetf(std::ios::fixed);
      std::cout << "\t\t" << keyName << std::endl;
    }
  }
//   TList *list = f.GetStreamerInfoList();
//   list->Print();
//   TStreamerInfo *info;
//   info = (TStreamerInfo*)list->FindObject("Trk::CovarianceMatrix");
//   if (info!=0) 
//   {
//       info->ComputeSize();
//     std::cout << "Size of Object : " << info->GetSize() << std::endl;
//     std::cout << "Size of Element : " << info->GetSizeElements() << std::endl;
//   }
//   info = (TStreamerInfo*)list->FindObject("Hep3Vector");
//   if (info!=0) 
//   {
//     std::cout << "Size of Object : " << info->GetSize() << std::endl;
//     std::cout << "Size of Element : " << info->GetSizeElements() << std::endl;
//   }
//   delete list;
  f->Close();
  return;
}

void PrintFileInfo(TFile * f)
{
    std::cout << "File " << f->GetName() << " has " << f->GetSize() << " Bytes." << std::endl;
    std::cout << "Compression factor is " << f->GetCompressionFactor();
    std::cout << " and a compression level of " << f->GetCompressionLevel() << " " << std::endl;
     std::cout << std::endl; 
    return;
}


