#Tue Sep 15 09:41:56 2009
"""Automatically generated. DO NOT EDIT please"""
from GaudiKernel.Proxy.Configurable import *

class MuAnalysis( ConfigurableAlgorithm ) :
  __slots__ = { 
    'OutputLevel' : 0, # int
    'Enable' : True, # bool
    'ErrorMax' : 1, # int
    'ErrorCount' : 0, # int
    'AuditAlgorithms' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditReinitialize' : False, # bool
    'AuditRestart' : False, # bool
    'AuditExecute' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditBeginRun' : False, # bool
    'AuditEndRun' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'MonitorService' : 'MonitorSvc', # str
    'tilemuon_filler' : 'TileCosmicMuonHT', # str
    'calocell_filler' : 'AllCalo', # str
    'calocluster_filler' : 'LArMuClusterCandidates', # str
    'calomuon_filler' : 'CaloMuonCollection', # str
    'specmuon_filler' : 'StacoMuonCollection', # str
    'MaxLArMuCandidates' : 30, # int
    'OutputFile' : 'output.HIST.root', # str
  }
  _propertyDocDct = { 
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(MuAnalysis, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'CosmicsAnalysis'
  def getType( self ):
      return 'MuAnalysis'
  pass # class MuAnalysis
