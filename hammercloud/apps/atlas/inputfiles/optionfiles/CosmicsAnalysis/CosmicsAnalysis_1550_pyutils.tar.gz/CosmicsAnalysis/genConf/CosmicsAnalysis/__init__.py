## Hook for CosmicsAnalysis genConf module
