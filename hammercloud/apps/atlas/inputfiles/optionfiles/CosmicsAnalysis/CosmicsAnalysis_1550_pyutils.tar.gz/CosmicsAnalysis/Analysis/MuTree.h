//////////////////////////////////////////////////////////
// This class has been automatically generated on
// Tue Jun 16 09:27:51 2009 by ROOT version 5.22/00
// from TTree MuTree/MuTTree
// found on file: P_E_RunOutput_IDCosmic.root
//////////////////////////////////////////////////////////

#ifndef MuTree_h
#define MuTree_h

#include <TROOT.h>
#include <TChain.h>
#include <TFile.h>

class MuTree {
public :
   TTree          *fChain;   //!pointer to the analyzed TTree or TChain
   Int_t           fCurrent; //!current Tree number in a TChain

   // Declaration of leaf types
   vector<double>  *MuSpecP;
   vector<double>  *MuCombinedP;
   vector<double>  *MuInDetP;
   vector<double>  *MuSpec_pt;
   vector<double>  *MuCombined_pt;
   vector<double>  *MuInDet_pt;
   Int_t           nEvent;
   Int_t           MuOriginal_n;
   Int_t           TileMu_n;
   Int_t           MuSpec_n;
   Int_t           MuComb_n;
   Int_t           MuInDet_n;
   vector<double>  *MuSpec_phi;
   vector<double>  *MuInDet_phi;
   vector<double>  *MuComb_phi;
   vector<double>  *MuSpec_eta;
   vector<double>  *MuInDet_eta;
   vector<double>  *MuComb_eta;
   vector<double>  *MuSpec_E;
   vector<double>  *MuInDet_E;
   vector<double>  *MuComb_E;
   vector<double>  *MuSpec_perigee_x;
   vector<double>  *MuInDet_perigee_x;
   vector<double>  *MuComb_perigee_x;
   vector<double>  *MuSpec_perigee_y;
   vector<double>  *MuInDet_perigee_y;
   vector<double>  *MuComb_perigee_y;
   vector<double>  *MuSpec_perigee_z;
   vector<double>  *MuInDet_perigee_z;
   vector<double>  *MuComb_perigee_z;
   vector<double>  *MuOriginal_P;
   vector<double>  *MuOriginal_phi;
   vector<double>  *MuOriginal_eta;
   vector<double>  *MuOriginal_x;
   vector<double>  *MuOriginal_y;
   vector<double>  *MuOriginal_z;
   vector<double>  *MuSpec_eloss;
   vector<double>  *Tile_E;
   vector<double>  *Tile_Path;
   vector<double>  *Tile_Phi;
   vector<double>  *Tile_Theta;
   vector<double>  *Tile_x;
   vector<double>  *Tile_y;
   vector<double>  *Tile_z;

   // List of branches
   TBranch        *b_MuSpecP;   //!
   TBranch        *b_MuCombinedP;   //!
   TBranch        *b_MuInDetP;   //!
   TBranch        *b_MuSpec_pt;   //!
   TBranch        *b_MuCombined_pt;   //!
   TBranch        *b_MuInDet_pt;   //!
   TBranch        *b_nEvent;   //!
   TBranch        *b_MuOriginal_n;   //!
   TBranch        *b_TileMu_n;   //!
   TBranch        *b_MuSpec_n;   //!
   TBranch        *b_MuComb_n;   //!
   TBranch        *b_MuInDet_n;   //!
   TBranch        *b_MuSpec_phi;   //!
   TBranch        *b_MuInDet_phi;   //!
   TBranch        *b_MuComb_phi;   //!
   TBranch        *b_MuSpec_eta;   //!
   TBranch        *b_MuInDet_eta;   //!
   TBranch        *b_MuComb_eta;   //!
   TBranch        *b_MuSpec_E;   //!
   TBranch        *b_MuInDet_E;   //!
   TBranch        *b_MuComb_E;   //!
   TBranch        *b_MuSpec_perigee_x;   //!
   TBranch        *b_MuInDet_perigee_x;   //!
   TBranch        *b_MuComb_perigee_x;   //!
   TBranch        *b_MuSpec_perigee_y;   //!
   TBranch        *b_MuInDet_perigee_y;   //!
   TBranch        *b_MuComb_perigee_y;   //!
   TBranch        *b_MuSpec_perigee_z;   //!
   TBranch        *b_MuInDet_perigee_z;   //!
   TBranch        *b_MuComb_perigee_z;   //!
   TBranch        *b_MuOriginal_P;   //!
   TBranch        *b_MuOriginal_phi;   //!
   TBranch        *b_MuOriginal_eta;   //!
   TBranch        *b_MuOriginal_x;   //!
   TBranch        *b_MuOriginal_y;   //!
   TBranch        *b_MuOriginal_z;   //!
   TBranch        *b_MuSpec_eloss;   //!
   TBranch        *b_Tile_E;   //!
   TBranch        *b_Tile_Path;   //!
   TBranch        *b_Tile_Phi;   //!
   TBranch        *b_Tile_Theta;   //!
   TBranch        *b_Tile_x;   //!
   TBranch        *b_Tile_y;   //!
   TBranch        *b_Tile_z;   //!

   MuTree(TTree *tree=0);
   virtual ~MuTree();
   virtual Int_t    Cut(Long64_t entry);
   virtual Int_t    GetEntry(Long64_t entry);
   virtual Long64_t LoadTree(Long64_t entry);
   virtual void     Init(TTree *tree);
   virtual void     Loop();
   virtual Bool_t   Notify();
   virtual void     Show(Long64_t entry = -1);
};

#endif

#ifdef MuTree_cxx
MuTree::MuTree(TTree *tree)
{
// if parameter tree is not specified (or zero), connect the file
// used to generate this class and read the Tree.
   if (tree == 0) {
      TFile *f = (TFile*)gROOT->GetListOfFiles()->FindObject("P_E_RunOutput_IDCosmic.root");
      if (!f) {
         f = new TFile("P_E_RunOutput_IDCosmic.root");
      }
      tree = (TTree*)gDirectory->Get("MuTree");

   }
   Init(tree);
}

MuTree::~MuTree()
{
   if (!fChain) return;
   delete fChain->GetCurrentFile();
}

Int_t MuTree::GetEntry(Long64_t entry)
{
// Read contents of entry.
   if (!fChain) return 0;
   return fChain->GetEntry(entry);
}
Long64_t MuTree::LoadTree(Long64_t entry)
{
// Set the environment to read one entry
   if (!fChain) return -5;
   Long64_t centry = fChain->LoadTree(entry);
   if (centry < 0) return centry;
   if (!fChain->InheritsFrom(TChain::Class()))  return centry;
   TChain *chain = (TChain*)fChain;
   if (chain->GetTreeNumber() != fCurrent) {
      fCurrent = chain->GetTreeNumber();
      Notify();
   }
   return centry;
}

void MuTree::Init(TTree *tree)
{
   // The Init() function is called when the selector needs to initialize
   // a new tree or chain. Typically here the branch addresses and branch
   // pointers of the tree will be set.
   // It is normally not necessary to make changes to the generated
   // code, but the routine can be extended by the user if needed.
   // Init() will be called many times when running on PROOF
   // (once per file to be processed).

   // Set object pointer
   MuSpecP = 0;
   MuCombinedP = 0;
   MuInDetP = 0;
   MuSpec_pt = 0;
   MuCombined_pt = 0;
   MuInDet_pt = 0;
   MuSpec_phi = 0;
   MuInDet_phi = 0;
   MuComb_phi = 0;
   MuSpec_eta = 0;
   MuInDet_eta = 0;
   MuComb_eta = 0;
   MuSpec_E = 0;
   MuInDet_E = 0;
   MuComb_E = 0;
   MuSpec_perigee_x = 0;
   MuInDet_perigee_x = 0;
   MuComb_perigee_x = 0;
   MuSpec_perigee_y = 0;
   MuInDet_perigee_y = 0;
   MuComb_perigee_y = 0;
   MuSpec_perigee_z = 0;
   MuInDet_perigee_z = 0;
   MuComb_perigee_z = 0;
   MuOriginal_P = 0;
   MuOriginal_phi = 0;
   MuOriginal_eta = 0;
   MuOriginal_x = 0;
   MuOriginal_y = 0;
   MuOriginal_z = 0;
   MuSpec_eloss = 0;
   Tile_E = 0;
   Tile_Path = 0;
   Tile_Phi = 0;
   Tile_Theta = 0;
   Tile_x = 0;
   Tile_y = 0;
   Tile_z = 0;
   // Set branch addresses and branch pointers
   if (!tree) return;
   fChain = tree;
   fCurrent = -1;
   fChain->SetMakeClass(1);

   fChain->SetBranchAddress("MuSpecP", &MuSpecP, &b_MuSpecP);
   fChain->SetBranchAddress("MuCombinedP", &MuCombinedP, &b_MuCombinedP);
   fChain->SetBranchAddress("MuInDetP", &MuInDetP, &b_MuInDetP);
   fChain->SetBranchAddress("MuSpec_pt", &MuSpec_pt, &b_MuSpec_pt);
   fChain->SetBranchAddress("MuCombined_pt", &MuCombined_pt, &b_MuCombined_pt);
   fChain->SetBranchAddress("MuInDet_pt", &MuInDet_pt, &b_MuInDet_pt);
   fChain->SetBranchAddress("nEvent", &nEvent, &b_nEvent);
   fChain->SetBranchAddress("MuOriginal_n", &MuOriginal_n, &b_MuOriginal_n);
   fChain->SetBranchAddress("TileMu_n", &TileMu_n, &b_TileMu_n);
   fChain->SetBranchAddress("MuSpec_n", &MuSpec_n, &b_MuSpec_n);
   fChain->SetBranchAddress("MuComb_n", &MuComb_n, &b_MuComb_n);
   fChain->SetBranchAddress("MuInDet_n", &MuInDet_n, &b_MuInDet_n);
   fChain->SetBranchAddress("MuSpec_phi", &MuSpec_phi, &b_MuSpec_phi);
   fChain->SetBranchAddress("MuInDet_phi", &MuInDet_phi, &b_MuInDet_phi);
   fChain->SetBranchAddress("MuComb_phi", &MuComb_phi, &b_MuComb_phi);
   fChain->SetBranchAddress("MuSpec_eta", &MuSpec_eta, &b_MuSpec_eta);
   fChain->SetBranchAddress("MuInDet_eta", &MuInDet_eta, &b_MuInDet_eta);
   fChain->SetBranchAddress("MuComb_eta", &MuComb_eta, &b_MuComb_eta);
   fChain->SetBranchAddress("MuSpec_E", &MuSpec_E, &b_MuSpec_E);
   fChain->SetBranchAddress("MuInDet_E", &MuInDet_E, &b_MuInDet_E);
   fChain->SetBranchAddress("MuComb_E", &MuComb_E, &b_MuComb_E);
   fChain->SetBranchAddress("MuSpec_perigee_x", &MuSpec_perigee_x, &b_MuSpec_perigee_x);
   fChain->SetBranchAddress("MuInDet_perigee_x", &MuInDet_perigee_x, &b_MuInDet_perigee_x);
   fChain->SetBranchAddress("MuComb_perigee_x", &MuComb_perigee_x, &b_MuComb_perigee_x);
   fChain->SetBranchAddress("MuSpec_perigee_y", &MuSpec_perigee_y, &b_MuSpec_perigee_y);
   fChain->SetBranchAddress("MuInDet_perigee_y", &MuInDet_perigee_y, &b_MuInDet_perigee_y);
   fChain->SetBranchAddress("MuComb_perigee_y", &MuComb_perigee_y, &b_MuComb_perigee_y);
   fChain->SetBranchAddress("MuSpec_perigee_z", &MuSpec_perigee_z, &b_MuSpec_perigee_z);
   fChain->SetBranchAddress("MuInDet_perigee_z", &MuInDet_perigee_z, &b_MuInDet_perigee_z);
   fChain->SetBranchAddress("MuComb_perigee_z", &MuComb_perigee_z, &b_MuComb_perigee_z);
   fChain->SetBranchAddress("MuOriginal_P", &MuOriginal_P, &b_MuOriginal_P);
   fChain->SetBranchAddress("MuOriginal_phi", &MuOriginal_phi, &b_MuOriginal_phi);
   fChain->SetBranchAddress("MuOriginal_eta", &MuOriginal_eta, &b_MuOriginal_eta);
   fChain->SetBranchAddress("MuOriginal_x", &MuOriginal_x, &b_MuOriginal_x);
   fChain->SetBranchAddress("MuOriginal_y", &MuOriginal_y, &b_MuOriginal_y);
   fChain->SetBranchAddress("MuOriginal_z", &MuOriginal_z, &b_MuOriginal_z);
   fChain->SetBranchAddress("MuSpec_eloss", &MuSpec_eloss, &b_MuSpec_eloss);
   fChain->SetBranchAddress("Tile_E", &Tile_E, &b_Tile_E);
   fChain->SetBranchAddress("Tile_Path", &Tile_Path, &b_Tile_Path);
   fChain->SetBranchAddress("Tile_Phi", &Tile_Phi, &b_Tile_Phi);
   fChain->SetBranchAddress("Tile_Theta", &Tile_Theta, &b_Tile_Theta);
   fChain->SetBranchAddress("Tile_x", &Tile_x, &b_Tile_x);
   fChain->SetBranchAddress("Tile_y", &Tile_y, &b_Tile_y);
   fChain->SetBranchAddress("Tile_z", &Tile_z, &b_Tile_z);
   Notify();
}

Bool_t MuTree::Notify()
{
   // The Notify() function is called when a new file is opened. This
   // can be either for a new TTree in a TChain or when when a new TTree
   // is started when using PROOF. It is normally not necessary to make changes
   // to the generated code, but the routine can be extended by the
   // user if needed. The return value is currently not used.

   return kTRUE;
}

void MuTree::Show(Long64_t entry)
{
// Print contents of entry.
// If entry is not specified, print current entry
   if (!fChain) return;
   fChain->Show(entry);
}
Int_t MuTree::Cut(Long64_t entry)
{
// This function may be called from Loop.
// returns  1 if entry is accepted.
// returns -1 otherwise.
   return 1;
}
#endif // #ifdef MuTree_cxx
