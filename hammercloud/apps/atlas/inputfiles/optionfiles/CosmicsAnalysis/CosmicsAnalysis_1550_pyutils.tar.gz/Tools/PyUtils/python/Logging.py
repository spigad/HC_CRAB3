## @author: Sebastien Binet
## @file :  Logging.py
## @purpose: try to import Logging from AthenaCommon.
##           falls back on stdlib's one

__version__ = "$Revision: 1.2 $"
__author__  = "Sebastien Binet"

__all__ = ['msg', 'logging']

try:
    import AthenaCommon.Logging as L
    msg = L.log
    logging = L.logging
except ImportError:
    import logging
    logging.VERBOSE = logging.DEBUG - 1
    logging.ALL     = logging.DEBUG - 2
    logging.addLevelName( logging.VERBOSE, 'VERBOSE' )
    logging.addLevelName( logging.ALL, 'ALL' )
    logging.basicConfig(level=logging.INFO)
    log = msg = logging.getLogger("Athena")
