# @file PyUtils.RootUtils
# @author Sebastien Binet
# @purpose a few utils to ease the day-to-day work with ROOT
# @date November 2009

from __future__ import with_statement

__doc__ = "a few utils to ease the day-to-day work with ROOT"
__version__ = "$Revision: 226706 $"
__author__ = "Sebastien Binet"

__all__ = [
    'import_root',
    'root_compile',
    ]

### imports -------------------------------------------------------------------
from .Decorators import memoize
from .Helpers import ShutUp as root_shutup

### functions -----------------------------------------------------------------
def import_root(batch=True):
    """a helper method to wrap the 'import ROOT' statement to prevent ROOT
    from screwing up the display or loading graphics libraries when in batch
    mode (which is the default.)

    e.g.
    >>> ROOT = import_root(batch=True)
    >>> f = ROOT.TFile.Open(...)
    """
    import sys
    if batch:
        sys.argv.insert(1, '-b')
    import ROOT
    ROOT.gROOT.SetBatch(batch)
    if batch:
        del sys.argv[1]
    return ROOT

def root_compile(src=None, fname=None, batch=True):
    """a helper method to compile a set of C++ statements (via ``src``) or
    a C++ file (via ``fname``) via ACLiC
    """
    if src is not None and fname is not None:
        raise ValueError("'src' xor 'fname' should be not None, *not* both")

    ROOT = import_root(batch=batch)
    if src:
        import textwrap
        import tempfile
        with tempfile.NamedTemporaryFile(suffix='.cxx') as src_file:
            src_file.write(textwrap.dedent(src))
            src_file.flush()
            orig_root_lvl = ROOT.gErrorIgnoreLevel
            ROOT.gErrorIgnoreLevel = ROOT.kError
            try:
                with root_shutup():
                    sc = ROOT.gROOT.LoadMacro(src_file.name+'++')
                if sc:
                    raise RuntimeError(
                        'problem compiling ROOT macro (rc=%s)'%(sc,)
                        )
            finally:
                ROOT.gErrorIgnoreLevel = orig_root_lvl
            return

    if fname:
        import os
        fname = os.path.expanduser(os.path.expandvars(fname))
        assert os.access(fname, os.R_OK), "could not read [%s]"%(fname,)
        orig_root_lvl = ROOT.gErrorIgnoreLevel
        ROOT.gErrorIgnoreLevel = ROOT.kError
        try:
            with root_shutup():
                sc = ROOT.gROOT.LoadMacro(fname+'++')
            if sc:
                raise RuntimeError(
                    'problem compiling ROOT macro (rc=%s)'%(sc,)
                    )
        finally:
            ROOT.gErrorIgnoreLevel = orig_root_lvl
            
        return
    
        
@memoize
def _pythonize_tfile():
    root = import_root()
    root_compile(src=r"""
    #include "TString.h"
    #define protected public
    #define private public
    #include "TFile.h"
    #undef protected
    #undef private

    Long64_t _pythonize_tell_root_file(TFile* f)
    { return f->GetRelOffset(); }
    
    #include <stdlib.h>
    #include <stdio.h>
    class PyBytes_t
    {
    public:
      PyBytes_t(size_t buf_sz=0) : sz(buf_sz>0?buf_sz:0), buf(0)
      {
        if (this->sz>0) {
           buf = (char*)malloc(sizeof(char*)*this->sz);
           //buf = new char[this->sz];
        }
      }
      ~PyBytes_t() {free(buf); buf = 0;}
      PyBytes_t(const PyBytes_t& rhs) : sz(rhs.sz), buf(0)
      {
        if (this->sz>0) {
           buf = (char*)malloc(sizeof(char*)*this->sz);     
           buf = (char*)memcpy(buf, rhs.buf, this->sz);
        }
      }
      PyBytes_t operator=(const PyBytes_t& rhs)
      {
        if (this != &rhs) {
          this->sz = rhs.sz;
          free(this->buf); this->buf = 0;
          if (this->sz>0) {      
             this->buf = (char*)malloc(sizeof(char*)*this->sz);     
             this->buf = (char*)memcpy(this->buf, rhs.buf, rhs.sz);
          }
        }
        return *this;
      }
      size_t sz;
      char*  buf;
      void* buffer() const { return (void*)buf; }
    };
    PyBytes_t _pythonize_read_root_file(TFile* f, Int_t len)
    {
      //f->SysSync(f->GetFd());  
      Long64_t totsz  = f->GetSize();
      Long64_t curpos = _pythonize_tell_root_file(f);
      Long64_t remain = totsz - curpos;
      remain = (remain>0) ? remain : 0;
      //f->Seek(curpos);
      //fprintf(stderr, "==len=[%d], remain=[%ld/%ld=%ld]\n", len, remain, totsz, curpos);
      len = (len>remain) ? remain : len;
      PyBytes_t buf(len);
      if (f->ReadBuffer((char*)buf.buf, buf.sz)) {
        //err
        return PyBytes_t(0);
      }
      f->Seek(buf.sz + curpos);
      //f->SysSync(f->GetFd());  
      //fprintf(stderr, "--len=[%d], remain=[%ld/%ld=%ld]\n", len, remain, totsz, curpos);
      return buf;
    }
    """)
    read_root_file = getattr(root, "_pythonize_read_root_file")
    tell_root_file = getattr(root, "_pythonize_tell_root_file")
    def read(self, size=-1):
        """read([size]) -> read at most size bytes, returned as a string.

        If the size argument is negative or omitted, read until EOF is reached.
        Notice that when in non-blocking mode, less data than what was requested
        may be returned, even if no size parameter was given.

        FIXME: probably doesn't follow python file-like conventions...
        """
        SZ = 4096
        ## def _adjust_sz(sz):
        ##     # FIXME: all of this should be done at the C level
        ##     #        probably in _pythonize_read_root_file
        ##     cur_pos = self.tell()
        ##     remain = self.GetSize()-cur_pos
        ##     if remain<=0: remain=0
        ##     print "-->[%s/%s=>%s]"%(remain,self.GetSize(),cur_pos,)
        ##     return min(remain, sz)
        
        if size>=0:
            #size = _adjust_sz(size)
            #print "-->0",self.tell(),size
            c_buf = read_root_file(self, size)
            if c_buf and c_buf.sz:
                #print "-->1",self.tell(),c_buf.sz
                #self.seek(c_buf.sz+self.tell())
                #print "-->2",self.tell()
                buf = c_buf.buffer()
                buf.SetSize(c_buf.sz)
                return str(buf[:])
            return ''
        else:
            size = SZ
            out = []
            while True:
                #size = _adjust_sz(size)
                c_buf = read_root_file(self, size)
                if c_buf and c_buf.sz:
                    buf = c_buf.buffer()
                    buf.SetSize(c_buf.sz)
                    out.append(str(buf[:]))
                else:
                    break
            return ''.join(out)
    root.TFile.read = read
    del read
    
    root.TFile.seek = root.TFile.Seek
    root.TFile.tell = lambda self: tell_root_file(self)
    ## import os
    ## def tell(self):
    ##     fd = os.dup(self.GetFd())
    ##     return os.fdopen(fd).tell()
    ## root.TFile.tell = tell
    ## del tell
    return 


