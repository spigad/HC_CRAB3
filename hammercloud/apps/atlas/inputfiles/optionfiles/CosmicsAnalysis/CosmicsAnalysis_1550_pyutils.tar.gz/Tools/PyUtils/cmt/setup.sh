# echo "Setting PyUtils PyUtils-00-08-53 in /afs/cern.ch/user/e/elmsheus/athena/testarea/15.5.0/Tools"

if test "${CMTROOT}" = ""; then
  CMTROOT=/afs/cern.ch/sw/contrib/CMT/v1r20p20090520; export CMTROOT
fi
. ${CMTROOT}/mgr/setup.sh

tempfile=`${CMTROOT}/mgr/cmt -quiet build temporary_name`
if test ! $? = 0 ; then tempfile=/tmp/cmt.$$; fi
${CMTROOT}/mgr/cmt setup -sh -pack=PyUtils -version=PyUtils-00-08-53 -path=/afs/cern.ch/user/e/elmsheus/athena/testarea/15.5.0/Tools  -no_cleanup $* >${tempfile}; . ${tempfile}
/bin/rm -f ${tempfile}

