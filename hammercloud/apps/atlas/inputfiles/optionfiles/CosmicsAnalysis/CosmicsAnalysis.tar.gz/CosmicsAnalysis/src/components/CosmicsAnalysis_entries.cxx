#include "CosmicsAnalysis/MuAnalysis.h"
#include "GaudiKernel/DeclareFactoryEntries.h"

DECLARE_ALGORITHM_FACTORY( MuAnalysis )
DECLARE_FACTORY_ENTRIES( CosmicsAnalysis ) {
  DECLARE_ALGORITHM( MuAnalysis )
}

