#ifndef MU_ANALYSIS_H
#define MU_ANALYSIS_H

#include <vector>
#include <string>

#include "GaudiKernel/SmartDataPtr.h"
#include "GaudiKernel/SmartDataLocator.h"
#include "GaudiKernel/IDataProviderSvc.h"
#include "GaudiKernel/PropertyMgr.h"
#include "GaudiKernel/INTupleSvc.h"
#include "GaudiKernel/ITHistSvc.h"
#include "GaudiKernel/NTuple.h"
#include "GaudiKernel/ListItem.h"
#include "GaudiKernel/ToolHandle.h"
#include "GaudiKernel/Algorithm.h"
#include "GaudiKernel/ObjectVector.h"
#include "CLHEP/Units/SystemOfUnits.h"
#include "StoreGate/DataHandle.h"
#include "StoreGate/StoreGateSvc.h"

#include "TrigDecisionTool/TrigDecisionTool.h"
#include "CaloIdentifier/CaloCell_ID.h"
#include "CaloIdentifier/CaloIdManager.h"

class TH1F;
class TFile;

class MuAnalysis : public Algorithm  {

   public:
			MuAnalysis(const std::string& name, ISvcLocator* pSvcLocator);
			~MuAnalysis();

			virtual StatusCode initialize();
      virtual StatusCode finalize();
      virtual StatusCode execute();
            
   private:
   		StoreGateSvc* m_storeGate;
   		StoreGateSvc* m_detStore;
			ToolHandle<Trig::TrigDecisionTool> m_trigDec;
			const CaloIdManager* m_calo_id_man;
      const CaloCell_ID*   m_calo_helper;

   					//spec track
			std::vector<double>* mu_spec_P;
			std::vector<double>* mu_spec_pt;
			std::vector<double>* mu_spec_phi;
			std::vector<double>* mu_spec_eta;
			std::vector<double>* mu_spec_E;
			std::vector<double>* mu_spec_x;
			std::vector<double>* mu_spec_y;
			std::vector<double>* mu_spec_z;
								//combined track
			std::vector<double>* mu_comb_P;
			std::vector<double>* mu_comb_pt; 
			std::vector<double>* mu_comb_phi;
			std::vector<double>* mu_comb_eta;
			std::vector<double>* mu_comb_E;
			std::vector<double>* mu_comb_x;
			std::vector<double>* mu_comb_y;
			std::vector<double>* mu_comb_z;
					// inner detector track
			std::vector<double>* mu_id_z;
			std::vector<double>* mu_id_P;
			std::vector<double>* mu_id_pt;
			std::vector<double>* mu_id_phi;
			std::vector<double>* mu_id_eta;
			std::vector<double>* mu_id_E;
			std::vector<double>* mu_id_x;
			std::vector<double>* mu_id_y;
					//tile muons
			std::vector<double>* tile_e;
			std::vector<double>* tile_path;
			std::vector<double>* tile_phi;	
			std::vector<double>* tile_theta;	
			std::vector<double>* tile_x;
			std::vector<double>* tile_y;
			std::vector<double>* tile_z;
			std::vector<double>* tile_path_bottom;
			std::vector<double>* tile_path_top;
			std::vector<double>* tile_path_topA;
			std::vector<double>* tile_path_bottomA;
			std::vector<double>* tile_path_topBC;
			std::vector<double>* tile_path_bottomBC;
			std::vector<double>* tile_path_topD;
			std::vector<double>* tile_path_bottomD;
			std::vector<double>* tile_path_total;
			std::vector<double>* tile_E_topA;
			std::vector<double>* tile_E_bottomA;
			std::vector<double>* tile_E_topBC;
			std::vector<double>* tile_E_bottomBC;
			std::vector<double>* tile_E_topD;
			std::vector<double>* tile_E_bottomD;
			std::vector<double>* tile_E_top;
			std::vector<double>* tile_E_bottom;
			std::vector<double>* tile_E_total; 
					//Calorimeter Cells
			std::vector<double>* cell_e;
					//Calo Muons
			std::vector<double>* calomu_e;
			//LAr Muons
			int      LAr_ncand;
			int      LAr_max_mu;
			std::vector<double>* LAr_eta1;
			std::vector<double>* LAr_phi1;
			std::vector<double>* LAr_eta2;
			std::vector<double>* LAr_phi2;
			std::vector<double>* LAr_energy;
			std::vector<double>* LAr_senergy;
			std::vector<long>* LAr_nbmcells;
			std::vector<long>* LAr_nbscells;

					//general
			std::vector<double>* mu_eloss;
			std::vector<double>* combmu_P;
			std::vector<double>* combmu_phi;
			std::vector<double>* combmu_eta;
			std::vector<double>* combmu_x;
			std::vector<double>* combmu_y;
			std::vector<double>* combmu_z;
			int nEvent;
			int nCombmu;
			int mu_spec_n;
			int mu_comb_n;
			int mu_indet_n;
			int tile_n;
			
				//Strings
			std::string m_muonfill;
			std::string m_tilemu_fill;
			std::string m_cellfill;	
			std::string m_OutputFile;
			std::string m_specmu_fill;
			std::string m_idmuon_filler;
			std::string m_calomufill;
			std::string m_clusterfill;
			TFile* mufile;
			TTree* t;

			
};

#endif // MU_ANALYSIS_H
