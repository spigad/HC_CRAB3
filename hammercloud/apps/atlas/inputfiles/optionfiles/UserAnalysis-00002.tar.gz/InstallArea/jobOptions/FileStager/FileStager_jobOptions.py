# File: FileStager/FileStager_jobOptions.py
# Author: Max Baak <mbaak@cern.ch>

# Some global settings (typically, you *only* want to
# do this in the final options file, never in a fragment):
theApp.EvtMax = -1

from AthenaCommon.GlobalFlags import GlobalFlags
GlobalFlags.DetGeo.set_atlas()
GlobalFlags.DataSource.set_geant4()
include( "IOVDbSvc/IOVRecExCommon.py" )
include( "AtlasGeoModel/SetGeometryVersion.py" )
include( "AtlasGeoModel/GeoModelInit.py" )
include( "BFieldAth/BFieldAth_jobOptions.py" )
GeoModelSvc = Service("GeoModelSvc")
GeoModelSvc.IgnoreTagDifference = True

# Event selector
include( "AthenaPoolCnvSvc/ReadAthenaPool_jobOptions.py" )
# the POOL converters
#include( "ParticleEventAthenaPool/AOD_PoolCnv_jobOptions.py")
include( "ParticleBuilderOptions/ESD_PoolCnv_jobOptions.py")
include( "ParticleBuilderOptions/AOD_PoolCnv_jobOptions.py")
#include( "ParticleEventAthenaPool/AOD_PoolCnv_jobOptions.py")

from McParticleTools.McParticleToolsConf import TruthParticleCnvTool
from TrigDecision.TrigDecisionConf import TrigDec__TrigDecisionTool

#handle.TrigDec__TrigDecisionTool = TrigDecisionTool('TrigDecisionTool')
   
theApp.Dlls += ["TrigDecision"]

## get a handle on the ServiceManager
svcMgr = theApp.serviceMgr()

## EventSelector Properties
EventSelector = svcMgr.EventSelector

# This Athena job consists of algorithms that loop over events;
# here, the (default) top sequence is used:
from AthenaCommon.AlgSequence import AlgSequence
job = AlgSequence()

#################################################################################################
# Configure the FileStager
#################################################################################################

## File with input collections
sampleFile = "../samples/52283.def"

## Import file stager classes
from FileStager.FileStagerConf import FileStagerAlg
from FileStager.FileStagerTool import FileStagerTool

## process sample definition file
stagetool = FileStagerTool(sampleFile)

## check if collection names begin with "gridcopy"
print "doStaging?", stagetool.DoStaging()

if stagetool.DoStaging():
  EventSelector.InputCollections = stagetool.GetStageCollections()
else:
  EventSelector.InputCollections = stagetool.GetSampleList()

## filestageralg needs to be the first algorithm added to the job.
if stagetool.DoStaging():
   job += FileStagerAlg('FileStager')
   job.FileStager.InputCollections = stagetool.GetSampleList()
   #job.FileStager.PipeLength = 2
   #job.FileStager.VerboseStager = True
   job.FileStager.BaseTmpdir    = stagetool.GetTmpdir()
   job.FileStager.InfilePrefix  = stagetool.InfilePrefix
   job.FileStager.OutfilePrefix = stagetool.OutfilePrefix
   job.FileStager.CpCommand     = stagetool.CpCommand
   job.FileStager.CpArguments   = stagetool.CpArguments
   job.FileStager.FirstFileAlreadyStaged = stagetool.StageFirstFile

#################################################################################################
# Add your modules below ...
#################################################################################################





#################################################################################################

print job

## Set output level threshold (2=DEBUG, 3=INFO, 4=WARNING, 5=ERROR, 6=FATAL )
## get a handle on the ServiceManager
svcMgr.MessageSvc.OutputLevel = WARNING

AthenaEventLoopMgr = Service( "AthenaEventLoopMgr" )
AthenaEventLoopMgr.OutputLevel = WARNING

