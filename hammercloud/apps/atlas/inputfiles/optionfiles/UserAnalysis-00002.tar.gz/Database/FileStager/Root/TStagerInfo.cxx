#include "FileStager/TStagerInfo.h"
#include <stdlib.h>

ClassImp(TStagerInfo)


TStagerInfo::TStagerInfo()
    : pipeLength(1)
    , pid(getpid())
    , baseTmpdir("/tmp")
    , tmpdir("/tmp")
    , cpcommand("cp")
    , stagemonitorcmd("StageMonitor.exe") 
{
  setDefaultTmpdir();

  inPrefixMap["lfn/"] = "lfn:/";
  inPrefixMap["srm/"] = "srm:/";
  inPrefixMap["sfn/"] = "sfn:/";
  inPrefixMap["gsiftp/"] = "gsiftp:/";
  inPrefixMap["rfio/"] = "rfio:/";
}


TStagerInfo::~TStagerInfo() {}


void TStagerInfo::setTmpdir()
{
  // MB: make baseTmpdir the default so actual tmpdir is easily known from outside ...
  tmpdir = baseTmpdir;

  char pidchar[25];
  sprintf(pidchar,"%d",pid);
  string testtmpdir = baseTmpdir+"/"+getenv("USER")+"_pID"+pidchar;
  int errnum = mkdir(testtmpdir.c_str(),0700);

  // test the tmpdir ...
  if ( !(errnum==0 || errnum==2) ) {
    // no permissions to write in base directory, switching to /tmp
    cerr << "TStagerInfo::setTmpdir() : No permission to write in temporary directory <"
         << baseTmpdir
         << ">. Switching back to default <$TMPDIR>, or else </tmp>."
         << endl;
    setDefaultTmpdir();
  } else {
    // writing works, leave nothing behind
    rmdir(testtmpdir.c_str());
  }
}


void TStagerInfo::setDefaultTmpdir()
{
  const char* tmp = getenv("TMPDIR");
  if (tmp!=0) {
    baseTmpdir = tmp;
    tmpdir = tmp;
  } else { 
    baseTmpdir = "/tmp";
    tmpdir = "/tmp";
  }
}
