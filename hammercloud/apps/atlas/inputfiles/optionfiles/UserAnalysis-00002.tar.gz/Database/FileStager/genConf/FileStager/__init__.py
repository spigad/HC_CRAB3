## Hook for FileStager genConf module
