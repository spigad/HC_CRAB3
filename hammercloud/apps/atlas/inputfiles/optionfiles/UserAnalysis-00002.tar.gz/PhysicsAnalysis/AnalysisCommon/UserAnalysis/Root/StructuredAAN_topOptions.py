# Author: Ketevi A. Assamagan
# BNL, June 12, 2004

# get a handle on the ServiceManager which holds all the services
from AthenaCommon.AppMgr import ServiceMgr
# Event selector
import AthenaPoolCnvSvc.ReadAthenaPool

#EventSelector.BackNavigation = True

# Particle Properties
from PartPropSvc.PartPropSvcConf import PartPropSvc

# the POOL converters
include( "ParticleBuilderOptions/ESD_PoolCnv_jobOptions.py" )
include( "ParticleBuilderOptions/AOD_PoolCnv_jobOptions.py")
include( "ParticleBuilderOptions/McAOD_PoolCnv_jobOptions.py")
include( "EventAthenaPool/EventAthenaPool_joboptions.py" )

# Dictionary for User Defined classes
include( "UserAnalysisEvent/UserAnalysisEventDict_joboptions.py" )

# The AOD input file
ServiceMgr.EventSelector.InputCollections = [ "AOD.pool.root" ]

# Overlap removal by default - This is analysis dependent
# The user is encouraged to customize the overlap removal as necessary
#include ("ParticleBuilderOptions/DefaultOverlapRemoval_jobOptions.py" )

# Athena-Aware NTuple making Tools
CBNTAthenaAware = True
include ("CBNT_Athena/CBNT_AthenaAware_jobOptions.py")
include ("CBNT_Athena/CBNT_EventInfo_jobOptions.py")

# list of the algorithms to be executed at run time
from AthenaCommon.AlgSequence import AlgSequence
topSequence = AlgSequence()

from UserAnalysis.UserAnalysisConf import StructuredAAN
topSequence += StructuredAAN("SAN")

############ The SAN making AlgTools ---
topSequence.SAN.AlgTools = [
    "SanRecVertexBranchTool/RecVertexBranches",
    "SanClusterBranchTool/ClusterBranches",
    "SanTrackBranchTool/TrackBranches",
    "SanElectronBranchTool/ElectronBranches",
    "SanPhotonBranchTool/PhotonBranches",
    "SanMuonBranchTool/MuonBranches",
    "SanMissingETBranchTool/MissingETBranches",
    "SanTauJetBranchTool/TauJetBranches",
    "SanParticleJetBranchTool/ParticleJetBranches",
    "SanTruthParticleBranchTool/TruthParticleBranches"
    ]

############ Now configure each AlgTool one by one
from AthenaCommon.AppMgr import ToolSvc
# Vertices - List all the Containers Key to go to the SAN
ToolSvc.RecVertexBranches.RecVertexContainers = [ 
     "VxPrimaryCandidate" 
     ]
ToolSvc.UserRecVertexTool.RecVertexRefKey = "RecVertexRef"
ToolSvc.RecVertexBranches.TTreeBranchBufferSize = 2000
ToolSvc.RecVertexBranches.TTreeBranchSplitLevel = 99

# CaloClusters - List all the Containers Key to go to the SAN
ToolSvc.ClusterBranches.ClusterContainers = [
    "LArClusterEM37",
    "LArClusterEM",
    "LArClusterEMSofte",
    "LArClusterEMgam35",
    "LArClusterEMgam",
    "CaloCalTopoCluster",
    "EMTopoCluster",
    "CombinedCluster"
    ]
ToolSvc.UserCaloClusterTool.ClusterRefKey = "ClusterRef"
ToolSvc.ClusterBranches.TTreeBranchBufferSize = 2000
ToolSvc.ClusterBranches.TTreeBranchSplitLevel = 99

# TrackParticles - List all the containers to go to the SAN
ToolSvc.TrackBranches.TrackContainers = [
    "TrackParticleCandidate",
    "StacoTrackParticles",
    "MuonboyMuonSpectroOnlyTrackParticles",
    "MuonboyTrackParticles",
    "MuTagTrackParticles",
    "MooreTrackParticles",
    "MuidExtrTrackParticles",
    "MuidCombTrackParticles"    
    ]
ToolSvc.UserTrackParticleTool.TrackRefKey = "TrackRef"
ToolSvc.TrackBranches.TTreeBranchBufferSize = 2000
ToolSvc.TrackBranches.TTreeBranchSplitLevel = 99

# Electrons - List all the containers to go to the SAN
ToolSvc.ElectronBranches.ElectronContainers = [ 
     "ElectronAODCollection"
  ]
ToolSvc.UserElectronTool.TrackRefKey    = ToolSvc.UserTrackParticleTool.TrackRefKey
ToolSvc.UserElectronTool.ClusterRefKey  = ToolSvc.UserCaloClusterTool.ClusterRefKey
ToolSvc.UserElectronTool.ElectronRefKey = "ElectronRef"
ToolSvc.ElectronBranches.TTreeBranchBufferSize = 2000
ToolSvc.ElectronBranches.TTreeBranchSplitLevel = 99

# Photons - List all the containers to go to the SAN
ToolSvc.PhotonBranches.PhotonContainers = [
    "PhotonCollection"
    ]
ToolSvc.UserPhotonTool.TrackRefKey   = ToolSvc.UserTrackParticleTool.TrackRefKey
ToolSvc.UserPhotonTool.ClusterRefKey = ToolSvc.UserCaloClusterTool.ClusterRefKey
ToolSvc.UserPhotonTool.PhotonRefKey  = "PhotonRef"
ToolSvc.PhotonBranches.TTreeBranchBufferSize = 2000
ToolSvc.PhotonBranches.TTreeBranchSplitLevel = 99

# Muons - List all the container to go to the SAN
ToolSvc.MuonBranches.MuonContainers = [
    "StacoMuonCollection",
    "MuidMuonCollection"
    ]
ToolSvc.UserMuonTool.TrackRefKey   = ToolSvc.UserTrackParticleTool.TrackRefKey
ToolSvc.UserMuonTool.ClusterRefKey = ToolSvc.UserCaloClusterTool.ClusterRefKey
ToolSvc.UserMuonTool.MuonRefKey    = "MuonRef"
ToolSvc.MuonBranches.TTreeBranchBufferSize = 2000
ToolSvc.MuonBranches.TTreeBranchSplitLevel = 99

# MissingETs - List the MissingET objects to appear in the SAN
ToolSvc.MissingETBranches.MissingETs = [
    "MET_Final_Muonboy",
    "MET_Final",
    "ObjMET_Final",
    "MET_Truth"
    ]
ToolSvc.UserMissingETTool.METFinalTool.muonKey = "MET_MuonBoy"
ToolSvc.UserMissingETTool.METFinalTool.outKey  = "MET_Final_Muonboy"
ToolSvc.MissingETBranches.TTreeBranchBufferSize = 2000
ToolSvc.MissingETBranches.TTreeBranchSplitLevel = 99

# TauJets - List all the TauJet containers to appear in the SAN
ToolSvc.TauJetBranches.TauJetContainers = [
    "TauJetCollection",
    "TauJet1p3pCollection"
    ]
ToolSvc.UserTauJetTool.TrackRefKey   = ToolSvc.UserTrackParticleTool.TrackRefKey
ToolSvc.UserTauJetTool.ClusterRefKey = ToolSvc.UserCaloClusterTool.ClusterRefKey
ToolSvc.UserTauJetTool.TauJetRefKey  = "TauJetRef"
ToolSvc.TauJetBranches.TTreeBranchBufferSize = 2000
ToolSvc.TauJetBranches.TTreeBranchSplitLevel = 99

# ParticleJets - List all the ParticleJet contianers to appear in the SAN
ToolSvc.ParticleJetBranches.ParticleJetContainers = [
    "Kt4TowerParticleJets",
    "Kt6TowerParticleJets",
    "Cone4TowerParticleJets",
    "ConeTowerParticleJets",
    "Kt4TopoParticleJets",
    "Kt6TopoParticleJets",
    "Cone4TopoParticleJets",
    "ConeTopoParticleJets",
    "Kt4TruthParticleJets",
    "Kt6TruthParticleJets",
    "Cone4TruthParticleJets",
    "ConeTruthParticleJets"
    ]
ToolSvc.UserParticleJetTool.TrackRefKey       = ToolSvc.UserTrackParticleTool.TrackRefKey
ToolSvc.UserParticleJetTool.ClusterRefKey     = ToolSvc.UserCaloClusterTool.ClusterRefKey
ToolSvc.UserParticleJetTool.ElectronRefKey    = ToolSvc.UserElectronTool.ElectronRefKey
ToolSvc.UserParticleJetTool.ParticleJetRefKey = "JetRef"
ToolSvc.ParticleJetBranches.TTreeBranchBufferSize = 2000
ToolSvc.ParticleJetBranches.TTreeBranchSplitLevel = 99

ToolSvc.TruthParticleBranches.TruthParticleContainers = [
    "SpclMC"
    ]
ToolSvc.TruthParticleToolBranches.TTreeBranchBufferSize = 2000
ToolSvc.TruthParticleToolBranches.TTreeBranchSplitLevel = 99
ToolSvc.UserTruthParticleTool.McTruthRefKey = "TruthRef"
ToolSvc.UserTruthParticleTool.SpclParticles   = [ 5,   11,      12,  13,      14,   15,      16,   22 ]
ToolSvc.UserTruthParticleTool.SpclPtTresholds = [ 0.0, 10.0*GeV, 0.0, 3.0*GeV, 0.0, 20.0*GeV, 0.0, 15.0*GeV ]
ToolSvc.UserTruthParticleTool.SaveSUSY = True
ToolSvc.UserTruthParticleTool.SaveLongLivedHadrons = True
ToolSvc.UserTruthParticleTool.SaveHeavyUnstables = True

# Output Printing Level
topSequence.SAN.OutputLevel = INFO

##########################################
# setup TTree registration Service
# save ROOT histograms and Tuple
from GaudiSvc.GaudiSvcConf import THistSvc
ServiceMgr += THistSvc()
ServiceMgr.THistSvc.Output = [ "AANT DATAFILE='SAN.root' OPT='RECREATE'"]
from AnalysisTools.AnalysisToolsConf import AANTupleStream
topSequence += AANTupleStream()
topSequence.AANTupleStream.ExtraRefNames = [ "StreamESD","Stream1" ]
topSequence.AANTupleStream.OutputName = 'SAN.root'
topSequence.AANTupleStream.WriteInputDataHeader = True
topSequence.AANTupleStream.OutputLevel = WARNING

# Set output level threshold (2=DEBUG, 3=INFO, 4=WARNING, 5=ERROR, 6=FATAL )
ServiceMgr.MessageSvc.OutputLevel = ERROR

# Number of Events to process
theApp.EvtMax = 100

###################### For interactive analysis
#include ("PyAnalysisCore/InitPyAnalysisCore.py")

###################### Detail time measurement and auditors
# Use auditors
#theApp.AuditAlgorithms=True

from GaudiSvc.GaudiSvcConf import AuditorSvc
ServiceMgr.AuditorSvc.Auditors  += [ "ChronoAuditor"]

#AthenaPoolCnvSvc = Service("AthenaPoolCnvSvc")
#AthenaPoolCnvSvc.UseDetailChronoStat = TRUE

#StoreGateSvc = Service( "StoreGateSvc" )
#StoreGateSvc.Dump = True 
#MessageSvc.OutputLevel = DEBUG

