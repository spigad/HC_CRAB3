###############################################################
# 
# Main jobOptions.file seting up general parameters 
# and sourcing one auxilliary jobOption per major algorithm
#==============================================================

# change traceback handling. It is in principle not needed but the observation
# is that in most case it helps recovering a meaningful trace back
# http://cern.ch/seal/workbook/sealbase.html
# USR1_DUMP_CORE        =   1
# FATAL_ON_QUIT	        =   2 x
# FATAL_ON_INT          =   4 x
# FATAL_DUMP_CORE       =   8
# FATAL_DUMP_SIG        =  16 x
# FATAL_DUMP_STACK      =  32 x
# FATAL_DUMP_LIBS       =  64 
# FATAL_DUMP_CONTEXT    = 128 x
# FATAL_AUTO_EXIT       = 256 x
gbl.AthenaServices.SetFatalHandler(438)
#pylcgdict.libPyROOT.SetSignalPolicy( pylcgdict.libPyROOT.kSignalFast )





import traceback


from AthenaCommon.Logging import logging
import traceback

logRecExCommon_topOptions = logging.getLogger( 'RecExCommon_topOptions' )

# print available memory resource
import resource
softas, hardas = resource.getrlimit( resource.RLIMIT_AS )
logRecExCommon_topOptions.info( 'Memory address space VSize soft limit : %s hard limit: %s ',softas == -1L and 'unlimited' or str(softas),  hardas == -1L and 'unlimited' or str(hardas))
softas, hardas = resource.getrlimit( resource.RLIMIT_RSS )
logRecExCommon_topOptions.info( 'Memory resident state RSS soft limit : %s hard limit: %s ',softas == -1L and 'unlimited' or str(softas),  hardas == -1L and 'unlimited' or str(hardas))




# if really want to trace within ObjKeyStore nor Configured
#from AthenaCommon.Include import includeTracePattern
#includeTracePattern.append("*/RecExConfig/ObjKeyStore*")
#includeTracePattern.append("*/RecExConfig/Configured*")

from AthenaCommon.Resilience import treatException,protectedInclude
from AthenaCommon.Include import excludeTracePattern
excludeTracePattern.append("*/RecExConfig/Resilience.py")

include ( "RecExCommon/RecExCommon_flags.py" )


# sort keys for reproduceability 
IOVSvc=Service("IOVSvc")
IOVSvc.sortKeys=True


from RecExConfig.RecFlags import rec

#if check multiple includes and property modifications
if rec.doCheckJOT():
    protectedInclude ("AthenaCommon/JobOptTraceInclude.py")

# possible user flags specification 


# dump flag content
jobproperties.print_JobProperties('tree&value')

if rec.oldFlagCompatibility:
    print "RecExCommon_flags.py flags values:"
    for o in RecExCommonFlags.keys():
        exec 'print "%s =",%s ' % (o,o)
else:
    print "Old flags have been deleted"
    
DetFlags.Print()
GlobalFlags.Print()

# end flag settings section
##########################################################################
# set up job

from AthenaCommon.AthenaCommonFlags  import athenaCommonFlags


# to read ByteStream data


# import theApp
from AthenaCommon.AppMgr import theApp

#import ServiceMgr
from AthenaCommon.AppMgr import ServiceMgr

# to read ByteStream data
from AthenaCommon.GlobalFlags  import globalflags
if globalflags.InputFormat()=='bytestream':

    include( "ByteStreamCnvSvc/BSEventStorageEventSelector_jobOptions.py" )
    ServiceMgr.ByteStreamInputSvc.FullFileName    = athenaCommonFlags.BSRDOInput()    
    #ByteStreamEventStorageInputSvc.DumpFlag    = True


    theApp.ExtSvc += [ "ByteStreamCnvSvc"]

    # this fragment should not be in trigger (also governed by triggerflags)
    include( "TriggerRelease/jobOfragment_ReadBS.py" )
    ServiceMgr.EventSelector.OverrideRunNumber=True




if not 'doMixPoolInput' in dir():
    doMixPoolInput = False
if globalflags.InputFormat()=='pool':
    if doMixPoolInput:
        if not rec.readRDO():
            raise "doMixPoolInput only functional reading RDO"
        import StreamMix.ReadAthenaPool
        svcMgr.AthenaPoolCnvSvc.PoolAttributes = [ "DEFAULT_BUFFERSIZE = '2048'" ]
        from EventSelectorAthenaPool.EventSelectorAthenaPoolConf   import EventSelectorAthenaPool    
        from AthenaServices.AthenaServicesConf import MixingEventSelector
        svcMgr.ProxyProviderSvc.ProviderNames += [ "MixingEventSelector/EventMixer" ]
        EventMixer =  MixingEventSelector("EventMixer")
        # In UserAlgs, do the following for as many datasets as you like:
        # svcMgr += EventSelectorAthenaPool( "EventSelector5009" )
        # Service("EventSelector5009").InputCollections = [ 'misal1_mc12.005009.etc.RDO.pool.root' ]
        # EventMixer.TriggerList += [ "EventSelectorAthenaPool/EventSelector5009:0:500" ]    
    else:        
        # to read Pool data
        import AthenaPoolCnvSvc.ReadAthenaPool
        svcMgr.AthenaPoolCnvSvc.PoolAttributes = [ "DEFAULT_BUFFERSIZE = '2048'" ]

        # if file not in catalog put it there
        svcMgr.PoolSvc.AttemptCatalogPatch=True 

        # G4 Pool input 
        # it is possible to specify a list of files to be processed consecutively
        # If using logical file name or using back navigation the relevant input
        # files should be listed in the PoolFileCatalog.xml

        if rec.doShowSizeStatistics():
            svcMgr.EventSelector.ShowSizeStatistics = True #  show size inform

        if rec.readTAG():
            svcMgr.EventSelector.InputCollections = athenaCommonFlags.PoolTAGInput()
            svcMgr.EventSelector.CollectionType = "ExplicitROOT"
            svcMgr.EventSelector.Connection = ""
            svcMgr.EventSelector.Query = athenaCommonFlags.PoolInputQuery()
            if rec.readESD():
                svcMgr.EventSelector.RefName="StreamESD"
            elif not rec.readAOD() and not rec.TAGFromRDO() : # == read RDO
                svcMgr.EventSelector.RefName="Stream1"
        elif rec.readAOD():
            # dummy line in case this file is edited by a batch script
            pass
            svcMgr.EventSelector.InputCollections = athenaCommonFlags.PoolAODInput()
        else:    
            if not rec.readESD():
                # dummy line in case this file is edited by a batch script
                pass
                # EventSelector.InputCollections = athenaCommonFlags.PoolRDOInput()
                svcMgr.EventSelector.InputCollections = athenaCommonFlags.PoolRDOInput()
            else:
                # dummy line in case this file is edited by a batch script        
                pass
                svcMgr.EventSelector.InputCollections = athenaCommonFlags.PoolESDInput() 


        from RecExConfig.RecConfFlags import recConfFlags
        ServiceMgr.EventSelector.BackNavigation = recConfFlags.AllowBackNavigation()
        # FIXME temporary
        #logRecExCommon_topOptions.warning("temporary : EventSelector.OverrideRunNumber = True")
        #ServiceMgr.EventSelector.OverrideRunNumber=True

        # backward compatibility (needed for RTT overwriting InputCollections)
        EventSelector=ServiceMgr.EventSelector


#particle property service
protectedInclude( "PartPropSvc/PartPropSvc.py" )
include.block( "PartPropSvc/PartPropSvc.py" )

#######################################################################
# useful debugging/info tools


#
# write out a summary of the time spent
#
#from AthenaCommon.AppMgr import theAuditorSvc
from AthenaCommon.ConfigurableDb import getConfigurable
theAuditorSvc += getConfigurable("ChronoAuditor")()


# Display detailed size and timing statistics for writing and reading
#  but not if trigger on, because of the randomize key
from RecExConfig.RecAlgsFlags import recAlgs


#
# write out a short message upon entering or leaving each algorithm
#
if rec.doNameAuditor():
    # theAuditorSvc += getConfigurable("NameAuditor")()
    theAuditorSvc.Auditors += [ 'NameAuditor' ]
#
try:
    if rec.doSGAuditor():
        # build SGOutFileName
        if 'SGOutFileSuffix' in dir():
            SGOutFileName=SGOutFileSuffix+"SG.out"
        else:
            SGOutFileName="SG.out"
        if rec.doCBNT:
            SGOutFileName="CBNT_"+SGOutFileName
        if rec.doWriteTAG:
            SGOutFileName="TAG_"+SGOutFileName
        if rec.doWriteAOD:
            SGOutFileName="AOD_"+SGOutFileName
        if rec.doWriteESD:
            SGOutFileName="ESD_"+SGOutFileName
        if rec.doWriteRDO:
            SGOutFileName="RDO_"+SGOutFileName

            # svcMgr += getConfigurable("SGAudSvc")(OutFileName = SGOutFileName )
        from AthenaCommon.ConfigurableDb import getConfigurable
        svcMgr += getConfigurable('SGAudSvc')()
        theApp.CreateSvc += [ svcMgr.SGAudSvc.getFullName() ]
        svcMgr.SGAudSvc.OutFileName = SGOutFileName

        del SGOutFileName
except Exception:
    treatException("Could not load SGAudSvc" )


#ChronoStatSvc = Service ( "ChronoStatSvc")
# write out summary of the memory usage
#   number of events to be skip to detect memory leak
# Set to 50 to give some time to stabilise
ServiceMgr.ChronoStatSvc.NumberOfSkippedEventsForMemStat = 50


theMemStatAuditor = getConfigurable("MemStatAuditor")()
#FIXME
theAuditorSvc += theMemStatAuditor

if rec.doDetailedAuditor():
    pass
    theMemStatAuditor.OutputLevel = VERBOSE

else:
    pass
    theMemStatAuditor.OutputLevel = WARNING


try:
    if rec.doFloatingPointException:
        theApp.CreateSvc += ["FPEControlSvc"]
except Exception:
    treatException("Could not load FPEControlSvc" )
    

#
# write out a list of all Storegate collection with their keys and
# lock/unlock state. Very useful for debugging purpose
#
#StoreGateSvc = Service ("StoreGateSvc" )
ServiceMgr.StoreGateSvc.Dump = rec.doDumpTES()
ServiceMgr.DetectorStore.Dump = rec.doDumpTDS()

# print one line for every object manipulation, incluing deletion at the end
# of the event or the end of the job
# StoreGateSvc.OutputLevel=VERBOSE
# DetectorStore.OutputLevel=VERBOSE

# Set output level threshold
#    (  ALL, VERBOSE, DEBUG, INFO, WAR NING, ER ROR, FATAL )
ServiceMgr.MessageSvc.OutputLevel               = rec.OutputLevel()
#increase the number of letter reserved to the alg/tool name from 18 to 30
ServiceMgr.MessageSvc.Format = "% F%50W%S%7W%R%T %0W%M" 
# to change the default limit on number of message


# MessageSvc.debugLimit = 10000   # all debug message etc...
ServiceMgr.MessageSvc.defaultLimit = 9999999  # all messages

# printout summary of messages
theAuditorSvc += getConfigurable("AlgErrorAuditor")()

theApp.AuditAlgorithms=True 
theApp.AuditServices=True
theApp.AuditTools=True 


# show summary of WAR NING ER ROR and FATAL messages
ServiceMgr.MessageSvc.showStats=True
ServiceMgr.MessageSvc.statLevel=WARNING

ServiceMgr.MessageSvc.enableSuppression = True

# if no truth and some alg still want to access it, zillions of HepMcParticleLink
# WARNING need to be suppressed
if not rec.doTruth():
    ServiceMgr.MessageSvc.setError +=  [ "HepMcParticleLink"]

#FIXME should be removed for 14.1.0
ServiceMgr.MessageSvc.setFatal +=  [ "HistorySvc"]


# to get couloured messages (not in emacs though)
# MessageSvc.useColors = true 

try:
    if rec.doPerfMon():
        from PerfMonComps.PerfMonFlags import jobproperties
        jobproperties.PerfMonFlags.OutputFile = "ntuple.root"
        # by default, PerfMon is disabled: enable it
        # see https://twiki.cern.ch/twiki/bin/view/Atlas/PerfMonComps
        jobproperties.PerfMonFlags.doMonitoring = True
        include( "PerfMonComps/PerfMonSvc_jobOptions.py" )
    else:   
    #   switch by default fast monitoring but not if monitoring already on
        from PerfMonComps.PerfMonFlags import jobproperties
        jobproperties.PerfMonFlags.doMonitoring = True
        jobproperties.PerfMonFlags.doFastMon = True
        include( "PerfMonComps/PerfMonSvc_jobOptions.py" )

except Exception:
    treatException("Could not load PerfMon" )


########################################################################

# Number of events to be processed 
theApp.EvtMax = athenaCommonFlags.EvtMax()
# possibly skip events



if 'EventSelector' in dir():
    EventSelector.SkipEvents = athenaCommonFlags.SkipEvents() 

			

if rec.doTimeLimit():
    try:
        include ("LSFTimeKeeper/LSFTimeKeeperOptions.py")
        LSFTimeKeeperSvc= Service("LSFTimeKeeperSvc")
        LSFTimeKeeperSvc.OutputLevel=DEBUG
    except Exception:
        treatException("could not load LSFTimeKeeperOptions.py ")


if rec.doCBNT():
    from AthenaCommon.AppMgr import ServiceMgr
    if not hasattr(ServiceMgr, 'THistSvc'):
        from GaudiSvc.GaudiSvcConf import THistSvc
        ServiceMgr += THistSvc()
    ServiceMgr.THistSvc.Output += ["AANT DATAFILE='%s' OPT='RECREATE'" % rec.RootNtupleOutput()]
    # do not print the full dump of variables
    THistSvc.OutputLevel=WARNING

    try:
        from AnalysisTools.AnalysisToolsConf import AANTupleStream

        theAANTupleStream=AANTupleStream(ExtraRefNames = [ "StreamESD","StreamRDO" ],                                
                                         OutputName=rec.RootNtupleOutput() )
        if not rec.doWriteESD() and not rec.doWriteRDO() and not rec.doWriteAOD():
            theAANTupleStream.WriteInputDataHeader = True
    except Exception:
        treatException("could not load AnalysisTools.AnalysisToolsConf=>no ntuple! ")
        rec.doCBNT=False


# if need histogram output

if rec.doHist() :
    # Histogram output, if any. 
    HistogramPersistencySvc = Service( "HistogramPersistencySvc" )
    theApp.HistogramPersistency = "ROOT"
    # ServiceMgr.HistogramPersistencySvc.OutputFile  = RootHistoOutput
    HistogramPersistencySvc.OutputFile  = rec.RootHistoOutput()        


##########################################################################

#--------------------------------------------------------------
# Needed for Configurables
#--------------------------------------------------------------

from AthenaCommon.AlgSequence import AlgSequence
topSequence = AlgSequence()
from AthenaCommon.AppMgr import ToolSvc

# FIXME should
doFastCaloSim=False

try:
    from CaloRec.CaloCellFlags import jobproperties
    if not jobproperties.CaloCellFlags.doFastCaloSim.statusOn:
        doFastCaloSim=False
        logRecExCommon_topOptions.info("doFastCaloSim not set, so not using it")
    else:
        doFastCaloSim=jobproperties.CaloCellFlags.doFastCaloSim()
        if doFastCaloSim:
            logRecExCommon_topOptions.info("doFastCaloSim requested. Switching also Atlfast on")
            recAlgs.doAtlfast=True
            doAtlfast=True
        else:
            logRecExCommon_topOptions.info("doFastCaloSim explicitly not requested")
except Exception:
    logRecExCommon_topOptions.warning("could not load CaloCellFlags")

from RecExConfig.ObjKeyStore import objKeyStore





if not rec.readESD() and not rec.readAOD():
    objKeyStore.readInputFile('RecExCond/OKS_streamRDO.py')
elif rec.readESD():
    if doFastCaloSim:
        logRecExCommon_topOptions.info("reading FastCaloSim/FS_OKS_streamESD.py")
        objKeyStore.readInputFile('FastCaloSim/FS_OKS_streamESD.py')
    else:
        logRecExCommon_topOptions.info("reading RecExCond/OKS_streamESD.py")
        objKeyStore.readInputFile('RecExCond/OKS_streamESD.py')
    objKeyStore.readInputBackNav('RecExCond/OKS_streamRDO.py')
elif rec.readAOD():
    objKeyStore.readInputFile('RecExCond/OKS_streamAOD.py')
    objKeyStore.readInputBackNav('RecExCond/OKS_streamESD.py')
    objKeyStore.readInputBackNav('RecExCond/OKS_streamRDO.py')





print " Initial content of objKeyStore "
#objKeyStore.Print()
print objKeyStore
#stop



# for example : disable SimpleRawObjGetter, this will cascade to
# downstream algorithm
if False:
    from RecExAlgs.SimpleRawObjGetter import SimpleRawObjGetter
    theSimpleRawObjGetter = SimpleRawObjGetter(disable=True)



# to be tested : this should enforce config error 
# recConfFlags.AllowIgnoreConfigError=False
# for example :if try to disable here, this would be ineffective 
#if False:
#    from RecExAlgs.SimpleRawObjGetter import SimpleRawObjGetter
#    theSimpleRawObjGetter = SimpleRawObjGetter(disable=True)




# put quasi empty first algorithm so that the first real
# algorithm does not see the memory change due to event manipulation
#from AthenaPoolTools.AthenaPoolToolsConf import EventCounter
from GaudiAlg.GaudiAlgConf import EventCounter
# one print every 100 event
topSequence+=EventCounter(Frequency=100)



if rec.doEdmMonitor() and DetFlags.detdescr.ID_on():
    try:
        from AthenaCommon.ConfigurableDb import getConfigurable
        topSequence += getConfigurable("Trk::EventDataModelMonitor")("EventDataModelMonitor")
    except Exception:
        treatException("Could not load EventDataModelMonitor" )



if rec.doDumpPoolInputContent() and globalflags.InputFormat()=='pool':
    try:
        include("AthenaPoolTools/EventCount_jobOptions.py")
        topSequence.EventCount.Dump=True
        topSequence.EventCount.OutputLevel=DEBUG   
    except:
        treatException("EventCount_jobOptions.py" )
        

# set up all detector description description 
include ("RecExCommon/AllDet_detDescr.py")



#
# G4 : RDO Pool converters
#
#if read or write ESD load the converters
# necessary for ESD->AOD
#if ( rec.doWriteESD() or rec.readESD()) or ( rec.doWriteAOD() or rec.readAOD()) or rec.doWriteRDO() :
#    # Converters:
#    include ( "RecExCommon/RecoOutputPoolCnv_jobOptions.py" )

# should not be necessary anymore
#if ( rec.doWriteESD() and DetFlags.detdescr.ID_on() ) or doWriteAOD or readESD or readAOD :
#    include ("VxMultiVertex/VxMultiVertexDict_joboptions.py" )


# conevrters are now automatically loaded
#if not rec.readAOD() and rec.doTruth():        #needed to read MuonEntryRecord
#   include( "G4SimAthenaPOOL/G4SimAthenaPOOL_joboptions.py" )


## should be automatic now
## if DetFlags.readRDOPool.any_on() or DetFlags.readRIOPool.any_on() or rec.readESD() :
##     if DetFlags.readRDOPool.ID_on():
##     #FIXME tile reading very slow if InDet dict not there. Bug in Pool.     
##         include( "InDetEventAthenaPool/InDetEventAthenaPool_joboptions.py" )

##     if DetFlags.readRDOPool.LAr_on() :
##         include( "LArAthenaPool/LArAthenaPool_joboptions.py" )

##     if DetFlags.readRDOPool.Tile_on():
##         include( "TileEventAthenaPool/TileEventAthenaPool_joboptions.py" )

##     if DetFlags.readRDOPool.Muon_on() or DetFlags.readRIOPool.Muon_on()  :
##     	include( "MuonEventAthenaPool/MuonEventAthenaPool_joboptions.py" )
   
##     if recAlgs.doTrigger() or ( rec.readESD() and not rec.noESDTrigger()) or rec.readAOD() or rec.doWriteRDO() :
##         # needed for TriggerDecision
##         try:
##             include ("TrigEventAthenaPool/TrigEventAthenaPool_joboptions.py")
##             include("TrigT1EventAthenaPool/TrigT1EventAthenaPool_joboptions.py")
##         except Exception:
##             print traceback.format_exc() 
##             logRecExCommon_topOptions.error("Could not load TrigEvent or TrigT1Event. Switched off !" )
##             doTrigger=False
##     #if DetFlags.readRDOPool.Muon_on() or DetFlags.readRIOPool.Muon_on()  :


##     include( "EventAthenaPool/EventAthenaPool_joboptions.py" )

    

## if rec.readAOD():
##     include( "ParticleBuilderOptions/AOD_PoolCnv_jobOptions.py")
##     if doTruth:
##        include( "ParticleBuilderOptions/McAOD_PoolCnv_jobOptions.py")


## if rec.doTruth():
##     include( "GeneratorObjectsAthenaPool/GeneratorObjectsAthenaPool_joboptions.py" )


        
#--------------------------------------------------------------
# Now specify the list of algorithms to be run
# The order of the jobOption specify the order of the algorithms
# (don't modify it)
#--------------------------------------------------------------


# 
#
# functionality : read truth
#
if rec.doTruth():
    # this algorithm dump the content of the MC event: big output
    if rec.doDumpMC():
        # generator truth
        from TruthExamples.TruthExamplesConf import DumpMC
        topSequence+=DumpMC()


if rec.readESD():
   doMuonboyEDM=False



if recAlgs.doAtlfast():
    protectedInclude ("AtlfastAlgs/Atlfast_RecExCommon_Fragment.py")


#
# System Reconstruction
#
include ("RecExCommon/SystemRec_config.py")


#
# Combined reconstruction
#
include ("RecExCommon/CombinedRec_config.py")


#
# Heavy ion reconstruction  special configuration
#
if rec.doHeavyIon():
    protectedInclude ("HIRecExample/HIRec_jobOptions.py")


# FIXME I do not understand this
if doFastCaloSim:
    readESD=False
    rec.readESD=False

#
# trigger
#

from AthenaCommon.Include import excludeTracePattern
excludeTracePattern.append("*/TriggerMenuPython/Combined.py")
excludeTracePattern.append("*/TrigMonitorBase/TrigGenericMonitoringToolConfig.py")
excludeTracePattern.append("*/TrigSteering/TrigSteeringConfig.py")

# FIXME doTriggerConfigOnly jobproperties.Trigger.doTriggerConfigOnly seem ineffective
if recAlgs.doTrigger() :
    try:
        #include ("TriggerRelease/jobOfragment_forRecExCommon.py")
        from TriggerJobOpts.TriggerGetter import TriggerGetter
        triggerGetter = TriggerGetter()
    except Exception:
        treatException("Could not import TriggerJobOpts.TriggerGetter . Switched off !" )
        recAlgs.doTrigger=False

# run monitoring
if rec.doMonitoring() and rec.readRDO():
    try:
        include ("DataQualityTools/DataQualityMon_RecExCommon_jobOptions.py")
    except Exception:
        treatException("Could not load DataQualityTools/DataQualityMon_RecExCommon_jobOptions.py")
 


################################################################"


# CBNT_Athena.Members specify the ntuple block corresponding to a given ntuple
# Comment CBNT_Athena.Members line to remove a ntuple block
# It is also possible to disable a ntuple block by
#       disabling the corresponding
#       CBNT_Athena.Members with the line: <Member>.Enable = False 
# The ntuple specification is in file CBNT_jobOptions.py
# and can be modified by adding properties below
#
# ----- CBNT_Athena algorithm
#


if rec.doAOD():
    try:
        include( "ParticleBuilderOptions/AOD_Builder_jobOptions.py")
    except Exception:
        treatException("Could not load AOD_Builder_joboptions. Switched off !" )
        rec.doAOD=False
        

if rec.doWriteTAG():
    try:
        include( "EventTagAlgs/EventTag_jobOptions.py" )
    except Exception:
        treatException("EventTag_jobOptions.py Switched off !" )
        rec.doWriteTAG=False


#
# possible user code and property modifiers should come here
# could be several algorithms
for UserAlg in rec.UserAlgs():
    include (UserAlg)


if rec.doCBNT():
    protectedInclude( "RecExCommon/CBNT_config.py" )


        

if rec.doJiveXML():
    protectedInclude ( "RecExCommon/JiveXML_config.py")


if rec.doPersint():
    from MboyView.ConfiguredMboyView import theMboyView






###################################################################
#
# functionality : monitor memory and cpu time
#
    

#
# functionality : build combined ntuple, 
# gathering info from all the reco algorithms
#




# check dictionary all the time
ServiceMgr.AthenaSealSvc.CheckDictionary = True
if not rec.doCheckDictionary():
    ServiceMgr.AthenaSealSvc.OutputLevel=WARNING



#
#
#now write out Transient Event Store content in POOL
#
#
# 
if rec.doWriteESD() or rec.doWriteAOD() or rec.doWriteRDO() or rec.doWriteTAG():
    #OBSOLETE include ("AthenaPoolCnvSvc/WriteAthenaPool_jobOptions.py")
    import AthenaPoolCnvSvc.WriteAthenaPool
    # set maximum size limit to 15 GB (up from 2GB)
    svcMgr.AthenaPoolCnvSvc.MaxFileSizes = [ "15000000000" ]

    svcMgr.AthenaPoolCnvSvc.PoolAttributes = [ "DEFAULT_BUFFERSIZE = '2048'" ]
    svcMgr.AthenaPoolCnvSvc.CommitInterval = 10
        


    #obsolete if not ( DetFlags.readRDOPool.any_on() or rec.readESD() ) :
    #obsolete    include ("AthenaPoolCnvSvc/WriteAthenaPool_jobOptions.py")
  

# Must make sure that no OutStream's have been declared
#FIXME
theApp.OutStream = []

if rec.doWriteRDO():
    from AthenaServices.AthenaServicesConf import AthenaOutputStream 

    topSequence+=AthenaOutputStream("StreamRDO",
                                 #>=12.3.0 StreamAOD.EvtConversionSvc = "AthenaPoolCnvSvc"
                                 WritingTool = "AthenaPoolOutputStreamTool",    
                                 #force read of input data to write in output data
                                 ForceRead = True, 
                                 # Define the output file name
                                 OutputFile    = athenaCommonFlags.PoolRDOOutput())

    StreamRDO=topSequence.StreamRDO

    if rec.readRDO():
        if globalflags.InputFormat()=='pool':
            StreamRDO.TakeItemsFromInput=True
        else:
            # reading BS , so need explicit list of item
            # should eventually be shared with Digitization
            # Only include non-truth
            StreamRDO.ItemList=["LArRawChannelContainer#*"]
            StreamRDO.ItemList+=["TileRawChannelContainer#*"]
            StreamRDO.ItemList+=["EventInfo#*"];
            StreamRDO.ItemList+=["PileUpEventInfo#*"]
            StreamRDO.ItemList+=["PixelRDO_Container#*"]
            StreamRDO.ItemList+=["SCT_RDO_Container#*"]
            StreamRDO.ItemList+=["TRT_RDO_Container#*"]
            StreamRDO.ItemList+=["ROIB::RoIBResult#*", "MuCTPI_RDO#*","CTP_RDO#*","LArTTL1Container#*","TileTTL1Container#*"]
            StreamRDO.ItemList+=["CscDigitContainer#*"]
            StreamRDO.ItemList+=["MdtDigitContainer#*"]
            StreamRDO.ItemList+=["RpcDigitContainer#*"]
            StreamRDO.ItemList+=["TgcDigitContainer#*"]
            StreamRDO.ItemList+=["CscRawDataContainer#*"]
            StreamRDO.ItemList+=["MdtCsmContainer#*"]
            StreamRDO.ItemList+=["RpcPadContainer#*"]
            StreamRDO.ItemList+=["TgcRdoContainer#*"]
            StreamRDO.ItemList+=["CscRawDataContainer#CSC_Hits"]
            StreamRDO.ItemList+=["MdtCsmContainer#MDT_Hits"]
            StreamRDO.ItemList+=["RpcPadContainer#RPC_Hits"]
            StreamRDO.ItemList+=["TgcRdoContainer#TGC_Hits"]



try:
    if globalflags.InputFormat()=='bytestream':
        # FIXME : metadata store definition is in ReadAthenaPool_jobOptions.py
        # copy it there for BS Reading for 13..0.X
        # Add in MetaDataSvc 
        from EventSelectorAthenaPool.EventSelectorAthenaPoolConf import MetaDataSvc
        svcMgr += MetaDataSvc( "MetaDataSvc" )
        # Add in MetaData Stores
        from StoreGate.StoreGateConf import StoreGateSvc
        svcMgr += StoreGateSvc( "MetaDataStore" )
        svcMgr += StoreGateSvc( "InputMetaDataStore" )

        # Make MetaDataSvc an AddressProvider
        svcMgr.ProxyProviderSvc.ProviderNames += [ "MetaDataSvc" ]

        # enable IOVDbSvc to read metadata
        svcMgr.MetaDataSvc.MetaDataContainer = "MetaDataHdr"
        svcMgr.MetaDataSvc.MetaDataTools += [ "IOVDbMetaDataTool" ]

    # read detector status information from conditions database
    include("DetectorStatus/DetStatusSvc_CondDB.py")
    MetaDataStore=svcMgr.MetaDataStore
        

except Exception:
    treatException("Could not load DetStatusSvc_CondDb !")
    rec.doFileMetaData=False

if (rec.doWriteAOD() or rec.doWriteESD()) and rec.doFileMetaData():
    protectedInclude("DetectorStatus/DetStatusSvc_ToFileMetaData.py")
    # Create LumiBlock meta data containers *before* creating the output StreamESD/AOD
    include ("LumiBlockAthenaPool/LumiBlockAthenaPool_joboptions.py")
    from LumiBlockComps.LumiBlockCompsConf import CreateLumiBlockCollectionFromFile
    topSequence += CreateLumiBlockCollectionFromFile()



if rec.doWriteESD():
    if rec.doWriteRDO():
        # mark the RDO DataHeader as the input DataHeader

        from OutputStreamAthenaPool.OutputStreamAthenaPoolConf import MakeInputDataHeader
        topSequence+=MakeInputDataHeader("MakeInputDataHeaderRDO",
                                         StreamName="StreamRDO")
    
    #Create output StreamESD
    from AthenaPoolCnvSvc.WriteAthenaPool import AthenaPoolOutputStream
    StreamESD=AthenaPoolOutputStream("StreamESD",athenaCommonFlags.PoolESDOutput(),True)    
    StreamESD.ForceRead = True
    if rec.doFileMetaData():
        # Put MetaData in ESD stream via StreamESD_FH.
        # Note: StreamESD_FH is executed immediately after StreamESD,
        # so MetaData objects have to be created *before* StreamESD.
        from AthenaServices.AthenaServicesConf import  AthenaOutputStream        
        StreamESD_FH = AthenaOutputStream( "StreamESD_FH" )    
        # Write all IOV meta data containers
        StreamESD_FH.ItemList += [ "IOVMetaDataContainer#*" ]
        # Write LumiBlock meta data containers
        StreamESD_FH.ItemList += [ "LumiBlockCollection#*" ]


    protectedInclude ( "RecExPers/RecoOutputESDList_jobOptions.py" )
    
    logRecExCommon_topOptions.info("StreamESD Itemlist dump:")
    print StreamESD.ItemList

    # print one line for each object to be written out
    #StreamESD.OutputLevel=DEBUG
    
    # this is ESD->ESD copy 
    if rec.readESD():
        # copy does not point to input
        StreamESD.ExtendProvenanceRecord = False 
        # all input to be copied to output
        StreamESD.TakeItemsFromInput=True

        # FIXME in ESD jet points to non existent cluster, hide WARNING
        ServiceMgr.MessageSvc.setError +=  [ "SG::ELVRef"]
    

if rec.doESD() or rec.doWriteESD():
    #        
    # Heavy ion reconstruction  special configuration
    #
    if rec.doHeavyIon():
        protectedInclude ("HIRecExample/heavyion_postOptionsESD.py")
    

if rec.doWriteAOD(): 

    # build list of cells from clusters
    # (since cluster element link are reset to the new list this must
    # be done after StreamESD )

    if rec.doWriteESD():
        # mark the ESD DataHeader as the input DataHeader
        from OutputStreamAthenaPool.OutputStreamAthenaPoolConf import MakeInputDataHeader
        topSequence+=MakeInputDataHeader("MakeInputDataHeaderESD",
                                         StreamName="StreamESD")


    # special slimmed cell in AOD         
    if DetFlags.detdescr.Calo_on() and rec.doAODCaloCells():
        try:
            if rec.readESD() or jobproperties.CaloRecFlags.doEmCluster() :
                from CaloRec.CaloCellAODGetter import addClusterToCaloCellAOD
                addClusterToCaloCellAOD("LArClusterEM57Nocorr")
            if rec.readESD() or recAlgs.doEgamma() :
                from CaloRec.CaloCellAODGetter import addClusterToCaloCellAOD
                addClusterToCaloCellAOD("egClusterCollection")                
                
            if rec.readESD() or MuonClusterInitialized :
                # hack until MuonClusterCollection is properly added to ObjKeyStore
                from RecExConfig.ObjKeyStore import objKeyStore
                objKeyStore.addStreamAOD("CaloClusterContainer","MuonClusterCollection")

                from CaloRec.CaloCellAODGetter import addClusterToCaloCellAOD
                addClusterToCaloCellAOD("MuonClusterCollection")

        except Exception:
            treatException("Could not make AOD cells" )


    protectedInclude( "ParticleBuilderOptions/AOD_OutputList_jobOptions.py")


    # Create output StreamAOD
    from AthenaPoolCnvSvc.WriteAthenaPool import AthenaPoolOutputStream
    StreamAOD=AthenaPoolOutputStream("StreamAOD", athenaCommonFlags.PoolAODOutput(), True)
    StreamAOD.ItemList = AOD_ItemList
    StreamAOD.ForceRead = True
    if rec.doFileMetaData():
        # Put MetaData in AOD stream via StreamAOD_FH.
        # Note: StreamAOD_FH is executed immediately after StreamAOD,
        # so MetaData objects have to be created *before* StreamAOD.
        from AthenaServices.AthenaServicesConf import AthenaOutputStream
        StreamAOD_FH = AthenaOutputStream( "StreamAOD_FH" )
        # Write all IOV meta data containers
        StreamAOD_FH.ItemList += [ "IOVMetaDataContainer#*" ]
        # Write all LumiBlock meta data containers
        StreamAOD_FH.ItemList += [ "LumiBlockCollection#*" ]


    logRecExCommon_topOptions.info("StreamAOD Itemlist dump:")
    print StreamAOD.ItemList
    
    # this is AOD->AOD copy 
    if rec.readAOD():
        # copy does not point to input
        StreamAOD.ExtendProvenanceRecord = False 
        # all input to be copied to output
        StreamAOD.TakeItemsFromInput=True
        
    # print one line for each object to be written out
    #StreamAOD.OutputLevel=DEBUG    

if rec.doAOD() or rec.doWriteAOD():
    #        
    # Heavy ion reconstruction  special configuration
    #
    if rec.doHeavyIon():
        protectedInclude ("HIRecExample/heavyion_postOptionsAOD.py")




if rec.doWriteTAG():

    # FIXME : temporary switch off 
    logRecExCommon_topOptions.warning("temporary : EventTagFlags.set_DataQualityOff")
    if not 'EventTagFlags' in dir():
        try:
            include ( "EventTagAlgs/EventTagFlags.py" )
            if rec.readAOD() or rec.readESD():
                EventTagFlags.set_DataQualityOff()
        except:
                treatException("could not load EventTagFlags")

    from RegistrationServices.RegistrationServicesConf import RegistrationStream        
    topSequence+=RegistrationStream("StreamTAG",
                                    CollectionType="ExplicitROOT")
    StreamTAG=topSequence.StreamTAG


    TagStreamName="*"


    # Default is that TAG will point at an output file
    StreamTAG.WriteInputDataHeader = False
    # ... unless nothing is written out
    if (rec.readRDO() or rec.readESD()) and (not rec.doWriteESD() and not rec.doWriteAOD()):
        StreamTAG.WriteInputDataHeader = True
    elif rec.readAOD() and not rec.doWriteAOD():
        StreamTAG.WriteInputDataHeader = True

    # and then specify which output dataheader to take

    if rec.doWriteAOD() and (rec.readRDO() or rec.readESD() or rec.readAOD()):
        TagStreamName="StreamAOD"
    elif not rec.readAOD() and (rec.readRDO() or rec.readESD()) and rec.doWriteESD():
        TagStreamName="StreamESD"

    logRecExCommon_topOptions.info( "TAG primary ref points to "+ TagStreamName)
    StreamTAG.ItemList += [ "DataHeader#"+TagStreamName ]
    StreamTAG.ItemList += [ "AthenaAttributeList#"+EventTagGlobal.AttributeList ]

    # Define the output file name
    StreamTAG.OutputCollection = athenaCommonFlags.PoolTAGOutput()
    logRecExCommon_topOptions.info("StreamTAG Itemlist dump:")
    print StreamTAG.ItemList


if rec.doCBNT():
    # AANTupleStream should be at the very end
    topSequence+=theAANTupleStream



# detailed auditor of time to read/write pool object
if hasattr(ServiceMgr, 'AthenaPoolCnvSvc'):
    ServiceMgr.AthenaPoolCnvSvc.UseDetailChronoStat = True


print "The following pattern exclude python files from traceing"
from AthenaCommon.Include import excludeTracePattern
print excludeTracePattern


# BS writing (T Bold)
if rec.doWriteBS(): 

    from ByteStreamCnvSvc.ByteStreamCnvSvcConf import ByteStreamCnvSvc
    svcMgr += ByteStreamCnvSvc()

    
    # OutputSvc
    from ByteStreamCnvSvc.ByteStreamCnvSvcConf import ByteStreamEventStorageOutputSvc
    svcMgr += ByteStreamEventStorageOutputSvc()
    
    svcMgr.ByteStreamCnvSvc.ByteStreamOutputSvc = "ByteStreamEventStorageOutputSvc"
    #DOES NOT WORK ANYMORE
    #svcMgr.ByteStreamCnvSvc.ByteStreamOutputSvcList += ["ByteStreamEventStorageOutputSvc"]    

    from AthenaServices.AthenaServicesConf import AthenaOutputStream
    StreamBSFileOutput = AthenaOutputStream(
        "StreamBSFileOutput",
        EvtConversionSvc = "ByteStreamCnvSvc",
        OutputFile = "ByteStreamEventStorageOutputSvc",
        ForceRead=True
        )
    theApp.addOutputStream( StreamBSFileOutput )
    theApp.OutStreamType ="AthenaOutputStream";
    


    # maximum event size (beyond which it creates a new file) 15GB like for Pool
    svcMgr.ByteStreamEventStorageOutputSvc.MaxFileMB = 15000
    # maximum number of event (beyond which it creates a new file)
    svcMgr.ByteStreamEventStorageOutputSvc.MaxFileNE = 15000000
    svcMgr.ByteStreamEventStorageOutputSvc.OutputDirectory = "./"
    svcMgr.ByteStreamEventStorageOutputSvc.AppName = "Athena"
    # release variable depends the way the env is configured
    #svcMgr.ByteStreamEventStorageOutputSvc.FileTag = release    
    svcMgr.ByteStreamEventStorageOutputSvc.RunNumber = 0   
    # does not work
    if hasattr( svcMgr.EventSelector, 'RunNumber'):
        svcMgr.ByteStreamEventStorageOutputSvc.RunNumber = svcMgr.EventSelector.RunNumber()


    # decode BSRDOOutput property and overwrite some OutputStream properties if things are there defined
    props = athenaCommonFlags.BSRDOOutput().split(",")
    for p in props:
        if "AppName" in p:
            svcMgr.ByteStreamEventStorageOutputSvc.AppName = p.split("=")[1]
        if "OutputDirectory" in p:
            svcMgr.ByteStreamEventStorageOutputSvc.OutputDirectory = p.split("=")[1]
        if "FileTag" in p:
            svcMgr.ByteStreamEventStorageOutputSvc.FileTag =  p.split("=")[1]
        if "Run" in p:
            svcMgr.ByteStreamEventStorageOutputSvc.RunNumber = int(p.split("=")[1])
            
    ##StreamBSFileOutput = AthenaOutputStream("StreamBSFileOutput", EvtConversionSvc = "ByteStreamCnvSvc")


    # BS content definition
    # LVL1
    StreamBSFileOutput.ItemList   += [ "ROIB::RoIBResult#*" ]

    StreamBSFileOutput.ItemList += [ "DataVector<LVL1::TriggerTower>#TriggerTowers" ]
    StreamBSFileOutput.ItemList += [ "LVL1::JEPBSCollection#JEPBSCollection" ]
    StreamBSFileOutput.ItemList += [ "LVL1::JEPRoIBSCollection#JEPRoIBSCollection" ]
    StreamBSFileOutput.ItemList += [ "LVL1::CPBSCollection#CPBSCollection" ]
    StreamBSFileOutput.ItemList += [ "DataVector<LVL1::CPMRoI>#CPMRoIs" ]

    
    # LVL2
    if TriggerFlags.doLVL2() or TriggerFlags.doEF():
        StreamBSFileOutput.ItemList   += [ "HLT::HLTResult#HLTResult_L2" ]    
        StreamBSFileOutput.ItemList   += [ "HLT::HLTResult#HLTResult_EF" ]
    if hasattr( topSequence, "StreamBS"):
        StreamBSFileOutput.ItemList += topSequence.StreamBS.ItemList
    else: # we would not need all what is below if we exclude use casese BS -> BS
        # LVL2
        StreamBSFileOutput.ItemList   += [ "HLT::HLTResult#HLTResult_L2" ]
        StreamBSFileOutput.ItemList   += [ "HLT::HLTResult#HLTResult_EF" ]

        StreamBSFileOutput.ItemList += [ "TRT_RDO_Container#*" ]
        StreamBSFileOutput.ItemList += [ "SCT_RDO_Container#*" ]
        StreamBSFileOutput.ItemList += [ "PixelRDO_Container#*" ]

        # Pixel CABLING
        from InDetCabling.InDetCablingConf import PixelFillCablingData_Cosmics as PixelFillCablingData
        PixelFillCablingData = PixelFillCablingData(Bandwidth = 0, MappingFile = "Pixels_Atlas_IdMapping.dat")
        ToolSvc             += PixelFillCablingData

        # SCT CABLING
        from InDetCabling.InDetCablingConf import SCT_CablingSelector
        SCT_CablingSelector = SCT_CablingSelector(Method = "MANUAL", Layout = "FromTextFile", Filename = "SCT_MC_FullCabling.dat")
        ToolSvc            += SCT_CablingSelector

        # LAr
        #        StreamBS.ItemList +=["LArRawChannels#*"]
        StreamBSFileOutput.ItemList +=["2721#*"]

        from LArByteStream.LArByteStreamConf import LArRawDataContByteStreamTool                 
        
        ToolSvc+=LArRawDataContByteStreamTool(InitializeForWriting=True)

        # Tile
        #        StreamBS.ItemList +=["TileRawChannelCnt#*"]
        StreamBSFileOutput.ItemList +=["2927#*"]

        # Muon
        StreamBSFileOutput.ItemList +=["MdtCsmContainer#*"]
        StreamBSFileOutput.ItemList +=["RpcPadContainer#*"]
        StreamBSFileOutput.ItemList +=["TgcRdoContainer#*"]
        StreamBSFileOutput.ItemList +=["CscRawDataContainer#*"]

# EOF BS Writting (T Bold)    

print "List all Dlls"
print theApp.Dlls
print "List all ExtSvc"
print theApp.ExtSvc
print "List of all top algorithms"
print theApp.TopAlg



# dump all known python properties of algorithms and services (including tools)
if rec.doDumpProperties():
    print topSequence
    print ServiceMgr
    #print ToolSvc # already included in ServiceMgr

#objKeyStore.Print()
print objKeyStore

# dump objKeyStore content in a readable way
objKeyStore.writeStreamRDO('OKS_streamRDO_current.py')
objKeyStore.writeStreamESD('OKS_streamESD_current.py')
objKeyStore.writeStreamAOD('OKS_streamAOD_current.py')
objKeyStore.writeStreamTAG('OKS_streamTAG_current.py')


# switch on auditor on specific alg or service
# to measure CPU time and memory spend in initialisation
# alg.AuditInitialize = True
# svc.AuditInitialize = True


    
if rec.doCheckJOT():
    JOT.joWarns()
    JOT.propWarns()

print "jobproperties when exiting RecExCommon_topOptions.py"
jobproperties.print_JobProperties('tree&value')



# end of configuration : check that some standalone flag have not been reinstantiated
varInit=dir()
if not rec.oldFlagCompatibility:
    for i in RecExCommonFlags.keys(): 
        if i in varInit:
            logRecExCommon_topOptions.warning("Variable %s has been re-declared, forbidden !" % i)



