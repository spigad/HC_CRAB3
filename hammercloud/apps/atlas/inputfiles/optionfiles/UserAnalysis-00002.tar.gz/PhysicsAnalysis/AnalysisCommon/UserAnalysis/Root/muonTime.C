#include <sstream>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <vector>

#include "TSystem.h"
#include "TTree.h"
#include "TBranch.h"
#include "TString.h"
#include "TCanvas.h"
#include "TKey.h"
#include "TFile.h"
#include "TClassTable.h"
#include "TStopwatch.h"

#include "UserAnalysisEvent/TrackParticle.h"
#include "UserAnalysisEvent/CaloCluster.h"
#include "UserAnalysisEvent/Muon.h"

using namespace User;

void muonTime () {

  TFile *  f = new TFile("/afs/cern.ch/user/k/ketevi/scratch0/Tutorial/12.0.2/data/SAN.root");
  TTree *  tree = (TTree*)gDirectory->Get("CollectionTree");

  /** Muon */
  std::vector<User::Muon> * pMuon=0;
  tree->SetBranchAddress("StacoMuonCollection",&pMuon);
  TBranch * muonBranch = tree->GetBranch("StacoMuonCollection");

  Long64_t nentries = tree->GetEntriesFast();
  double nbytes = 0; 
  
  TStopwatch timer;
  timer.Start();
  for (Long64_t jentry=0; jentry<nentries;jentry++) {

    /** Read the Muon */
    nbytes += muonBranch->GetEntry(jentry);     
  }
  timer.Stop();
  Double_t kbytes = 0.001*nbytes;
  Double_t rtime = timer.RealTime();
  Double_t ctime = timer.CpuTime();
  std::cout << "You have read " << nentries << " Events with " << kbytes << " kb total" << std::endl;
  std::cout << "RealTime and CpuTime in seconds = " << rtime << " " << ctime << endl;
  std::cout << "RealTime::You read " << kbytes/rtime << " kb/s" << std::endl;
  std::cout << "CPUTime::You read  " << kbytes/ctime << " kb/s" << std::endl;
  
  f->Close();
  
  return;
  
}
