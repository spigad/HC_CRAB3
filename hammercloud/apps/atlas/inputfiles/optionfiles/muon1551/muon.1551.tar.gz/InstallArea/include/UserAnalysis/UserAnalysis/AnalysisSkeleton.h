#ifndef ANALYSIS_SKELETON_H
#define ANALYSIS_SKELETON_H
/////////////////////////////////////////////////////////////////////////////////////////////////////
/// Name    : AnalysisSkeleton.h
/// Package : offline/PhysicsAnalysis/AnalysisCommon/UserAnalysis
/// Author  : Ketevi A. Assamagan
/// Created : July 2004
///
/// DESCRIPTION:
///
/// This class is an analysis skeleton - The user can implement his analysis here
/// This class is also used for the demonstration of the distributed analysis
/// Some electron histograms are used for the distributed case. The user may
/// remove the histograms and the electron stuff if not needed.
/// Note: the single algorithm structure as an analysis code does not scale
/// For detailed analysis examples, look in CVS: PhysicsAnalysis/AnalysisCommon/AnalysisExamples/
/// Ketevi A. Assamagan on June 9, 2004
///
///////////////////////////////////////////////////////////////////////////////////////////////////////

#include "GaudiKernel/ToolHandle.h"
#include "GaudiKernel/Algorithm.h"
#include "GaudiKernel/ObjectVector.h"
#include "CLHEP/Units/SystemOfUnits.h"
#include "StoreGate/StoreGateSvc.h"
#include "GaudiKernel/ITHistSvc.h"

#include "AnalysisTools/AnalysisTools.h"

//#include "TLorentzVector.h"
//#include "CLHEP/Vector/LorentzVector.h"

#include "CBNT_Utils/CBNT_AthenaAwareBase.h"
#include "TrigDecision/TrigDecisionTool.h"
#include <string>
#include <map>

#include "TH1.h"
#include "TH2.h"

class LVL1_ROI;
class Muon_ROI;
class MuonFeatureContainer;
class MuonFeature;
class CombinedMuonFeatureContainer;
class CombinedMuonFeature;
class TrigMuonEF;
class TrigMuonEFContainer;

class AnalysisSkeleton : public CBNT_AthenaAwareBase  {

 public:

   AnalysisSkeleton(const std::string& name, ISvcLocator* pSvcLocator);
   ~AnalysisSkeleton();

   virtual StatusCode CBNT_initializeBeforeEventLoop();
   virtual StatusCode CBNT_initialize();
   virtual StatusCode CBNT_finalize();
   virtual StatusCode CBNT_execute();
   virtual StatusCode CBNT_clear();

 private:

   /** method called by CBNT_execute()  */
   StatusCode dumpMuonTrigger();
   StatusCode dumpMuonTrigger_OLD();
   StatusCode dumpMuonTrigger_noTruth();
   StatusCode trigDec();
   StatusCode wrtOffline();
   StatusCode fakeProb();
   //   StatusCode electronSkeleton();
   StatusCode bookHistos();
   StatusCode trackParticleAnalysis();

 private:


   /** handle for Trigdecision tool */
   ToolHandle<TrigDec::TrigDecisionTool> m_trigDec;

   /** get a handle to the tool helper */
   ToolHandle<AnalysisTools> m_analysisTools;

   /** a handle on the Hist/TTree registration service */
   ITHistSvc * m_thistSvc;

   /** a handle on Store Gate for access to the Event Store */
   StoreGateSvc* m_storeGate;

   //////////////////// To be removed if not needed ///////////////////////////
   /// only here for distributed analysis example

   /** name of the AOD electron container to retrieve from StoreGate */
   std::string m_electronContainerName;
 
   /** name of the AOD truth particle container to retrieve from StoreGate */
   std::string m_truthParticleContainerName;

   /** cuts for user  pre selected electrons, muons and taus - 
       to be modified thru job options */

   double m_ptThrTruth;
 
   double m_deltaRMatchCut;
   double m_deltaRMatchCutLOW;
   double m_deltaRMatchCutL1;
   double m_maxDeltaR;

   bool m_doTruth;
   bool m_doTrigDec;

   /** electron specific cuts */
   double m_etElecCut;
   double m_elecCone;

   double m_etaElecCut;

   int    m_NfakeSA;
   int    m_NfakeCB;
   int    m_NfakeSA_tmef;
   int    m_NfakeCB_tmef;
   int    m_NfakeSA_mu6;
   int    m_NfakeCB_mu6;
   int    m_NfakeSA_tmef_mu6;
   int    m_NfakeCB_tmef_mu6;
   int    m_NfakeSA_mu20;
   int    m_NfakeCB_mu20;
   int    m_NfakeSA_tmef_mu20;
   int    m_NfakeCB_tmef_mu20;

   std::map<std::string,int> m_triggerItemsL1;
   std::map<std::string,int> m_triggerItemsL2;
   std::map<std::string,int> m_triggerItemsEF;
   
  /** Histograms */
   TH1F*   m_h_trketa;
   TH1F*     m_h_trkphi;
   TH1F*     m_h_trkpt ;
   
   TH1F*   m_h_MCeta_4;
   TH1F*   m_h_MCeta_6;
   TH1F*   m_h_MCeta_20;
   TH1F*   m_h_MCeta_40;
   TH1F*    m_h_MCphi_b;
   TH1F*    m_h_MCphi_e;
   TH1F*    m_h_MCpt;
   TH1F*    m_h_MCpt_b;
   TH1F*    m_h_MCpt_e;
   TH1F*    m_h_MCpt_b_4;
   TH1F*    m_h_MCpt_b_6;
   TH1F*    m_h_MCpt_b_20;
   TH1F*    m_h_MCpt_b_40;
   TH1F*    m_h_MCpt_e_4;
   TH1F*    m_h_MCpt_e_6;
   TH1F*    m_h_MCpt_e_20;
   TH1F*    m_h_MCpt_e_40;

  TH1F* m_h_muonpt_l1_b;
  TH1F* m_h_muoneta_l1;
  TH1F* m_h_muonphi_l1_b;
  TH1F* m_h_muonpt_l1_e;
  TH1F* m_h_muonphi_l1_e;

  TH1F*   m_h_DR_l1;
  TH1F*  m_h_muonpt_l1_b_truth;
  TH1F*  m_h_muonpt_l1_e_truth;

  TH1F*  m_h_muonpt_l1_b_truth_6;
  TH1F*  m_h_muonpt_l1_e_truth_6;
  TH1F*  m_h_muonpt_l1_b_truth_20;
  TH1F*  m_h_muonpt_l1_e_truth_20;
  TH1F*  m_h_muonpt_l1_b_truth_40;
  TH1F*  m_h_muonpt_l1_e_truth_40;

  TH1F*  m_h_muoneta_l1_truth;
  TH1F*  m_h_muoneta_l1_truth_6;
  TH1F*  m_h_muoneta_l1_truth_20;
  TH1F*  m_h_muoneta_l1_truth_40;

  /** Histograms */
  TH1F* m_h_muonpt_l2ms;
  TH1F* m_h_muonpt_l2ms_b;
  TH1F* m_h_muonpt_l2ms_e;
  TH1F* m_h_muoneta_l2ms;
  TH1F* m_h_muonphi_l2ms;
  TH2F*  m_h_muonptVSeta_l2ms;
  TH1F*   m_h_DR_l2ms;
  TH1F*  m_h_muonpt_l2ms_b_truth;
  TH1F*  m_h_muonpt_l2ms_b_truth_6;
  TH1F*  m_h_muonpt_l2ms_b_truth_20;
  TH1F*  m_h_muonpt_l2ms_b_truth_40;
  TH1F*  m_h_muonpt_l2ms_e_truth;
  TH1F*  m_h_muonpt_l2ms_e_truth_6;
  TH1F*  m_h_muonpt_l2ms_e_truth_20;
  TH1F*  m_h_muonpt_l2ms_e_truth_40;
  TH1F*  m_h_muoneta_l2ms_truth;
  TH1F*  m_h_muoneta_l2ms_truth_6;
  TH1F*  m_h_muoneta_l2ms_truth_20;
  TH1F*  m_h_muoneta_l2ms_truth_40;
  TH2F* m_h_ptres_vs_pt_l2ms;

  /** Histograms */
  TH1F* m_h_muonpt_l2cb;
  TH1F* m_h_muonpt_l2cb_b;
  TH1F* m_h_muonpt_l2cb_e;
  TH1F* m_h_muoneta_l2cb;
  TH1F* m_h_muonphi_l2cb;
  
  TH1F*   m_h_DR_l2cb;
  TH1F*  m_h_muonpt_l2cb_b_truth;
  TH1F*  m_h_muonpt_l2cb_b_truth_6;
  TH1F*  m_h_muonpt_l2cb_b_truth_20;
  TH1F*  m_h_muonpt_l2cb_b_truth_40;
  TH1F*  m_h_muonpt_l2cb_e_truth;
  TH1F*  m_h_muonpt_l2cb_e_truth_6;
  TH1F*  m_h_muonpt_l2cb_e_truth_20;
  TH1F*  m_h_muonpt_l2cb_e_truth_40;
  TH1F*  m_h_muoneta_l2cb_truth;
  TH1F*  m_h_muoneta_l2cb_truth_6;
  TH1F*  m_h_muoneta_l2cb_truth_20;
  TH1F*  m_h_muoneta_l2cb_truth_40;
  TH2F* m_h_ptres_vs_pt_l2cb;

  /** Histograms */
  TH1F* m_h_muonpt_ms;
  TH1F* m_h_muonpt_ms_b;
  TH1F* m_h_muonpt_ms_e;
  TH1F* m_h_muoneta_ms;
  TH1F* m_h_muonphi_ms;
  TH1F*   m_h_DR_efms;
  TH1F*  m_h_muonpt_efms_b_truth;
  TH1F*  m_h_muonpt_efms_b_truth_6;
  TH1F*  m_h_muonpt_efms_b_truth_20;
  TH1F*  m_h_muonpt_efms_b_truth_40;
  TH1F*  m_h_muonpt_efms_e_truth;
  TH1F*  m_h_muonpt_efms_e_truth_6;
  TH1F*  m_h_muonpt_efms_e_truth_20;
  TH1F*  m_h_muonpt_efms_e_truth_40;
  TH1F*  m_h_muoneta_efms_truth;
  TH1F*  m_h_muoneta_efms_truth_6;
  TH1F*  m_h_muoneta_efms_truth_20;
  TH1F*  m_h_muoneta_efms_truth_40;
             


  /** Histograms */
  TH1F* m_h_muonpt_sa;
  TH1F* m_h_muonpt_sa_b;
  TH1F* m_h_muonpt_sa_e;
  TH1F* m_h_muoneta_sa;
  TH1F* m_h_muonphi_sa;
  TH1F*   m_h_DR_sa;
  TH1F*  m_h_muonpt_sa_b_truth;
  TH1F*  m_h_muonpt_sa_e_truth;
  TH1F*  m_h_muoneta_sa_truth;
  TH1F*  m_h_ptres_sa5;
  TH1F*  m_h_ptres_sa10;
  TH1F*  m_h_ptres_sa15;
  TH1F*  m_h_ptres_sa20;
  TH1F*  m_h_ptres_sa25;
  TH1F*  m_h_ptres_sa30;
  TH1F*  m_h_ptres_sa35;
  TH1F*  m_h_ptres_sa40;

  TH1F*   m_h_DR_efsa;
  TH1F*  m_h_muonpt_efsa_b_truth;
  TH1F*  m_h_muonpt_efsa_b_truth_6;
  TH1F*  m_h_muonpt_efsa_b_truth_20;
  TH1F*  m_h_muonpt_efsa_b_truth_40;
  TH1F*  m_h_muonpt_efsa_e_truth;
  TH1F*  m_h_muonpt_efsa_e_truth_6;
  TH1F*  m_h_muonpt_efsa_e_truth_20;
  TH1F*  m_h_muonpt_efsa_e_truth_40;
  TH1F*  m_h_muoneta_efsa_truth;
  TH1F*  m_h_muoneta_efsa_truth_6;
  TH1F*  m_h_muoneta_efsa_truth_20;
  TH1F*  m_h_muoneta_efsa_truth_40;
  TH2F* m_h_ptres_vs_pt_efsa;
  TH1F*   m_h_muonpt_safake;
  TH2F* m_h_pt_vs_eta_efsa;

  TH1F* m_h_muonpt_sa_tmef;
  TH1F* m_h_muonpt_sa_b_tmef;
  TH1F* m_h_muonpt_sa_e_tmef;
  TH1F* m_h_muoneta_sa_tmef;
  TH1F* m_h_muonphi_sa_tmef;  
  TH1F*   m_h_DR_efsa_tmef;
  TH1F*  m_h_muonpt_efsa_b_truth_tmef;
  TH1F*  m_h_muonpt_efsa_b_truth_6_tmef;
  TH1F*  m_h_muonpt_efsa_b_truth_20_tmef;
  TH1F*  m_h_muonpt_efsa_b_truth_40_tmef;
  TH1F*  m_h_muonpt_efsa_e_truth_tmef;
  TH1F*  m_h_muonpt_efsa_e_truth_6_tmef;
  TH1F*  m_h_muonpt_efsa_e_truth_20_tmef;
  TH1F*  m_h_muonpt_efsa_e_truth_40_tmef;
  TH1F*  m_h_muoneta_efsa_truth_tmef;
  TH1F*  m_h_muoneta_efsa_truth_6_tmef;
  TH1F*  m_h_muoneta_efsa_truth_20_tmef;
  TH1F*  m_h_muoneta_efsa_truth_40_tmef;
  TH2F* m_h_ptres_vs_pt_efsa_tmef;

  TH1F*   m_h_muonpt_safake_tmef;
  

  /** Histograms */
  TH1F* m_h_muonpt_cb;
  TH1F* m_h_muonpt_cb_b;
  TH1F* m_h_muonpt_cb_e;
  TH1F* m_h_muoneta_cb;
  TH1F* m_h_muonphi_cb;
  TH1F*   m_h_DR_cb;
  TH1F*  m_h_muonpt_cb_b_truth;
  TH1F*  m_h_muonpt_cb_e_truth;
  TH1F*  m_h_muoneta_cb_truth;
  TH1F*  m_h_ptres_cb5;
  TH1F*  m_h_ptres_cb10;
  TH1F*  m_h_ptres_cb15;
  TH1F*  m_h_ptres_cb20;
  TH1F*  m_h_ptres_cb25;
  TH1F*  m_h_ptres_cb30;
  TH1F*  m_h_ptres_cb35;
  TH1F*  m_h_ptres_cb40;

  TH1F*   m_h_DR_efcb;
  TH1F*  m_h_muonpt_efcb_b_truth;
  TH1F*  m_h_muonpt_efcb_b_truth_6;
  TH1F*  m_h_muonpt_efcb_b_truth_20;
  TH1F*  m_h_muonpt_efcb_b_truth_40;
  TH1F*  m_h_muonpt_efcb_e_truth;
  TH1F*  m_h_muonpt_efcb_e_truth_6;
  TH1F*  m_h_muonpt_efcb_e_truth_20;
  TH1F*  m_h_muonpt_efcb_e_truth_40;
  TH1F*  m_h_muoneta_efcb_truth;
  TH1F*  m_h_muoneta_efcb_truth_6;
  TH1F*  m_h_muoneta_efcb_truth_20;
  TH1F*  m_h_muoneta_efcb_truth_40;
  TH2F* m_h_ptres_vs_pt_efcb;
  TH1F*   m_h_muonpt_cbfake;
  TH2F* m_h_pt_vs_eta_efcb;

  TH1F* m_h_muonpt_cb_tmef;
  TH1F* m_h_muonpt_cb_b_tmef;
  TH1F* m_h_muonpt_cb_e_tmef;
  TH1F* m_h_muoneta_cb_tmef;
  TH1F* m_h_muonphi_cb_tmef;  
  TH1F*   m_h_DR_efcb_tmef;
  TH1F*  m_h_muonpt_efcb_b_truth_tmef;
  TH1F*  m_h_muonpt_efcb_b_truth_6_tmef;
  TH1F*  m_h_muonpt_efcb_b_truth_20_tmef;
  TH1F*  m_h_muonpt_efcb_b_truth_40_tmef;
  TH1F*  m_h_muonpt_efcb_e_truth_tmef;
  TH1F*  m_h_muonpt_efcb_e_truth_6_tmef;
  TH1F*  m_h_muonpt_efcb_e_truth_20_tmef;
  TH1F*  m_h_muonpt_efcb_e_truth_40_tmef;
  TH1F*  m_h_muoneta_efcb_truth_tmef;
  TH1F*  m_h_muoneta_efcb_truth_6_tmef;
  TH1F*  m_h_muoneta_efcb_truth_20_tmef;
  TH1F*  m_h_muoneta_efcb_truth_40_tmef;
  TH2F* m_h_ptres_vs_pt_efcb_tmef;

  TH1F*   m_h_muonpt_cbfake_tmef;

  
  //  no truth
  TH2F* m_h_ptl1_vs_ptl2_l2sa_b;
  TH2F*  m_h_ptl1_vs_ptl2_l2cb_b;
  TH2F*  m_h_ptl1_vs_ptl2_l2sa_e;
  TH2F*  m_h_ptl1_vs_ptl2_l2cb_e;
  
  TH1F* m_h_muonpt_l1_b_nt;
  TH1F* m_h_muoneta_l1_nt;
  TH1F* m_h_muonphi_l1_b_nt;
  TH1F* m_h_muonpt_l1_e_nt;
  TH1F* m_h_muonphi_l1_e_nt;

  TH1F* m_h_muonpt_l1_b_nt_matched_l2sa;
  TH1F* m_h_muoneta_l1_nt_matched_l2sa;
  TH1F* m_h_muonphi_l1_b_nt_matched_l2sa;
  TH1F* m_h_muonpt_l1_e_nt_matched_l2sa;
  TH1F* m_h_muonphi_l1_e_nt_matched_l2sa;
  TH1F* m_h_muonpt_l1_b_nt_matched_l2cb;
  TH1F* m_h_muoneta_l1_nt_matched_l2cb;
  TH1F* m_h_muonphi_l1_b_nt_matched_l2cb;
  TH1F* m_h_muonpt_l1_e_nt_matched_l2cb;
  TH1F* m_h_muonphi_l1_e_nt_matched_l2cb;

  TH1F* m_h_muonpt_l2_b_nt_matched_efsa;
  TH1F* m_h_muoneta_l2_nt_matched_efsa;
  TH1F* m_h_muonphi_l2_b_nt_matched_efsa;
  TH1F* m_h_muonpt_l2_e_nt_matched_efsa;
  TH1F* m_h_muonphi_l2_e_nt_matched_efsa;
  TH1F* m_h_muonpt_l2_b_nt_matched_efcb;
  TH1F* m_h_muoneta_l2_nt_matched_efcb;
  TH1F* m_h_muonphi_l2_b_nt_matched_efcb;
  TH1F* m_h_muonpt_l2_e_nt_matched_efcb;
  TH1F* m_h_muonphi_l2_e_nt_matched_efcb;



  TH1F* m_h_muonpt_b_nt_l2sa;
  TH1F* m_h_muoneta_nt_l2sa;
  TH1F* m_h_muonphi_b_nt_l2sa;
  TH1F* m_h_muonpt_e_nt_l2sa;
  TH1F* m_h_muonphi_e_nt_l2sa;
  TH1F* m_h_muonpt_b_nt_l2cb;
  TH1F* m_h_muoneta_nt_l2cb;
  TH1F* m_h_muonphi_b_nt_l2cb;
  TH1F* m_h_muonpt_e_nt_l2cb;
  TH1F* m_h_muonphi_e_nt_l2cb;

  //wrt offline
  TH1F*   m_h_pt_offmuon_matched_l1_b_mu6;
  TH1F*   m_h_pt_offmuon_matched_l1_b_mu10;
  TH1F*   m_h_pt_offmuon_matched_l1_b_mu11;
  TH1F*   m_h_pt_offmuon_matched_l1_b_mu20;
  TH1F*  m_h_pt_offmuon_matched_l1_b_mu40;

  TH1F*   m_h_pt_offmuon_matched_l1_e_mu6;
  TH1F*   m_h_pt_offmuon_matched_l1_e_mu10;
  TH1F*   m_h_pt_offmuon_matched_l1_e_mu11;
  TH1F*   m_h_pt_offmuon_matched_l1_e_mu20;
  TH1F*  m_h_pt_offmuon_matched_l1_e_mu40;
  TH1F*  m_h_eta_offmuon_matched_l1  ;

  TH1F* m_h_pt_offmuon_b;
  TH1F* m_h_pt_offmuon_e;
  TH1F*  m_h_eta_offmuon;  
  TH2F * m_h_ptl1_vs_ptoffmuon_b; 
  TH2F * m_h_ptl1_vs_ptoffmuon_e; 
     //  TH1F* m_h_muonpt_rec_cb_b;
     //TH1F* m_h_muonpt_rec_cb_e;
    
  TH1F*  m_h_pt_offmuon_matched_l2sa_b;     
  TH1F*  m_h_pt_offmuon_matched_l2sa_b_mu6;     
  TH1F*  m_h_pt_offmuon_matched_l2sa_b_mu20;     
  TH1F*  m_h_phi_offmuon_matched_l2sa_b ;
  TH1F*  m_h_pt_offmuon_matched_l2sa_e  ;
  TH1F*  m_h_pt_offmuon_matched_l2sa_e_mu6;     
  TH1F*  m_h_pt_offmuon_matched_l2sa_e_mu20;     
  TH1F*  m_h_phi_offmuon_matched_l2sa_e ;
  TH1F*  m_h_eta_offmuon_matched_l2sa   ;

  TH1F*  m_h_pt_offmuon_matched_l2cb_b;     
  TH1F*  m_h_pt_offmuon_matched_l2cb_b_mu6;     
  TH1F*  m_h_pt_offmuon_matched_l2cb_b_mu20;     
  TH1F*  m_h_phi_offmuon_matched_l2cb_b ;
  TH1F*  m_h_pt_offmuon_matched_l2cb_e  ;
  TH1F*  m_h_pt_offmuon_matched_l2cb_e_mu6;     
  TH1F*  m_h_pt_offmuon_matched_l2cb_e_mu20;     
  TH1F*  m_h_phi_offmuon_matched_l2cb_e ;
  TH1F*  m_h_eta_offmuon_matched_l2cb   ;


  //trigger decision tool
  TH1F* m_h_l1item;
  TH1F* m_h_l2item;
  TH1F* m_h_efitem;
  TH1F* m_h_l1item_all;
  TH1F* m_h_l2item_all;
  TH1F* m_h_efitem_all;


  //fakes
  TH1F* m_h_ptfakeSAL2;
  TH1F* m_h_etafakeSAL2;
  TH1F* m_h_phifakeSAL2;
  TH1F* m_h_ptfakeCBL2;
  TH1F* m_h_etafakeCBL2;
  TH1F* m_h_phifakeCBL2;
  TH1F* m_h_ptfakeSA;
  TH1F* m_h_etafakeSA;
  TH1F* m_h_phifakeSA;
  TH1F* m_h_ptfakeCB;
  TH1F* m_h_etafakeCB;
  TH1F* m_h_phifakeCB;
  TH1F* m_h_ptfakeSA_tmef;
  TH1F* m_h_etafakeSA_tmef;
  TH1F* m_h_phifakeSA_tmef;
  TH1F* m_h_ptfakeCB_tmef;
  TH1F* m_h_etafakeCB_tmef;
  TH1F* m_h_phifakeCB_tmef;


  /** Athena-Aware Ntuple (AAN) variables - branches of the AAN TTree */

  /** Simple variables */
  int m_aan_size;
  std::vector<double> * m_aan_eta;
  std::vector<double> * m_aan_pt;
  std::vector<double> * m_aan_elecetres;

  double m_PlateauStep;
  
  bool matchL1 (double &deltaR, Muon_ROI &, const DataHandle<LVL1_ROI> lvl1ROI, const double eta, const double phi) const;
  bool matchL2SA(double &deltaR , MuonFeature & , const MuonFeatureContainer *, float &etal2, float &phil2) const;
  bool matchL2CB(double &deltaR , CombinedMuonFeature & , const CombinedMuonFeatureContainer *, 
		 float &etal2, float &phil2) const ;
  bool matchEF(double &deltaR, TrigMuonEF & muon, const DataHandle<TrigMuonEFContainer>& trigMuon,
		 const DataHandle<TrigMuonEFContainer>& lastTrigMuon, 
		 float &eta, float &phi, int muonCode) const ;

  bool matchEF(double &deltaR, const TruthParticleContainer*& truthTDS,
				 float &etal2, float &phil2) const  ;

  bool matchR (const double, const double, const TruthParticleContainer *, int &, 
	      double &, const int&, const bool) const;


  double DR (const Muon_ROI &p1, const double & v_eta, const double & v_phi)  const ; 
  double DR (MuonFeature *  p1, const double & v_eta, const double & v_phi)  const ;
  double DR (CombinedMuonFeature * p1, const double & v_eta, const double & v_phi)  const ;
  double DR (const TruthParticle *p1, const double & v_eta, const double & v_phi) const ;
  double DR (const TrigMuonEF *p1, const double & v_eta, const double & v_phi) const ;

  //  template <class COLL>
  // bool R (const double eta, const double phi, COLL *coll, int &index, double &deltaR, const int pdg);

  //  template <class COLL>
  // bool R (const INavigable4Momentum *t, COLL *coll, int &index, double &deltaR, const int pdg);
  
  //  bool R (const INavigable4Momentum *t, const TruthParticleContainer *coll, int &index, double &deltaR,
  //  const int pdg, const bool);
  
  /////////////////////// the above to be removed if not needed ////////////////////
  
};

#endif // ANALYSIS_SKELETON_H

