#include "UserAnalysis/AnalysisSkeleton.h"
//#include "UserAnalysis/StructuredAAN.h"

#include "GaudiKernel/DeclareFactoryEntries.h"

DECLARE_ALGORITHM_FACTORY( AnalysisSkeleton )
  //DECLARE_ALGORITHM_FACTORY( StructuredAAN )

DECLARE_FACTORY_ENTRIES( UserAnalysis ) {
  DECLARE_ALGORITHM( AnalysisSkeleton )
    //  DECLARE_ALGORITHM( StructuredAAN )
}

