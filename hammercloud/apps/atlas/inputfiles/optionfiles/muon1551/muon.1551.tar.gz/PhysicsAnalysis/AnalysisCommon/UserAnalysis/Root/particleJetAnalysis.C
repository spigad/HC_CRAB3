#include <sstream>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <vector>

#include "TSystem.h"
#include "TTree.h"
#include "TBranch.h"
#include "TString.h"
#include "TCanvas.h"
#include "TKey.h"
#include "TFile.h"
#include "TClassTable.h"
#include "TStopwatch.h"

#include "UserAnalysisEvent/TrackParticle.h"
#include "UserAnalysisEvent/CaloCluster.h"
#include "UserAnalysisEvent/Electron.h"
#include "UserAnalysisEvent/Muon.h"
#include "UserAnalysisEvent/ParticleJet.h"

#include "UserAnalysisEvent/ElectronConstituent.h"
#include "UserAnalysisEvent/MuonConstituent.h"
#include "UserAnalysisEvent/JetConstituent.h"
#include "UserAnalysisEvent/TrackConstituents.h"
#include "UserAnalysisEvent/CaloClusterConstituents.h"
#include "UserAnalysisEvent/CaloSampling.h"

using namespace User;

void particleJetAnalysis () {

  TFile *  f = new TFile("SAN.root");
  TTree *  tree = (TTree*)gDirectory->Get("CollectionTree");

  /** TrackParticle */
  std::vector<TrackParticle> * pTrack=0;
  tree->SetBranchAddress("TrackParticleCandidate",&pTrack);
  TBranch * trackBranch = tree->GetBranch("TrackParticleCandidate");

  /** CaloClusters */
  std::vector<CaloCluster> * pLArClusterEM=0;
  tree->SetBranchAddress("LArClusterEM",&pLArClusterEM);
  TBranch * clusEMBranch = tree->GetBranch("LArClusterEM");

  std::vector<CaloCluster> * pLArClusterEM37=0;
  tree->SetBranchAddress("LArClusterEM37",&pLArClusterEM37);
  TBranch * clusEM37Branch = tree->GetBranch("LArClusterEM37");

  std::vector<CaloCluster> * pLArClusterEMSofte=0;
  tree->SetBranchAddress("LArClusterEMSofte",&pLArClusterEMSofte);
  TBranch * clusEMSofteBranch = tree->GetBranch("LArClusterEMSofte");

  std::vector<CaloCluster> * pCombinedCluster=0;
  tree->SetBranchAddress("CombinedCluster",&pCombinedCluster);
  TBranch * combinedClusterBranch = tree->GetBranch("CombinedCluster");

  std::vector<CaloCluster> * pEMTopoCluster=0;
  tree->SetBranchAddress("EMTopoCluster",&pEMTopoCluster);
  TBranch * clusEMTopoClusterBranch = tree->GetBranch("EMTopoCluster");

  std::vector<CaloCluster> * pCaloCalTopoCluster=0;
  tree->SetBranchAddress("CaloCalTopoCluster",&pCaloCalTopoCluster);
  TBranch * clusCaloCalTopoClusterBranch = tree->GetBranch("CaloCalTopoCluster");

  /** Electron */
  std::vector<Electron> * pElectron=0;
  tree->SetBranchAddress("ElectronCollection",&pElectron);
  TBranch * elecBranch = tree->GetBranch("ElectronCollection");

  /** Muon */
  std::vector<Muon> * pMuon=0;
  tree->SetBranchAddress("StacoMuonCollection",&pMuon);
  TBranch * muonBranch = tree->GetBranch("StacoMuonCollection");

  /** ParticleJet */
  std::vector<ParticleJet> * pJet=0;
  tree->SetBranchAddress("ConeTowerParticleJets",&pJet);
  TBranch * jetBranch = tree->GetBranch("ConeTowerParticleJets");

  Long64_t nentries = tree->GetEntriesFast();
  int nbytes = 0; 
  int nb = 0;
  
  for (Long64_t jentry=0; jentry<nentries;jentry++) {

    std::cout << "Event Number = " << (jentry+1) << std::endl;
    std::cout << " " << std::endl;

    /** Read the Tracks */
    nb = trackBranch->GetEntry(jentry);  nbytes += nb;

    /** Read the EM clusters */
    nb = clusEMBranch->GetEntry(jentry);       nbytes += nb;
    nb = clusEM37Branch->GetEntry(jentry);     nbytes += nb;
    nb = clusEMSofteBranch->GetEntry(jentry);  nbytes += nb;
    nb = combinedClusterBranch->GetEntry(jentry);  nbytes += nb;
    nb = clusEMTopoClusterBranch->GetEntry(jentry);  nbytes += nb;
    nb = clusCaloCalTopoClusterBranch->GetEntry(jentry);  nbytes += nb;
    nb = elecBranch->GetEntry(jentry);  nbytes += nb;
    nb = muonBranch->GetEntry(jentry);  nbytes += nb;

    /** Read the ParticleJet */
    nb = jetBranch->GetEntry(jentry);   nbytes += nb;    

    /** Loop over Jets and do something */
    std::vector<ParticleJet>::const_iterator jetItr  = pJet->begin();
    std::vector<ParticleJet>::const_iterator jetItrE = pJet->end();
    for (; jetItr != jetItrE; ++jetItr) {

      std::cout << "Jet pt()  = " <<  (*jetItr).pt() << std::endl;
      std::cout << "Jet eta() = " <<  (*jetItr).eta() << std::endl;
      std::cout << "Jet phi() = " <<  (*jetItr).phi() << std::endl;

      /** The ParticleJet */
      std::cout << "Jet Tagging weight = " <<  (*jetItr).weight() << std::endl;
      std::cout << "Jet Tagging likelihood = " <<  (*jetItr).lhSig() << std::endl;
      //std::cout << "Jet author = " <<  (*jetItr).jetAuthor() << std::endl;

      /** Jet constituent information - bare jet information */
      const JetConstituent jetC = (*jetItr).jetConstituent(); 
      for (int sample=0; sample<CaloSampling::Unknown; sample++){
         CaloSampling::CaloSample s = static_cast<CaloSampling::CaloSample>(sample);
         std::cout <<"Jet energy in Sampling = " <<  jetC.energyInSample(s) << " Sample = " << s << std::endl;
      }  

      /** Jet constituent information - associated track information */
      const TrackConstituents trackC = (*jetItr).trackConstituents();
      std::cout << "Numbers of tracks in this jet = " << trackC.nTracks() << std::endl; 
      std::vector<const TrackParticle*>* theTracks = trackC.tracks();
      std::vector<const TrackParticle*>::const_iterator trackItr = theTracks->begin();
      std::vector<const TrackParticle*>::const_iterator trackItrE = theTracks->end();
      for (; trackItr != trackItrE; ++trackItr ){
         std::cout <<"Track(i) pt = " <<  (*trackItr)->pt() << " charge = " << (*trackItr)->charge() << std::endl;
      }  

      /** Jet constituent information - associated CaloCluster information */
      const CaloClusterConstituents clusterC = (*jetItr).clusterConstituents();
      std::cout << "Numbers of clusters in this jet = " << clusterC.nClusters() << std::endl; 
      std::vector<const CaloCluster*>* theClusters = clusterC.clusters();
      std::vector<const CaloCluster*>::const_iterator clusterItr = theClusters->begin();
      std::vector<const CaloCluster*>::const_iterator clusterItrE = theClusters->end();
      for (; clusterItr != clusterItrE; ++clusterItr ){
         std::cout <<"Cluster(i) E = " <<  (*clusterItr)->e() << " eta = " << (*clusterItr)->eta() << std::endl;
      }  

      /** Jet constituent information - associated Electron information */
      const ElectronConstituent elecC = (*jetItr).electronConstituent();
      const Electron * electron = elecC.electron();
      if ( electron ) {
       double deltaR = electron->hlv().deltaR( (*jetItr).hlv() );
       std::cout << "electron-jet deltaR = " << deltaR << std::endl;
      } else std::cout << "No Electron found associated to this jet" << std::endl;

      /** Jet constituent information - associated Muon information */
      const MuonConstituent muonC = (*jetItr).muonConstituent();
      const Muon * muon = muonC.muon();
      if ( muon ) {
       double deltaR = muon->hlv().deltaR( (*jetItr).hlv() );
       std::cout << "muon-jet deltaR = " << deltaR << std::endl;
      } else std::cout << "No Muon found associated to this jet" << std::endl;

      std::cout << " " << std::endl;
    }
    std::cout << "------------------------------------- " << std::endl;
  }
  
  f->Close();
  
  return;
  
}
