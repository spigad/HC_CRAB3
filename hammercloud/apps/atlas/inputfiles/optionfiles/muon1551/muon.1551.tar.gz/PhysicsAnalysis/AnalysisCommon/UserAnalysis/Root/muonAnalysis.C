#include <sstream>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <vector>

#include "TSystem.h"
#include "TTree.h"
#include "TBranch.h"
#include "TString.h"
#include "TCanvas.h"
#include "TKey.h"
#include "TFile.h"
#include "TClassTable.h"
#include "TStopwatch.h"
#include "TH1F.h"

#include "UserAnalysisEvent/TrackParticle.h"
#include "UserAnalysisEvent/CaloCluster.h"
#include "UserAnalysisEvent/Muon.h"

using namespace User;
TH1F * NLooseMuon = new TH1F ("NLooseMuon", "NLooseMuon", 100, -.5, 4.5);

void muonAnalysis () {

  TFile *  f = new TFile("SAN.root");
  TTree *  tree = (TTree*)gDirectory->Get("CollectionTree");

  /** TrackParticles */
  std::vector<TrackParticle> * pInDetTrack=0;
  tree->SetBranchAddress("TrackParticleCandidate",&pInDetTrack);
  TBranch * inDetBranch = tree->GetBranch("TrackParticleCandidate");

  /** Muon Spectrometer TrackParticle */
  std::vector<TrackParticle> * pMuonSpTrack=0;
  tree->SetBranchAddress("MuonboyMuonSpectroOnlyTrackParticles",&pMuonSpTrack);
  TBranch * muonSpBranch = tree->GetBranch("MuonboyMuonSpectroOnlyTrackParticles");

  /** Muon TrackParticle at the vertex */
  std::vector<TrackParticle> * pMuonExtrapTrack=0;
  tree->SetBranchAddress("MuonboyTrackParticles",&pMuonExtrapTrack);
  TBranch * extrapBranch = tree->GetBranch("MuonboyTrackParticles");

  /** Muon Combined TrackParticle - STACO */
  std::vector<TrackParticle> * pStacoTrack=0;
  tree->SetBranchAddress("StacoTrackParticles",&pStacoTrack);
  TBranch * stacoBranch = tree->GetBranch("StacoTrackParticles");

  /** Muon */
  std::vector<Muon> * pMuon=0;
  tree->SetBranchAddress("StacoMuonCollection",&pMuon);
  TBranch * muonBranch = tree->GetBranch("StacoMuonCollection");

  Long64_t nentries = tree->GetEntriesFast();
  int nbytes = 0; 
  int nb = 0;
  
  for (Long64_t jentry=0; jentry<nentries;jentry++) {

    std::cout << "Event Number = " << std::dec << (jentry+1) << std::endl;
    std::cout << " " << std::endl;

    /** Read the TrackParticles */
    nb = inDetBranch->GetEntry(jentry);  nbytes += nb;
    nb = muonSpBranch->GetEntry(jentry); nbytes += nb;
    nb = extrapBranch->GetEntry(jentry); nbytes += nb;
    nb = stacoBranch->GetEntry(jentry);  nbytes += nb;

    /** Read the collection of Muons */
    nb = muonBranch->GetEntry(jentry);   nbytes += nb;    

    /** Loop over Muons and do something */
    std::vector<Muon>::const_iterator muonItr = pMuon->begin();
    std::vector<Muon>::const_iterator muonItrE = pMuon->end();

    int icount = 0;

    for (; muonItr != muonItrE; ++muonItr) {

      /** muon selection : pt > 6 GeV && ( combined or extrapolated to vertex ) */
      bool select = (*muonItr).pt() > 6000 && ( (*muonItr).isStandAloneMuon() ||
						(*muonItr).isCombinedMuon() ); 
      /** count the selected muon */
      if ( select ) icount++;

      std::cout << "muon pt()  = " << (*muonItr).pt() << std::endl;
      std::cout << "muon eta() = " <<  (*muonItr).eta() << std::endl;
      std::cout << "muon phi() = " <<  (*muonItr).phi() << std::endl;
      std::cout << "muon fit chi2 = " << (*muonItr).fitChi2OverDoF() << std::endl;
      std::cout << "muon match chi2 = " << (*muonItr).matchChi2OverDoF() << std::endl;
      std::cout << "muon is best match?  = " << (*muonItr).bestMatch() << std::endl;
      std::cout << "muon is highPt? = " << (*muonItr).isHighPt() << std::endl;
      std::cout << "muon is lowPt? = " << (*muonItr).isLowPt() << std::endl;
      std::cout << "muon calo energy loss " << (*muonItr).energyLoss().first << std::endl;
      std::cout << "muon calo energy loss error " << (*muonItr).energyLoss().second << std::endl;
      std::cout << "muon number of Pixel Hits " << (*muonItr).numberOfPixelHits() << std::endl;
      std::cout << "muon isolation ET - cone 0.4 = " << (*muonItr).parameter(muonParameters::etcone40) 
		<< std::endl;
      /** get the primary TrackParticle of this muon -
	  it could be any of the 4 associated TrackParticle. The order of precedence is:
          CombinedTrack, Extrapolated Track to Vertex, MuonSpectrometer Track, Inner Detector Track */
      const TrackParticle * primaryTrack = (*muonItr).track();
      if ( primaryTrack ) {
	std::cout << "Found muon primary Track at " << std::hex << primaryTrack << std::endl;
        /** See trackParticleAnalysis.C for detailed analysis of the TrackParticle */  
      } else std::cout << "No associated Track? Something is wrong" << std::endl;
      std::cout << " " << std::endl;
    }
    std::cout << "------------------------------------- " << std::endl;
    NLooseMuon->Fill(1.0*icount);
  }

  NLooseMuon->Draw();  
  f->Close();
  
  return;
  
}
