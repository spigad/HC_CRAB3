#include <sstream>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <vector>

#include "TSystem.h"
#include "TTree.h"
#include "TBranch.h"
#include "TString.h"
#include "TCanvas.h"
#include "TKey.h"
#include "TFile.h"
#include "TClassTable.h"
#include "TStopwatch.h"

#include "UserAnalysisEvent/TrackParticle.h"
#include "UserAnalysisEvent/CaloCluster.h"
#include "UserAnalysisEvent/TauJet.h"

using namespace User;

void tauJetAnalysis () {

  TFile *  f = new TFile("SAN.root");
  TTree *  tree = (TTree*)gDirectory->Get("CollectionTree");

  /** TrackParticle */
  std::vector<TrackParticle> * pTrack=0;
  tree->SetBranchAddress("TrackParticleCandidate",&pTrack);
  TBranch * trackBranch = tree->GetBranch("TrackParticleCandidate");

  /** CaloClusters */
  std::vector<CaloCluster> * pLArClusterEM=0;
  tree->SetBranchAddress("LArClusterEM",&pLArClusterEM);
  TBranch * clusEMBranch = tree->GetBranch("LArClusterEM");

  std::vector<CaloCluster> * pLArClusterEM37=0;
  tree->SetBranchAddress("LArClusterEM37",&pLArClusterEM37);
  TBranch * clusEM37Branch = tree->GetBranch("LArClusterEM37");

  std::vector<CaloCluster> * pLArClusterEMSofte=0;
  tree->SetBranchAddress("LArClusterEMSofte",&pLArClusterEMSofte);
  TBranch * clusEMSofteBranch = tree->GetBranch("LArClusterEMSofte");

  std::vector<CaloCluster> * pCombinedCluster=0;
  tree->SetBranchAddress("CombinedCluster",&pCombinedCluster);
  TBranch * combinedClusterBranch = tree->GetBranch("CombinedCluster");

  /** TauJet */
  std::vector<TauJet> * pTauJet=0;
  tree->SetBranchAddress("TauJetCollection",&pTauJet);
  TBranch * tauBranch = tree->GetBranch("TauJetCollection");

  Long64_t nentries = tree->GetEntriesFast();
  int nbytes = 0; 
  int nb = 0;
  
  for (Long64_t jentry=0; jentry<nentries;jentry++) {

    std::cout << "Event Number = " << (jentry+1) << std::endl;
    std::cout << " " << std::endl;

    /** Read the Tracks */
    nb = trackBranch->GetEntry(jentry);  nbytes += nb;

    /** Read the EM clusters */
    nb = clusEMBranch->GetEntry(jentry);       nbytes += nb;
    nb = clusEM37Branch->GetEntry(jentry);     nbytes += nb;
    nb = clusEMSofteBranch->GetEntry(jentry);  nbytes += nb;
    nb = combinedClusterBranch->GetEntry(jentry);  nbytes += nb;

    /** Read the TauJet */
    nb = tauBranch->GetEntry(jentry);   nbytes += nb;    

    /** Loop over TauJets and do something */
    std::vector<TauJet>::const_iterator tauItr  = pTauJet->begin();
    std::vector<TauJet>::const_iterator tauItrE = pTauJet->end();
    for (; tauItr != tauItrE; ++tauItr) {

      std::cout << "TauJet pt()  = " <<  (*tauItr).pt() << std::endl;
      std::cout << "TauJet eta() = " <<  (*tauItr).eta() << std::endl;
      std::cout << "TauJet phi() = " <<  (*tauItr).phi() << std::endl;

      /** The TauJet Tracks */
      int numberOfTracks = (*tauItr).numTrack();
      std::cout << "Number of Tracks associated to this TauJet = " << numberOfTracks << std::endl;
      for (int i=0; i<numberOfTracks; ++i) {
        const TrackParticle * track = (*tauItr).track(i);
        if (track) {
           std::cout << "the charge of this track is = " << track->charge() << std::endl;
        } 
      }

      /** The TauJet Cluster */
      const CaloCluster * cluster = (*tauItr).cluster();
      if (cluster) {
        std::cout << "TauJet cluster energy = " << cluster->e() << std::endl;
      }

      /** Access to more TauJet data */
      std::cout << "TauJet etHadCalib = " <<  (*tauItr).parameter(tauJetParameters::etHadCalib) << std::endl;
      std::cout << "TauJet etEMCalib = " <<  (*tauItr).parameter(tauJetParameters::etEMCalib) << std::endl;
      std::cout << "TauJet emRadius = " <<  (*tauItr).parameter(tauJetParameters::emRadius) << std::endl;
      std::cout << "TauJet isolationFraction = " <<  (*tauItr).parameter(tauJetParameters::isolationFraction) << std::endl;
      std::cout << "TauJet centralityFraction = " <<  (*tauItr).parameter(tauJetParameters::centralityFraction) << std::endl;
      std::cout << "TauJet stripWidth2 = " << (*tauItr).parameter(tauJetParameters::stripWidth2) << std::endl;
      std::cout << "TauJet nStripCells = " <<  (*tauItr).parameter(tauJetParameters::nStripCells) << std::endl;
      std::cout << "TauJet logLikelihoodRatio = " << (*tauItr).parameter(tauJetParameters::logLikelihoodRatio) << std::endl;
      std::cout << "TauJet author = " <<  (*tauItr).author() << std::endl;
      
      std::cout << " " << std::endl;
    }
    std::cout << "------------------------------------- " << std::endl;
  }
  
  f->Close();
  
  return;
  
}
