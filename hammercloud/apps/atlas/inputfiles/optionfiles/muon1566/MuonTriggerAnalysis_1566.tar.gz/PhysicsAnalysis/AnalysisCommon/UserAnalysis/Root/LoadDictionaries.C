{

/** If you use ROOT inside ATHENA (after setting up ATHENA)
    load the library for the dictionary */
gSystem.Load("libUserAnalysisEventDict.so");

/** If you use ROOT outside ATHENA on save Linux and gcc compiler
    you will need to load this too */
gSystem.Load("libUserAnalysisEvent.so");

}

