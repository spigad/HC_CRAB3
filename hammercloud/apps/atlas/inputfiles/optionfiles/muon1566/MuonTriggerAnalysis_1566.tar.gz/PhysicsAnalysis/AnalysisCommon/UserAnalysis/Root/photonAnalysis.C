#include <sstream>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <vector>

#include "TSystem.h"
#include "TTree.h"
#include "TBranch.h"
#include "TString.h"
#include "TCanvas.h"
#include "TKey.h"
#include "TFile.h"
#include "TClassTable.h"
#include "TStopwatch.h"

#include "UserAnalysisEvent/TrackParticle.h"
#include "UserAnalysisEvent/CaloCluster.h"
#include "UserAnalysisEvent/Photon.h"

using namespace User;

void photonAnalysis () {

  TFile *  f = new TFile("SAN.root");
  TTree *  tree = (TTree*)gDirectory->Get("CollectionTree");

  /** TrackParticle */
  std::vector<User::TrackParticle> * pTrack=0;
  tree->SetBranchAddress("TrackParticleCandidate",&pTrack);
  TBranch * trackBranch = tree->GetBranch("TrackParticleCandidate");

  /** EM CaloClusters */
  std::vector<User::CaloCluster> * pLArClusterEMgam35=0;
  tree->SetBranchAddress("LArClusterEMgam35",&pLArClusterEMgam35);
  TBranch * clusEMgam35Branch = tree->GetBranch("LArClusterEMgam35");

  std::vector<User::CaloCluster> * pLArClusterEMgam=0;
  tree->SetBranchAddress("LArClusterEMgam",&pLArClusterEMgam);
  TBranch * clusEMgamBranch = tree->GetBranch("LArClusterEMgam");

  /** Photon */
  std::vector<User::Photon> * pPhoton=0;
  tree->SetBranchAddress("PhotonCollection",&pPhoton);
  TBranch * photBranch = tree->GetBranch("PhotonCollection");

  Long64_t nentries = tree->GetEntriesFast();
  int nbytes = 0; 
  int nb = 0;
  
  for (Long64_t jentry=0; jentry<nentries;jentry++) {

    std::cout << "Event Number = " << (jentry+1) << std::endl;
    std::cout << " " << std::endl;

    /** Read the Tracks */
    nb = trackBranch->GetEntry(jentry);  nbytes += nb;

    /** Read the EM clusters */
    nb = clusEMgam35Branch->GetEntry(jentry);   nbytes += nb;
    nb = clusEMgamBranch->GetEntry(jentry);     nbytes += nb;

    /** Read the Electron */
    nb = photBranch->GetEntry(jentry);   nbytes += nb;    

    /** Loop over Photons and do something */
    std::vector<User::Photon>::const_iterator photItr  = pPhoton->begin();
    std::vector<User::Photon>::const_iterator photItrE = pPhoton->end();
    for (; photItr != photItrE; ++photItr) {

      /** The converted Photon Tracks */
      for (unsigned int i=0; i<2; ++i) {
        const User::TrackParticle * track = (*photItr).track(i);
        if (track) {
          std::cout << "Converted Track charge is = " << track->charge() << std::endl;
        } 
      }

      /** The Photon Cluster */
      const User::CaloCluster * cluster = (*photItr).cluster();
      if (cluster) {
        std::cout << "Photon cluster energy = " << cluster->e() << std::endl;
      }

      std::cout << " " << std::endl;
    }
    std::cout << "------------------------------------- " << std::endl;
  }
  
  f->Close();
  
  return;
  
}
