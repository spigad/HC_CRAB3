#include <sstream>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <vector>

#include "TSystem.h"
#include "TTree.h"
#include "TBranch.h"
#include "TString.h"
#include "TCanvas.h"
#include "TKey.h"
#include "TFile.h"
#include "TClassTable.h"
#include "TStopwatch.h"

#include "UserAnalysisEvent/Electron.h"
#include "UserAnalysisEvent/Muon.h"

using namespace User;

/** initialize the Trigger Decision TBranches */
void initialize( TTree * tree, bool* decisions, std::vector<TBranch*>& branches, 
		 std::vector<std::string>& names);

/** example to access Trigger decisions from the SAN */
void triggerDecision () {

  /** Trigger list */
  enum Trigger {
    DecisionL1=0, DecisionL2=1, DecisionEF=2, EM01=3,
    L1_2EM15=4, L1_2EM15I=5, L1_EM25=6, L1_EM25I=7, L1_EM60=8, L1_XE20=9, L1_XE30=10, L1_XE40=11,
    L1_XE50=12, L1_XE100=13, L1_XE200=14, L1_TAU05=15, L1_TAU10=16, L1_TAU10I=17, L1_TAU15=18, L1_TAU15I=19,
    L1_TAU20I=20, L1_TAU25I=21, L1_TAU35I=22, L1_MU06=23, L1_2MU06=24, L1_MU08=25, L1_MU10=26, L1_MU11=27, L1_MU20=28,
    L1_MU40=29, L1_J35=30, L1_J45=31, L1_2J45=32, L1_3J45=33, L1_4J45=34, L1_FJ30=35, L1_J60=36, L1_J80=37,
    L1_J170=38, L1_J300=39, L1_BJT15=40, L1_EM5=41,
    L2_met10f=452, L2_g10=43, L2_g20iL2_g20i=44, L2_g60=45, L2_jet20a=46, L2_jet20bL2_jet20b=47,
    L2_jet20cL2_jet20cL2_jet20c=48, L2_jet20dL2_jet20dL2_jet20dL2_jet20d=49, L2_jet20kt=50, L2_jet160=51,
    L2_jet120L2_jet120=52, L2_jet65L2_jet65L2_jet65=53,L2_jet50L2_jet50L2_jet50L2_jet50=54, L2_frjet10=55,
    L2_fljet10=56, L2_b35=57, L2_e10TRTxK=58, L2_e15iL2_e15i=59, L2_e25i=60, L2_e60=61, L2_e10=62, L2_e10L2_e10=63,
    L2_mu6l=64, L2_mu6=65, L2_mu20i=66, L2_Ze10e10=67, L2_tau10=68, L2_tau10i=69, L2_tau15=70, L2_tau15i=70,
    L2_tau20i=71, L2_tau25i=72, L2_tau35i=73, L2_tauNoCut=74,
    EF_met10=75, EF_jet20aEt=76, EF_jet20bEtEF_jet20bEt=77, EF_jet20cEtEF_jet20cEtEF_jet20cEt=78,
    EF_jet20dEtEF_jet20dEtEF_jet20dEtEF_jet20dEt=79, EF_jet20kt=80, EF_jet160=81, EF_jet120EF_jet120=82,
    EF_jet65EF_jet65EF_jet65=83, EF_jet50EF_jet50EF_jet50EF_jet50=84, EF_frjet10=85, EF_fljet10=86,
    EF_MuonTRTExt_mu6l=87, EF_b35=88, EF_tau10=89, EF_tau10i=90, EF_tau15=91, EF_tau15i=92, EF_tau20i=93,
    EF_tau25i=94, EF_tau35i=95, EF_tauNoCut=96, EF_mu6l=97, EF_mu6=98, EF_mu20i=99, EF_g10=100, 
    EF_g20iEF_g20i=101, EF_g60=102, EF_e10=103, EF_e10TRTxK=104, EF_e15iEF_e15i=105, EF_e25i=106, EF_e60=107,
    Size=108 };

  TFile *  f = new TFile("SAN.root");
  TTree *  tree = (TTree*)gDirectory->Get("CollectionTree");

  /** map of interesting Trigger decision TBranches and values 
      You should fill these in the initialize() - 
      the default may not be the trigger that you want */
  bool* decisions = new bool[Size];
  std::vector<TBranch*> branches(Size);
  std::vector<std::string> triggerNames;

  /** in the initialze method, simply select the Trigger decision 
      that you want to read do not read the rest if not needed - 
      it will run faster */
  initialize( tree, decisions, branches, triggerNames );

  /** Offline Electron */
  std::vector<Electron> * pElectron=0;
  tree->SetBranchAddress("ElectronCollection",&pElectron);
  TBranch * elecBranch = tree->GetBranch("ElectronCollection");

  /** Offline Muon */
  std::vector<Muon> * pMuon=0;
  tree->SetBranchAddress("StacoMuonCollection",&pMuon);
  TBranch * muonBranch = tree->GetBranch("StacoMuonCollection");

  Long64_t nentries = tree->GetEntriesFast();
  int nbytes = 0; 
  int nb = 0;
  
  for (Long64_t jentry=0; jentry<nentries;jentry++) {

    std::cout << "Event Number = " << (jentry+1) << std::endl;
    std::cout << " " << std::endl;

    /** Read the Trigger Decisions */
    for (unsigned int i=0; i<Size; ++i) {
      nb = branches[i]->GetEntry(jentry);  nbytes += nb;
    }

    /** Read Offline Collection of Electrons */
    nb = elecBranch->GetEntry(jentry);   nbytes += nb;    

    /** Read the Offline collection of Muons */
    nb = muonBranch->GetEntry(jentry);   nbytes += nb;    

    /** Print the Trigger Decisions */
    for (unsigned int i=0; i<Size; ++i) { 
      std::cout << triggerNames[i] << "      " << decisions[i] << std::endl;
    }

    /** Now check for specific Triggers and if passed look at offline objects */
    if ( decisions[EF_mu20i] || decisions[EF_e25i] ) {

      /** Loop over the offline Electrons */
      std::vector<Electron>::const_iterator elecItr = pElectron->begin();
      std::vector<Electron>::const_iterator elecItrE = pElectron->end();
      for (; elecItr != elecItrE; ++elecItr) {
	bool select = (*elecItr).author()== electronParameters::AuthorEgamma && (*elecItr).pt() > 20000;
	if ( select ) {
	  std::cout << " " << std::endl;
	  std::cout << "Electron pt()  = " <<  (*elecItr).pt() << std::endl;
	  std::cout << "Electron eta() = " <<  (*elecItr).eta() << std::endl;
	  std::cout << "Electron phi() = " <<  (*elecItr).phi() << std::endl;
	  std::cout << "Electron isolation ET - cone 0.4 " << (*elecItr).parameter(electronParameters::etcone40) 
		    << std::endl;
	}
      }

      /** Loop over offline over Muons */
      std::vector<Muon>::const_iterator muonItr = pMuon->begin();
      std::vector<Muon>::const_iterator muonItrE = pMuon->end();
      for (; muonItr != muonItrE; ++muonItr) {

	/** muon selection : pt > 6 GeV && ( combined or extrapolated to vertex ) */
	bool select = (*muonItr).pt() > 6000 && ( (*muonItr).isStandAloneMuon() ||
						  (*muonItr).isCombinedMuon() ); 
	/** count the selected muon */
	if ( select ) {
	  std::cout << " " << std::endl;
	  std::cout << "muon pt()  = " << (*muonItr).pt() << std::endl;
	  std::cout << "muon eta() = " <<  (*muonItr).eta() << std::endl;
	  std::cout << "muon phi() = " <<  (*muonItr).phi() << std::endl;
	  std::cout << "muon fit chi2 = " << (*muonItr).fitChi2OverDoF() << std::endl;
	  std::cout << "muon match chi2 = " << (*muonItr).matchChi2OverDoF() << std::endl;
	  std::cout << "muon is best match?  = " << (*muonItr).bestMatch() << std::endl;
	  std::cout << "muon isolation ET - cone 0.4 = " << (*muonItr).parameter(muonParameters::etcone40) 
		    << std::endl;
	}
      }
    }    
    
    std::cout << " " << std::endl;
      
  }
  std::cout << "------------------------------------- " << std::endl;
  
  delete decisions;
  
  f->Close();
  
  return;
  
}

void initialize( TTree * tree, bool* decisions, std::vector<TBranch*>& branches,
		 std::vector<std::string>& triggerNames) {

  triggerNames.push_back("DecisionL1");
  triggerNames.push_back("DecisionL2");
  triggerNames.push_back("DecisionEF");
  triggerNames.push_back("EM01");
  triggerNames.push_back("L1_2EM15");
  triggerNames.push_back("L1_2EM15I");
  triggerNames.push_back("L1_EM25");
  triggerNames.push_back("L1_EM25I");
  triggerNames.push_back("L1_EM60");
  triggerNames.push_back("L1_XE20");
  triggerNames.push_back("L1_XE30");
  triggerNames.push_back("L1_XE40");
  triggerNames.push_back("L1_XE50");
  triggerNames.push_back("L1_XE100");
  triggerNames.push_back("L1_XE200");
  triggerNames.push_back("L1_TAU05");
  triggerNames.push_back("L1_TAU10");
  triggerNames.push_back("L1_TAU10I");
  triggerNames.push_back("L1_TAU15");
  triggerNames.push_back("L1_TAU15I");
  triggerNames.push_back("L1_TAU20I");
  triggerNames.push_back("L1_TAU25I");
  triggerNames.push_back("L1_TAU35I");
  triggerNames.push_back("L1_MU06");
  triggerNames.push_back("L1_2MU06");
  triggerNames.push_back("L1_MU08");
  triggerNames.push_back("L1_MU10");
  triggerNames.push_back("L1_MU11");
  triggerNames.push_back("L1_MU20");
  triggerNames.push_back("L1_MU40");
  triggerNames.push_back("L1_J35");
  triggerNames.push_back("L1_J45");
  triggerNames.push_back("L1_2J45");
  triggerNames.push_back("L1_3J45");
  triggerNames.push_back("L1_4J45");
  triggerNames.push_back("L1_FJ30");
  triggerNames.push_back("L1_J60");
  triggerNames.push_back("L1_J80");
  triggerNames.push_back("L1_J170");
  triggerNames.push_back("L1_J300");
  triggerNames.push_back("L1_BJT15");
  triggerNames.push_back("L1_EM5");
  triggerNames.push_back("L2_met10f");
  triggerNames.push_back("L2_g10");
  triggerNames.push_back("L2_g20iL2_g20i");
  triggerNames.push_back("L2_g60");
  triggerNames.push_back("L2_jet20a");
  triggerNames.push_back("L2_jet20bL2_jet20b");
  triggerNames.push_back("L2_jet20cL2_jet20cL2_jet20c");
  triggerNames.push_back("L2_jet20dL2_jet20dL2_jet20dL2_jet20d");
  triggerNames.push_back("L2_jet20kt");
  triggerNames.push_back("L2_jet160");
  triggerNames.push_back("L2_jet120L2_jet120");
  triggerNames.push_back("L2_jet65L2_jet65L2_jet65");
  triggerNames.push_back("L2_jet50L2_jet50L2_jet50L2_jet50");
  triggerNames.push_back("L2_frjet10");
  triggerNames.push_back("L2_fljet10");
  triggerNames.push_back("L2_b35");
  triggerNames.push_back("L2_e10TRTxK");
  triggerNames.push_back("L2_e15iL2_e15i");
  triggerNames.push_back("L2_e25i");
  triggerNames.push_back("L2_e60");
  triggerNames.push_back("L2_e10");
  triggerNames.push_back("L2_e10L2_e10");
  triggerNames.push_back("L2_mu6l");
  triggerNames.push_back("L2_mu6");
  triggerNames.push_back("L2_mu20i");
  triggerNames.push_back("L2_Ze10e10");
  triggerNames.push_back("L2_tau10");
  triggerNames.push_back("L2_tau10i");
  triggerNames.push_back("L2_tau15");
  triggerNames.push_back("L2_tau15i");
  triggerNames.push_back("L2_tau20i");
  triggerNames.push_back("L2_tau25i");
  triggerNames.push_back("L2_tau35i");
  triggerNames.push_back("L2_tauNoCut");
  triggerNames.push_back("EF_met10");
  triggerNames.push_back("EF_jet20aEt");
  triggerNames.push_back("EF_jet20bEtEF_jet20bEt");
  triggerNames.push_back("EF_jet20cEtEF_jet20cEtEF_jet20cEt");
  triggerNames.push_back("EF_jet20dEtEF_jet20dEtEF_jet20dEtEF_jet20dEt");
  triggerNames.push_back("EF_jet20kt");
  triggerNames.push_back("EF_jet160");
  triggerNames.push_back("EF_jet120EF_jet120");
  triggerNames.push_back("EF_jet65EF_jet65EF_jet65");
  triggerNames.push_back("EF_jet50EF_jet50EF_jet50EF_jet50");
  triggerNames.push_back("EF_frjet10");
  triggerNames.push_back("EF_fljet10");
  triggerNames.push_back("EF_MuonTRTExt_mu6l");
  triggerNames.push_back("EF_b35");
  triggerNames.push_back("EF_tau10");
  triggerNames.push_back("EF_tau10i");
  triggerNames.push_back("EF_tau15");
  triggerNames.push_back("EF_tau15i");
  triggerNames.push_back("EF_tau20i");
  triggerNames.push_back("EF_tau25i");
  triggerNames.push_back("EF_tau35i");
  triggerNames.push_back("EF_tauNoCut");
  triggerNames.push_back("EF_mu6l");
  triggerNames.push_back("EF_mu6");
  triggerNames.push_back("EF_mu20i");
  triggerNames.push_back("EF_g10");
  triggerNames.push_back("EF_g20iEF_g20i");
  triggerNames.push_back("EF_g60");
  triggerNames.push_back("EF_e10");
  triggerNames.push_back("EF_e10TRTxK");
  triggerNames.push_back("EF_e15iEF_e15i");
  triggerNames.push_back("EF_e25i");
  triggerNames.push_back("EF_e60");

  for (unsigned int i=0; i<triggerNames.size(); ++i) {
    std::string name = "Trig_"+triggerNames[i];
    tree->SetBranchAddress( name.c_str(),&decisions[i] );
    branches[i] = tree->GetBranch( name.c_str() );
  }

}

