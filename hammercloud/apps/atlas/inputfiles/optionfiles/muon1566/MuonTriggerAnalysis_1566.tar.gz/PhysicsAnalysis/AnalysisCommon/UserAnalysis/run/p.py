#Ganga# File created by Ganga - Mon Sep  7 16:25:34 2009
#Ganga#
#Ganga# Object properties may be freely edited before reloading into Ganga
#Ganga#
#Ganga# Lines beginning #Ganga# are used to divide object definitions,
#Ganga# and must not be deleted

#Ganga# Job object (category: jobs)
Job (
 name = '' ,
 outputsandbox = [] ,
 info = JobInfo (
    ) ,
 inputdata = None ,
 merger = None ,
 inputsandbox = [ File (
    name = '/afs/cern.ch/user/e/elmsheus/split/HelloWorldOptions.py' ,
    subdir = '.' 
    ) , ] ,
 application = Executable (
    exe = '/afs/cern.ch/user/e/elmsheus/split/panda.sh' ,
    env = {} ,
    args = ['15.3.1', 'HelloWorldOptions.py'] 
    ) ,
 outputdata = DQ2OutputDataset (
    datasetname = 'user09.JohannesElmsheuser.ganga.129.20090907.3' ,
    isGroupDS = False ,
    use_shortfilename = False ,
    groupname = '' ,
    outputdata = [] ,
    local_location = '' ,
    location = '' 
    ) ,
 splitter = ArgSplitter (
    args = [[''], [''], [''], [''], ['']] 
    ) ,
 backend = Panda (
    extOutFile = [] ,
    site = 'ANALY_DESY-HH' ,
    libds = None ,
    requirements = PandaRequirements (
       notSkipMissing = False ,
       cputime = -1 ,
       corCheck = False ,
       long = False ,
       memory = -1 ,
       excluded_sites = [] ,
       cloud = 'US' 
       ) 
    ) 
 ) 

