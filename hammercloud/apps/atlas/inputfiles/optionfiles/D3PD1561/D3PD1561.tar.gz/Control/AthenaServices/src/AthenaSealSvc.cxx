
/********************************************************************

NAME:     AthenaSealSvc.cxx
PACKAGE:  AthenaSealSvc

AUTHORS:  Christian Arnault
CREATED:  May. 13, 2003

PURPOSE:  Provides an access to the SEAL dictionary
********************************************************************/

#include "AthenaSealSvc.h"
#include "Reflex/Base.h"
#include "Reflex/Member.h"
#include "Reflex/Scope.h"
#include "Reflex/Type.h"

#include "GaudiKernel/MsgStream.h"
#include "GaudiKernel/ISvcLocator.h"
#include "GaudiKernel/IChronoStatSvc.h"
#include "GaudiKernel/Bootstrap.h"
#include "GaudiKernel/MsgStream.h"
#include "GaudiKernel/SvcFactory.h"
#include "GaudiKernel/IAlgManager.h"
#include "GaudiKernel/IAlgorithm.h"
#include "GaudiKernel/SmartIF.h"
#include "GaudiKernel/PropertyMgr.h"
#include "GaudiKernel/System.h"

#include <errno.h>
#include <set>
#include <algorithm>

/////////////////////////////////////////////////////////////////////////////
//
//  Job control cards:
//
//  "Dictionaries"    - list of the dictionaries to load
//  
/////////////////////////////////////////////////////////////////////////////



#if ROOT_VERSION_CODE < ROOT_VERSION(5,19,0)
using namespace ROOT;
#endif

//----------------------------------------------------------------------------  
AthenaSealSvc::AthenaSealSvc(const std::string& name, ISvcLocator* pSvcLocator) 
    :
    AthService(name, pSvcLocator),
    m_checkDictAtInit(false),
    m_checkDictionary(true),
    m_loadAllDicts(false),
    m_chronoStatSvc( "ChronoStatSvc", name ),
    m_dictLoaderSvc( "AthDictLoaderSvc", name ),
    m_doChronoStat (true)
{ 
    declareProperty ("DictNames",       m_dictionaryNames);
    declareProperty ("IgnoreNames",     m_ignoreNames);
    declareProperty ("CheckDictionary", m_checkDictionary);
    declareProperty ("CheckDictAtInit", m_checkDictAtInit);
    declareProperty ("LoadAllDicts",    m_loadAllDicts);
    declareProperty ("IgnoreDicts",     m_ignoreDicts);
    declareProperty ("UseChronoStag",   m_doChronoStat);

    // configure sensible defaults
    setDefaultDictNames();
    setDefaultIgnoreNames();
    setDefaultIgnoreDicts();
}

//----------------------------------------------------------------------------  
AthenaSealSvc::~AthenaSealSvc()
{}

//----------------------------------------------------------------------------  
StatusCode AthenaSealSvc::queryInterface ( const InterfaceID& riid, void** ppvInterface )
{
    if ( IAthenaSealSvc::interfaceID() == riid )    
	{
	    *ppvInterface = (IAthenaSealSvc*)this;
	} 
    else
	{
	    // Interface is not directly available: try out a base class
	    return AthService::queryInterface(riid, ppvInterface);
	}
    addRef();
    return StatusCode::SUCCESS;
}

//----------------------------------------------------------------------------  
StatusCode AthenaSealSvc::initialize()
{
/////////////////////////////////////////////////////////////////////////////
//
//  AthenaSealSvc::initialize()
//  Initiliaze the streams defined by the job control cards as follows:
//
//  No  data-card name                   Action
//  --  ---------------     --------------------------------------------
//   1. "Dictionaries"      - load the specified dictionaries
//  --  ---------------     ----------------------------------------------------
//
/////////////////////////////////////////////////////////////////////////////

    // get ChronoStatSvc
    StatusCode status = m_chronoStatSvc.retrieve();
    if (!status.isSuccess()) {
      ATH_MSG_ERROR ("Can not get ChronoStatSvc.");
      return(status);
    }
    
    if (!m_dictLoaderSvc.retrieve().isSuccess()) {
      ATH_MSG_ERROR ("could not retrieve athena dict. loader service !");
      return StatusCode::FAILURE;
    }

    ATH_MSG_INFO
      ("begin initialize() - loading dictionary fillers: size " 
       << m_dictionaryNames.value().size());

    if (m_dictionaryNames.value().size()) {
	
	if (m_doChronoStat) {
	    m_chronoStatSvc->chronoStart("AthenaSealSvc::dictLoading");
	}

	for (unsigned int i = 0; i < m_dictionaryNames.value().size(); i++) {
	    std::string name = m_dictionaryNames.value()[i];

	    // Try to load: we ignore the return code for the moment
	    status = loadDictFiller(name); 
	    if (status.isFailure()) {
		return status;
	    }
	}

	if (m_doChronoStat) {
	    m_chronoStatSvc->chronoStop("AthenaSealSvc::dictLoading");
	}
    }
    

    // Print out names to ignore
    for (unsigned int i = 0; i < m_ignoreNames.value().size(); i++) {
	std::string name = m_ignoreNames.value()[i];
	ATH_MSG_DEBUG ("Ignore name: " << name);
    }
    

    // Load all classes available
    if(m_loadAllDicts) {
	status = loadClasses();
	if (status.isFailure()) {
	  ATH_MSG_ERROR ("Unable to load classes");
	    return status;
	}
    }
    
    // Check the dictionary completeness
    if(m_checkDictAtInit) {
	try {
	    checkDictionary();
	}
	
	catch (std::exception& e) {
	  ATH_MSG_FATAL ("*** Reflex exception caught: " << e.what());
	  return StatusCode::FAILURE;
	}
    }
    
    ATH_MSG_DEBUG ("end initialize()");

    return status;
}


//----------------------------------------------------------------------------  
StatusCode
AthenaSealSvc::loadClasses() const
{
    ATH_MSG_DEBUG ("loadClasses: Looking for class capabilities");

    // Iterate over the reflex types

    ReflexType_Iterator itr  = ReflexType::Type_Begin();
    ReflexType_Iterator last = ReflexType::Type_End();

    // Printout the list of classes/ one per module
    ATH_MSG_INFO
      ("Loading ALL dict libs - number is: " << ReflexType::TypeSize());
    for (; itr != last; ++itr) {
      if (!itr->IsClass() || !itr->IsStruct()) {
	continue;
      }
#if ROOT_VERSION_CODE < ROOT_VERSION(5,19,0)
      const std::string n = itr->Name(ROOT::Reflex::SCOPED);
#else
      const std::string n = itr->Name(Reflex::SCOPED);
#endif
      if ( !m_dictLoaderSvc->load_type (n)) {
	ATH_MSG_DEBUG ("could not load reflex-dict for [" << n << "] !");
      }
      ATH_MSG_DEBUG ("Called IDictLoaderSvc to load dictionary for: " << n);
    }

    return (StatusCode::SUCCESS);
}


//----------------------------------------------------------------------------  
void 
AthenaSealSvc::show_member (const Reflex::Member& m) const
{
    const Reflex::Type t1 = m.DeclaringType ();
    const Reflex::Type t2 = m.TypeOf ();
    unsigned int width = 20;

    if (t1) {
        msg(MSG::DEBUG) << "    " << m.Name(); 
	unsigned int s = m.Name().size();
	if (s < width) {
	    std::string tab(width - s,' ');
	    msg(MSG::DEBUG) << tab;
	}  
    }
    else msg(MSG::DEBUG) << "  warning - declaring type unknown for " << m.Name(); 
  
    msg(MSG::DEBUG) << " -- offset: ";
    if (m.Offset() < 100) {
        msg(MSG::DEBUG) << ' '; 
	if (m.Offset() < 10) msg(MSG::DEBUG) << ' ';
    }
  
    msg(MSG::DEBUG) << m.Offset(); 
  
    if (t2) {
        msg(MSG::DEBUG) << " -- type: " << t2.Name();
	if (m.IsTransient()) {
	  msg(MSG::DEBUG) << "  [declared transient]";
	}
    }
    else {
	if (m.IsTransient()) {
	  msg(MSG::DEBUG) << " -- type: " << "[unknown - declared transient]";
	}
	else {
	  msg(MSG::DEBUG) << " -- type: " << "[unknown]";
	}
    }
    msg(MSG::DEBUG) << endreq;
}

//----------------------------------------------------------------------------  
void 
AthenaSealSvc::show_type (const Reflex::Type& t) const
{
    // show info of members
    msg(MSG::DEBUG) << "Members of class " << t.Name() << ":" << endreq;
    for (size_t i = 0; i < t.DataMemberSize(); ++i) {
	Reflex::Member m = t.DataMemberAt(i);
	if (m) {
	  show_member (m);
	}
    }

}

//----------------------------------------------------------------------------  
bool 
AthenaSealSvc::member_is_ok(const std::string& typeName, 
			    const std::string& memberName) const
{
    if (typeName == "basic_string<char>" && 
	memberName == "_M_dataplus") {
	return (true);
    }
    if (typeName.find("map<") != std::string::npos && 
	memberName == "_M_t") {
	return (true);
    }
    if (typeName.find("hash_") != std::string::npos && 
	memberName == "_M_ht") {
	return (true);
    }
    if (typeName.find("set<") != std::string::npos && 
	memberName == "_M_t") {
	return (true);
    }
    if (typeName.find("std::_Vector_alloc_base<DataLinkVector") != std::string::npos && 
	memberName.find("_M_") != std::string::npos) {
	return (true);
    }
    if (typeName == "DetailedTrackTruthCollection" && 
	memberName == "m_trackCollection") {
	return (true);
    }
    return (false);
}

//----------------------------------------------------------------------------  
static bool 
isnum(const std::string& str) 
{
    for (unsigned int i = 0; i < str.size(); i++) {
        if ((str[i] < '0') || (str[i] > '9'))
            return false;
    }
    return true; 
}

//----------------------------------------------------------------------------  
void
AthenaSealSvc::find_extra_types (const Reflex::Type& t,
				 std::vector<Reflex::Type>& newTypes) const
{
    // Add the type of each field 

    // check that types of the fields are defined
    msg(MSG::DEBUG) << "Looking for members of type " << t.Name() << ":" 
		    << "  newTypes size " << newTypes.size() << endreq;
    for (size_t i = 0; i < t.DataMemberSize(); ++i) {
	Reflex::Member m = t.DataMemberAt(i);
	if (m) {
	    Reflex::Type t2 = m.TypeOf ();
	    // If type is pointer, get the underlying type
	    if (t2.IsPointer()) t2 = t2.ToType();
	    
	    // Skip transient fields - this and downstream classes may
	    // not yet be defined
	    if (m.IsTransient()) {
	        msg(MSG::DEBUG) 
		  << " Skipping check for transient member " << m.Name()
		  << " of type " << t2.Name()
		  << endreq;
		continue;
	    }
	    if (t2) {
		newTypes.push_back(t2);
		msg(MSG::DEBUG) << " found class " << t2.Name() << endreq;
	    }
	}
    }

    // Add in types for each superclass
    if (t.IsClass()) {
	if(t.BaseSize()) {
	  msg(MSG::DEBUG) << "    Loop over superclass names " << endreq;
	}
	for (size_t i = 0; i < t.BaseSize(); ++i) {
	    Reflex::Base b = t.BaseAt(i);
	    if (b) {
		std::string bname = b.Name();
		// Remove stl container base classes
		if (bname.find("_base<") == std::string::npos) {
		    msg(MSG::DEBUG) << "      found name: " << bname;
		    Reflex::Type tb = b.ToType();
		    if (tb) {
		      msg(MSG::DEBUG) << ". Type IS defined in dictionary. ";
		      newTypes.push_back(tb);
		    }
		    msg(MSG::DEBUG) << endreq;
		}
	    }
	}
    }

    // Add in types for templates
    if (t.IsTemplateInstance()) {
      msg(MSG::DEBUG) << " Loop over template args of " << t.Name()<< " " 
		      << endreq;
	for (size_t i = 0; i < t.TemplateArgumentSize(); ++i) {
	    Reflex::Type ta = t.TemplateArgumentAt(i);
            
            // If type not found, try to dynamically load it
            std::string taname = ta.Name(7);
            if (!ta) {
                std::string name = ta.Name(7);
                // skip single digit strings
                if (name.size() == 1 && isdigit(name[0])) {
		  msg(MSG::DEBUG) << "Skip template arg: " << name << " is digit " << endreq;
                    continue;
                }
                if ('*' == name[name.size()-1]) name = name.substr(0, name.size()-1);
                if ("const " == name.substr(0, 6)) name = name.substr(6, name.size());
		int ntypesBefore = Reflex::Type::TypeSize();
                if (m_doChronoStat) {
                    m_chronoStatSvc->chronoStart("AthenaSealSvc::autoLoading");
                }
                ta = m_dictLoaderSvc->load_type (name);
                if (m_doChronoStat) {
                    m_chronoStatSvc->chronoStop("AthenaSealSvc::autoLoading");
                }
                msg(MSG::DEBUG) << "Trying to 'Autoload' dictionary for class " 
                    << name
		    << " ntypes before load " << ntypesBefore
		    << " ntypes loaded " << Reflex::Type::TypeSize() - ntypesBefore
                    << " top level class " <<     m_currentClassName << endreq;
            }
            
            
	    // If type is pointer, get the underlying type
	    if (ta.IsPointer()) ta = ta.ToType();
	    
	    if (ta) {
	        msg(MSG::DEBUG) << ta.Name() << " ";
		newTypes.push_back(ta);
		msg(MSG::DEBUG) << " name " << ta.Name()<< " " << endreq;
	    }
	    else {
	        msg(MSG::DEBUG) << " type not found " << taname
                                << " isnum: " << isnum(taname) << endreq;
		if (!(ignoreName(t) || ignoreName(ta) || isnum(taname) )) {
		  msg(MSG::WARNING) 
		    << "****> Missing type for template argument " << ta.Name()
		    << " of template " << t.Name() 
		    << endreq;
		  msg(MSG::WARNING) 
		    << "****> For the moment, we DO NOT return FAILURE - so expect abort if type is really missing!! "
		    << endreq;
		}
	    }
	    if (t.IsPointer()) {
	      msg(MSG::WARNING) << " type is pointer:  " << t.Name() << endreq;
	    }

		// Check for pointers and add in simple class
// 		msg(MSG::DEBUG) << "Checking for pointer class: " 
// 		    <<((*it2)) << endreq;
// 		    std::string nm = (*it2);
// 		    nm = nm.substr(0, nm.size() - 1);
// 		    msg(MSG::DEBUG) << " try class " << nm << " " << endreq;
	}
    }

    return;
}

//----------------------------------------------------------------------------  
bool 
AthenaSealSvc::incorrect_guid (const Reflex::Type& t) const
{
    bool result = false;

    // Check that guid is ok

    // If class has GUID, try to look it up in this way
    Reflex::PropertyList plist = t.Properties();
    if (plist.HasProperty("ClassID")) {
	const std::string clid = plist.PropertyAsString("ClassID");
	if (clid.size()) {
	    for (unsigned int i = 0; i < clid.size(); ++i) {
		if ('a' <= clid[i] && clid[i] <= 'z') {
		    msg(MSG::ERROR)
		      << "----->  Found lower case letter in class guid: pos, value - " 
		      << i << ", " << clid[i] << endreq
		      << "----->  For class, guid " 
		      << t.Name() << ", " << clid << endreq
		      << "----->  The guid MUST be all upper case. " 
		      << endreq;
		    result = true;
		}
	    }
	}
	else {
	  ATH_MSG_VERBOSE ("Class " << t.Name() << " has an empty CLID. ");
	}
    }
    else {
      ATH_MSG_VERBOSE ("Class " << t.Name() << " does NOT have CLID. ");
    }
    return result;
}


//----------------------------------------------------------------------------  
bool 
AthenaSealSvc::missing_member_types (const Reflex::Type& t) const
{
    bool result  = false;
    int nmembers = 0;

    // check that types of the fields are defined
    if (t.DataMemberSize()) {
      msg(MSG::INFO)
	<< "Checking members of type " << t.Name() << " for "
	<< t.DataMemberSize() << " members:";
    }
    
    bool first = true;
    for (size_t i = 0; i < t.DataMemberSize(); ++i) {
	Reflex::Member m = t.DataMemberAt(i);
	if (m) {
	    Reflex::Type t1 = m.DeclaringType ();
	    Reflex::Type t2 = m.TypeOf ();
	    bool transient = m.IsTransient();

	    //msg(MSG::DEBUG) << "Type of member: " << t1.Name(7) << " " << t2.Name(7) << endreq;
	    if (!t2 && !member_is_ok(t1.Name(), m.Name()) && !transient) {

                // Missing type, try to load it
                //  We ignore transient types and some special members 
		std::string name = t2.Name(7);
                if ('*' == name[name.size()-1]) name = name.substr(0, name.size()-1);
                if ("const " == name.substr(0, 6)) name = name.substr(6, name.size());
                msg() << endreq;
		int ntypesBefore = Reflex::Type::TypeSize();
                if (m_doChronoStat) {
                    m_chronoStatSvc->chronoStart("AthenaSealSvc::autoLoading");
                }
		t2 = m_dictLoaderSvc->load_type (name);
                if (m_doChronoStat) {
                    m_chronoStatSvc->chronoStop("AthenaSealSvc::autoLoading");
                }
                msg(MSG::DEBUG)
		  << "Trying to 'Autoload' dictionary for class " 
		  << name
		  << " ntypes before load " << ntypesBefore
		  << " ntypes loaded " 
		  << Reflex::Type::TypeSize() - ntypesBefore
		  << " top level class " <<     m_currentClassName 
		  << endreq;
            }
            
	    if (t2) {
		nmembers++;
	    }
	    else {  
		// 0 => possible error:
		// Know exceptions:
		if (member_is_ok(t1.Name(), m.Name()) || transient) {
		    if (first) {
			first = false;
			msg(MSG::VERBOSE) << endreq;
		    }
		    if (transient) {
		      msg(MSG::VERBOSE)
			<< "****> IGNORING missing type for transient member "
			<< "  " << m.Name() 
			<< endreq;
		    }
		    else {
		      msg(MSG::VERBOSE)
			<< "****> IGNORING missing type for " << t1.Name()
			<< "  " << m.Name() 
			<< endreq;
		    }
		}
		else {
		    if (first) {
			first = false;
			msg(MSG::INFO) << endreq;
		    }
		    msg(MSG::INFO) << "****> Missing type for " << t1.Name()
				   << "  " << m.Name() << endreq;
		    result = true;
		}
	    }
	}
    }
    if (!result) {
	if (t.DataMemberSize()) 
	  msg(MSG::INFO) << " ok  - isComplete " << t.IsComplete() << endreq;
    }

    // print out class info
    if(nmembers) show_type(t);
    return (result);
}



//----------------------------------------------------------------------------  
StatusCode AthenaSealSvc::checkClass(const std::string& typeName) const
{

     if(!m_checkDictionary) {
       ATH_MSG_DEBUG 
	 ("checkClass - AthenaSealSvc.CheckDictionary is set to false. "
	  "No checks done for class:  " << typeName);
	return (StatusCode::SUCCESS);
     }
    
   if (m_doChronoStat) {
      m_chronoStatSvc->chronoStart("AthenaSealSvc::checkClass");
   }

   ATH_MSG_INFO 
     ("checkClass - Number of types on entry " << Reflex::Type::TypeSize());

    Reflex::Type t =  Reflex::Type::ByName(typeName);

    // Set current class name
    m_currentClassName = typeName;
    if (!t) {
	int ntypesBefore = Reflex::Type::TypeSize();
        if (m_doChronoStat) {
            m_chronoStatSvc->chronoStart("AthenaSealSvc::autoLoading");
        }
        if (!m_dictLoaderSvc->load_type (typeName)) {
	  ATH_MSG_INFO ("problem loading type [" << typeName << "] !");
	}
        if (m_doChronoStat) {
            m_chronoStatSvc->chronoStop("AthenaSealSvc::autoLoading");
        }
        t =  Reflex::Type::ByName(typeName);
        ATH_MSG_DEBUG 
	  ("Loaded dictionary for class " << typeName 
	   << " ntypes before load " << ntypesBefore
	   << " ntypes loaded " << Reflex::Type::TypeSize() - ntypesBefore);
    }
    

    // typeName comes from typeinfo and may not be the same as the
    // name of the class in the reflection dictionary, e.g. for
    // maps. Skip checks if class not found.
    if (!t) {
      ATH_MSG_WARNING
	("checkClass - could NOT find reflection class for type "
	 << typeName << " => NO CHECKS DONE ");

	Reflex::Scope s =  Reflex::Scope::ByName(typeName);
	if (s) {
	  ATH_MSG_INFO ("checkClass - found scope " << s.Name());
	}
	else {
	  ATH_MSG_INFO ("checkClass - unable to find scope ");
	}

	return (StatusCode::SUCCESS);
    }
    
    ATH_MSG_INFO ("checkClass - found type " << t.Name());

    // We require class c to have a GUID - assume that it it a data
    // object. (Otherwise, add and argument to the method call)
    Reflex::PropertyList plist = t.Properties();
    const std::string clid = plist.PropertyAsString("ClassID");
    ATH_MSG_INFO ("checkClass - found ClassID " << clid);
    if (!clid.size()) {
      ATH_MSG_ERROR
	("----->  MISSING GUID (id in selection file) for class " << t.Name()
	 << endreq
	 << "----->  This is needed for ALL DataObjects ");
      return (StatusCode::FAILURE);
    }

    std::vector<Reflex::Type> toCheck;
    std::vector<Reflex::Type> toCheckAll;
    std::vector<Reflex::Type>::const_iterator it;

    std::map<std::string, Reflex::Type> checked;
    std::string cn = t.Name();
    checked[cn] = t;
    if(cn.find('*') == std::string::npos)m_checkedClasses.insert(cn);
    
    // Print names for debug
//      ATH_MSG_DEBUG ("Found classes");
//      std::vector <const reflect::Class*> myvec = reflect::Class::forNames ();
//      for (it = myvec.begin(); it != myvec.end (); ++it) {
//  	const reflect::Class* c = *it;
//  	if (c) ATH_MSG_DEBUG (c->fullName());
//      }
    

    bool continueCheck = true;

    do {

	if(missingTypes(t)) return (StatusCode::FAILURE);

	ATH_MSG_DEBUG ("checkClass - check for class " << t.Name() << " ok");

	// Collect the extra types for this class - fields, base
	// classes, template args, etc.
	find_extra_types (t, toCheck);
	
	// Select the new classes to be checked
	for (it = toCheck.begin(); it != toCheck.end(); ++it) {
	    if (checked.find((*it).Name()) == checked.end()) {
		toCheckAll.push_back((*it));
		cn = (*it).Name();
		checked[cn] = (*it);
		if(cn.find('*') == std::string::npos)m_checkedClasses.insert(cn);
//		ATH_MSG_DEBUG ("checkClass - added class " << (*it)->fullName());
	    }
	}
	toCheck.clear();

	if (toCheckAll.size() > 0) {
	    // Select the next one to check and save in set
	    t = toCheckAll[0];
	    //checked.insert(c);
	    //checked[c->fullName()] = c;
	}
	else {
	    continueCheck = false;
	}
	if (toCheckAll.size() > 1) {
	    // Remove the first element
	    toCheck = toCheckAll;
	    toCheckAll.clear();
	    it = toCheck.begin();
	    ++it;
	    for (; it != toCheck.end(); ++it )toCheckAll.push_back((*it));
	    // Clear vec for collecting new classes to check
	    toCheck.clear();
	}
	else {
	    toCheckAll.clear();
	}
	

    } while (continueCheck);

    ATH_MSG_INFO
      ("checkClass - NO MISSING FIELDS!!!" 
       << endreq
       << "checkClass - Number of types on exit " << Reflex::Type::TypeSize());

//     ATH_MSG_DEBUG ("Classes checked: ");

//     std::map<std::string, const reflect::Class*>::const_iterator it1   = checked.begin();
//     std::map<std::string, const reflect::Class*>::const_iterator last1 = checked.end();
//     for (; it1 != last1; ++it1) {
// 	ATH_MSG_DEBUG ((*it1).first);
//    }

    if (m_doChronoStat) {
        m_chronoStatSvc->chronoStop("AthenaSealSvc::checkClass");
    }

    return (StatusCode::SUCCESS);

}


//----------------------------------------------------------------------------  
StatusCode 
AthenaSealSvc::loadDictFiller(const std::string& dictName) const
{
    unsigned int typesBefore = Reflex::Type::TypeSize();
    
    System::ImageHandle h;
    long rc = System::loadDynamicLib (dictName, &h);

    ATH_MSG_INFO
      ("loadDictFiller - Ntypes before " << typesBefore 
       << " types added "  << (Reflex::Type::TypeSize() - typesBefore) 
       << " dictionary filler name:" << dictName);

    if (1 == rc) {
      ATH_MSG_DEBUG (" Loaded dict filler " << dictName);
    }
    else {
      ATH_MSG_ERROR 
	(" Unable to load " << dictName << "  rc=" << rc
	 << " h=" << h << " errno=" << errno);
      return (StatusCode::FAILURE);
    }
    return (StatusCode::SUCCESS);
}

//----------------------------------------------------------------------------  
void AthenaSealSvc::checkDictionary() const
{
    ATH_MSG_INFO
      ("Checking the completeness of the dictionary for all classes");
    bool isMissingTypes = false;

    ATH_MSG_DEBUG ("Number of types: " << Reflex::Type::TypeSize());

    for (size_t i = 0; i < Reflex::Type::TypeSize(); ++i) {
	Reflex::Type t = Reflex::Type::TypeAt(i);
	if(t && t.IsClass()) {
	    ATH_MSG_INFO ("Checking type " << t.Name() << " number: " << i);
//	    if (missingTypes(t)) isMissingTypes = true;

	    // Build up full type name
	    std::string name = t.Name();
	    bool finished = false;
	    Reflex::Scope s =  t.DeclaringScope();
	    do {
		if (s) {
// 		    ATH_MSG_INFO ("checkDictionary - found scope " << s.Name());
		    if (s.IsTopScope()) {
			finished = true;
		    }
		    else {
			name = s.Name() + "::" + name;
			s = s.DeclaringScope();
		    }
		}
		else {
		    finished = true;
		}
	    } while (!finished);
	    
	    Reflex::Type t1 = Reflex::Type::ByName(name);
	    if(t1) {
	      ATH_MSG_INFO ("Found type: " << t1.Name());
	    }
	    ATH_MSG_INFO ("checkDictionary - full scope name " << name);

	    //if (checkClass(t.Name()) != StatusCode::SUCCESS) isMissingTypes = true;
	    if (checkClass(name) != StatusCode::SUCCESS) isMissingTypes = true;

	}
	//ATH_MSG_DEBUG ("Checking type number: " << i);
    }
    
    if (isMissingTypes) {

      ATH_MSG_INFO ("----->  Missing fields. Please check output and complete selection file!!");

    }
    else {
      ATH_MSG_INFO ("----->  NO Missing fields!!");
    }
}

//----------------------------------------------------------------------------  
bool AthenaSealSvc::ignoreName(const Reflex::Type& t) const
{
//     if (t) {
    ATH_MSG_DEBUG ("Check if class should be ignored: " << t.Name());
//     }
//     else {
// 	return (false);
//     }
    // Now try and match
    for (unsigned int i = 0, iMax = m_ignoreNames.value().size(); i!=iMax; i++) {
	const std::string& name = m_ignoreNames.value()[i];
	if(t.Name().find(name) != std::string::npos) {
	  ATH_MSG_DEBUG
	    ("Warning: Ignoring checks for class name: " << t.Name());
	  return (true);
	}
	
    }
    ATH_MSG_DEBUG ("Not ignored.");
    return (false);
}

//----------------------------------------------------------------------------  
bool AthenaSealSvc::ignoreName(const std::string& typeName) const
{
    if (typeName.size()) {
      ATH_MSG_DEBUG ("Check if class should be ignored: " << typeName);
    }
    else {
	return (false);
    }
    // Now try and match
    for (unsigned int i = 0, iMax = m_ignoreNames.value().size(); i!=iMax; i++) {
	const std::string& ignoreName = m_ignoreNames.value()[i];
	if(typeName.find(ignoreName) != std::string::npos) {
	    ATH_MSG_DEBUG 
	      ("Warning: Ignoring checks for class name: " << typeName);
	    return (true);
	}
	
    }
    ATH_MSG_DEBUG ("Not ignored.");
    return (false);
}


//----------------------------------------------------------------------------  
bool
AthenaSealSvc::missingTypes(const Reflex::Type& t) const
{
    bool isMissingTypes = false;

    // Check for missing class name - NOT NORMAL!!!
    if (t) {
	if (t.Name() == "")  { 
	    ATH_MSG_INFO ("missingTypes: empty Type name - NOT NORMAL ");
	    return (false);
	}
    }
    else {
	// Missing class object, return true
	return (true);
    }


    //ATH_MSG_INFO ("missingTypes: check type " << t.Name() << " isComplete  " << t.IsComplete());
    

    // Check if we should ignore this class
    if (ignoreName(t)) return (false);
    

    // Check c and collect additional classes to check
    if (missing_member_types (t)) isMissingTypes = true;


    // Now check base classes
    if (t.IsClass()) {
	if(t.BaseSize()) {
	  ATH_MSG_DEBUG ("    Loop over superclass names ");
	}
	for (size_t i = 0; i < t.BaseSize(); ++i) {
	    Reflex::Base b = t.BaseAt(i);
	    if (b) {
		std::string bname = b.Name();
		// Remove stl container base classes
		if (bname.find("_base<") == std::string::npos) {
		    msg(MSG::DEBUG) << "      found name: " << bname;
		    Reflex::Type tb = b.ToType();
		    if (tb) {
		        msg(MSG::DEBUG) << ". Type IS defined in dictionary. ";
		    }
		}
		else {
		    if (!ignoreName(bname)) {
		        msg(MSG::INFO) 
			  << endreq
			  << "    ****> Missing base class not defined in dictionary!! " 
			  << endreq
			  << "    ****>   Looking for base class " 
			  << bname << " of type " << t.Name()
			  << endreq;
			isMissingTypes = true;
		    }
		}
	    }
	    msg(MSG::DEBUG) << endreq;
	}
    }

    // Now check the guid
    if (incorrect_guid (t)) isMissingTypes = true;
    
    return (isMissingTypes);
}


//----------------------------------------------------------------------------  
StatusCode AthenaSealSvc::finalize() 
{
    ATH_MSG_INFO ("finalize() in AthenaSealSvc");

    if (msgLvl(MSG::DEBUG)) {
      ATH_MSG_DEBUG ("Classes checked: ");

      std::set<std::string>::const_iterator it   = m_checkedClasses.begin();
      std::set<std::string>::const_iterator last = m_checkedClasses.end();
      for (; it != last; ++it) {
	ATH_MSG_DEBUG ((*it));
      }
    }
    return StatusCode::SUCCESS;
}


void AthenaSealSvc::setDefaultDictNames()
{
  std::vector<std::string> dictNames;
  dictNames.reserve( 10 );

  // STL dictionaries 
  dictNames.push_back( "STLRflx" );
//   dictNames.push_back( "STLAddRflx" );
//   dictNames.push_back( "AtlasSTLAddReflexDict" );

  m_dictionaryNames.set( dictNames );
  return;
}

void AthenaSealSvc::setDefaultIgnoreNames()
{
  std::vector<std::string> ignoreNames;
  ignoreNames.reserve( 100 );

  /// Gaudi
  ignoreNames.push_back( "Gaudi" );
  ignoreNames.push_back( "GaudiPython::Interface" );
  ignoreNames.push_back( "GaudiPython::Helper" );
  ignoreNames.push_back( "FactoryTable" );
  ignoreNames.push_back( "IInterface" );
  ignoreNames.push_back( "IFactory" );
  ignoreNames.push_back( "IAlgFactory" );
  ignoreNames.push_back( "ISvcFactory" );
  ignoreNames.push_back( "IToolFactory" );
  ignoreNames.push_back( "InterfaceID" );
  ignoreNames.push_back( "StatusCode" );
  ignoreNames.push_back( "IAppMgrUI" );
  ignoreNames.push_back( "IProperty" );
  ignoreNames.push_back( "Property" );
  ignoreNames.push_back( "std::vector<Property*>" );
  ignoreNames.push_back( "std::vector<const Property*>" );
  ignoreNames.push_back( "std::list<IAlgorithm*>" );
  ignoreNames.push_back( "std::list<IService*>" );
  ignoreNames.push_back( "std::list<const IFactory*>" );
  ignoreNames.push_back( "std::vector<IRegistry*>" );
  ignoreNames.push_back( "SimpleProperty" );
  ignoreNames.push_back( "SimplePropertyRef" );
  ignoreNames.push_back( "IService" );
  ignoreNames.push_back( "IAlgorithm" );
  ignoreNames.push_back( "ISvcManager" );
  ignoreNames.push_back( "IAlgManager" );
  ignoreNames.push_back( "IJobOptionsSvc" );
  ignoreNames.push_back( "ISvcLocator" );
  ignoreNames.push_back( "IEventProcessor" );
  ignoreNames.push_back( "IDataProviderSvc" );
  ignoreNames.push_back( "IDataManagerSvc" );
  ignoreNames.push_back( "IRegistry" );
  ignoreNames.push_back( "ContainedObject" );
  ignoreNames.push_back( "std::vector<const ContainedObject*>" );
  ignoreNames.push_back( "DataObject" );
  ignoreNames.push_back( "IHistogramSvc" );
  ignoreNames.push_back( "AIDA::I" );
  ignoreNames.push_back( "Algorithm" );
  ignoreNames.push_back( "Service" );
  ignoreNames.push_back( "GaudiPython::PyAlgorithm" );
  ignoreNames.push_back( "GaudiPython::PyAlgorithmWrap" );
  ignoreNames.push_back( "IParticlePropertySvc" );
  ignoreNames.push_back( "ParticleProperty" );
  ignoreNames.push_back( "StoreGateSvc" );
  ignoreNames.push_back( "IStoragePolicy" );
  
  /// POOL - StorageSvc/DbArray.h
  ignoreNames.push_back( "CharDbArray" );
  ignoreNames.push_back( "DoubleDbArray" );
  ignoreNames.push_back( "FloatDbArray" );
  ignoreNames.push_back( "IntDbArray" );
  ignoreNames.push_back( "LongDbArray" );
  ignoreNames.push_back( "ShortDbArray" );


  /// Dicts added by athena.py
  ignoreNames.push_back( "AthenaEventLoopMgr" );
  ignoreNames.push_back( "MinimalEventLoopMgr" );
  ignoreNames.push_back( "PyAthenaEventLoopMgr" );
  ignoreNames.push_back( "NTuple::Directory" );
  ignoreNames.push_back( "NTuple::File " );
  ignoreNames.push_back( "NTuple::Tuple" );
  ignoreNames.push_back( "INTuple" );
  ignoreNames.push_back( "NTuple::Tuple" );

  /// Ignore extra template args
  ignoreNames.push_back( "greater<int>" );
  ignoreNames.push_back( "allocator<" );

  m_ignoreNames.set( ignoreNames );
  return;
}

void AthenaSealSvc::setDefaultIgnoreDicts()
{
  std::vector<std::string> ignoreDicts;
  ignoreDicts.reserve( 5 );

  ignoreDicts.push_back( "libSealCLHEPDict" );

  m_ignoreDicts.set( ignoreDicts );
  return;
}
