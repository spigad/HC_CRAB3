## @file __init__.py
## Hook for the AthenaServices py-module
