#ifndef HAVE_NEW_IOSTREAMS /*gnu-specific*/
#define BOOST_NO_STRINGSTREAM 1 /*FIXME should come from boost config */
#endif

#include "GaudiKernel/ISvcLocator.h"
#include "GaudiKernel/IIncidentSvc.h"
#include "GaudiKernel/Incident.h"

#include "CLHEP/Random/RanecuEngine.h"

#include "StoreGate/tools/hash_functions.h"

#include "interpretSeeds.h"
#include "AtRndmGenSvc.h"
#include <cassert>
#include <iostream>
using namespace std;

/// Standard Constructor
AtRndmGenSvc::AtRndmGenSvc(const std::string& name,ISvcLocator* svc)
  : AthService(name,svc), 
    m_read_from_file(false),
    m_file_to_read("AtRndmGenSvc.out"),    
    m_save_to_file(true),
    m_file_to_write("AtRndmGenSvc.out"),
    m_engines(), m_engines_copy()
{
    // Get user's input
    declareProperty("Seeds", m_streams_seeds,
		    "seeds for the engines, this is a vector of strings of the form ['SequenceName Seed1 Seed2', ...]");
    declareProperty("ReadFromFile", m_read_from_file,
		    "set/restore the status of the engine from file");
    declareProperty("FileToRead",   m_file_to_read,
		    "name of a ASCII file, usually produced by AtRndmGenSvc itself at the end of a job, containing the information to fully set/restore the status of Ranecu");
    declareProperty("SaveToFile", m_save_to_file,
		    "save the status of the engine to file");
    declareProperty("FileToWrite",   m_file_to_write,
		    "name of an ASCII file which will be produced on finalize, containing the information to fully set/restore the status of Ranecu");

    // Set Default values
    m_default_seed1		=	3591;
    m_default_seed2		=	2309736;
    m_PYTHIA_default_seed1	=	93453591;
    m_PYTHIA_default_seed2	=	73436;
    m_HERWIG_default_seed1	=	355391;
    m_HERWIG_default_seed2	=	97336;
}


/// Standard Destructor
AtRndmGenSvc::~AtRndmGenSvc()  
{
  engineIter i(m_engines.begin()), e(m_engines.end());
  while (i != e) delete (i++)->second;
}

// Query the interfaces.
//   Input: riid, Requested interface ID
//          ppvInterface, Pointer to requested interface
//   Return: StatusCode indicating SUCCESS or FAILURE.
// N.B. Don't forget to release the interface after use!!!
StatusCode 
AtRndmGenSvc::queryInterface(const InterfaceID& riid, void** ppvInterface) 
{
    if ( IAtRndmGenSvc::interfaceID().versionMatch(riid) )    {
        *ppvInterface = (IAtRndmGenSvc*)this;
    }
    else  {
	// Interface is not directly available: try out a base class
	return AthService::queryInterface(riid, ppvInterface);
    }
    addRef();
    return StatusCode::SUCCESS;
}

StatusCode 
AtRndmGenSvc::initialize()
{
  ATH_MSG_INFO
    ("Initializing " << name()
     << " - package version " << PACKAGE_VERSION 
     << "\n INITIALISING RANDOM NUMBER STREAMS. ");


  /// Incident Service
  IIncidentSvc* pIncSvc(0);

  // set up the incident service:
  if (!(service("IncidentSvc", pIncSvc, true)).isSuccess()) {
    ATH_MSG_ERROR ("Could not locate IncidentSvc ");
    return StatusCode::FAILURE;
  }
  
  //start listening to "EndEvent"
  static const int PRIORITY = 100;
  pIncSvc->addListener(this, "EndEvent", PRIORITY);


  if (m_read_from_file)
    {
      // Read from a file
      ifstream	infile( m_file_to_read.c_str() );
      if ( !infile ) {
	ATH_MSG_ERROR (" Unable to open: " << m_file_to_read);
	return StatusCode::FAILURE;
      } else {
	std::string buffer;
	while (std::getline(infile, buffer)) {
	  string stream; 
	  long seed1, seed2;
	  //split the space-separated string in 3 words:
	  if (interpretSeeds(buffer, stream, seed1, seed2)) {
	    ATH_MSG_DEBUG 
	      (" INITIALISING " << stream << " stream with seeds "
	       << seed1 << "  " << seed2 
	       << " read from file " << m_file_to_read);
	    CreateStream(seed1, seed2, stream);
	  } else {		
		ATH_MSG_ERROR
		  ("bad line\n" << buffer 
		   << "\n in input file " << m_file_to_read);
		return StatusCode::FAILURE;
	  }		
	}
	
      }
    }

    // Create the various streams according to user's request
    for (VStrings::const_iterator i = m_streams_seeds.begin(); i != m_streams_seeds.end(); ++i) {
      string stream; 
      long seed1, seed2;
      //split the space-separated string in 3 words:
      if (interpretSeeds(*i, stream, seed1, seed2)) {
	ATH_MSG_VERBOSE
	  ("Seeds property: stream " << stream 
	   << " seeds " << seed1 << ' ' << seed2);
      } else {
	ATH_MSG_ERROR ("bad Seeds property\n" << (*i));
	return StatusCode::FAILURE;
      }		
      
      // Check if stream already generated (e.g. from reading a file)
      bool				not_found	=	true;
      if ( number_of_streams() != 0 ) {
	AtRndmGenSvc::engineConstIter sf 		= 	begin();
	do {
	  if ((*sf).first == stream) not_found = false;
	  ++sf;
	} while (sf != end() && not_found);
      }
	
      if (not_found) {
	ATH_MSG_DEBUG
	  (" INITIALISING " << stream << " stream with seeds "
	   << seed1 << "  " << seed2);
	CreateStream(seed1, seed2, stream);
      }
	
    }
    return StatusCode::SUCCESS;
}

void 
AtRndmGenSvc::handle(const Incident &inc) {
  ATH_MSG_DEBUG (" Handle EndEvent ");

  if ( inc.type() == "EndEvent") 
  {

    m_engines_copy.clear();
    for (engineConstIter i = begin(); i != end(); ++i)
    {
      HepRandomEngine* engine = GetEngine((*i).first);
      const long*	    s =	engine->getSeeds();
      std::vector<long int> tseeds;
      tseeds.push_back(s[0]);
      tseeds.push_back(s[1]);
      m_engines_copy.insert( 
	std::map<std::string, std::vector<long int> >::value_type( (*i).first,
						                   tseeds ) );
    }
    
    print();    
  }
}

StatusCode 
AtRndmGenSvc::finalize()
{
  ATH_MSG_INFO (" FINALISING ");

  if (m_save_to_file) {
    // Write the status of the Service into a file
    std::ofstream outfile( m_file_to_write.c_str() );
    if ( !outfile ) {
      ATH_MSG_ERROR ("error: unable to open: " << m_file_to_write);
    } else {
      for  (std::map<std::string, std::vector<long int> >::const_iterator i = m_engines_copy.begin();
	    i != m_engines_copy.end();
	    ++i) { 
	outfile << (*i).first << " " << (*i).second[0] << " " << (*i).second[1] << "\n";
      }
    ATH_MSG_DEBUG (" wrote seeds to " << m_file_to_write );
    }
  }
  return AthService::finalize();
}

HepRandomEngine*
AtRndmGenSvc::GetEngine	( const std::string& StreamName )
{
    engineConstIter citer = m_engines.find(StreamName);
    if ( citer == m_engines.end() )
    {
	m_engines.insert( engineValType( StreamName, new RanecuEngine() ) );
	SetStreamSeeds	( StreamName );
    }
    
    engineIter	iter	=	m_engines.find(StreamName);
    return	(HepRandomEngine*)(*iter).second;
}

void
AtRndmGenSvc::CreateStream	( long seed1, long seed2, const std::string& StreamName )
{
    long seeds[2] = { seed1, seed2 };
    const long* s = seeds;
    engineConstIter citer = m_engines.find(StreamName);
    if ( citer == m_engines.end() ) m_engines.insert( engineValType(	StreamName,
									new RanecuEngine() ) );
    engineIter	iter	=	m_engines.find(StreamName);
    ((*iter).second)->setSeeds( s, -1 );
}

void
AtRndmGenSvc::SetStreamSeeds	( const std::string& StreamName )
{
    long seed1;
    long seed2;
    if (StreamName == "PYTHIA")
    {
	seed1 = m_PYTHIA_default_seed1;
	seed2 = m_PYTHIA_default_seed2;
    }
    else if (StreamName == "HERWIG")
    {
	seed1 = m_HERWIG_default_seed1;
	seed2 = m_HERWIG_default_seed2;
    }
    else
    {
	seed1 = m_default_seed1;
	seed2 = m_default_seed2;
    }
    ATH_MSG_WARNING
      (" INITIALISING " << StreamName << " stream with DEFAULT seeds "
       << seed1 << "  " << seed2);
    
    long seeds[2] = { seed1, seed2 };
    const long* s = seeds;
    engineIter	iter	=	m_engines.find(StreamName);
    ((*iter).second)->setSeeds( s, -1 );
}

void
AtRndmGenSvc::print	( const std::string& StreamName )
{
    engineConstIter citer = m_engines.find(StreamName);
    if ( citer == m_engines.end() )
    {
      ATH_MSG_WARNING (" Stream =  " << StreamName << " NOT FOUND");
    }
    else
    {
	const long* s	=	((*citer).second)->getSeeds();
	ATH_MSG_INFO (" Stream =  " << StreamName << ", Seed1 =  "
		      << s[0] << ", Seed2 = " << s[1]);
    }
}

void
AtRndmGenSvc::print	( void )
{
    for (engineConstIter i = m_engines.begin(); i != m_engines.end(); ++i)
	print( (*i).first );
}

HepRandomEngine*
AtRndmGenSvc::setOnDefinedSeeds	(int eventNumber, int runNumber,
				 const std::string& StreamName)
{
  engineConstIter citer = m_engines.find(StreamName);
  if ( citer == m_engines.end() ) m_engines.insert( engineValType(	StreamName,
									new RanecuEngine() ) );
  engineIter	iter	=	m_engines.find(StreamName);
  int hashedStream(SG::simpleStringHash(StreamName));
  long seeds[2] = { 1000*runNumber + hashedStream, 
		    eventNumber };
  assert( seeds[0] > 0 );
  assert( seeds[1] > 0 );
  const long* s = seeds;
  ((*iter).second)->setSeeds( s, -1 );
  return	(HepRandomEngine*)(*iter).second;
}

HepRandomEngine*
AtRndmGenSvc::setOnDefinedSeeds	(int eventNumber, const std::string& StreamName){
  engineConstIter citer = m_engines.find(StreamName);
  if ( citer == m_engines.end() ) m_engines.insert( engineValType(	StreamName,
									new RanecuEngine() ) );
  engineIter	iter	=	m_engines.find(StreamName);
  int hashedStream(SG::simpleStringHash(StreamName));
  long seeds[2] = { hashedStream % (eventNumber+13), 
		    eventNumber };
  assert( seeds[0] > 0 );
  assert( seeds[1] > 0 );
  const long* s = seeds;
  ((*iter).second)->setSeeds( s, -1 );
  return	(HepRandomEngine*)(*iter).second;
}

