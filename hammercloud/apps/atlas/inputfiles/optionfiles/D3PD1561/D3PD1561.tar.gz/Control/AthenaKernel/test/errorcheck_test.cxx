// $Id: errorcheck_test.cxx,v 1.6 2009-04-09 15:11:18 ssnyder Exp $
/**
 * @file  errorcheck_test.cxx
 * @author scott snyder <snyder@bnl.gov>
 * @date Jan, 2006
 * @brief Regression tests for errorcheck.
 */

#undef NDEBUG

#include "AthenaKernel/errorcheck.h"
#include "TestTools/initGaudi.h"
#include "GaudiKernel/StatusCode.h"
#include "GaudiKernel/Algorithm.h"
#include "GaudiKernel/AlgTool.h"
#include "GaudiKernel/Service.h"
#include "GaudiKernel/Bootstrap.h"
#include <cassert>


class Algtest
  : public Algorithm
{
public:
  Algtest()
    : Algorithm ("algname", Gaudi::svcLocator()) {}
  virtual StatusCode execute() { return StatusCode (StatusCode::SUCCESS); }
  StatusCode test1();
};


StatusCode Algtest::test1()
{
  REPORT_ERROR (StatusCode (StatusCode::FAILURE)) << "foomsg";
  REPORT_MESSAGE (MSG::INFO) << "some info";
  CHECK( StatusCode (StatusCode::SUCCESS) );
  CHECK( StatusCode (StatusCode::FAILURE) );
  return StatusCode (StatusCode::SUCCESS);
}


class Algtooltest
  : public AlgTool
{
public:
  Algtooltest (IInterface* parent)
    : AlgTool ("tooltype", "toolname", parent) {}
  StatusCode test1();
};


StatusCode Algtooltest::test1()
{
  REPORT_ERROR (StatusCode (StatusCode::FAILURE)) << "foomsg";
  REPORT_MESSAGE (MSG::INFO) << "some info";
  CHECK( StatusCode (StatusCode::SUCCESS) );
  CHECK( StatusCode (StatusCode::RECOVERABLE) );
  return StatusCode (StatusCode::SUCCESS);
}


class Servtest
  : public Service
{
public:
  Servtest()
    : Service ("servname", Gaudi::svcLocator()) {}
  StatusCode test1();
};


StatusCode Servtest::test1()
{
  REPORT_ERROR (StatusCode (StatusCode::FAILURE)) << "foomsg";
  REPORT_MESSAGE (MSG::INFO) << "some info";
  CHECK_RECOVERABLE( StatusCode (StatusCode::SUCCESS) );
  CHECK_RECOVERABLE( StatusCode (StatusCode::FAILURE) );
  return StatusCode (StatusCode::SUCCESS);
}


class Test
{
public:
  StatusCode test1();
};


StatusCode Test::test1()
{
  REPORT_ERROR (StatusCode (StatusCode::FAILURE)) << "foomsg";
  REPORT_MESSAGE (MSG::INFO) << "some info";
  CHECK_FATAL( StatusCode (StatusCode::SUCCESS) );
  CHECK_FATAL( StatusCode (StatusCode::RECOVERABLE) );
  return StatusCode (StatusCode::SUCCESS);
}


StatusCode test1a()
{
  CHECK_WITH_CONTEXT( StatusCode (StatusCode::SUCCESS), "alg" );
  CHECK_WITH_CONTEXT( StatusCode (StatusCode::FAILURE), "alg" );
  return StatusCode (StatusCode::SUCCESS);
}


StatusCode test1b()
{
  CHECK_RECOVERABLE_WITH_CONTEXT( StatusCode (StatusCode::SUCCESS), "alg" );
  CHECK_RECOVERABLE_WITH_CONTEXT( StatusCode (StatusCode::FAILURE), "alg" );
  return StatusCode (StatusCode::SUCCESS);
}


StatusCode test1c()
{
  CHECK_RECOVERABLE_WITH_CONTEXT( StatusCode (StatusCode::SUCCESS), "alg" );
  CHECK_RECOVERABLE_WITH_CONTEXT( StatusCode (StatusCode::RECOVERABLE),"alg" );
  return StatusCode (StatusCode::SUCCESS);
}


StatusCode test1d()
{
  CHECK_FATAL_WITH_CONTEXT( StatusCode (StatusCode::SUCCESS), "alg" );
  CHECK_FATAL_WITH_CONTEXT( StatusCode (StatusCode::FAILURE), "alg" );
  return StatusCode (StatusCode::SUCCESS);
}


StatusCode test1e()
{
  CHECK_FATAL_WITH_CONTEXT( StatusCode (StatusCode::SUCCESS), "alg" );
  CHECK_FATAL_WITH_CONTEXT( StatusCode (StatusCode::RECOVERABLE), "alg" );
  return StatusCode (StatusCode::SUCCESS);
}


StatusCode test1()
{
  Algtest algtest;  algtest.addRef();
  Algtooltest algtooltest (&algtest);  algtooltest.addRef();
  Servtest servtest;  servtest.addRef();
  Test test;
  REPORT_ERROR_WITH_CONTEXT (StatusCode (StatusCode::FAILURE), "alg")
    << "foomsg";
  REPORT_MESSAGE_WITH_CONTEXT (MSG::INFO, "alg")
    << "some message";
  {
    errorcheck::ReportMessage msg (MSG::INFO, ERRORCHECK_ARGS, "alg");
    msg << "a... ";
    msg << "b";
  }
  REPORT_MESSAGE_WITH_CONTEXT (MSG::INFO, "alg") << "foo" << endreq;
  assert( test1a().isFailure() );
  assert( test1b().isFailure() );
  assert( test1c().isFailure() );
  assert( test1d().isFailure() );
  assert( test1e().isFailure() );
  assert( algtest.test1().isFailure() );
  assert( algtooltest.test1().isFailure() );
  assert( servtest.test1().isFailure() );
  assert( test.test1().isFailure() );

  errorcheck::ReportMessage::hideErrorLocus();
  REPORT_ERROR_WITH_CONTEXT (StatusCode (StatusCode::FAILURE), "alg")
    << "foox";
  errorcheck::ReportMessage::hideErrorLocus (false);
  REPORT_ERROR_WITH_CONTEXT (StatusCode (StatusCode::FAILURE), "alg")
    << "fooy";
  return StatusCode (StatusCode::SUCCESS);
}


int main()
{
  ISvcLocator* loc;
  assert( Athena_test::initGaudi (loc) );
  test1();
  return 0;
}
