/** @class IAddressProvider
 * @brief interface for IOA providers
 *
 * @author <pcalafiura@lbl.gov> - ATLAS Collaboration
 *
 * $Id: IAddressProvider.h,v 1.9 2003-04-16 01:12:23 calaf Exp $
 ***************************************************************************/

#ifndef ATHENAKERNEL_IADDRESSPROVIDER_H
# define ATHENAKERNEL_IADDRESSPROVIDER_H

//<<<<<< INCLUDES                                                       >>>>>>
#ifndef _CPP_LIST
 #include <list>
#endif
#ifndef KERNEL_STATUSCODES_H
 #include "GaudiKernel/StatusCode.h"
#endif
#ifndef ATHENAKERNEL_STOREID_H
 #include "AthenaKernel/StoreID.h"
#endif

//<<<<<< FORWARD DECLARATIONS                                           >>>>>>
namespace SG {
  class TransientAddress;
}

//<<<<<< CLASS DECLARATIONS                                             >>>>>>
class IAddressProvider {
public:
  typedef std::list<SG::TransientAddress*> tadList;
  typedef tadList::iterator tadListIterator;

  ///get all addresses from Provider : Called before Begin Event
  virtual StatusCode preLoadAddresses(StoreID::type /* storeID */,
				      tadList& /* list */) {
     return StatusCode::SUCCESS;
  }

  /// get all new addresses from Provider for this Event.
  virtual StatusCode loadAddresses(StoreID::type /* storeID */,
				   tadList& /* list */) {
     return StatusCode::SUCCESS;
  }

  /// update a transient Address
  virtual StatusCode updateAddress(SG::TransientAddress* tad) = 0;

  virtual ~IAddressProvider() {}
};

//<<<<<< INLINE PUBLIC FUNCTIONS                                        >>>>>>
//<<<<<< INLINE MEMBER FUNCTIONS                                        >>>>>>

#endif // ATHENAKERNEL_IADDRESSPROVIDER_H



