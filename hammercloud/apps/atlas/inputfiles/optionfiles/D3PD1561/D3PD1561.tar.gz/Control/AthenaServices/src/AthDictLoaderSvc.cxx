///////////////////////// -*- C++ -*- /////////////////////////////
// AthDictLoaderSvc.cxx 
// Implementation file for class AthDictLoaderSvc
// Author: S.Binet<binet@cern.ch>
/////////////////////////////////////////////////////////////////// 

// Python
#include "Python.h"
// fixes 'dereferencing type-punned pointer will break strict-aliasing rules'
#ifdef Py_True
#undef Py_True
#define Py_True ( (PyObject*)(void*)&_Py_TrueStruct )
#endif
#ifdef Py_False
#undef Py_False
#define Py_False ( (PyObject*)(void*)&_Py_ZeroStruct )
#endif

// AthenaServices includes
#include "AthDictLoaderSvc.h"

// STL includes

// FrameWork includes
#include "GaudiKernel/Property.h"
#include "GaudiKernel/System.h"
#include "SGTools/BaseInfo.h"

namespace Rflx = ROOT::Reflex;

namespace {
  /// helper function to capture the boilerplate code for user friendly
  /// stack trace display
  void report_py_exception (bool display = true)
  {
    if (display) {
      // fetch error
      PyObject* pytype = 0, *pyvalue = 0, *pytrace = 0;
      PyErr_Fetch (&pytype, &pyvalue, &pytrace);
      Py_XINCREF  (pytype);
      Py_XINCREF  (pyvalue);
      Py_XINCREF  (pytrace);
      // restore...
      PyErr_Restore (pytype, pyvalue, pytrace);
      // and print
      PyErr_Print();
    }
  }
}

/////////////////////////////////////////////////////////////////// 
// Public methods: 
/////////////////////////////////////////////////////////////////// 

// Constructors
////////////////
AthDictLoaderSvc::AthDictLoaderSvc (const std::string& name, 
                                    ISvcLocator* pSvcLocator) : 
  ::AthService( name, pSvcLocator ),
  m_dsodb (0),
  m_doRecursiveLoad (true),
  m_clidSvc ("ClassIDSvc", name)
{
  //
  // Property declaration
  // 
  //declareProperty( "Property", m_nProperty );

  declareProperty ("DoRecursiveLoad",
		   m_doRecursiveLoad = true,
		   "Switch to recursively load (or not) all dictionaries for "
		   "all types composing a given one. \n"
		   "  ie: load dict of Bar in 'struct Foo {Bar*b;};' \n"
		   "Default is 'true'.");
}

// Destructor
///////////////
AthDictLoaderSvc::~AthDictLoaderSvc()
{
  Py_XDECREF (m_dsodb);
}

// Athena Service's Hooks
////////////////////////////
StatusCode AthDictLoaderSvc::initialize()
{
  ATH_MSG_INFO ("in initialize...");
  if (!Py_IsInitialized()) {
    Py_Initialize();
    if (!Py_IsInitialized()) {
      ATH_MSG_ERROR("could not get an initialized python interpreter");
      ::report_py_exception();
      return StatusCode::FAILURE;
    }
  }

  PyObject *module = PyImport_ImportModule ((char*)"AthenaServices.Dso");
  if (!module || !PyModule_Check (module)) {
    ATH_MSG_ERROR ("could not import module [AthenaServices.Dso] !");
    Py_XDECREF (module);
    ::report_py_exception();
    return StatusCode::FAILURE;
  }
  // instance is borrowed
  PyObject *instance = PyDict_GetItemString (PyModule_GetDict (module),
					     (char*)"registry");
  Py_DECREF (module);
  if (!instance) {
    ATH_MSG_ERROR ("could not retrieve 'registry' instance from module "
		   "[AthenaServices.Dso] !");
    ::report_py_exception();
    return StatusCode::FAILURE;
  }

  // acquire reference
  Py_INCREF (instance);
  // steal reference
  m_dsodb = instance;

  ATH_MSG_INFO ("acquired Dso-registry");

  if (!m_clidSvc.retrieve().isSuccess()) {
    ATH_MSG_ERROR("could not retrieve [" << m_clidSvc.typeAndName() << "]");
    return StatusCode::FAILURE;
  }

  return StatusCode::SUCCESS;
}

StatusCode AthDictLoaderSvc::finalize()
{
  ATH_MSG_INFO ("in finalize...");
  return StatusCode::SUCCESS;
}

// Query the interfaces.
//   Input: riid, Requested interface ID
//          ppvInterface, Pointer to requested interface
//   Return: StatusCode indicating SUCCESS or FAILURE.
// N.B. Don't forget to release the interface after use!!!
StatusCode 
AthDictLoaderSvc::queryInterface(const InterfaceID& riid, void** ppvInterface) 
{
  if ( IDictLoaderSvc::interfaceID().versionMatch(riid) ) {
    *ppvInterface = dynamic_cast<IDictLoaderSvc*>(this);
  } else {
    // Interface is not directly available : try out a base class
    return ::AthService::queryInterface(riid, ppvInterface);
  }
  addRef();
  return StatusCode::SUCCESS;
}

/** @brief check a @c Reflex dictionary exists for a given type
 */
bool
AthDictLoaderSvc::has_type (const std::string& type_name)
{
  if (!m_dsodb)
    return false;

  PyObject *res = PyObject_CallMethod (m_dsodb, 
				       (char*)"has_type",
				       (char*)"s", 
				       (char*)type_name.c_str());
  if (!res) {
    // FIXME: do something !
    return false;
  }

  bool has_type = res == Py_True;
  Py_DECREF (res);

  if (!has_type)
    ATH_MSG_DEBUG ("no reflex dict. for type [" << type_name << "]");

  return has_type;
}

/** @brief check a @c Reflex dictionary exists for a given type
 */
bool
AthDictLoaderSvc::has_type (const std::type_info& typeinfo)
{
  return has_type (System::typeinfoName(typeinfo).c_str());
}

/** @brief check a @c Reflex dictionary exists for a given type
 */
bool
AthDictLoaderSvc::has_type (CLID clid)
{
  bool ret = false;
  std::string name = "<N/A>";
  if (m_clidSvc->getTypeNameOfID(clid, name).isSuccess()) {
    ret = has_type (name);
    if (ret) {
      return ret;
    }
  }

  // try out the typeinfoname...
  if (m_clidSvc->getTypeInfoNameOfID(clid, name).isSuccess()) {
    ret = has_type (name);
    if (ret) {
      return ret;
    }
  }
  
  return ret;
}

/** @brief retrieve a @c Reflex::Type by name (auto)loading the dictionary
 *         by any necessary means.
 */
const Rflx::Type
AthDictLoaderSvc::load_type (const std::string& type_name)
{
  ATH_MSG_DEBUG ("loading [" << type_name << "]...");

  if (!m_dsodb) {
    // dummy
    return Rflx::Type();
  }

  // load library
  PyObject *res = PyObject_CallMethod (m_dsodb,
				       (char*)"load_type",
				       (char*)"s",
				       (char*)type_name.c_str());
  if (!res || res == Py_None || !PyString_Check (res)) {
    Py_XDECREF (res);
    return Rflx::Type();
  }

  const std::string cpp_typename = PyString_AsString(res);
  Py_DECREF (res);
  return Rflx::Type::ByName (cpp_typename);
}

/** @brief retrieve a @c Reflex::Type by @c std::type_info (auto)loading the
 *         dictionary by any necessary means.
 *         This method is preferred over the above one as it is guaranteed to
 *         succeed *IF* the dictionary for that type has been generated.
 */
const Rflx::Type
AthDictLoaderSvc::load_type (const std::type_info& typeinfo)
{
  ATH_MSG_DEBUG 
    ("loading [" << System::typeinfoName(typeinfo) << " (from typeinfo)]...");
  return load_type (System::typeinfoName(typeinfo));
}

/** @brief retrieve a @c Reflex::Type by name (auto)loading the dictionary
 *         by any necessary means.
 */
const Rflx::Type
AthDictLoaderSvc::load_type (CLID clid)
{
  std::string name = "<N/A>";
  if (!m_clidSvc->getTypeNameOfID(clid, name).isSuccess()) {
    ATH_MSG_INFO ("could not retrieve typename for clid [" << clid << "]");
    // try out the bare std::type_info if available...
    const SG::BaseInfoBase* bib = SG::BaseInfoBase::find(clid);
    if (bib) {
      return load_type(bib->typeinfo());
    }
    // fail early...
    return Rflx::Type();
  }
  
  ATH_MSG_DEBUG("loading [" << name << " (from clid="<<clid<<")]...");

  Rflx::Type type = load_type(name);
  if (type) {
    return type;
  }

  // try out the typeinfo-name
  m_clidSvc->getTypeInfoNameOfID(clid, name).ignore();
  type = load_type(name);
  if (type) {
    return type;
  }

  // try out the bare std::type_info if available...
  const SG::BaseInfoBase* bib = SG::BaseInfoBase::find(clid);
  if (bib) {
    return load_type(bib->typeinfo());
  }
  return type;
}

/////////////////////////////////////////////////////////////////// 
// Const methods: 
///////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////// 
// Non-const methods: 
/////////////////////////////////////////////////////////////////// 

/////////////////////////////////////////////////////////////////// 
// Protected methods: 
/////////////////////////////////////////////////////////////////// 

/////////////////////////////////////////////////////////////////// 
// Const methods: 
///////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////// 
// Non-const methods: 
/////////////////////////////////////////////////////////////////// 


