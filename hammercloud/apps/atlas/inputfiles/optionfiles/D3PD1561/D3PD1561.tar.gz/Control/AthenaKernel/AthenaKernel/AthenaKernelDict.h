// dear emacs, this is -*- C++ -*-
#ifndef ATHENAKERNEL_ATHENAKERNELDICT_H
#define ATHENAKERNEL_ATHENAKERNELDICT_H 1

#include <vector>
#include "AthenaKernel/UserDataAssociation.h"
#include "AthenaKernel/IEventSeek.h"

namespace AthenaKernelDict {
  struct tmp {
    std::vector<UserDataAssociation> uv;
  };
} //> namespace AthenaKernelDict

#endif // !ATHENAKERNEL_ATHENAKERNELDICT_H
