#include "AthenaKernel/AddressProviderSvc.h"

// a dummy place holder
void AddressProviderSvc::dummy() 
{ }
