#include <boost/lexical_cast.hpp>
#include <boost/tokenizer.hpp>

#include "interpretSeeds.h"

bool interpretSeeds(const std::string& buffer, 
		    std::string& stream, long& seed1, long& seed2) {
  //split the space-separated string in 3 words:	
  typedef boost::tokenizer<boost::char_separator<char> > tokenizer;
  boost::char_separator<char> sep(" ");
  tokenizer tokens(buffer, sep);	      	    
  bool status = (distance(tokens.begin(), tokens.end()) == 3);
  if (status) {
    tokenizer::iterator token(tokens.begin());
    stream = *token++;
    try {
      seed1 = boost::lexical_cast<long>(*token++);
      seed2 = boost::lexical_cast<long>(*token++);
    } catch (boost::bad_lexical_cast e) {
      status = false;
    }
  }
  return status;
}

bool interpretSeeds(const std::string& buffer, 
		    std::string& stream, std::vector<unsigned long>& seeds) {
  //split the space-separated string in 31 words:	
  typedef boost::tokenizer<boost::char_separator<char> > tokenizer;
  boost::char_separator<char> sep(" ");
  tokenizer tokens(buffer, sep);
  bool status = (distance(tokens.begin(), tokens.end()) == 31);
  if (status) {
    tokenizer::iterator token(tokens.begin());
    stream = *token++;
    try {
      for (int i=0; i<30; i++) {
	seeds.push_back(boost::lexical_cast<unsigned long>(*token++));
      }
    } catch (boost::bad_lexical_cast e) {
      status = false;
    }
  }
  return status;
}
