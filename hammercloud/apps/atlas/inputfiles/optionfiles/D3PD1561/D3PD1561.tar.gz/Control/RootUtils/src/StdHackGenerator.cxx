// $Id: StdHackGenerator.cxx,v 1.4 2008-03-20 15:30:00 ssnyder Exp $
/**
 * @file  RootUtils/src/StdHackGenerator.cxx
 * @author scott snyder
 * @date Oct 2007
 * @brief Work around inconsistent use of @c std::  and spaces.
 */

#include "RootUtils/StdHackGenerator.h"
#include "TROOT.h"
#include "TClassEdit.h"
#include "TClassTable.h"
#include "TInterpreter.h"


namespace {


/**
 * @brief Make a new class name, inserting any missing @c std:: qualifications.
 * @param in The name to edit.
 * @return The new name (may be the same as @a in).
 */
std::string addstd (const std::string& in)
{
  // string -> std::string
  if (in == "string")
    return "std::string";

  // Otherwise, give up if it's not a template name.
  if (strchr (in.c_str(), '<') == 0)
    return in;

  // Split apart template arguments.
  std::vector<std::string> vec;
  int loc;
  TClassEdit::GetSplit (in.c_str(), vec, loc);
  if (vec.empty())
    return "";
  else {
    std::string out;

    // If the template name is a STL name that does not start with
    // std::, then add std::.
    if (strncmp (vec[0].c_str(), "std::", 5) != 0 &&
        (TClassEdit::STLKind (vec[0].c_str()) != 0 ||
         vec[0] == "pair" ||
         vec[0] == "string"))
    {
      out = "std::";
    }
    out += vec[0];

    // Now add the arguments.  Process each one recursively.
    if (vec.size() > 1) {
      out += "<";
      for (size_t i = 1; i < vec.size(); i++) {
        if (i > 1) out += ",";
        out += addstd (vec[i]);
      }
      if (out[out.size()-1] == '>')
        out += " ";
      out += ">";
    }
    return out;
  }
}

// Need to convert
//__gnu_cxx::__normal_iterator<HepMC::GenParticle*const*,vector<HepMC::GenParticle*> >
//to
//__gnu_cxx::__normal_iterator<HepMC::GenParticle* const*,vector<HepMC::GenParticle*> >

/**
 * @brief Make a new class name, inserting any missing spaces.
 * @param in The name to edit.
 * @return The new name (may be the same as @a in).
 */
std::string addspc (const std::string& in)
{
  if (strchr (in.c_str(), '<') == 0) {
    std::string::size_type i = in.find ("*const*");
    if (i != std::string::npos) {
      std::string out = in;
      out.insert (i+1, " ");
      return out;
    }
    return in;
  }

  // Split apart template arguments.
  std::vector<std::string> vec;
  int loc;
  TClassEdit::GetSplit (in.c_str(), vec, loc);
  if (vec.empty())
    return "";
  else {
    std::string out;

    out += vec[0];

    // Now add the arguments.  Process each one recursively.
    if (vec.size() > 1) {
      out += "<";
      for (size_t i = 1; i < vec.size(); i++) {
        if (i > 1) out += ",";
        out += addspc (vec[i]);
      }
      if (out[out.size()-1] == '>')
        out += " ";
      out += ">";
    }
    return out;
  }
}


} // anonymous namespace


namespace RootUtils {


/**
 * @brief Initialize.
 *        Create an instance of this class and register it as a generator.
 */
void StdHackGenerator::initialize()
{
  // Only do this once.
  static bool initialized = false;
  if (!initialized) {
    initialized = true;
    gROOT->AddClassGenerator (new StdHackGenerator);
  }
}


/**
 * @brief Look up a class by name.
 * @param classname The name of the class to find.
 * @param load If true, enable autoloading.
 */
TClass* StdHackGenerator::GetClass (const char* classname, Bool_t load)
{
  // Don't do anything if no autoloading.
  if (!load)
    return 0;

  // Add any missing std::'s to the name.
  std::string newname = addstd (classname);

  // If it's different, retry the autoloading.
  if (newname != classname && gInterpreter->AutoLoad (newname.c_str())) {
    // From here, we're just copying what the root code does.
    VoidFuncPtr_t dict = TClassTable::GetDict (newname.c_str());
    if (!dict)
      dict = TClassTable::GetDict (classname);
    if (dict) {
      (dict)();
      return gROOT->GetClass (newname.c_str(), kFALSE);
    }
  }

  newname = addspc (classname);
  // If it's different, retry the autoloading.
  if (newname != classname && gInterpreter->AutoLoad (newname.c_str())) {
    // From here, we're just copying what the root code does.
    VoidFuncPtr_t dict = TClassTable::GetDict (newname.c_str());
    if (!dict)
      dict = TClassTable::GetDict (classname);
    if (dict) {
      (dict)();
      return gROOT->GetClass (newname.c_str(), kFALSE);
    }
  }

  return 0;
}


/**
 * @brief Look up a class by @c type_info.
 * @param typeinfo The @c type_info of the class to find.
 * @param load If true, enable autoloading.
 */
TClass* StdHackGenerator::GetClass (const type_info& typeinfo, Bool_t load)
{
  // Just get the name and pass to the other overload.
  return GetClass (typeinfo.name(), load);
}


} // namespace RootUtils
