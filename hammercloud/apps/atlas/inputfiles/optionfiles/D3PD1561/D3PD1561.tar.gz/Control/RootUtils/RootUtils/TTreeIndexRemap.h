// This file's extension implies that it's C, but it's really -*- C++ -*-.
// $Id: TTreeIndexRemap.h,v 1.1 2008-03-21 05:24:40 ssnyder Exp $

/**
 * @file  RootUtils/TTreeIndexRemap.h
 * @author scott snyder
 * @date Mar 2008
 * @brief Work around index naming issues in reading DPDs.
 */


#ifndef ROOTUTILS_TTREEINDEXREMAP_H
#define ROOTUTILS_TTREEINDEXREMAP_H


#include "TTreeIndex.h"
#include <string>


namespace RootUtils {


// xxx
class TTreeIndexRemap
  : public TTreeIndex
{
public:
  /**
   * @brief Return a pointer to the @c TreeFormula corresponding to the
   *        majorname in parent tree T.
   * @param T The parent tree.
   *
   * The column name is remapped, if needed.
   */
  virtual TTreeFormula* GetMajorFormulaParent(const TTree *T);


  /**
   * @brief Return a pointer to the @c TreeFormula corresponding to the
   *        minorname in parent tree T.
   * @param T The parent tree.
   *
   * The column name is remapped, if needed.
   */
  virtual TTreeFormula* GetMinorFormulaParent(const TTree *T);


  /**
   * @brief Set up so that this class gets used for TTreeIndex on reading.
   */
  static void initialize();


  /**
   * @brief Register a new name mapping.
   * @param from The source of the mapping.
   * @param to The target of the mapping.
   */
  static void add_mapping (const std::string& from, const std::string& to);


private:
  /**
   * @brief new() method for this object.
   * @param p Address for placement new, or 0.
   * @return Address of the new object.
   *
   * This is installed as the @c New method in @c TTreeIndex's @c TClass.
   * Thus, when we read from a file a @c TTreeIndex, we actually
   * make an instance of this class.
   */
  static void* new_TTreeIndexRemap (void *p);


  /**
   * @brief Change the index column name if needed.
   * @param t The parent tree.
   * @param name The index column name or formula.
   *
   * If @a name is not a member of @a t and there's a mapping
   * entry for it, change @a name to the target of the mapping.
   */
  static void maybe_remap (const TTree* t, TString& name);
};


} // namespace RootUtils


#endif // not ROOTUTILS_TTREEINDEXREMAP_H
