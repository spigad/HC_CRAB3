//===================================================================
//	PyAthenaEventLoopMgr.cxx
//--------------------------------------------------------------------
//
//	Package    : AthenaServices
//
//  Description: implementation of the Application's interactive mode
//               handler
//
//	Author     : Wim Lavrijsen
//  History    :
// +---------+----------------------------------------------+---------
// |    Date |                 Comment                      | Who     
// +---------+----------------------------------------------+---------
// | 01/12/05| Initial version                              | WL
// +---------+----------------------------------------------+---------
//
//====================================================================

// Python
#include "Python.h"

// Gaudi
#include "GaudiKernel/MsgStream.h"
#include "GaudiKernel/Bootstrap.h"
#include "GaudiKernel/ISvcLocator.h"
#include "GaudiKernel/IAlgorithm.h"
#include "GaudiKernel/DataSvc.h"

// AthenaServices
#include "PyAthenaEventLoopMgr.h"


//- data ------------------------------------------------------------------
namespace {

   char* execalgs = const_cast< char* >( "executeAlgorithms" );

} // unnamed namespace


//=========================================================================
// Outside access to the event loop manager
//=========================================================================
PyAthenaEventLoopMgr* PyAthenaEventLoopMgr::pointer() {
   IEventProcessor* ep = 0;

   static const bool CREATEIF( false );
   if ( ( Gaudi::svcLocator()->service( "PyAthenaEventLoopMgr", ep, CREATEIF ) ).isSuccess() ) {
      ep->addRef();
      return dynamic_cast< PyAthenaEventLoopMgr* >( ep ); 
   }

   return 0;
}


//=========================================================================
// Standard Constructor
//=========================================================================
PyAthenaEventLoopMgr::PyAthenaEventLoopMgr( const std::string& name, 
                                            ISvcLocator* svcLoc )
   : AthenaEventLoopMgr( name, svcLoc ), m_manager( 0 )
{
  /// overrides the base-class default: for interactive use, it is mandatory
  /// to leave the store untouched at the end of the event (so people can
  /// interactively browse the store).
  /// Hence, we ask for store clean-up at the beginning of the event.
  AthenaEventLoopMgr::m_clearStorePolicy.set( "BeginEvent" );
}


//=========================================================================
// Python side manager set/get
//=========================================================================
PyObject* PyAthenaEventLoopMgr::setManager( PyObject* mgr )
{
   if ( ! PyObject_HasAttrString( mgr, execalgs ) )
   {
      PyErr_SetString( PyExc_TypeError, "given object is not a manager" );
      return 0;
   }

   PyObject* old = m_manager;
   Py_XINCREF( mgr );
   m_manager = mgr;

   if ( old != 0 )
      return old;

   Py_INCREF( Py_None );
   return Py_None;
}

PyObject* PyAthenaEventLoopMgr::getManager()
{
   if ( ! m_manager )
   {
      Py_INCREF( Py_None );
      return Py_None;
   }
      
   Py_INCREF( m_manager );
   return m_manager;
}


PyObject* PyAthenaEventLoopMgrHelper::SetPyAthenaEventLoopMgrManager( IProperty* ip, PyObject* mgr )
{
   PyAthenaEventLoopMgr* pyevt = 0;

   IEventProcessor* ievtpro = 0;
   if ( ip )
      ip->queryInterface( IEventProcessor::interfaceID(), (void**)&ievtpro ).ignore();

   pyevt = dynamic_cast< PyAthenaEventLoopMgr* >( ievtpro );
   if ( ! pyevt ) {
      PyErr_SetString( PyExc_TypeError, "received wrong or null IService pointer" );
      return 0;
   }

   return pyevt->setManager( mgr );
}


//=========================================================================
// Run the algorithms for the current event
//=========================================================================
StatusCode PyAthenaEventLoopMgr::executeAlgorithms()
{
   if ( m_manager != 0 )
   {
   // forward call, if python side manager available
      PyObject* result = PyObject_CallMethod( m_manager, execalgs, (char*)"" );

      if ( ! result )
      {
	  PyErr_Print();            // should use MessageSvc instead
	  return StatusCode::FAILURE;
      }

      if ( PyInt_Check( result ) || PyLong_Check( result ) )
      {
	 StatusCode sc = StatusCode( (int) PyInt_AS_LONG( result ) );
         Py_DECREF( result );
         return sc;
      }

   // FIXME: allow python result to be a statuscode
      MsgStream log( msgSvc(), name() );
      log << MSG::ERROR
	  << "result from python event loop manager has unexpected type."
	  << endreq;
      Py_DECREF( result );
      return StatusCode::FAILURE;
   }

// otherwise, let base class handle it
   return AthenaEventLoopMgr::executeAlgorithms();
}
