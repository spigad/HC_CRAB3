__version__ = '1.0.0'
__author__  = 'Yushu Yao (yyao@lbl.gov)'
 
__all__ = [ 'TheUserDataSvc' ]

from AthenaServicesConf import UserDataSvc
import sys

class TheUserDataSvc(UserDataSvc):
    __slots__ = [] 
    def __init__(self, name = 'UserDataSvc'): 
         super(TheUserDataSvc, self).__init__(name)
          
    def setDefaults(cls, handle):
        pass;
         
    def __setattr__(self, name, value):

        callbase=True;
        
        if name=="OutputStream":
 #           print "Setting OutputStream:",value

            outfilename=value.OutputFile
            super( TheUserDataSvc, self ).__setattr__( name, value.getName() )
            from AthenaCommon.AppMgr import ServiceMgr as svcMgr
            if not hasattr( svcMgr, 'THistSvc' ):
                from GaudiSvc.GaudiSvcConf import THistSvc
                svcMgr+=THistSvc("THistSvc")
            svcMgr.THistSvc.Output+=["userdataoutputstream_"+self.name()+" DATAFILE='"+outfilename+"' OPT='SHARE'"]
 #           print "Setting svcMgr.THistSvc.Output:",svcMgr.THistSvc.Output
            callbase=False
            
        if name=="OutputFileName":
            print "Obsolete option 'OutputFileName', please use OutputStream=mystream instead!!"
            sys.exit(1)
            
        if callbase:
            super( TheUserDataSvc, self ).__setattr__( name, value )
