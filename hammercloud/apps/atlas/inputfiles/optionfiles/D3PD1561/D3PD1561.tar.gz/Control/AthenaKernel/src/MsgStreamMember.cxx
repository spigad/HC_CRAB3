/** @file MsgStreamMember.cxx
 *  @brief MsgStreamMember implementation
 *
 *  $Id: MsgStreamMember.cxx,v 1.1 2008-07-14 22:10:14 calaf Exp $
 *  @author Paolo Calafiura - Atlas collaboration
 */
#include "AthenaKernel/MsgStreamMember.h"
using namespace Athena;
/// @param o: if o is @c Athena::Options::Eager it will create a
/// @c MsgStream instance there and then.
MsgStreamMember::MsgStreamMember(const Athena::Options::CreateOptions opt, 
				 const std::string& label) :   
  m_ims(opt), m_label(label)
{
  if (opt == Athena::Options::Eager) m_stream = new MsgStream(m_ims.get(), m_label);
}
MsgStreamMember::~MsgStreamMember() { delete m_stream; }

/// upon first access sets m_ims as needed
MsgStream& MsgStreamMember::get() const {
  if (0 == m_stream) m_stream = new MsgStream(m_ims.get(), m_label);
  return *m_stream;
}
