#ifndef KERNEL_STATUSCODES_H
 #include "GaudiKernel/StatusCode.h"
#endif
#ifndef _CPP_STRING
 #include <string>
#endif
class IService;
class Service;
namespace CloneService {
  /** given a reference to a parent svc sets a reference to a cloned child */
  StatusCode clone(const IService* parent, const std::string& childName,
		   Service*& child);
}
