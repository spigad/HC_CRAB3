/** @class IProxyProviderSvc.h 
 * @brief add on demand proxies to the address registry (SG)
 *
 * @author pcalafiura@lbl.gov - ATLAS Collaboration
 ***************************************************************************/

// $Id: IProxyProviderSvc.h,v 1.9 2007-06-23 01:12:06 calaf Exp $

#ifndef ATHENAKERNEL_IPROXYPROVIDERSVC_H
# define ATHENAKERNEL_IPROXYPROVIDERSVC_H

//<<<<<< INCLUDES                                                       >>>>>>
#ifndef GAUDIKERNEL_ISERVICE_H
 #include "GaudiKernel/IService.h"
#endif
#ifndef KERNEL_STATUSCODES_H
 #include "GaudiKernel/StatusCode.h"
#endif
#ifndef GAUDIKERNEL_CLASSID_H
 #include "GaudiKernel/ClassID.h"
#endif
#ifndef _CPP_STRING
 #include <string>
#endif
#ifndef _CPP_LIST
 #include <list>
#endif
//<<<<<< FORWARD DECLARATIONS                                             >>>>>>
class IAddressProvider;
class IProxyRegistry; //this is the store

namespace SG {
  class DataProxy;
  class TransientAddress;
}

class IOpaqueAddress;

//<<<<<< CLASS DECLARATIONS                                             >>>>>>
class IProxyProviderSvc : virtual public IService {
public:
  /// add proxies to the store before Begin Event:
  virtual StatusCode preLoadProxies(IProxyRegistry& dataStore) = 0;

  ///add new proxies to store every Event:
  virtual StatusCode loadProxies(IProxyRegistry& dataStore) = 0;

  ///get the default proxy for a given CLID/Key"
  virtual SG::DataProxy* retrieveProxy(const CLID& id, 
				   const std::string& key,
				   IProxyRegistry& dataStore) = 0;

  /// Update a transient Address:
  virtual StatusCode updateAddress(SG::TransientAddress* tAD) = 0; 

  ///IAddressProvider manager functionality
  ///add a provider to the set of known ones. PROVIDER IS OWNED BY THE CLIENT
  virtual void addProvider(IAddressProvider* aProvider) = 0;

  static const InterfaceID& interfaceID();
  virtual ~IProxyProviderSvc() {}
};

//<<<<<< INLINE MEMBER FUNCTIONS                                        >>>>>>
inline
const InterfaceID&
IProxyProviderSvc::interfaceID() {
  static InterfaceID _ID("IProxyProviderSvc", 0 , 0);
  return _ID;
}

#endif // ATHENAKERNEL_IPROXYPROVIDERSVC_H
