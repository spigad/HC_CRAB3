///////////////////////// -*- C++ -*- /////////////////////////////
// DecisionSvc.cxx 
// Implementation file for class DecisionSvc
// Author: S.Binet<binet@cern.ch>
//         B.Radics<radbal@cern.ch>
/////////////////////////////////////////////////////////////////// 


#include "DecisionSvc.h"

// Gaudi include files
#include "GaudiKernel/IIncidentSvc.h"

// Athena include files
#include "AthenaPoolKernel/FileIncident.h"



DecisionSvc::DecisionSvc(const std::string& name, 
		       ISvcLocator* pSvcLocator ) : 
  AthService(name, pSvcLocator)

{
  declareProperty("AcceptAlgNames", m_acceptAlgNames);
  declareProperty("RequireAlgNames", m_requireAlgNames);
  declareProperty("VetoAlgNames", m_vetoAlgNames);
  
  ATH_MSG_DEBUG ("In DecisionSvc::DecisionSvc ");
  
  assert( pSvcLocator );

  // Allocate  m_SacceptAlgNames vector
  m_SacceptAlgNames = new std::vector<std::string>;
  // Allocate  m_SrequireAlgNames vector
  m_SrequireAlgNames = new std::vector<std::string>;
  // Allocate  m_SvetoAlgNames vector
  m_SvetoAlgNames = new std::vector<std::string>;
  // Allocate m_streamNames
  m_streamNames = new std::vector<std::string>;

  m_frozen = false;
}

DecisionSvc::~DecisionSvc()
{
  delete m_SacceptAlgNames;
  delete m_SrequireAlgNames;
  delete m_SvetoAlgNames;
  delete m_streamNames;
}

StatusCode
DecisionSvc::initialize()
{
  
  ATH_MSG_DEBUG ("In DecisionSvc::initialize ");

  StatusCode status(StatusCode::SUCCESS);

  // Decode the accept, required and veto Algorithms. 
  // The logic is the following:
  //  a. The event is accepted if all lists are empty.
  //  b. The event is provisionally accepted if any Algorithm in the 
  //     accept list
  //     has been executed and has indicated that its filter is passed. This
  //     provisional acceptance can be overridden by the other lists.
  //  c. The event is rejected unless all Algorithms in the required list have
  //     been executed and have indicated that their filter passed.
  //  d. The event is rejected if any Algorithm in the veto list has been
  //     executed and has indicated that its filter has passed.

  // Set to be listener for BeginRun

  ServiceHandle<IIncidentSvc> incSvc("IncidentSvc", this->name());
  status = incSvc.retrieve();
  if (!status.isSuccess()) {
    ATH_MSG_ERROR("Unable to get the IncidentSvc");
    return(status);
  }
  incSvc->addListener(this, "BeginRun", 100); 

  ATH_MSG_DEBUG ("End initialize ");
  
  return status;

}


StatusCode
DecisionSvc::finalize()
{
  msg(MSG::INFO) << "List of registered " << m_streamNames->size() 
		 << " Streams: ";
  for(std::vector<std::string>::const_iterator it = m_streamNames->begin(); it != m_streamNames->end(); ++it){
    msg(MSG::INFO)<< (*it) << " ";
  }
  msg(MSG::INFO)<<endreq;

  ATH_MSG_INFO ("Finalized successfully.");

  return StatusCode::SUCCESS;

}

StatusCode
DecisionSvc::interpretAlgMap()
{
  StatusCode status = StatusCode::SUCCESS;

  status = interpretAcceptAlgsProps();
  if( !status.isSuccess() ){
    ATH_MSG_FATAL ("Unable to parse AcceptAlgNames");
    return status;
  }
  
  status = interpretRequireAlgsProps();
  if( !status.isSuccess() ){
    ATH_MSG_FATAL ("Unable to parse RequireAlgNames");
    return status;
  }
  
  status = interpretVetoAlgsProps();
  if( !status.isSuccess() ){
    ATH_MSG_FATAL ("Unable to parse VetoAlgNames");
    return status;
  } 
    

  for(std::map<std::string, std::vector<std::string> >::iterator ait = m_stream_accept.begin(); ait!=m_stream_accept.end(); ++ait){
    
    status = decodeAcceptAlgs(ait->first, ait->second, &m_stream_acceptAlgs);
    if( !status.isSuccess() )   
      {
 	ATH_MSG_FATAL ("Unable to decodeAcceptAlgs.");
 	return status;
      }
  }

  for(std::map<std::string, std::vector<std::string> >::iterator ait = m_stream_require.begin(); ait!=m_stream_require.end(); ++ait){
    
    status = decodeRequireAlgs(ait->first, ait->second, &m_stream_requireAlgs);
    if( !status.isSuccess() )   
      {
	ATH_MSG_FATAL ("Unable to decodeRequireAlgs.");
	return status;
      }
  }

  for(std::map<std::string, std::vector<std::string> >::iterator ait = m_stream_veto.begin(); ait!=m_stream_veto.end(); ++ait){
    
    status = decodeVetoAlgs(ait->first, ait->second, &m_stream_vetoAlgs );
    if( !status.isSuccess() )   
      {
	ATH_MSG_FATAL ("Unable to decodeVetoAlgs.");
	return status;
      }
  }


  // Fill up m_streamNames vector

  // first take list of streams from accept streams
  for(std::map<std::string, std::vector<std::string> >::iterator iter = m_stream_accept.begin(); iter != m_stream_accept.end(); ++iter){
    m_streamNames->push_back(iter->first);
  }

  // second take list of streams from require streams, 
  // but only those that not have been added to list yet
  // first take list of streams from accept streams
  for(std::map<std::string, std::vector<std::string> >::iterator iter = m_stream_require.begin(); iter != m_stream_require.end(); ++iter){
    bool exist = false;
    for(std::vector<std::string>::iterator it = m_streamNames->begin(); it != m_streamNames->end(); ++it){
      if((*it) == iter->first){
	exist = true;
	break;
      }
    }
    if(exist == false)
      m_streamNames->push_back(iter->first);
  }


  // third take list of streams from veto streams, 
  // but only those that not have been added to list yet
  // first take list of streams from accept and require streams
  for(std::map<std::string, std::vector<std::string> >::iterator iter = m_stream_require.begin(); iter != m_stream_require.end(); ++iter){
    bool exist = false;
    for(std::vector<std::string>::iterator it = m_streamNames->begin(); it != m_streamNames->end(); ++it){
      if((*it) == iter->first){
	exist = true;
	break;
      }
    }
    if(exist == false)
      m_streamNames->push_back(iter->first);
  }

  return status;
}


/////////////////////////////////////////////////////////////////// 
// Non-const methods: 
/////////////////////////////////////////////////////////////////// 


StatusCode
DecisionSvc::interpretAcceptAlgsProps()
{
  ATH_MSG_DEBUG("In DecisionSvc::interpretAcceptAlgsProps");

  StatusCode status = StatusCode::SUCCESS;

  // this holds the interpreted streamname and algname
  std::vector<std::string> temp;

  for(std::vector<std::string>::iterator it = m_acceptAlgNames.begin(); it != m_acceptAlgNames.end(); ++it){
    temp.clear();
    status = interpretString((*it), &temp);
    if(!status.isSuccess()){
      ATH_MSG_WARNING("Interpretation of string " << (*it) << " has failed...");
    }else{
      status = addAcceptAlg(temp[1], temp[0]);
      if(!status.isSuccess()){
	ATH_MSG_WARNING("Couldn't add acceptAlg " << temp[1]
			<< " of stream " << temp[0]);
      }
    }
  }

  return status;

}


StatusCode
DecisionSvc::interpretRequireAlgsProps()
{
  ATH_MSG_DEBUG("In DecisionSvc::interpretRequireAlgsProps");

  StatusCode status = StatusCode::SUCCESS;

  // this holds the interpreted streamname and algname
  std::vector<std::string> temp;

  for(std::vector<std::string>::iterator it = m_requireAlgNames.begin(); it != m_requireAlgNames.end(); ++it){
    temp.clear();
    status = interpretString((*it), &temp);
    if(!status.isSuccess()){
      ATH_MSG_WARNING("Interpretation of string " << (*it) << " has failed...");
    }else{
      status = addRequireAlg(temp[1], temp[0]);
      if(!status.isSuccess()){
	ATH_MSG_WARNING("Couldn't add requireAlg " << temp[1] 
			<< " of stream " << temp[0]);
      }
    }
  }
  return status;

}


StatusCode
DecisionSvc::interpretVetoAlgsProps()
{
  ATH_MSG_DEBUG("In DecisionSvc::interpretVetoAlgsProps");

  StatusCode status = StatusCode::SUCCESS;

  // this holds the interpreted streamname and algname
  std::vector<std::string> temp;

  for(std::vector<std::string>::iterator it = m_vetoAlgNames.begin(); it != m_vetoAlgNames.end(); ++it){
    temp.clear();
    status = interpretString((*it), &temp);
    if(!status.isSuccess()){
      ATH_MSG_WARNING("Interpretation of string " << (*it) << " has failed...");
    }else{
      status = addVetoAlg(temp[1], temp[0]);
      if(!status.isSuccess()){
	ATH_MSG_WARNING("Couldn't add vetoAlg " << temp[1] 
			<< " of stream " << temp[0]);
      }
    }
  }
  return status;

}


StatusCode
DecisionSvc::interpretString(const std::string& input,
			     std::vector<std::string> * output)
{
  ATH_MSG_DEBUG("In DecisionSvc::interpretString");

  StatusCode status = StatusCode::SUCCESS;

  ATH_MSG_DEBUG("Input string: " << input);
  // search for the separator character '#'
  size_t found = input.find_first_of("#");
  if(found != std::string::npos){
    output->push_back(input.substr(0,found));
    output->push_back(input.substr(found+1));
    ATH_MSG_DEBUG("Interpreted as: " << (*output)[0] << "\t " << (*output)[1]);
  }else{
    ATH_MSG_ERROR("String parsing failed for input string [" << input << "]");
    return StatusCode::FAILURE;
  }

  return status;
}

StatusCode 
DecisionSvc::addStream(const std::string& stream)
{
  StatusCode status = StatusCode::SUCCESS;
  if(m_frozen != true){
    // check if this stream already exist
    std::map<std::string, std::vector<std::string> >::iterator it = m_stream_accept.find(stream);
    if(it != m_stream_accept.end()){
      // ok, it exists, then do nothing
      msg(MSG::WARNING) << "Stream name : " << stream << " already been registered!" << endreq;
      status = StatusCode::FAILURE;
    }else{
      //if the stream doesn't exist yet, then insert it to the accept list with an empty vector of Algs
      std::vector<std::string> tmpvec;
      tmpvec.clear();
      msg(MSG::INFO) << "Inserting stream: "<< stream  << " with no Algs" << endreq; 
      m_stream_accept.insert(std::make_pair(stream, tmpvec));
      status = StatusCode::SUCCESS;
    }
  }
  return status;
}


StatusCode
DecisionSvc::addAcceptAlg(const std::string& name, const std::string& stream)
{
  StatusCode status = StatusCode::SUCCESS;

  // Check if Alg exists.
  IAlgManager* theAlgMgr;
  StatusCode result = serviceLocator( )->getService
    ("ApplicationMgr",
     IID_IAlgManager,
     *pp_cast<IInterface>(&theAlgMgr));

  if ( result.isSuccess( ) ) {

    IAlgorithm* theIAlg;
     result = theAlgMgr->getAlgorithm( name, theIAlg );
    if ( result.isSuccess( ) ) {


      if(m_frozen != true){
	
	// check if this stream already exist
	std::map<std::string, std::vector<std::string> >::iterator it = m_stream_accept.find(stream);
	if(it != m_stream_accept.end()){
	  // ok, it exists, then check if the algname has already been inserted
	  
	  // save the list
	  std::vector<std::string> tmpvec = it->second;
	  
	  bool algexist = false;
	  for(std::vector<std::string>::iterator vit = (it->second).begin(); vit != (it->second).end(); ++vit){
	    if((*vit) == name){
	      algexist = true;
	      // it seems the alg was already inserted, warn the user
	      msg(MSG::WARNING) << "Alg name : " << name << " of stream " << stream << " has already been registered!" << endreq;
	    }
	  }
	  
	  
	  // So, if the stream exist but the alg has not been registered
	  // update its content std::vector with a alg
	  if(algexist == false){
	    tmpvec.push_back(name);
	    m_stream_accept.erase(stream);
	    m_stream_accept.insert(std::make_pair(stream, tmpvec));
	    msg(MSG::INFO) << "Inserting Algo " << name << " to existing stream: "<< stream  << endreq; 
	  }
	  
	  //if the stream doesn't exist yet, then insert it with the alg
	}else{
	  std::vector<std::string> tmpvec;
	  tmpvec.push_back(name);
	  m_stream_accept.insert(std::make_pair(stream, tmpvec));
	  msg(MSG::INFO) << "Inserting stream: "<< stream << " with first algorithm: " << name << endreq; 
	}    
      }else{
	msg(MSG::WARNING) << "State of DecisionSvc is " << m_frozen << " ( " << false << " - open, " << true << " - frozen )" << endreq;
	msg(MSG::WARNING) << "Adding " << name << " Alg of stream " << stream <<  "not allowed anymore!" << endreq;
      }
    } else{
      msg(MSG::WARNING) << "Algorithm " << name << " doesn't exist - ignored" << endreq;
    }
  }

  return status;
}




StatusCode
DecisionSvc::addRequireAlg(const std::string& name,
			   const std::string& stream)
{

  // Check if Alg exists.
  IAlgManager* theAlgMgr;
  StatusCode result = serviceLocator( )->getService
    ("ApplicationMgr",
     IID_IAlgManager,
     *pp_cast<IInterface>(&theAlgMgr));

  if ( result.isSuccess( ) ) {

    IAlgorithm* theIAlg;
    result = theAlgMgr->getAlgorithm( name, theIAlg );
    if ( result.isSuccess( ) ) {

      if (m_frozen != true) {
	
	// check if this stream already exist
	std::map<std::string, std::vector<std::string> >::iterator it = m_stream_require.find(stream);
	if(it != m_stream_require.end()){
	  // ok, it exists, then check if the algname was already been inserted
	  
	  // save the list
	  std::vector<std::string> tmpvec = it->second;
	  
	  bool algexist = false;
	  for(std::vector<std::string>::iterator vit = (it->second).begin(); vit != (it->second).end(); ++vit){
	    if((*vit) == name){
	      algexist = true;
	      // it seems the alg was already inserted, warn the user
	      msg(MSG::ERROR) << "Alg name : " << name << " of stream " << stream << " has already been registered!" << endreq;
	      return StatusCode::FAILURE;
	    }
	  }
	  
	  
	  // So, if the stream exist but the alg has not been registered
	  // update its content std::vector with a alg
	  if(algexist == false){
	    tmpvec.push_back(name);
	    m_stream_require.erase(stream);
	    m_stream_require.insert(std::make_pair(stream, tmpvec));
	  }
	  
	  //if the stream doesn't exist yet, then insert it
	}else{
	  std::vector<std::string> tmpvec;
	  tmpvec.push_back(name);
	  m_stream_require.insert(std::make_pair(stream, tmpvec));
	}    
      }else{
	
	msg(MSG::WARNING) << "State of DecisionSvc is " << m_frozen << " ( " << false << " - open, " << true << " - frozen )" << endreq;
	msg(MSG::WARNING) << "Adding Algs not allowed anymore!"<< endreq;
      }
    } else{
      msg(MSG::WARNING) << "Algorithm " << name << " doesn't exist - ignored" << endreq;
    }
  }

  return StatusCode::SUCCESS;


}


StatusCode 
DecisionSvc::addVetoAlg(const std::string& name,
			const std::string& stream)
{
  // Check if Alg exists.
  IAlgManager* theAlgMgr;
  StatusCode result = serviceLocator( )->getService
    ("ApplicationMgr",
     IID_IAlgManager,
     *pp_cast<IInterface>(&theAlgMgr));

  if ( result.isSuccess( ) ) {

    IAlgorithm* theIAlg;
    result = theAlgMgr->getAlgorithm( name, theIAlg );
    if ( result.isSuccess( ) ) {
      
      if(m_frozen != true){
	// check if this stream already exist
	std::map<std::string, std::vector<std::string> >::iterator it = m_stream_veto.find(stream);
	if(it != m_stream_veto.end()){
	  // ok, it exists, then check if the algname was already been inserted
	  
	  // save the list
	  std::vector<std::string> tmpvec = it->second;
	  
	  bool algexist = false;
	  for(std::vector<std::string>::iterator vit = (it->second).begin(); vit != (it->second).end(); ++vit){
	    if((*vit) == name){
	      algexist = true;
	      // it seems the alg was already inserted, warn the user
	      msg(MSG::ERROR) << "Alg name : " << name << " of stream " << stream << " has already been registered!" << endreq;
	      return StatusCode::FAILURE;
	    }
	  }
	  
	  
	  // So, if the stream exist but the alg has not been registered
	  // update its content std::vector with a alg
	  if(algexist == false){
	    tmpvec.push_back(name);
	    m_stream_veto.erase(stream);
	    m_stream_veto.insert(std::make_pair(stream, tmpvec));
	  }
	  
	  //if the stream doesn't exist yet, then insert it
	}else{
	  std::vector<std::string> tmpvec;
	  tmpvec.push_back(name);
	  m_stream_veto.insert(std::make_pair(stream, tmpvec));
	}    
      }else{
	msg(MSG::WARNING) << "State of DecisionSvc is " << m_frozen << " ( " << false << " - open, " << true << " - frozen )" << endreq;
	msg(MSG::WARNING) << "Adding Algs not allowed anymore!" << endreq;
      }
    }else{
      msg(MSG::WARNING) << "Algorithm " << name << " doesn't exist - ignored" << endreq;
    }
  }
  return StatusCode::SUCCESS;

}




StatusCode
DecisionSvc::decodeAcceptAlgs(const std::string& stream, 
			      const std::vector<std::string>& acceptNames, 
			      std::map<std::string, std::vector<Algorithm*>*> * theAlgMap )
{
  msg(MSG::DEBUG) << "In DecisionSvc::decodeAcceptAlgs " << endreq ;
  StatusCode result = decodeAlgorithms( stream, acceptNames, theAlgMap );

  if (acceptNames.size()) {
    msg(MSG::DEBUG) << "Found AcceptNames: " ;
    std::vector<std::string>::const_iterator first = acceptNames.begin();
    std::vector<std::string>::const_iterator last  = acceptNames.end();
    for (; first != last; ++first) {
      msg(MSG::DEBUG) << (*first);
    }
    msg(MSG::DEBUG) << endreq;
  }
  else {
    ATH_MSG_DEBUG ("No AcceptNames found ");
  }


  std::map<std::string, std::vector<Algorithm*>* >::const_iterator itAlgs = theAlgMap->find(stream);
  if(itAlgs != theAlgMap->end()){
    // get a handle of the streams' algos vector
    std::vector<Algorithm*> * acceptAlgs = itAlgs->second;  

    if (acceptAlgs->size()) {
      msg(MSG::DEBUG) << "Found AcceptAlgs: " ;
      std::vector<Algorithm*>::const_iterator first = acceptAlgs->begin();
      std::vector<Algorithm*>::const_iterator last  = acceptAlgs->end();
      for (; first != last; ++first) {
	msg(MSG::DEBUG) << (*first)->name();
      }
      msg(MSG::DEBUG) << endreq;
    }else {
      msg(MSG::DEBUG) << "No acceptalgs list found for stream " << stream << endreq;
    }
  }else{
      msg(MSG::DEBUG) << "No stream found as " << stream << endreq;
  }

  return result;
}

StatusCode
DecisionSvc::decodeRequireAlgs(const std::string& stream,
			       const std::vector<std::string>& requireNames, 
			       std::map<std::string, std::vector<Algorithm*>*> * theAlgMap )
{
  StatusCode result = decodeAlgorithms( stream, requireNames, theAlgMap);

  if (requireNames.size()) {
    if ( msgLvl(MSG::DEBUG) ) {
      msg(MSG::DEBUG) << "Found RequireNames: " ;
      std::vector<std::string>::const_iterator first = requireNames.begin();
      std::vector<std::string>::const_iterator last  = requireNames.end();
      for (; first != last; ++first) {
	msg(MSG::DEBUG) << (*first);
      }
      msg(MSG::DEBUG) << endreq;
    }
  }
  else {
    ATH_MSG_DEBUG ("No RequireNames found ");
  }


  std::map<std::string, std::vector<Algorithm*>* >::const_iterator itAlgs = theAlgMap->find(stream);
  if(itAlgs != theAlgMap->end()){
    // get a handle of the streams' algos vector
    std::vector<Algorithm*> * requireAlgs = itAlgs->second;  

    if (requireAlgs->size()) {
      msg(MSG::DEBUG) << "Found RequireAlgs: " ;
      std::vector<Algorithm*>::const_iterator first = requireAlgs->begin();
      std::vector<Algorithm*>::const_iterator last  = requireAlgs->end();
      for (; first != last; ++first) {
	msg(MSG::DEBUG) << (*first)->name();
      }
      msg(MSG::DEBUG) << endreq;
    }else {
      msg(MSG::DEBUG) << "No requirealgs list found for stream " << stream << endreq;
    }
  }else{
      msg(MSG::DEBUG) << "No stream found as " << stream << endreq;
  }

  return result;
}

StatusCode
DecisionSvc::decodeVetoAlgs(const std::string& stream, 
			    const std::vector<std::string>& vetoNames,
			    std::map<std::string, std::vector<Algorithm*>*> * theAlgMap )
{
  StatusCode result = decodeAlgorithms( stream, vetoNames, theAlgMap );

  if (vetoNames.size()) {
    if ( msgLvl(MSG::DEBUG) ) {
      msg(MSG::DEBUG) << "Found VetoNames: " ;
      std::vector<std::string>::const_iterator first = vetoNames.begin();
      std::vector<std::string>::const_iterator last  = vetoNames.end();
      for (; first != last; ++first) {
	msg(MSG::DEBUG) << (*first);
      }
      msg(MSG::DEBUG) << endreq;
    }
  } else {
    ATH_MSG_DEBUG ("No VetoNames found ");
  }



  std::map<std::string, std::vector<Algorithm*>* >::const_iterator itAlgs = theAlgMap->find(stream);
  if(itAlgs != theAlgMap->end()){
    // get a handle of the streams' algos vector
    std::vector<Algorithm*> * vetoAlgs = itAlgs->second;  

    if (vetoAlgs->size()) {
      msg(MSG::DEBUG) << "Found VetoAlgs: " ;
      std::vector<Algorithm*>::const_iterator first = vetoAlgs->begin();
      std::vector<Algorithm*>::const_iterator last  = vetoAlgs->end();
      for (; first != last; ++first) {
	msg(MSG::DEBUG) << (*first)->name();
      }
      msg(MSG::DEBUG) << endreq;
    }else {
      msg(MSG::DEBUG) << "No vetoalgs list found for stream " << stream << endreq;
    }
  }else{
      msg(MSG::DEBUG) << "No stream found as " << stream << endreq;
  }


  return result;
}


// Given a list of names, it checks for the Algorithm objects in the memory from AlgMgr,
// and copy the pointers of Algorithm objects to the streamname -- Algorithm map
StatusCode
DecisionSvc::decodeAlgorithms(const std::string& stream, 
			      const std::vector<std::string>& theNames, 
			      std::map<std::string, std::vector<Algorithm*>*> * theAlgMap )
{
  msg(MSG::DEBUG) << "In DecisionSvc::decodeAlgorithms " << endreq ;
  // Reset the list of Algorithms
  //  theAlgs->clear( );
  std::vector<Algorithm*>* tempAlgs = new std::vector<Algorithm*>;

  IAlgManager* theAlgMgr;
  StatusCode result = serviceLocator( )->getService
    ("ApplicationMgr",
     IID_IAlgManager,
     *pp_cast<IInterface>(&theAlgMgr));

  if ( result.isSuccess( ) ) {

    // Build the list of Algorithms from the names list
    const std::vector<std::string>& nameList = theNames;
    std::vector<std::string>::const_iterator it;
    std::vector<std::string>::const_iterator itend = nameList.end( );
    for (it = nameList.begin(); it != itend; it++) {

      // Check whether the supplied name corresponds to an existing
      // Algorithm object.
      const std::string& theName = (*it);
      IAlgorithm* theIAlg;
      Algorithm*  theAlgorithm;
      result = theAlgMgr->getAlgorithm( theName, theIAlg );
      if ( result.isSuccess( ) ) {
	theAlgorithm = dynamic_cast<Algorithm*>(theIAlg);
	if (0==theAlgorithm) {
	  result = StatusCode::FAILURE;
	}
      }
      if ( result.isSuccess( ) ) {

        // Check that the specified algorithm doesn't already exist in the list
        std::vector<Algorithm*>::iterator ita;
	//        std::vector<Algorithm*>::iterator itaend = theAlgs->end( );
        std::vector<Algorithm*>::iterator itaend = tempAlgs->end( );
	//       for (ita = theAlgs->begin(); ita != itaend; ita++) {
       for (ita = tempAlgs->begin(); ita != itaend; ita++) {
          Algorithm* existAlgorithm = (*ita);
          if ( theAlgorithm == existAlgorithm ) {
            result = StatusCode::FAILURE;
            break;
          }
        }
        if ( result.isSuccess( ) ) {
	  //          theAlgs->push_back( theAlgorithm );
          tempAlgs->push_back( theAlgorithm );
        }
      } else {
        ATH_MSG_FATAL (theName << " doesn't exist -- trying to get pointer to a non-existing Algorithm! Stop the job!");
	result = StatusCode::FAILURE;
	return result;
      }
    }
    
    theAlgMap->insert(std::make_pair(stream, tempAlgs));
    
    result = StatusCode::SUCCESS;
  } else {
    ATH_MSG_FATAL ("Can't locate ApplicationMgr!!!");
  }

  return result;
}

std::vector<std::string> * 
DecisionSvc::getStreams()
{
  return m_streamNames;
}

std::vector<std::string> * 
DecisionSvc::getAcceptAlgs(const std::string& stream) 
{ 
  m_SacceptAlgNames->clear();

  if(m_frozen == true){
    //Loop over all streams of accept type and find the one of interest
    std::map<std::string, std::vector<Algorithm*>* >::const_iterator itAlgs = m_stream_acceptAlgs.find(stream);
    if(itAlgs != m_stream_acceptAlgs.end()){
      // get a handle of the streams' *existing* algos vector
      std::vector<Algorithm*> * vecAlgs = itAlgs->second;
      if ( ! vecAlgs->empty( ) ) {
	std::vector<Algorithm*>::iterator it;
	std::vector<Algorithm*>::iterator itend = vecAlgs->end( );
	for (it = vecAlgs->begin(); it != itend; it++) {
	  m_SacceptAlgNames->push_back((*it)->name());
	}
      }else{
	ATH_MSG_WARNING ("No proper AcceptAlgs got registered to DecisionSvc");
      }
    }
  }else{
    ATH_MSG_WARNING ("Sorry, your call is illegal, DecisionSvc not in frozen state yet, please call after BeginRun");
  }

  return m_SacceptAlgNames; 

}

std::vector<std::string> * 
DecisionSvc::getRequireAlgs(const std::string& stream) 
{ 
  m_SrequireAlgNames->clear();


  if(m_frozen == true){
    //Loop over all streams of accept type and find the one of interest
    std::map<std::string, std::vector<Algorithm*>* >::const_iterator itAlgs = m_stream_requireAlgs.find(stream);
    if(itAlgs != m_stream_requireAlgs.end()){
      // get a handle of the streams' *existing* algos vector
      std::vector<Algorithm*> * vecAlgs = itAlgs->second;
      if ( ! vecAlgs->empty( ) ) {
	std::vector<Algorithm*>::iterator it;
	std::vector<Algorithm*>::iterator itend = vecAlgs->end( );
	for (it = vecAlgs->begin(); it != itend; it++) {
	  m_SrequireAlgNames->push_back((*it)->name());
	}
      }else{
	ATH_MSG_WARNING ("No proper RequireAlgs got registered to DecisionSvc");
      }
    }
  }else{
    ATH_MSG_WARNING ("Sorry, your call is illegal, DecisionSvc not in frozen state yet, please call after BeginRun");
  }

  return m_SrequireAlgNames; 
}

std::vector<std::string> * 
DecisionSvc::getVetoAlgs(const std::string& stream) 
{ 
  m_SvetoAlgNames->clear();

  if(m_frozen == true){
    //Loop over all streams of accept type and find the one of interest
    std::map<std::string, std::vector<Algorithm*>* >::const_iterator itAlgs = m_stream_vetoAlgs.find(stream);
    if(itAlgs != m_stream_vetoAlgs.end()){
      // get a handle of the streams' *existing* algos vector
      std::vector<Algorithm*> * vecAlgs = itAlgs->second;
      if ( ! vecAlgs->empty( ) ) {
	std::vector<Algorithm*>::iterator it;
	std::vector<Algorithm*>::iterator itend = vecAlgs->end( );
	for (it = vecAlgs->begin(); it != itend; it++) {
	  m_SvetoAlgNames->push_back((*it)->name());
	}
      }else{
	ATH_MSG_WARNING ("No proper VetoAlgs got registered to DecisionSvc");
      }
    }
  }else{
    ATH_MSG_WARNING ("Sorry, your call is illegal, DecisionSvc not in frozen state yet, please call after BeginRun");
  }

  return m_SvetoAlgNames; 
}



/////////////////////////////////////////////////////////////////// 
// Const methods: 
///////////////////////////////////////////////////////////////////


bool
DecisionSvc::isEventAccepted( const std::string& stream ) const
{

  ATH_MSG_DEBUG("In DecisionSvc::isEventAccepted( " << stream << " )");

  // By construction a stream is accepted
  bool result = true;

  bool found_accept = false;
  bool found_require = false;
  bool found_veto = false;

   //Loop over all streams of accept type and find the one of interest
  std::map<std::string, std::vector<Algorithm*>* >::const_iterator itAlgs = m_stream_acceptAlgs.find(stream);
  if(itAlgs != m_stream_acceptAlgs.end()){
    found_accept = true;
    // get a handle of the streams' algos vector
    std::vector<Algorithm*> * vecAlgs = itAlgs->second;
    // Loop over all Algorithms in the list to see
    // whether any have been executed and have their filter
    // passed flag set. Any match causes the event to be
    // provisionally accepted.
    if ( ! vecAlgs->empty( ) ) {
      result = false;
      std::vector<Algorithm*>::iterator it;
      std::vector<Algorithm*>::iterator itend = vecAlgs->end( );
      for (it = vecAlgs->begin(); it != itend; it++) {
	Algorithm* theAlgorithm = (*it);
	// little cross check__________________
	msg(MSG::DEBUG) << "Algorithm " << theAlgorithm->name()
			<< "got Executed? ";
	if(theAlgorithm->isExecuted() == true) {
	  msg(MSG::DEBUG) << " Yes!" << endreq;
	} else {
	  msg(MSG::DEBUG) << " No!" << endreq;
	}
	// ______________________
	if ( theAlgorithm->isExecuted( ) && theAlgorithm->filterPassed( ) ) {
	  result = true;
	  break;
	}
      }
    }
  }

   //Loop over all streams of require type and find the one of interest
  itAlgs = m_stream_requireAlgs.find(stream);
  if(itAlgs != m_stream_requireAlgs.end()){
    found_require = true;
    // get a handle of the streams' algos vector
    std::vector<Algorithm*> * vecAlgs = itAlgs->second;
   // Loop over all Algorithms in the required list to see
   // whether all have been executed and have their filter
   // passed flag set. Any mismatch causes the event to be
   // rejected.
    if ( result && ! vecAlgs->empty( ) ) {
     std::vector<Algorithm*>::iterator it;
     std::vector<Algorithm*>::iterator itend = vecAlgs->end( );
     for (it = vecAlgs->begin(); it != itend; it++) {
       Algorithm* theAlgorithm = (*it);
	// little cross check__________________
       msg(MSG::DEBUG) << "Algorithm " << theAlgorithm->name() 
		       << "got Executed? ";
       if(theAlgorithm->isExecuted() == true) {
	 msg(MSG::DEBUG) << " Yes!" << endreq;
       } else {
	 msg(MSG::DEBUG) << " No!" << endreq;
       }
	// ______________________
       if ( ! theAlgorithm->isExecuted( ) || ! theAlgorithm->filterPassed( ) ) {
         result = false;
         break;
       }
     }
    }
  }

   //Loop over all streams of veto type and find the one of interest
  itAlgs = m_stream_vetoAlgs.find(stream);
  if(itAlgs != m_stream_vetoAlgs.end()){
    found_veto = true;
    // get a handle of the streams' algos vector
    std::vector<Algorithm*> * vecAlgs = itAlgs->second;
    // Loop over all Algorithms in the veto list to see
    // whether any have been executed and have their filter
    // passed flag set. Any match causes the event to be
    // rejected.
    if ( result && ! vecAlgs->empty( ) ) {
      std::vector<Algorithm*>::iterator it;
      std::vector<Algorithm*>::iterator itend = vecAlgs->end( );
      for (it = vecAlgs->begin(); it != itend; it++) {
	Algorithm* theAlgorithm = (*it);
	// little cross check__________________
	msg(MSG::DEBUG) << "Algorithm " << theAlgorithm->name()
			<< "got Executed? ";
	if(theAlgorithm->isExecuted() == true) {
	  msg(MSG::DEBUG) << " Yes!" << endreq;
	} else {
	  msg(MSG::DEBUG) << " No!" << endreq;
	}
	// ______________________
	if ( theAlgorithm->isExecuted( ) && theAlgorithm->filterPassed( ) ) {
         result = false;
         break;
	}
      }
    }
  }

  if(found_accept == false && found_require == false && found_veto == false){
    ATH_MSG_WARNING("Stream: " << stream << " not found registered in DecisionSvc -- accepting event by default ");
  }


  return result;
}

//__________________________________________________________________________
void 
DecisionSvc::handle(const Incident& inc) 
{
  const FileIncident* fileInc  = dynamic_cast<const FileIncident*>(&inc);
  std::string fileName;
  bool isPayl=false;
  if (fileInc == 0) { 
    fileName = "Undefined "; 
  } else { 
    fileName = fileInc->fileName(); isPayl=fileInc->isPayload();
  }
  
  ATH_MSG_DEBUG("handle() " << inc.type()
		<< " for file: " << fileName 
		<< " and payload: " << isPayl);

  // this incident serves the same purpose as BeginRun
  if (inc.type() == "BeginRun") {
    ATH_MSG_INFO("BeginRun is fired!");
    this->interpretAlgMap();
    m_frozen = true;
  }


}



StatusCode
DecisionSvc::queryInterface( const InterfaceID& riid, void** ppvi )
{
  // valid placeholder? 
  if ( 0 == ppvi ) { return StatusCode::FAILURE ; }  // RETURN 
  if ( IDecisionSvc::interfaceID() == riid ) 
    {
      *ppvi = static_cast<IDecisionSvc*>(this);
      addRef(); // NB! : inrement the reference count!
      return StatusCode::SUCCESS;                     // RETURN
    }
  // Interface is not directly availible: try out a base class
  return Service::queryInterface( riid, ppvi );
}

// Singleton accessor function
//DecisionSvc *DecisionSvc::instance(const std::string& name, 
//		       ISvcLocator* pSvcLocator ){
//  if (!inst)
//     // Do "lazy initialization" in the accessor function
//     inst = new DecisionSvc(name, pSvcLocator);
//   return inst;
// }
