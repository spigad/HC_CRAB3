#include "GaudiKernel/DeclareFactoryEntries.h"

#include "../AthenaEventLoopMgr.h"
#include "../PyAthenaEventLoopMgr.h"
#include "../AthenaOutputStream.h"
#include "../AthenaOutputStreamTool.h"
#include "../AthenaConditionStream.h"
#include "../AtRndmGenSvc.h"
#include "../AtRanluxGenSvc.h"
#include "../MultipleEventLoopMgr.h"
#include "../SimplePOSIXTimeKeeperSvc.h"
#include "../MixingEventSelector.h"
#include "../ThinningSvc.h"
#include "../ThinningOutputTool.h"
//#include "../EventDumperSvc.h"
#include "../MemoryRescueSvc.h"
#include "../FPEControlSvc.h"
#include "../JobIDSvc.h"
#include "../UserDataSvc.h"
#include "../CoreDumpSvc.h"
#include "../AthDictLoaderSvc.h"
#include "../AthenaSealSvc.h"
#include "../PageAccessControlSvc.h"
#include "../DecisionSvc.h"

DECLARE_FACTORY_ENTRIES(AthenaServices) {
    DECLARE_ALGORITHM( AthenaOutputStream )
    DECLARE_ALGORITHM( AthenaConditionStream )
    DECLARE_SERVICE( AtRndmGenSvc )
    DECLARE_SERVICE( AtRanluxGenSvc )
    DECLARE_SERVICE( AthenaEventLoopMgr )
    DECLARE_SERVICE( MultipleEventLoopMgr )
    DECLARE_SERVICE( PyAthenaEventLoopMgr )
    DECLARE_SERVICE( SimplePOSIXTimeKeeperSvc )
    DECLARE_SERVICE( MixingEventSelector )
    DECLARE_SERVICE( ThinningSvc )
//       DECLARE_SERVICE( EventDumperSvc )
    DECLARE_SERVICE( MemoryRescueSvc )
    DECLARE_SERVICE( FPEControlSvc )
    DECLARE_SERVICE( JobIDSvc )
    DECLARE_SERVICE( UserDataSvc )
    DECLARE_SERVICE( CoreDumpSvc )
    DECLARE_SERVICE( PageAccessControlSvc )
    DECLARE_SERVICE( AthDictLoaderSvc )
    DECLARE_SERVICE( AthenaSealSvc )
    DECLARE_SERVICE( DecisionSvc )
    DECLARE_TOOL( AthenaOutputStreamTool )
    DECLARE_TOOL( ThinningOutputTool )
}
DECLARE_ALGORITHM_FACTORY( AthenaOutputStream )
DECLARE_ALGORITHM_FACTORY( AthenaConditionStream )
DECLARE_SERVICE_FACTORY( AtRndmGenSvc )
DECLARE_SERVICE_FACTORY( AtRanluxGenSvc )
DECLARE_SERVICE_FACTORY( AthenaEventLoopMgr )
DECLARE_SERVICE_FACTORY( MultipleEventLoopMgr )
DECLARE_SERVICE_FACTORY( PyAthenaEventLoopMgr )
DECLARE_SERVICE_FACTORY( SimplePOSIXTimeKeeperSvc )
DECLARE_SERVICE_FACTORY( MixingEventSelector )
DECLARE_SERVICE_FACTORY( ThinningSvc )
//DECLARE_SERVICE_FACTORY( EventDumperSvc )
DECLARE_SERVICE_FACTORY( MemoryRescueSvc )
DECLARE_SERVICE_FACTORY( FPEControlSvc )
DECLARE_SERVICE_FACTORY( JobIDSvc )
DECLARE_SERVICE_FACTORY( UserDataSvc )
DECLARE_SERVICE_FACTORY( CoreDumpSvc )
DECLARE_SERVICE_FACTORY( PageAccessControlSvc )
DECLARE_SERVICE_FACTORY( AthDictLoaderSvc )
DECLARE_SERVICE_FACTORY( AthenaSealSvc )
DECLARE_SERVICE_FACTORY( DecisionSvc )
DECLARE_TOOL_FACTORY( AthenaOutputStreamTool )
DECLARE_TOOL_FACTORY( ThinningOutputTool )
