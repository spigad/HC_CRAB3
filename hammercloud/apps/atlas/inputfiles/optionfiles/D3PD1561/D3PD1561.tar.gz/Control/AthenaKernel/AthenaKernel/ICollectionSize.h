// This file's extension implies that it's C, but it's really -*- C++ -*-.
// $Id: ICollectionSize.h,v 1.1 2005-05-05 00:15:02 calaf Exp $
/**
 * @file  ICollectionSize.h
 * @author scott snyder <snyder@bnl.gov>
 * @date May, 2005
 * @brief Abstract interface for finding the size of an event collection.
 */

#ifndef ATHENAKERNEL_ICOLLECTIONSIZE_H
#define ATHENAKERNEL_ICOLLECTIONSIZE_H


/**
 * @class ICollectionSize
 * @brief Abstract interface for finding the size of an event collection.
 */
class ICollectionSize
{
public:
  /**
   * @brief Destructor.
   */
  virtual ~ICollectionSize () {};


  /**
   * @brief Return the size of the collection.
   */
  virtual int size () = 0;
};


#endif // not ATHENAKERNEL_ICOLLECTIONSIZE_H
