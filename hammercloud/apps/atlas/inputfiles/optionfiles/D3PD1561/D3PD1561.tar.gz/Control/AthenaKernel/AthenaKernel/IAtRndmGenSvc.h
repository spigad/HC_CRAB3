/** @class IAtRndmGenSvc
  * @brief manage multiple CLHEP random engines as named streams
  * 
  * @author Giorgos Stavropoulos <George.Stavropoulos@cern.ch> 
  * @author Paolo Calafiura <pcalafiura@lbl.gov> 
  * $Id: IAtRndmGenSvc.h,v 1.9 2007-02-08 17:48:38 binet Exp $
  */

#ifndef ATHENAKERNEL_IATRNDMGENSVC_H
# define ATHENAKERNEL_IATRNDMGENSVC_H

//<<<<<< INCLUDES                                                       >>>>>>
#ifndef GAUDIKERNEL_ISERVICE_H
 #include "GaudiKernel/IService.h"
#endif
#ifndef _CPP_STRING
 #include <string>
#endif
#ifndef HepRandomEngine_h
 #include "CLHEP/Random/RandomEngine.h"
#endif

//<<<<<< FORWARD DECLARATIONS                                           >>>>>>

//<<<<<< CLASS DECLARATIONS                                             >>>>>>
class IAtRndmGenSvc : virtual public IService {
public:
  /// Interface to the CLHEP engine
  //@{
  virtual CLHEP::HepRandomEngine* GetEngine(const std::string& StreamName)=0;
  virtual void CreateStream(long seed1, long seed2, 
			    const std::string& StreamName)=0;
  ///set the seeds for an engine. First param will usually be the event number
  virtual CLHEP::HepRandomEngine* setOnDefinedSeeds(int EventNumber, 
	 				            const std::string& StreamName)=0;
  ///set the seeds for an engine. Second param will usually be the run number
  virtual CLHEP::HepRandomEngine* setOnDefinedSeeds(int eventNumber,
						    int runNumber,
	 				            const std::string& StreamName)=0;
  //@}
  
  /// Print methods
  //@{
  virtual void print(const std::string& StreamName)=0;
  virtual void print()=0;
  //@}

  /// Gaudi boilerplate
  static const InterfaceID& interfaceID();
  
  virtual ~IAtRndmGenSvc() {}
};
inline
const InterfaceID& 
IAtRndmGenSvc::interfaceID() {
  static const InterfaceID _IID("IAtRndmGenSvc", 1, 0);
  return _IID;
}

#endif // ATHENAKERNEL_IATRNDMGENSVC_H
