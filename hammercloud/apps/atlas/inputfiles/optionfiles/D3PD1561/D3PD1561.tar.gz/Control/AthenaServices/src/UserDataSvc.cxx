//$Id: UserDataSvc.cxx,v 1.17 2008/07/07 05:44:46 yyao Exp $

#include <cassert>
#include <memory>
#include <string>
#include <sstream>
#include <cxxabi.h>

#include "TROOT.h"
#include "TError.h"
#include "TClass.h"
#include "TString.h"

#include "GaudiKernel/System.h"
#include "GaudiKernel/MsgStream.h"
#include "GaudiKernel/IIncidentSvc.h"
#include "GaudiKernel/IAlgManager.h"
#include "GaudiKernel/ISvcLocator.h"

#include "AthenaPoolKernel/FileIncident.h"

#include "EventInfo/EventInfo.h"
#include "EventInfo/EventID.h"

#include "StoreGate/StoreGateSvc.h"

#include "UserDataSvc.h"
#include "AthenaOutputStream.h"

using namespace std;

using namespace Athena;

UserDataSvc::UserDataSvc(const std::string& name, ISvcLocator* svc) :
  Service(name, svc), m_currRunNumber(0), m_currEventNumber(0),
      m_associationtree(0), m_userdatatree(0), m_fileleveluserdatatree(0),
      m_r_inputfilecounter(0), m_r_synchronized(false),
      m_el_curevent_begin(-1), m_el_curevent_end(-1), m_r_el_evt_init(false),
      m_r_el_tree(0), m_r_el_tree_abc(0), m_r_el_tree_label(0),
      m_r_el_tree_blob(0), m_r_el_tree_type(0), m_activeStoreSvc(
          "ActiveStoreSvc", name), m_thistsvc("THistSvc", name),
      m_propTHistSvc(0), m_infirstevent(true), m_doRead(false),
  m_doWrite(false), m_doWriteTransient(true),
  m_log(msgSvc(), name), m_dictLoaderSvc(
          "AthDictLoaderSvc", name) {

  declareProperty("InputFileCollection", m_inputfilecoll,
      "List of name of the input files to read userdata from");
  declareProperty("OutputFileName", m_outputfilename = "none",
      "Name of the output file to write userdata to");
  declareProperty("OutputStream", m_outputstreamname = "none",
      "Name of the output file to write userdata to");
  declareProperty("InputFileStreamName", m_inputfilestream,
      "List of stream names corresponding to input files. set automatically.");
  declareProperty("WriteTransient", m_doWriteTransient = true,
                  "Allow writing to transient UserData store.");

  m_outputstreamname.declareUpdateHandler(&UserDataSvc::outputstreamHandler,
      this);

}

void
UserDataSvc::outputstreamHandler(Property& /* theProp */) {

  ServiceHandle<IAlgManager> theAlgMgr("ApplicationMgr", name());
  StatusCode sc = theAlgMgr.retrieve();

  if (sc.isSuccess()) {
    m_log << MSG::DEBUG << "Got Alg Mgr " << theAlgMgr << endreq;
  } else {
    m_log << MSG::FATAL << "Can't Get Alg Mgr " << theAlgMgr << endreq;
    throw GaudiException("Unable to get Algorithm Mgr", name(), sc);
  }

  StatusCode result;
  IAlgorithm* theIAlg;
  AthenaOutputStream* theAlgorithm;
  result = theAlgMgr->getAlgorithm(m_outputstreamname.value(), theIAlg);
  if (result.isSuccess()) {
    m_log << MSG::DEBUG << "Got theIAlg " << theIAlg << endreq;
    
    try {
      theAlgorithm = dynamic_cast<AthenaOutputStream*> (theIAlg);
    } catch (...) {
      //      result = StatusCode::FAILURE;
    }
    m_log << MSG::DEBUG << "Got AthenaOutputStream " << theAlgorithm->name()
	  << endreq;
    m_outputStream = theAlgorithm;
  } else {
    m_log << MSG::FATAL << "Unable to decode AcceptAlgs list" << endreq;
    throw GaudiException("Unable to decode AcceptAlgs list", name(), result);
  }
}

StatusCode
UserDataSvc::queryInterface(const InterfaceID& riid, void** ppvInterface) {
  if (IUserDataSvc::interfaceID().versionMatch(riid)) {
    *ppvInterface = (IUserDataSvc*) this;
  }
  else {
    // Interface is not directly available: try out a base class
    return Service::queryInterface(riid, ppvInterface);
  }
  addRef();
  return StatusCode::SUCCESS;
}

StatusCode
UserDataSvc::initialize() {

  m_log << MSG::INFO << "Initializing " << name() << " - package version "
      << PACKAGE_VERSION << endreq;

  if (!(Service::initialize()).isSuccess()) {
    m_log << MSG::FATAL << "Failed to initialize base Service class !"
        << endreq;
    return StatusCode::FAILURE;
  }

  StatusCode sc = m_thistsvc.retrieve();
  if (!sc.isSuccess()) {
    m_log << MSG::FATAL << "Could not find THistSvc" << endreq;
    return StatusCode::FAILURE;
  }

  sc = Service::service("THistSvc", m_propTHistSvc, false);
  if (!sc.isSuccess()) {
    m_log << MSG::DEBUG
        << "Could not retrieve IProperty Interface to 'THistSvc' " << sc
        << endreq;
    return StatusCode::FAILURE;
  }

  ServiceHandle<IIncidentSvc> incSvc("IncidentSvc", this->name());
  sc = incSvc.retrieve();
  if (!sc.isSuccess()) {
    m_log << MSG::FATAL << "Unable to get the IncidentSvc" << endreq;
    return StatusCode::FAILURE;
  }
  incSvc->addListener(this, "BeginRun");
  incSvc->addListener(this, "EndRun");
  incSvc->addListener(this, "BeginEvent");
  incSvc->addListener(this, "EndEvent");
  incSvc->addListener(this, "BeginInputFile");
  incSvc->addListener(this, "EndInputFile");
  incSvc->addListener(this, "BeginTagFile");
  incSvc->addListener(this, "EndTagFile");
  incSvc.release().ignore();

  if (!m_dictLoaderSvc.retrieve().isSuccess()) {
    m_log << MSG::ERROR << "could not retrieve athena dict. loader service !"
        << endreq;
    return StatusCode::FAILURE;
  }

  m_doRead = true;

  m_log << MSG::DEBUG << "Doing Write = " << m_outputstreamname.value()
      << endreq;

  if (m_outputstreamname.value() != "none") {

    m_log << MSG::DEBUG << "Doing Write = " << m_outputStream->m_outputName
        << endreq;
    m_doWrite = true;
    m_doWriteTransient = true;
  }

  if (m_doWriteTransient) {
    //Create new TTree.
    m_userdatatree = new TTree("UserDataTree",
        "TTree containing all Event/Collection level user data");
    m_fileleveluserdatatree = new TTree("FileLevelUserDataTree",
        "TTree containing all file level user data");
    if (m_doWrite) {
      //Reg the tree with THistSvc
      if (!(m_thistsvc->regTree(std::string("/userdataoutputstream_")+name()+"/UserDataTree",
                                m_userdatatree)).isSuccess()) {
        m_log << MSG::FATAL << "Could not register UserDataTree " << endreq;
        return StatusCode::FAILURE;
      }

      //Reg the tree with THistSvc
      if (!(m_thistsvc->regTree(std::string("/userdataoutputstream_")+name()+"/FileLevelUserDataTree",
                                m_fileleveluserdatatree)).isSuccess()) {
        m_log << MSG::FATAL << "Could not register FileLevelUserDataTree "
              << endreq;
        return StatusCode::FAILURE;
      }
    }

    m_el_tree = new TTree("ElementLevelUserDataTree",
        "ElementLevelUserDataTree");
    //In the tree
    //Event Number/Run Number/AthenaBarCode/Label/blob/typeString

    //the m_el_tree_xxx are needed for branching the tree, they will be replaced by other
    //vars when filling the tree.
 //   m_el_tree->Branch("RunNumber", &m_currRunNumber, "RunNumber/i");
 //   m_el_tree->Branch("EventNumber", &m_currEventNumber, "EventNumber/i");
    m_el_tree->Branch("AthenaBarCode", &m_el_tree_abc, "AthenaBarCode/l");
    m_el_tree->Branch("Label", &m_el_tree_label);
    m_el_tree->Branch("Blob", &m_el_tree_blob);
    m_el_tree->Branch("Type", &m_el_tree_type);

    if (m_doWrite) {
      //Reg the tree with THistSvc
      if (!(m_thistsvc->regTree(std::string("/userdataoutputstream_")+name()+"/ElementLevelUserDataTree",
                                m_el_tree)).isSuccess()) {
        m_log << MSG::FATAL << "Could not register FileLevelUserDataTree "
              << endreq;
        return StatusCode::FAILURE;
      }
    }

  }

  if (m_doWriteTransient || m_doRead) {
    // Protect against multiple instances of TROOT
    if (0 == gROOT) {
      static TROOT root("root", "ROOT I/O");
      //    gDebug = 99;
      m_log << MSG::DEBUG << "ROOT not initialized, debug = " << gDebug
          << endreq;

    }
    else {
      m_log << MSG::DEBUG << "ROOT already initialized, debug = " << gDebug
          << endreq;
    }
  }
  return StatusCode::SUCCESS;
}

StatusCode
UserDataSvc::finalize() {
  m_log << MSG::INFO << "Finalizing " << name() << " - package version "
      << PACKAGE_VERSION << endreq;

  m_thistsvc.release().ignore();
  m_activeStoreSvc.release().ignore();
  return Service::finalize();
}

void
UserDataSvc::dump() const {
  m_log << MSG::INFO << "Dumping " << name() << " - package version "
      << PACKAGE_VERSION << endreq;

}

StatusCode
UserDataSvc::reinitialize() {
  m_log << MSG::INFO << "RE-initializing " << name() << " - package version "
      << PACKAGE_VERSION << endreq;
  m_log << MSG::WARNING << "RE-initializing " << name()
      << " not implemented, returning SUCCESS. " << endreq;
  return StatusCode::SUCCESS;
}

void
UserDataSvc::handle(const Incident &inc) {

  if (inc.type() == "BeginEvent") {
    m_log << MSG::DEBUG << "UserDataSvc::BeginEvent" << endreq;

    const EventInfo* evt;
    StatusCode sc = eventStore()->retrieve(evt);
    if (sc.isFailure()) {
      m_log << MSG::WARNING << "Could not find event" << endreq;
      return;
    }

    m_currRunNumber = evt->event_ID()->run_number();
    m_currEventNumber = evt->event_ID()->event_number();

    m_log << MSG::DEBUG << "Run:" << m_currRunNumber << " Event:"
        << m_currEventNumber << endreq;

    if (m_doWriteTransient) {

      // If not in first event, reset all decorations.
      // Do not reset if inside the first event,
      // so that to carry forward the decorations set before the first event,
      // in initialize(), for example
      if (!m_infirstevent) {
        for (unsigned int i = 0; i < m_associations.size(); i++) {
          if (m_associations[i].getLevel() == UserDataAssociation::EVENT
              || m_associations[i].getLevel()
                  == UserDataAssociation::COLLECTION) {
            m_numbersetinthisevent[i] = false;
          }
        }
      }
      if (!(decorateEvent("RunNumber", m_currRunNumber)).isSuccess()) {
        m_log << MSG::WARNING << "Could not add RunNumber as event decoration"
            << endreq;
        return;
      }

      if (!(decorateEvent("EventNumber", m_currEventNumber)).isSuccess()) {
        m_log << MSG::WARNING
            << "Could not add EventNumber as event decoration" << endreq;
        return;
      }

      if (!(decorateEvent("ElDecoBegin", m_el_curevent_begin)).isSuccess()) {
        m_log << MSG::WARNING
            << "Could not add ElDecoBegin as event decoration" << endreq;
        return;
      }
      if (!(decorateEvent("ElDecoEnd", m_el_curevent_end)).isSuccess()) {
        m_log << MSG::WARNING << "Could not add ElDecoEnd as event decoration"
            << endreq;
        return;
      }

      //for ElementLevel
      m_el_decodata.clear();

      m_el_decomap.clear();
      m_el_label2id.clear();
      m_el_labelarray.clear();
      m_el_id2label.clear();

      m_el_curevent_begin = m_el_curevent_end + 1; //in first event it will be set to 0


    }

    if (m_doRead) {
      m_r_synchronized = false;
      m_r_el_evt_init = false;

      m_r_el_decomap.clear();
      m_r_el_label2id.clear();
      m_r_el_labelarray.clear();
      m_r_el_id2label.clear();
    }

  }
  else if (inc.type() == "EndEvent") {
    m_log << MSG::DEBUG << "UserDataSvc::EndEvent" << endreq;
    //m_log<<MSG::DEBUG<<m_outputStream->name()<<endreq;
    //m_log<<MSG::DEBUG<<m_outputStream->m_outputName<<endreq;
    //m_log << MSG::DEBUG << "m_doWrite="<<m_doWrite << endreq;

    if (m_doWrite) {
      if (m_outputStream->isEventAccepted()) {
        m_log << MSG::INFO << "Event Accepted, saving decorations" << endreq;

	m_log << MSG::DEBUG << "#of Entries in the ElTree "
	      << m_el_tree->GetEntries() 
	      << " m_el_curevent_begin="<< m_el_curevent_begin 
	      << " m_el_curevent_end="<< m_el_curevent_end 
	      << endreq;
	
        //Element Level

        for (std::vector<ElDataEntry>::size_type it = 0; it
            < m_el_decodata.size(); it++) {

          m_log << MSG::DEBUG << "\t" << it << "\t"
		<< m_el_decodata[it].m_label << "\t" << std::hex
		<< m_el_decodata[it].m_abc << "\t"
		<< m_el_decodata[it].m_object.Address() << "\t" << endreq;
	  
          std::string *labelstr = &(m_el_decodata[it].m_label);
          TBufferFile *buf = objectToStream(m_el_decodata[it].m_object); //need delete
          int buflen = buf->Length();
          char *bufptr = buf->Buffer();
          std::string *blobstr = new std::string(bufptr, buflen); //need delete
          std::string *typestr = new std::string(
						 m_el_decodata[it].m_object.TypeOf().Name(REFLEX_NS::SCOPED)); //need delete
	  
          ULong64_t abc = (ULong64_t)(m_el_decodata[it].m_abc);
	  

          m_el_tree->SetBranchAddress("AthenaBarCode", &abc);
	  
          m_el_tree->SetBranchAddress("Label", &labelstr);
          m_el_tree->SetBranchAddress("Blob", &blobstr);
          m_el_tree->SetBranchAddress("Type", &typestr);
	  
          m_el_tree->Fill();

	  
          m_el_curevent_end++;
	  
          delete buf;
          delete blobstr;
          delete typestr;
        }
	
        if (m_el_curevent_end < m_el_curevent_begin) {//no decoration for this event
	  m_log << MSG::DEBUG << "No decoration for this event"<<endreq;
        }
        else {
	  m_log << MSG::DEBUG << "Yes decoration for this event"<<endreq;	  
        }

        if (!(decorateEvent("ElDecoBegin", m_el_curevent_begin)).isSuccess()) {
          m_log << MSG::WARNING
              << "Could not add ElDecoBegin as event decoration" << endreq;
          return;
        }
        if (!(decorateEvent("ElDecoEnd", m_el_curevent_end)).isSuccess()) {
          m_log << MSG::WARNING
              << "Could not add ElDecoEnd as event decoration" << endreq;
          return;
        }

        //Event Level
        //Loop over all decorations and reset the branch address
        for (unsigned int i = 0; i < m_associations.size(); i++) {

          //Fill event and collection level decorations
          if (m_associations[i].getLevel() == UserDataAssociation::EVENT
              || m_associations[i].getLevel()
                  == UserDataAssociation::COLLECTION) {

            void **addr = 0;
            if (m_numbersetinthisevent[i]) {//use new address
              addr = m_number2address[i];
              m_log << MSG::DEBUG << "UserDataSvc::EndEvent:UseNewAddress"
                  << endreq;
            }
            else {//use default address
              addr = m_number2defaultaddress[i];
              m_log << MSG::DEBUG << "UserDataSvc::EndEvent:UseDefaultAddress"
                  << endreq;
            }

            if (m_numberissimpletype[i]) {
              m_number2branch[i]->SetAddress(*addr);
            }
            else {
              m_number2branch[i]->SetAddress(addr);
            }

            m_numbersetinthisevent[i] = false;
          }
        }

        m_userdatatree->Fill();

        if (m_infirstevent)
          m_infirstevent = false;

      }
      else {//Filtered out
        m_log << MSG::INFO
            << "Event Filtered out by OutputStream, not saving decorations for this event."
            << endreq;
      }

    } // if (m_doWrite)
  }
  else if (inc.type() == "BeginRun") {
    //Todos On the BeginRun Incident
    m_log << MSG::DEBUG << "UserDataSvc::BeginRun" << endreq;
  }
  else if (inc.type() == "EndRun") {
    m_log << MSG::DEBUG << "UserDataSvc::EndRun" << endreq;
    if (m_doWrite) {
      SaveAssociations();
      //Loop over all decorations and reset the branch address
      for (unsigned int i = 0; i < m_associations.size(); i++) {

        //Fill event and collection level decorations
        if (m_associations[i].getLevel() == UserDataAssociation::FILE) {

          void **addr = 0;
          if (m_numbersetinthisevent[i]) {//use new address
            addr = m_number2address[i];
            m_log << MSG::DEBUG << "UserDataSvc::EndEvent:UseNewAddress"
                << endreq;
          }
          else {//use default address
            addr = m_number2defaultaddress[i];
            m_log << MSG::DEBUG << "UserDataSvc::EndEvent:UseDefaultAddress"
                << endreq;
          }

          if (m_numberissimpletype[i]) {
            m_number2branch[i]->SetAddress(*addr);
          }
          else {
            m_number2branch[i]->SetAddress(addr);
          }

          m_numbersetinthisevent[i] = false;
        }
      }

      m_fileleveluserdatatree->Fill();
    }
  }
  else if (inc.type() == "BeginInputFile") {
    m_log << MSG::DEBUG << "UserDataSvc::BeginInputFile" << endreq;
    if (m_doRead) {
      const FileIncident* fileInc = dynamic_cast<const FileIncident*> (&inc);
      if (fileInc == 0) {
        m_log << MSG::ERROR
            << " Unable to get FileName from BeginInputFile incident" << endreq;
        return;
      }
      m_log << MSG::DEBUG << "UserDataSvc::BeginInputFile::Filename:"
          << fileInc->fileName() << " " << fileInc->isPayload() << endreq;

      //FIXME: THistSvc will not close the files
      m_r_inputfilename = fileInc->fileName();
      m_r_fileopened = false;
      m_r_inputfilecounter++;
      m_doRead = true;
    }
  }
  else if (inc.type() == "EndInputFile") {
    m_log << MSG::DEBUG << "UserDataSvc::EndInputFile" << endreq;
    if (m_doRead) {
      const FileIncident* fileInc = dynamic_cast<const FileIncident*> (&inc);
      if (fileInc == 0) {
        m_log << MSG::ERROR
            << " Unable to get FileName from EndInputFile incident" << endreq;
        return;
      }
      m_log << MSG::DEBUG << "UserDataSvc::Filename:" << fileInc->fileName()
          << " " << fileInc->isPayload() << endreq;
    }
  }
  else if (inc.type() == "BeginTagFile") {
    m_log << MSG::DEBUG << "UserDataSvc::BeginTagFile" << endreq;
    if (m_doRead) {
      const FileIncident* fileInc = dynamic_cast<const FileIncident*> (&inc);
      if (fileInc == 0) {
        m_log << MSG::ERROR
            << " Unable to get FileName from BeginTagFile/EndTagFile incident"
            << endreq;
        return;
      }
      m_log << MSG::DEBUG << "UserDataSvc::Filename:" << fileInc->fileName()
          << " " << fileInc->isPayload() << endreq;
    }
  }
  else if (inc.type() == "EndTagFile") {
    m_log << MSG::DEBUG << "UserDataSvc::EndTagFile" << endreq;
    if (m_doRead) {
      const FileIncident* fileInc = dynamic_cast<const FileIncident*> (&inc);
      if (fileInc == 0) {
        m_log << MSG::ERROR
            << " Unable to get FileName from BeginTagFile/EndTagFile incident"
            << endreq;
        return;
      }
      m_log << MSG::DEBUG << "UserDataSvc::Filename:" << fileInc->fileName()
          << " " << fileInc->isPayload() << endreq;
    }
  }
}

int
UserDataSvc::CreateAssociation(const std::string &label,
    const UserDataAssociation::DecoLevel level,
    const std::string &demangledname, const std::string &key, const CLID clid,
    const UserDataAssociation::IndexType index) {

  //new association
  UserDataAssociation uda;
  uda.setLabel(label);
  uda.setLevel(level);
  uda.setKey(key);
  uda.setID(clid);
  uda.setIndex(index);
  //	uda.setType(decoinfo.name());
  uda.setLongType(demangledname);

  //add into vector
  m_associations.push_back(uda);
  std::vector<UserDataAssociation>::size_type mynumber = m_associations.size()
      - 1;
  m_label2number[label] = mynumber;
  m_number2label[mynumber] = label;

  return (int) mynumber;
}

void
UserDataSvc::SaveAssociations() {
  //Create Root TTree
  m_associationtree = new TTree("UserDataAssociations",
      "TTree associations between UserData and what they decorate");
  //Reg the tree with THistSvc
  if ((m_thistsvc->regTree(std::string("/userdataoutputstream_")+name()+"/UserDataAssociations",
      m_associationtree)).isSuccess()) {

    UserDataAssociation *uda = 0;
    m_associationtree->Bronch("UDA.", "UserDataAssociation", &uda);

    std::vector<UserDataAssociation>::iterator itr = m_associations.begin();
    while (itr != m_associations.end()) {
      uda = new UserDataAssociation(*itr);
      m_associationtree->Fill();
      delete uda;
      uda = 0;

      ++itr;
    }
  }
  else {
    m_log << MSG::ERROR << "Could not register UserDataAssociations tree"
        << endreq;
    //FIXME return StatusCode::FAILURE;
  }
}

const std::string
UserDataSvc::GetSimpleTypeString(const std::string &label,
    const std::type_info &info) const {
  std::string result("");
  if (info == typeid(double))
    result = label + "/D";
  if (info == typeid(int))
    result = label + "/I";
  if (info == typeid(unsigned int))
    result = label + "/i";
  if (info == typeid(long))
    result = label + "/L";
  if (info == typeid(unsigned long))
    result = label + "/l";
  if (info == typeid(char))
    result = label + "/B";
  if (info == typeid(unsigned char))
    result = label + "/b";
  if (info == typeid(float))
    result = label + "/F";
  if (info == typeid(bool))
    result = label + "/O";
  if (info == typeid(char *))
    result = label + "/C";
  if (info == typeid(const char *))
    result = label + "/C";
  return result;
}

bool
UserDataSvc::IsSimpleType(const std::type_info &info) const {
  if (info == typeid(double))
    return true;
  if (info == typeid(int))
    return true;
  if (info == typeid(unsigned int))
    return true;
  if (info == typeid(long))
    return true;
  if (info == typeid(unsigned long))
    return true;
  if (info == typeid(char))
    return true;
  if (info == typeid(unsigned char))
    return true;
  if (info == typeid(float))
    return true;
  if (info == typeid(bool))
    return true;
  if (info == typeid(char *))
    return true;
  if (info == typeid(const char *))
    return true;
  return false;
}
bool
UserDataSvc::IsSimpleType(const std::string &typenamedotname) const {
  if (typenamedotname == "d")
    return true;
  if (typenamedotname == "i")
    return true;
  if (typenamedotname == "j")
    return true;
  if (typenamedotname == "l")
    return true;
  if (typenamedotname == "m")
    return true;
  if (typenamedotname == "c")
    return true;
  if (typenamedotname == "h")
    return true;
  if (typenamedotname == "f")
    return true;
  if (typenamedotname == "b")
    return true;
  if (typenamedotname == "Pc")
    return true;
  if (typenamedotname == "PKc")
    return true;

  return false;
}

const std::type_info &
UserDataSvc::GetSimpleTypeInfoFromName(const std::string &typenamedotname) const {

  if (typenamedotname == "d")
    return typeid(double);
  if (typenamedotname == "i")
    return typeid(int);
  if (typenamedotname == "j")
    return typeid(unsigned int);
  if (typenamedotname == "l")
    return typeid(long);
  if (typenamedotname == "m")
    return typeid(unsigned long);
  if (typenamedotname == "c")
    return typeid(char);
  if (typenamedotname == "h")
    return typeid(unsigned char);
  if (typenamedotname == "f")
    return typeid(float);
  if (typenamedotname == "b")
    return typeid(bool);
  if (typenamedotname == "Pc")
    return typeid(char *);
  if (typenamedotname == "PKc")
    return typeid(const char *);

  return typeid(void);

}

StoreGateSvc*
UserDataSvc::eventStore() {
  if (m_activeStoreSvc == 0) {
    if (!m_activeStoreSvc.retrieve().isSuccess()) {
      m_log << MSG::ERROR << "Cannot get ActiveStoreSvc" << endreq;
      throw GaudiException("Cannot get ActiveStoreSvc", name(),
          StatusCode::FAILURE);
    }
  }
  return (m_activeStoreSvc->operator->());
}

const std::string
UserDataSvc::GenerateLabel(const std::string& label,
    const UserDataAssociation::DecoLevel& level, const CLID& clid,
    const std::string & key) {
  std::string ss;
  if (level == UserDataAssociation::EVENT || level == UserDataAssociation::FILE) {
    //Event level label is unique through out the file
    ss = label;
  }
  else if (level == UserDataAssociation::COLLECTION) {
    //Collection level, label is unique for each pair of <CLID,KEY>
    ostringstream s1;
    s1.fill('0');
    s1.width(20);
    s1 << clid;
    ss = std::string("COLL_") + s1.str() + std::string("_") + key
        + std::string("_") + label;
  }
  return ss;
}

int
UserDataSvc::vdecorate(const std::string& lab, const std::type_info &decoinfo,
    void* & deco, void* &defaultobj, void* &tobedeleted,
    const UserDataAssociation::DecoLevel& level, const CLID& clid,
    const std::string & key) {

  m_log << MSG::DEBUG << "UserDataSvc::vdecorate:" << "\tlabel=" << lab
      << "\type_info.name()=" << decoinfo.name() << "\tdeco=" << deco
      << "\tdefaultobj=" << defaultobj << "\tlevel=" << level << "\tclid="
      << clid << "\tkey=" << key << endreq;

  //Check if in the writing mode
  if (!m_doWriteTransient) {
    m_log << MSG::ERROR
        << "UserDataSvc::Trying to decorate when not in writing mode. Check TheUserDataSvc.Output"
        << endreq;
    return -1;
  }

  //Problem with decorating strings, so check and return error
  if (decoinfo == typeid(std::string) || decoinfo == typeid(char *) || decoinfo
      == typeid(const char*) || decoinfo == typeid(TString)) {
    m_log << MSG::ERROR
        << "Decoration type 'std::string', 'TString', 'char *' or 'const char *' is not supported (Due to ROOT functionality)"
        << "Please use vector of std::string instead (std::vector<std::string>)"
        << endreq;
    return -1;
  }

  //get the full demangled name of the type
  int sta;
  char * str;
  str = abi::__cxa_demangle(decoinfo.name(), 0, 0, &sta);
  if (sta != 0) {
    m_log << MSG::ERROR << "Can not get demangled name for typeid.name()="
        << decoinfo.name() << endreq;
    return -1;
  }
  std::string demangledname(str);
  m_log << MSG::DEBUG << "UserDataSvc::dis-mangled name:" << demangledname
      << endreq;
  delete str;

  std::vector<UserDataAssociation>::size_type mynumber;
  TBranch *mybranch = 0;

  //generate a label for this decoration
  std::string label = GenerateLabel(lab, level, clid, key);
  m_log << MSG::DEBUG << "UserDataSvc::decorate:GeneratedLabel=" << label
      << endreq;

  TTree *treelevel =
      ((level == UserDataAssociation::FILE) ? m_fileleveluserdatatree
          : m_userdatatree);

  //see if the decoration with the same label is already exist
  std::map<std::string, std::vector<UserDataAssociation>::size_type>::iterator
      itr = m_label2number.find(label);

  if (itr == m_label2number.end()) {//label not exist yet
    //One can only add new decoration in the first event (Or in initialize())
    //In other events can only change the address of decoration
    if (m_infirstevent) {
      //See if deco is one of the simple types
      if (!IsSimpleType(decoinfo)) {// not simple type
        m_log << MSG::DEBUG << "UserDataSvc::not simple type:" << demangledname
            << endreq;

        //see if the class can be obtained by TClass
        TClass *cl = TClass::GetClass(demangledname.c_str());
        if (cl) { //Class definition found, can be added to TTree
          m_log << MSG::DEBUG << "UserDataSvc::FIND CLASS:" << demangledname
              << endreq;
          void **defaultaddr = new void*((void*) defaultobj);
          void **addr = new void*((void*) deco);

          mybranch = treelevel->Bronch((label + ".").c_str(), cl->GetName(),
              defaultaddr);//, 32000, 0); //Do not split it

          if (!mybranch) {
            m_log << MSG::DEBUG << "Can't call bronch" << endreq;
          }

          int result =
              CreateAssociation(label, level, demangledname, key, clid);

          if (result < 0) {
            m_log << MSG::ERROR
                << "UserDataSvc::vgetDecoration:Can not create association."
                << endreq;
            return -1;

          }

          mynumber = (std::vector<UserDataAssociation>::size_type) result;

          m_number2branch[mynumber] = mybranch;
          m_numberissimpletype[mynumber] = false;
          m_number2address[mynumber] = addr;
          m_number2defaultaddress[mynumber] = defaultaddr;
          m_numbersetinthisevent[mynumber] = true;

          return 1;
        }
        else {//Class definition not found
          m_log << MSG::ERROR << "UserDataSvc::NOT FIND CLASS:"
              << demangledname << endreq;
          return -1;
        }
      }
      else { //Is simple type
        std::string rootstr(GetSimpleTypeString(label, decoinfo));
        m_log << MSG::DEBUG << "Adding simple type:" << rootstr.c_str()
            << endreq;
        //FIXME: catch exceptions of branch

        void **defaultaddr = new void*((void*) defaultobj);
        void **addr = new void*((void*) deco);

        mybranch = treelevel->Branch(label.c_str(), *defaultaddr,
            rootstr.c_str());

        if (!mybranch) {
          m_log << MSG::DEBUG << "Can't call Branch" << endreq;
        }

        int result = CreateAssociation(label, level, demangledname, key, clid);

        if (result < 0) {
          m_log << MSG::ERROR
              << "UserDataSvc::vgetDecoration:Can not create association."
              << endreq;
          return -1;

        }

        mynumber = (std::vector<UserDataAssociation>::size_type) result;

        m_number2branch[mynumber] = mybranch;
        m_numberissimpletype[mynumber] = true;
        m_number2address[mynumber] = addr;
        m_number2defaultaddress[mynumber] = defaultaddr;
        m_numbersetinthisevent[mynumber] = true;

        return 1;
      }
    }
    else {//can't add new label after first event
      m_log << MSG::ERROR
          << "Label not Exists but can't change userdata configuration after first event. Label="
          << label << endreq;
      return -1;
    }
  }
  else { //label already exist
    m_log << MSG::DEBUG << "Label exist:" << label << endreq;

    mynumber = itr->second;

    if (m_numberissimpletype[mynumber]) {// simple type
      m_log << MSG::DEBUG << "Simple type:"
          << m_associations[mynumber].getLongType() << endreq;
    }
    else {// complex type
      m_log << MSG::DEBUG << "Complex type:"
          << m_associations[mynumber].getLongType() << endreq;
    }

    if (m_associations[mynumber].getLongType() != demangledname) {
      m_log << MSG::ERROR << " Label Exists but type not the same. Label="
          << label << "\tTypeRequested=" << demangledname << "\tTypeExist="
          << m_associations[mynumber].getLongType() << endreq;

      return -1;
    }
    else {//good to go, set address to current

      void **addr = new void*((void*) deco);
      //delete the old address holder
      void **tmp = m_number2address[mynumber];

      //pass the old address out to be freed.
      tobedeleted = *tmp;
      delete tmp;
      tmp = 0;
      m_number2address[mynumber] = addr;

      m_numbersetinthisevent[mynumber] = true;

      m_log << MSG::DEBUG << "Label Exists, address updated. Label=" << label
          << endreq;

      return 0;
    }
  }

  //should not reach here;
  return -1;

}

int
UserDataSvc::vgetDecoration(const std::string& lab,
    const std::type_info &decoinfo, void *&deco,
    const UserDataAssociation::DecoLevel& level, const CLID& clid,
    const std::string & key) {

  //int UserDataSvc::vgetDecoration(const std::string& label,
  //		const std::type_info &decoinfo, void *&deco) {

  //see if it's in the reading mode
  if (!m_doRead) {
    m_log << MSG::ERROR
        << "UserDataSvc::Trying to get decoration when no input file is set."
        << endreq;
    return -1;
  }

  if (decoinfo == typeid(std::string) || decoinfo == typeid(char *) || decoinfo
      == typeid(const char*) || decoinfo == typeid(TString)) {
    m_log << MSG::ERROR
        << "Decoration type 'std::string', 'TString', 'char *' or 'const char *' is not supported (Due to ROOT functionality)"
        << "Please use vector of std::string instead (std::vector<std::string>)"
        << endreq;
    return -1;
  }

  int sta;
  char * str;
  str = abi::__cxa_demangle(decoinfo.name(), 0, 0, &sta);
  if (sta != 0) {
    m_log << MSG::ERROR << "Can not get demangled name for typeid.name()="
        << decoinfo.name() << endreq;
    return -1;
  }
  std::string demangledname(str);
  delete str;

  std::string label = GenerateLabel(lab, level, clid, key);

  m_log << MSG::DEBUG << "UserDataSvc::vgetDecoration('" << label << "','"
      << demangledname << "')" << endreq;

  m_log << MSG::DEBUG << "Demangled name=" << demangledname
      << "\ttypeid.name()" << decoinfo.name() << endreq;

  //see if the input file is opened
  if (m_r_fileopened) {

  }
  else {
    //***connect the file to THistSvc

    //Get the property "Input" from THistSvc
    std::auto_ptr<Property> prop(m_propTHistSvc->getProperty("Input").clone());
    StringArrayProperty *pp = dynamic_cast<StringArrayProperty *> (prop.get());
    m_log << MSG::DEBUG
        << "UserDataSvc::BeginInputFile::Before Update:THistSvc.Input=";
    m_log << MSG::DEBUG << pp->value() << endreq;

    //Set new property
    std::vector<std::string> strarr = pp->value();
    ostringstream s1;
    s1 << "userdatainputstream_";
    s1.fill('0');
    s1.width(5);
    s1 << m_r_inputfilecounter;
    m_r_inputstreamname = std::string("/") + s1.str();
    s1 << " DATAFILE='" << m_r_inputfilename << "' OPT='READ'";
    strarr.push_back(s1.str());
    m_log << MSG::DEBUG
        << "UserDataSvc::BeginInputFile::After Update:THistSvc.Input=";
    m_log << MSG::DEBUG << strarr << endreq;
    *pp = strarr;
    //activate the handler of this property in THistSvc
    if (!(m_propTHistSvc->setProperty(*prop)).isSuccess()) {
      m_log << MSG::ERROR << "Could not set THistSvc.Input property" << endreq;
      return -1;
    }

    //ReadBack and see if it worked
    //		prop=(m_propTHistSvc->getProperty("Input")).clone();
    //		pp=dynamic_cast<StringArrayProperty *>(prop);
    //		m_log<<MSG::DEBUG<<"UserDataSvc::BeginInputFile::THistSvc.Input="
    //				<<endreq;
    //		m_log<<MSG::DEBUG<<pp->value()<<endreq;

    //***Connect to the UserDataTree
    m_r_associationtree = 0;
    m_r_userdatatree = 0;
    m_r_fileleveluserdatatree = 0;

    StatusCode sc = m_thistsvc->regTree(m_r_inputstreamname
        + "/UserDataAssociations");
    if (sc != StatusCode::SUCCESS) {
      m_log << MSG::ERROR
          << "regTree Can not connect to UserDataAssociation tree in the input file"
          << endreq;
      return -1;
    }
    sc = m_thistsvc->getTree(m_r_inputstreamname + "/UserDataAssociations",
        m_r_associationtree);
    if (sc != StatusCode::SUCCESS || m_r_associationtree == 0) {
      m_log << MSG::ERROR
          << "getTree Can not connect to UserDataAssociation tree in the input file"
          << endreq;
      return -1;
    }
    sc = m_thistsvc->regTree(m_r_inputstreamname + "/UserDataTree");
    if (sc != StatusCode::SUCCESS) {
      m_log << MSG::WARNING
          << "regTree Can not connect to UserDataTree tree in the input file"
          << endreq;
    }
    sc = m_thistsvc->getTree(m_r_inputstreamname + "/UserDataTree",
        m_r_userdatatree);
    if (sc != StatusCode::SUCCESS || m_r_userdatatree == 0) {
      m_log << MSG::WARNING
          << "getTree Can not connect to UserDataTree tree in the input file"
          << endreq;
    }

    sc = m_thistsvc->regTree(m_r_inputstreamname + "/FileLevelUserDataTree");
    if (sc != StatusCode::SUCCESS) {
      m_log << MSG::WARNING
          << "regTree Can not connect to FileLevelUserDataTree tree in the input file"
          << endreq;
    }
    sc = m_thistsvc->getTree(m_r_inputstreamname + "/FileLevelUserDataTree",
        m_r_fileleveluserdatatree);
    if (sc != StatusCode::SUCCESS || m_r_fileleveluserdatatree == 0) {
      m_log << MSG::WARNING
          << "getTree Can not connect to FileLevelUserDataTree tree in the input file"
          << endreq;
    }

    sc = m_thistsvc->regTree(m_r_inputstreamname + "/ElementLevelUserDataTree");
    if (sc != StatusCode::SUCCESS) {
      m_log << MSG::WARNING
          << "regTree Can not connect to ElementLevelUserDataTree tree in the input file"
          << endreq;
    }
    sc = m_thistsvc->getTree(m_r_inputstreamname + "/ElementLevelUserDataTree",
        m_r_el_tree);
    if (sc != StatusCode::SUCCESS || m_r_el_tree == 0) {
      m_log << MSG::WARNING
          << "getTree Can not connect to ElementLevelUserDataTree tree in the input file"
          << endreq;
    }

    //*** get the list of associations
    if (m_r_associationtree->FindBranch("UDA.")) {
    }
    else {
      m_log << MSG::ERROR
          << "Branch UDA not exist in UserDataAssociations Tree" << endreq;
      return -1;
    }
    UserDataAssociation *uda = 0;
    m_r_associationtree->SetBranchAddress("UDA.", &uda);
    for (int i = 0; i < m_r_associationtree->GetEntries(); i++) {
      m_r_associationtree->GetEntry(i);
      m_r_associations.push_back(*uda);
      m_log << MSG::DEBUG << "UserDataSvc::vgetDecoration::uda=" << *uda
          << endreq;
      std::vector<UserDataAssociation>::size_type mynumber =
          m_r_associations.size() - 1;
      m_r_label2number[uda->getLabel()] = mynumber;
      m_number2label[mynumber] = uda->getLabel();
    }

    m_r_fileopened = true;
    m_r_currententry = 0;
  }

  //at this point the file should be opened
  //** see if the label exist
  std::map<std::string, std::vector<UserDataAssociation>::size_type>::iterator
      itr = m_r_label2number.find(label);

  if (itr == m_r_label2number.end()) {//label not exist yet
    m_log << MSG::ERROR << "label not exist:" << label << endreq;
    deco = 0;
    return -1;
  }

  std::vector<UserDataAssociation>::size_type mynumber;
  mynumber = itr->second;

  m_log << MSG::DEBUG << "label found:"
      << m_r_associations[mynumber].getLabel() << endreq;

  //**first check if the data type matches
  if (m_r_associations[mynumber].getLongType() == demangledname) {
    m_log << MSG::DEBUG << "Type Match:"
        << m_r_associations[mynumber].getLongType() << endreq;
  }
  else {
    m_log << MSG::ERROR << "Type does not Match, in root file:"
        << m_r_associations[mynumber].getLongType() << " Called with:"
        << demangledname << endreq;
    return -1;
  }

  if (level == UserDataAssociation::EVENT || level
      == UserDataAssociation::COLLECTION) {
    if (!m_r_synchronized) {
      //**Synchronize with event selector
      if (!m_r_userdatatree->FindBranch("RunNumber")
          || !m_r_userdatatree->FindBranch("EventNumber")) {
        m_log << MSG::WARNING
            << "Not find RunNumber and EventNumber in UserDataTree, may not synchronize correctly with EventSelector"
            << label << endreq;
      }
      else {
        bool synchronized = false;
        unsigned int runn;
        unsigned int evtn;
        m_r_userdatatree->SetBranchAddress("RunNumber", &runn);
        m_r_userdatatree->SetBranchAddress("EventNumber", &evtn);
        m_r_userdatatree->SetBranchStatus("*", 0); //disable all branches
        m_r_userdatatree->SetBranchStatus("RunNumber", 1);
        m_r_userdatatree->SetBranchStatus("EventNumber", 1);

        /* Now trying to synchronize the UD tree to the input stream according to Event# and Run#
		Assumption: 1. the Event# and Run# might not be in order in the input stream.
					2. for the same entry# (row#), the Event# and Run# in the UserDataTree matches the Event# and Run# in the stream (EventInfo)
		Method: look at the next entry (row) until Event# and Run# matches, or return failure if reach the last row
				One it return failure once, it will never return success again, since the last row is reached.
         */

        while (m_r_currententry<m_r_userdatatree->GetEntries()) {
          m_r_userdatatree->GetEntry(m_r_currententry);
          m_log << MSG::DEBUG << "RunNumber=" << runn << "\tEventNumber="
              << evtn << "\tm_currEventNumber=" << m_currEventNumber
              << "\tm_r_currententry=" << m_r_currententry << endreq;
          if (evtn == m_currEventNumber && runn == m_currRunNumber) { //correctly synchronized, can go ahead to read
            synchronized = true;
            break;
          }
          m_r_currententry++;
        }
        if (!synchronized) {
          m_log << MSG::ERROR
              << "Can not synchronize event, input file might be corrupted:\n"
              << "\tm_currRunNumber=" << m_currRunNumber
              << "\tm_currEventNumber=" << m_currEventNumber << "\tlabel="
              << label << "\tm_r_currententry=" << m_r_currententry << endreq;
          return -1;
        }
        m_r_synchronized = true;
      }
    }
  }

  m_log << MSG::DEBUG << "Synchronized:\n" << "\tm_currRunNumber="
      << m_currRunNumber << "\tm_currEventNumber=" << m_currEventNumber
      << "\tm_r_currententry=" << m_r_currententry << "\tlabel=" << label
      << endreq;

  TTree *currenttree = 0;
  unsigned int entrytoread = 0;

  //set the proper tree and number of entry to read for different decoration level
  if (level == UserDataAssociation::FILE) {
    if (m_r_fileleveluserdatatree) {
      entrytoread = 0;
      currenttree = m_r_fileleveluserdatatree;
    }
    else {
      m_log << MSG::ERROR
          << "FileLevelUserDataTree does not exist in the input file while trying to get file level decoration."
          << endreq;
      return -1;
    }
  }
  else if (level == UserDataAssociation::EVENT || level
      == UserDataAssociation::COLLECTION) {
    if (m_r_fileleveluserdatatree) {
      entrytoread = m_r_currententry;
      currenttree = m_r_userdatatree;
    }
    else {
      m_log << MSG::ERROR
          << "UserDataTree does not exist in the input file while trying to get event/collection level decoration."
          << endreq;
      return -1;
    }
  }

  //Now start to read the decoration
  if (IsSimpleType(decoinfo)) { //if is simple type

    m_log << MSG::DEBUG << "Getting data from UserDataTree, longtype="
        << demangledname << endreq;

    void *data = 0;
    currenttree->SetBranchStatus("*", 0); //disable all branches
    currenttree->SetBranchStatus(label.c_str(), 1);

    //Handle separately for different types
    if (decoinfo == typeid(double)) {
      double *tmpdata = new double();
      currenttree->SetBranchAddress(label.c_str(), tmpdata);
      currenttree->GetEntry(entrytoread);
      if (tmpdata) {
        data = static_cast<void*> (tmpdata);
      }
      else {
        m_log << MSG::ERROR << "Can not get data for branch:" << label
            << "\tentry#:" << entrytoread << endreq;
        return -1;

      }
    }

    if (decoinfo == typeid(int)) {
      int *tmpdata = new int();
      currenttree->SetBranchAddress(label.c_str(), tmpdata);
      currenttree->GetEntry(entrytoread);
      if (tmpdata) {
        data = static_cast<void*> (tmpdata);
      }
      else {
        m_log << MSG::ERROR << "Can not get data for branch:" << label
            << "\tentry#:" << entrytoread << endreq;
        return -1;

      }
    }

    if (decoinfo == typeid(unsigned int)) {
      unsigned int *tmpdata = new unsigned int();
      currenttree->SetBranchAddress(label.c_str(), tmpdata);
      currenttree->GetEntry(entrytoread);
      if (tmpdata) {
        data = static_cast<void*> (tmpdata);
      }
      else {
        m_log << MSG::ERROR << "Can not get data for branch:" << label
            << "\tentry#:" << entrytoread << endreq;
        return -1;

      }
    }

    if (decoinfo == typeid(long)) {
      long *tmpdata = new long();
      currenttree->SetBranchAddress(label.c_str(), tmpdata);
      currenttree->GetEntry(entrytoread);
      if (tmpdata) {
        data = static_cast<void*> (tmpdata);
      }
      else {
        m_log << MSG::ERROR << "Can not get data for branch:" << label
            << "\tentry#:" << entrytoread << endreq;
        return -1;

      }
    }

    if (decoinfo == typeid(unsigned long)) {
      unsigned long *tmpdata = new unsigned long();
      currenttree->SetBranchAddress(label.c_str(), tmpdata);
      currenttree->GetEntry(entrytoread);
      if (tmpdata) {
        data = static_cast<void*> (tmpdata);
      }
      else {
        m_log << MSG::ERROR << "Can not get data for branch:" << label
            << "\tentry#:" << entrytoread << endreq;
        return -1;

      }
    }

    if (decoinfo == typeid(char)) {
      char *tmpdata = new char();
      currenttree->SetBranchAddress(label.c_str(), tmpdata);
      currenttree->GetEntry(entrytoread);
      if (tmpdata) {
        data = static_cast<void*> (tmpdata);
      }
      else {
        m_log << MSG::ERROR << "Can not get data for branch:" << label
            << "\tentry#:" << entrytoread << endreq;
        return -1;

      }
    }

    if (decoinfo == typeid(unsigned char)) {
      unsigned char *tmpdata = new unsigned char();
      currenttree->SetBranchAddress(label.c_str(), tmpdata);
      currenttree->GetEntry(entrytoread);
      if (tmpdata) {
        data = static_cast<void*> (tmpdata);
      }
      else {
        m_log << MSG::ERROR << "Can not get data for branch:" << label
            << "\tentry#:" << entrytoread << endreq;
        return -1;

      }
    }

    if (decoinfo == typeid(float)) {
      float *tmpdata = new float();
      currenttree->SetBranchAddress(label.c_str(), tmpdata);
      currenttree->GetEntry(entrytoread);
      if (tmpdata) {
        data = static_cast<void*> (tmpdata);
      }
      else {
        m_log << MSG::ERROR << "Can not get data for branch:" << label
            << "\tentry#:" << entrytoread << endreq;
        return -1;

      }
    }

    if (decoinfo == typeid(bool)) {
      bool *tmpdata = new bool();
      currenttree->SetBranchAddress(label.c_str(), tmpdata);
      currenttree->GetEntry(entrytoread);
      if (tmpdata) {
        data = static_cast<void*> (tmpdata);
      }
      else {
        m_log << MSG::ERROR << "Can not get data for branch:" << label
            << "\tentry#:" << entrytoread << endreq;
        return -1;

      }
    }

    /*		 if (info==typeid(char *))
     return true;
     if (info==typeid(const char *))
     return true;
     */
    m_log << MSG::DEBUG << "Trying to GetEntry #" << entrytoread << endreq;
    m_log << MSG::DEBUG << "After GetEntry, data=" << data << endreq;

    if (data) {
      deco = data;
    }
    else {
      m_log << MSG::ERROR << "Can not get data for branch:" << label
          << "entry#" << entrytoread << endreq;
      return -1;
    }
  }
  else { //if is not simple type
    //**then check if the data type (class) is accessable in ROOT
    //get the name of the class
    bool foundclass = false;
    m_log << MSG::DEBUG << "UserDataSvc::dis-mangled name:" << demangledname
        << endreq;
    //see if the class can be obtained by TClass
    TClass *cl = TClass::GetClass(demangledname.c_str());
    if (cl) { //Class definition found, can be added to TTree
      m_log << MSG::DEBUG << "UserDataSvc::FIND CLASS:" << demangledname
          << endreq;
      foundclass = true;
    }
    if (!foundclass) {
      m_log << MSG::DEBUG << "Can not find class in ROOT" << demangledname
          << endreq;
      return -1;
    }

    //* check if the branch exists
    std::string brname;
    if (currenttree->GetBranch(label.c_str())) {
      brname = label;
    }
    else if (currenttree->GetBranch((label + ".").c_str())) {
      brname = label + ".";
    }
    else {
      m_log << MSG::ERROR << "Can not find branch in UserDataTree. branchname:"
          << label << endreq;
      return -1;
    }

    m_log << MSG::DEBUG << "Using branch name:" << brname << endreq;

    void *data = 0;
    currenttree->SetBranchStatus("*", 0); //disable all branches
    currenttree->SetBranchStatus((brname + "*").c_str(), 1);
    currenttree->GetBranch(brname.c_str())->SetAddress(&data);
    currenttree->GetEntry(entrytoread);

    if (data) {
      deco = data;
      m_log << MSG::DEBUG << "data=" << data << " deco=" << deco << endreq;
    }
    else {
      m_log << MSG::ERROR << "Can not get data for branch:" << label
          << "entry#" << entrytoread << endreq;
      return -1;
    }
  }

  return 0;

}

int
UserDataSvc::vgetInMemDecoration(const std::string& lab,
    const std::type_info &decoinfo, void *&deco,
    const UserDataAssociation::DecoLevel& level, const CLID& clid,
    const std::string & key) {

  if (decoinfo == typeid(std::string) || decoinfo == typeid(char *) || decoinfo
      == typeid(const char*) || decoinfo == typeid(TString)) {
    m_log << MSG::ERROR
        << "Decoration type 'std::string', 'TString', 'char *' or 'const char *' is not supported (Due to ROOT functionality)"
        << "Please use vector of std::string instead (std::vector<std::string>)"
        << endreq;
    return -1;
  }

  int sta;
  char * str;
  str = abi::__cxa_demangle(decoinfo.name(), 0, 0, &sta);
  if (sta != 0) {
    m_log << MSG::ERROR << "Can not get demangled name for typeid.name()="
        << decoinfo.name() << endreq;
    return -1;
  }
  std::string demangledname(str);
  delete str;

  std::string label = GenerateLabel(lab, level, clid, key);

  m_log << MSG::DEBUG << "UserDataSvc::vgetInMemDecoration('" << label << "','"
      << demangledname << "')" << endreq;

  m_log << MSG::DEBUG << "Demangled name=" << demangledname
      << "\ttypeid.name()" << decoinfo.name() << endreq;

  //** see if the label exist
  std::map<std::string, std::vector<UserDataAssociation>::size_type>::iterator
      itr = m_label2number.find(label);

  if (itr == m_label2number.end()) {//label not exist yet
    m_log << MSG::ERROR << "label not exist:" << label << endreq;
    deco = 0;
    return -1;
  }

  std::vector<UserDataAssociation>::size_type mynumber;
  mynumber = itr->second;
  //now mynumber is the index of the decoration in the associations list

  m_log << MSG::DEBUG << "label found:"
      << m_associations[mynumber].getLabel() << endreq;

  //**first check if the data type matches
  if (m_associations[mynumber].getLongType() == demangledname) {
    m_log << MSG::DEBUG << "Type Match:"
        << m_associations[mynumber].getLongType() << endreq;
  }
  else {
    m_log << MSG::ERROR << "Type does not Match, in root file:"
        << m_associations[mynumber].getLongType() << " Called with:"
        << demangledname << endreq;
    return -1;
  }

  if (level == UserDataAssociation::EVENT || level
      == UserDataAssociation::COLLECTION || level==UserDataAssociation::FILE) {
    
    void **addr = 0;
    if (m_numbersetinthisevent[mynumber]) {//use new address
      addr = m_number2address[mynumber];
            }
    else {//use default address
      addr = m_number2defaultaddress[mynumber];
    }
    deco=*addr;
    return 0;
  } 

  m_log<<MSG::WARNING<<"UserDataSvc::vgetInMemDecoration:wrong level"<<level<<endreq;
  return -1;
}

int
UserDataSvc::vdecorateElement(const IAthenaBarCode &abc,
    const std::string& label, const std::type_info &decoinfo, void* & deco,
    void* &defaultobj, void* &tobedeleted) {

  m_log << MSG::DEBUG << "UserDataSvc::vdecorateElement:" << "\tABC="
      << abc.getAthenaBarCode() << "\tlabel=" << label << "\type_info.name()="
      << decoinfo.name() << "\tdeco=" << deco << "\tdefaultobj=" << defaultobj
      << endreq;

  el_dump();

  //Check if in the writing mode
  if (!m_doWriteTransient) {
    m_log << MSG::ERROR
        << "vdecorateElement::Trying to decorate when not in writing mode. Check TheUserDataSvc.Output"
        << endreq;
    return -1;
  }

  //Get a ReflexObject from the object deco&decoinfo
  if (!m_dictLoaderSvc->load_type(decoinfo)) {
    m_log << MSG::ERROR << "vdecorateElement::The type:" << decoinfo.name()
        << " can't be loaded by reflex. Make sure the reflex library is properly generated for this type"
        << endreq;
    return -1;
  }

  REFLEX_NS::Type mytype = REFLEX_NS::Type::ByTypeInfo(decoinfo);
  if (!mytype.IsComplete()) {
    m_log << MSG::DEBUG << "vdecorateElement::The type:" << decoinfo.name()
        << " is not complete. Make sure the reflex library is properly generated for this type"
        << endreq;
    //    return -1;
  }

  m_log << MSG::DEBUG << "Successfully obtained reflex dictionary. "
      << "\tName=" << mytype.Name() << "\tIsFundamental="
      << mytype.IsFundamental() << "\tSizeOf=" << mytype.SizeOf() << endl;

  REFLEX_NS::Object myobject(mytype, deco);

  int64_t myentryid = el_findEntryID(abc, label);

  if (myentryid >= 0) {//found valid entry, overwriting the object
    //pass this out to be deleted

    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
    // DOREALWORK:already decorated abc&label, so overwriting
    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
    tobedeleted = m_el_decodata[myentryid].m_object.Address();
    m_el_decodata[myentryid].m_object = myobject;

    el_dump();
    return 0;

  }
  else if (myentryid <= -1) {

    m_log << MSG::DEBUG << "el_newDecoration::" << endreq;

    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
    // DOREALWORK:create a new entry
    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

    std::vector<std::string>::size_type labelid = el_findOrAddLabel(label);
    std::vector<ElDataEntry>::size_type entryid = el_newDataEntry(abc, label,
        myobject);

    if (myentryid == -1) {
      //If not found abc, create a new map
      std::map<uint32_t, uint32_t> mymap;
      mymap[labelid] = entryid;
      m_el_decomap[abc.getAthenaBarCode()] = mymap;
    }
    else {
      ((*m_el_decomap.find(abc.getAthenaBarCode())).second)[labelid] = entryid;
    }

    el_dump();
    return 1;

  }

  //should not reach here;
  return -1;

}

int
UserDataSvc::vgetElementDecoration(const IAthenaBarCode &abc,
    const std::string& lab, const std::type_info &decoinfo, void *&deco) {

  //see if it's in the reading mode
  if (!m_doRead) {
    m_log << MSG::ERROR
        << "UserDataSvc::Trying to get decoration when no input file is set."
        << endreq;
    return -1;
  }

  if (r_el_init() < 0) {
    return -1;
  }

  //Now locate the row and read the blob
  //See if the same ABC can be found
  int entryNumber = -1;

  std::map<AthenaBarCode_t, std::map<uint32_t, uint32_t> >::iterator itRDecoMap;

  itRDecoMap = m_r_el_decomap.find(abc.getAthenaBarCode());

  if (itRDecoMap == m_r_el_decomap.end()) {
    //If not found abc

    m_log << MSG::WARNING << "UserDataSvc::AthenaBarCode requested not exist"
        << endreq;

    return -1;
  }
  else {
    //If found abc
    //Look to see if the label already exist
    std::map<std::string, uint32_t>::iterator itLabel2id;
    itLabel2id = m_r_el_label2id.find(lab);
    if (itLabel2id == m_r_el_label2id.end()) {
      //not exist
      m_log << MSG::WARNING << "UserDataSvc::label requested not exist"
          << endreq;

      return -1;
    }
    else {
      //good
      std::vector<std::string>::size_type labelid = (*itLabel2id).second;
      std::map<uint32_t, uint32_t>::iterator itLabelID2EntryID;
      itLabelID2EntryID = (*itRDecoMap).second.find(labelid);
      if (itLabelID2EntryID == (*itRDecoMap).second.end()) {
        //not found the map<abc,map<labelid,entryid>>
        m_log << MSG::WARNING
            << "UserDataSvc::Label & AthenaBarCode pair requested not exist"
            << endreq;

        return -1;
      }
      else {
        entryNumber = (*itLabelID2EntryID).second;
      }
    }
  }

  m_log << MSG::DEBUG << "UserDataSvc::entryNumber=" << entryNumber << endreq;

  //read the blob
  m_r_el_tree->SetBranchStatus("*", 0); //disable all branches
  m_r_el_tree->SetBranchStatus("Blob", 1);
  m_r_el_tree->SetBranchStatus("Type", 1);
  m_r_el_tree->GetEntry(entryNumber);

  //verify type

  //Get a ReflexObject from the object deco&decoinfo
  if (!m_dictLoaderSvc->load_type(decoinfo)) {
    m_log << MSG::ERROR << "vdecorateElement::The type:" << decoinfo.name()
        << " can't be loaded by reflex. Make sure the reflex library is properly generated for this type"
        << endreq;
    return -1;
  }

  REFLEX_NS::Type mytype = REFLEX_NS::Type::ByTypeInfo(decoinfo);
  if (!mytype.IsComplete()) {
    m_log << MSG::DEBUG << "vdecorateElement::The type:" << decoinfo.name()
        << " is not complete. Make sure the reflex library is properly generated for this type"
        << endreq;
    //    return -1;
  }

  REFLEX_NS::Type readtype = REFLEX_NS::Type::ByName(*m_r_el_tree_type);

  if (mytype.Name(REFLEX_NS::SCOPED) != readtype.Name(REFLEX_NS::SCOPED)) {
    m_log << MSG::ERROR << "vdecorateElement::The type requested:"
        << mytype.Name(REFLEX_NS::SCOPED) << " does not match the type in userdata:"
        << readtype.Name(REFLEX_NS::SCOPED) << endreq;
    return -1;
  }

  m_log << MSG::DEBUG << "Successfully obtained reflex dictionary. "
      << "\tName=" << mytype.Name(REFLEX_NS::SCOPED) << "\tIsFundamental="
      << mytype.IsFundamental() << "\tSizeOf=" << mytype.SizeOf() << endl;

  m_log << MSG::DEBUG << "m_r_el_tree_type=" << *m_r_el_tree_type << endreq;


  //create object

  char *blobaddr = (char*) (m_r_el_tree_blob->c_str());
  int bloblen = (int) (m_r_el_tree_blob->length());
  REFLEX_NS::Object *theobj = blobToObject(blobaddr, bloblen, mytype);

  deco = theobj->Address();

  m_log << MSG::DEBUG << "theobj->AddressOf()=" << theobj->Address()
      << " deco=" << deco << endreq;

  //  delete theobj;
  //FIXME: delete the reflex object theobj somewhere to avoid memory leak

  //  m_log << MSG::DEBUG << "theobj->AddressOf()=" << theobj->Address()
  //      << " deco=" << deco << endreq;

  delete m_r_el_tree_type;
  m_r_el_tree_type = 0;
  delete m_r_el_tree_blob;
  m_r_el_tree_blob = 0;

  return 0;

}

int
UserDataSvc::vgetInMemElementDecoration(const IAthenaBarCode &abc,
                                        const std::string& lab, const std::type_info &decoinfo, void *&deco,
                                        bool quiet /*= false*/) {

  int64_t myentryid = el_findEntryID(abc, lab);
  
  if (myentryid >= 0) {//found valid entry
    m_log << MSG::DEBUG << "UserDataSvc::myentryid=" << myentryid << endreq;
    
    //Get a ReflexObject from the object deco&decoinfo
    if (!m_dictLoaderSvc->load_type(decoinfo)) {
      m_log << MSG::ERROR << "vgetInMemElementDecoration::The type:" << decoinfo.name()
	    << " can't be loaded by reflex. Make sure the reflex library is properly generated for this type"
	    << endreq;
      return -1;
    }

    REFLEX_NS::Type mytype = REFLEX_NS::Type::ByTypeInfo(decoinfo);
    if (!mytype.IsComplete()) {
      m_log << MSG::DEBUG << "vgetInMemElementDecoration::The type:" << decoinfo.name()
	    << " is not complete. Make sure the reflex library is properly generated for this type"
	    << endreq;
    }

    if (mytype.Name(REFLEX_NS::SCOPED) != m_el_decodata[myentryid].m_object.TypeOf().Name(REFLEX_NS::SCOPED)) {
      m_log << MSG::ERROR << "vgetInMemElementDecoration::The type requested:"
	    << mytype.Name(REFLEX_NS::SCOPED) << " does not match the type in userdata:"
	    << m_el_decodata[myentryid].m_object.TypeOf().Name(REFLEX_NS::SCOPED) << endreq;
      return -1;
    }

    m_log << MSG::DEBUG << "vgetInMemElementDecoration::Successfully obtained and matched reflex dictionary. "
	  << "\tName=" << mytype.Name(REFLEX_NS::SCOPED) << "\tIsFundamental="
	  << mytype.IsFundamental() << "\tSizeOf=" << mytype.SizeOf() << endl;
    
    deco = m_el_decodata[myentryid].m_object.Address();

    return 0;

  } else if (myentryid==-1) {
    if (!quiet)
      m_log << MSG::WARNING << "UserDataSvc::vgetInMemElementDecoration:AthenaBarCode requested not exist"
        << endreq;
    return -1;
  } else if (myentryid==-2) {
    if (!quiet)
      m_log << MSG::WARNING << "UserDataSvc::label requested not exist"<< endreq;
    return -1;
  } else if (myentryid==-3) {
    //not found the map<abc,map<labelid,entryid>>
    if (!quiet)
      m_log << MSG::WARNING
            << "UserDataSvc::Label & AthenaBarCode pair requested not exist"
            << endreq;
    return -1;
  }

  //should not reach here
  return -1;
}

std::vector<std::string>::size_type
UserDataSvc::el_findOrAddLabel(const std::string & label) {

  std::vector<std::string>::size_type labelid;
  std::map<std::string, uint32_t>::iterator it2;
  it2 = m_el_label2id.find(label);
  if (it2 == m_el_label2id.end()) {
    //not found, add new
    m_el_labelarray.push_back(label);
    labelid = m_el_labelarray.size() - 1;
    m_el_label2id[label] = labelid;
    m_el_id2label[labelid] = label;
  }
  else {
    labelid = (*it2).second;
  }

  return labelid;
}

//Return -1 when found no abc
//return -2 when found abc, but label is not defined (label not in m_el_label2id)
//return -3 when found abc, found label in m_el_label2id, but no entry map<abc,map<labelid,entryid>> is found
//otherwise return the entry id >=0
int64_t
UserDataSvc::el_findEntryID(const IAthenaBarCode &abc, const std::string& label) {

  //See if the same ABC can be found
  std::map<AthenaBarCode_t, std::map<uint32_t, uint32_t> >::iterator it;
  it = m_el_decomap.find(abc.getAthenaBarCode());

  if (it == m_el_decomap.end()) {
    //If not found abc
    return -1;
  }
  else {
    //If found abc
    //Look to see if the label already exist
    std::map<std::string, uint32_t>::iterator itLabel2id;
    itLabel2id = m_el_label2id.find(label);
    if (itLabel2id == m_el_label2id.end()) {
      return -2;
    }
    else {
      std::vector<std::string>::size_type labelid = (*itLabel2id).second;
      std::map<uint32_t, uint32_t>::iterator itLabelID2EntryID;
      itLabelID2EntryID = (*it).second.find(labelid);
      if (itLabelID2EntryID == (*it).second.end()) {
        //not found the map<abc,map<labelid,entryid>>
        return -3;
      }
      else {
        return (*itLabelID2EntryID).second;
      }
    }
  }
}

std::vector<UserDataSvc::ElDataEntry>::size_type
UserDataSvc::el_newDataEntry(const IAthenaBarCode &abc,
    const std::string& label, const REFLEX_NS::Object &myobject) {
  ElDataEntry mydataentry;
  mydataentry.m_label = label;
  mydataentry.m_abc = abc.getAthenaBarCode();
  mydataentry.m_object = myobject;

  m_el_decodata.push_back(mydataentry);

  m_log << MSG::DEBUG << "el_newDataEntry: entryID=" << m_el_decodata.size()
      - 1 << endreq;

  return m_el_decodata.size() - 1;

}

void
UserDataSvc::el_dump() const {
  m_log << MSG::DEBUG << "el_dump()\n" << "Number of Data Entries="
      << m_el_decodata.size() << "List of Entries:" << endreq;

  m_log << MSG::DEBUG << "\t" << "entryID" << "\t" << "label" << "\t"
      << "AthenaBarCode" << "\t" << "m_object.Address()" << "\t" << endreq;

  for (std::vector<ElDataEntry>::size_type it = 0; it < m_el_decodata.size(); it++) {
    m_log << MSG::DEBUG << "\t" << it << "\t" << m_el_decodata[it].m_label
        << "\t" << std::hex << m_el_decodata[it].m_abc << "\t"
        << m_el_decodata[it].m_object.Address() << "\t" << endreq;
  }

  //Dump the map
  m_log << MSG::DEBUG << "Dumping map:" << endreq;

  for (std::map<AthenaBarCode_t, std::map<uint32_t, uint32_t> >::const_iterator
      itDecoMap = m_el_decomap.begin(); itDecoMap != m_el_decomap.end(); itDecoMap++) {

    m_log << MSG::DEBUG << "AthenaBarCode=" << (*itDecoMap).first << endreq;

    for (std::map<uint32_t, uint32_t>::const_iterator itLabelID2EntryID =
        (*itDecoMap).second.begin(); itLabelID2EntryID
        != (*itDecoMap).second.end(); itLabelID2EntryID++) {

      m_log << MSG::DEBUG << "AthenaBarCode=" << (*itDecoMap).first
          << "\tLabelID=" << (*itLabelID2EntryID).first << "\tEntryID="
          << (*itLabelID2EntryID).second << endreq;
    }
  }
  //Dump label array and maps

  m_log << MSG::DEBUG << "Dumping m_el_labelarray:\n" << "LabelID\tLABEL"
      << endreq;

  for (std::vector<std::string>::size_type i = 0; i < m_el_labelarray.size(); i++) {
    m_log << MSG::DEBUG << i << "\t" << m_el_labelarray[i] << endreq;
  }

  m_log << MSG::DEBUG << "Dumping m_el_label2id:\n" << endreq;

  for (std::map<std::string, uint32_t>::const_iterator it =
      m_el_label2id.begin(); it != m_el_label2id.end(); it++) {
    m_log << MSG::DEBUG << "\tLabel=" << (*it).first << "\tLabelID="
        << (*it).second << endreq;
  }

  m_log << MSG::DEBUG << "Dumping m_el_id2label:\n" << endreq;

  for (std::map<uint32_t, std::string>::const_iterator it =
      m_el_id2label.begin(); it != m_el_id2label.end(); it++) {
    m_log << MSG::DEBUG << "\tLabelID=" << (*it).first << "\tLabel="
        << (*it).second << endreq;
  }

}

void
UserDataSvc::r_el_dump() const {
  //Dump the map
  m_log << MSG::DEBUG << "Dumping map:" << endreq;

  for (std::map<AthenaBarCode_t, std::map<uint32_t, uint32_t> >::const_iterator
      itDecoMap = m_r_el_decomap.begin(); itDecoMap != m_r_el_decomap.end(); itDecoMap++) {

    m_log << MSG::DEBUG << "AthenaBarCode=" << (*itDecoMap).first << endreq;

    for (std::map<uint32_t, uint32_t>::const_iterator itLabelID2EntryID =
        (*itDecoMap).second.begin(); itLabelID2EntryID
        != (*itDecoMap).second.end(); itLabelID2EntryID++) {

      m_log << MSG::DEBUG << "AthenaBarCode=" << (*itDecoMap).first
          << "\tLabelID=" << (*itLabelID2EntryID).first << "\tEntryID="
          << (*itLabelID2EntryID).second << endreq;
    }
  }
  //Dump label array and maps

  m_log << MSG::DEBUG << "Dumping m_r_el_labelarray:\n" << "LabelID\tLABEL"
      << endreq;

  for (std::vector<std::string>::size_type i = 0; i < m_r_el_labelarray.size(); i++) {
    m_log << MSG::DEBUG << i << "\t" << m_r_el_labelarray[i] << endreq;
  }

  m_log << MSG::DEBUG << "Dumping m_r_el_label2id:\n" << endreq;

  for (std::map<std::string, uint32_t>::const_iterator it =
      m_r_el_label2id.begin(); it != m_r_el_label2id.end(); it++) {
    m_log << MSG::DEBUG << "\tLabel=" << (*it).first << "\tLabelID="
        << (*it).second << endreq;
  }

  m_log << MSG::DEBUG << "Dumping m_r_el_id2label:\n" << endreq;

  for (std::map<uint32_t, std::string>::const_iterator it =
      m_r_el_id2label.begin(); it != m_r_el_id2label.end(); it++) {
    m_log << MSG::DEBUG << "\tLabelID=" << (*it).first << "\tLabel="
        << (*it).second << endreq;
  }
}

TBufferFile *
UserDataSvc::objectToStream(REFLEX_NS::Object &obj) {
  //This function takes an Reflex Object, stream it into a buffer (memory blob)
  //and returns the pointer to the buffer.
  //then buf.Buffer() is a pointer to the blob, and buf.Length() is the length of the blob.
  //see blolToObject() for the inverse operation
  //
  //User Need to delete tbuf after use;

  TBufferFile *tbuf = new TBufferFile(TBuffer::kWrite);
  tbuf->Reset();
  REFLEX_NS::Type mytype = obj.TypeOf();

  if (mytype.IsFundamental()) {

    if (mytype.Name() == "double") {
      double *tmp = static_cast<double*> (obj.Address());
      tbuf->WriteDouble(*tmp);
    }
    else if (mytype.Name() == "int") {
      int *tmp = static_cast<int*> (obj.Address());
      tbuf->WriteInt(*tmp);
    }
    else if (mytype.Name() == "unsigned int") {
      unsigned int *tmp = static_cast<unsigned int *> (obj.Address());
      tbuf->WriteUInt(*tmp);
    }
    else if (mytype.Name() == "long") {
      long *tmp = static_cast<long*> (obj.Address());
      tbuf->WriteLong(*tmp);
    }
    else if (mytype.Name() == "unsigned long") {
      unsigned long *tmp = static_cast<unsigned long*> (obj.Address());
      tbuf->WriteULong(*tmp);
    }
    else if (mytype.Name() == "char") {
      char *tmp = static_cast<char*> (obj.Address());
      tbuf->WriteChar(*tmp);
    }
    else if (mytype.Name() == "unsigned char") {
      unsigned char *tmp = static_cast<unsigned char*> (obj.Address());
      tbuf->WriteUChar(*tmp);
    }
    else if (mytype.Name() == "float") {
      float *tmp = static_cast<float*> (obj.Address());
      tbuf->WriteFloat(*tmp);
    }
    else if (mytype.Name() == "bool") {
      bool *tmp = static_cast<bool*> (obj.Address());
      tbuf->WriteBool(*tmp);
    }
    else {
      return 0;
    }

  }
  else {//is class
    tbuf->StreamObject(obj.Address(), TClass::GetClass(
        obj.TypeOf().Name().c_str()));
  }

  return tbuf;

}

REFLEX_NS::Object *
UserDataSvc::blobToObject(char *buf, int &len, REFLEX_NS::Type& mytype) {

  //This function takes a memory blob with pointer "buf" and length "len"
  //and create a Reflex Object out of it.
  //See objectToBuffer() for the inverse operation

  //User need to delete object after use

  TBufferFile ibuf(TBuffer::kRead, len, buf, kFALSE);

  REFLEX_NS::Object bobj = mytype.Construct();
  REFLEX_NS::Object *iobj = &bobj;

  if (mytype.IsFundamental()) {

    if (mytype.Name() == "double") {
      double *tmp = static_cast<double*> (iobj->Address());
      ibuf.ReadDouble(*tmp);
    }
    else if (mytype.Name() == "int") {
      int *tmp = static_cast<int*> (iobj->Address());
      ibuf.ReadInt(*tmp);
    }
    else if (mytype.Name() == "unsigned int") {
      unsigned int *tmp = static_cast<unsigned int*> (iobj->Address());
      ibuf.ReadUInt(*tmp);
    }
    else if (mytype.Name() == "long") {
      long *tmp = static_cast<long*> (iobj->Address());
      ibuf.ReadLong(*tmp);
    }
    else if (mytype.Name() == "unsigned long") {
      unsigned long *tmp = static_cast<unsigned long*> (iobj->Address());
      ibuf.ReadULong(*tmp);
    }
    else if (mytype.Name() == "char") {
      char *tmp = static_cast<char*> (iobj->Address());
      ibuf.ReadChar(*tmp);
    }
    else if (mytype.Name() == "unsigned char") {
      unsigned char *tmp = static_cast<unsigned char*> (iobj->Address());
      ibuf.ReadUChar(*tmp);
    }
    else if (mytype.Name() == "float") {
      float *tmp = static_cast<float*> (iobj->Address());
      ibuf.ReadFloat(*tmp);
    }
    else if (mytype.Name() == "bool") {
      bool *tmp = static_cast<bool*> (iobj->Address());
      ibuf.ReadBool(*tmp);
    }
    else {
      return 0;
    }

  }
  else {//is class
    ibuf.StreamObject(iobj->Address(), TClass::GetClass(mytype.Name().c_str()));
  }

  return iobj;

}

int
UserDataSvc::r_el_init() {

  //read every thing in the event into a map (excpt the blob part)
  if (!m_r_el_evt_init) {

    //Get the two evtDecos
    //Compare the two

    if (!(getEventDecoration("ElDecoBegin", m_r_el_curevent_begin)).isSuccess()) {
      m_log << MSG::WARNING
          << "Could not retrieve ElDecoBegin as event decoration, maybe file does not contain element level userdata"
          << endreq;
      return -1;
    }

    if (!(getEventDecoration("ElDecoEnd", m_r_el_curevent_end)).isSuccess()) {
      m_log << MSG::WARNING
          << "Could not retrieve ElDecoEnd as event decoration, maybe file does not contain element level userdata"
          << endreq;
      return -1;
    }

    if (m_r_el_curevent_begin >= m_r_el_curevent_end) {
      m_log << MSG::WARNING
          << "ElDecoEnd<=ElDecoBegin, Noelement level userdata for this event"
          << endreq;
      return -1;
    }

    if (m_r_el_tree == 0) {
      m_log << MSG::WARNING
          << "No ElementLevelUserDataTree tree in the input file, ignoring"
          << endreq;
      return -1;
    }

    //m_r_el_evt_init is true when all element level userdata has been loaded into map for this event, it will be reset to false at the beginning of each event.

 //   EventID::number_type rn, en;

 //   m_r_el_tree->SetBranchAddress("RunNumber", &rn);
 //   m_r_el_tree->SetBranchAddress("EventNumber", &en);
    m_r_el_tree->SetBranchAddress("AthenaBarCode", &m_r_el_tree_abc);
    m_r_el_tree->SetBranchAddress("Label", &m_r_el_tree_label);
    m_r_el_tree->SetBranchAddress("Blob", &m_r_el_tree_blob);
    m_r_el_tree->SetBranchAddress("Type", &m_r_el_tree_type);
    m_r_el_tree->SetBranchStatus("*", 0); //disable all branches
 //   m_r_el_tree->SetBranchStatus("RunNumber", 1);
 //   m_r_el_tree->SetBranchStatus("EventNumber", 1);
    m_r_el_tree->SetBranchStatus("AthenaBarCode", 1);
    m_r_el_tree->SetBranchStatus("Label", 1);

    //loop over all rows
    for (int ii = m_r_el_curevent_begin; ii <= m_r_el_curevent_end; ii++) {

      //Read in the row
      m_r_el_tree->GetEntry(ii);

      m_log << MSG::DEBUG << "label=" << *m_r_el_tree_label << " abc="
          << std::hex << m_r_el_tree_abc << endreq;

      //add the label into labelid
      std::vector<std::string>::size_type labelid;
      std::map<std::string, uint32_t>::iterator it2;
      it2 = m_r_el_label2id.find(*m_r_el_tree_label);

      if (it2 == m_r_el_label2id.end()) {

        //not found, add new
        m_r_el_labelarray.push_back(*m_r_el_tree_label);
        labelid = m_r_el_labelarray.size() - 1;
        m_r_el_label2id[*m_r_el_tree_label] = labelid;
        m_r_el_id2label[labelid] = *m_r_el_tree_label;

      }
      else {

        labelid = (*it2).second;
      }

      //Locate the AthenaBarCode from the map
      std::map<AthenaBarCode_t, std::map<uint32_t, uint32_t> >::iterator
          itDecoMap;
      itDecoMap = m_r_el_decomap.find(m_r_el_tree_abc);

      if (itDecoMap == m_r_el_decomap.end()) {
        //not found, add new
        std::map<uint32_t, uint32_t> mymap;
        mymap[labelid] = ii;
        m_r_el_decomap[m_r_el_tree_abc] = mymap;

      }
      else {
        //already exist add the pair <labelid,ii> directly

        ((*m_r_el_decomap.find(m_r_el_tree_abc)).second)[labelid] = ii;
      }

      delete m_r_el_tree_label;
      m_r_el_tree_label = 0;
    }
    m_r_el_evt_init = true;
  }//if(!m_r_el_evt_init)

  return 0;

}

std::vector<AthenaBarCode_t>
UserDataSvc::getElListOfABC() {
  std::vector<AthenaBarCode_t> myvec;

  if (r_el_init() < 0) {
    return myvec;
  }

  myvec.reserve(m_r_el_decomap.size() + 1);

  std::map<AthenaBarCode_t, std::map<uint32_t, uint32_t> >::iterator
      itRDecoMap = m_r_el_decomap.begin();

  for (; itRDecoMap != m_r_el_decomap.end(); itRDecoMap++) {
    myvec.push_back((*itRDecoMap).first);
  }

  return myvec;
}

std::vector<AthenaBarCode_t>
UserDataSvc::getInMemElListOfABC() {
  std::vector<AthenaBarCode_t> myvec;

  myvec.reserve(m_el_decomap.size() + 1);

  std::map<AthenaBarCode_t, std::map<uint32_t, uint32_t> >::iterator
      itRDecoMap = m_el_decomap.begin();

  for (; itRDecoMap != m_el_decomap.end(); itRDecoMap++) {
    myvec.push_back((*itRDecoMap).first);
  }

  return myvec;
}

std::vector<std::string>
UserDataSvc::getElListOfLabel(const AthenaBarCode_t &abc) {
  m_log << MSG::DEBUG << "GG1" << endreq;
  std::vector<std::string> myvec;
  if (r_el_init() < 0) {
    return myvec;
  }
  m_log << MSG::DEBUG << "GG2" << endreq;

  std::map<AthenaBarCode_t, std::map<uint32_t, uint32_t> >::iterator
      itRDecoMap = m_r_el_decomap.find(abc);

  if (itRDecoMap == m_r_el_decomap.end()) {
    //not found this abc
    return myvec;
  }

  std::map<uint32_t, uint32_t>::iterator itAbc2Entry =
      (*itRDecoMap).second.begin();
  myvec.reserve((*itRDecoMap).second.size() + 1);

  for (; itAbc2Entry != (*itRDecoMap).second.end(); itAbc2Entry++) {
    myvec.push_back(m_r_el_id2label[(*itAbc2Entry).first]);
  }

  return myvec;

}

std::vector<std::string>
UserDataSvc::getInMemElListOfLabel(const AthenaBarCode_t &abc) {

  std::vector<std::string> myvec;

  std::map<AthenaBarCode_t, std::map<uint32_t, uint32_t> >::iterator
      itRDecoMap = m_el_decomap.find(abc);

  if (itRDecoMap == m_el_decomap.end()) {
    //not found this abc
    return myvec;
  }

  std::map<uint32_t, uint32_t>::iterator itAbc2Entry =
      (*itRDecoMap).second.begin();
  myvec.reserve((*itRDecoMap).second.size() + 1);

  for (; itAbc2Entry != (*itRDecoMap).second.end(); itAbc2Entry++) {
    myvec.push_back(m_el_id2label[(*itAbc2Entry).first]);
  }

  return myvec;

}
