///////////////////////// -*- C++ -*- /////////////////////////////
#ifndef USERDATAASSOCIATION_H
#define USERDATAASSOCIATION_H
/** @file UserDataAssociation.h
 * @brief Helper file for UserDataSvc
 * @author Yushu Yao <yyao@lbl.gov> - ATLAS Collaboration
 *$Id: UserDataAssociation.h,v 1.4 2008/12/11 19:30:32 ssnyder Exp $
 */

#include <string>
#include <iostream>

#include <typeinfo>
#include "GaudiKernel/ClassID.h"

/** @class UserDataAssociation 
 * @brief The association between decoration and decorated object
 *
 * @details 
 */
class UserDataAssociation {

public:

	enum DecoLevel {
		NONE,
		EVENT,
		COLLECTION,
		ELEMENT,
		FILE
	};

	typedef std::size_t IndexType;

public:
	//Constructor
	UserDataAssociation() {
		m_label="";
		m_id=0;
		m_key="";
		m_index=0;
		m_level=NONE;
		//		m_type="";
		m_longtype="";
		m_doc="";

	}

	UserDataAssociation(const UserDataAssociation &rhs) {
		m_label=rhs.getLabel();
		m_id=rhs.getID();
		m_key=rhs.getKey();
		m_index=rhs.getIndex();
		m_level=rhs.getLevel();
		m_doc=rhs.getDoc();
		//		m_type=rhs.getType();
		m_longtype=rhs.getLongType();
	}

	~UserDataAssociation() {
	}

public:
	//Setters and getters
	inline CLID getID() const {
		return m_id;
	}
	inline void setID(const CLID& id) {
		m_id=id;
	}
	inline const std::string& getKey() const {
		return m_key;
	}
	inline void setKey(const std::string &key) {
		m_key=key;
	}
	inline const std::string& getLabel() const {
		return m_label;
	}
	inline void setLabel(const std::string &label) {
		m_label=label;
	}
	inline DecoLevel getLevel() const {
		return m_level;
	}
	inline void setLevel(const DecoLevel &level) {
		m_level=level;
	}
	inline IndexType getIndex() const {
		return m_index;
	}
	inline void setIndex(const IndexType &index) {
		m_index=index;
	}
	inline const std::string & getDoc() const {
		return m_doc;
	}
	inline void setDoc(const std::string &doc) {
		m_doc=doc;
	}
	//	inline const std::string & getType() const {
	//		return m_type;
	//	}
	//	inline void setType(const std::string &type) {
	//		m_type=type;
	//	}

	inline const std::string & getLongType() const {
		return m_longtype;
	}
	inline void setLongType(const std::string &type) {
		m_longtype=type;
	}

public:
	//Operators
	inline UserDataAssociation& operator=(const UserDataAssociation &rhs) {
		if (this != &rhs) {
			m_label=rhs.getLabel();
			m_id=rhs.getID();
			m_key=rhs.getKey();
			m_index=rhs.getIndex();
			m_level=rhs.getLevel();
			m_doc=rhs.getDoc();
			//			m_type=rhs.getType();
			m_longtype=rhs.getLongType();
		}
		return *this;
	}

	inline bool operator ==(const UserDataAssociation &rhs) const {
		if (m_level!=rhs.getLevel())
			return false;
		switch (m_level) {
		case NONE:
			return true;
		case FILE:
		case EVENT:
			return m_label==rhs.getLabel()&&m_longtype ==rhs.getLongType();
		case COLLECTION:
			return m_label==rhs.getLabel()&&m_key==rhs.getKey()&&m_longtype
					==rhs.getLongType();
		case ELEMENT:
			return m_index==rhs.getIndex()&&m_label==rhs.getLabel()&&m_key
					==rhs.getKey()&&m_longtype ==rhs.getLongType();
		default:
			return true;
		}
	}

	friend std::ostream& operator<<(std::ostream& out,
			const UserDataAssociation& rhs) // output
	{
		switch (rhs.getLevel()) {
		case NONE:
			out<<"LEVEL:NONE";
			break;
		case FILE:
			out<<"LEVEL:FILE,      LABEL:"<<rhs.getLabel()<<"\tLONGTYPE"
					<<rhs.getLongType();
			break;
		case EVENT:
			out<<"LEVEL:EVENT,     LABEL:"<<rhs.getLabel()<<"\tLONGTYPE"
					<<rhs.getLongType();
			break;
		case COLLECTION:
			out<<"LEVEL:COLLECTION,LABEL:"<<rhs.getLabel()<<"\tKEY:"
					<<rhs.getKey()<<"\tLONGTYPE" <<rhs.getLongType();
			break;
		case ELEMENT:
			out<<"LEVEL:ELEMENT,   LABEL:"<<rhs.getLabel()<<"\tKEY:"
					<<rhs.getKey()<<"\tINDEX:"<<rhs.getIndex()<<"\tLONGTYPE"
					<<rhs.getLongType();
			break;
		default:
			out<<"LEVEL:UNKNOWN";
		}
		return out;
	}

private:
	//fields
	std::string m_label; //path to decoration

	CLID m_id;
	std::string m_key;
	uint32_t m_index;
	DecoLevel m_level;
	std::string m_doc;
//	std::string m_type;
	std::string m_longtype;
};

#endif
