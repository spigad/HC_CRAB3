///////////////////////// -*- C++ -*- /////////////////////////////
#ifndef USERDATASVC_H
#define USERDATASVC_H
/** @file UserDataSvc.h
 * @brief a service to add/read user data in Athena
 * @author Yushu Yao <yyao@lbl.gov> - ATLAS Collaboration
 *$Id: UserDataSvc.h,v 1.11 2008/07/07 05:44:46 yyao Exp $
 */

#include <string>
#include <vector>
#include <map>

#include "AthenaKernel/IUserDataSvc.h"
#include "AthenaKernel/UserDataAssociation.h"

#include "EventInfo/EventID.h"  /* number_type */

#include "GaudiKernel/Service.h"
#include "GaudiKernel/IIncidentListener.h"
#include "GaudiKernel/ITHistSvc.h"   /* ServiceHandle */
#include "GaudiKernel/ServiceHandle.h"
#include "StoreGate/ActiveStoreSvc.h"  /* ServiceHandle */

#include "TTree.h"
#include "TBranch.h"
#include "TBufferFile.h"
#include "Rtypes.h"

#include "Navigation/IAthenaBarCode.h"
#include "Reflex/Reflex.h"
#include "stdint.h"
#include "AthenaKernel/IDictLoaderSvc.h"

template<class TYPE>
  class SvcFactory;
class IIncidentSvc;
class Incident;
class IProperty;
class MsgStream;
class StoreGateSvc;

#if ROOT_VERSION_CODE < ROOT_VERSION(5,19,0)
#define REFLEX_NS Reflex
#else
#define REFLEX_NS ROOT::Reflex
#endif

/** @class UserDataSvc
 * @brief a service to to let user add/access User Data
 *
 * @details
 */
class UserDataSvc : virtual public IUserDataSvc,
    public Service,
    public IIncidentListener {

public:

  struct ElDataEntry {
    std::string m_label;
    AthenaBarCode_t m_abc;
    REFLEX_NS::Object m_object;
  };

  ///dump to MsgStream contents of in memory DB
  void dump() const;

  void el_dump() const;
  void r_el_dump() const;

  //@name Gaudi Service Implementation
  //@{
  virtual StatusCode initialize();
  virtual StatusCode reinitialize();
  virtual StatusCode finalize();
  virtual StatusCode queryInterface(const InterfaceID& riid,
      void** ppvInterface);
  //@}

  void handle(const Incident &inc);

protected:
  friend class SvcFactory<UserDataSvc>;

  // Standard Constructor
  UserDataSvc(const std::string& name, ISvcLocator* svc);

  // Standard Destructor
  virtual ~UserDataSvc()
  {
  }

public:
  // * * * * * * * * * * * * * * * * * * * * * * * *
  // Virtual Methods
  // * * * * * * * * * * * * * * * * * * * * * * * *

  virtual int vdecorate(const std::string& label,
      const std::type_info &decoinfo,
      void* & deco,
      void* & defaultobj,
      void* &tobedeleted,
      const UserDataAssociation::DecoLevel& level,
      const CLID& clid,
      const std::string & key);

  virtual int vgetDecoration(const std::string& label,
      const std::type_info &decoinfo,
      void *&deco,
      const UserDataAssociation::DecoLevel& level,
      const CLID& clid,
      const std::string & key);

  virtual int vgetInMemDecoration(const std::string& label,
      const std::type_info &decoinfo,
      void *&deco,
      const UserDataAssociation::DecoLevel& level,
      const CLID& clid,
      const std::string & key);

  virtual int vdecorateElement(const IAthenaBarCode &abc,
      const std::string& label,
      const std::type_info &decoinfo,
      void* & deco,
      void* & defaultobj,
      void* &tobedeleted);

  virtual int vgetElementDecoration(const IAthenaBarCode &abc,
      const std::string& label,
      const std::type_info &decoinfo,
      void *&deco);

  virtual  std::vector<AthenaBarCode_t> getElListOfABC() ;
  virtual  std::vector<std::string> getElListOfLabel(const AthenaBarCode_t &abc) ;

  virtual int vgetInMemElementDecoration(const IAthenaBarCode &abc,
      const std::string& label,
      const std::type_info &decoinfo,
      void *&deco,
      bool quiet = false);

  virtual  std::vector<AthenaBarCode_t> getInMemElListOfABC() ;
  virtual  std::vector<std::string> getInMemElListOfLabel(const AthenaBarCode_t &abc) ;

private:

  /// @name Private Functions
  //@{
  StoreGateSvc* eventStore();
  int CreateAssociation(const std::string &label,
      const UserDataAssociation::DecoLevel level,
      const std::string &demangledname,
      const std::string &key = std::string(""),
      const CLID clid = 0,
      const UserDataAssociation::IndexType index = 0);
  void SaveAssociations();
  const std::string GetSimpleTypeString(const std::string &label,
      const std::type_info &info) const;
  bool IsSimpleType(const std::type_info &info) const;
  bool IsSimpleType(const std::string &typenamedotname) const;

  const std::type_info & GetSimpleTypeInfoFromName(const std::string &typenamedotname) const;

  const std::string GenerateLabel(const std::string& label,
      const UserDataAssociation::DecoLevel& level,
      const CLID& clid,
      const std::string & key);

  void outputstreamHandler(Property& /* theProp */);

  int64_t el_findEntryID(const IAthenaBarCode &abc,
      const std::string& label);
  std::vector<std::string>::size_type el_findOrAddLabel(const std::string & label);
  std::vector<ElDataEntry>::size_type el_newDataEntry(const IAthenaBarCode &abc,
      const std::string& label,
      const REFLEX_NS::Object &myobject);

  int r_el_init();

  TBufferFile *objectToStream(REFLEX_NS::Object &obj);
  REFLEX_NS::Object *blobToObject(char *buf,int &len, REFLEX_NS::Type& mytype);

  //@}

  /// @name Properties for Writing
  //@{
  ///"m_associations": vector of associations
  std::vector< UserDataAssociation> m_associations;

  ///"m_label2number": mapping from label to the index in the m_associations vector
  std::map< std::string, std::vector<UserDataAssociation>::size_type>
  m_label2number;
  ///"m_number2label": mapping index number to label
  std::map< std::vector<UserDataAssociation>::size_type, std::string>
  m_number2label;
  ///"m_number2address": mapping index number to the address
  std::map<std::vector<UserDataAssociation>::size_type, void **>
  m_number2address;
  ///"m_number2address": mapping index number to the address of the default values
  std::map<std::vector<UserDataAssociation>::size_type, void **>
  m_number2defaultaddress;
  ///"m_numberissimpletype": map index number -> true if is simple type
  std::map< std::vector<UserDataAssociation>::size_type, bool>
  m_numberissimpletype;
  ///"m_numbersetinthisevent": map index number -> true if a DecorateXXX function is called to this label in this event
  std::map< std::vector<UserDataAssociation>::size_type, bool>
  m_numbersetinthisevent;
  ///"m_number2branch": map index number -> TBranch*
  std::map< std::vector<UserDataAssociation>::size_type, TBranch *>
  m_number2branch;
  ///"m_currRunNumber": Current Run # to be written to Userdatatree
  EventID::number_type m_currRunNumber;
  ///"m_currEventNumber": Current Event #
  EventID::number_type m_currEventNumber;
  ///"m_associationtree": tree of association
  TTree *m_associationtree;
  ///"m_userdatatree": tree of Event/Collection level user data
  TTree *m_userdatatree;
  ///"m_userdatatree": tree of File Level user data, will be filled only once
  TTree *m_fileleveluserdatatree;
  //@}


  /// @name Properties for reading, all updated for each input file
  //@{
  /// "m_r_associationtree": tree of association
  TTree *m_r_associationtree;
  /// "m_r_userdatatree": tree of event/collection level user data
  TTree *m_r_userdatatree;
  /// "m_r_fileleveluserdatatree": tree of file level user data
  TTree *m_r_fileleveluserdatatree;
  ///"m_r_associations": vector of associations
  std::vector< UserDataAssociation> m_r_associations;
  ///"m_r_label2number": mapping from label to the index in the m_r_associations vector
  std::map< std::string, std::vector<UserDataAssociation>::size_type>
  m_r_label2number;
  ///"m_r_number2label": mapping index number to label
  std::map< std::vector<UserDataAssociation>::size_type, std::string>
  m_r_number2label;
  ///"m_r_inputfilename": input file name of the current event, might be different for different events
  std::string m_r_inputfilename;
  ///"m_r_fileopened": true if the input file corresponding to the current event has been opened in THistSvc
  bool m_r_fileopened;
  ///"m_r_inputfilecounter": true if the input file corresponding to the current event has been opened in THistSvc
  unsigned int m_r_inputfilecounter;
  ///"m_r_inputstreamname": Name of the stream for input in THistSvc, for current event
  std::string m_r_inputstreamname;
  ///"m_r_currententry": the current entry (line) that the opened file is at
  unsigned int m_r_currententry;
  ///"m_r_synchronized": true if synchronized in this event, to avoid synchronizing multiple times in the same event (when calling getDecoration multiple times)
  bool m_r_synchronized;

  //@}

  /// @name Properties for element level
  //@{
  //Writing
  ///"m_el_decodata": vector of decoration data
  std::vector<ElDataEntry> m_el_decodata;
  ///"m_el_decomap": index of the decodata, map of abc->(labelid->position)
  std::map<AthenaBarCode_t,std::map<uint32_t,uint32_t> > m_el_decomap;
  ///"m_el_label2id: map of the label to label id, so that search integers instead of strings to save time
  std::map<std::string,uint32_t> m_el_label2id;

  std::vector<std::string> m_el_labelarray;
  ///"m_el_label2id: map of the label to label id, so that search integers instead of strings to save time
  std::map<uint32_t,std::string> m_el_id2label;

  TTree *m_el_tree;

  ULong64_t m_el_tree_abc;
  std::string m_el_tree_label;
  std::string m_el_tree_blob;
  std::string m_el_tree_type;

  int m_el_curevent_begin;
  int m_el_curevent_end;

  //Reading
  ///"m_r_el_decomap": index of the decodata, map of abc->(labelid->position(row in root))
  std::map<AthenaBarCode_t,std::map<uint32_t,uint32_t> > m_r_el_decomap;
  ///"m_r_el_label2id: map of the label to label id, so that search integers instead of strings to save time
  std::map<std::string,uint32_t> m_r_el_label2id;

  std::vector<std::string> m_r_el_labelarray;
  ///"m_r_el_id2label: map of the label id to label, so that search integers instead of strings to save time
  std::map<uint32_t,std::string> m_r_el_id2label;

  bool m_r_el_evt_init;
  TTree *m_r_el_tree;

  ULong64_t m_r_el_tree_abc;
  std::string *m_r_el_tree_label;
  std::string *m_r_el_tree_blob;
  std::string *m_r_el_tree_type;

  int m_r_el_curevent_begin;
  int m_r_el_curevent_end;

  //@}

  /// @name Common Properties
  //@{

  /// "m_activeStoreSvc": handle of ActiveStoreSvc
  ServiceHandle<ActiveStoreSvc> m_activeStoreSvc;

  /// "m_thistsvc": handle of THistSvc
  ServiceHandle<ITHistSvc> m_thistsvc;
  /// "m_propTHistSvc": IProperty interface to THistSvc
  IProperty *m_propTHistSvc;

  /// "m_infirstevent": true if it's in the first event
  bool m_infirstevent;

  // "m_inputtypestr":
  StringArrayProperty m_inputfilecoll;
  // "m_inputfilename":
  StringProperty m_outputfilename;
  // "m_inputfilestream":
  StringArrayProperty m_inputfilestream;

  BooleanProperty m_enableReading;
  BooleanProperty m_enableWriting;

  StringProperty m_outputstreamname;
  AthenaOutputStream* m_outputStream;

  //"m_doRead":
  bool m_doRead;
  //"m_doWrite":
  bool m_doWrite;
  bool m_doWriteTransient;

  mutable MsgStream m_log;

  typedef ServiceHandle<IDictLoaderSvc> IDictLoaderSvc_t;
  IDictLoaderSvc_t m_dictLoaderSvc;

  //@}

};

//<<<<<< INLINE PUBLIC FUNCTIONS                                        >>>>>>
//<<<<<< INLINE MEMBER FUNCTIONS                                        >>>>>>

#endif // USERDATASVC_H
