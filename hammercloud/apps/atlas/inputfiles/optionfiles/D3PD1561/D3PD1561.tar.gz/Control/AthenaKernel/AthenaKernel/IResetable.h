#ifndef ATHENAKERNEL_IRESETABLE_H
#define ATHENAKERNEL_IRESETABLE_H

/** @class IResetable
 *  @brief a resetable object (e.g. a SG DataHandle)
 *  @author ATLAS Collaboration
 *  $Id: IResetable.h,v 1.2 2007-03-13 17:14:11 ssnyder Exp $
 **/
class IResetable {
public:
  virtual ~IResetable() {}
  virtual void reset() = 0;    
};

#endif
