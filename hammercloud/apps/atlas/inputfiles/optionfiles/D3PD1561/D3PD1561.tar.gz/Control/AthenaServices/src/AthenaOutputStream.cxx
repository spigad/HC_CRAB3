#include <cassert>

#include <string>
using std::string;

#include <vector>
using std::vector;

// Framework include files
#include "GaudiKernel/GaudiException.h"
#include "GaudiKernel/Tokenizer.h"
#include "GaudiKernel/AlgFactory.h"
#include "GaudiKernel/IAlgManager.h"
#include "GaudiKernel/ISvcLocator.h"
#include "GaudiKernel/IOpaqueAddress.h"
#include "GaudiKernel/IProperty.h"
#include "GaudiKernel/ClassID.h"
#include "GaudiKernel/MsgStream.h"
 
#include "AthenaKernel/IClassIDSvc.h"
#include "AthenaKernel/IAthenaOutputTool.h"
#include "AthenaKernel/IAthenaOutputStreamTool.h"

#include "StoreGate/StoreGateSvc.h"
#include "SGTools/DataProxy.h"
#include "SGTools/ProxyMap.h"
#include "SGTools/SGIFolder.h"

#include "AthenaOutputStream.h"

// Standard Constructor
AthenaOutputStream::AthenaOutputStream(const string& name, 
				       ISvcLocator* pSvcLocator) :
  FilteredAlgorithm(name, pSvcLocator),
  m_dataStore   ( "StoreGateSvc", name ),
  m_pCLIDSvc    ( "ClassIDSvc",   name ),
  m_p2BWritten(string("SG::Folder/")+name+string("_TopFolder"), this),
  m_decoder(string("SG::Folder/")+name+string("_excluded"), this),
  m_streamer(string("AthenaOutputStreamTool/")+name+string("Tool"), this),
  m_helperTools(this) {
  assert( pSvcLocator );
  declareProperty("ItemList",         m_itemList);
  declareProperty("OutputFile",       m_outputName="DidNotNameOutput.root");
  declareProperty("EvtConversionSvc", m_persName="EventPersistencySvc");
  declareProperty("WritingTool",      m_streamer);
  declareProperty("Store",            m_dataStore);
  declareProperty("ProcessingTag",    m_processTag=name);
  declareProperty("ForceRead",        m_forceRead=false);
  declareProperty("PersToPers",       m_persToPers=false);
  declareProperty("ProvideDef",       m_provideDef=false);
  declareProperty("ExtendProvenanceRecord",m_extendProvenanceRecord=true);
  declareProperty("WriteOnExecute",   m_writeOnExecute=true);
  declareProperty("WriteOnFinalize",  m_writeOnFinalize=false);
  declareProperty("TakeItemsFromInput", m_itemListFromTool=false);
  declareProperty("CheckNumberOfWrites", m_checkNumberOfWrites=false);
  declareProperty("ExcludeList",      m_excludeList);
  declareProperty("HelperTools",      m_helperTools);

  // Associate action handlers with the AcceptAlgs, 
  // RequireAlgs & VetoAlgs properties

  m_itemList.declareUpdateHandler(&AthenaOutputStream::itemListHandler, this);
  m_excludeList.declareUpdateHandler(&AthenaOutputStream::excludeListHandler, this);
}

// Standard Destructor
AthenaOutputStream::~AthenaOutputStream()   {
}

// initialize data writer
StatusCode AthenaOutputStream::initialize() 
{
  StatusCode status(StatusCode::FAILURE);
  StatusCode baseStatus = this->FilteredAlgorithm::initialize();

  ATH_MSG_DEBUG ("In initialize ");

  // Reset the number of events written
  m_events = 0;
	
  // set up the SG service:
  StatusCode sc = m_dataStore.retrieve();
  if ( !sc.isSuccess() ) 
  {
    ATH_MSG_FATAL ("Could not locate default store");
    return sc;
  }
  else {
    ATH_MSG_DEBUG ("Found " << m_dataStore.type() << " store.");
  }
  assert( static_cast<bool>(m_dataStore) );

  // set up the CLID  service
  if ( !m_pCLIDSvc.retrieve().isSuccess() ) {
    ATH_MSG_FATAL ("Could not locate default ClassIDSvc");
    return StatusCode::FAILURE;
  }
  assert( static_cast<bool>(m_pCLIDSvc) );

  // Get Output Stream tool for writing
  status = m_streamer.retrieve();
  if (status.isFailure()) {
    ATH_MSG_FATAL ("Unable to find " << m_streamer.type());
    return StatusCode::FAILURE;
  }
  status = m_streamer->connectServices(m_dataStore.type(), m_persName, m_extendProvenanceRecord);
  if (status.isFailure()) {
    ATH_MSG_FATAL ("Unable to connect services");
    return StatusCode::FAILURE;
  }

  // Pointer to Tool Service
  ServiceHandle<IToolSvc> toolSvc("ToolSvc", this->name());
  status = toolSvc.retrieve();
  if (!status.isSuccess()) {
    ATH_MSG_FATAL ("Tool Service not found");
    return(status);
  }

  status = m_helperTools.retrieve();
  if (status.isFailure()) {
    ATH_MSG_FATAL ("Can not find " << m_helperTools);
    return StatusCode::FAILURE;
  }
  ATH_MSG_INFO ("Found " << m_helperTools <<endreq
		<< "Data output: " << m_outputName);

  for (std::vector<ToolHandle<IAthenaOutputTool> >::const_iterator iter = m_helperTools.begin();
		  iter != m_helperTools.end(); iter++) {
    if( !(*iter)->postInitialize().isSuccess() )
    {
      status = StatusCode::FAILURE;
    }
  }

  // move Property values into searchable containers
  translateExcludeProperty();

  ATH_MSG_DEBUG ("End initialize ");
  
  if (status == StatusCode::FAILURE || baseStatus == StatusCode::FAILURE) return StatusCode::FAILURE;
  return status;
}

// terminate data writer
StatusCode AthenaOutputStream::finalize() 
{
  StatusCode sc = StatusCode::SUCCESS;
  for (std::vector<ToolHandle<IAthenaOutputTool> >::const_iterator iter = m_helperTools.begin();
		  iter != m_helperTools.end(); iter++) {
    if( !(*iter)->preFinalize().isSuccess() )
    {
      sc = StatusCode::FAILURE;
    }
  }
  if( m_writeOnFinalize )
  {
    if( !write().isSuccess() )
    {
      sc = StatusCode::FAILURE;
    }
  }

  ATH_MSG_INFO ("Records written: " << m_events);

  if( !m_helperTools.release().isSuccess() )
  {
    sc = StatusCode::FAILURE;
  }
  return sc;
}

StatusCode AthenaOutputStream::execute() 
{
  StatusCode status = StatusCode::SUCCESS;
  for (std::vector<ToolHandle<IAthenaOutputTool> >::const_iterator iter = m_helperTools.begin();
		  iter != m_helperTools.end(); iter++) {
    if( !(*iter)->preExecute().isSuccess() )
    {
      status = StatusCode::FAILURE;
    }
  }
  status = (m_writeOnExecute ? write() : StatusCode::SUCCESS); 
  for (std::vector<ToolHandle<IAthenaOutputTool> >::const_iterator iter = m_helperTools.begin();
		  iter != m_helperTools.end(); iter++) {
    if( !(*iter)->postExecute().isSuccess() )
    {
      status = StatusCode::FAILURE;
    }
  }
  return status;
}


// Work entry point
StatusCode AthenaOutputStream::write() 
{
  bool failed = false;
  // Clear any previously existing item list
  clearSelection();
  // Test whether this event should be output
  if ( isEventAccepted( ) ) 
  {
    // Connect the output file to the service
    StatusCode status = m_streamer->connectOutput(m_outputName);

    // FIXME: this double looping sucks... got to query the
    // data store for object of a given type/key.
    if ( status.isSuccess() )   
    {
      StatusCode currentStatus(StatusCode::FAILURE);
      // First check if there are any new items in the list
      collectAllObjects();

      // print out info about objects collected
      if (m_checkNumberOfWrites) {
          bool checkCountError = false;
          ATH_MSG_DEBUG (" Collected objects: ");
          CounterMapType::iterator cit   = m_objectWriteCounter.begin();
          CounterMapType::iterator clast = m_objectWriteCounter.end();
          bool first = true;
          unsigned int lastCount = 0;
          for (; cit != clast; ++cit) {
              bool isError = false;
              if (first) {
                  lastCount = (*cit).second;
                  first = false;
              }
              else {
                  if (lastCount != (*cit).second) {
                      isError = true;
                      checkCountError = true;
                  }
              }
              if (isError) {
		ATH_MSG_FATAL
		  (" INCORRECT Object/count: " << (*cit).first << ", " <<  (*cit).second 
		   << " should be: " << lastCount);
              }
              else {
		ATH_MSG_INFO
		  (" Object/count: " << (*cit).first << ", " <<  (*cit).second);
              }
          }
          if (checkCountError) {
	    ATH_MSG_FATAL ("Check number of writes failed. See messages above "
			   "to identify which continer is not always written");
	    return StatusCode::FAILURE;
          }
      }
      
      currentStatus = m_streamer->streamObjects(m_objects);
      // Do final check of streaming
      if ( !currentStatus.isSuccess() ) {
	if ( !currentStatus.isRecoverable() ) {
          ATH_MSG_FATAL ("streamObjects failed.");
	  failed = true;
	} else {
          ATH_MSG_DEBUG ("streamObjects failed.");
	}
      }

      currentStatus = m_streamer->commitOutput();
      if ( !currentStatus.isSuccess() ) 
      {
        ATH_MSG_FATAL ("commitOutput failed.");
	failed = true;
      }

      clearSelection();
      if (!failed) ++m_events;
    }
  }
  if (failed) {
    return StatusCode::FAILURE;
  }
  return StatusCode::SUCCESS;
}

// Clear collected object list
void AthenaOutputStream::clearSelection()     
{
  m_objects.erase(m_objects.begin(), m_objects.end());
}

void AthenaOutputStream::collectAllObjects() {
  if (m_itemListFromTool) { 
     if ( !m_streamer->getInputItemList(&*m_p2BWritten).isSuccess() ) {
       ATH_MSG_WARNING
	 ("collectAllObjects() could not get ItemList from Tool.");
     }
  } 
  const bool CHECKVALIDCLID(true);
  m_p2BWritten->updateItemList(CHECKVALIDCLID);

  addFolderObjects(*m_p2BWritten);
}

//FIXME refactor: move this in folder. Treat as composite
void AthenaOutputStream::addFolderObjects(const SG::IFolder& folder) {

/*
  std::multimap<CLID,std::string>::iterator bis = m_CLIDKeyPairs.begin();
  while (bis != m_CLIDKeyPairs.end()) {
    m_msg << MSG::DEBUG << "m_CLIDKeyPairs (" << bis->first << "," 
                        << bis->second << ")" << endreq;
    ++bis;
  }
*/

  // Collect all objects that need to be persistified:
  SG::IFolder::const_iterator i(folder.begin()); 
  SG::IFolder::const_iterator iEnd(folder.end()); 
  while (i != iEnd) { 
    addItemObjects(*i, msg()); 
    ++i; 
  }
}

//FIXME refactor: move this in folder. Treat as composite
void AthenaOutputStream::addItemObjects(const SG::FolderItem& item, MsgStream&)   
{
  ATH_MSG_DEBUG ("addItemObjects("<< item.id() << ",\"" 
		 << item.key() << "\") called");

  bool useThisItem = true;
  static const std::string wildCard = "*";
  std::string xkey1, xkey2;

  // Check if it's in the exclusion list
  std::multimap<CLID,std::string>::const_iterator c2k_it = m_CLIDKeyPairs.lower_bound(item.id());

  if ( c2k_it != m_CLIDKeyPairs.end() )
  {
     // Do the simple cases of full key or full wildcard
     if (c2k_it->second == wildCard) useThisItem = false;  // wildcard first
     else {
        // Loop over the instances of the clid in the multimap
        while (c2k_it != m_CLIDKeyPairs.upper_bound(item.id())) {
           // Look for wildcard in key
           std::string::size_type xsep = c2k_it->second.find(wildCard);
           // If wildcard not found, then check whether the second is an excluded key
           if (xsep == std::string::npos) {
              if (c2k_it->second == item.key()) useThisItem = false;
           }
           // Otherwise take before and after wildcard for later use
           else {
              xkey1 = breakAtSep(c2k_it->second,wildCard).first;
              xkey2 = breakAtSep(c2k_it->second,wildCard).second;
           }
           ++c2k_it;
        }
     }
  }

  // If no exit on simple exclude
  //m_msg << MSG::DEBUG << "useThisItem set to " << useThisItem << endreq; 
  if (useThisItem) {
    SG::ConstProxyIterator iter;
    SG::ConstProxyIterator end;
    // Look for the clid in storegate
    if ( (m_dataStore->proxyRange(item.id(), iter, end)).isSuccess() ) {
      bool added(false);
      // For item list entry
      // Check for wildcard within string, i.e. 'xxx*yyy', and save
      // the matching parts
      std::string key1, key2;
      key1 = breakAtSep(item.key(),wildCard).first;
      key2 = breakAtSep(item.key(),wildCard).second;
      SG::TransientAddress* tAddr = 0;
      // Now loop over any found proxies
      for (; iter != end; iter++) {
        SG::DataProxy* itemProxy(iter->second);
        // Does this key match the proxy key name - allow for wildcarding and aliases
        bool keyMatch =  (item.key() == "*" || item.key() == itemProxy->name()
                          || itemProxy->alias().find(item.key()) != itemProxy->alias().end() );
        if (!keyMatch) {
            // Allow wildcarding within the key
            if (key1.size() && key2.size()) {
                // Must match both pre- and post- strings
                if (itemProxy->name().find(key1) != std::string::npos &&
                    itemProxy->name().find(key2) != std::string::npos) {
                    keyMatch = true;
                }
            }
            else if (key1.size()) {
                // Must match both pre- and post- strings
                if (itemProxy->name().find(key1) != std::string::npos) {
                    keyMatch = true;
                }
            }
            else if (key2.size()) {
                // Must match both pre- and post- strings
                if (itemProxy->name().find(key2) != std::string::npos) {
                    keyMatch = true;
                }
            }
        }

        // Now undo the flag based on a similar analysis of excluded wildcard keys
        if (keyMatch) {
            // Allow wildcarding within the key
            if (xkey1.size() && xkey2.size()) {
                // Must match both pre- and post- strings
                if (itemProxy->name().find(xkey1) != std::string::npos &&
                    itemProxy->name().find(xkey2) != std::string::npos) {
                    keyMatch = false;
                }
            }
            else if (xkey1.size()) {
                // Must match both pre- and post- strings
                if (itemProxy->name().find(xkey1) != std::string::npos) {
                    keyMatch = false;
                }
            }
            else if (xkey2.size()) {
                // Must match both pre- and post- strings
                if (itemProxy->name().find(xkey2) != std::string::npos) {
                    keyMatch = false;
                }
            }
        }

        // All right, it passes all the gobbledegook filtering
        if (keyMatch) {
	   if (m_forceRead && itemProxy->isValid()) itemProxy->accessData();
	   if (0 != itemProxy->object()) {
	      m_objects.push_back(itemProxy->object());
	      ATH_MSG_DEBUG
		(" Added object " << item.id() << ",\"" 
		 << itemProxy->name() << "\"");
	      added=true;
              if (m_checkNumberOfWrites) {
                  std::string tn;
                  StatusCode sc = m_pCLIDSvc->getTypeNameOfID(item.id(), tn);
                  if (!sc.isSuccess()) {
		    ATH_MSG_ERROR
		      (" Could not get type name for id " << item.id() << ",\"" 
		       << itemProxy->name());
                  } else {
                      tn += '_' + itemProxy->name();
                      CounterMapType::iterator cit = m_objectWriteCounter.find(tn);
                      if (cit == m_objectWriteCounter.end()) {
                          // First time through
                          std::pair<CounterMapType::iterator,bool> result = 
                              m_objectWriteCounter.insert(CounterMapType::value_type(tn,1));
                      } else {
			  // increment
			  (*cit).second++;
		      }
		  }
	      }
            } else if (!m_forceRead && m_persToPers && itemProxy->isValid()) {
              tAddr = itemProxy->transientAddress();
	    } //if data object there 
	  } //if key matches
      } // proxy loop
      if (!added) {
	ATH_MSG_DEBUG (" No object matching " 
		       << item.id() << ",\"" << item.key()  << "\" found");
        if (m_persToPers && tAddr != 0) {
          DataObject* ics = new DataObject();
          SG::DataProxy* proxy = new SG::DataProxy(ics, tAddr);
          m_objects.push_back(proxy->object());
        } else if (m_provideDef) {
          tAddr = new SG::TransientAddress(item.id(), item.key());
          DataObject* ics = new DataObject();
          SG::DataProxy* proxy = new SG::DataProxy(ics, tAddr);
          m_objects.push_back(proxy->object());
        }
      }
    } else {
      ATH_MSG_DEBUG 
	(" Failed to receive proxy iterators from StoreGate for " 
	 << item.id() << ",\"" << item.key()  << "\". Skipping");
    }
  } else {
    ATH_MSG_DEBUG
      (" Object being excluded based on property setting "
       << item.id() << ",\"" << item.key()  << "\". Skipping");
  }
}

void
AthenaOutputStream::itemListHandler( Property& /* theProp */ )
{
  //assuming concrete SG::Folder also has an itemList property
  IProperty *pAsIProp(0);
  if ((m_p2BWritten.retrieve()).isFailure() ||
      0 == (pAsIProp=dynamic_cast<IProperty*>(&*m_p2BWritten)) || 
      (pAsIProp->setProperty(m_itemList)).isFailure()) 
    throw GaudiException("Folder property [itemList] not found", name(), 
			 StatusCode::FAILURE); 
}

void
AthenaOutputStream::excludeListHandler( Property& /* theProp */ )
{
    translateExcludeProperty();
}

void
AthenaOutputStream::translateExcludeProperty()
{
  ATH_MSG_DEBUG
    ("translateExcludeProperty list has size " << m_excludeList.value().size());
  std::vector<std::string>::const_iterator tempit = m_excludeList.value().begin();
  // Loop over elements of property list
  while (tempit != m_excludeList.value().end() ) {
    ATH_MSG_DEBUG ("Exclude List contains " << *tempit);

    // pull apart the pieces in the property list value
    size_t sep(tempit->rfind('#'));
    std::string typeName (tempit->substr(0,sep));
    std::string skey;
    if (sep != std::string::npos) skey = tempit->substr(sep+1);

    // Now record the list as maps of clid <-> key pairs for fast lookup

    // First assume "typeName" is actually a clid
    CLID clid(atoi(typeName.c_str()));
    // If it is not, then look up the clid
    if (clid==CLID(0)) {
       if (m_pCLIDSvc.retrieve().isSuccess()) {
          StatusCode sc = m_pCLIDSvc->getIDOfTypeName(typeName, clid);
          if (!sc.isSuccess()) {
	    ATH_MSG_WARNING ("getIDOfTypeName failed for " << typeName);
          }
       }
       else {
	 ATH_MSG_WARNING ("Could not retrieve CLIDSvc");
       }
    }
    // if after all this you have a valid clid, record it
    if (clid!=CLID(0)) {
       m_CLIDKeyPairs.insert(std::make_pair(clid,skey));
       //m_KeyCLIDPairs.insert(std::make_pair(skey,clid));
    }
    else {
      ATH_MSG_WARNING ("Could not construct clid for " << typeName);
    }

    ++tempit;
  }
  ATH_MSG_DEBUG ("translateExcludeProperty ended with "
		 << m_CLIDKeyPairs.size() << " excluded type,key");
}

std::pair<std::string,std::string> AthenaOutputStream::breakAtSep(const std::string portia, 
                                                                  const std::string sepchar)
{
   std::string key1, key2;
   std::string::size_type sep = portia.find( sepchar );
   if ( sep != std::string::npos ) { // found a '*' 
       key1 = portia.substr(0, sep);
       std::string::size_type end = portia.size();
       key2 = portia.substr(sep + 1, end);
   }
   return std::make_pair(key1,key2);
}

