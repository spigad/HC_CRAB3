// $Id: PyROOTTTreePatch.cxx,v 1.5 2009-02-17 19:26:31 ssnyder Exp $
/**
 * @file RootUtils/src/pyroot/PyROOTTTreePatch.cxx
 * @author scott snyder
 * @date Nov 2007
 * @brief Performance improvements and fixes for root's pythonized @c TTree.
 */

#include "RootUtils/PyROOTTTreePatch.h"
#include "Python.h"
#include "TClass.h"
#include "TClassRef.h"
#include "TTree.h"
#include "TChain.h"
#include "TBranch.h"
#include "TBranchElement.h"
#include "TLeaf.h"
#include "TROOT.h"
#include "Api.h"
#include <map>
#include <vector>


//***************************************************************************
// Most of the PyROOT headers are not exported.
// So we need to copy pieces of some PyROOT declarations here.
//

namespace PyROOT {

class PyRootClass {
public:
  PyHeapTypeObject fType;
  TClassRef fClass;
};

class ObjectProxy {
public:
  enum EFlags { kNone = 0x0, kIsOwner = 0x0001, kIsReference = 0x0002 };

  TClass* ObjectIsA() const
  {
#if ROOT_VERSION_CODE >= ROOT_VERSION(5,22,0)
         return ((PyRootClass*)ob_type)->fClass.GetClass(); // may return null
#else
    return fClass.GetClass();                        // may return null
#endif
  }

  void* GetObject() const
  {
    if ( fObject && ( fFlags & kIsReference ) )
      return *(reinterpret_cast< void** >( const_cast< void* >( fObject ) ));
    else
      return const_cast< void* >( fObject );        // may be null
  }

  void HoldOn() { fFlags |= kIsOwner; }

  PyObject_HEAD
  void*     fObject;
#if ROOT_VERSION_CODE < ROOT_VERSION(5,22,0)
  TClassRef fClass;
#endif
  int       fFlags;
};

R__EXTERN PyTypeObject ObjectProxy_Type;

template< typename T >
inline Bool_t ObjectProxy_Check( T* object )
{
  return object && PyObject_TypeCheck( object, &ObjectProxy_Type );
}

PyObject* BindRootObjectNoCast( void* object, TClass* klass, Bool_t isRef = kFALSE );
PyObject* BindRootObject( void* object, TClass* klass, Bool_t isRef = kFALSE );

union TParameter;

class TConverter {
public:
  virtual ~TConverter() {}

public:
  virtual Bool_t SetArg( PyObject*, TParameter&, G__CallFunc* = 0 ) = 0;
  virtual PyObject* FromMemory( void* address );
  virtual Bool_t ToMemory( PyObject* value, void* address );
};

TConverter* CreateConverter( const std::string& fullType, Long_t user = -1 );

class PyCallable;

R__EXTERN PyTypeObject MethodProxy_Type;

struct MethodInfo_t;

class MethodProxy
{
public:
  typedef std::map< Long_t, Int_t >  DispatchMap_t;
  typedef std::vector< PyCallable* > Methods_t;

  void Set( const std::string& name, std::vector< PyCallable* >& methods );
  const std::string& GetName() const;

public:               // public, as the python C-API works with C structs
  PyObject_HEAD
  ObjectProxy*   fSelf;        // The instance it is bound to, or NULL
  MethodInfo_t*  fMethodInfo;
};

MethodProxy* MethodProxy_New(
         const std::string& name, std::vector< PyCallable* >& methods )
{
  MethodProxy* pymeth = (MethodProxy*)MethodProxy_Type.tp_new( &MethodProxy_Type, 0, 0 );
  pymeth->Set( name, methods );
  return pymeth;
}

MethodProxy* MethodProxy_New( const std::string& name, PyCallable* method )
{
  std::vector< PyCallable* > p;
  p.push_back( method );
  return MethodProxy_New( name, p );
}



struct MethodInfo_t {
  std::string                 fName;
  MethodProxy::DispatchMap_t  fDispatchMap;
  MethodProxy::Methods_t      fMethods;
  std::string                 fDoc;
  Bool_t                      fIsSorted;

  int* fRefCount;
};

const std::string& MethodProxy::GetName() const { return fMethodInfo->fName; }

class PyCallable {
public:
  virtual ~PyCallable() {}

public:
  virtual PyObject* GetSignature() = 0;
  virtual PyObject* GetPrototype() = 0;
  virtual PyObject* GetDocString();
  virtual Int_t GetPriority();

public:
  virtual PyObject* operator()( ObjectProxy* self, PyObject* args, PyObject* kwds ) = 0;
};

class TTreeMemberFunction : public PyCallable {
protected:
  TTreeMemberFunction( MethodProxy* org ) { Py_INCREF( org ); fOrg = org; }
  ~TTreeMemberFunction();

public:
  virtual PyObject* GetSignature();
  MethodProxy* fOrg;
};

class TTreeSetBranchAddress : public TTreeMemberFunction {
public:
  TTreeSetBranchAddress( MethodProxy* org ) : TTreeMemberFunction( org ) {}

public:
  virtual PyObject* GetPrototype();
  virtual PyObject* operator()( ObjectProxy* self, PyObject* args, PyObject* kwds );
};

namespace Utility {
int GetBuffer( PyObject* pyobject, char tc, int size, void*& buf, Bool_t check = kTRUE );

}


} // namespace PyROOT

using namespace PyROOT;


//=========================================================================



namespace RootUtils {


// Interned string constants that we use for dictionary lookups.
static PyObject* elements_str = 0;
static PyObject* notifier_str = 0;
static PyObject* pynotify_str = 0;


/**
 * @brief Tree notification handler.
 *
 * This is the tree notification handler.  When it's @c Notify
 * method is called, we need to do two things.  First, clear
 * the cached branches/leaves.  Second, call any Python notification
 * handler.
 */
class TreeNotifier
  : public TNamed
{
public:
  /**
   * @brief Constructor.
   * @param tree The tree for which we're creating the notification.
   * @param treeobj_ref A weak reference to the tree for which we're creating
   *                    the notification.  We take ownership of the reference
   *                    object.
   * @param elements The __elements__ dictionary from the tree.
   */
  TreeNotifier (TTree* tree, PyObject* treeobj_ref, PyObject* elements);

  /// Destructor.
  virtual ~TreeNotifier();

  /// Root notification hook.
  virtual Bool_t Notify();

private:
  /// A weak reference to the Python object for the tree.
  /// Making it a reference prevents a reference cycle.
  PyObject* m_treeobj_ref;

  /// The tree's __elements__ dictionary.
  PyObject* m_elements;

  /// Notification tree.
  TObject* m_chain;
};


/**
 * @brief Constructor.
 * @param tree The tree for which we're creating the notification.
 * @param treeobj_ref A weak reference to the tree for which we're creating
 *                    the notification.  We take ownership of the reference
 *                    object.
 * @param elements The __elements__ dictionary from the tree.
 */
TreeNotifier::TreeNotifier (TTree* tree,
                            PyObject* treeobj_ref,
                            PyObject* elements)
  : m_treeobj_ref (treeobj_ref),
    m_elements (elements),
    m_chain (tree->GetNotify())
{
  // Construct a name.
  std::string name = "Notifier for tree ";
  name += tree->GetName();
  SetName (name.c_str());

  // Manage refcounts.
  Py_INCREF (m_elements);

  // We acquire ownership of treeobj_ref.
}


/**
 * @brief Destructor.
 */
TreeNotifier::~TreeNotifier()
{
  Py_XDECREF (m_elements);
  Py_XDECREF (m_treeobj_ref);
}


/**
 * @brief Root notification hook.
 */
Bool_t TreeNotifier::Notify()
{
  // Clear the element cache.
  PyDict_Clear (m_elements);

  // Intern __pynotify__ if needed.
  if (pynotify_str == 0)
    pynotify_str = PyString_InternFromString("__pynotify__");

  // Look for a notification object.
  PyObject* treeobj = PyWeakref_GetObject (m_treeobj_ref);
  if (treeobj) {
    PyObject** dictptr = _PyObject_GetDictPtr (treeobj);
    if (dictptr && *dictptr) {
      PyObject* notobj = PyObject_GetItem (*dictptr, pynotify_str);
      if (notobj) {
        // Got it --- call @c Notify.
        PyObject* ret =
          PyObject_CallMethod (notobj, const_cast<char*> ("Notify"), NULL);
        if (!ret) return 0;
        Py_DECREF (ret);
      }
      else
        PyErr_Clear();
    }
  }
  return true;
}


/**
 * @brief Convert a leaf to a Python value.
 * @param leaf The leaf to convert.
 * @return The Python object.
 */
PyObject* leafToValue (TLeaf* leaf)
{
  if ( 1 < leaf->GetLenStatic() || leaf->GetLeafCount() ) {
    // array types
    std::string typeName = leaf->GetTypeName();
    std::string xname = typeName;
    xname += '*';
    TConverter* pcnv = CreateConverter( xname, leaf->GetNdata() );
    void* address = (void*)leaf->GetValuePointer();
    PyObject* value = pcnv->FromMemory( &address );
    delete pcnv;
      
    return value;
  } else {
    // value types
    TConverter* pcnv = CreateConverter( leaf->GetTypeName() );
    PyObject* value = pcnv->FromMemory( (void*)leaf->GetValuePointer() );
    delete pcnv;

    return value;
  }
}


/**
 * @brief Convert a leaf to a Python value, and enter into the element cache.
 * @param leaf The leaf to convert.
 * @param nameobj Python object for the element name.
 * @param elements The element cache dictionary.
 * @return The Python object.
 */
PyObject*
leafToValueCache (TLeaf* leaf, PyObject* nameobj, PyObject* elements)
{
  // Get a Python object holding the leaf.
  PyObject* leafobj = BindRootObject (leaf, TLeaf::Class());
  if (!leafobj)
    return 0;

  // Pack it into a tuple.
  PyObject* elt = PyTuple_Pack (1, leafobj);
  Py_XDECREF (leafobj);
  if (!elt)
    return 0;

  // And add it to the elements dictionary.
  int stat = PyObject_SetItem (elements, nameobj, elt);
  Py_XDECREF(elt);
  if (stat < 0)
    return 0;

  // Now convert the leaf to its value.
  return leafToValue (leaf);
}


/**
 * @brief Convert a branch to a Python value and cache it.
 * @param branch The branch.
 * @param branchobj The branch, as a Python object.
 * @param nameobj Python object for the element name.
 * @param elements The element cache dictionary.
 */
PyObject*
branchToValueCache (TBranch* branch,
                    PyObject* branchobj,
                    PyObject* nameobj,
                    PyObject* elements)
{
  // Get the branch class.
  // Could think about caching the class too --- but probably not worth it.
  TClass* klass = gROOT->GetClass( branch->GetClassName() );
  PyObject* ret = 0;

  // Bind the branch's object to a Python object.
  if ( klass && branch->GetAddress() )
    ret = BindRootObjectNoCast( *(char**)branch->GetAddress(), klass );

  // If we succeeded, add to the cache.
  // A 2-tuple with the branch and the object.
  if (ret) {
    PyObject* elt = PyTuple_Pack (2, branchobj, ret);
    if (!elt) {
      Py_XDECREF(ret);
      return 0;
    }
    if (PyObject_SetItem (elements, nameobj, elt) < 0) {
      Py_XDECREF(elt);
      Py_XDECREF(ret);
      return 0;
    }
  }
  return ret;
}


/**
 * @brief Convert a branch to a Python value and cache it.
 * @param branch The branch.
 * @param nameobj Python object for the element name.
 * @param elements The element cache dictionary.
 */
static PyObject*
branchToValueCache (TBranch* branch,
                    PyObject* nameobj,
                    PyObject* elements)
{
  // First need to make a Python object holding the branch.
  PyObject* branchobj = BindRootObject (branch, TBranch::Class());
  if (!branchobj)
    return 0;
  PyObject* ret = branchToValueCache (branch, branchobj, nameobj, elements);
  Py_XDECREF (branchobj);
  return ret;
}


/**
 * @brief Enable a @c TBranch and any descendants it might have.
 * @param branch The branch to enable.
 */
static void enableBranch (TBranch* branch)
{
  if (TBranchElement* br = dynamic_cast<TBranchElement*> (branch)) {
    TObjArray* branches = br->GetListOfBranches();
    int nbranches = branches->GetEntriesFast();
    for (int i = 0; i < nbranches; i++) {
      TBranch* b = dynamic_cast<TBranch*> (branches->At(i));
      enableBranch (b);
    }
  }

  if (branch) {
    if (strcmp (branch->GetName(), "TObject") != 0 &&
        strcmp (branch->GetName(), "TMatrixTBase<float>") != 0)
    {
      branch->ResetBit (kDoNotProcess);

      // Saved read entry may not be correct now --- invalidate it.
      branch->ResetReadEntry();
    }
  }
}


/**
 * @brief Enable a branch if not already enabled.
 * @param branch The branch.
 */
void checkEnable (TBranch* branch)
{
  // User has requested this branch for the first time for this tree.
  // If it's not enabled, force it on.
  // Note: TTree::SetBranchStatus has problems if there are multiple
  // branches with the same name (can happen with split branches).
  // So don't use that here.
  if (branch->TestBit (kDoNotProcess)) {
    enableBranch (branch);

    TTree* tree = branch->GetTree();

    // We're likely not at the correct entry.
    // Move to the proper place.
    Long64_t entry = tree->GetReadEntry();

    // Work around the root TChain::GetReadEntry bug.
    // Note that this is fixed in later root versions, so check
    // that we actually need to fix it.
    if (TChain* chain = dynamic_cast<TChain*> (tree)) {
      int treenum = tree->GetTreeNumber();
      if (treenum != -1) {
        Long64_t offs = chain->GetTreeOffset()[treenum];
        if (entry >= 0 && entry < offs)
          entry += offs;
      }
    }

    Long64_t local_entry = tree->LoadTree (entry);
    branch->GetEntry (local_entry);
  }
}


/**
 * @brief getattr implementation for @c TTree.
 * @param args The Python arguments.
 * @return The Python return value.
 */
PyObject* treeGetattr( PyObject*, PyObject* args )
{
  // Allow access to branches/leaves as if they are data members

  // Decode the arguments.
  ObjectProxy* self = 0; const char* name = 0;
  if ( ! PyArg_ParseTuple( args, const_cast< char* >( "O!s:__getattr__" ),
                           &ObjectProxy_Type, &self, &name ) )
    return 0;

  // Avoid wasting time for special python names.
  if (name[0] == '_' && name[1] == '_') {
    PyErr_Format( PyExc_AttributeError,
                  "TTree object has no attribute \'%s\'", name );
    return 0;
  }

  // Intern strings.
  if (elements_str == 0) {
    elements_str = PyString_InternFromString("__elements__");
    notifier_str = PyString_InternFromString("__notifier__");
  }

  // Get our name argument as a py string.
  // This must succeed if the ParseTuple did.
  // Note that this is a borrowed reference.
  PyObject* nameobj = PyTuple_GET_ITEM (args, 1);

  // Find the __elements__ dictionary.  If it's there, try looking
  // up the name there first.
  PyObject** dictptr = _PyObject_GetDictPtr ((PyObject*)self);
  PyObject* elements = 0;
  if (dictptr && *dictptr) {
    // Note: returns a borrowed reference.
    elements = PyDict_GetItem (*dictptr, elements_str);
  }
  if (elements) {
    PyObject* elt = PyObject_GetItem (elements, nameobj);
    if (elt) {
      // Got it.  Now figure out what we have, and see if any saved
      // buffer is still valid.
      int len = PyObject_Length (elt);
      if (len == 1) {
        // Leaf.  elt[0] is the leaf.
        // Possible further optimizations:
        //  For an atomic leaf, we can cache the converter across calls.
        //  Not done yet because there's no good place to put the TConverter
        //  (I'm too lazy to make a new type, etc. to represent it to python).
        //  For array leaves the converter and buffer can be reused
        //  only if the size of the array doesn't change.
        PyObject* leafobj = PySequence_GetItem (elt, 0);
        if (ObjectProxy_Check (leafobj)) {
          ObjectProxy* leafprox = (ObjectProxy*)leafobj;
          TLeaf* leaf =
            (TLeaf*)leafprox->ObjectIsA()->DynamicCast( TLeaf::Class(),
                                                     leafprox->GetObject() );
          if (leaf) {
            checkEnable (leaf->GetBranch());
            PyObject* ret = leafToValue (leaf);
            Py_XDECREF (leafobj);
            Py_XDECREF(elt);
            return ret;
          }
        }
        Py_DECREF (leafobj);
      }

      else if (len == 2) {
        // Branch type.
        // elt[0] is the branch, elt[1] is the obj.
        PyObject* branchobj = PySequence_GetItem (elt, 0);
        if (ObjectProxy_Check (branchobj)) {
          ObjectProxy* branchprox = (ObjectProxy*)branchobj;
          TBranch* branch =
            (TBranch*)branchprox->ObjectIsA()->DynamicCast( TBranch::Class(),
                                                     branchprox->GetObject() );
          if (branch) {
            PyObject* objobj = PySequence_GetItem (elt, 1);
            if (ObjectProxy_Check (objobj)) {
              checkEnable (branch);
              ObjectProxy* obj = (ObjectProxy*)objobj;
              // Now check that the address hasn't moved.
              // If not, we can just return the object as-is.
              // Otherwise, we need to make a new one.
              if (*(char**)branch->GetAddress() != obj->GetObject())
                objobj = branchToValueCache (branch, branchobj,
                                             nameobj, elements);
              Py_XDECREF (elt);
              Py_XDECREF (branchobj);
              return objobj;
            }
            Py_DECREF (objobj);
          }
        }
        Py_DECREF (branchobj);
      }

      // Something wasn't right.
      // Continue, and remake the cache.
      printf ("drop cache!\n");
      Py_XDECREF (elt);
    }
    else
      PyErr_Clear();
  }

  // get hold of actual tree
  TTree* tree =
    (TTree*)self->ObjectIsA()->DynamicCast( TTree::Class(),self->GetObject() );

  if (!elements) {
    // Need to make the __elements__ dict.
    PyErr_Clear();
    elements = PyDict_New();
    if (!elements)
      return 0;
    int stat = PyObject_SetAttr ((PyObject*)self, elements_str, elements);
    Py_XDECREF (elements);
    if (stat < 0)
      return 0;

    // Make the notifier too.
    PyObject* treeobj_ref = PyWeakref_NewRef ((PyObject*)self, 0);
    if (!treeobj_ref)
      return 0;
    TNamed* notifier = new TreeNotifier (tree, treeobj_ref, elements);
    PyObject* notobj = BindRootObjectNoCast (notifier, TNamed::Class());
    ((ObjectProxy*)notobj)->HoldOn();
    stat = PyObject_SetAttr ((PyObject*)self, notifier_str, notobj);
    Py_XDECREF (notobj);
    if (stat < 0)
      return 0;
    tree->SetNotify (notifier);
  }

  // Search for branch first (typical for objects)
  TBranch* branch = tree->GetBranch( name );
  if ( branch ) {
    checkEnable (branch);
    PyObject* ret = branchToValueCache (branch, nameobj, elements);
    if (ret)
      return ret;
  }

  // If not, try leaf
  TLeaf* leaf = tree->GetLeaf( name );
  if ( leaf ) {
    checkEnable (leaf->GetBranch());
    return leafToValueCache (leaf, nameobj, elements);
  }

  // Didn't find it.
  PyErr_Format( PyExc_AttributeError,
                "\'%s\' object has no attribute \'%s\'",
                tree->IsA()->GetName(), name );
  return 0;
}


/**
 * @brief Implementation for pythonization of @c TTree::SetNotify.
 * @param args The Python arguments.
 */
PyObject* treeSetNotify (PyObject*, PyObject* args)
{
  // Decode the objects --- the tree and the notifier object.
  PyObject* self = 0;
  PyObject* obj = 0;
  if ( ! PyArg_ParseTuple( args, const_cast< char* >( "OO:SetNotify" ),
                           &self, &obj ) )
    return 0;

  // Intern string if needed.
  if (pynotify_str == 0)
    pynotify_str = PyString_InternFromString("__pynotify__");

  // Install the object.
  int stat = PyObject_SetAttr (self, pynotify_str, obj);
  if (stat < 0)
    return 0;

  Py_INCREF (Py_None);
  return Py_None;
}


/**
 * @brief Implementation for pythonization of @c TTree::SetNotify.
 * @param args The Python arguments.
 */
PyObject* treeGetNotify (PyObject*, PyObject* args)
{
  // Decode the objects --- the tree.
  PyObject* self = 0;
  if ( ! PyArg_ParseTuple( args, const_cast< char* >( "O:SetNotify" ),
                           &self ) )
    return 0;

  // Intern string if needed.
  if (pynotify_str == 0)
    pynotify_str = PyString_InternFromString("__pynotify__");

  // Retrieve the notifier.
  PyObject* ret = PyObject_GetAttr (self, pynotify_str);
  if (!ret) {
    PyErr_Clear();
    Py_INCREF (Py_None);
    ret = Py_None;
  }
  return ret;
}


/**
 * @brief Pythonization of @c TBranch::SetAddress.
 * @param args The Python arguments.
 */
PyObject* branchSetAddress (PyObject*, PyObject* args)
{
  // Decode arguments --- the branch and the buffer.
  ObjectProxy* self = 0;
  PyObject* address = 0;
  if ( ! PyArg_ParseTuple( args, const_cast< char* >( "O!O:SetBranchAddress" ),
                           &ObjectProxy_Type, &self, &address ) )
    return 0;

  // The branch as a Root object.
  TBranch* branch =
    (TBranch*)self->ObjectIsA()->DynamicCast( TBranch::Class(),
                                              self->GetObject() );

  if ( ! branch ) {
    PyErr_SetString( PyExc_TypeError,
                     "TBranch::SetAddress must be called with a "
                     "TBranch instance as first argument" );
    return 0;
  }

  // Convert the buffer argument to an address.
  void* buf = 0;
  if ( ObjectProxy_Check( address ) ) {
    if ( ((ObjectProxy*)address)->fFlags & ObjectProxy::kIsReference )
      buf = (void*)((ObjectProxy*)address)->fObject;
    else
      buf = (void*)&((ObjectProxy*)address)->fObject;
  } else
    Utility::GetBuffer( address, '*', 1, buf, kFALSE );

  // Make the call and return.
  if ( buf != 0 )
    branch->SetAddress( buf );

  Py_INCREF( Py_None );
  return Py_None;
}


/**
 * @brief Helper to install a method in a Python class.
 * @param pyclass The Python class.
 * @param pdef A PyMethodDef object.
 * @param name The method name.
 * @param cfunc The C function to install.
 */
void installMethod (PyObject* pyclass,
                    PyMethodDef& pdef, 
                    const char* name,
                    PyCFunction cfunc)
{
  pdef.ml_name = const_cast<char*> (name);
  pdef.ml_meth = cfunc;
  pdef.ml_flags = METH_VARARGS;
  pdef.ml_doc = 0;

  PyObject* func = PyCFunction_New (&pdef, 0);
  PyObject* method = PyMethod_New (func, 0, pyclass);
  Bool_t isOK = PyObject_SetAttrString (pyclass, pdef.ml_name, method) == 0;

  if (PyErr_Occurred())
    fprintf (stderr, "Py error");
  else if (!isOK) {
    fprintf (stderr, "Could not add method %s\n", name);
  }
}


/**
 * @brief Install the PyROOT patches.
 * @param tree_pyclass The @c TTree Python class.
 * @param chain_pyclass The @c TChain Python class.
 * @param branch_pyclass The @c TBranch Python class.
 */
void PyROOTTTreePatch::Initialize (PyObject* tree_pyclass,
                                   PyObject* chain_pyclass,
                                   PyObject* branch_pyclass)
{
# define INSTALL_METHOD(pyclass, name, func) do {  \
  static PyMethodDef pdef;                     \
  installMethod (pyclass, pdef, name, (PyCFunction)func); \
  } while(0)

  INSTALL_METHOD (tree_pyclass, "__getattr__", treeGetattr);
  INSTALL_METHOD (tree_pyclass, "SetNotify",   treeSetNotify);
  INSTALL_METHOD (tree_pyclass, "GetNotify",   treeGetNotify);
  INSTALL_METHOD (branch_pyclass, "SetAddress",   branchSetAddress);
#undef INSTALL_METHOD

  MethodProxy* original = (MethodProxy*)PyObject_GetAttrString(
         chain_pyclass, const_cast< char* >( "SetBranchAddress" ) );
  MethodProxy* method = MethodProxy_New( "SetBranchAddress",
                                         new TTreeSetBranchAddress(original) );
  Py_DECREF( original );
      
  PyObject_SetAttrString(
      chain_pyclass,
      const_cast< char* >( method->GetName().c_str() ),
      (PyObject*)method );
  Py_DECREF( method );
}


} // namespace RootUtils
