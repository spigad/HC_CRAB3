#ifndef INTERPRET_SEEDS_H
#define INTERPRET_SEEDS_H 1
#include <string>
bool interpretSeeds(const std::string& buffer, 
		    std::string& stream, long& seed1, long& seed2);
bool interpretSeeds(const std::string& buffer, 
		    std::string& stream, std::vector<unsigned long>& seeds);
#endif
