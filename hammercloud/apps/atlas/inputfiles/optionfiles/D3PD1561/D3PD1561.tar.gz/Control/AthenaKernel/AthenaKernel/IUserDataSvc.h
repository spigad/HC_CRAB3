#ifndef IUSERDATASVC_H
#define IUSERDATASVC_H

//<<<<<< INCLUDES                                                       >>>>>>
#include "GaudiKernel/IService.h"
#include "GaudiKernel/StatusCode.h"
#include "GaudiKernel/ClassID.h"

#include <string>
#include <typeinfo>
#include <iostream>

#include <AthenaKernel/UserDataAssociation.h>

//<<<<<< FORWARD DECLARATIONS                                           >>>>>>
namespace Athena {
  class PackageInfo;
}

//class IAthenaBarCode;

//<<<<<< CLASS DECLARATIONS                                             >>>>>>
/** @class IUserDataSvc
 * @brief  interface to UserDataSvc
 * @author Yushu Yao <yyao@lbl.gov> - ATLAS Collaboration
 *$Id: IUserDataSvc.h,v 1.8 2008/05/27 22:09:42 yyao Exp $
 */

//Work Around dependency issue of Navigation
//If don't see IAthenaBarCode.h yet, do the definitions here.
#ifndef NAVIGATION_IATHENABARCODE_H
#include <inttypes.h>
typedef uint64_t AthenaBarCode_t;
class IAthenaBarCode;
#endif

class IUserDataSvc : virtual public IService {

public:

  ~IUserDataSvc() {
  }

  static const InterfaceID&
  interfaceID();

public:
  // * * * * * * * * * * * * * * * * * * * * * * * *
  // Decorate (Adding Decorations)
  // Label of decoration is unique throughout the file (even job), for all levels
  // Specially handled Adding Decoration for type double and std::string
  // * * * * * * * * * * * * * * * * * * * * * * * *

  //getInMemxxx functions are for accessing the userdata that was created in the same job.
  //getXXX function are for accesing the userdata from the input stream

  //Event Level Decorations
  template<typename DECO>
    StatusCode
    decorateEvent(const std::string& label, DECO& deco);
  template<typename DECO>
    StatusCode
    getEventDecoration(const std::string & label, DECO &deco);
  template<typename DECO>
    StatusCode
    getInMemEventDecoration(const std::string & label, DECO &deco);
  
  //Object (Collection) Level Decorations, using clid, key
  template<typename DECO>
    StatusCode
    decorateCollection(const std::string & label, DECO& deco, const CLID& clid,
        const std::string& key);
  template<typename DECO>
    StatusCode
    getCollectionDecoration(const std::string & label, const CLID& clid,
        const std::string& key, DECO &deco);

  //File Level Decorations
  template<typename DECO>
    StatusCode
    decorateFile(const std::string& label, DECO& deco);
  template<typename DECO>
    StatusCode
    getFileDecoration(const std::string & label, DECO &deco);
  template<typename DECO>
    StatusCode
    getInMemFileDecoration(const std::string & label, DECO &deco);

  //Element Level Decorations
  template<typename DECO>
    StatusCode
    decorateElement(const IAthenaBarCode &abc, const std::string& label,
        DECO& deco);
  template<typename DECO>
    StatusCode
    getElementDecoration(const IAthenaBarCode &abc, const std::string & label,
        DECO &deco);
  template<typename DECO>
    StatusCode
    getInMemElementDecoration(const IAthenaBarCode &abc, const std::string & label,
        DECO &deco);

  //Functions to iterate over existing element level decorations in this event
  //Slow, not suggested to use for production purpose
  virtual  std::vector<AthenaBarCode_t> getElListOfABC()  =0;
  virtual  std::vector<std::string> getElListOfLabel(const AthenaBarCode_t &abc) =0;
  virtual  std::vector<AthenaBarCode_t> getInMemElListOfABC()  =0;
  virtual  std::vector<std::string> getInMemElListOfLabel(const AthenaBarCode_t &abc) =0;

private:
  template<typename DECO>
    StatusCode
    getInMemDecoration(const std::string & label,
        const UserDataAssociation::DecoLevel& level, const CLID& clid,
        const std::string& key, DECO &deco);

  template<typename DECO>
    StatusCode
    getDecoration(const std::string & label,
        const UserDataAssociation::DecoLevel& level, const CLID& clid,
        const std::string& key, DECO &deco);

  template<typename DECO>
    StatusCode
    decorate(const std::string & label,
        const UserDataAssociation::DecoLevel& level, const CLID& clid,
        const std::string& key, DECO& deco);

  // * * * * * * * * * * * * * * * * * * * * * * * *
  // Pure Virtual Methods
  // * * * * * * * * * * * * * * * * * * * * * * * *

public:
  virtual int
  vdecorate(const std::string& label, const std::type_info &decoinfo,
      void* & deco, void* & defaultobj, void* & tobedeleted,
      const UserDataAssociation::DecoLevel& level, const CLID& clid,
      const std::string & key) = 0;

  virtual int
  vdecorateElement(const IAthenaBarCode &abc, const std::string& label,
      const std::type_info &decoinfo, void* & deco, void* & defaultobj,
      void* & tobedeleted)=0;

  virtual int
  vgetDecoration(const std::string& label, const std::type_info &decoinfo,
      void *&deco, const UserDataAssociation::DecoLevel& level,
      const CLID& clid, const std::string & key) = 0;

  virtual int
  vgetInMemDecoration(const std::string& label, const std::type_info &decoinfo,
      void *&deco, const UserDataAssociation::DecoLevel& level,
      const CLID& clid, const std::string & key) = 0;

  virtual int
  vgetElementDecoration(const IAthenaBarCode &abc, const std::string& label,
                        const std::type_info &decoinfo, void *&deco) = 0;

  virtual int
  vgetInMemElementDecoration(const IAthenaBarCode &abc, const std::string& label,
                             const std::type_info &decoinfo, void *&deco,
                             bool quiet = false) =0;

};

//<<<<<< INLINE MEMBER FUNCTIONS                                        >>>>>>
inline const InterfaceID&
IUserDataSvc::interfaceID() {
  static const InterfaceID _IID("IUserDataSvc", 1, 0);
  return _IID;
}

// * * * * * * * * * * * * * * * * * * * * * * * *
// Event Level
// * * * * * * * * * * * * * * * * * * * * * * * *
template<typename DECO>
  inline StatusCode
  IUserDataSvc::decorateEvent(const std::string& label, DECO& deco) {

    return decorate(label, UserDataAssociation::EVENT, 0, "", deco);
  }
template<typename DECO>
  inline StatusCode
  IUserDataSvc::getEventDecoration(const std::string & label, DECO &deco) {
    return getDecoration(label, UserDataAssociation::EVENT, 0, "", deco);
  }

template<typename DECO>
  inline StatusCode
  IUserDataSvc::getInMemEventDecoration(const std::string & label, DECO &deco) {
    return getInMemDecoration(label, UserDataAssociation::EVENT, 0, "", deco);
  }

// * * * * * * * * * * * * * * * * * * * * * * * *
// Collection Level
// * * * * * * * * * * * * * * * * * * * * * * * *
template<typename DECO>
  inline StatusCode
  IUserDataSvc::decorateCollection(const std::string & label, DECO& deco,
      const CLID& clid, const std::string& key) {
    return decorate<DECO> (label, UserDataAssociation::COLLECTION, clid, key,
        deco);
  }
template<typename DECO>
  inline StatusCode
  IUserDataSvc::getCollectionDecoration(const std::string & label,
      const CLID& clid, const std::string& key, DECO &deco) {
    return getDecoration(label, UserDataAssociation::COLLECTION, clid, key,
        deco);
  }
// * * * * * * * * * * * * * * * * * * * * * * * *
// File Level
// * * * * * * * * * * * * * * * * * * * * * * * *
template<typename DECO>
  inline StatusCode
  IUserDataSvc::decorateFile(const std::string & label, DECO& deco) {
    return decorate<DECO> (label, UserDataAssociation::FILE, 0, "", deco);
  }
template<typename DECO>
  inline StatusCode
  IUserDataSvc::getFileDecoration(const std::string & label, DECO &deco) {
    return getDecoration(label, UserDataAssociation::FILE, 0, "", deco);
  }
template<typename DECO>
  inline StatusCode
  IUserDataSvc::getInMemFileDecoration(const std::string & label, DECO &deco) {
    return getInMemDecoration(label, UserDataAssociation::FILE, 0, "", deco);
  }

// * * * * * * * * * * * * * * * * * * * * * * * *
// Universial getDecoration
// * * * * * * * * * * * * * * * * * * * * * * * *
template<typename DECO>
  inline StatusCode
  IUserDataSvc::getDecoration(const std::string & label,
      const UserDataAssociation::DecoLevel& level, const CLID& clid,
      const std::string& key, DECO &deco) {

    void * obj = 0;

    int sc = vgetDecoration(label, typeid(DECO), obj, level, clid, key);

    if (sc == 0) {
      //success
      if (!obj) {//problem with vgetDecoration()
        //			std::cout<<"IUserDataSvc::deco="<<deco<<std::endl;
        return StatusCode::FAILURE;
      }

      //Copy the object to deco
      DECO *decoobj = static_cast<DECO*> (obj);
      deco = *decoobj;

      //remove the temp object created in ROOT TTree.GetEntry() for complex types,
      // or created in vgetDecoration() for simple types
      delete decoobj;

      return StatusCode::SUCCESS;
    }

    //do nothing if not success;
    return StatusCode::FAILURE;

  }

template<typename DECO>
  inline StatusCode
  IUserDataSvc::getInMemDecoration(const std::string & label,
      const UserDataAssociation::DecoLevel& level, const CLID& clid,
      const std::string& key, DECO &deco) {

    void * obj = 0;

    int sc = vgetInMemDecoration(label, typeid(DECO), obj, level, clid, key);

    if (sc == 0) {
      //success
      if (!obj) {//problem with vgetInMemDecoration()
        //			std::cout<<"IUserDataSvc::deco="<<deco<<std::endl;
        return StatusCode::FAILURE;
      }

      //Copy the object to deco
      DECO *decoobj = static_cast<DECO*> (obj);
      deco = *decoobj;

      //Different from getDecoration: no need to delete decoobj since it still needs to be used

      return StatusCode::SUCCESS;
    }

    //do nothing if not success;
    return StatusCode::FAILURE;

  }

// * * * * * * * * * * * * * * * * * * * * * * * *
// Universial decorate (all but ElementLevel)
// * * * * * * * * * * * * * * * * * * * * * * * *
template<typename DECO>
  inline StatusCode
  IUserDataSvc::decorate(const std::string & label,
      const UserDataAssociation::DecoLevel& level, const CLID& clid,
      const std::string& key, DECO& deco) {

    //Copy the object to a new one
    DECO *decoobj = new DECO(deco);
    void * obj = static_cast<void *> (decoobj);

    //Copy the object to a new one, in case this is the first time calling,
    // the default value will be set to this.
    //currently the default value is set to be the default constructor created object
    DECO *defaultdecoobj = new DECO(/*deco*/);
    void *defaultobj = static_cast<void *> (defaultdecoobj);

    void *tobedeleted = 0;

    int sc = vdecorate(label, typeid(DECO), obj, defaultobj, tobedeleted,
        level, clid, key);

   // std::cout << "Done vdecorate: return=" << sc << std::endl;

    if (sc == 1) {
      //Success, since calling before the second event, no needs to delete the temp objects
      return StatusCode::SUCCESS;
    }
    else if (sc == 0) {
      //When decorating with the same label for 2nd time or more
      //No need to keep the default object pointer, so delete it
      //Since the pointer in record is updated, delete the old one

      //Success, but needs to delete the pointers
      //For example, in the case where the decoration is made after the first time
      // when the default value has already been set
      delete defaultdecoobj;
      defaultdecoobj = 0;
      defaultobj = 0;

      DECO *decotmp = static_cast<DECO *> (tobedeleted);
      if (decotmp) {
        delete decotmp;
        decotmp = 0;
        tobedeleted = 0;
      }
      else {
        //tobedeleted can't be 0 and it has to be able to be casted into DECO *
        return StatusCode::FAILURE;
      }

      return StatusCode::SUCCESS;
    }

    //failed, delete the temp objects
    delete decoobj;
    decoobj = 0;
    obj = 0;

    delete defaultdecoobj;
    defaultdecoobj = 0;
    defaultobj = 0;

    return StatusCode::FAILURE;

  }

// * * * * * * * * * * * * * * * * * * * * * * * *
// Decorate ElementLevel
// * * * * * * * * * * * * * * * * * * * * * * * *
template<typename DECO>
  inline StatusCode
  IUserDataSvc::decorateElement(const IAthenaBarCode &abc,
      const std::string& label, DECO& deco) {

    //Copy the object to a new one
    DECO *decoobj = new DECO(deco);
    void * obj = static_cast<void *> (decoobj);

    //Copy the object to a new one, in case this is the first time calling,
    // the default value will be set to this.
    //currently the default value is set to be the default constructor created object
    DECO *defaultdecoobj = new DECO(/*deco*/);
    void *defaultobj = static_cast<void *> (defaultdecoobj);

    void *tobedeleted = 0;

    int sc = vdecorateElement(abc, label, typeid(DECO), obj, defaultobj,
        tobedeleted);

    //    std::cout << "Done vdecorate: return=" << sc << std::endl;

    if (sc == 1) {
      //Success, since calling before the second event, no needs to delete the temp objects
      return StatusCode::SUCCESS;
    }
    else if (sc == 0) {
      //When decorating with the same label for 2nd time or more
      //No need to keep the default object pointer, so delete it
      //Since the pointer in record is updated, delete the old one

      //Success, but needs to delete the pointers
      //For example, in the case where the decoration is made after the first time
      // when the default value has already been set
      delete defaultdecoobj;
      defaultdecoobj = 0;
      defaultobj = 0;

      DECO *decotmp = static_cast<DECO *> (tobedeleted);
      if (decotmp) {
        delete decotmp;
        decotmp = 0;
        tobedeleted = 0;
      }
      else {
        //tobedeleted can't be 0 and it has to be able to be casted into DECO *
        return StatusCode::FAILURE;
      }

      return StatusCode::SUCCESS;
    }

    //failed, delete the temp objects
    delete decoobj;
    decoobj = 0;
    obj = 0;

    delete defaultdecoobj;
    defaultdecoobj = 0;
    defaultobj = 0;

    return StatusCode::FAILURE;

  }

// * * * * * * * * * * * * * * * * * * * * * * * *
//  getDecoration element level
// * * * * * * * * * * * * * * * * * * * * * * * *
template<typename DECO>
  StatusCode
  IUserDataSvc::getElementDecoration(const IAthenaBarCode &abc,
      const std::string & label, DECO &deco) {

    void * obj = 0;

    int sc = vgetElementDecoration(abc, label, typeid(DECO), obj);

    if (sc == 0) {
      //success
      if (!obj) {//problem with vgetDecoration()
        //			std::cout<<"IUserDataSvc::deco="<<deco<<std::endl;
        return StatusCode::FAILURE;
      }

      //Copy the object to deco
      DECO *decoobj = static_cast<DECO*> (obj);
      deco = *decoobj;

      //remove the temp object created in ROOT TTree.GetEntry() for complex types,
      // or created in vgetDecoration() for simple types
      delete decoobj;

      return StatusCode::SUCCESS;
    }

    //do nothing if not success;
    return StatusCode::FAILURE;
  }

template<typename DECO>
  StatusCode
  IUserDataSvc::getInMemElementDecoration(const IAthenaBarCode &abc,
      const std::string & label, DECO &deco) {

    void * obj = 0;

    int sc = vgetInMemElementDecoration(abc, label, typeid(DECO), obj);

    if (sc == 0) {
      //success
      if (!obj) {//problem with vgetInMemDecoration()
        //			std::cout<<"IUserDataSvc::deco="<<deco<<std::endl;
        return StatusCode::FAILURE;
      }

      //Copy the object to deco
      DECO *decoobj = static_cast<DECO*> (obj);
      deco = *decoobj;

      return StatusCode::SUCCESS;
    }

    //do nothing if not success;
    return StatusCode::FAILURE;
  }

#endif // IUSERDATASVC_H
