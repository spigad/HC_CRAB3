///////////////////////// -*- C++ -*- /////////////////////////////
#ifndef ATHENAKERNEL_IPROXYDICT_H
# define ATHENAKERNEL_IPROXYDICT_H

//<<<<<< INCLUDES                                                       >>>>>>
#include "GaudiKernel/INamedInterface.h"

#ifndef GAUDIKERNEL_CLASSID_H
 #include "GaudiKernel/ClassID.h"
#endif
#ifndef _CPP_STRING
 #include <string>
#endif
#include <vector>

//<<<<<< FORWARD DECLARATIONS                                           >>>>>
namespace SG {
  class DataProxy;
}

/** @class IProxyDict   
 * @brief a proxy dictionary. 
 * it inherits from INamedInterface because clients need its name (e.g. data links)
 *
 * @author Paolo Calafiura - ATLAS
 *  $Id: IProxyDict.h,v 1.5 2007-12-11 02:56:22 binet Exp $
 */

class IProxyDict : virtual public INamedInterface {
public:
  /// get proxy for a given data object address in memory,
  /// but performs a deep search among all possible 'symlinked' containers
  virtual SG::DataProxy* deep_proxy(const void* const pTransient) const=0;

  /// get proxy for a given data object address in memory
  virtual SG::DataProxy* proxy(const void* const pTransient) const=0;

  /// get default proxy with given id. Returns 0 to flag failure
  virtual SG::DataProxy* proxy(const CLID& id) const=0;

  /// get proxy with given id and key. Returns 0 to flag failure
  virtual SG::DataProxy* proxy(const CLID& id, const std::string& key) const=0;

  /// return the list of all current proxies in store
  virtual std::vector<const SG::DataProxy*> proxies() const = 0;

  virtual ~IProxyDict() {}

  /// Gaudi boilerplate
  static const InterfaceID& interfaceID();
};
//<<<<<< INLINE MEMBER FUNCTIONS                                        >>>>>>
inline
const InterfaceID& 
IProxyDict::interfaceID() {
  static const InterfaceID _IID("IProxyDict", 1, 0);
  return _IID;
}
#endif // ATHENAKERNEL_IPROXYDICT_H










