# @file: PyAthenaComps.py
# @purpose: a set of Python classes for PyAthena
# @author: Sebastien Binet <binet@cern.ch>

__doc__     = """Module containing a set of Python base classes for PyAthena"""
__version__ = "$Revision: 1.12 $"
__author__  = "Sebastien Binet <binet@cern.ch>"

### data
__all__ = [ 'StatusCode',
            'Alg',
            'Svc',
            'AlgTool',
            'Aud',
            'algs',
            'services',
            ]

### imports
import sys
from AthenaCommon.Logging import logging
from AthenaCommon.Configurable  import *
from Configurables import (CfgPyAlgorithm,
                           CfgPyService,
                           CfgPyAlgTool,
                           CfgPyAud)

### helpers -------------------------------------------------------------------
import weakref
class WeakRefHolder(object):
    """A convenient class to access py-components by name
    """
    pass
def __wk_setattr__(self, k, v):
    self.__setattr__(k, weakref.ref(v))

services = WeakRefHolder()
services.__doc__ = """The list of PyAthena::Svc which have been instantiated"""
services.__setattr__ = __wk_setattr__

algs = WeakRefHolder()
algs.__doc__ = """The list of PyAthena::Alg which have been instantiated"""
algs.__setattr__ = __wk_setattr__

del __wk_setattr__

### helper methods ------------------------------------------------------------
def _get_prop_value(pycomp, propname):
    v = pycomp.properties()[propname]
    if v == pycomp.propertyNoValue:
        v = pycomp.getDefaultProperty(propname)
        pass
    return v

### PyAthena.StatusCode -------------------------------------------------------
class StatusCode:
    Recoverable = 2
    Success     = 1
    Failure     = 0

### PyAthena.Alg --------------------------------------------------------------
class Alg( CfgPyAlgorithm ):
    """
    Base class from which all concrete algorithm classes should
    be derived.

    In order for a concrete algorithm class to do anything
    useful the methods initialize(), execute() and finalize()
    should be overridden.
    """
    def __init__(self, name = None, **kw):
        if name is None: name = kw.get('name', self.__class__.__name__)
        ## init base class
        super(Alg, self).__init__(name, **kw)
        self.__dict__['msg']  = logging.getLogger( self.getJobOptName() )
        return

    def sysInitialize(self):
        self.__dict__['msg']  = logging.getLogger( self.getJobOptName() )
        self.msg.setLevel(_get_prop_value(self,'OutputLevel'))
        return self.initialize()
    
    def initialize(self):
        raise NotImplementedError(
            "You have to implement PyAthena.Alg.initialize() !"
            )

    def sysReinitialize(self):
        self.msg.setLevel(_get_prop_value(self,'OutputLevel'))
        return self.reinitialize()
    
    def reinitialize(self):
        self.msg.info( "==> re-initialize..." )
        return StatusCode.Success

    def sysExecute(self):
        return self.execute()
    
    def execute(self):
        raise NotImplementedError(
            "You have to implement PyAthena.Alg.execute() !"
            )

    def sysFinalize(self):
        return self.finalize()
    
    def finalize(self):
        raise NotImplementedError(
            "You have to implement PyAthena.Alg.finalize() !"
            )

    def sysBeginRun(self):
        return self.beginRun()
    
    def beginRun(self):
        self.msg.debug( "==> beginRun..." )
        return StatusCode.Success

    def sysEndRun(self):
        return self.endRun()
    
    def endRun(self):
        self.msg.debug( "==> endRun..." )
        return StatusCode.Success

    def filterPassed(self):
        """Did this algorithm pass or fail its filter criterion for the last event?"""
        return self._cppHandle.filterPassed()

    def setFilterPassed(self, state):
        """Set the filter passed flag to the specified state"""
        return self._cppHandle.setFilterPassed(state)
    
    pass # PyAthena.Alg

### PyAthena.Svc --------------------------------------------------------------
class Svc( CfgPyService ):
    """Base class for all services
    """
    def __init__(self, name = None, **kw):

        if name is None: name = kw.get('name', self.__class__.__name__)
        ## init base class
        super(Svc, self).__init__(name, **kw)
        self.__dict__['msg']  = logging.getLogger( self.getJobOptName() )
        
        return

    def sysInitialize(self):
        self.msg.setLevel(_get_prop_value(self,'OutputLevel'))
        return self.initialize()
    
    def initialize(self):
        raise NotImplementedError(
            "You have to implement PyAthena.Svc.initialize() !"
            )

    def sysReinitialize(self):
        self.msg.setLevel(_get_prop_value(self,'OutputLevel'))
        return self.reinitialize()
    
    def reinitialize(self):
        self.msg.info( "==> re-initialize..." )
        return StatusCode.Success

    def sysFinalize(self):
        return self.finalize()
    
    def finalize(self):
        self.msg.info( "==> finalize..." )
        return StatusCode.Success

    def sysBeginRun(self):
        return self.beginRun()
    
    def beginRun(self):
        self.msg.info( "==> beginRun..." )
        return StatusCode.Success

    def sysEndRun(self):
        return self.endRun()
    
    def endRun(self):
        self.msg.info( "==> endRun..." )
        return StatusCode.Success
    
    pass # PyAthena.Svc

### PyAthena.AlgTool ----------------------------------------------------------
class AlgTool( CfgPyAlgTool ):
    """
    Base class from which all concrete algtool classes should be derived.
    """
    def setParent (self, parentName):
        # needed to update our logger name...
        o = super (AlgTool, self).setParent (parentName)
        self.__dict__['msg'] = logging.getLogger (self.getJobOptName())
        return o
    
    def __init__(self, name=None, parent=None, **kw):
        if name is None: name = kw.get('name', self.__class__.__name__)
        if not (parent is None):
            if isinstance(parent, str): name = "%s.%s" % (parent,name)
            else:                       name = "%s.%s" % (parent.name(),name)
        ## init base class
        super(AlgTool, self).__init__(name, **kw)
        self.__dict__['msg']  = logging.getLogger( self.getJobOptName() )
        return

    def sysInitialize(self):
        self.msg.setLevel(_get_prop_value(self,'OutputLevel'))
        return self.initialize()
    
    def initialize(self):
        raise NotImplementedError(
            "You have to implement PyAthena.AlgTool.initialize() !"
            )

    def sysReinitialize(self):
        self.msg.setLevel(_get_prop_value(self,'OutputLevel'))
        return self.reinitialize()
    
    def reinitialize(self):
        self.msg.info( "==> re-initialize..." )
        return StatusCode.Success

    def sysFinalize(self):
        return self.finalize()
    
    def finalize(self):
        raise NotImplementedError(
            "You have to implement PyAthena.AlgTool.finalize() !"
            )

    pass # PyAthena.AlgTool

### PyAthena.Aud --------------------------------------------------------------
class Aud( CfgPyAud ):
    """
    Base class from which all concrete auditor classes should be derived.
    """
    def __init__(self, name=None, **kw):

        if name is None: name = kw.get('name', self.__class__.__name__)
        ## init base class
        super(Aud, self).__init__(name, **kw)
        from AthenaCommon.Logging import logging
        self.__dict__['msg'] = logging.getLogger( self.getJobOptName() )

        return

    def sysInitialize(self):
        self.msg.setLevel(_get_prop_value(self,'OutputLevel'))
        return self.initialize()
    
    def initialize(self):
        raise NotImplementedError(
            "You have to implement PyAthena.Aud.initialize() !"
            )

    def sysFinalize(self):
        return self.finalize()
    
    def finalize(self):
        raise NotImplementedError(
            "You have to implement PyAthena.Aud.finalize() !"
            )

    ## default no-op implementation...

    def before(self, evt_name, comp_name):
        return

    def after (self, evt_name, comp_name):
        return
    
    pass # PyAthena.Aud

### ---
def toiter(beg,end):
    while beg != end:
        yield beg.__deref__()
        beg.__preinc__()
    return
   
class FilePeeker(Alg):
    """utility algorithm to inspect a file's content
    """
    def __init__(self, name='FilePeeker', **kw):
        ## init base class
        super(FilePeeker, self).__init__(name, **kw)
        self.infname = kw.get('infname', 'not-there.pool')
        self.outfname= kw.get('outfname', None)

        # flag to enable the bwd compat fallback mechanism...
        self._old_file_flag = False
        
        # flag to enable event less files without beginRun...
        self._begin_run_flag = False
        
    def initialize(self):

        import AthenaPython.PyAthena as PyAthena
        self.peeked_data = {
            'run_number':      [],
            'evt_number':      [],
            'run_type':        ['N/A'],
            'evt_type':        [],
            'lumi_block':      [],
            'stream_tags':     [],
            'stream_names':    [],
            'eventdata_items': [],
            'beam_type':       ['N/A'], # XXX fixme
            'beam_energy':     ['N/A'], # XXX fixme
            ##
            'metadata': {},
            'tag_info': {},
            }
        
        # load our pythonizations:
        for cls_name in ('EventStreamInfo',
                         'EventType',
                         'PyEventType',
                         ):
            cls = getattr(PyAthena, cls_name)

        _info = self.msg.info
        _info("retrieving various stores...")
        for store_name in ('evtStore', 'metaStore',
                           'tagStore', 'inputStore'):
            _info('retrieving [%s]...', store_name)
            o = getattr(self, store_name)
            _info('retrieving [%s]... [done]', store_name)
        _info("retrieving various stores... [done]")

        import os
        self.infname = os.path.basename(self.infname)

        import AthenaPython.PyAthena as PyAthena
        _info = self.msg.info
        return StatusCode.Success
        
    def beginRun(self):
        self._begin_run_flag = True
        # retrieving data available at start...
        self.peeked_data.update(self._do_peeking(peek_evt_data=False))
        self.print_summary()
        return StatusCode.Success

    def endRun(self):
        if not self._begin_run_flag:
            # retrieving data for event less jobs, where no beginRun is called
            self.peeked_data.update(self._do_peeking(peek_evt_data=False))
            self.print_summary()

        return StatusCode.Success

    @property
    def evtStore(self):
        import AthenaPython.PyAthena as PyAthena
        return PyAthena.py_svc('StoreGateSvc/StoreGateSvc')
    
    @property
    def metaStore(self):
        import AthenaPython.PyAthena as PyAthena
        return PyAthena.py_svc('StoreGateSvc/MetaDataStore')
    
    @property
    def tagStore(self):
        import AthenaPython.PyAthena as PyAthena
        return PyAthena.py_svc('StoreGateSvc/TagMetaDataStore')
    
    @property
    def inputStore(self):
        import AthenaPython.PyAthena as PyAthena
        return PyAthena.py_svc('StoreGateSvc/InputMetaDataStore')
    
    def execute(self):
        _info = self.msg.info
        self.peeked_data.update(self._do_peeking(peek_evt_data=True))
        self.print_summary()
        return StatusCode.Success

    def process_metadata(self, store, metadata_name):
        msg = self.msg
        try:
            obj = store[metadata_name]
        except KeyError,err:
            msg.warning('could not retrieve [%s]', metadata_name)
            return
        msg.info('processing container [%s]', obj.folderName())
        data = []
        payloads = obj.payloadContainer()
        for payload in toiter(payloads.begin(),
                              payloads.end()):
            # names
            chan_names = []
            sz = payload.name_size()
            msg.info('==names== (sz: %s)', sz)
            for idx in xrange(sz):
                chan = payload.chanNum(idx)
                chan_name = payload.chanName(chan)
                # msg.info( '--> (%s, %s)', idx, chan_name)
                chan_names.append(chan_name)
                
            if 1: # we don't really care about those...
                # iovs
                sz = payload.iov_size()
                msg.info('==iovs== (sz: %s)',sz)
                for idx in xrange(sz):
                    chan = payload.chanNum(idx)
                    iov_range = payload.iovRange(chan)
                    iov_start = iov_range.start()
                    iov_stop  = iov_range.stop()
                    if 0:
                        msg.info( '(%s, %s) => (%s, %s) valid=%s runEvt=%s',
                                  iov_start.run(),
                                  iov_start.event(),
                                  iov_stop.run(),
                                  iov_stop.event(),
                                  iov_start.isValid(),
                                  iov_start.isRunEvent())
        
            # attrs
            attrs = [] # can't use a dict as spec.name() isn't unique
            sz = payload.size()
            msg.info('==attrs== (sz: %s)', sz)
            for idx in xrange(sz):
                chan = payload.chanNum(idx)
                attr_list = payload.attributeList(chan)
                attr_list = list(toiter(attr_list.begin(),
                                        attr_list.end()))
                attr_data = []
                for a in attr_list:
                    # msg.info((a,dir(a),type(a)))
                    spec   = a.specification()
                    a_type = spec.typeName()
                    a_type = 'std::string' if a_type == 'string' else a_type
                    a_data = getattr(a,'data<%s>'%a_type)()
                    if a_type == 'std::string':
                        try:
                            a_data = eval(a_data,{},{})
                        except Exception:
                            # swallow and keep as a string
                            pass
                    attr_data.append((spec.name(),
                                      #type(a_data),
                                      a_data))
                attrs.append(dict(attr_data))
                # msg.info(attrs[-1])
            if len(attrs) == len(chan_names):
                data.append(dict(zip(chan_names,attrs)))
            else:
                if len(attrs):
                    if len(attrs) == 1:
                        data.append(attrs[0])
                    else:
                        data.append(attrs)
                else:
                    data.append(chan_names)
            pass # loop over payloads...
        
        #payload.dump()
        ## if len(data)>1:
        ##     print "="*80,metadata_name
        ##     for d in data:
        ##         print "==",d
        return data

    def finalize(self):
        _info = self.msg.info
        self.print_summary()
        if self.outfname:
            oname = self.outfname
            import os
            oname = os.path.expanduser(os.path.expandvars(oname))
            _info('storing peeked file infos into [%s]...', oname)
            if os.path.exists(oname):
                os.remove(oname)
            try:
                import cPickle as pickle
            except ImportError:
                import pickle
            import PyUtils.dbsqlite as dbsqlite
            db = dbsqlite.open(oname,flags='w')
            db['fileinfos'] = self.peeked_data
            db.close()
            _info('storing peeked file infos into [%s]... [done]', oname)
        return StatusCode.Success

    def print_summary(self):
        _info = self.msg.info

        ## -- summary
        _info(':::::: summary ::::::')
        _info(' - run numbers: %s', self.peeked_data['run_number'])
        _info(' - evt types: %s', self.peeked_data['evt_type'])
        _info(' - item list: %s', len(self.peeked_data['eventdata_items']))
        _info(' - lumiblocks: %s', self.peeked_data['lumi_block'])
        _info(' - processing tags: %s', self.peeked_data['stream_names'])
        _info(' - stream tags: %s', self.peeked_data['stream_tags'])
        _info(' - geometry: %s', self.peeked_data['geometry'])
        _info(' - conditions tag: %s', self.peeked_data['conditions_tag'])
        _info(' - metadata items: %s', len(self.peeked_data['metadata_items']))
        _info(' - tag-info: %s', self.peeked_data['tag_info'].keys())
        return
    
    def _do_peeking(self, peek_evt_data=False):
        """ the real function doing all the work of peeking at the input file
        @return a dict of peeked-at data
        """
        peeked_data = {}
        import AthenaPython.PyAthena as PyAthena
        _info = self.msg.info

        def _get_detdescr_tags(evt_type):
            ddt = evt_type.get_detdescr_tags().split()
            # det_descr_tags is of the form:
            # [ 'key1', 'val1', 'key2', 'val2', ... ]
            ddt = dict(zip(ddt[0::2],  # select 'key?'
                           ddt[1::2])) # select 'val?'
            return ddt
        
        ## input-store
        # self.inputStore.dump()
        store = self.inputStore
        esi_keys = store.keys('EventStreamInfo')
        nentries = None
        ddt = None
        if len(esi_keys) >= 1:
            sg_key = esi_keys.pop()
            esi = store.retrieve('EventStreamInfo', sg_key)
            _info('=== [EventStreamInfo#%s] ===', sg_key)
            nentries = esi.getNumberOfEvents()

            evt_types = PyAthena.EventStreamInfo.evt_types(esi)
            if len(evt_types) > 0:
                evt_type = evt_types[0]
                peeked_data['evt_type'] = evt_type.bit_mask
                ddt = _get_detdescr_tags(evt_type)
                peeked_data['det_descr_tags'] = ddt
                
            def _make_item_list(item):
                sgkey= item[1]
                clid = item[0]
                _typename = store._pyclidsvc.typename
                return (_typename(clid) or str(clid), # str or keep the int?
                        sgkey)
            item_list = esi.item_list()
            item_list = map(_make_item_list, item_list)
            peeked_data['eventdata_items'] = item_list
            peeked_data['lumi_block'] = esi.lumi_blocks()
            peeked_data['run_number'] = esi.run_numbers()
            #peeked_data['evt_number'] = esi.event_number()
            peeked_data['stream_names'] = esi.processing_tags()
            
        # hack to retrieve the number of events if no EventStreamInfo
        # was present in the input file
        if nentries is None:
            ROOT = _import_ROOT()
            import os
            root_files = list(ROOT.gROOT.GetListOfFiles())
            root_files = [root_file for root_file in root_files
                          if root_file.GetName().count(self.infname)]
            if len(root_files)==1:
                root_file = root_files[0]
                data_hdr = root_file.Get("POOLContainer_DataHeader")
                nentries = data_hdr.GetEntriesFast() if data_hdr is not None \
                           else 'N/A'
            else:
                _info('could not find correct ROOT file (looking for [%s])',
                      self.infname)
                nentries = 'N/A'
            del root_files
            del data_hdr
        peeked_data['nentries'] = nentries

        # retrieve the GUID
        def _get_guid():
            guid = None
            ROOT = _import_ROOT()
            import os
            root_files = list(ROOT.gROOT.GetListOfFiles())
            root_files = [root_file for root_file in root_files
                          if root_file.GetName().count(self.infname)]
            if len(root_files)!=1:
                _info('could not find correct ROOT file (looking for [%s])',
                      self.infname)
                return
            
            root_file = root_files[0]
            pool = root_file.Get("##Params")
            import re
            # Pool parameters are of the form:
            # '[NAME=somevalue][VALUE=thevalue]'
            pool_token = re.compile(r'[[]NAME=(?P<name>.*?)[]]'\
                                    r'[[]VALUE=(?P<value>.*?)[]]').match
            params = []
            for i in xrange(pool.GetEntries()):
                if pool.GetEntry(i)>0:
                    d = pool_token(pool.db_string).groupdict()
                    params.append((d['name'], d['value']))
                    if d['name'].lower() == 'fid':
                        guid = d['value']
            return guid
        guid = _get_guid()
        if guid:
            peeked_data['file_guid'] = guid
        
        ## -- metadata
        metadata_items = [(self.inputStore._pyclidsvc.typename(p.clID()),
                           p.name())
                          for p in self.inputStore.proxies()]
        peeked_data['metadata_items'] = metadata_items
        metadata = {}
        def maybe_get(o, idx, default=None):
            try:
                return o[idx]
            except IndexError:
                return default
        def maybe_float(o):
            try:
                return float(o)
            except ValueError:
                return o
        for k in self.inputStore.keys('IOVMetaDataContainer'):
            v = self.process_metadata(self.inputStore, k)
            metadata[k] = maybe_get(v, -1)
        peeked_data['metadata'] = metadata

        ## -- taginfo
        taginfo = {}
        if self.metaStore.contains('IOVMetaDataContainer','/TagInfo'):
            v = self.process_metadata(self.metaStore, '/TagInfo')
            taginfo = maybe_get(v, -1)
        else:
            if '/TagInfo' in metadata:
                taginfo = metadata['/TagInfo'].copy()
            else:
                self._old_file_flag = True
                # no tag info whatsoever...
                # try detdescr_tags ?
        if ddt:
            peeked_data['det_descr_tags'] = ddt
            peeked_data['geometry'] = ddt.get('GeoAtlas', None)
            peeked_data['conditions_tag'] = ddt.get('IOVDbGlobalTag', None)
        peeked_data['tag_info'] = taginfo
        if taginfo:
            peeked_data['det_descr_tags'] = taginfo
            peeked_data['geometry'] = taginfo.get('GeoAtlas', None)
            peeked_data['conditions_tag'] = taginfo.get('IOVDbGlobalTag', None)

        if not 'geometry' in peeked_data:
            peeked_data['geometry'] = None
        if not 'conditions_tag' in peeked_data:
            peeked_data['conditions_tag'] = None
        if not 'det_descr_tags' in peeked_data:
            peeked_data['det_descr_tags'] = {}
            
        #######################################################################
        ## return early if no further processing needed...
        if peek_evt_data == False:
            return peeked_data
        #######################################################################

        
        # access directly the EventInfo
        store = self.evtStore
        evt_info_keys = store.keys('EventInfo')
        if len(evt_info_keys) != 1:
            _info('more than one EventInfo: %s', evt_info_keys)
            _info(' ==> we\'ll use [%s]', evt_info_keys[0])
        sg_key = evt_info_keys.pop()
        ei = store.retrieve('EventInfo', sg_key)
        _info('=== [EventInfo#%s] ===', sg_key)
        eid = ei.event_ID()

        dh = store.retrieve('DataHeader')
        def _make_item_list(dhe):
            sgkey= dhe.getKey()
            clid = dhe.getPrimaryClassID()
            _typename = store._pyclidsvc.typename
            return (_typename(clid) or str(clid), # str or keep the int?
                    sgkey)
        item_list = map(_make_item_list, dh)

        # -- event-type
        evt_type = ei.event_type()
        det_descr_tags = _get_detdescr_tags(evt_type)

        peeked_data.update({
            'run_number':      [eid.run_number()],
            'evt_number':      [eid.event_number()],
            'run_type':        ['N/A'],
            'evt_type':        evt_type.bit_mask,
            'det_descr_tags':  det_descr_tags,
            'geometry':        det_descr_tags.get('GeoAtlas', None),
            'conditions_tag':  det_descr_tags.get('IOVDbGlobalTag', None),
            'lumi_block':      [eid.lumi_block()],
            'stream_names':    [dh.getProcessTag()],
            'eventdata_items': item_list,
            'beam_type':       [det_descr_tags.get('beam_type','N/A')],
            'beam_energy':     [maybe_float(det_descr_tags.get('beam_energy',
                                                               'N/A'))],
            })
        
        trigger_info= ei.trigger_info()
        stream_tags = trigger_info.streamTags() if trigger_info else []
        stags = []
        for st in stream_tags: # don't use list-comprehensions b/c of ROOT bugs
            st_type = st.type()
            st_name = st.name()
            obeys_lbk=bool(st.obeysLumiblock())
            stags.append(dict(stream_type=st_type,
                              stream_name=st_name,
                              obeys_lbk=obeys_lbk))
        peeked_data['stream_tags'] = stags

        # -- old files compat
        if self._old_file_flag or 1:

            ## -- metadata
            metadata_items = [(self.inputStore._pyclidsvc.typename(p.clID()),
                               p.name())
                              for p in self.inputStore.proxies()]
            peeked_data['metadata_items'] = metadata_items
            metadata = {}
            for k in self.inputStore.keys('IOVMetaDataContainer'):
                v = self.process_metadata(self.inputStore, k)
                metadata[k] = maybe_get(v, -1)
            peeked_data['metadata'] = metadata

            ## -- taginfo
            taginfo = {}
            if self.metaStore.contains('IOVMetaDataContainer','/TagInfo'):
                v = self.process_metadata(self.metaStore, '/TagInfo')
                taginfo = maybe_get(v, -1)
            if taginfo:
                # we want to keep the AtlasRelease from when the file was produced
                atlas_release = peeked_data.get('det_descr_tags', taginfo)
                atlas_release = atlas_release.get('AtlasRelease',
                                                  taginfo['AtlasRelease'])
                taginfo['AtlasRelease'] = atlas_release
                peeked_data['det_descr_tags'] = taginfo
            peeked_data['tag_info'] = taginfo

            ## -- geometry + conditions-tag
            # update these values which may have changed b/c of sync' w/ taginfo
            ddt = peeked_data['det_descr_tags']
            peeked_data['geometry'] = ddt.get('GeoAtlas', None)
            peeked_data['conditions_tag'] = ddt.get('IOVDbGlobalTag', None)

            ## -- beam energy/type
            peeked_data['beam_type']= [ddt.get('beam_type','N/A')]
            beam_ene = maybe_float(ddt.get('beam_energy','N/A'))
            peeked_data['beam_energy']=[beam_ene]
            
            pass # old files compat

        return peeked_data
        
    pass # class FilePeeker

### helper functions ----------------------------------------------------------
def _import_ROOT():
    import sys
    sys.argv.insert(1, '-b')
    import ROOT
    del sys.argv[1]
    return ROOT

