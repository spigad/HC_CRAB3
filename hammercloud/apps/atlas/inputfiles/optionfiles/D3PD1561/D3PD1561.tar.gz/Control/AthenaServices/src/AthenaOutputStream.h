// Dear emacs, this is -*- C++ -*-
#ifndef ATHENASERVICES_ATHENAOUTPUTSTREAM_H
#define ATHENASERVICES_ATHENAOUTPUTSTREAM_H

// STL include files
#ifndef _CPP_MEMORY
 #include <memory>
#endif
#ifndef _CPP_MAP
 #include <map>
#endif
#ifndef _CPP_SET
 #include <set>
#endif
#ifndef _CPP_VECTOR
 #include <vector>
#endif
#ifndef _CPP_STRING
 #include <string>
#endif

// Required for inheritance
#ifndef GAUDIKERNEL_IDATASELECTOR_H
 #include "GaudiKernel/IDataSelector.h"
#endif
#ifndef GAUDIKERNEL_ALGORITHM_H
 #include "GaudiKernel/Algorithm.h"
#endif
//get the CLID typedef
#ifndef GAUDIKERNEL_CLASSID_H
 #include "GaudiKernel/ClassID.h"
#endif
#ifndef GAUDIKERNEL_PROPERTY_H
 #include "GaudiKernel/Property.h"
#endif
#ifndef GAUDIKERNEL_SERVICEHANDLE_H
 #include "GaudiKernel/ServiceHandle.h"
#endif
#ifndef GAUDIKERNEL_TOOLHANDLE_H
 #include "GaudiKernel/ToolHandle.h"
#endif

#include "AthenaBaseComps/FilteredAlgorithm.h"

// forward declarations
template <class ConcreteAlgorithm> class AlgFactory;
class IClassIDSvc;
class StoreGateSvc;
class IAthenaOutputStreamTool;
class IAthenaOutputTool;
class UserDataSvc;

namespace SG {
  class DataProxy;
  class IFolder;
  class FolderItem;
}

/** @class AthenaOutputStream
  * @brief algorithm that marks for write data objects in SG
  * 
  * @author srinir@bnl.gov
  * $Id: AthenaOutputStream.h,v 1.12 2008-12-15 19:14:58 binet Exp $
  */
class AthenaOutputStream : public FilteredAlgorithm
{
  friend class AlgFactory<AthenaOutputStream>;
  friend class UserDataSvc;

public:
  typedef std::vector<SG::DataProxy*>     Items;

protected:
  /// handle to the @c StoreGateSvc store where the data we want to
  /// write out resides
  ServiceHandle<StoreGateSvc> m_dataStore;

  /// Name of the persistency service capable to write data from the store
  std::string              m_persName;
  /// Name of the OutputStreamTool used for writing
  StringProperty           m_writingTool;
  /// Name of the output file
  std::string              m_outputName;
  /// tag of processing stage:
  StringProperty           m_processTag;
  
  typedef ServiceHandle<IClassIDSvc> IClassIDSvc_t;
  IClassIDSvc_t m_pCLIDSvc;
  
  /// Vector of item names
  StringArrayProperty      m_itemList;
  /// Vector of item names
  StringArrayProperty      m_excludeList;
  /// the top-level folder with items to be written
  ToolHandle<SG::IFolder>  m_p2BWritten;
  /// the top-level folder with items to be written
  ToolHandle<SG::IFolder>    m_decoder;
  /// set of clid's to be excluded (comes from m_excludeList)
  //std::multimap<std::string,CLID> m_KeyCLIDPairs;
  /// map of (clid,key) pairs to be excluded (comes from m_excludeList)
  std::multimap<CLID,std::string> m_CLIDKeyPairs;
  /// Collection of objects beeing selected
  IDataSelector            m_objects;
  /// Number of events written to this output stream
  int                      m_events;
  /// set to true to force read of data objects in item list
  bool m_forceRead;
  /// set to true to allow data objects being copied persistent to persistent (without SG retrieve).
  bool m_persToPers;
  /// set to true to allow defaults being provided for non-existent data objects.
  bool m_provideDef;
  /// set to false to omit adding the current DataHeader into the DataHeader history
  /// this will cause the input file to be neglected for back navigation (replace mode).
  bool m_extendProvenanceRecord;
  /// set to true to trigger streaming of data on execute()
  bool m_writeOnExecute;
  /// set to true to trigger streaming of data on finalize()
  bool m_writeOnFinalize;
  /// set to write out everything in input DataHeader
  bool m_itemListFromTool;
  /// set to true to check for number of times each object is written
  bool m_checkNumberOfWrites;
  /// map to record number of writes per object
  typedef std::map<std::string, unsigned int>  CounterMapType;
  CounterMapType  m_objectWriteCounter;
  /// Vector of names of AlgTools that are executed by this stream

  typedef ToolHandle<IAthenaOutputStreamTool> IAthenaOutputStreamTool_t;
  /// pointer to AthenaOutputStreamTool
  IAthenaOutputStreamTool_t  m_streamer;
  /// vector of AlgTools that that are executed by this stream
  ToolHandleArray<IAthenaOutputTool> m_helperTools;

protected:
  /// Standard algorithm Constructor
  AthenaOutputStream(const std::string& name, ISvcLocator* pSvcLocator); 
  /// Standard Destructor
  virtual ~AthenaOutputStream();
  /// Handler for ItemNames Property
  void itemListHandler( Property& );
  /// Handler for ItemNames Property
  void excludeListHandler( Property& );

public:
  typedef std::vector < std::pair < std::string, std::string > > TypeKeyPairs;
  /// \name implement IAlgorithm
  //@{
  virtual StatusCode initialize();
  virtual StatusCode finalize();
  virtual StatusCode execute();
  //@}
  /// Stream the data
  virtual StatusCode write();
  /// Clear list of selected objects
  void clearSelection();
  /// Collect data objects for output streamer list
  void collectAllObjects();
  /// Add folder data objects to output stramer list
  void addDataHeaderObjects();
  /// Return the list of selected objects
  IDataSelector* selectedObjects() {
    return &m_objects;
  }
private:
  /// Add folder data objects to output stramer list
  void addFolderObjects(const SG::IFolder&);
  /// Add item data objects to output streamer list
  void addItemObjects(const SG::FolderItem&, MsgStream& log);
  void translateExcludeProperty();
  std::pair<std::string,std::string> breakAtSep(const std::string,const std::string);

};

#endif // ATHENASERVICES_OUTPUTSTREAM_H
