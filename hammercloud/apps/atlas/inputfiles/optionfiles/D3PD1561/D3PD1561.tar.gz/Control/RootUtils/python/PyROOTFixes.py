"""Functions to work around PyROOT bugs for accessing DataVector.

:author: scott snyder
:contact: snyder@bnl.gov

PyROOT (as of root 5.14.00h) has a couple bugs that bite us when accessing
DataVector classes.

 - The element accessors of DataVector return different types for the
   const and non-const versions.  These are not just const and non-const
   qualified versions of the same type, but distinct, layout-incompatible
   types.  (The const version returns a reference directly, while the
   non-const version returns a proxy object.)  PyROOT gets confused
   in such a case: it will call the non-const method, but it will then
   use the const return type to convert the return value.
   As a workaround, when we see that we have
   a DataVector class, we overwrite the names of the non-const methods
   with trash.  This prevents PyROOT from considering them for overload
   resolution, resolving the issue.

 - Attempts to use element access via [] on a class deriving from DataVector
   will cause an infinite recursion.  We also fix this up.

Importing this module will automatically apply these workarounds
for all DataVector classes (and classes deriving from them).

In addition, there may be individual methods of classes that have the
const problem referred to above.  These can be fixed up by calling
fix_method.

There are also some fixes for performance problems with the pythonization
of TTree.  These may be enabled by calling enable_tree_speedups().


"""
__docformat__ = "restructuredtext en"

import ROOT
import PyCintex


def fix_dv_container (clname):
    # Now only a stub.
    return


def _fix_method (clname, methname):
    """Fix a single method of a class.
    This one actually does the work."""
    return ROOT.RootUtils.PyROOTConstFix.fix_one (clname, methname)

def fix_method (clname, methname):
    """Fix a single method of a class"""
    #return ROOT.RootUtils.PyROOTConstFix.fix_one (clname, methname)
    return ROOT.RootUtils.PyROOTTypePatch.register_fixup (clname, methname)

def enable_tree_speedups ():
    """Enable speedups for TTree element access"""
    ROOT.RootUtils.PyROOTTTreePatch.Initialize (ROOT.TTree,
                                                ROOT.TChain,
                                                ROOT.TBranch)
    return

def enable_pickling ():
    """Enable pickling of object proxy's"""
    import libPyROOT
    ROOT.RootUtils.PyROOTPickle.Initialize (libPyROOT, ROOT.ObjectProxy)
    del libPyROOT
    return


ROOT.RootUtils.PyROOTTypePatch.initialize (ROOT.PyRootType)
