#ifndef ATRNDMGENSVC_H
#define ATRNDMGENSVC_H
/** @file AtRndmGenSvc.h
 *  @brief A random number engine manager, based on Ranecu. 
 *  Its usage is deprecated, at least when high quality sequences of randoms
 *  are required (Ranecu period has been shown to be too short, and sensitive
 *  to the quality of initial seeds).
 *  @author Paolo Calafiura
 *  @author George Stavropoulous
 *  
 *  $Id: AtRndmGenSvc.h,v 1.3 2008-09-23 22:00:47 binet Exp $
 */

#include <map>

//base classes
#include "AthenaKernel/IAtRndmGenSvc.h"
#include "GaudiKernel/IIncidentListener.h"
#include "AthenaBaseComps/AthService.h"

#include "CLHEP/Random/RandomEngine.h"
#include "CLHEP/Random/RanecuEngine.h"

class IAlgorithm; 
class ISvcLocator;
class IIncident;


/** @class AtRndmGenSvc
 *  @brief A random number engine manager, based on Ranecu. 
 *  Its usage is deprecated, at least when high quality sequences of randoms
 *  are required (Ranecu period has been shown to be too short, and sensitive
 *  to the quality of initial seeds).
 *
 *  @details this service mantains a number of named, independent random
 *  number sequences. Each sequence is initialized by an entry of the form
 *  "SequenceName Seed1 Seed2" in the Seeds property. For example
 *  @code
 *   Seeds = [ "PYTHIA 4789899 989240512", "PYTHIA_INIT 820021 2347532",
 *             "JIMMY 390020611 821000366", "JIMMY_INIT 820021 2347532",
 *             "HERWIG 390020611 821000366", "HERWIG_INIT 820021 2347532" ]
 *
 *  @endcode
 *  At the end of the job  in AtRndmGenSvc::finalize(), the status of the
 *  engine is dumped as an array of unsigned long to the ASCII file
 *  "AtRndmGenSvc.out".  This file can be used to restore the status of the
 *  engine in another job by setting the properties
 *  @code
 *   ReadFromFile = true
 *   FileToRead = path_to_ascii_file
 *  @endcode
 */
class AtRndmGenSvc : virtual public IAtRndmGenSvc,
		     virtual public IIncidentListener,
		     public AthService
{
public:
    /// @name Interface to the CLHEP engine
    //@{
    HepRandomEngine*	GetEngine	( const std::string& StreamName );
    void		CreateStream	( long seed1, long seed2, const std::string& StreamName );
    bool		CreateStream	( std::vector<unsigned long> seeds, const std::string& StreamName );
    //@}

    /// CLHEP engines typedefs:
    typedef	std::map<std::string, RanecuEngine*>	engineMap;
    typedef	engineMap::iterator 			engineIter;
    typedef	engineMap::const_iterator		engineConstIter;  
    typedef	engineMap::value_type			engineValType;

    /// @name Stream access
    //@{
    engineConstIter	begin			(void)	const;
    engineConstIter	end			(void)	const;
    unsigned int	number_of_streams	(void)	const;    
    void		print		( const std::string& StreamName );
    void		print		( void );
    //@}

    ///set the seeds for an engine. First param will usually be the event number
    HepRandomEngine* setOnDefinedSeeds (int eventNumber, 
					const std::string& StreamName);
    ///set the seeds for an engine. Second param will usually be the run number
    HepRandomEngine* setOnDefinedSeeds (int eventNumber, 
					int runNumber,
					const std::string& StreamName);
  
    /// @name Gaudi Service Implementation
    //@{
    StatusCode initialize();
    StatusCode finalize();
    virtual StatusCode queryInterface( const InterfaceID& riid, 
				       void** ppvInterface );
    //@}

    /// IIncidentListener implementation. Handles EndEvent incident
    void handle(const Incident&);


private:
    typedef	std::vector< std::string >	VStrings;
    /// @name Properties
    //@{
    /// seeds for the engines, this is a vector of strings of the form "EnginName Seed1 Seed2"
    VStrings m_streams_seeds;   
    bool     m_read_from_file;  ///< read engine status from file
    std::string	m_file_to_read; ///< name of the file to read the engine status from
    bool m_save_to_file; ///< should current engine status be saved to file ?
    std::string m_file_to_write; ///< name of the file to save the engine status to.

    //@}

    engineMap	m_engines;
    /// Random engine copy (for output to a file)
    std::map<std::string, std::vector<long int> >	m_engines_copy;


    /// @name Default seed values
    //@{
    long m_default_seed1;
    long m_default_seed2;
    long m_PYTHIA_default_seed1;
    long m_PYTHIA_default_seed2;
    long m_HERWIG_default_seed1;
    long m_HERWIG_default_seed2;
    //@}

    void SetStreamSeeds( const std::string& StreamName );
    
public:
    
    // Standard Constructor
    AtRndmGenSvc(const std::string& name, ISvcLocator* svc);
        
    // Standard Destructor
    virtual ~AtRndmGenSvc();

};
 
inline	AtRndmGenSvc::engineConstIter
AtRndmGenSvc::begin			(void)	const
{ return m_engines.begin(); }

inline	AtRndmGenSvc::engineConstIter
AtRndmGenSvc::end			(void)	const
{ return m_engines.end(); }

inline	unsigned int
AtRndmGenSvc::number_of_streams		(void)	const
{ return m_engines.size(); }

#endif // ATRNDMGENSVC_H


