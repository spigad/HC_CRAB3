#ifndef HAVE_NEW_IOSTREAMS /*gnu-specific*/
#define BOOST_NO_STRINGSTREAM 1 /*FIXME should come from boost config */
#endif

#include "GaudiKernel/ISvcLocator.h"
#include "GaudiKernel/IIncidentSvc.h"
#include "GaudiKernel/Incident.h"

#include "CLHEP/Random/RandomEngine.h"

#include "StoreGate/tools/hash_functions.h"

#include "interpretSeeds.h"
#include "AtRanluxGenSvc.h"
#include <cassert>
#include <iostream>
using namespace std;

/// Standard Constructor
AtRanluxGenSvc::AtRanluxGenSvc(const std::string& name,ISvcLocator* svc)
  : AthService(name,svc), 
    m_read_from_file(false),
    m_file_to_read("AtRanluxGenSvc.out"),    
    m_save_to_file(true),
    m_file_to_write("AtRanluxGenSvc.out"),
    m_engines(), m_engines_copy()
{
    // Get user's input
    declareProperty("Seeds", m_streams_seeds,
		    "seeds for the engines, this is a vector of strings of the form ['SequenceName Seed1 Seed2', ...]");
    declareProperty("ReadFromFile", m_read_from_file,
		    "set/restore the status of the engine from file");
    declareProperty("FileToRead",   m_file_to_read,
		    "name of a ASCII file, usually produced by AtRanLuxGenSvc itself at the end of a job, containing the information to fully set/restore the status of Ranlux64");
    declareProperty("SaveToFile", m_save_to_file,
		    "save the status of the engine to file");
    declareProperty("FileToWrite",   m_file_to_write,
		    "name of an ASCII file which will be produced on finalize, containing the information to fully set/restore the status of Ranlux64");

    // Set Default values
    m_default_seed1		=	3591;
    m_default_seed2		=	2309736;
    m_PYTHIA_default_seed1	=	93453591;
    m_PYTHIA_default_seed2	=	73436;
    m_HERWIG_default_seed1	=	355391;
    m_HERWIG_default_seed2	=	97336;
}


/// Standard Destructor
AtRanluxGenSvc::~AtRanluxGenSvc()  
{
  engineIter i(m_engines.begin()), e(m_engines.end());
  while (i != e) delete (i++)->second;
}

// Query the interfaces.
//   Input: riid, Requested interface ID
//          ppvInterface, Pointer to requested interface
//   Return: StatusCode indicating SUCCESS or FAILURE.
// N.B. Don't forget to release the interface after use!!!
StatusCode 
AtRanluxGenSvc::queryInterface(const InterfaceID& riid, void** ppvInterface) 
{
    if ( IAtRndmGenSvc::interfaceID().versionMatch(riid) )    {
        *ppvInterface = (IAtRndmGenSvc*)this;
    }
    else  {
	// Interface is not directly available: try out a base class
	return AthService::queryInterface(riid, ppvInterface);
    }
    addRef();
    return StatusCode::SUCCESS;
}

StatusCode 
AtRanluxGenSvc::initialize()
{
  ATH_MSG_INFO
    ("Initializing " << name()
     << " - package version " << PACKAGE_VERSION 
     << "\n INITIALISING RANDOM NUMBER STREAMS. ");


  /// Incident Service
  IIncidentSvc* pIncSvc(0);

  // set up the incident service:
  if (!(service("IncidentSvc", pIncSvc, true)).isSuccess()) {
    ATH_MSG_ERROR ("Could not locate IncidentSvc ");
    return StatusCode::FAILURE;
  }
  
  //start listening to "EndEvent"
  static const int PRIORITY = 100;
  pIncSvc->addListener(this, "EndEvent", PRIORITY);


  if (m_read_from_file) {
    // Read from a file
    ifstream	infile( m_file_to_read.c_str() );
    if ( !infile ) {
      ATH_MSG_ERROR (" Unable to open: " << m_file_to_read);
      return StatusCode::FAILURE;
    } else {
      std::string buffer;
      while (std::getline(infile, buffer)) {
	string stream; 
	std::vector<unsigned long> seeds;
	//split the space-separated string in 3 words:
	if (interpretSeeds(buffer, stream, seeds)) {
	  msg (MSG::DEBUG) 
	    << " INITIALISING " << stream << " stream with seeds ";
	  for (std::vector<unsigned long>::const_iterator i = seeds.begin(); i != seeds.end(); ++i){
            // The state returned is a set of 32-bit numbers.
            // On 64-bit platforms, though, the vector holds 64-bit ints.
            // For the first word, one gets garbage in the high 32 bits.
            // (This is because the crc32 routine used in clhep
            // to hash the engine names doesn't mask down to 32 bits.)
            // So mask off the garbage so that we get consistent results
            // across platforms.
            msg() << ((*i) & 0xffffffffu) << " ";
	  }
	  msg() << " read from file " << m_file_to_read << endreq;
	  if (CreateStream(seeds, stream)) {
	    msg(MSG::DEBUG)
	      << stream << " stream initialized succesfully" <<endreq;
	  } else {
	    msg(MSG::ERROR)
	      << stream << " stream FAILED to initialize" <<endreq;
	    return StatusCode::FAILURE;
	  }
	} else {		
	  msg(MSG::ERROR)
	    << "bad line\n" << buffer 
	    << "\n in input file " << m_file_to_read << endreq;
	  return StatusCode::FAILURE;
	}		
      }
      
    }
  }

  // Create the various streams according to user's request
  for (VStrings::const_iterator i = m_streams_seeds.begin(); i != m_streams_seeds.end(); ++i) {
    string stream; 
    long seed1, seed2;
    //split the space-separated string in 3 words:
    if (interpretSeeds(*i, stream, seed1, seed2)) {
    ATH_MSG_VERBOSE
      ("Seeds property: stream " << stream 
       << " seeds " << seed1 << ' ' << seed2);
    } else {
      ATH_MSG_ERROR ("bad Seeds property\n" << (*i));
      return StatusCode::FAILURE;
    }		
    	
    // Check if stream already generated (e.g. from reading a file)
    bool				not_found	=	true;
    if ( number_of_streams() != 0 ) {
      AtRanluxGenSvc::engineConstIter sf 		= 	begin();
      do {
	if ((*sf).first == stream) not_found = false;
	++sf;
      } while (sf != end() && not_found);
    }
	
    if (not_found) {
      ATH_MSG_DEBUG
	(" INITIALISING " << stream << " stream with seeds "
	 << seed1 << "  " << seed2);
      CreateStream(seed1, seed2, stream);
    }
    
  }
  return StatusCode::SUCCESS;
}

void 
AtRanluxGenSvc::handle(const Incident &inc) {
  ATH_MSG_DEBUG (" Handle EndEvent ");

  if ( inc.type() == "EndEvent") 
  {

    m_engines_copy.clear();
    for (engineConstIter i = begin(); i != end(); ++i)
    {
      HepRandomEngine* engine = GetEngine((*i).first);
      std::vector<unsigned long> tseeds = engine->put();
      m_engines_copy.insert(std::map<std::string,
			    std::vector<unsigned long> >::value_type( (*i).first,
								 tseeds ) );
    }
    
    print();    
  }
}

StatusCode 
AtRanluxGenSvc::finalize()
{
  ATH_MSG_INFO (" FINALISING ");

  if (m_save_to_file) {
    // Write the status of the Service to file
    std::ofstream outfile( m_file_to_write.c_str() );
    if ( !outfile ) {
      ATH_MSG_ERROR ("error: unable to open: " << m_file_to_write);
    } else {
      for (std::map<std::string, std::vector<unsigned long> >::const_iterator i = m_engines_copy.begin();
	   i != m_engines_copy.end();
	   ++i) {
	outfile << (*i).first << " ";
	for (std::vector<unsigned long>::const_iterator j = (*i).second.begin(); j !=(*i).second.end(); ++j){
	  outfile << (*j) << " ";
	}
	outfile << endl;
      }
      ATH_MSG_DEBUG (" wrote seeds to " << m_file_to_write );
      
    }
  }
  return AthService::finalize();
}

HepRandomEngine*
AtRanluxGenSvc::GetEngine	( const std::string& StreamName )
{
    engineConstIter citer = m_engines.find(StreamName);
    if ( citer == m_engines.end() )
    {
	m_engines.insert( engineValType( StreamName, new Ranlux64Engine() ) );
	SetStreamSeeds	( StreamName );
    }
    
    engineIter	iter	=	m_engines.find(StreamName);
    return	(HepRandomEngine*)(*iter).second;
}

void
AtRanluxGenSvc::CreateStream	( long seed1, long seed2, const std::string& StreamName )
{
    long seeds[2] = { seed1, seed2 };
    const long* s = seeds;
    engineConstIter citer = m_engines.find(StreamName);
    if ( citer == m_engines.end() ) m_engines.insert( engineValType(	StreamName,
									new Ranlux64Engine() ) );
    engineIter	iter	=	m_engines.find(StreamName);
//     ((*iter).second)->setSeeds( s, -1 );
    ((*iter).second)->setSeed( s[0], 3 );
}

bool
AtRanluxGenSvc::CreateStream	( std::vector<unsigned long> seeds, const std::string& StreamName )
{
    engineConstIter citer = m_engines.find(StreamName);
    if ( citer == m_engines.end() ) m_engines.insert( engineValType(	StreamName,
									new Ranlux64Engine() ) );
    engineIter	iter	=	m_engines.find(StreamName);
//     ((*iter).second)->setSeeds( s, -1 );
    return ((*iter).second)->getState( seeds );
}

void
AtRanluxGenSvc::SetStreamSeeds	( const std::string& StreamName )
{
    long seed1;
    long seed2;
    if (StreamName == "PYTHIA")
    {
	seed1 = m_PYTHIA_default_seed1;
	seed2 = m_PYTHIA_default_seed2;
    }
    else if (StreamName == "HERWIG")
    {
	seed1 = m_HERWIG_default_seed1;
	seed2 = m_HERWIG_default_seed2;
    }
    else
    {
	seed1 = m_default_seed1;
	seed2 = m_default_seed2;
    }
    ATH_MSG_WARNING
      (" INITIALISING " << StreamName << " stream with DEFAULT seeds "
       << seed1 << "  " << seed2);
    
    long seeds[2] = { seed1, seed2 };
    const long* s = seeds;
    engineIter	iter	=	m_engines.find(StreamName);
//     ((*iter).second)->setSeeds( s, -1 );
    ((*iter).second)->setSeed( s[0], 3 );
}

void
AtRanluxGenSvc::print	( const std::string& StreamName )
{
    engineConstIter citer = m_engines.find(StreamName);
    if ( citer == m_engines.end() ) {
      ATH_MSG_WARNING (" Stream =  " << StreamName << " NOT FOUND");
    } else {
      std::vector<unsigned long> v = ((*citer).second)->put();
      msg(MSG::INFO) << " Stream =  " << StreamName << " ";
      for (std::vector<unsigned long>::const_iterator i = v.begin(); i != v.end(); ++i){
        // The state returned is a set of 32-bit numbers.
        // On 64-bit platforms, though, the vector holds 64-bit ints.
        // For the first word, one gets garbage in the high 32 bits.
        // (This is because the crc32 routine used in clhep
        // to hash the engine names doesn't mask down to 32 bits.)
        // So mask off the garbage so that we get consistent results
        // across platforms.
	msg() << ((*i) & 0xffffffffu) << " ";
      }
      msg() << endreq;
    }
}

void
AtRanluxGenSvc::print	( void )
{
    for (engineConstIter i = m_engines.begin(); i != m_engines.end(); ++i)
	print( (*i).first );
}

HepRandomEngine*
AtRanluxGenSvc::setOnDefinedSeeds	(int eventNumber, int runNumber,
				 const std::string& StreamName)
{
  engineConstIter citer = m_engines.find(StreamName);
  if ( citer == m_engines.end() ) m_engines.insert( engineValType(	StreamName,
									new Ranlux64Engine() ) );
  engineIter	iter	=	m_engines.find(StreamName);
  int hashedStream(SG::simpleStringHash(StreamName));
  long seeds[2] = { 1000*runNumber + hashedStream, 
		    eventNumber };
  assert( seeds[0] > 0 );
  assert( seeds[1] > 0 );
  const long* s = seeds;
//   ((*iter).second)->setSeeds( s, -1 );
  ((*iter).second)->setSeed( s[0], 3 );
  return	(HepRandomEngine*)(*iter).second;
}

HepRandomEngine*
AtRanluxGenSvc::setOnDefinedSeeds	(int eventNumber, const std::string& StreamName){
  engineConstIter citer = m_engines.find(StreamName);
  if ( citer == m_engines.end() ) m_engines.insert( engineValType(	StreamName,
									new Ranlux64Engine() ) );
  engineIter	iter	=	m_engines.find(StreamName);
  int hashedStream(SG::simpleStringHash(StreamName));
  long seeds[2] = { hashedStream % (eventNumber+13), 
		    eventNumber };
  assert( seeds[0] > 0 );
  assert( seeds[1] > 0 );
  const long* s = seeds;
//   ((*iter).second)->setSeeds( s, -1 );
  ((*iter).second)->setSeed( s[0], 3 );
  return	(HepRandomEngine*)(*iter).second;
}

