## Hook for AthenaServices genConf module
