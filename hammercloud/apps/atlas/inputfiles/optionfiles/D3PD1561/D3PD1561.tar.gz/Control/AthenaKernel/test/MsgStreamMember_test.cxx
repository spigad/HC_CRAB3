/**
 * @file  MsgStreamMember_test.cxx
 * @brief Example/Regression test for @class Athena::MsgStreamMember
 *
 * @author Paolo Calafiura
 * $Id: MsgStreamMember_test.cxx,v 1.1 2008-07-14 22:10:14 calaf Exp $
 */
#undef NDEBUG
#include <cassert>
#include "TestTools/initGaudi.h"
#include "AthenaKernel/MsgStreamMember.h"

using namespace Athena;
class Mine {
public:
  Mine() : 
    //this is how you would set m_stream in a (data)obj w/o access to IMessageSvc*
    m_stream(name()) {}
  const std::string& name() const { 
    static const std::string n("Mine"); 
    return n;
  }
  void printIt() {
    m_stream << MSG::ALWAYS << "*** Mine works ***" <<endmsg;
  }
private:
  MsgStreamMember m_stream;
};
class Yours {
public:
  Yours(IMessageSvc* ims) :
    //this would be the typical way to construct m_stream in e.g. a Service
    m_stream(ims, name()) {}
  const std::string& name() const {  
    static const std::string n("Yours"); 
    return n;
  }

  void printIt() {
    m_stream << MSG::ALWAYS << "*** Yours works too ***" <<endmsg;
  }
private:
  Athena::MsgStreamMember m_stream;
};

class Hers {
public:
  Hers(IMessageSvc* ims) {
    //this would be another (less preferred) way to construct m_stream
    m_stream = MsgStreamMember(ims, name());
  }
  const std::string& name() const {  
    static const std::string n("Hers"); 
    return n;
  }

  void printIt() {
    m_stream << MSG::ALWAYS << "*** reporting ***" <<endmsg;
  }
private:
  Athena::MsgStreamMember m_stream;
};

int main() {
  ISvcLocator* pDum;
  assert( Athena_test::initGaudi(pDum) );
  IMessageSvc *pMS(Athena::getMessageSvc());
  assert( pMS );
  //usual nasty trick to get the ref count
  pMS->addRef();
  unsigned int refCount(pMS->release());
  {
    Mine my;
    my.printIt();
    Yours you(pMS);
    Yours alsoYours(you);
    alsoYours.printIt();
    Hers her(pMS);
    her.printIt();
  } //my, you, etc destructors called
  pMS->addRef();
  assert(pMS->release() == refCount);

  std::cout << "*** MsgStreamMember_test OK ***" <<std::endl;
  return 0;
}
