// File: AthDsoLogger.c
// Author: Wim Lavrijsen (WLavrijsen@lbl.gov)
// Created: 01/16/09
// Last: 01/16/09
//
// Implement dlfcn hooks in order to log whenever dlopen is called.
//
// adapted by S.Binet for logging purposes.

#if defined(linux)

#define _GNU_SOURCE 1

#include <stdio.h>

#ifdef _POSIX_C_SOURCE
#undef _POSIX_C_SOURCE
#endif

#ifdef _FILE_OFFSET_BITS
#undef _FILE_OFFSET_BITS
#endif

#include "Python.h"

#include <dlfcn.h>
#include <stdlib.h>
#include <unistd.h> /*for sysconf and page size*/
#include <assert.h>

/* type of the callback function the dso logger will execute */
typedef int (*DsoFctCb_t) (const char* libname, int step);

/* return the VMem in kilo-bytes */
static
float fetch_vmem (void);

/* default callback function */
static
int ath_default_cb (const char* libname, int step);

/* handle to the callback function */
static DsoFctCb_t cb_fct = ath_default_cb;

struct dlfcn_hook
{
  void *(*dlopen) (const char *file, int mode, void *dl_caller);
  int (*dlclose) (void *handle);
  void *(*dlsym) (void *handle, const char *name, void *dl_caller);
  void *(*dlvsym) (void *handle, const char *name, const char *version,
                   void *dl_caller);
  char *(*dlerror) (void);
  int (*dladdr) (const void *address, Dl_info *info);
  int (*dladdr1) (const void *address, Dl_info *info,
                  void **extra_info, int flags);
  int (*dlinfo) (void *handle, int request, void *arg, void *dl_caller);
  void *(*dlmopen) (Lmid_t nsid, const char *file, int mode, void *dl_caller);
  void *pad[4];
};

extern struct dlfcn_hook *_dlfcn_hook __attribute__ ((nocommon));

void *ath_dlopen( const char *fname, int mode, void *dl_caller );
int ath_dlclose( void *handle );
void *ath_dlsym( void *handle, const char *name, void *dl_caller );
void *ath_dlvsym( void *handle, const char *name, const char *version, void *dl_caller );
char *ath_dlerror( void );
int ath_dladdr( const void *address, Dl_info *info );
int ath_dladdr1( const void *address, Dl_info *info, void **extra_info, int flags );
int ath_dlinfo( void *handle, int request, void *arg, void *dl_caller );
void *ath_dlmopen( Lmid_t nsid, const char *file, int mode, void *dl_caller );

/* setup the library */
void ath_dl_hook_install (DsoFctCb_t cb);

/* release the library */
void ath_dl_hook_release ();

static struct dlfcn_hook ath_dl_hook = {
  ath_dlopen, ath_dlclose, ath_dlsym, ath_dlvsym, ath_dlerror,
  ath_dladdr, ath_dladdr1, ath_dlinfo, ath_dlmopen, { 0, 0, 0, 0 }
};

void* 
ath_dlopen( const char *fname, int mode, void *dl_caller ) 
{
  void *result = 0;
  _dlfcn_hook = 0;

  assert (cb_fct);
  (*cb_fct) (fname, 0);
  result = dlopen( fname, mode );
  (*cb_fct) (fname, 1);

  _dlfcn_hook = &ath_dl_hook;

  return result;
}

int
ath_dlclose( void *handle ) 
{
  int result = 0;
  _dlfcn_hook = 0;
  result = dlclose( handle );
  _dlfcn_hook = &ath_dl_hook;
  return result;
}

void*
ath_dlsym( void *handle, const char *name, void *dl_caller ) 
{
  void *result = 0;
  _dlfcn_hook = 0;
  result = dlsym( handle, name );
  _dlfcn_hook = &ath_dl_hook;
  return result;
}

void*
ath_dlvsym( void *handle, const char *name, const char *version, void *dl_caller ) 
{
  void *result = 0;
  _dlfcn_hook = 0;
  result = dlvsym( handle, name, version );
  _dlfcn_hook = &ath_dl_hook;
  return result;
}

char*
ath_dlerror( void ) 
{
  char *result = 0;
  _dlfcn_hook = 0;
  result = dlerror();
  _dlfcn_hook = &ath_dl_hook;
  return result;
}

int
ath_dladdr( const void *address, Dl_info *info ) 
{
  int result = 0;
  _dlfcn_hook = 0;
  result = dladdr( address, info );
  _dlfcn_hook = &ath_dl_hook;
  return result;
}

int
ath_dladdr1( const void *address, Dl_info *info, void **extra_info, int flags ) 
{
  int result = 0;
  _dlfcn_hook = 0;
  result = dladdr1( address, info, extra_info, flags );
  _dlfcn_hook = &ath_dl_hook;
  return result;
}

int
ath_dlinfo( void *handle, int request, void *arg, void *dl_caller ) 
{
  int result = 0;
  _dlfcn_hook = 0;
  result = dlinfo( handle, request, arg );
  _dlfcn_hook = &ath_dl_hook;
  return result;
}

void*
ath_dlmopen( Lmid_t nsid, const char *file, int mode, void *dl_caller ) 
{
  void *result = 0;
  _dlfcn_hook = 0;
  result = dlmopen( nsid, file, mode );
  _dlfcn_hook = &ath_dl_hook;
  return result;
}

void
ath_dl_hook_install (DsoFctCb_t cb) {
/*   printf ("AthDsoLogger: setting dlopen hooks\n" ); */
  _dlfcn_hook = &ath_dl_hook;
/*   printf ("AthDsoLogger: installing callback-fct\n" ); */
  cb_fct = cb;
}

void ath_dl_hook_release ()
{
  _dlfcn_hook = 0;
  printf ("AthDsoLogger: releasing library\n");
  cb_fct = ath_default_cb;
}

float
fetch_vmem (void)
{
  unsigned siz, rss, shd;
  FILE *fp = fopen ("/proc/self/statm", "r");
  assert (fp);
  
  /* FIXME: error handling... */
  fscanf(fp, "%u%u%u", &siz, &rss, &shd);
  fclose (fp);

  double pg_sz = sysconf(_SC_PAGESIZE);
  return (pg_sz * siz)/ (float)1024;
}

int 
ath_default_cb (const char* libname, int step)
{
  int pid = getpid();
  float vmem = fetch_vmem();
  printf ("AthLdPreload: [%d] loading [%s] vmem = [%8.3f] (%d)",
	  pid, libname, vmem, step);

  return 0;
}

#endif /* !linux */
