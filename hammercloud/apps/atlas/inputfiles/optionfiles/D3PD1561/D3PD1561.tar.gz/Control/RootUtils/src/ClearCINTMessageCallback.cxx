// $Id: ClearCINTMessageCallback.cxx,v 1.1 2007-10-19 21:03:00 ssnyder Exp $
/**
 * @file RootUtils/src/ClearCINTMessageCallback.cxx
 * @author scott snyder
 * @date Oct 2007
 * @brief Clear Cint's error message callback.
 */


#include "RootUtils/ClearCINTMessageCallback.h"
#include "Api.h"


namespace RootUtils {


/**
 * @brief Clear Cint's error message callback.
 */
void ClearCINTMessageCallback::initialize()
{
  G__set_errmsgcallback (0);
}


} // namespace RootUtils
