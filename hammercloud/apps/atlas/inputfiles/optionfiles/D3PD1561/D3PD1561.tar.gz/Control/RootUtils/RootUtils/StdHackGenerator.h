// This file's extension implies that it's C, but it's really -*- C++ -*-.
// $Id: StdHackGenerator.h,v 1.4 2008-03-20 15:30:00 ssnyder Exp $

/**
 * @file  RootUtils/StdHackGenerator.h
 * @author scott snyder
 * @date Oct 2007
 * @brief Work around inconsistent use of @c std:: and spaces.
 */

#ifndef ROOTUTILS_STDHACKGENERATOR_H
#define ROOTUTILS_STDHACKGENERATOR_H

#include "TClassGenerator.h"


namespace RootUtils {


/**
 * @brief Work around inconsistent use of @c std:: and spaces.
 *
 * Sometimes, when Athena is requesting a class to autoload (via @c GetClass),
 * the name that's requested omits some of the @c std:: qualifications
 * in front of the STL names.  One usually finds, though, that the
 * autoload database contains the full @c std::-qualified names.  Thus,
 * the autoload fails.
 *
 * For example, we may be asked to load a class with a name like
 *@code
 *   Navigable<foo,vector<...> >
 @endcode
 * but what's in the rootmap file is
 *@code
 *   Navigable<foo,std::vector<...> >
 @endcode
 *
 * Root does provide a way to hook into class autoloading ---
 * a @c TClassGenerator, which is called when autoloading fails.
 * Thus, we create an autoloader such that when autoloading fails,
 * it tries again with any missing @c std:: qualifications reinserted.
 *
 * With 5.18, we run into a similar problem with pairs of names like
 * __gnu_cxx::__normal_iterator<HepMC::GenParticle*const*,vector<HepMC::GenParticle*> >
 * and
 * __gnu_cxx::__normal_iterator<HepMC::GenParticle* const*,vector<HepMC::GenParticle*> >
 *
 * We do a fixup for this case too.
 *
 * ??? FIXME: Find out why the bad names are being requested
 * in the first place.
 */
class StdHackGenerator
  : public TClassGenerator
{
public:
  /**
   * @brief Initialize.
   *        Create an instance of this class and register it as a generator.
   */
  static void initialize();


  /**
   * @brief Look up a class by name.
   * @param classname The name of the class to find.
   * @param load If true, enable autoloading.
   */
  virtual TClass *GetClass(const char* classname, Bool_t load);


  /**
   * @brief Look up a class by @c type_info.
   * @param typeinfo The @c type_info of the class to find.
   * @param load If true, enable autoloading.
   */
  virtual TClass *GetClass(const type_info& typeinfo, Bool_t load);
};


} // namespace RootUtils


#endif // not ROOTUTILS_STDHACKGENERATOR_H
