// $Id: TTreeIndexRemap.cxx,v 1.1 2008-03-21 05:24:40 ssnyder Exp $
/**
 * @file  RootUtils/src/pyroot/TTreeIndexRemap.cxx
 * @author scott snyder
 * @date Mar 2008
 * @brief Work around index naming issues in reading DPDs.
 */


#include "RootUtils/TTreeIndexRemap.h"
#include "TROOT.h"
#include "TClass.h"
#include "TTree.h"
#include "TError.h"
#include <map>


namespace RootUtils {


std::map<std::string, std::string> s_index_namemap;


/**
 * @brief Return a pointer to the @c TreeFormula corresponding to the
 *        majorname in parent tree T.
 * @param T The parent tree.
 *
 * The column name is remapped, if needed.
 */
TTreeFormula* TTreeIndexRemap::GetMajorFormulaParent(const TTree *T)
{
  if (!fMajorFormulaParent)
    maybe_remap (T, fMajorName);
  return TTreeIndex::GetMajorFormulaParent (T);
}


/**
 * @brief Return a pointer to the @c TreeFormula corresponding to the
 *        minorname in parent tree T.
 * @param T The parent tree.
 *
 * The column name is remapped, if needed.
 */
TTreeFormula* TTreeIndexRemap::GetMinorFormulaParent(const TTree *T)
{
  if (!fMinorFormulaParent)
    maybe_remap (T, fMinorName);
  return TTreeIndex::GetMinorFormulaParent (T);
}


/**
 * @brief Set up so that this class gets used for TTreeIndex on reading.
 */
void TTreeIndexRemap::initialize()
{
  static bool initialized = false;
  if (initialized)
    return;
  initialized = true;

  TClass* cl = gROOT->GetClass ("TTreeIndex", true);
  if (!cl) {
    ::Error ("RootUtils::TTreeIndexRemap",
             "Can't find TClass for TTreeIndex");
    return;
  }

  // Change the @c New() method for @c TTreeIndex to make
  // an instance of this class instead.
  cl->SetNew (TTreeIndexRemap::new_TTreeIndexRemap);
}


/**
 * @brief new() method for this object.
 * @param p Address for placement new, or 0.
 * @return Address of the new object.
 *
 * This is installed as the @c New method in @c TTreeIndex's @c TClass.
 * Thus, when we read from a file a @c TTreeIndex, we actually
 * make an instance of this class.
 */
void* TTreeIndexRemap::new_TTreeIndexRemap (void *p)
{
  if (p)
    return new (p) TTreeIndexRemap;
  return new TTreeIndexRemap;
}


/**
 * @brief Change the index column name if needed.
 * @param t The parent tree.
 * @param name The index column name or formula.
 *
 * If @a name is not a member of @a t and there's a mapping
 * entry for it, change @a name to the target of the mapping.
 */
void TTreeIndexRemap::maybe_remap (const TTree* t, TString& name)
{
  // Test to see if NAME is a branch in T.
  // Must actually be in T, not in a friend.
  TTree* thist = t->GetTree();
  TBranch* br = thist->GetBranch (name.Data());
  if (!br || br->GetTree() != thist) {
    std::map<std::string, std::string>::iterator i =
      s_index_namemap.find (name.Data());
    if (i != s_index_namemap.end()) {
      name = i->second;
    }
  }
}


/**
 * @brief Register a new name mapping.
 * @param from The source of the mapping.
 * @param to The target of the mapping.
 */
void
TTreeIndexRemap::add_mapping (const std::string& from, const std::string& to)
{
  s_index_namemap[from] = to;
}


} // namespace RootUtils
