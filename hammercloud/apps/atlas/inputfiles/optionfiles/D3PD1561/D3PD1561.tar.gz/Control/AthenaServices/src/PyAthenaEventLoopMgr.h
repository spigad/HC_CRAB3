#ifndef ATHENASERVICES_PYATHENAEVENTLOOPMGR_H
#define ATHENASERVICES_PYATHENAEVENTLOOPMGR_H
/** @file PyAthenaEventLoopMgr.h
    @brief Implementation of the AthenaEventLoopMgr that allows selective and
    specific overrides in python. The idea is to maximize code-sharing
    with AthenaEventLoopMgr to reduce maintainance.

   $Id: PyAthenaEventLoopMgr.h,v 1.4 2009-05-04 21:24:41 wlav Exp $
   @author Atlas 
*/

// Framework include files
#ifndef ATHENASERVICES_ATHENAEVENTLOOPMGR_H
 #include "AthenaEventLoopMgr.h"
#endif

// Gaudi
class ISvcLocator;

// Python
struct _object;
typedef _object PyObject;

// Standard
#include <string>


/** @class PyAthenaEventLoopMgr
    @brief Implementation of the AthenaEventLoopMgr that allows selective and
    specific overrides in python. The idea is to maximize code-sharing
    with AthenaEventLoopMgr to reduce maintainance.
*/
class PyAthenaEventLoopMgr : public AthenaEventLoopMgr   {
public:
  /// outside access
  static PyAthenaEventLoopMgr* pointer();

  /// Creator friend class
  friend class SvcFactory< PyAthenaEventLoopMgr >;

  /// actual manager object
  PyObject* setManager( PyObject* );
  PyObject* getManager();

protected:
   /// Unimplemented features to keep Reflex happy
   PyAthenaEventLoopMgr(); // Not implemented
   PyAthenaEventLoopMgr( const PyAthenaEventLoopMgr& ); // Not implemented
   PyAthenaEventLoopMgr& operator = ( const PyAthenaEventLoopMgr& ); // Not implemented
	
  /// Standard Constructor
  PyAthenaEventLoopMgr( const std::string& name, ISvcLocator* svcLoc );
  ~PyAthenaEventLoopMgr() {}

  /// Run the algorithms for the current event
  virtual StatusCode executeAlgorithms();

private:
   PyObject* m_manager;
};


// the following is a bit of an unfortunate hack
class PyAthenaEventLoopMgrHelper {
public:

   static PyObject* SetPyAthenaEventLoopMgrManager( IProperty*, PyObject* );

};

#endif // !ATHENASERVICES_PYATHENAEVENTLOOPMGR_H
