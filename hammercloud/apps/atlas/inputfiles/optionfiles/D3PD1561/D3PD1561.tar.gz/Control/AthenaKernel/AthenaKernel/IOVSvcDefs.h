#ifndef ATHENAKERNEL_IOVSVCDEFS_H
#define ATHENAKERNEL_IOVSVCDEFS_H
/**
 * @file IOVSvcDefs.h
 * @author Charles Leggett
 *  $Id: IOVSvcDefs.h,v 1.3 2007-06-14 01:57:23 calaf Exp $ 
 * @brief defines and typedefs for IOVSvc 
 */

#ifndef _CPP_LIST
 #include <list>
#endif
#ifndef _CPP_STRING
 #include <string>
#endif

/**
 * @brief short hand for IOVSvc call back argument list, to be used
 * when no access to formal arguments is needed, e.g. in method declaration (.h)
 * @code
 * StatusCode callBack( IOVSVC_CALLBACK_ARGS );
 * @endcode
 */
#define IOVSVC_CALLBACK_ARGS int&,std::list<std::string>&

/**
 * @brief short hand for IOVSvc call back argument list, to be used 
 *when access to formal arguments is needed, e.g. in method definition (.cxx)
 * @code
 * StatusCode CoolHistExample::callBack( IOVSVC_CALLBACK_ARGS_P(I,keys) ) {
 * @endcode
 */
#define IOVSVC_CALLBACK_ARGS_P(I,K) int& I,std::list<std::string>& K


#include "boost/function.hpp"


#ifndef KERNEL_STATUSCODES_H
 #include "GaudiKernel/StatusCode.h"
#endif

/* This can also be done as:
typedef boost::function2< StatusCode, IOVSVC_CALLBACK_ARGS > IOVSvcCallBackFcn;
*/

/// the type of an IOVSvc call back: it wraps both the method and the object
/// the method is called on
typedef boost::function< StatusCode (IOVSVC_CALLBACK_ARGS) > IOVSvcCallBackFcn;

#endif
