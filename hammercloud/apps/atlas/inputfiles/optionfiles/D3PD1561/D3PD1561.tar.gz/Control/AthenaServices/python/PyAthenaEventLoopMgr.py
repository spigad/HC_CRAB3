## @file PyAthenaEventLoopMgr.py
#  @brief Python facade of PyAthenaEventLoopMgr
#  @author Wim Lavrijsen (WLavrijsen@lbl.gov)

from AthenaCommon.AppMgr import ServiceMgr as svcMgr
from AthenaCommon import CfgMgr

def _installPyAthenaEventLoopMgr():
   """Various fix-up and improvements to the application manager for
   interactive purposes.
   """
   from AthenaCommon.AppMgr import ServiceMgr as svcMgr
   # Patch application manager to add methods for seeking.
   from AthenaCommon.AppMgr import AppMgr

   def seek(self, n):
      # fetch event loop mgr
      import AthenaPython.PyAthena as PyAthena
      svc = PyAthena.py_svc(self.EventLoop, iface='IEventSeek')
      if not svc:
         raise RuntimeError('could not retrieve an EventLoopMgr with the'\
                            'correct interface (IEventSeek)')
      sc = svc.seek(n)
      # don't leave unchecked statuscodes...
      if sc.isSuccess():
         return sc
      return sc
   AppMgr.seek = seek
   del seek

   def seekEvent(self, n):
      sc = self.seek(n)
      if not sc.isSuccess():
         return sc
      sc = self.nextEvent()
      if not sc.isSuccess():
         return sc
      return sc
   AppMgr.seekEvent = seekEvent
   del seekEvent

   def curEvent(self):
      # fetch event loop mgr
      import AthenaPython.PyAthena as PyAthena
      svc = PyAthena.py_svc(self.EventLoop, iface='IEventSeek')
      if not svc:
         raise RuntimeError('could not retrieve an EventLoopMgr with the'\
                            'correct interface (IEventSeek)')
      return svc.curEvent()
   AppMgr.curEvent = curEvent
   del curEvent


def setupEvtSelForSeekOps():
   """ try to install seek-stuff on the EventSelector side """
   import sys
   from AthenaCommon.Logging import log as msg
   if not sys.modules.has_key('AthenaPoolCnvSvc.ReadAthenaPool'):
      ## user did not import that module so we give up
      msg.debug( "Cannot enable 'seeking' b/c module " + \
                 "[AthenaPoolCnvSvc.ReadAthenaPool] hasn't been imported..." )
      msg.debug( "Modify your jobOptions to import that module "+ \
                 "(or just ignore this message)" )
      return

   from AthenaCommon.AppMgr import theApp, AthAppMgr
   if theApp.state() != AthAppMgr.State.OFFLINE:
      msg.info( "C++ ApplicationMgr already instantiated, probably seeking "+\
                "will be ill-configured..." )
      msg.info( "EventSelector writers should implement updateHandlers" )
   
   from AthenaCommon.AppMgr import ServiceMgr as svcMgr
   from AthenaCommon.Configurable import Configurable
   collectionType = svcMgr.EventSelector.properties()["CollectionType"]

   if collectionType in ( "ImplicitROOT", Configurable.propertyNoValue, ):
      svcMgr.EventSelector.CollectionType = "SeekableROOT"
      msg.info   ( "=> Seeking enabled." )

   elif collectionType in ( "SeekableROOT", ):
      msg.verbose( "=> Seeking already enabled." )

   else:
      msg.warning( "Input seeking is not compatible with collection type of %s",
                   svcMgr.EventSelector.properties()["CollectionType"] )
      msg.warning( "=> Seeking disabled." )


## @class _PyAthenaEventLoopMgrClass
#  @brief Python facade of PyAthenaEventLoopMgr.
#  combine python property and bound interfaces (FIXME: this uses internal code)
class PyAthenaEventLoopMgr( CfgMgr.PyAthenaEventLoopMgr ):

   def __init__( self, name = 'PyAthenaEventLoopMgr', **kw ):
      
      # have to call base init
      kw['name'] = name
      super( PyAthenaEventLoopMgr, self ).__init__( **kw )

      self.__dict__[ '_isvc' ] = None

      ## try to install seek'ing capabilities
      setupEvtSelForSeekOps()
      
      return

   def setDefaults( cls, handle ):

      ## carry on, only if it is our Configurable
      if not isinstance( handle, PyAthenaEventLoopMgr ):
         return

      ## only run once
      if handle.__dict__[ '_isvc' ] != None:
         return
      
      ## try to install seek'ing capabilities
      setupEvtSelForSeekOps()
      ## various fix-up to the application manager
      _installPyAthenaEventLoopMgr()

      import PyCintex
      try:                from GaudiPython.Bindings import iService
      except ImportError: from gaudimodule import iService
      # FIXME: make sure the real C++ application has been instantiated ?
      # from AthenaCommon.AppMgr import theApp
      # cppApp = theApp.getHandle()
      handle.__dict__[ '_isvc' ] = iService( 'PyAthenaEventLoopMgr' )
      PyCintex.gbl.PyAthenaEventLoopMgrHelper.SetPyAthenaEventLoopMgrManager(
         handle._isvc.getInterface(), handle )

      return
   
   def __getattr__( self, name ):

      if name in super(PyAthenaEventLoopMgr, self).__slots__:
         return super(PyAthenaEventLoopMgr, self).__getattribute__(name)
      
      return getattr( self._isvc, name )
            
   def __setattr__( self, name, value ):
    # required b/c the lookup is otherwise intercepted by iProperty
      if name[0] == '_':           # private properties
         return object.__setattr__( self, name, value )

      if self.__dict__['_isvc'] != None:
         setattr( self._isvc, name, value )
      else:
         super( PyAthenaEventLoopMgr, self ).__setattr__( name, value )

   def executeAlgorithms( self ):
      try:                   import GaudiPython.Bindings as PyGaudi
      except AttributeError: import GaudiPython          as PyGaudi
      except ImportError:    import gaudimodule          as PyGaudi
      from AthenaCommon.AppMgr import theApp

      result = PyGaudi.SUCCESS

      try:
         for name in theApp.TopAlg:
            alg = theApp.algorithm( name[ name.find('/')+1 : ] )
            if not alg._ialg:
               alg.retrieveInterface()
            ialg = alg._ialg
            ialg.resetExecuted()
            result = ialg.sysExecute()
            if result.isFailure():
               from AthenaCommon.Logging import log as msg
               msg.error( "Execution of algorithm %s failed" % name )
               return result.getCode()
      except KeyboardInterrupt:
         from AthenaCommon.Logging import log as msg
         msg.critical( "event loop stopped by user interrupt" )
         return PyGaudi.FAILURE.getCode()

      return result.getCode()

   def properties( self ):
      if self.__dict__[ '_isvc' ] != None:
         return self.__dict__[ '_isvc' ].properties()
      else:
         return super( PyAthenaEventLoopMgr, self ).properties()

   def seek (self, evt):
      # redirect to AppMgr
      from AthenaCommon.AppMgr import theApp
      return theApp.seek(evt)

   def curEvent (self):
      # redirect to AppMgr
      from AthenaCommon.AppMgr import theApp
      return theApp.curEvent()

   def name (self):
      return "PyAthenaEventLoopMgr"


## install our own customized version
CfgMgr.PyAthenaEventLoopMgr = PyAthenaEventLoopMgr

# the event loop manager instance
svcMgr += PyAthenaEventLoopMgr( 'PyAthenaEventLoopMgr' )
EventLoopMgr = svcMgr.PyAthenaEventLoopMgr
