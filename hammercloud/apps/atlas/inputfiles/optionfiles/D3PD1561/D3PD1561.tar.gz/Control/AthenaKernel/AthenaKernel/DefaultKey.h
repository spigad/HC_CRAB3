#ifndef ATHENAKERNEL_DEFAULTKEY_H
#define ATHENAKERNEL_DEFAULTKEY_H

#include <string>

namespace SG
{
  const std::string DEFAULTKEY = "";
}
#endif
