///////////////////////// -*- C++ -*- /////////////////////////////
// PyAthenaAlg.cxx 
// Implementation file for class PyAthena::Alg
// Author: S.Binet<binet@cern.ch>
/////////////////////////////////////////////////////////////////// 

// Python includes
#include "Python.h"

// PyROOT includes
#include "TPython.h"

// AthenaPython includes
#include "AthenaPython/PyAthenaUtils.h"
#include "AthenaPython/PyAthenaAlg.h"

// STL includes

// FrameWork includes
#include "GaudiKernel/System.h"
#include "GaudiKernel/MsgStream.h"
#include "GaudiKernel/ServiceHandle.h"
#include "AthenaPython/IPyComponentMgr.h"

namespace PyAthena {

/////////////////////////////////////////////////////////////////// 
// Public methods: 
/////////////////////////////////////////////////////////////////// 

// Constructors
////////////////
Alg::Alg( const std::string& name, ISvcLocator* svcLocator ) :
  AlgBase_t( name, svcLocator ),
  m_self   ( 0 )
{}

// Destructor
///////////////
Alg::~Alg()
{ 
  msg(MSG::DEBUG) << "Calling destructor" << endreq;
  Py_XDECREF( m_self );
}

// Framework's Hooks
////////////////////////////
StatusCode 
Alg::initialize()
{
  msg(MSG::INFO) 
    << "Initializing " << name() << "..." 
    << endreq;

  return PyAthena::callPyMethod( m_self, "sysInitialize" );
}

StatusCode 
Alg::reinitialize()
{
  msg(MSG::INFO) 
    << "Re-Initializing " << name() << "..." 
    << endreq;

  return PyAthena::callPyMethod( m_self, "sysReinitialize" );
}

StatusCode 
Alg::beginRun()
{ 
  return PyAthena::callPyMethod( m_self, "sysBeginRun" );
}

StatusCode 
Alg::endRun()
{
  return PyAthena::callPyMethod( m_self, "sysEndRun" );
}

StatusCode 
Alg::finalize()
{
  msg(MSG::INFO) 
    << "Finalizing " << name() << "..." 
    << endreq;

  return PyAthena::callPyMethod( m_self, "sysFinalize" );
}

StatusCode 
Alg::execute()
{  
//   msg(MSG::DEBUG) << "Executing " << name() << "..." 
// 	<< endreq;

  return PyAthena::callPyMethod( m_self, "sysExecute" );
}

StatusCode
Alg::sysInitialize()
{
  ServiceHandle<IPyComponentMgr> pyMgr
    ( "PyAthena::PyComponentMgr/PyComponentMgr", name() );
  if ( !pyMgr.retrieve().isSuccess() ) {
    msg(MSG::ERROR)
      << "Could not retrieve service [" << pyMgr.typeAndName() << "] !!"
      << endreq;
    return StatusCode::FAILURE;
  }

  // first retrieve our python object cousin...
  m_self = pyMgr->pyObject( this );

  if ( m_self == Py_None ) {
    msg(MSG::ERROR)
      << "Wrapped PyObject is NONE !"
      << endreq;
    return StatusCode::FAILURE;
  }

  // re-route to usual sysInit...
  return AlgBase_t::sysInitialize();
}

/////////////////////////////////////////////////////////////////// 
// Const methods: 
///////////////////////////////////////////////////////////////////

const char*
Alg::typeName() const
{ 
  static const std::string tname = System::typeinfoName(typeid(*this));
  return tname.c_str();
}

/////////////////////////////////////////////////////////////////// 
// Non-const methods: 
/////////////////////////////////////////////////////////////////// 

bool
Alg::setPyAttr( PyObject* o )
{
  // now we tell the PyObject which C++ object it is the cousin of.
  PyObject* pyobj = TPython::ObjectProxy_FromVoidPtr
    ( (void*)this, this->typeName() );
  if ( !pyobj ) {
    // try PyAthena::Alg
    pyobj = TPython::ObjectProxy_FromVoidPtr ((void*)this, "PyAthena::Alg");
    msg(MSG::INFO)
      << "could not dyncast component [" << name() << "] to a python "
      << "object of type [" << this->typeName() << "] (probably a missing "
      << "dictionary)" << endreq
      << "fallback to [PyAthena::Alg]..."
      << endreq;
  }
  if ( !pyobj ) {
    msg(MSG::WARNING)
      << "Could not dyncast component ["
      << name() << "] to a pyobject of type [" 
      << this->typeName() << "]"
      << endreq;
  } else {
    if ( -1 == PyObject_SetAttrString(o, "_cppHandle", pyobj) ) {
      msg(MSG::WARNING) 
	<< "Could not attach C++ handle [" << name() << "] to its python "
	<< "cousin !"
	<< endreq;
      PyObject_SetAttrString(o, "_cppHandle", Py_None);
    } else {
      return true;
    }
  }
  return false;
}

/////////////////////////////////////////////////////////////////// 
// Protected methods: 
/////////////////////////////////////////////////////////////////// 

/////////////////////////////////////////////////////////////////// 
// Const methods: 
///////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////// 
// Non-const methods: 
/////////////////////////////////////////////////////////////////// 

} //> end namespace PyAthena
