// -*- C++ -*-
#ifndef ATHENAPYTHON_ATHENAPYTHONDICT_H
#define ATHENAPYTHON_ATHENAPYTHONDICT_H

#include <string>
#include <typeinfo>
#include "GaudiKernel/IEvtSelector.h"
#include "AthenaKernel/IClassIDSvc.h"
#include "AthenaKernel/IThinningHdlr.h"
#include "AthenaKernel/ISlimmingHdlr.h"
#include "AthenaKernel/IThinningSvc.h"
#include "AthenaKernel/IValgrindSvc.h"
#include "AthenaKernel/IUserDataSvc.h"
#include "AthenaKernel/IEventSeek.h"
#include "AthenaKernel/IAthenaSealSvc.h"
#include "AthenaKernel/IDictLoaderSvc.h"
#include "AthenaKernel/IIoComponent.h"
#include "AthenaKernel/IIoComponentMgr.h"

#include "AthenaBaseComps/AthAlgorithm.h"
#include "AthenaBaseComps/AthAlgTool.h"
#include "AthenaBaseComps/AthService.h"

#include "AthenaPython/PyAthenaAlg.h"
#include "AthenaPython/PyAthenaSvc.h"
#include "AthenaPython/PyAthenaTool.h"
#include "AthenaPython/PyAthenaAud.h"

namespace AthenaInternal {
  
  CLID getClid( IClassIDSvc* self, const std::string& typeName ) {
    CLID clid = CLID_NULL;
    self->getIDOfTypeName(typeName, clid).ignore();
    return clid;
  }

  IEventSeek* to_ievent_seek (IEvtSelector *sel) 
  { return dynamic_cast<IEventSeek*> (sel); }

}

#endif // ATHENAPYTHON_ATHENAPYTHONDICT_H
