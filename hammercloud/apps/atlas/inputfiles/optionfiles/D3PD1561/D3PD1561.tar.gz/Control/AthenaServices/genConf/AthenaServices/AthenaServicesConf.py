#Mon Dec 21 20:54:19 2009
"""Automatically generated. DO NOT EDIT please"""
from GaudiKernel.GaudiHandles import *
from GaudiKernel.Proxy.Configurable import *

class ToyNextPassFilterTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'NPasses' : 2, # int
  }
  _propertyDocDct = { 
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(ToyNextPassFilterTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'AthenaServices'
  def getType( self ):
      return 'ToyNextPassFilterTool'
  pass # class ToyNextPassFilterTool

class ToyNextPassFilterAlg( ConfigurableAlgorithm ) :
  __slots__ = { 
    'OutputLevel' : 0, # int
    'Enable' : True, # bool
    'ErrorMax' : 1, # int
    'ErrorCount' : 0, # int
    'AuditAlgorithms' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditReinitialize' : False, # bool
    'AuditRestart' : False, # bool
    'AuditExecute' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditBeginRun' : False, # bool
    'AuditEndRun' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'MonitorService' : 'MonitorSvc', # str
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'NPasses' : 2, # int
  }
  _propertyDocDct = { 
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(ToyNextPassFilterAlg, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'AthenaServices'
  def getType( self ):
      return 'ToyNextPassFilterAlg'
  pass # class ToyNextPassFilterAlg

class AthenaOutputStream( ConfigurableAlgorithm ) :
  __slots__ = { 
    'OutputLevel' : 0, # int
    'Enable' : True, # bool
    'ErrorMax' : 1, # int
    'ErrorCount' : 0, # int
    'AuditAlgorithms' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditReinitialize' : False, # bool
    'AuditRestart' : False, # bool
    'AuditExecute' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditBeginRun' : False, # bool
    'AuditEndRun' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'MonitorService' : 'MonitorSvc', # str
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'AcceptAlgs' : [  ], # list
    'RequireAlgs' : [  ], # list
    'VetoAlgs' : [  ], # list
    'decSvc' : ServiceHandle('DecisionSvc/DecisionSvc'), # GaudiHandle
    'ItemList' : [  ], # list
    'OutputFile' : 'DidNotNameOutput.root', # str
    'EvtConversionSvc' : 'EventPersistencySvc', # str
    'WritingTool' : PrivateToolHandle('AthenaOutputStreamTool/DefaultNameTool'), # GaudiHandle
    'Store' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'ProcessingTag' : 'DefaultName', # str
    'ForceRead' : False, # bool
    'PersToPers' : False, # bool
    'ProvideDef' : False, # bool
    'ExtendProvenanceRecord' : True, # bool
    'WriteOnExecute' : True, # bool
    'WriteOnFinalize' : False, # bool
    'TakeItemsFromInput' : False, # bool
    'CheckNumberOfWrites' : False, # bool
    'ExcludeList' : [  ], # list
    'HelperTools' : PrivateToolHandleArray([]), # GaudiHandleArray
  }
  _propertyDocDct = { 
    'RequireAlgs' : """ Filters which must all be passed to enable output """,
    'AcceptAlgs' : """ Filters which if any are passed enable output """,
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
    'VetoAlgs' : """ Filters which if any are passed disable output """,
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(AthenaOutputStream, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'AthenaServices'
  def getType( self ):
      return 'AthenaOutputStream'
  pass # class AthenaOutputStream

class AthenaConditionStream( ConfigurableAlgorithm ) :
  __slots__ = { 
    'OutputLevel' : 0, # int
    'Enable' : True, # bool
    'ErrorMax' : 1, # int
    'ErrorCount' : 0, # int
    'AuditAlgorithms' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditReinitialize' : False, # bool
    'AuditRestart' : False, # bool
    'AuditExecute' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditBeginRun' : False, # bool
    'AuditEndRun' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'MonitorService' : 'MonitorSvc', # str
    'EvtStore' : ServiceHandle('StoreGateSvc/ConditionStore'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'AcceptAlgs' : [  ], # list
    'RequireAlgs' : [  ], # list
    'VetoAlgs' : [  ], # list
    'decSvc' : ServiceHandle('DecisionSvc/DecisionSvc'), # GaudiHandle
    'ItemList' : [  ], # list
    'OutputFile' : 'DidNotNameOutput.root', # str
    'EvtConversionSvc' : 'EventPersistencySvc', # str
    'WritingTool' : PrivateToolHandle('AthenaOutputStreamTool/DefaultNameTool'), # GaudiHandle
    'Store' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'ProcessingTag' : 'DefaultName', # str
    'ForceRead' : False, # bool
    'PersToPers' : False, # bool
    'ProvideDef' : False, # bool
    'ExtendProvenanceRecord' : True, # bool
    'WriteOnExecute' : True, # bool
    'WriteOnFinalize' : False, # bool
    'TakeItemsFromInput' : False, # bool
    'CheckNumberOfWrites' : False, # bool
    'ExcludeList' : [  ], # list
    'HelperTools' : PrivateToolHandleArray([]), # GaudiHandleArray
  }
  _propertyDocDct = { 
    'RequireAlgs' : """ Filters which must all be passed to enable output """,
    'AcceptAlgs' : """ Filters which if any are passed enable output """,
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
    'VetoAlgs' : """ Filters which if any are passed disable output """,
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(AthenaConditionStream, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'AthenaServices'
  def getType( self ):
      return 'AthenaConditionStream'
  pass # class AthenaConditionStream

class AtRndmGenSvc( ConfigurableService ) :
  __slots__ = { 
    'OutputLevel' : 7, # int
    'AuditServices' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditReInitialize' : False, # bool
    'AuditReStart' : False, # bool
    'Seeds' : [  ], # list
    'ReadFromFile' : False, # bool
    'FileToRead' : 'AtRndmGenSvc.out', # str
    'SaveToFile' : True, # bool
    'FileToWrite' : 'AtRndmGenSvc.out', # str
  }
  _propertyDocDct = { 
    'FileToRead' : """ name of a ASCII file, usually produced by AtRndmGenSvc itself at the end of a job, containing the information to fully set/restore the status of Ranecu """,
    'ReadFromFile' : """ set/restore the status of the engine from file """,
    'SaveToFile' : """ save the status of the engine to file """,
    'Seeds' : """ seeds for the engines, this is a vector of strings of the form ['SequenceName Seed1 Seed2', ...] """,
    'FileToWrite' : """ name of an ASCII file which will be produced on finalize, containing the information to fully set/restore the status of Ranecu """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(AtRndmGenSvc, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'AthenaServices'
  def getType( self ):
      return 'AtRndmGenSvc'
  pass # class AtRndmGenSvc

class AtRanluxGenSvc( ConfigurableService ) :
  __slots__ = { 
    'OutputLevel' : 7, # int
    'AuditServices' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditReInitialize' : False, # bool
    'AuditReStart' : False, # bool
    'Seeds' : [  ], # list
    'ReadFromFile' : False, # bool
    'FileToRead' : 'AtRanluxGenSvc.out', # str
    'SaveToFile' : True, # bool
    'FileToWrite' : 'AtRanluxGenSvc.out', # str
  }
  _propertyDocDct = { 
    'FileToRead' : """ name of a ASCII file, usually produced by AtRanLuxGenSvc itself at the end of a job, containing the information to fully set/restore the status of Ranlux64 """,
    'ReadFromFile' : """ set/restore the status of the engine from file """,
    'SaveToFile' : """ save the status of the engine to file """,
    'Seeds' : """ seeds for the engines, this is a vector of strings of the form ['SequenceName Seed1 Seed2', ...] """,
    'FileToWrite' : """ name of an ASCII file which will be produced on finalize, containing the information to fully set/restore the status of Ranlux64 """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(AtRanluxGenSvc, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'AthenaServices'
  def getType( self ):
      return 'AtRanluxGenSvc'
  pass # class AtRanluxGenSvc

class AthenaEventLoopMgr( ConfigurableService ) :
  __slots__ = { 
    'OutputLevel' : 7, # int
    'AuditServices' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditReInitialize' : False, # bool
    'AuditReStart' : False, # bool
    'TopAlg' : [  ], # list
    'OutStream' : [  ], # list
    'OutStreamType' : 'OutputStream', # str
    'EvtSel' : '', # str
    'HistogramPersistency' : '', # str
    'TimeKeeper' : '', # str
    'HistWriteInterval' : 0, # int
    'FailureMode' : 1, # int
    'EventPrintoutInterval' : 1, # int
    'ClearStorePolicy' : 'EndEvent', # str
    'PreSelectTools' : PrivateToolHandleArray([]), # GaudiHandleArray
  }
  _propertyDocDct = { 
    'HistWriteInterval' : """ histogram write/update interval """,
    'EventPrintoutInterval' : """ Print event heartbeat printouts every m_eventPrintoutInterval events """,
    'PreSelectTools' : """ AlgTools for event pre-selection """,
    'FailureMode' : """ Controls behaviour of event loop depending on return code of Algorithms. 0: all non-SUCCESSes terminate job. 1: RECOVERABLE skips to next event, FAILURE terminates job (DEFAULT). 2: RECOVERABLE and FAILURE skip to next events """,
    'ClearStorePolicy' : """ Configure the policy wrt handling of when the 'clear-the-event-store' event shall happen: at EndEvent (default as it is makes things easier for memory management) or at BeginEvent (easier e.g. for interactive use) """,
    'TimeKeeper' : """ Name of TimeKeeper to use. NONE or empty string (default) means no time limit control on event loop """,
    'EvtSel' : """ Name of Event Selector to use. If empty string (default) take value from ApplicationMgr """,
    'HistogramPersistency' : """ Histogram persistency technology to use: ROOT, HBOOK, NONE. By default (empty string) get property value from ApplicationMgr """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(AthenaEventLoopMgr, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'AthenaServices'
  def getType( self ):
      return 'AthenaEventLoopMgr'
  pass # class AthenaEventLoopMgr

class MultipleEventLoopMgr( ConfigurableService ) :
  __slots__ = { 
    'OutputLevel' : 7, # int
    'AuditServices' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditReInitialize' : False, # bool
    'AuditReStart' : False, # bool
    'TopAlg' : [  ], # list
    'OutStream' : [  ], # list
    'OutStreamType' : 'OutputStream', # str
    'EvtSel' : '', # str
    'HistogramPersistency' : '', # str
    'TimeKeeper' : '', # str
    'HistWriteInterval' : 0, # int
    'FailureMode' : 1, # int
    'EventPrintoutInterval' : 1, # int
    'ClearStorePolicy' : 'EndEvent', # str
    'PreSelectTools' : PrivateToolHandleArray([]), # GaudiHandleArray
    'NextPassFilter' : '', # str
    'ToBeReinitialized' : [  ], # list
  }
  _propertyDocDct = { 
    'HistWriteInterval' : """ histogram write/update interval """,
    'EventPrintoutInterval' : """ Print event heartbeat printouts every m_eventPrintoutInterval events """,
    'PreSelectTools' : """ AlgTools for event pre-selection """,
    'FailureMode' : """ Controls behaviour of event loop depending on return code of Algorithms. 0: all non-SUCCESSes terminate job. 1: RECOVERABLE skips to next event, FAILURE terminates job (DEFAULT). 2: RECOVERABLE and FAILURE skip to next events """,
    'ClearStorePolicy' : """ Configure the policy wrt handling of when the 'clear-the-event-store' event shall happen: at EndEvent (default as it is makes things easier for memory management) or at BeginEvent (easier e.g. for interactive use) """,
    'TimeKeeper' : """ Name of TimeKeeper to use. NONE or empty string (default) means no time limit control on event loop """,
    'EvtSel' : """ Name of Event Selector to use. If empty string (default) take value from ApplicationMgr """,
    'HistogramPersistency' : """ Histogram persistency technology to use: ROOT, HBOOK, NONE. By default (empty string) get property value from ApplicationMgr """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(MultipleEventLoopMgr, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'AthenaServices'
  def getType( self ):
      return 'MultipleEventLoopMgr'
  pass # class MultipleEventLoopMgr

class PyAthenaEventLoopMgr( ConfigurableService ) :
  __slots__ = { 
    'OutputLevel' : 7, # int
    'AuditServices' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditReInitialize' : False, # bool
    'AuditReStart' : False, # bool
    'TopAlg' : [  ], # list
    'OutStream' : [  ], # list
    'OutStreamType' : 'OutputStream', # str
    'EvtSel' : '', # str
    'HistogramPersistency' : '', # str
    'TimeKeeper' : '', # str
    'HistWriteInterval' : 0, # int
    'FailureMode' : 1, # int
    'EventPrintoutInterval' : 1, # int
    'ClearStorePolicy' : 'BeginEvent', # str
    'PreSelectTools' : PrivateToolHandleArray([]), # GaudiHandleArray
  }
  _propertyDocDct = { 
    'HistWriteInterval' : """ histogram write/update interval """,
    'EventPrintoutInterval' : """ Print event heartbeat printouts every m_eventPrintoutInterval events """,
    'PreSelectTools' : """ AlgTools for event pre-selection """,
    'FailureMode' : """ Controls behaviour of event loop depending on return code of Algorithms. 0: all non-SUCCESSes terminate job. 1: RECOVERABLE skips to next event, FAILURE terminates job (DEFAULT). 2: RECOVERABLE and FAILURE skip to next events """,
    'ClearStorePolicy' : """ Configure the policy wrt handling of when the 'clear-the-event-store' event shall happen: at EndEvent (default as it is makes things easier for memory management) or at BeginEvent (easier e.g. for interactive use) """,
    'TimeKeeper' : """ Name of TimeKeeper to use. NONE or empty string (default) means no time limit control on event loop """,
    'EvtSel' : """ Name of Event Selector to use. If empty string (default) take value from ApplicationMgr """,
    'HistogramPersistency' : """ Histogram persistency technology to use: ROOT, HBOOK, NONE. By default (empty string) get property value from ApplicationMgr """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(PyAthenaEventLoopMgr, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'AthenaServices'
  def getType( self ):
      return 'PyAthenaEventLoopMgr'
  pass # class PyAthenaEventLoopMgr

class SimplePOSIXTimeKeeperSvc( ConfigurableService ) :
  __slots__ = { 
    'OutputLevel' : 7, # int
    'AuditServices' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditReInitialize' : False, # bool
    'AuditReStart' : False, # bool
    'AllocTime' : 99999999, # int
  }
  _propertyDocDct = { 
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(SimplePOSIXTimeKeeperSvc, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'AthenaServices'
  def getType( self ):
      return 'SimplePOSIXTimeKeeperSvc'
  pass # class SimplePOSIXTimeKeeperSvc

class MixingEventSelector( ConfigurableService ) :
  __slots__ = { 
    'OutputLevel' : 7, # int
    'AuditServices' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditReInitialize' : False, # bool
    'AuditReStart' : False, # bool
    'TriggerList' : [  ], # list
    'OutputRunNumber' : 123456789, # int
    'EventNumbers' : [  ], # list
    'StreamStatusFileName' : '', # str
    'MergedEventInfoKey' : 'MergedEventInfo', # str
    'RndmGenSvc' : ServiceHandle('AtRndmGenSvc'), # GaudiHandle
    'RndmStreamName' : 'MixingEventSelectorStream', # str
  }
  _propertyDocDct = { 
    'RndmGenSvc' : """ IAtRndmGenSvc controlling the order with which events are takes from streams """,
    'TriggerList' : """ list of triggers (streams) to be used. Format is SelectorType/SelectorName:firstEventToUse:lastEventToUse. One assumes events are consecutively numbered. """,
    'MergedEventInfoKey' : """ StoreGate key for output (merged) event info object. Default is MergedEventInfo  """,
    'EventNumbers' : """ list of event numbers to be used for output stream. If list empty or not long enough, event numbers are assigned consucutively after last one in list """,
    'StreamStatusFileName' : """ Name of the file recording the last event used and how many were available for each stream. Default is to produce no file. """,
    'RndmStreamName' : """ IAtRndmGenSvc stream used as engine for our random distributions """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(MixingEventSelector, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'AthenaServices'
  def getType( self ):
      return 'MixingEventSelector'
  pass # class MixingEventSelector

class ThinningSvc( ConfigurableService ) :
  __slots__ = { 
    'OutputLevel' : 7, # int
    'AuditServices' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditReInitialize' : False, # bool
    'AuditReStart' : False, # bool
    'StoreGate' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'Streams' : [  ], # list
  }
  _propertyDocDct = { 
    'Streams' : """ The names of output stream(s) we want to apply thinning on. If empty, then thinning will be applied on all streams found during the job configuration. """,
    'StoreGate' : """ Handle to the StoreGateSvc instance holding containers which will be thinned in the course of the job """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(ThinningSvc, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'AthenaServices'
  def getType( self ):
      return 'ThinningSvc'
  pass # class ThinningSvc

class MemoryRescueSvc( ConfigurableService ) :
  __slots__ = { 
    'OutputLevel' : 7, # int
    'AuditServices' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditReInitialize' : False, # bool
    'AuditReStart' : False, # bool
    'NumberOfPages' : 12800, # int
  }
  _propertyDocDct = { 
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(MemoryRescueSvc, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'AthenaServices'
  def getType( self ):
      return 'MemoryRescueSvc'
  pass # class MemoryRescueSvc

class FPEControlSvc( ConfigurableService ) :
  __slots__ = { 
    'OutputLevel' : 7, # int
    'AuditServices' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditReInitialize' : False, # bool
    'AuditReStart' : False, # bool
    'Exceptions' : [ 'invalid' , 'divbyzero' , 'overflow' ], # list
    'ToolSvc' : ServiceHandle('ToolSvc'), # GaudiHandle
  }
  _propertyDocDct = { 
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(FPEControlSvc, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'AthenaServices'
  def getType( self ):
      return 'FPEControlSvc'
  pass # class FPEControlSvc

class JobIDSvc( ConfigurableService ) :
  __slots__ = { 
    'OutputLevel' : 7, # int
    'AuditServices' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditReInitialize' : False, # bool
    'AuditReStart' : False, # bool
  }
  _propertyDocDct = { 
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(JobIDSvc, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'AthenaServices'
  def getType( self ):
      return 'JobIDSvc'
  pass # class JobIDSvc

class UserDataSvc( ConfigurableService ) :
  __slots__ = { 
    'OutputLevel' : 7, # int
    'AuditServices' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditReInitialize' : False, # bool
    'AuditReStart' : False, # bool
    'InputFileCollection' : [  ], # list
    'OutputFileName' : 'none', # str
    'OutputStream' : 'none', # str
    'InputFileStreamName' : [  ], # list
    'WriteTransient' : True, # bool
  }
  _propertyDocDct = { 
    'OutputFileName' : """ Name of the output file to write userdata to """,
    'WriteTransient' : """ Allow writing to transient UserData store. """,
    'InputFileCollection' : """ List of name of the input files to read userdata from """,
    'InputFileStreamName' : """ List of stream names corresponding to input files. set automatically. """,
    'OutputStream' : """ Name of the output file to write userdata to """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(UserDataSvc, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'AthenaServices'
  def getType( self ):
      return 'UserDataSvc'
  pass # class UserDataSvc

class CoreDumpSvc( ConfigurableService ) :
  __slots__ = { 
    'OutputLevel' : 7, # int
    'AuditServices' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditReInitialize' : False, # bool
    'AuditReStart' : False, # bool
    'Signals' : [ 11 , 7 , 4 , 8 ], # list
    'CallOldHandler' : True, # bool
    'CoreDumpStream' : 'stdout', # str
  }
  _propertyDocDct = { 
    'Signals' : """ List of signals to catch """,
    'CoreDumpStream' : """ Stream to use for core dump [stdout,stderr,MsgStream] """,
    'CallOldHandler' : """ Call previous signal handler """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(CoreDumpSvc, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'AthenaServices'
  def getType( self ):
      return 'CoreDumpSvc'
  pass # class CoreDumpSvc

class PageAccessControlSvc( ConfigurableService ) :
  __slots__ = { 
    'OutputLevel' : 7, # int
    'AuditServices' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditReInitialize' : False, # bool
    'AuditReStart' : False, # bool
    'AutoMonitoring' : True, # bool
  }
  _propertyDocDct = { 
    'AutoMonitoring' : """ start monitoring on initialize, stop on finalize """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(PageAccessControlSvc, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'AthenaServices'
  def getType( self ):
      return 'PageAccessControlSvc'
  pass # class PageAccessControlSvc

class AthDictLoaderSvc( ConfigurableService ) :
  __slots__ = { 
    'OutputLevel' : 7, # int
    'AuditServices' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditReInitialize' : False, # bool
    'AuditReStart' : False, # bool
    'DoRecursiveLoad' : True, # bool
  }
  _propertyDocDct = { 
    'DoRecursiveLoad' : """ Switch to recursively load (or not) all dictionaries for all types composing a given one. 
  ie: load dict of Bar in 'struct Foo {Bar*b;};' 
Default is 'true'. """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(AthDictLoaderSvc, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'AthenaServices'
  def getType( self ):
      return 'AthDictLoaderSvc'
  pass # class AthDictLoaderSvc

class AthenaSealSvc( ConfigurableService ) :
  __slots__ = { 
    'OutputLevel' : 7, # int
    'AuditServices' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditReInitialize' : False, # bool
    'AuditReStart' : False, # bool
    'DictNames' : [ 'STLRflx' ], # list
    'IgnoreNames' : [ 'Gaudi' , 'GaudiPython::Interface' , 'GaudiPython::Helper' , 'FactoryTable' , 'IInterface' , 'IFactory' , 'IAlgFactory' , 'ISvcFactory' , 'IToolFactory' , 'InterfaceID' , 'StatusCode' , 'IAppMgrUI' , 'IProperty' , 'Property' , 'std::vector<Property*>' , 'std::vector<const Property*>' , 'std::list<IAlgorithm*>' , 'std::list<IService*>' , 'std::list<const IFactory*>' , 'std::vector<IRegistry*>' , 'SimpleProperty' , 'SimplePropertyRef' , 'IService' , 'IAlgorithm' , 'ISvcManager' , 'IAlgManager' , 'IJobOptionsSvc' , 'ISvcLocator' , 'IEventProcessor' , 'IDataProviderSvc' , 'IDataManagerSvc' , 'IRegistry' , 'ContainedObject' , 'std::vector<const ContainedObject*>' , 'DataObject' , 'IHistogramSvc' , 'AIDA::I' , 'Algorithm' , 'Service' , 'GaudiPython::PyAlgorithm' , 'GaudiPython::PyAlgorithmWrap' , 'IParticlePropertySvc' , 'ParticleProperty' , 'StoreGateSvc' , 'IStoragePolicy' , 'CharDbArray' , 'DoubleDbArray' , 'FloatDbArray' , 'IntDbArray' , 'LongDbArray' , 'ShortDbArray' , 'AthenaEventLoopMgr' , 'MinimalEventLoopMgr' , 'PyAthenaEventLoopMgr' , 'NTuple::Directory' , 'NTuple::File ' , 'NTuple::Tuple' , 'INTuple' , 'NTuple::Tuple' , 'greater<int>' , 'allocator<' ], # list
    'CheckDictionary' : True, # bool
    'CheckDictAtInit' : False, # bool
    'LoadAllDicts' : False, # bool
    'IgnoreDicts' : [ 'libSealCLHEPDict' ], # list
    'UseChronoStag' : True, # bool
  }
  _propertyDocDct = { 
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(AthenaSealSvc, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'AthenaServices'
  def getType( self ):
      return 'AthenaSealSvc'
  pass # class AthenaSealSvc

class DecisionSvc( ConfigurableService ) :
  __slots__ = { 
    'OutputLevel' : 7, # int
    'AuditServices' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditReInitialize' : False, # bool
    'AuditReStart' : False, # bool
    'AcceptAlgNames' : [  ], # list
    'RequireAlgNames' : [  ], # list
    'VetoAlgNames' : [  ], # list
  }
  _propertyDocDct = { 
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(DecisionSvc, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'AthenaServices'
  def getType( self ):
      return 'DecisionSvc'
  pass # class DecisionSvc

class AthenaOutputStreamTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'OutputFile' : '', # str
    'CnvSvc' : ServiceHandle('AthenaPoolCnvSvc'), # GaudiHandle
    'Store' : ServiceHandle('DetectorStore'), # GaudiHandle
  }
  _propertyDocDct = { 
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(AthenaOutputStreamTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'AthenaServices'
  def getType( self ):
      return 'AthenaOutputStreamTool'
  pass # class AthenaOutputStreamTool

class ThinningOutputTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'ThinningSvc' : ServiceHandle('ThinningSvc'), # GaudiHandle
    'Proxies' : [  ], # list
  }
  _propertyDocDct = { 
    'ThinningSvc' : """ Handle to the service which has thinned data """,
    'Proxies' : """ list of pairs (clid,key) the tool will forcingly read from input to ensure a sound thinning state """,
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(ThinningOutputTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'AthenaServices'
  def getType( self ):
      return 'ThinningOutputTool'
  pass # class ThinningOutputTool
