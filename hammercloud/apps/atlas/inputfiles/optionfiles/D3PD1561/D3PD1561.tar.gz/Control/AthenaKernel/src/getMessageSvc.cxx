#include <iostream>
using std::cerr;
using std::endl;
#include "GaudiKernel/Bootstrap.h"
#include "GaudiKernel/IMessageSvc.h"
#include "GaudiKernel/ISvcLocator.h"
#include "AthenaKernel/getMessageSvc.h"

using namespace Athena;

IMessageSvc* Athena::getMessageSvc( ) { return getMessageSvc( Options::Lazy ); }
IMessageSvc* Athena::getMessageSvc( const Options::CreateOptions opt ) {
  IMessageSvc* pSvc(0);
  const bool createIf( opt == Athena::Options::Eager );
  if (!(Gaudi::svcLocator()->service("MessageSvc", pSvc, createIf)).isSuccess())
    cerr << "Athena::getMessageSvc: WARNING MessageSvc not found, will use std::cerr" << endl;
  return pSvc;
}

IMessageSvcHolder::IMessageSvcHolder(IMessageSvc *ims) : m_ims(ims) {
  assert(m_ims);
  m_ims->addRef(); //take ownership till we go out of scope
}

IMessageSvcHolder::IMessageSvcHolder(const IMessageSvcHolder& rhs) :
  m_ims(rhs.m_ims) 
{
  if (m_ims) m_ims->addRef(); //take ownership till we go out of scope
}

IMessageSvcHolder& 
IMessageSvcHolder::operator=(const IMessageSvcHolder& rhs) {
  if (this != & rhs && m_ims != rhs.m_ims) {
    if (m_ims) m_ims->release(); //give up our IMessageSvc*
    m_ims = rhs.m_ims;
    if (m_ims) m_ims->addRef(); //take ownership till we go out of scope
  }
  return *this;
}

IMessageSvcHolder::IMessageSvcHolder( const Options::CreateOptions opt ) :
  m_ims(0)
{
  if (opt == Athena::Options::Eager) m_ims = getMessageSvc(opt);
}

IMessageSvcHolder::~IMessageSvcHolder() {
  if (m_ims) m_ims->release();
}

IMessageSvc*
IMessageSvcHolder::get() const {
  if (!m_ims) m_ims = getMessageSvc();
  return m_ims;
}

