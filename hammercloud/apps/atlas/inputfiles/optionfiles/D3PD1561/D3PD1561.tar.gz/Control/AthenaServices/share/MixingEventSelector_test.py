## @file MixingEventSelector_test.py
# @brief Job options file to test the Event Mixing selector
#
# $Id: MixingEventSelector_test.py,v 1.20 2007-12-15 19:05:45 calaf Exp $
#==============================================================
include( "AthenaCommon/Atlas.UnixStandardJob.py" )

include( "AthenaPoolCnvSvc/AthenaPool_jobOptions.py" )

# Pool Converters
#
include( "EventAthenaPool/EventAthenaPool_joboptions.py" )

include( "GeneratorObjectsAthenaPool/GeneratorObjectsAthenaPool_joboptions.py" )

include( "InDetEventAthenaPool/InDetEventAthenaPool_joboptions.py" )

#--------------------------------------------------------------
#---   EventMixer configuration
#--------------------------------------------------------------
# Number of events to be processed (default is 10)
theApp.EvtMax = -1

#run without file catalog
ServiceMgr.PoolSvc.AttemptCatalogPatch = True

ServiceMgr.ProxyProviderSvc.ProviderNames += [ "MixingEventSelector/EventMixer" ]
#why not !!! AthenaEventLoopMgr.EvtSel = "EventMixer";
theApp.EvtSel = "EventMixer";  #FIXME should decode ListItem
#
ServiceMgr += Service("MixingEventSelector/EventMixer")
# Event mixing trigger list
# format is [frequency in %]
ServiceMgr.EventMixer.TriggerList += [ "EventSelectorAthenaPool/G4MinBiasSelector:0:1000" ]
ServiceMgr.EventMixer.TriggerList += [ "EventSelectorAthenaPool/G4MuPlusSelector:0:1000" ]
ServiceMgr.EventMixer.StreamStatusFileName = "streamStatus.txt"
# Pool input G4Sim  use 
ServiceMgr += Service( "EventSelectorAthenaPool/G4MuPlusSelector" )
ServiceMgr.G4MuPlusSelector.InputCollections = [ "/afs/cern.ch/atlas/offline/data/testfile/calib1_csc11.007234.singlepart_mu200.simul.HITS.v12000301_tid003123._00005.pool.root" ]
ServiceMgr += Service( "EventSelectorAthenaPool/G4MinBiasSelector" )
ServiceMgr.G4MinBiasSelector.InputCollections = [ "rfio:/castor/cern.ch/user/s/svahsen/digitization/RTT/pileup/misal1_csc11.005001.pythia_minbias.simul.HITS.v12003104_tid004278._00001.pool.root.2" ]
ServiceMgr.EventMixer.OutputRunNumber=54321
ServiceMgr.EventMixer.EventNumbers=[1, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 47]

#--------------------------------------------------------------
#---   Output stream configuration
#--------------------------------------------------------------
include( "AthenaPoolCnvSvc/WriteAthenaPool_jobOptions.py" )
from AthenaPoolCnvSvc.WriteAthenaPool import AthenaPoolOutputStream
Stream1 = AthenaPoolOutputStream( "Stream1" )
Stream1.OutputFile = "MixedFile.root"; # ** mandatory parameter ** // The output file name
Stream1.ForceRead=TRUE;  #force read of output data objs
Stream1.ItemList=["MergedEventInfo#*",
                  "EventInfo#*",
                  "McEventCollection#*",
		  "SiHitCollection#SCT_Hits",
		  "SiHitCollection/PixelHits"]; #SYNTAX ERROR: / not #

#--------------------------------------------------------------
#--- Monitoring and Debug printouts
#--------------------------------------------------------------

MessageSvc.OutputLevel      = INFO
ServiceMgr.EventMixer.OutputLevel      = VERBOSE
MessageSvc.setVerbose += [ "MixingEventSelector::TriggerList" ]
Stream1.OutputLevel = DEBUG
#StoreGateSvc.Dump=1
#StoreGateSvc.OutputLevel=DEBUG

from AthenaCommon.AppMgr import theAuditorSvc
from GaudiAud.GaudiAudConf import ChronoAuditor
theAuditorSvc += ChronoAuditor()
