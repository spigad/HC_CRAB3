#include "AthenaKernel/CloneService.h"

#include <cassert>
#include <vector>

#include "GaudiKernel/ISvcLocator.h"
#include "GaudiKernel/ISvcManager.h"
#include "GaudiKernel/MsgStream.h"
#include "GaudiKernel/Service.h"
#include "GaudiKernel/SmartIF.h"
#include "GaudiKernel/System.h"

namespace CloneService {
  /** given a pointer to a parent svc sets a reference to a cloned child */
  StatusCode clone(const IService* iParent, const std::string& childName,
		   Service*& child) 
  {
    //FIXME this only creates an uninitialized SERVICE. 
    //FIXME it would be better if one could say parent->clone()
    //FIXME (its default implementation could be this one)

    //check the parent pointer is valid
    const Service* parent(0);
    parent = dynamic_cast<const Service*>(iParent);
    assert(parent);

    MsgStream log( parent->msgSvc(), "CloneService::clone" );

    // can we access the Service locator interface?
    ISvcLocator* svcLoc(parent->serviceLocator());
    assert (0 != svcLoc);

    //create the child unless it is already there
    //if the service is not there and can't be created barf
    IService* pIS(0);
    const bool DONOTCREATE(false);
    if ((svcLoc->getService(childName, pIS, DONOTCREATE)).isSuccess() &&
	0 != (child = dynamic_cast<Service*>(pIS))) {
      log << MSG::DEBUG 
	  << "Found service " << childName
	  << endreq;
    } else {
      // can we access the Service Manager interface?
      SmartIF<ISvcManager> svcMgr(IID_ISvcManager, svcLoc);
      if ( !svcMgr.isValid() ) {
	log << MSG::FATAL 
	    << "ISvcManager interface not found by serviceLocator." 
	    << endreq;
	return StatusCode::FAILURE;
      }
      const std::string& parentType = System::typeinfoName(typeid(*parent));
      if (svcMgr->createService(parentType, childName,
				pIS).isSuccess() &&
	  0 != (child = dynamic_cast<Service*>(pIS))) {
	log << MSG::DEBUG 
	    << "Created service " << childName << " of type " << parentType
	    << endreq;
      } else {
	log << MSG::ERROR
	    << "Failed to create " << childName << " of type " << parentType 
	    << endreq;
	return StatusCode::FAILURE;
      }

    }
    //now copy parent's properties into child
    std::vector<Property*>::const_iterator iProp(parent->getProperties().begin());
    std::vector<Property*>::const_iterator eProp(parent->getProperties().end());
    while (iProp != eProp &&
	   (child->setProperty(**iProp)).isSuccess()) ++iProp;
    if (iProp != eProp) {
      log << MSG::ERROR 
	  << "Failed to set child property " << (**iProp).name() 
	  << endreq;
      return StatusCode::FAILURE;
    } else {
      log << MSG::DEBUG 
	  << childName << " properties set"
	  << endreq;
    }

    //finally put the service in the same state as the parent
    //FIXME vile hack to handle v19/v20 differences
#ifdef GAUDIKERNEL_STATEMACHINE_H_
    //FIXME should we handle the case in which the parent is RUNNING?
    if (Gaudi::StateMachine::INITIALIZED == parent->FSMState() &&
	Gaudi::StateMachine::CONFIGURED == child->FSMState())
#else
    if (IService::INITIALIZED == parent->state() &&
	IService::INITIALIZED > child->state())
#endif
      return child->sysInitialize(); 
    else {
      log << MSG::DEBUG 
	  << "Did not initialize " <<  childName
	  << endreq;
      return StatusCode::SUCCESS;
    }
  }
}
