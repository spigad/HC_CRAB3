#ifndef ATRANLUXGENSVC_H
#define ATRANLUXGENSVC_H
/** @file AtRanluxGenSvc.h
 *  @brief The default ATLAS random number engine manager, based on Ranlux64
 *  @author Paolo Calafiura
 *  @author George Stavropoulous
 *  
 *  $Id: AtRanluxGenSvc.h,v 1.5 2008-09-23 22:00:47 binet Exp $
 */

#include <map>

//base classes
#include "AthenaKernel/IAtRndmGenSvc.h"
#include "GaudiKernel/IIncidentListener.h"
#include "AthenaBaseComps/AthService.h"

#include "CLHEP/Random/Ranlux64Engine.h"

/** @class AtRanluxGenSvc
 *  @brief The default ATLAS random number engine manager, based on Ranlux64
 *
 *  @details this service mantains a number of named, independent random
 *  number sequences. Each sequence is initialized by an entry of the form
 *  "SequenceName Seed1 Seed2" in the Seeds property. For example
 *  @code
 *   Seeds = [ "PYTHIA 4789899 989240512", "PYTHIA_INIT 820021 2347532",
 *             "JIMMY 390020611 821000366", "JIMMY_INIT 820021 2347532",
 *             "HERWIG 390020611 821000366", "HERWIG_INIT 820021 2347532" ]
 *
 *  @endcode
 *  At the end of the job  in AtRanluxGenSvc::finalize(), the status of the
 *  engine is dumped as an array of unsigned long to the ASCII file
 *  "AtRanluxGenSvc.out":
 *  @code
 *   PITHIA 4010409557 1071463497 2862960128 1068652744 145815808 1072305199 2363435712 1072215177 2274024032 1071848040 1607052768 1070928280 1688486400 1071840599 2068481888 1067315347 62450688 1072023539 312153120 1070857822 2535009472 1070427845 3698875904 1070616419 3726185024 0 0 11 1 202 
 *   PITHIA_INIT 4010409557 1057836705 3838836736 1072443439 2098440704 1066892778 3689119744 1072151794 3818888768 1071853913 3574320864 1071982408 3603063712 1071718264 2168786016 1072391676 2208235040 1072000044 3037871232 1072480358 3292613248 1071901297 579757952 1065720911 3788918784 0 0 11 1 202 
 * @endcode
 *  This file can be used to restore the status of the
 *  engine in another job by setting the properties
 *  @code
 *   ReadFromFile = true
 *   FileToRead = path_to_ascii_file
 *  @endcode
 * 
 */
class AtRanluxGenSvc : virtual public IAtRndmGenSvc,
                       virtual public IIncidentListener,
		       public AthService
{
public:
    /// @name Interface to the CLHEP engine
    //@{
    HepRandomEngine*	GetEngine	( const std::string& StreamName );
    void		CreateStream	( long seed1, long seed2, const std::string& StreamName );
    bool		CreateStream	( std::vector<unsigned long> seeds, const std::string& StreamName );
    //@}

    /// @name CLHEP engines typedefs:
    //@{
    typedef std::map<std::string, Ranlux64Engine*> engineMap;
    typedef engineMap::iterator 		   engineIter;
    typedef engineMap::const_iterator              engineConstIter;  
    typedef engineMap::value_type		   engineValType;
    //@}

    /// @name Stream access
    //@{
    engineConstIter	begin			(void)	const;
    engineConstIter	end			(void)	const;
    unsigned int	number_of_streams	(void)	const;    
    void		print		( const std::string& StreamName );
    void		print		( void );
    //@}

    ///set the seeds for an engine. First param will usually be the event number
    HepRandomEngine* setOnDefinedSeeds (int eventNumber, 
					const std::string& StreamName);
    ///set the seeds for an engine. Second param will usually be the run number
    HepRandomEngine* setOnDefinedSeeds (int eventNumber, 
					int runNumber,
					const std::string& StreamName);
  
    /// @name Gaudi Service Implementation
    //@{
    StatusCode initialize();
    StatusCode finalize();
    virtual StatusCode queryInterface( const InterfaceID& riid, 
				       void** ppvInterface );
    //@}

    /// IIncidentListener implementation. Handles EndEvent incident
    void handle(const Incident&);


private:
    typedef	std::vector< std::string >	VStrings;
    /// @name Properties
    //@{
    /// seeds for the engines, this is a vector of strings of the form "EnginName Seed1 Seed2"
    VStrings m_streams_seeds;   
    bool     m_read_from_file;  ///< read engine status from file
    std::string	m_file_to_read; ///< name of the file to read the engine status from
    bool m_save_to_file; ///< should current engine status be saved to file ?
    std::string m_file_to_write; ///< name of the file to save the engine status to.

    //@}

    engineMap	m_engines;
    /// Random engine copy (for output to a file)
    std::map<std::string, std::vector<unsigned long> >	m_engines_copy;


    /// @name Default seed values
    //@{
    long m_default_seed1;
    long m_default_seed2;
    long m_PYTHIA_default_seed1;
    long m_PYTHIA_default_seed2;
    long m_HERWIG_default_seed1;
    long m_HERWIG_default_seed2;
    //@}

    void SetStreamSeeds( const std::string& StreamName );
    
public:
    
    /// Standard Gaudi Constructor
    AtRanluxGenSvc(const std::string& name, ISvcLocator* svc);
        
    virtual ~AtRanluxGenSvc();

};
 
inline	AtRanluxGenSvc::engineConstIter
AtRanluxGenSvc::begin			(void)	const
{ return m_engines.begin(); }

inline	AtRanluxGenSvc::engineConstIter
AtRanluxGenSvc::end			(void)	const
{ return m_engines.end(); }

inline	unsigned int
AtRanluxGenSvc::number_of_streams		(void)	const
{ return m_engines.size(); }

#endif // ATRANLUXGENSVC_H


