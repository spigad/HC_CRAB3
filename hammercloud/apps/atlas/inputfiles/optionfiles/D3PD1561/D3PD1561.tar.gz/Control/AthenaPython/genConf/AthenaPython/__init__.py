## Hook for AthenaPython genConf module
