#include <AthenaKernel/IJobIDSvc.h>

IJobIDSvc::~IJobIDSvc() 
{}
