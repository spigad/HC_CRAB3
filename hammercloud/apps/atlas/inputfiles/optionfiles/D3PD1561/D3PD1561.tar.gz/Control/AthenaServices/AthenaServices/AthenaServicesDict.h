/* assumes -I$(GAUDISVCROOT)/src */
#include "GaudiKernel/IConversionSvc.h"
#include "GaudiKernel/IIncidentSvc.h"
#include "StoreGate/StoreGateSvc.h"

#include "PyAthenaEventLoopMgr.h"

#include "SetFatalHandler.h"

#include "GaudiKernel/DataSvc.h"
