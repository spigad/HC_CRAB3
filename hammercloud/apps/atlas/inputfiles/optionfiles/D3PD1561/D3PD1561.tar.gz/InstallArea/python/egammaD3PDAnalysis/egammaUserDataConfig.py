# $Id$
#
# @file egammaD3PDMakerAnalysis/python/egammaUserDataConfig.py
# @author scott snyder <snyder@bnl.gov>
# @date Nov, 2009
# @brief Configure algorithms to fill UserData used by egammaD3PDMaker.
#


from D3PDMakerConfig.D3PDMakerFlags           import D3PDMakerFlags
from RecExConfig.RecFlags                     import rec
import egammaD3PDAnalysis
import D3PDMakerCoreComps

from AthenaCommon.AlgSequence import AlgSequence
topSequence = AlgSequence()


def egammaUserDataConfig (seq = topSequence,
                          prefix = ''):

    DVGetter = D3PDMakerCoreComps.SGDataVectorGetterTool
    
    if (not D3PDMakerFlags.MakeEgammaUserData() or
        D3PDMakerFlags.HaveEgammaUserData()):
        return

    if rec.doTruth():
        ptaname = prefix + 'PhotonTruthAlg'
        if not hasattr (seq, ptaname):
            seq += egammaD3PDAnalysis.PhotonTruthAlg \
                   (ptaname,
                    PhotonGetter = DVGetter
                      (prefix + 'PhotonTruthAlgGetter',
                       TypeName = 'PhotonContainer',
                       SGKey = D3PDMakerFlags.PhotonSGKey()),
                    UDPrefix = D3PDMakerFlags.EgammaUserDataPrefix())

        
    ptianame = prefix + 'PhotonTopoIsoAlg'
    if not hasattr (seq, ptianame):
        seq += egammaD3PDAnalysis.PhotonTopoIsoAlg \
               (ptianame,
                PhotonGetter = DVGetter
                  (prefix +'PhotonTopoIsoAlgPhotonGetter',
                   TypeName = 'PhotonContainer',
                   SGKey = D3PDMakerFlags.PhotonSGKey()),
                ClusterGetter = DVGetter
                  (prefix + 'PhotonTopoIsoAlgClusterGetter',
                   TypeName = 'CaloClusterContainer',
                   SGKey = D3PDMakerFlags.ClusterSGKey()))

    emax2elename = prefix + 'DeltaEmax2EleAlg'
    if not hasattr (seq, emax2elename):
        highlum = False
        from AthenaCommon.BeamFlags import jobproperties        
        if jobproperties.Beam.numberOfCollisions() >= 20 :
            highlum = True

        seq += egammaD3PDAnalysis.egammaDeltaEmax2Alg \
               (emax2elename,
                Getter = DVGetter 
                  (prefix + 'DeltaEmax2EleGetter',
                   TypeName = 'ElectronContainer',
                   SGKey = D3PDMakerFlags.ElectronSGKey()),
                HighLum = highlum)

    emax2gamname = prefix + 'DeltaEmax2GamAlg'
    if not hasattr (seq, emax2gamname):
        seq += egammaD3PDAnalysis.egammaDeltaEmax2Alg \
               (emax2gamname,
                Getter = DVGetter 
                  (prefix + 'DeltaEmax2GamGetter',
                   TypeName = 'PhotonContainer',
                   SGKey = D3PDMakerFlags.PhotonSGKey()))

