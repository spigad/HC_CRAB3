# $Id$
#
# @file D3PDMakerCoreComps/python/IndexAssociation.py
# @author Nicolas Berger <nberger@mail.cern.ch>, scott snyder <snyder@bnl.gov>
# @date Nov, 2009
# @brief Helper for setting up an association via an index.
#


def IndexAssociation (parent,
                      assoctool,
                      target,
                      prefix = '',
                      level = 0,
                      blockname = None,
                      *args, **kw):

    """Helper for setting up an association via an index.

    parent: The parent D3PDobject or block.
    assoctool: The class for the (single) association tool.
    target: The label for the getter within which we look up the index.
    prefix: Prefix to add to the contained variables, if any.
    level: Level of detail for the block.
    blockname: Name for the block.

    Extra arguments are passed to the association tool.
"""

    if blockname == None:
        blockname = assoctool.__class__.__name__

    def maker (name, prefix):
        assoc = assoctool (name + 'Assoc', *args, **kw)
        return D3PDMakerCoreComps.IndexAssociationFillerTool \
               (name, Target = target, Prefix = prefix, Associator = assoc)

    obj = D3PDObject (maker, prefix)
    parent.defineBlock (level, blockname, obj)
    return obj
