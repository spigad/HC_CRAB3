# $Id$
#
# @file  egammaD3PDMaker/python/egammaTriggerBitsD3PDObject.py
# @author  Haifeng Li <Haifeng.Li@cern.ch>, sss
# @date    Sep, 2009
# @brief   Define trigger bit blocks for egamma.
#


import D3PDMakerCoreComps
import TriggerD3PDMaker
from D3PDMakerCoreComps.D3PDObject import D3PDObject


#
# The maker function.
# We don't get any input from SG (directly).
# 
def makeEgammaTriggerBitsD3PDObject (name,
                                     prefix,
                                     getter = None,
                                     sgkey = ''):
  
    return D3PDMakerCoreComps.VoidObjFillerTool (name,
                                                 Prefix = prefix
                                                 )

# Create the object type.
egammaTriggerBitsD3PDObject = \
  D3PDObject (makeEgammaTriggerBitsD3PDObject,
              default_name = 'egammaTriggerBitsFiller')


######
# Define blocks.


egammaTriggerBitsD3PDObject.defineBlock \
  (0, 'egammaBits0',
   TriggerD3PDMaker.TriggerBitFillerTool ,
   Triggers=[
    'EF_2e5_medium',
    'EF_e10_medium',
    'EF_e20_loose',
    'EF_em105_passHLT',
    'EF_g20_loose',
    ]
   )


egammaTriggerBitsD3PDObject.defineBlock \
  (1, 'egammaBits1',
   TriggerD3PDMaker.TriggerBitFillerTool ,
   Triggers=[
    'L1_EM3',
    'L1_EM7',
    'L1_EM13',
    'L1_EM13I',
    'L1_EM18',
    'L1_EM18I',
    'L1_EM23I',
    'L1_EM100',
    'L2_2e5_medium',
    'L2_e10_medium',
    #'L2_e20_medium',  # Not present in menu.
    'L2_e20_loose',
    'L2_em105_passHLT',
    'L2_g20_loose',
    ]
   )
