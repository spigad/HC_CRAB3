/*author Renato Febbraro*/
/*date 3/7/2007*/
/*renato.febbraro@cern.ch*/


#ifndef TILELASER_H
#define TILELASER_H

namespace TileLaser{

class TileLaser {

 public:

  int getDiodeCurrOrd() const;
  int getDiodeCurrMeas() const;
  int getFiltNumber() const; 
  int getCounter() const;
  int getSlamaDelay() const; 

  void setLaser(const int Counter, 
		const int diodeCurrOrd, 
                const int diodeCurrMeas, 
                const int filtNumber,
		const int SlamaDelay); 
 
 private:

  int m_counter;
  int m_diodeCurrOrd;
  int m_diodeCurrMeas;
  int m_filtNumber;
  int m_slamaDelay;

};

 inline void TileLaser::setLaser(const int Counter,
				 const int diodeCurrOrd,
				 const int diodeCurrMeas, 
				 const int filtNumber,
				 const int SlamaDelay)
{
  m_counter=Counter;
  m_diodeCurrOrd=diodeCurrOrd;
  m_diodeCurrMeas=diodeCurrMeas;
  m_filtNumber=filtNumber;
  m_slamaDelay=SlamaDelay;
}

inline int TileLaser::getDiodeCurrOrd() const {return m_diodeCurrOrd;}
inline int TileLaser::getDiodeCurrMeas() const {return m_diodeCurrMeas;}
inline int TileLaser::getFiltNumber() const { return m_filtNumber;}
inline int TileLaser::getCounter() const { return m_counter;}
inline int TileLaser::getSlamaDelay() const {return m_slamaDelay;} 
}

#endif
