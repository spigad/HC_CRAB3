#Mon Dec 21 20:57:51 2009
"""Automatically generated. DO NOT EDIT please"""
from GaudiKernel.GaudiHandles import *
from GaudiKernel.Proxy.Configurable import *

class D3PD__egammaDetailFillerTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'Prefix' : '', # str
    'Details' : [  ], # list
  }
  _propertyDocDct = { 
    'Prefix' : """ Tuple variable prefix for this block. """,
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(D3PD__egammaDetailFillerTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'egammaD3PDMaker'
  def getType( self ):
      return 'D3PD::egammaDetailFillerTool'
  pass # class D3PD__egammaDetailFillerTool

class D3PD__egammaAuthorFillerTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'Prefix' : '', # str
    'RecoveredFlag' : False, # bool
  }
  _propertyDocDct = { 
    'Prefix' : """ Tuple variable prefix for this block. """,
    'RecoveredFlag' : """ If true, write isRecovered. """,
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(D3PD__egammaAuthorFillerTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'egammaD3PDMaker'
  def getType( self ):
      return 'D3PD::egammaAuthorFillerTool'
  pass # class D3PD__egammaAuthorFillerTool

class D3PD__egammaIsEMoneFillerTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'Prefix' : '', # str
  }
  _propertyDocDct = { 
    'Prefix' : """ Tuple variable prefix for this block. """,
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(D3PD__egammaIsEMoneFillerTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'egammaD3PDMaker'
  def getType( self ):
      return 'D3PD::egammaIsEMoneFillerTool'
  pass # class D3PD__egammaIsEMoneFillerTool

class D3PD__egammaIsEMFillerTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'Prefix' : '', # str
    'IsEM' : [  ], # list
  }
  _propertyDocDct = { 
    'Prefix' : """ Tuple variable prefix for this block. """,
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(D3PD__egammaIsEMFillerTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'egammaD3PDMaker'
  def getType( self ):
      return 'D3PD::egammaIsEMFillerTool'
  pass # class D3PD__egammaIsEMFillerTool

class D3PD__egammaPIDFillerTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'Prefix' : '', # str
    'PID' : [  ], # list
  }
  _propertyDocDct = { 
    'Prefix' : """ Tuple variable prefix for this block. """,
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(D3PD__egammaPIDFillerTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'egammaD3PDMaker'
  def getType( self ):
      return 'D3PD::egammaPIDFillerTool'
  pass # class D3PD__egammaPIDFillerTool

class D3PD__egammaLayer1ExtraFillerTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'Prefix' : '', # str
  }
  _propertyDocDct = { 
    'Prefix' : """ Tuple variable prefix for this block. """,
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(D3PD__egammaLayer1ExtraFillerTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'egammaD3PDMaker'
  def getType( self ):
      return 'D3PD::egammaLayer1ExtraFillerTool'
  pass # class D3PD__egammaLayer1ExtraFillerTool

class D3PD__egammaRetaphiFillerTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'Prefix' : '', # str
  }
  _propertyDocDct = { 
    'Prefix' : """ Tuple variable prefix for this block. """,
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(D3PD__egammaRetaphiFillerTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'egammaD3PDMaker'
  def getType( self ):
      return 'D3PD::egammaRetaphiFillerTool'
  pass # class D3PD__egammaRetaphiFillerTool

class D3PD__egammaIDHitsExtraFillerTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'Prefix' : '', # str
  }
  _propertyDocDct = { 
    'Prefix' : """ Tuple variable prefix for this block. """,
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(D3PD__egammaIDHitsExtraFillerTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'egammaD3PDMaker'
  def getType( self ):
      return 'D3PD::egammaIDHitsExtraFillerTool'
  pass # class D3PD__egammaIDHitsExtraFillerTool

class D3PD__egammaConversionFillerTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'Prefix' : '', # str
  }
  _propertyDocDct = { 
    'Prefix' : """ Tuple variable prefix for this block. """,
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(D3PD__egammaConversionFillerTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'egammaD3PDMaker'
  def getType( self ):
      return 'D3PD::egammaConversionFillerTool'
  pass # class D3PD__egammaConversionFillerTool

class D3PD__egammaConversion0FillerTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'Prefix' : '', # str
  }
  _propertyDocDct = { 
    'Prefix' : """ Tuple variable prefix for this block. """,
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(D3PD__egammaConversion0FillerTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'egammaD3PDMaker'
  def getType( self ):
      return 'D3PD::egammaConversion0FillerTool'
  pass # class D3PD__egammaConversion0FillerTool

class D3PD__TrigEMClusterVarsFillerTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'Prefix' : '', # str
  }
  _propertyDocDct = { 
    'Prefix' : """ Tuple variable prefix for this block. """,
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(D3PD__TrigEMClusterVarsFillerTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'egammaD3PDMaker'
  def getType( self ):
      return 'D3PD::TrigEMClusterVarsFillerTool'
  pass # class D3PD__TrigEMClusterVarsFillerTool

class D3PD__TrigElectronChargeFillerTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'Prefix' : '', # str
  }
  _propertyDocDct = { 
    'Prefix' : """ Tuple variable prefix for this block. """,
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(D3PD__TrigElectronChargeFillerTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'egammaD3PDMaker'
  def getType( self ):
      return 'D3PD::TrigElectronChargeFillerTool'
  pass # class D3PD__TrigElectronChargeFillerTool

class D3PD__TrigElectronCalo1FillerTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'Prefix' : '', # str
  }
  _propertyDocDct = { 
    'Prefix' : """ Tuple variable prefix for this block. """,
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(D3PD__TrigElectronCalo1FillerTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'egammaD3PDMaker'
  def getType( self ):
      return 'D3PD::TrigElectronCalo1FillerTool'
  pass # class D3PD__TrigElectronCalo1FillerTool

class D3PD__TrigPhotonCalo1FillerTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'Prefix' : '', # str
  }
  _propertyDocDct = { 
    'Prefix' : """ Tuple variable prefix for this block. """,
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(D3PD__TrigPhotonCalo1FillerTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'egammaD3PDMaker'
  def getType( self ):
      return 'D3PD::TrigPhotonCalo1FillerTool'
  pass # class D3PD__TrigPhotonCalo1FillerTool

class D3PD__TrigElectronTrack1FillerTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'Prefix' : '', # str
  }
  _propertyDocDct = { 
    'Prefix' : """ Tuple variable prefix for this block. """,
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(D3PD__TrigElectronTrack1FillerTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'egammaD3PDMaker'
  def getType( self ):
      return 'D3PD::TrigElectronTrack1FillerTool'
  pass # class D3PD__TrigElectronTrack1FillerTool

class D3PD__TrigElectronTrack2FillerTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'Prefix' : '', # str
  }
  _propertyDocDct = { 
    'Prefix' : """ Tuple variable prefix for this block. """,
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(D3PD__TrigElectronTrack2FillerTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'egammaD3PDMaker'
  def getType( self ):
      return 'D3PD::TrigElectronTrack2FillerTool'
  pass # class D3PD__TrigElectronTrack2FillerTool

class D3PD__EmTau_ROIIsoFillerTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'Prefix' : '', # str
  }
  _propertyDocDct = { 
    'Prefix' : """ Tuple variable prefix for this block. """,
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(D3PD__EmTau_ROIIsoFillerTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'egammaD3PDMaker'
  def getType( self ):
      return 'D3PD::EmTau_ROIIsoFillerTool'
  pass # class D3PD__EmTau_ROIIsoFillerTool

class D3PD__egammaTrackParticleAssociationTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'Prefix' : '', # str
  }
  _propertyDocDct = { 
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(D3PD__egammaTrackParticleAssociationTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'egammaD3PDMaker'
  def getType( self ):
      return 'D3PD::egammaTrackParticleAssociationTool'
  pass # class D3PD__egammaTrackParticleAssociationTool

class D3PD__egammaClusterAssociationTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'Prefix' : '', # str
  }
  _propertyDocDct = { 
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(D3PD__egammaClusterAssociationTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'egammaD3PDMaker'
  def getType( self ):
      return 'D3PD::egammaClusterAssociationTool'
  pass # class D3PD__egammaClusterAssociationTool

class D3PD__ElectronGenParticleAssociationTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'Prefix' : '', # str
    'Classifier' : PrivateToolHandle('egammaMCTruthClassifier'), # GaudiHandle
    'DRVar' : '', # str
  }
  _propertyDocDct = { 
    'Classifier' : """ Classifier tool instance. """,
    'DRVar' : """ If not empty, the variable name to use for DR. """,
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(D3PD__ElectronGenParticleAssociationTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'egammaD3PDMaker'
  def getType( self ):
      return 'D3PD::ElectronGenParticleAssociationTool'
  pass # class D3PD__ElectronGenParticleAssociationTool

class D3PD__PhotonGenParticleAssociationTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'Prefix' : '', # str
    'Classifier' : PrivateToolHandle('egammaMCTruthClassifier'), # GaudiHandle
    'DRVar' : '', # str
  }
  _propertyDocDct = { 
    'Classifier' : """ Classifier tool instance. """,
    'DRVar' : """ If not empty, the variable name to use for DR. """,
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(D3PD__PhotonGenParticleAssociationTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'egammaD3PDMaker'
  def getType( self ):
      return 'D3PD::PhotonGenParticleAssociationTool'
  pass # class D3PD__PhotonGenParticleAssociationTool

class D3PD__egammaL1TriggerObjectAssociationTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'Prefix' : '', # str
    'MatchTool' : PublicToolHandle('TrigMatchTool/TrigMatchTool'), # GaudiHandle
    'IncidentService' : ServiceHandle('IncidentSvc'), # GaudiHandle
    'ChainPattern' : 'L1_EM.*', # str
    'OnlyPassed' : True, # bool
    'MaxDR' : 0.1, # float
  }
  _propertyDocDct = { 
    'MaxDR' : """ Maximum DR for match. """,
    'IncidentService' : """ Gaudi incident service. """,
    'MatchTool' : """ Trigger object matching tool. """,
    'ChainPattern' : """ Pattern to use for matching chains. """,
    'OnlyPassed' : """ If true, only select objects that passed trigger. """,
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(D3PD__egammaL1TriggerObjectAssociationTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'egammaD3PDMaker'
  def getType( self ):
      return 'D3PD::egammaL1TriggerObjectAssociationTool'
  pass # class D3PD__egammaL1TriggerObjectAssociationTool

class D3PD__egammaEFTriggerObjectAssociationTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'Prefix' : '', # str
    'MatchTool' : PublicToolHandle('TrigMatchTool/TrigMatchTool'), # GaudiHandle
    'IncidentService' : ServiceHandle('IncidentSvc'), # GaudiHandle
    'ChainPattern' : '.*', # str
    'OnlyPassed' : True, # bool
    'MaxDR' : 0.1, # float
  }
  _propertyDocDct = { 
    'MaxDR' : """ Maximum DR for match. """,
    'IncidentService' : """ Gaudi incident service. """,
    'MatchTool' : """ Trigger object matching tool. """,
    'ChainPattern' : """ Pattern to use for matching chains. """,
    'OnlyPassed' : """ If true, only select objects that passed trigger. """,
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(D3PD__egammaEFTriggerObjectAssociationTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'egammaD3PDMaker'
  def getType( self ):
      return 'D3PD::egammaEFTriggerObjectAssociationTool'
  pass # class D3PD__egammaEFTriggerObjectAssociationTool

class D3PD__ElectronL2TriggerObjectAssociationTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'Prefix' : '', # str
    'MatchTool' : PublicToolHandle('TrigMatchTool/TrigMatchTool'), # GaudiHandle
    'IncidentService' : ServiceHandle('IncidentSvc'), # GaudiHandle
    'ChainPattern' : 'L2_e.*', # str
    'OnlyPassed' : True, # bool
    'MaxDR' : 0.1, # float
  }
  _propertyDocDct = { 
    'MaxDR' : """ Maximum DR for match. """,
    'IncidentService' : """ Gaudi incident service. """,
    'MatchTool' : """ Trigger object matching tool. """,
    'ChainPattern' : """ Pattern to use for matching chains. """,
    'OnlyPassed' : """ If true, only select objects that passed trigger. """,
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(D3PD__ElectronL2TriggerObjectAssociationTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'egammaD3PDMaker'
  def getType( self ):
      return 'D3PD::ElectronL2TriggerObjectAssociationTool'
  pass # class D3PD__ElectronL2TriggerObjectAssociationTool

class D3PD__PhotonL2TriggerObjectAssociationTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'Prefix' : '', # str
    'MatchTool' : PublicToolHandle('TrigMatchTool/TrigMatchTool'), # GaudiHandle
    'IncidentService' : ServiceHandle('IncidentSvc'), # GaudiHandle
    'ChainPattern' : 'L2_g.*', # str
    'OnlyPassed' : True, # bool
    'MaxDR' : 0.1, # float
  }
  _propertyDocDct = { 
    'MaxDR' : """ Maximum DR for match. """,
    'IncidentService' : """ Gaudi incident service. """,
    'MatchTool' : """ Trigger object matching tool. """,
    'ChainPattern' : """ Pattern to use for matching chains. """,
    'OnlyPassed' : """ If true, only select objects that passed trigger. """,
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(D3PD__PhotonL2TriggerObjectAssociationTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'egammaD3PDMaker'
  def getType( self ):
      return 'D3PD::PhotonL2TriggerObjectAssociationTool'
  pass # class D3PD__PhotonL2TriggerObjectAssociationTool

class D3PD__TrigElectronClusterAssociationTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'Prefix' : '', # str
  }
  _propertyDocDct = { 
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(D3PD__TrigElectronClusterAssociationTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'egammaD3PDMaker'
  def getType( self ):
      return 'D3PD::TrigElectronClusterAssociationTool'
  pass # class D3PD__TrigElectronClusterAssociationTool

class D3PD__TrigPhotonClusterAssociationTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'Prefix' : '', # str
  }
  _propertyDocDct = { 
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(D3PD__TrigPhotonClusterAssociationTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'egammaD3PDMaker'
  def getType( self ):
      return 'D3PD::TrigPhotonClusterAssociationTool'
  pass # class D3PD__TrigPhotonClusterAssociationTool
