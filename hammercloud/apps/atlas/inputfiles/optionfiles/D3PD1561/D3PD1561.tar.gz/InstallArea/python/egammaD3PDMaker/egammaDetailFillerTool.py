from egammaD3PDMaker import egammaD3PDMakerConf



class egammaDetailFillerTool (egammaD3PDMakerConf.D3PD__egammaDetailFillerTool):
    def __init__ (self,
                  name,
                  Details = [],
                  **kwargs):
        Details = [str(x) for x in Details]
        egammaD3PDMakerConf.D3PD__egammaDetailFillerTool.__init__ (self,
                                                             name,
                                                             Details = Details,
                                                             **kwargs)
        
