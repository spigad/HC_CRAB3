//***************************************************************************
// Filename : TileRawChannel.h
// Author   : Ed Frank, Ambreesh Gupta, Frank Merritt
// Created  : Mar, 2002
//
// DESCRIPTION:
//    A TileRawChannel is the final result of simulation, and represents the
//    raw information (pulse height, time, quality) for the in-time beam
//    crossing in the Tile channel.
//    Optimal filtering has been carried out, but energy has not been
//    extracted.
//
// HISTORY:
//    02Mar02  Created to replace the (now obsolete) TileRawCell class.
//    20Sep02  Move to DataVector (A.Solodkov)
//    02Oct02  Now sub-class of TileRawData (A.Solodkov)
//
// BUGS:
//    Question:  the amplitude in a TileRawChannel is in ADC counts (not
//    calibrated).  What about time?
//
// ***************************************************************************

#ifndef TILEEVENT_TILERAWCHANNEL_H
#define TILEEVENT_TILERAWCHANNEL_H

#include "TileEvent/TileRawData.h"

class TileRawChannel : public TileRawData
{
public:

    /* Constructors */

    TileRawChannel() { }

    TileRawChannel(const Identifier& id, 
                   double amplitude, double time, double quality, double ped=0.0 ); 
    TileRawChannel(const HWIdentifier& HWid, 
                   double amplitude, double time, double quality, double ped=0.0 ); 

    /* Destructor */

    ~TileRawChannel() {}

    int add (double amplitude, double time, double quality );
    void setPedestal (double ped) { m_pedestal = ped; }
    void insertTime (double time);

    /* Inline access methods */

    inline double amplitude (int ind=0)  const { return m_amplitude[ind]; }
    inline double time      (int ind=0)  const { return m_time[ind]; }
    inline double uncorrTime()           const { return m_time[m_time.size()-1]; }
    inline double quality   (int ind=0)  const { return m_quality[ind]; }
    inline double pedestal  (void)       const { return m_pedestal; }

    inline int size     (void) const { return m_amplitude.size(); }
    inline int sizeTime (void) const { return m_time.size(); }

    std::string whoami   (void) const { return "TileRawChannel"; }
    void        print    (void) const;
    // Conversion operator to a std::string 
    // Can be used in a cast operation : (std::string) TileRawChannel
    operator std::string() const;

private:

  std::vector<double>     m_amplitude;  // amplitude in ADC counts (max=1023)
  std::vector<double>     m_time;       // time relative to triggering bunch
  std::vector<double>     m_quality;    // quality of the sampling distribution
  double                  m_pedestal;   // reconstructed pedestal value

       // quality is a number in [0,1] obtained by integrating the parent
       // distribution for the "goodness" from the DSP.  In hypothesis testing
       // terms, it is the significance of the hypothisis that the input
       // to the DSP matches the signal-model used to tune the DSP.
};

#endif  //TILEEVENT_TILERAWCHANNEL_H

