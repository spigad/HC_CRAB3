// This file's extension implies that it's C, but it's really -*- C++ -*-.
// $Id$
/**
 * @file D3PDMakerInterfaces/ISingleAssociationTool.h
 * @author scott snyder <snyder@bnl.gov>
 * @date Jul, 2009
 * @brief Abstract interface to form a single association.
 */

#ifndef D3PDMAKERINTERFACES_ISINGLEASSOCIATIONTOOL_H
#define D3PDMAKERINTERFACES_ISINGLEASSOCIATIONTOOL_H


#include "GaudiKernel/IAlgTool.h"
#include <typeinfo>


namespace D3PD {


/// Interface definition.
static const InterfaceID
IID_ISingleAssociationTool ("D3PD::ISingleAssociationTool", 1, 0);


/**
 * @brief Abstract interface to form a single association.
 *
 * This tool forms a single association; that is, it associates an object
 * with at most one other object.  The interface is similar
 * to @c IObjGetterTool, except that @c get takes a pointer to the source
 * object for the association.
 */
class ISingleAssociationTool
  : virtual public IAlgTool
{
public:
  /// Gaudi interface definition.
  static const InterfaceID& interfaceID()
  { return IID_ISingleAssociationTool; }


  /**
   * @brief Configure during initialization: book variables and type-check.
   * @param tree Our parent for tuple making.
   * @param ti Gives the type of the object being passed to @c resetUntyped.
   *
   * @c configure should check that the type of the object coming as input
   * (to @c getUntyped)
   * is compatible with what it expects, and raise an error otherwise.
   */
  virtual StatusCode configure (IAddVariable* tree,
                                const std::type_info& ti) = 0;


  /**
   * @brief Declare tuple variables.
   *
   * This is called at the start of the first event.
   */
  virtual StatusCode book() = 0;


  /**
   * @brief Return the type of object retrieved by this tool.
   */
  virtual const std::type_info& typeinfo() const = 0;


  /**
   * @brief Return the target object.
   * @param p The source object for the association.
   *
   * Return the target of the association, or 0.
   * Should be of the type given by @c typeinfo.
   */
  virtual const void* getUntyped (const void* p) = 0;
};


} // namespace D3PD


#endif // not D3PDMAKERINTERFACES_ISINGLEASSOCIATIONTOOL_H
