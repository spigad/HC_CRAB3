# $Id$
#
# @file D3PDMakerCoreComps/python/D3PDObject.py
# @author scott snyder <snyder@bnl.gov>
# @date Aug, 2009
# @brief D3PD object creator class.
#


from Block import Block
from reset_props import reset_props
import D3PDMakerCoreComps


def _make_name (name, prefix, name_prefix, parent_prefix):
    """Helper to form the name for object filler tools."""
    if name == None:
        pref = prefix + name_prefix
        if len (pref) == 0:
            pref = 'Unnamed_'
        name = parent_prefix + pref + 'Filler'
    return name


class D3PDObject:
    """D3PD object creator class.

    For each type of object written to the D3PD, create
    an instance of this class.  The arguments to the constructor
    are a function to create the Configurable for the object filler
    tool and a default value for the variable name prefix
    for this block.

    After creating the instance, one calls defineBlock to define
    the blocks of variables that can be written for this object.

    Finally, one calls the object in order to create the
    configurable.

    So, a typical usage might look like this.

      def makeElectronD3PDObject (name, prefix,
                                  getter = None,
                                  sgkey = 'ElectronAODCollection')
          if not getter:
              getter = D3PDMakerCoreComps.SGDataVectorGetterTool \
                       (name + '_Getter',
                        TypeName = 'ElectronContainer',
                        SGKey = sgkey)

          return D3PDMakerCoreComps.VectorFillerTool (name,
                                                      Prefix = prefix,
                                                      Getter = getter)

      ElectronD3PDObject = D3PDObject (makeElectronD3PDObject, 'el_')

      ElectronD3PDObject.defineBlock (0, 'Kinematics',
                                      EventCommonD3PDMaker.FourMomFillerTool)

      alg = ...
      alg += ElectronD3PDObject (level)
"""

    
    def __init__ (self, maker, default_prefix = '', default_name = None):
        """Constructor.

        Arguments:
          maker: A function to create the IObjFillerTool Configurable
                 for this object.  It is called with two fixed arguments,
                 the tool name and the variable name prefix.  Any other
                 arguments provided to the call will be passed through.
          default_prefix: Default variable name prefix for objects
                          of this type.
          default_name: If specified, the default tool name to use
                        for these objects.
"""
        self._maker = maker
        self._blocks = []
        self._all_blocknames = {}
        self._default_prefix = default_prefix
        self._default_name   = default_name
        return


    def defineBlock (self, lod, name, func, prefix = None, **kw):
        """Define a new block of variables for this object type.

    Arguments:
      lod: Level of detail of this block.  See below.
      name: Name of this block.
      func:   Function to create the block Configurable.
      prefix: Variable name prefix for this block.
      kw: Arguments to pass to the creation function.

    The creation function will be called like this:

       b.func (name, **b.kw)

    where name is the name for the tool.

    However, if b.func is a class deriving from D3PDObject, then the creation
    function will instead be called like this:

       b.func (level, name, parent_prefix, **b.kw)

    LOD is used to control whether this block should be included.

    In the simple case, this is an integer, and the block is included
    if the block's level of detail is less than or equal to the
    requested level of detail (unless the block was explicitly
    included or excluded).

    In the general case, LOD may be a function.  This is called with
    two arguments, the requested level of detail and the block filler
    arguments.  The requested level of detail will be an integer;
    it will be 999 if the block was explicitly included, and -999
    if the block was explicitly excluded.  The block filler arguments
    is a dictionary of keyword arguments.  The LOD function should
    return a boolean value saying whether or not the block should
    be included.  It may also alter the dictionary of arguments
    (this overrides all other argument settings).
"""
        if prefix != None:
            kw = kw.copy()
            kw['Prefix'] = prefix

        # Record this block name.
        # Also recursively record any blocks that it contains.
        # This will check that the names are unique.
        self._add_blockname (name)
        if isinstance (func, D3PDObject):
            for n in func.allBlocknames():
                self._add_blockname (n)

        self._blocks.append (Block (name, lod, func, kw))
        return


    def _add_blockname (self, n):
        """Add a new block name N to the list of all names.
        Raises an exception if a block name is duplicated.
"""
        if self._all_blocknames.has_key (n):
            raise ValueError ('Duplicate block name: ' + n)
        self._all_blocknames[n] = 1
        return


    def allBlocknames (self):
        """Return a dictionary the keys of which are the names of all blocks
        defined for this object.  This list will include any blocks defined
        recursively.
"""
        return self._all_blocknames


    def __call__ (self,
                  level,
                  name = None,
                  prefix = None,
                  name_prefix = '',
                  parent_prefix = '',
                  include = [],
                  exclude = [],
                  blockargs = {},
                  *args, **kw):
        """Create a Configurable to fill an object of this type.

        Arguments:
          level: Requested level of detail for this object.  An integer.
          name: Tool name.  If omitted, one will be constructed.
          prefix: Variable name prefix for this object.
          name_prefix: If name wasn't specified, this is a prefix
                       to add to the tool name.
          parent_prefix: Variable name prefix for any parent tool.
          include: List of block names to include, regardless
                   of level of detail.
          exclude: List of block names to exclude, regardless
                   of level of detail.
          blockargs: Extra arguments to pass to block filler tools.
                     The keys are block names.
                     Values are dictionaries of keyword arguments.
                     These override anything specified in defineBlock.
          args, kw: Additional arguments to pass to the maker function.
                    However, any entries in KW that have the form
                    BLOCK_parm, where BLOCK is a known block name,
                    will instead be interpreted as arguments to pass
                    to a block filler tool.  These override entries
                    in BLOCKARGS.
"""

        # Prefix defaults to that given to the constructor.
        if prefix == None:
            prefix = self._default_prefix

        # The tool name.
        if name == None:
            name = self._default_name
        name = _make_name (name, prefix, name_prefix, parent_prefix)

        # Copy blockargs and kw.
        blockargs = dict ([(k, v.copy()) for (k, v) in blockargs.items()])
        kw = kw.copy()

        # Move any block filler args from kw to blockargs.
        for k in kw.keys():
            kk = k.split('_')
            if len(kk) == 2 and self._all_blocknames.has_key (kk[0]):
                blockargs.setdefault(kk[0],{})[kk[1]] = kw[k]
                del kw[k]

        # Call the maker function.  We actually do this twice.
        # This is going to be a private tool, so the name need not
        # be unique.  But if the name isn't unique, then we'll
        # get any property settings which were specified before.
        # So, we call the maker once to get the (singleton) instance,
        # reset its properties, then call the maker function again.
        c = self._maker (name=name, prefix=prefix, *args, **kw)
        reset_props (c)
        c = self._maker (name=name, prefix=prefix, *args, **kw)

        # Create block filler tools.
        self._makeBlockFillers (c, level, parent_prefix + prefix,
                                include, exclude, blockargs)
        return c


    def blockFillers (self,
                      level,
                      parent_name,
                      parent_prefix = '',
                      include = [],
                      exclude = [],
                      blockargs = {}):
        """Return a list of block filler tool configurables.
        
        Arguments:
          level: Requested level of detail for this object.  An integer.
          parent_name: Name of the parent component.
          parent_prefix: Variable name prefix for any parent tool.
          include: List of block names to include, regardless
                   of level of detail.
          exclude: List of block names to exclude, regardless
                   of level of detail.
          blockargs: Extra arguments to pass to block filler tools.
                     The keys are block names.
                     Values are dictionaries of keyword arguments.
                     These override anything specified in defineBlock.
          """
        out = []
        for b in self._blocks:
            # Find the requested level.
            if b.name in include:
                # Always request inclusion.
                reqlev = 999
            elif b.name in exclude:
                # Always request exclusion.
                reqlev = -999
            else:
                # Request level passed in.
                reqlev = level

            # Block filler arguments.
            args = b.kw.copy()
            args.update (blockargs.get (b.name, {}))

            # Decide whether to include this block.
            # If the block's LOD is callable, call it.
            # Otherwise, just compare.
            if callable (b.lod):
                doblock = b.lod (reqlev, args)
            else:
                doblock = (b.lod <= reqlev)
            
            if doblock:
                fillername = parent_name + '_' + b.name
                if isinstance (b.func, D3PDObject): # ugly!
                    bf = b.func (level, fillername,
                                 parent_prefix = parent_prefix,
                                 **args)
                else:
                    bf = b.func (fillername, **args)
                out += [bf]
        return out


    def _makeBlockFillers (self,
                           c,
                           level,
                           parent_prefix,
                           include,
                           exclude,
                           blockargs):
        """Create block filler tools for object C, for the specified
        level of detail.

        Arguments:
          c: Object for which to create the block fillers.
          level: Requested level of detail for this object.  An integer.
          parent_prefix: Variable name prefix for any parent tool.
          include: List of block names to include, regardless
                   of level of detail.
          exclude: List of block names to exclude, regardless
                   of level of detail.
          blockargs: Extra arguments to pass to block filler tools.
                     The keys are block names.
                     Values are dictionaries of keyword arguments.
                     These override anything specified in defineBlock.
"""
        for bf in self.blockFillers (level, c.getName(), parent_prefix,
                                     include, exclude, blockargs):
            c.BlockFillers += [bf]
        return
    
        


def make_SG_D3PDObject (type_name,
                        default_sgkey,
                        default_prefix,
                        default_allow_missing = False):
    """Helper to make a D3PDObject for the common case where the default
input source is a single object from StoreGate.

        Arguments:
          type_name: The name of the type being fetched from StoreGate.
          default_sgkey: The default value for the StoreGate key.
          default_prefix: The default prefix to put in front of variables.
          default_allow_missing: The default value for the AllowMissing
            property (defaults to False).

        Typical usage would be something like this:

           METD3PDObject = \
              make_SG_D3PDObject ('MissingET',
                                  D3PDMakerFlags.MissingETSGKey(),
                                  'met_')
        
"""
    def make_obj (name, prefix,
                  getter = None,
                  sgkey = None,
                  allow_missing = default_allow_missing):
        if sgkey == None: sgkey = default_sgkey
        if not getter:
            getter = D3PDMakerCoreComps.SGObjGetterTool \
                     (name + '_Getter',
                      TypeName = type_name,
                      SGKey = sgkey)
        return D3PDMakerCoreComps.ObjFillerTool (name,
                                                 Prefix = prefix,
                                                 Getter = getter,
                                                 AllowMissing=allow_missing)
    return D3PDObject (make_obj, default_prefix)



def make_SGDataVector_D3PDObject (type_name,
                                  default_sgkey,
                                  default_prefix,
                                  default_allow_missing = False,
                                  **other_defaults):
    """Helper to make a D3PDObject for the common case where the default
input source is a DataVector container from StoreGate.

        Arguments:
          type_name: The name of the type being fetched from StoreGate.
          default_sgkey: The default value for the StoreGate key.
          default_prefix: The default prefix to put in front of variables.
          default_allow_missing: The default value for the AllowMissing
            property (defaults to False).

        Typical usage would be something like this:

           JetD3PDObject = \
              make_SGDataVector_D3PDObject ('JetCollection',
                                            D3PDMakerFlags.JetSGKey(),
                                            'jet_')
        
"""
    def make_obj (name, prefix,
                  getter = None,
                  sgkey = None,
                  label = None,
                  allow_missing = default_allow_missing,
                  **kw):
        if sgkey == None: sgkey = default_sgkey
        if label == None: label = prefix
        if not getter:
            getter = D3PDMakerCoreComps.SGDataVectorGetterTool \
                     (name + '_Getter',
                      TypeName = type_name,
                      SGKey = sgkey,
                      Label = label)
        defs = other_defaults.copy()
        defs.update (kw)
        return D3PDMakerCoreComps.VectorFillerTool (name,
                                                    Prefix = prefix,
                                                    Getter = getter,
                                                    AllowMissing=allow_missing,
                                                    **defs)
    return D3PDObject (make_obj, default_prefix)
