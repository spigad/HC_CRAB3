#Mon Dec 21 20:53:56 2009
"""Automatically generated. DO NOT EDIT please"""
from GaudiKernel.GaudiHandles import *
from GaudiKernel.Proxy.Configurable import *

class D3PD__MakerAlg( ConfigurableAlgorithm ) :
  __slots__ = { 
    'OutputLevel' : 0, # int
    'Enable' : True, # bool
    'ErrorMax' : 1, # int
    'ErrorCount' : 0, # int
    'AuditAlgorithms' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditReinitialize' : False, # bool
    'AuditRestart' : False, # bool
    'AuditExecute' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditBeginRun' : False, # bool
    'AuditEndRun' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'MonitorService' : 'MonitorSvc', # str
    'D3PDSvc' : ServiceHandle('D3PD::RootD3PDSvc'), # GaudiHandle
    'Tools' : PrivateToolHandleArray([]), # GaudiHandleArray
    'MetadataTools' : PrivateToolHandleArray([]), # GaudiHandleArray
    'TuplePath' : '', # str
  }
  _propertyDocDct = { 
    'D3PDSvc' : """ The D3PD creation service. """,
    'Tools' : """ List of IObjFillerTool instances to run. """,
    'TuplePath' : """ The name of the tuple.  The interpretation of this depends on the D3PDSvc. """,
    'MetadataTools' : """ List of IMetadataTool instances to run. """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(D3PD__MakerAlg, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'D3PDMakerCoreComps'
  def getType( self ):
      return 'D3PD::MakerAlg'
  pass # class D3PD__MakerAlg

class D3PD__DummyInitAlg( ConfigurableAlgorithm ) :
  __slots__ = { 
    'OutputLevel' : 0, # int
    'Enable' : True, # bool
    'ErrorMax' : 1, # int
    'ErrorCount' : 0, # int
    'AuditAlgorithms' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditReinitialize' : False, # bool
    'AuditRestart' : False, # bool
    'AuditExecute' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditBeginRun' : False, # bool
    'AuditEndRun' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'MonitorService' : 'MonitorSvc', # str
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
  }
  _propertyDocDct = { 
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(D3PD__DummyInitAlg, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'D3PDMakerCoreComps'
  def getType( self ):
      return 'D3PD::DummyInitAlg'
  pass # class D3PD__DummyInitAlg

class D3PD__CollectionGetterRegistryTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'JobOptionsSvc' : ServiceHandle('JobOptionsSvc'), # GaudiHandle
    'ToolSvc' : ServiceHandle('ToolSvc'), # GaudiHandle
  }
  _propertyDocDct = { 
    'ToolSvc' : """ The ToolSvc instance. """,
    'JobOptionsSvc' : """ The JobOptionsSvc instance. """,
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(D3PD__CollectionGetterRegistryTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'D3PDMakerCoreComps'
  def getType( self ):
      return 'D3PD::CollectionGetterRegistryTool'
  pass # class D3PD__CollectionGetterRegistryTool

class D3PD__ObjFillerTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'Getter' : PrivateToolHandle('D3PD::IObjGetterTool'), # GaudiHandle
    'BlockFillers' : PrivateToolHandleArray([]), # GaudiHandleArray
    'Prefix' : '', # str
    'AllowMissing' : False, # bool
  }
  _propertyDocDct = { 
    'BlockFillers' : """ List of contained block filler tools. """,
    'Prefix' : """ Variable name prefix for the contained blocks. """,
    'AllowMissing' : """ If true, then it is not considered an error for the requested input object to be missing. """,
    'Getter' : """ The IObjGetterTool instance. """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(D3PD__ObjFillerTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'D3PDMakerCoreComps'
  def getType( self ):
      return 'D3PD::ObjFillerTool'
  pass # class D3PD__ObjFillerTool

class D3PD__VoidObjFillerTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'BlockFillers' : PrivateToolHandleArray([]), # GaudiHandleArray
    'Prefix' : '', # str
  }
  _propertyDocDct = { 
    'BlockFillers' : """ List of contained block filler tools. """,
    'Prefix' : """ Variable name prefix for the contained blocks. """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(D3PD__VoidObjFillerTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'D3PDMakerCoreComps'
  def getType( self ):
      return 'D3PD::VoidObjFillerTool'
  pass # class D3PD__VoidObjFillerTool

class D3PD__VectorFillerTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'Getter' : PrivateToolHandle('D3PD::ICollectionGetterTool'), # GaudiHandle
    'BlockFillers' : PrivateToolHandleArray([]), # GaudiHandleArray
    'Prefix' : '', # str
    'AllowMissing' : False, # bool
    'NrowName' : 'n', # str
    'NobjName' : '', # str
    'ObjIndexName' : '', # str
  }
  _propertyDocDct = { 
    'BlockFillers' : """ List of contained block filler tools. """,
    'Prefix' : """ Variable name prefix for the contained blocks. """,
    'AllowMissing' : """ If true, then it is not considered an error for the requested input object to be missing. """,
    'Getter' : """ The ICollectionGetterTool instance. """,
    'ObjIndexName' : """ Name of the variable for the object index. Omitted if empty. """,
    'NrowName' : """ Name of the variable for the count of rows. Omitted if empty. """,
    'NobjName' : """ Name of the variable for the count of objects. Omitted if empty. """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(D3PD__VectorFillerTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'D3PDMakerCoreComps'
  def getType( self ):
      return 'D3PD::VectorFillerTool'
  pass # class D3PD__VectorFillerTool

class D3PD__ContainedAssociationFillerTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'Associator' : PrivateToolHandle('D3PD::ISingleAssociationTool'), # GaudiHandle
    'BlockFillers' : PrivateToolHandleArray([]), # GaudiHandleArray
    'Prefix' : '', # str
    'Matched' : 'matched', # str
  }
  _propertyDocDct = { 
    'BlockFillers' : """ List of contained block filler tools. """,
    'Prefix' : """ Variable name prefix for the contained blocks. """,
    'Associator' : """ The ISingleAssociationTool instance. """,
    'Matched' : """ Variable name to use for the matched flag.  Omitted if empty. """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(D3PD__ContainedAssociationFillerTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'D3PDMakerCoreComps'
  def getType( self ):
      return 'D3PD::ContainedAssociationFillerTool'
  pass # class D3PD__ContainedAssociationFillerTool

class D3PD__IndexAssociationFillerTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'Associator' : PrivateToolHandle('D3PD::ISingleAssociationTool'), # GaudiHandle
    'Target' : '', # str
    'Prefix' : '', # str
    'CollectionGetterRegistry' : PublicToolHandle('D3PD::ICollectionGetterRegistryTool'), # GaudiHandle
  }
  _propertyDocDct = { 
    'Prefix' : """ Variable name prefix for the index variable. """,
    'CollectionGetterRegistry' : """ The ICollectionGetterRegistryTool instance. """,
    'Associator' : """ The ISingleAssociationTool instance. """,
    'Target' : """ Label of the collection getter defining the collection within which to index. """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(D3PD__IndexAssociationFillerTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'D3PDMakerCoreComps'
  def getType( self ):
      return 'D3PD::IndexAssociationFillerTool'
  pass # class D3PD__IndexAssociationFillerTool

class D3PD__ContainedMultiAssociationFillerTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'Associator' : PrivateToolHandle('D3PD::IMultiAssociationTool'), # GaudiHandle
    'BlockFillers' : PrivateToolHandleArray([]), # GaudiHandleArray
    'Prefix' : '', # str
  }
  _propertyDocDct = { 
    'BlockFillers' : """ List of contained block filler tools. """,
    'Prefix' : """ Variable name prefix for the contained blocks. """,
    'Associator' : """ The IMultiAssociationTool instance. """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(D3PD__ContainedMultiAssociationFillerTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'D3PDMakerCoreComps'
  def getType( self ):
      return 'D3PD::ContainedMultiAssociationFillerTool'
  pass # class D3PD__ContainedMultiAssociationFillerTool

class D3PD__IndexMultiAssociationFillerTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'Associator' : PrivateToolHandle('D3PD::IMultiAssociationTool'), # GaudiHandle
    'Target' : '', # str
    'Prefix' : '', # str
    'CollectionGetterRegistry' : PublicToolHandle('D3PD::ICollectionGetterRegistryTool'), # GaudiHandle
  }
  _propertyDocDct = { 
    'Prefix' : """ Variable name prefix for the index variable. """,
    'CollectionGetterRegistry' : """ The ICollectionGetterRegistryTool instance. """,
    'Associator' : """ The ISingleAssociationTool instance. """,
    'Target' : """ Label of the collection getter defining the collection within which to index. """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(D3PD__IndexMultiAssociationFillerTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'D3PDMakerCoreComps'
  def getType( self ):
      return 'D3PD::IndexMultiAssociationFillerTool'
  pass # class D3PD__IndexMultiAssociationFillerTool

class D3PD__SGObjGetterTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'TypeName' : '', # str
    'SGKey' : '', # str
    'ClassIDSvc' : ServiceHandle('ClassIDSvc'), # GaudiHandle
  }
  _propertyDocDct = { 
    'ClassIDSvc' : """ ClassIDSvc instance to use. """,
    'TypeName' : """ Name of the type of the object being retrieved """,
    'SGKey' : """ StoreGate key of the object being retrieved.  This may be a comma or space-separated list; the first existing key will be used. """,
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(D3PD__SGObjGetterTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'D3PDMakerCoreComps'
  def getType( self ):
      return 'D3PD::SGObjGetterTool'
  pass # class D3PD__SGObjGetterTool

class D3PD__SGDataVectorGetterTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'Label' : '', # str
    'CollectionGetterRegistry' : PublicToolHandle('D3PD::ICollectionGetterRegistryTool'), # GaudiHandle
    'TypeName' : '', # str
    'SGKey' : '', # str
    'ClassIDSvc' : ServiceHandle('ClassIDSvc'), # GaudiHandle
  }
  _propertyDocDct = { 
    'ClassIDSvc' : """ ClassIDSvc instance to use. """,
    'TypeName' : """ Name of the type of the object being retrieved """,
    'Label' : """ Label to assign to this getter, to be able to reference it from an association tool.  Leave blank if no label is needed. """,
    'CollectionGetterRegistry' : """ Collection getter registry tool """,
    'SGKey' : """ StoreGate key of the object being retrieved.  This may be a comma or space-separated list; the first existing key will be used. """,
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(D3PD__SGDataVectorGetterTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'D3PDMakerCoreComps'
  def getType( self ):
      return 'D3PD::SGDataVectorGetterTool'
  pass # class D3PD__SGDataVectorGetterTool

class D3PD__UserDataFillerTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'Prefix' : '', # str
    'UserDataSvc' : ServiceHandle('UserDataSvc'), # GaudiHandle
    'UDPrefix' : '', # str
    'Vars' : [  ], # list
  }
  _propertyDocDct = { 
    'Prefix' : """ Tuple variable prefix for this block. """,
    'UserDataSvc' : """ The UserDataSvc """,
    'Vars' : """ Specify variables to fill.
A sequence of VAR, LABEL, TYPE.
VAR is the D3PD variable name.
LABEL is the UDS label.  If blank, defaults to VAR.
TYPE is the name of the UD type. """,
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
    'UDPrefix' : """ Prefix to add to UD labels. """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(D3PD__UserDataFillerTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'D3PDMakerCoreComps'
  def getType( self ):
      return 'D3PD::UserDataFillerTool'
  pass # class D3PD__UserDataFillerTool
