# $Id$
#
# @file egammaD3PDMaker/python/isem_version.py
# @author scott snyder <snyder@bnl.gov>
# @date Oct, 2009
# @brief Try to determine which isem mask version is being used.
#

"""Try to determine which isem mask version is being used.
"""

from D3PDMakerConfig.D3PDMakerFlags import D3PDMakerFlags


def isem_version():
    """Try to determine which isem version is used.

    If a version was explicitly specified via the flag, use that.
    Otherwise, try to figure it out from the file metadata.
"""
    
    isem_version = D3PDMakerFlags.IsEMVersion()

    if isem_version == None:
        from RecExConfig.InputFilePeeker import inputFileSummary
        release = None
        try:
            release = inputFileSummary['metadata']['/TagInfo']['AtlasRelease']
        except KeyError:
            pass
        if not release:
            # Assume old version if we don't find the version string in metadata.
            isem_version = 1
        else:
            # Assume new version if there's a version string there, but not
            # in a format we recognize.  This may be from a private test build. 
            isem_version = 2
            rlist = release.split ('-')
            if len(rlist) >= 2:
                rlist = rlist[1].split ('.')
                if len(rlist) >= 2:
                    try:
                        v1 = int(rlist[0])
                        v2 = int(rlist[1])
                        if v1 < 15 or (v1 == 15 and v1 < 2):
                            # Version < 15.2.
                            isem_version = 1
                    except ValueError:
                        pass

    if not 1 <= isem_version <= 2:
        raise ValueError ("Bad IsEMVersion setting: %d" % isem_version)

    return isem_version

