//***************************************************************************
// Filename : TileDigits.h
// Author   : Frank Merritt
// Created  : May 16, 2002
//
// DESCRIPTION:
//    A TileDigits is the data class corresponding to the amplitude information
//    transmitted from the digitizers to the ROD's.  It contains a hardware
//    identifier (including pmt and adc info) and nsample amplitudes corresponding
//    to the time slices read out.  Optimal filtering must be applied to these
//    amplitudes (including pedestal subtractioin) to produce a TileRawChannel.
//
// HISTORY:
//    14May02  First created for DC1 phase-1 and HLT studies.
//    02Oct02  Now sub-class of TileRawData (A.Solodkov)
//
// ***************************************************************************

#ifndef TILEEVENT_TILEDIGITS_H
#define TILEEVENT_TILEDIGITS_H

#include "TileEvent/TileRawData.h"

class TileDigits : public TileRawData
{
public:
   
    /* Constructors */

    TileDigits() { }

    TileDigits(const Identifier& id, const std::vector<double>& digits );

    TileDigits(const HWIdentifier& HWid, const std::vector<double>& digits );
  
    TileDigits(const HWIdentifier& HWid, const std::vector<short>& digits );
  
    /* Destructor */

    ~TileDigits() { }

    /* Inline access methods */

    inline int NtimeSamples(void) const { return m_digits.size(); }
  
    inline std::vector<double>  get_digits(void)  const { return m_digits; }
    // inline std::vector<int>  get_Idigits(void) const { return m_digits; }
    inline const std::vector<double>  * get_digits_ptr(void)  const { return &m_digits; }

    std::string whoami   (void) const { return "TileDigits"; }
    void        print    (void) const;
    // Convertion operator to a std::string 
    // Can be used in a cast operation : (std::string) TileRawChannel
    operator std::string() const;

private:

  /* Member variables: */
  std::vector<double> m_digits;
};

#endif  //TILEEVENT_TILEDIGITS_H

