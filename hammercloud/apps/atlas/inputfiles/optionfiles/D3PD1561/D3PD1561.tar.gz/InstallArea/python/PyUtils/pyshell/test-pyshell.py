import logging,user
logging.RootLogger.root.setLevel (logging.DEBUG)

import localshell as ls
sh = ls.LocalShell()
