import egammaD3PDMakerConf
for k, v in egammaD3PDMakerConf.__dict__.items():
    if k.startswith ('D3PD__'):
        globals()[k[6:]] = v

from egammaDetailFillerTool import egammaDetailFillerTool
from egammaPIDFillerTool    import egammaPIDFillerTool
from egammaIsEMFillerTool   import egammaIsEMFillerTool
