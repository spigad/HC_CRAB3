import CaloD3PDMaker
import D3PDMakerCoreComps
import EventCommonD3PDMaker
from D3PDMakerCoreComps.D3PDObject import D3PDObject
from D3PDMakerConfig.D3PDMakerFlags import D3PDMakerFlags
from CaloD3PDMaker import CaloD3PDMakerConf

def makeCellD3PDObject (name, prefix, getter = None,
                           sgkey = None,
                           label = None):
    if sgkey == None: sgkey = 'AllCalo'
    if label == None: label = prefix
    if not getter:
        getter = D3PDMakerCoreComps.SGDataVectorGetterTool \
                 (name + '_Getter',
                  TypeName = 'CaloCellContainer',
                  SGKey = sgkey,
                  Label = label)
        
    return D3PDMakerCoreComps.VectorFillerTool (name,
                                                Prefix = prefix,
                                                Getter = getter)
CellD3PDObject = D3PDObject (makeCellD3PDObject, 'cells_')


CellD3PDObject.defineBlock (0, 'Kinematics',
                               CaloD3PDMaker.CellFillerTool)


