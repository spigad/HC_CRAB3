/*author Renato Febbraro*/
/*date 27/5/2008*/
/*renato.febbraro@cern.ch*/

#ifndef TILELASERPLC
#define TILELASERPLC

namespace TileLaser{

  class TileLaserPLC{

  public:
    
    int getAlphaPos() const;
    double getLVdiodes() const;
    double getHVpmts() const;
    int getShutter() const;
    int getInterlock() const;
    int getAlarm() const;

    void setPLC(const int alphaPos,
		const double LVdiodes,
		const double HVpmts,
		const int shutter,
		const int interlock,
		const int alarm);
  private:

    int m_alphaPos;
    double m_LVdiodes;
    double m_HVpmts;
    int m_shutter;
    int m_interlock;
    int m_alarm;
 

  };

inline void TileLaserPLC::setPLC(const int alphaPos,
				 const double LVdiodes,
				 const double HVpmts,
				 const int shutter,
				 const int interlock,
				 const int alarm)
    {

      m_alphaPos = alphaPos;
      m_LVdiodes = LVdiodes;
      m_HVpmts = HVpmts;
      m_shutter = shutter;
      m_interlock = interlock;
      m_alarm = alarm;

    }
  
inline int TileLaserPLC::getAlphaPos() const{return m_alphaPos;}
inline double TileLaserPLC::getLVdiodes() const{return m_LVdiodes;}
inline double TileLaserPLC::getHVpmts() const{return m_HVpmts;}
inline int TileLaserPLC::getShutter() const{return m_shutter;}
inline int TileLaserPLC::getInterlock() const{return m_interlock;}
inline int TileLaserPLC::getAlarm() const{return m_alarm;}

}

#endif
