//***************************************************************************
// Filename : TileL2.h
// Author   : Aranzazu Ruiz
// Created  : March 2006
//
// DESCRIPTION:
//    L2 is the class which keeps various numbers pre-calculated in ROD
//    which can be used in Level 2 trigger
//    One TileL2 contains all numbers for one drawer
//
// HISTORY:
//
// ***************************************************************************

#ifndef TILEEVENT_TILEL2_H
#define TILEEVENT_TILEL2_H

#include <vector>
#include <string>
#include <cmath>

/**
 * @class TileL2
 * @brief Class to store TileMuId and Et quantities computed at the TileCal ROD DSPs 
 * @author A. Ruiz (aranzazu.ruiz.martinez@cern.ch)
 */

class TileL2 {

  public:

  /** Constructor */
  TileL2() {}

  /** Constructor */
  TileL2(int id, const std::vector<unsigned int>& val);

  /** Constructor */
  TileL2(int id, const std::vector<unsigned int>& val, std::vector<double>& eta, double phi, double Et=0.0);

  /** Constructor */
  TileL2(int id, const std::vector<unsigned int>& val, std::vector<double>& eta, double phi, std::vector<double>& enemu0, std::vector<double>& enemu1, std::vector<double>& enemu2, std::vector<unsigned int>& qual, double Et=0.0);

  /** Destructor */
  ~TileL2() {}

  /* Access methods */

  /** Return Identifier */
  inline int identify(void) const { return m_ID; }

  /** Return Data */
  inline unsigned int val(unsigned int i) const { return m_val[i]; }

  /** Return number of muons */
  inline unsigned int NMuons() const { return m_eta.size(); }

  /** Return eta (computed as the average of the eta values of the TileCal cells where the muon goes through) */
  inline double eta(unsigned int ind) const { return m_eta[ind]; }

  /** Return phi (average value at the TileCal radius) */
  inline double phi(unsigned int /* ind=0 */) const { return m_phi; }

  /** Return energy deposited in innermost layer (A cells) */
  inline double enemu0(unsigned int ind) const { return m_enemu0[ind]; }

  /** Return energy deposited in central layer (BC cells) */
  inline double enemu1(unsigned int ind) const { return m_enemu1[ind]; }

  /** Return energy deposited in outermost layer (D cells) */
  inline double enemu2(unsigned int ind) const { return m_enemu2[ind]; }

  /** Return quality flag (0 or 1):
   * set to 0 if the "energy deposition path" is MIP like in all three samples,
   * set to 1 if the "energy deposition path" is MIP like in two samples and a larger energy deposition is found in the remaining cell
   */
  inline unsigned int qual(unsigned int ind) const { return m_quality_factor[ind]; }

  /** Return total Et in a TileCal superdrawer (ROD-based) */
  inline double Et() const { return m_Et; }

  /** Return Ex in a TileCal superdrawer (ROD-based) */
  inline double Ex() const { return m_Et*cos(m_phi); }

  /** Return Ey in a TileCal superdrawer (ROD-based) */
  inline double Ey() const { return m_Et*sin(m_phi); }

  /** Return identification */
  std::string whoami (void) const { return "TileL2"; }

  /** Printing for debugging */
  void print (void) const;

  /** Convertion operator to a std::string,
   * can be used in a cast operation : (std::string) TileL2 */
  operator std::string() const;

  /** Set TileL2 objects */
  void setL2(int identify,
	     std::vector<unsigned int> val,
	     std::vector<double> eta,
	     double phi,
	     std::vector<double> enemu0,
	     std::vector<double> enemu1,
	     std::vector<double> enemu2,
	     std::vector<unsigned int> qual,
	     double Et);

  /** Clear TileL2 objects */
  void clear();

  private:

  /** Drawer ID: 0x100-0x13F, 0x200-0x23F, 0x300-0x33F, 0x400-0x43F */
  int m_ID;

  /** 32-bit words */
  std::vector<unsigned int> m_val;

  /** Muon eta */
  std::vector<double> m_eta;

  /** Muon phi */
  double m_phi;

  /** Energy deposited by the muons in TileCal innermost layer */
  std::vector<double> m_enemu0;

  /** Energy deposited by the muons in TileCal central layer */
  std::vector<double> m_enemu1;

  /** Energy deposited by the muons in TileCal outermost layer */
  std::vector<double> m_enemu2;

  /** Quality flag for tight and loose muon selection */
  std::vector<unsigned int> m_quality_factor;

  /** Total transverse energy per TileCal superdrawer */
  double m_Et;
};

#endif  //TILEEVENT_TILEL2_H
