# @file PyUtils/python/AthFile/impl.py
# @purpose a simple abstraction of a file to retrieve informations out of it
# @author Sebastien Binet <binet@cern.ch>
# @date November 2009

from __future__ import with_statement

__version__ = "$Revision: 230196 $"
__author__  = "Sebastien Binet"
__doc__ = "implementation of AthFile-server behind a set of proxies to isolate environments"

import os
import multiprocessing
import multiprocessing.managers

mp = multiprocessing

import PyUtils.Helpers as H
from PyUtils.Helpers    import ShutUp

### globals -------------------------------------------------------------------
DEFAULT_AF_CACHE_FNAME = os.environ.get('DEFAULT_AF_CACHE_FNAME',
                                        'athfile-cache.ascii')

### utils ----------------------------------------------------------------------
def _find_file(filename, pathlist, access):
    """Find <filename> with rights <access> through <pathlist>."""
    import os
    import os.path as osp
    # special case for those filenames that already contain a path
    if osp.dirname(filename):
        if os.access(filename, access):
            return filename

    # test the file name in all possible paths until first found
    for path in pathlist:
        f = osp.join(path, filename)
        if os.access(f, access):
            return f

    # no such accessible file avalailable
    return None

def _create_file_infos():
    """simple helper function to create consistent dicts for the
    fileinfos attribute of AthFile
    """
    d = {
        'file_md5sum': None,
        'file_name': None,
        'file_type': None,
        'file_guid': None,
        'nentries' : 0, # to handle empty files
        'run_number': [],
        'run_type': [],
        'evt_type': [],
        'evt_number': [],
        'lumi_block': [],
        'beam_energy': [],
        'beam_type':   [],
        'stream_tags': [],
        'metadata_items': None,
        'eventdata_items': None,
        'stream_names': None,
        'geometry': None,
        'conditions_tag': None,
        'det_descr_tags': None,
        ##
        'metadata': None,
        'tag_info': None,
        }
    return d

### classes -------------------------------------------------------------------
class AthFile (object):
    """A handle to an athena file (POOL,ROOT or ByteStream)
    """
    __slots__ = ('fileinfos',)
    
    @staticmethod
    def from_infos(infos):
        o = AthFile()
        o.fileinfos = _create_file_infos() # ensure basic layout
        o.fileinfos.update(infos.copy())
        return o

    @staticmethod
    def from_fname(fname):
        import PyUtils.AthFile as af
        return af.fopen(fname)

    @property
    def name(self):
        return self.fileinfos['file_name']
    
    @property
    def nentries(self):
        return self.fileinfos['nentries']
    
    @property
    def infos(self):
        return self.fileinfos

    @property
    def run_number (self):
        """return the list of unique run-numbers the @c AthFile contains"""
        return list(set(self.infos['run_number']))
    # backward compatibility
    run_numbers = run_number
    
    @property
    def evt_number (self):
        """return the list of unique evt-numbers the @c AthFile contains"""
        return list(set(self.infos['evt_number']))
    
    @property
    def lumi_block (self):
        """return the list of unique lumi-block nbrs the @c AthFile contains
        """
        return list(set(self.infos['lumi_block']))
    
    @property
    def run_type (self):
        """return the list of unique run-types the @c AthFile contains"""
        return list(set(self.infos['run_type']))
    
    @property
    def beam_type (self):
        """return the list of unique beam-types the @c AthFile contains"""
        return list(set(self.infos['beam_type']))
    
    @property
    def beam_energy (self):
        """return the list of unique beam-energies the @c AthFile contains"""
        return list(set(self.infos['beam_energy']))
    
    pass # AthFile class

class AthFileMgr(mp.managers.BaseManager):
    """the manager of AthFile functionalities
    """
    pass

def _get_msg(name="AthFile"):
    import PyUtils.Logging as _L
    msg = _L.logging.getLogger(name)
    msg.setLevel(_L.logging.INFO)
    return msg
    
class AthFileServer(object):
    """the object serving AthFile requests
    """
    
    def __init__(self):
        #global msg
        import PyUtils.Logging as _L
        #self._msg = msg
        #self._msg = self._manager.msg()
        self._msg = _get_msg()#_L.logging.getLogger("AthFile")
        #self._msg = mp.get_logger("AthFile")
        #self._msg.setFormat("Py:%(name)-14s%(levelname)8s %(message)s")

        #self.msg.info('importing ROOT...')
        import PyUtils.RootUtils as ru
        self.pyroot = ru.import_root()
        ru._pythonize_tfile()
        #self.msg.info('importing ROOT... [done]')

        # a cache of already processed requests
        self._cache = {}
        self._do_pers_cache = True
        self.enable_pers_cache()

        # instantiate a "request handler"
        self._peeker = FilePeeker(self)
        
        return

    def msg(self):
        return self._msg
    
    def set_msg_lvl(self, lvl):
        self._msg.setLevel(lvl)
        
    def _md5_for_file(self, f, block_size=2**20, do_fast_md5=True):
        """helper function to calculate a MD5 checksum
        ``f`` can be filename, an open python file or an open TFile
        """
        import hashlib
        md5 = hashlib.md5()
        if isinstance(f, basestring):
            protocol,fname = self.fname(f)
            f = self.pyroot.TFile.Open(fname+'?filetype=raw', 'read')

        assert hasattr(f, 'read'), "'f' must be a file-like object"
        orig_pos = f.tell()
        f.seek(0)
        try:
            while True:
                data = f.read(block_size)
                if not data:
                    break
                md5.update(data)
                if do_fast_md5:
                    break
        finally:
            f.seek(orig_pos)
        return md5.hexdigest()

    def _root_open(self, fname):
        import PyUtils.Helpers as H
        # speed-up by tampering LD_LIBRARY_PATH to not load reflex-dicts
        import re
        with H.restricted_ldenviron(projects=['AtlasCore']):
            with H.ShutUp(filters=[
                re.compile(
                    'TClass::TClass:0: RuntimeWarning: no dictionary for.*'),
                ]):
                return self.pyroot.TFile.Open(fname+"?filetype=raw", "read")
        return

    def fopen(self, fname):
        msg = self.msg()
        msg.info("opening [%s]...", fname)
        cache = {}
        for k,v in self._cache.iteritems():
            v = v.infos
            fid = v.get('file_md5sum', v['file_guid'])
            cache[fid] = k

        fid = self.md5sum(fname)
        if not fid in cache:
            infos = self._peeker(fname)
            f = AthFile.from_infos(infos)
            self._cache[fname] = f
            # hysteresis...
            self._cache[infos['file_name']] = f
            cache[fid] = fname
        self._sync_pers_cache()
        return self._cache[cache[fid]]
    
    def md5sum(self, fname):
        """return the md5 checksum of file ``fname``
        """
        protocol,fname = self.fname(fname)
        md5 = self._md5_for_file(fname)
        return md5
    
    def fname(self, fname):
        """take a file name, return the pair (protocol, 'real' file name)
        """
        import os.path as osp
        fname = osp.expanduser(osp.expandvars(fname))

        msg = self.msg()
        
        def _normalize_uri(uri):
            if uri.startswith('/'):
                return 'file:'+uri
            return uri
        
        from urlparse import urlsplit
        url = urlsplit(_normalize_uri(fname))
        protocol = url.scheme
        def _normalize(fname):
            from posixpath import normpath
            fname = normpath(fname)
            if fname.startswith('//'): fname = fname[1:]
            return fname
        
        if protocol in ('', 'file', 'pfn'):
            protocol = ''
            fname = _normalize(url.path)

            ## hack for '/castor/cern.ch/...' paths
            if fname.startswith('/castor/'):
                protocol = 'rfio'
                fname = protocol + ':' + fname
                
        elif protocol in ('rfio', 'castor'):
            protocol = 'rfio'
            fname = _normalize(url.path)
            fname = protocol+':'+fname

        elif protocol in ('root','dcap', 'dcache'):
            #fname = fname
            pass

        elif protocol in ('gsidcap',):
            protocol = 'gfal:gsidcap'
            pass
        
        elif protocol in ('lfn','fid',):
            # percolate through the PoolFileCatalog
            from PyUtils.PoolFile import PoolFileCatalog as pfc
            fname = pfc().pfn(protocol+':'+url.path)
            pass
        
        else:
            msg.warning('unknown protocol [%s]. we\'ll just return our input',
                        protocol)
            #fname = fname
        return (protocol, fname)

    def cache(self):
        return self._cache

    def enable_pers_cache(self):
        """configure the file server to write out the persistent cache
        of inspected files.
        """
        # first disable previous cache, if any, to prevent hysteresis...
        self.disable_pers_cache()
        msg = self.msg()
        self._do_pers_cache = True
        
        import os
        fname = DEFAULT_AF_CACHE_FNAME
        if (os.path.exists(fname) and
            os.access(fname, os.R_OK)):
            msg.info('loading cache from [%s]...', fname)
            self.load_cache(fname)
        return

    def disable_pers_cache(self):
        """configure the file server to NOT write out the persistent cache
        of inspected files.
        if the persistent cache wasn't enabled, this is a no-op.
        """
        self._do_pers_cache = False
        return
    
    def _sync_pers_cache(self):
        if not self._do_pers_cache:
            return
        msg = self.msg()
        import os
        fname = DEFAULT_AF_CACHE_FNAME
        pid_fname = fname+'.%s.ascii'%os.getpid()
        msg.debug('synch-ing cache to [%s]...', fname)
        self.save_cache(pid_fname)
        if os.path.exists(pid_fname):
            # should be atomic on most FS...
            os.rename(pid_fname, fname) 
        msg.debug('synch-ing cache to [%s]... [done]', fname)

    def load_cache(self, fname=DEFAULT_AF_CACHE_FNAME):
        """load file informations from a cache file.
        the back-end (JSON, ASCII, pickle, ...) is inferred from the
        extension of the `fname` parameter.
        defaults to py-ASCII.
        """
        import os
        import os.path as osp
        msg = self.msg()
        
        ext = osp.splitext(osp.basename(fname))[1]
        if len(ext) == 0:
            # illegal file...
            msg.info('load_cache: invalid file [%s]', fname)
            return
        
        ext = ext[1:] if ext[0]=='.' else ext
        try:
            loader = getattr(self, '_load_%s_cache'%ext)
        except AttributeError:
            msg.info('load_cache: could not find a suitable backend for '
                     'extension [.%s] => using [ascii]', ext)
            loader = self._load_ascii_cache
        try:
            search_path = os.environ.get('DATAPATH',os.getcwd())
            search_path = search_path.split(os.pathsep)
            fname = _find_file(osp.expanduser(osp.expandvars(fname)),
                             search_path,
                             os.R_OK) or fname
        except ImportError:
            # not enough karma... tough luck!
            pass

        # ensure one can read that file...
        with open(fname, 'r') as file_handle:
            pass

        msg.debug('loading cache from [%s]...', fname)
        cache = loader(fname)
        self._cache.update(cache)
        msg.debug('loading cache from [%s]... [done]', fname)

    def save_cache(self, fname=DEFAULT_AF_CACHE_FNAME):
        """save file informations into a cache file.
        the back-end (JSON, ASCII, pickle, ...) is inferred from the
        extension of the `fname` parameter.
        falls back to py-ASCII.
        """
        msg = self.msg()
        import os
        if os.path.exists(fname):
            os.rename(fname, fname+'.bak')
        ext = os.path.splitext(fname)[1]
        ext = ext[1:] # drop the dot
        try:
            saver = getattr(self, '_save_%s_cache'%ext)
        except AttributeError:
            msg.info('save_cache: could not find a suitable backend for '
                     'extension [.%s] => using [ascii]', ext)
            saver = self._save_ascii_cache
        try:
            saver(fname)
        except IOError,err:
            import errno
            if err.errno != errno.EACCES:
                raise
            else:
                msg.info('could not save cache in [%s]', fname)
        except Exception,err:
            msg.warning('could not save cache into [%s]:\n%s', fname, err)
        
    def _load_pkl_cache(self, fname):
        """load file informations from pickle/shelve 'fname'"""
        try: import cPickle as pickle
        except ImportError: import pickle
        import shelve
        db = shelve.open(fname, protocol=pickle.HIGHEST_PROTOCOL)
        return db['fileinfos_cache'].copy()

    def _save_pkl_cache(self, fname):
        """save file informations into pickle/shelve 'fname'"""
        try: import cPickle as pickle
        except ImportError: import pickle
        import shelve
        db = shelve.open(fname, protocol=pickle.HIGHEST_PROTOCOL)
        db['fileinfos_cache'] = self._cache.copy()
        db.close()
        return
    
    def _load_json_cache(self, fname):
        """load file informations from a JSON file"""
        try:
            import simplejson as json
        except ImportError:
            import json
        with open(fname) as fd:
            cache = json.load(fd)
        return dict((k,AthFile.from_infos(v)) for k,v in cache)
        
    def _save_json_cache(self, fname):
        """save file informations using JSON"""
        try:
            import simplejson as json
        except ImportError:
            import json
        cache = self._cache
        with open(fname, 'w') as fd:
            json.dump([(k, cache[k].fileinfos) for k in cache],
                      fd,
                      indent=2,
                      sort_keys=True)
        return
    
    def _load_ascii_cache(self, fname):
        """load file informations from a pretty-printed python code"""
        dct = {}
        execfile(fname, dct)
        cache = dct['fileinfos']
        return dict((k,AthFile.from_infos(v)) for k,v in cache)
    
    def _save_ascii_cache(self, fname):
        """save file informations into pretty-printed python code"""
        from pprint import pprint
        cache = self._cache
        with open(fname, 'w') as fd:
            print >> fd, "# this is -*- python -*-"
            print >> fd, "# this file has been automatically generated."
            print >> fd, "fileinfos = ["
            fd.flush()
            for k in cache:
                print >> fd, "\n## new-entry"
                pprint((k, cache[k].fileinfos),
                       stream=fd,
                       width=120)
                fd.flush()
                print >> fd, ", "
            fd.flush()
            print >> fd, "]"
            print >> fd, "### EOF ###"
            
        return
    
    def flush_cache(self):
        self._cache = {}
        return

    def ftype(self, fname):
        """
        returns the type of a file ('pool' or 'bs') together with its
        canonical name

        example:
        >>> import PyUtils.AthFile as af
        >>> af.ftype ('castor:/castor/cern.ch/foo.pool')
        ('pool', 'rfio:/castor/cern.ch/foo.pool')
        
        >>> af.ftype ('LFN:ttbar.pool')
        ('pool', '/afs/cern.ch/somewhere/ttbar.pool')
        
        >>> af.ftype ('rfio:/castor/cern.ch/bs.data')
        ('bs', 'rfio:/castor/cern.ch/bs.data')
        
        >>> af.ftype ('rfio:/castor/cern.ch/bs.data')
        ('bs', 'rfio:/castor/cern.ch/bs.data')
        """
        msg = self.msg()
        import os
        import os.path as osp

        if not self.exists(fname):
            import errno
            raise IOError(errno.ENOENT, 'No such file or directory: [%s]'%fname)
        protocol,fname = self.fname(fname)

        root = self.pyroot
        _is_root_file = None
        f = self._root_open(fname)
        _is_root_file= bool(f and f.IsOpen() and 'root' in f.read(10))
        if f:
            f.Close()
            del f

        ftype = 'pool' if _is_root_file else 'bs'
        return (ftype, fname)

    def exists(self, fname):
        """helper function to test if a fiven `fname` exists.

        handles local filesystems as well as RFIO.
        usage example:
        >>> import PyUtils.AthFile as af
        >>> af.exists('/castor/cern.ch/user/b/binet/reffiles/14.1.0.x/AllBasicSamples.AOD.pool.root')
        False
        >>> af.exists('rfio:/castor/cern.ch/user/b/binet/reffiles/14.1.0.x/AllBasicSamples.AOD.pool.root')
        True
        >>> af.exists('castor:/castor/cern.ch/user/b/binet/reffiles/14.1.0.x/AllBasicSamples.AOD.pool.root')
        True
        >>> # you need a valid PoolFileCatalog.xml file for this to work:
        >>> af.exists('LFN:top_CSC-01-02-00_RDO_extract.pool')
        True
        >>> af.exists('/afs/cern.ch/atlas/offline/ReleaseData/v2/testfile/calib1_csc11.005200.T1_McAtNlo_Jimmy.digit.RDO.v12000301_tid003138._00016_extract_10evt.pool.root')
        True
        """
        import os

        msg = self.msg()

        def _root_exists(fname):
            exists = False
            f = self._root_open(fname)
            exists = f and f.IsOpen()
            if f:
                f.Close()
                del f
            return bool(exists)

        protocol,fname = self.fname(fname)

        if protocol in ('fid', 'lfn'):
            return self.exists(fname)
    
        ## elif protocol in ('dcap', 'dcache', 'gfal:gsidcap'):
        ##     ## FIXME: temporary hack. remove when ROOT bug #57409 is fixed.
        ##     if protocol == 'dcap':
        ##         fname = fname[len('dcap:'):]
        ##     elif protocol == 'dcache':
        ##         fname = fname[len('dcache:'):]
        ##     else:
        ##         pass
        ##     ## FIXME -end
        ##     return _root_exists(fname)

        else:
            return _root_exists(fname)
        # un-reachable
        return False

    pass # class AthFileServer

class FilePeeker(object):
    def __init__(self, server):
        self.server= server
        self.msg   = server.msg
        self.pyroot= server.pyroot
        
    def _is_tag_file(self, fname):
        is_tag = False
        tag_ref= None
        import PyUtils.Helpers as H
        with H.restricted_ldenviron(projects=['AtlasCore']):
            root = self.pyroot
            import re
            with H.ShutUp(filters=[
                re.compile('TClass::TClass:0: RuntimeWarning: no dictionary for class.*'),
                re.compile("Error in <T.*?File::Init>:.*? not a ROOT file")]):
                # for AttributeListLayout which uses CINT for its dict...
                root.gSystem.Load('liblcg_RootCollection')
                f = root.TFile.Open(fname)
                schema = f.Get('Schema') if f else None
                if schema:
                    is_tag  = True
                    tag_ref = schema.m_eventRefColumnName
                del schema
                if f:
                    f.Close()
                    del f
        return (is_tag, tag_ref)

    def _is_empty_pool_file(self, fname):
        is_empty = False
        import PyUtils.Helpers as H
        with H.restricted_ldenviron(projects=['AtlasCore']):
            root = self.pyroot
            import re
            with H.ShutUp(filters=[
                re.compile('TClass::TClass:0: RuntimeWarning: no dictionary for class.*'),
                re.compile("Error in <T.*?File::Init>:.*? not a ROOT file")]):
                # for AttributeListLayout which uses CINT for its dict...
                root.gSystem.Load('liblcg_RootCollection')
                f = root.TFile.Open(fname)
                payload = f.Get('CollectionTree') if f else None
                if payload:
                    is_empty = False
                else:
                    is_empty = True
                del payload

                if f:                    
                    f.Close()
                del f
        return is_empty
     
    def _process_call(self, fname, projects=['AtlasCore']):
        msg = self.msg()
        nevents = getattr(self.server, 'nevents', 1)
        import PyUtils.Helpers as H
        f = _create_file_infos()
        file_type, file_name = self.server.ftype(fname)
        import os
        
        protocol,file_name = self.server.fname(fname)
        f['file_md5sum'] = self.server.md5sum(fname)
        f['file_name'] = file_name
        f['file_type'] = file_type
        if file_type == 'pool':
            # POOL files are most nutritious when known to PoolFileCatalog.xml
            # FIXME: best would be to do that in athfile_peeker.py but
            #        athena.py closes sys.stdin when in batch, which confuses
            #        PyUtils.Cmt:subprocess.getstatusoutput
            import commands
            cmd = 'pool_insertFileToCatalog.py %s' % (file_name,)
            commands.getstatusoutput(cmd)
            #
            with H.restricted_ldenviron(projects=projects):
                is_tag, tag_ref = self._is_tag_file(file_name)
                if not is_tag:
                    import tempfile
                    #'peeker_%i.pkl' % os.getpid()
                    fd_pkl,out_pkl_fname = tempfile.mkstemp(suffix='.pkl')
                    #out_pkl_fname = 'peeked.out.pkl'
                    import os
                    os.close(fd_pkl)
                    if os.path.exists(out_pkl_fname):
                        os.remove(out_pkl_fname)
                    import AthenaCommon.ChapPy as api
                    app = api.AthenaApp()
                    app << """
                        import AthenaPoolCnvSvc.ReadAthenaPool
                        from AthenaCommon.AppMgr import ServiceMgr as svcMgr
                        svcMgr.EventSelector.InputCollections = %s
                        """ % str([file_name])
                    app << """
                        from AthenaCommon.AlgSequence import AlgSequence
                        job = AlgSequence()
                        from AthenaPython.PyAthenaComps import FilePeeker
                        job += FilePeeker('peeker')
                        # we don't really need this...
                        job.peeker.outfname='%(outfname)s'
                        job.peeker.infname='%(infname)s'

                        # metadata + taginfo
                        import IOVDbSvc.IOVDb

                        # evt-max
                        theApp.EvtMax = %(nevents)i
                        """ % {
                        'infname' : file_name,
                        'outfname': out_pkl_fname,
                        'nevents' : nevents,
                        }
                    import os
                    stdout = open('athfile-%i.log.txt' % os.getpid(), "a")
                    sc = app.run(stdout=stdout)
                    stdout.close()
                    import AthenaCommon.ExitCodes as ath_codes
                    if sc == 0:
                        #import shelve
                        import PyUtils.dbsqlite as dbsqlite
                        msg.info('extracting infos from [%s]...',
                                 out_pkl_fname)
                        db = dbsqlite.open(out_pkl_fname)
                        msg.info('keys: %s',db.keys())
                        f.update(db['fileinfos'])
                        db.close()
                        msg.info('extracting infos from [%s]... [ok]',
                                 out_pkl_fname)
                        import os
                        os.remove(stdout.name)
                    else:
                        # maybe an empty file
                        # trust but verify
                        if not self._is_empty_pool_file(file_name):
                            # actually a problem in athena !
                            import errno
                            from textwrap import dedent
                            err = dedent("""
                            %s
                            problem running chappy!
                            code: [%s (%s)]
                            what: [%s]
                            => corrupted input file ?
                            %s
                            logfile: [%s]
                            """% (":"*25,
                                  sc,errno.errorcode[sc],
                                  ath_codes.codes[sc],
                                  ":"*25,
                                  stdout.name
                                  ))
                            msg.error(err)
                            raise IOError(sc, err)
                        msg.info('athena failed to initialize.')
                        msg.info('=> probably an empty input POOL file')
                    if os.path.exists(out_pkl_fname):
                        os.remove(out_pkl_fname)
                else:
                    f['stream_names'] = ['TAG']
                # app.exit()
        else: # bytestream
            bs_fileinfos = self._process_bs_file(file_name, full_details=False)
            del bs_fileinfos['file_name']
            del bs_fileinfos['file_type']
            del bs_fileinfos['file_md5sum']
            f.update(bs_fileinfos)
                         
        return f

    def __call__(self, fname):
        import re
        import PyUtils.Helpers as H
        with H.ShutUp(filters=[re.compile('.*')]):
            try:
                f = self._process_call(fname, projects)
            except Exception,err:
                # give it another chance but with the full environment
                f = self._process_call(fname, projects=None)

        return f

    def _process_bs_file (self, fname, full_details=True):
        msg = self.msg()
        import eformat as ef

        data_reader = ef.EventStorage.pickDataReader(fname)
        assert data_reader and data_reader.good(), \
               'problem picking a data reader for file [%s]'%fname

        beam_type   = '<beam-type N/A>'
        try:
            beam_type = data_reader.beamType()
        except Exception,err:
            msg.warning ("problem while extracting beam-type information")
            pass
        beam_energy = '<beam-energy N/A>'
        try:
            beam_energy = data_reader.beamEnergy()
        except Exception,err:
            msg.warning ("problem while extracting beam-type information")
            pass

        bs = ef.istream(fname)

        file_infos = _create_file_infos()
        infos = []; _append = infos.append
        nentries = bs.total_events
        file_infos['nentries'] = nentries
        import uuid
        def _uuid():
            return str(uuid.uuid4()).upper()
        bs_metadata = {}
        for md in data_reader.freeMetaDataStrings():
            if md.startswith('Event type:'):
                k = 'evt_type'
                v = []
                if 'is sim' in md:   v.append('IS_SIMULATION')
                else:                v.append('IS_DATA')
                if 'is atlas' in md: v.append('IS_ATLAS')
                else:                v.append('IS_TESTBEAM')
                if 'is physics' in md: v.append('IS_PHYSICS')
                else:                  v.append('IS_CALIBRATION')
                bs_metadata[k] = tuple(v)
            elif '=' in md:
                k,v = md.split('=')
                bs_metadata[k] = v

        file_infos['file_guid'] = bs_metadata.get('GUID', _uuid())
        file_infos['evt_type']  = bs_metadata.get('evt_type', [])
        file_infos['bs_metadata'] = bs_metadata

        ievt = iter(bs)
        for i in xrange(1):
            try:
                evt = ievt.next()
                evt.check() # may raise a RuntimeError
                stream_tags = [dict(stream_type=tag.type,
                                    stream_name=tag.name,
                                    obeys_lbk=bool(tag.obeys_lumiblock))
                               for tag in evt.stream_tag()]
                file_infos['run_number'].append(evt.run_no())
                file_infos['evt_number'].append(evt.global_id())
                file_infos['lumi_block'].append(evt.lumi_block())
                file_infos['run_type'].append(ef.helper.run_type2string(evt.run_type()))
                file_infos['beam_type'].append(beam_type)
                file_infos['beam_energy'].append(beam_energy)
                file_infos['stream_tags'].extend(stream_tags)

            except RuntimeError, err:
                print "** WARNING ** detected a corrupted bs-file:\n",err
        """
        detailed dump how-to:
        ---------------------
        import eformat as ef
        import eformat.dump as edump
        edump.event_callback.append (('.+', edump.fullevent_handler))
        edump.dump (stream=ef.istream(fname), skip=0, total=0)
        """
        return file_infos

    pass # class FilePeeker

# register a proxy for logging.Logger instances
LoggerProxy = mp.managers.MakeProxyType(
    'LoggerProxy',
    ('debug', 'info', 'warning', 'error', 'setLevel')
    )
AthFileMgr.register('Logger', proxytype=LoggerProxy, create_method=False)

# register the AthFileServer with the manager
AthFileServerProxy = mp.managers.MakeProxyType(
    'AthFileServerProxy',
    ('msg',
     'cache', 'save_cache', 'load_cache', 'flush_cache',
     'ftype', 'exists', 'fopen',
     )
    )
AthFileServerProxy._method_to_typeid_ = {
    'msg' : 'Logger',
    }
AthFileMgr.register('Server', AthFileServer, AthFileServerProxy)


