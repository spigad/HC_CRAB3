/*author Renato Febbraro*/
/*date 3/7/2007*/
/*renato.febbraro@cern.ch*/

#ifndef TILELASERDIODE_H
#define TILELASERDIODE_H

namespace TileLaser{

class TileLaserDiode {

 public:

  int getDiodeADC() const; 
  double getDiodePedestal() const; 
  double getDiodeSigmaPedestal() const; 
  double getAlpha() const; 
  double getSigmaAlpha() const; 
  double getPedestalAlpha() const; 
  double getSigmaPedAlpha() const;


  void setDiode(const int diodeAdc, 
                const double diodePedestal, 
                const double diodeSigmaPedestal, 
                const double alpha, 
                const double sigmaAlpha,
                const double pedestalAlpha, 
                const double sigmaPedAlpha);
		
  
 private:
  
  int m_diodeADC;
  double m_diodePedestal;
  double m_diodeSigmaPedestal;
  double m_alpha;
  double m_sigmaAlpha;
  double m_pedestalAlpha;
  double m_sigmaPedAlpha;

};


  inline void TileLaserDiode::setDiode(
                                       const int diodeAdc, 
                                       const double diodePedestal, 
                                       const double diodeSigmaPedestal,
                                       const double alpha,
                                       const double sigmaAlpha,
                                       const double pedestalAlpha, 
                                       const double sigmaPedAlpha)

{ 
  m_diodeADC=diodeAdc;
  m_diodePedestal=diodePedestal;
  m_diodeSigmaPedestal=diodeSigmaPedestal;
  m_alpha=alpha;
  m_sigmaAlpha=sigmaAlpha;
  m_pedestalAlpha=pedestalAlpha;
  m_sigmaPedAlpha=sigmaPedAlpha;
 
}


inline int TileLaserDiode::getDiodeADC() const { return m_diodeADC; }
inline double TileLaserDiode::getDiodePedestal() const {return m_diodePedestal;}
inline double TileLaserDiode::getDiodeSigmaPedestal() const {return m_diodeSigmaPedestal;}
inline double TileLaserDiode::getAlpha() const {return m_alpha;}
inline double TileLaserDiode::getSigmaAlpha() const {return m_sigmaAlpha;}
inline double TileLaserDiode::getPedestalAlpha() const {return m_pedestalAlpha;}
inline double TileLaserDiode::getSigmaPedAlpha() const {return m_sigmaAlpha;}


}
#endif
