#Mon Dec 21 20:57:18 2009
"""Automatically generated. DO NOT EDIT please"""
from GaudiKernel.GaudiHandles import *
from GaudiKernel.Proxy.Configurable import *

class D3PD__egammaDeltaEmax2Alg( ConfigurableAlgorithm ) :
  __slots__ = { 
    'OutputLevel' : 0, # int
    'Enable' : True, # bool
    'ErrorMax' : 1, # int
    'ErrorCount' : 0, # int
    'AuditAlgorithms' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditReinitialize' : False, # bool
    'AuditRestart' : False, # bool
    'AuditExecute' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditBeginRun' : False, # bool
    'AuditEndRun' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'MonitorService' : 'MonitorSvc', # str
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'UserDataSvc' : ServiceHandle('UserDataSvc'), # GaudiHandle
    'UDPrefix' : 'egammaD3PDAnalysis::', # str
    'Getter' : PrivateToolHandle('D3PD::ICollectionGetterTool'), # GaudiHandle
    'HighLum' : False, # bool
  }
  _propertyDocDct = { 
    'Getter' : """ Getter instance for the input egamma objects. """,
    'HighLum' : """ True if we should use the high-lum definition of deltaEmax2. """,
    'UserDataSvc' : """ The UserDataSvc. """,
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
    'UDPrefix' : """ Prefix to add to UD labels. """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(D3PD__egammaDeltaEmax2Alg, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'egammaD3PDAnalysis'
  def getType( self ):
      return 'D3PD::egammaDeltaEmax2Alg'
  pass # class D3PD__egammaDeltaEmax2Alg

class D3PD__PhotonTruthAlg( ConfigurableAlgorithm ) :
  __slots__ = { 
    'OutputLevel' : 0, # int
    'Enable' : True, # bool
    'ErrorMax' : 1, # int
    'ErrorCount' : 0, # int
    'AuditAlgorithms' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditReinitialize' : False, # bool
    'AuditRestart' : False, # bool
    'AuditExecute' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditBeginRun' : False, # bool
    'AuditEndRun' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'MonitorService' : 'MonitorSvc', # str
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'UserDataSvc' : ServiceHandle('UserDataSvc'), # GaudiHandle
    'UDPrefix' : 'egammaD3PDAnalysis::', # str
    'TruthTool' : PrivateToolHandle('D3PD::PhotonTruthTool'), # GaudiHandle
    'PhotonGetter' : PrivateToolHandle('D3PD::ICollectionGetterTool'), # GaudiHandle
  }
  _propertyDocDct = { 
    'TruthTool' : """ Photon truth analysis tool instance. """,
    'UserDataSvc' : """ The UserDataSvc. """,
    'PhotonGetter' : """ Getter instance for the input photon objects. """,
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
    'UDPrefix' : """ Prefix to add to UD labels. """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(D3PD__PhotonTruthAlg, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'egammaD3PDAnalysis'
  def getType( self ):
      return 'D3PD::PhotonTruthAlg'
  pass # class D3PD__PhotonTruthAlg

class D3PD__PhotonTopoIsoAlg( ConfigurableAlgorithm ) :
  __slots__ = { 
    'OutputLevel' : 0, # int
    'Enable' : True, # bool
    'ErrorMax' : 1, # int
    'ErrorCount' : 0, # int
    'AuditAlgorithms' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditReinitialize' : False, # bool
    'AuditRestart' : False, # bool
    'AuditExecute' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditBeginRun' : False, # bool
    'AuditEndRun' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'MonitorService' : 'MonitorSvc', # str
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'UserDataSvc' : ServiceHandle('UserDataSvc'), # GaudiHandle
    'UDPrefix' : 'egammaD3PDAnalysis::', # str
    'PhotonGetter' : PrivateToolHandle('D3PD::ICollectionGetterTool'), # GaudiHandle
    'ClusterGetter' : PrivateToolHandle('D3PD::ICollectionGetterTool'), # GaudiHandle
  }
  _propertyDocDct = { 
    'UserDataSvc' : """ The UserDataSvc. """,
    'PhotonGetter' : """ Getter instance for the input photon objects. """,
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
    'UDPrefix' : """ Prefix to add to UD labels. """,
    'ClusterGetter' : """ Getter instance for the input topo cluster objects. """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(D3PD__PhotonTopoIsoAlg, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'egammaD3PDAnalysis'
  def getType( self ):
      return 'D3PD::PhotonTopoIsoAlg'
  pass # class D3PD__PhotonTopoIsoAlg

class D3PD__PhotonTruthTool( ConfigurableAlgTool ) :
  __slots__ = { 
    'MonitorService' : 'MonitorSvc', # str
    'OutputLevel' : 7, # int
    'AuditTools' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'Classifier' : PrivateToolHandle('egammaMCTruthClassifier'), # GaudiHandle
    'ZTruthConv' : 2800.0, # float
    'RTruthConv' : 800.0, # float
    'UseG4Particles' : False, # bool
  }
  _propertyDocDct = { 
    'Classifier' : """ Classifier tool instance. """,
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(D3PD__PhotonTruthTool, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'egammaD3PDAnalysis'
  def getType( self ):
      return 'D3PD::PhotonTruthTool'
  pass # class D3PD__PhotonTruthTool
