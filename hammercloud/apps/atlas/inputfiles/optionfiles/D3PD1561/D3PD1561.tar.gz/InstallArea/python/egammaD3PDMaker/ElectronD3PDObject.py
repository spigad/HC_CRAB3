from egammaD3PDMaker.isem_version import isem_version
import egammaD3PDMaker
import EventCommonD3PDMaker
import D3PDMakerCoreComps
from EventCommonD3PDMaker.IDHitsBlock  import IDHitsBlock
from EventCommonD3PDMaker.IDHitsBlock2 import IDHitsBlock2
from EventCommonD3PDMaker.DRAssociation import DRAssociation
from D3PDMakerCoreComps.D3PDObject import make_SGDataVector_D3PDObject
from D3PDMakerCoreComps.SimpleAssociation import SimpleAssociation
from D3PDMakerConfig.D3PDMakerFlags import D3PDMakerFlags
import PyCintex
PyCintex.loadDictionary('egammaEnumsDict')
from ROOT import egammaParameters
from ROOT import egammaPID
from RecExConfig.RecFlags import rec

ElectronD3PDObject = \
           make_SGDataVector_D3PDObject ('ElectronContainer',
                                         D3PDMakerFlags.ElectronSGKey(),
                                         'el_')


ElectronD3PDObject.defineBlock (0, 'Kinematics',
                                EventCommonD3PDMaker.FourMomFillerTool,
                                WriteE  = True,
                                WriteEt = True,
                                WriteRect = True)
ElectronD3PDObject.defineBlock (0, 'Charge',
                                EventCommonD3PDMaker.ChargeFillerTool)
ElectronD3PDObject.defineBlock (0, 'Author',
                                egammaD3PDMaker.egammaAuthorFillerTool)
ElectronD3PDObject.defineBlock (0, 'IsEM',
                                egammaD3PDMaker.egammaIsEMoneFillerTool
                                )

if rec.doTruth():
    ElectronGenPartAssoc = SimpleAssociation \
        (ElectronD3PDObject,
         egammaD3PDMaker.ElectronGenParticleAssociationTool,
         prefix = 'truth_',
         matched = 'matched',
         blockname = 'Truth')
    ElectronGenPartAssoc.defineBlock (0, 'Truth',
                                      EventCommonD3PDMaker.GenParticleFillerTool,
                                      WriteE = True,
                                      WriteM = False)
    ElectronGenPartAssoc.defineBlock (0, 'TruthBrem',
                                      EventCommonD3PDMaker.GenParticleBremFillerTool)


if isem_version() == 1:
    ElectronD3PDObject.defineBlock (0, 'IsEMCuts',
                                    egammaD3PDMaker.egammaIsEMFillerTool,
                                    IsEM  = [egammaPID.ElectronLooseOLDRel,
                                             'loose',
                                             egammaPID.ElectronMediumOLDRel,
                                             'medium',
                                             egammaPID.ElectronMediumNoIsoOLDRel,
                                             'mediumNoIso',
                                             egammaPID.ElectronTightOLDRel,
                                             'tight',
                                             egammaPID.ElectronTightTRTNoIsoOLDRel,
                                             'tightTRTNoIso',
                                             egammaPID.ElectronTightNoIsolationOLDRel,
                                             'tightNoIso',
                                    ])
else:
    ElectronD3PDObject.defineBlock (0, 'IsEMCuts',
                                    egammaD3PDMaker.egammaIsEMFillerTool,
                                    IsEM  = [egammaPID.ElectronLoose,
                                             'loose',
                                             egammaPID.ElectronMedium,
                                             'medium',
                                             egammaPID.ElectronMediumIso,
                                             'mediumIso',
                                             egammaPID.ElectronTight,
                                             'tight',
                                             egammaPID.ElectronTightIso,
                                             'tightIso',
                                    ])


ElectronD3PDObject.defineBlock (1, 'HadLeakage',
                                egammaD3PDMaker.egammaDetailFillerTool,
                                Details = [egammaParameters.ethad,
                                           'Ethad',
                                           egammaParameters.ethad1,
                                           'Ethad1',
                                           ])
ElectronD3PDObject.defineBlock (1, 'Layer1Shape',
                                egammaD3PDMaker.egammaDetailFillerTool,
                                Details = [egammaParameters.f1,
                                           'f1',
                                           egammaParameters.f1core,
                                           'f1core',
                                           egammaParameters.emins1,
                                           'Emins1',
                                           egammaParameters.fracs1,
                                           'fside',
                                           egammaParameters.e2tsts1,
                                           'Emax2',
                                           egammaParameters.weta1,
                                           'ws3',
                                           egammaParameters.wtots1,
                                           'wstot',
                                           ])
ElectronD3PDObject.defineBlock (1, 'Layer1ShapeExtra',
                                egammaD3PDMaker.egammaLayer1ExtraFillerTool)
ElectronD3PDObject.defineBlock (1, 'Layer2Shape',
                                egammaD3PDMaker.egammaDetailFillerTool,
                                Details = [egammaParameters.e233,
                                           'E233',
                                           egammaParameters.e237,
                                           'E237',
                                           egammaParameters.e277,
                                           'E277',
                                            egammaParameters.weta2,
                                           'weta2',
                                           ])
ElectronD3PDObject.defineBlock (1, 'Layer3Shape',
                                egammaD3PDMaker.egammaDetailFillerTool,
                                Details = [egammaParameters.f3,
                                           'f3',
                                           egammaParameters.f3core,
                                           'f3core',
                                           ])
ElectronD3PDObject.defineBlock (1, 'Iso',
                                egammaD3PDMaker.egammaDetailFillerTool,
                                Details = [egammaParameters.r33over37allcalo,
                                           'rphiallcalo',
                                           egammaParameters.etcone,
                                           'Etcone45',
                                           egammaParameters.etcone20,
                                           'Etcone20',
                                           egammaParameters.etcone30,
                                           'Etcone30',
                                           egammaParameters.etcone40,
                                           'Etcone40',
                                           ])
ElectronD3PDObject.defineBlock (1, 'TrkMatch',
                                egammaD3PDMaker.egammaDetailFillerTool,
                                Details = [egammaParameters.pos7,
                                           'pos7',
                                           egammaParameters.EtaCorrMag,
                                           'etacorrmag',
                                           egammaParameters.deltaEta1,
                                           'deltaeta1',
                                           egammaParameters.deltaEta2,
                                           'deltaeta2',
                                           egammaParameters.deltaPhi2,
                                           'deltaphi2',
                                    ])
ElectronD3PDObject.defineBlock (1, 'Retaphi',
                                egammaD3PDMaker.egammaRetaphiFillerTool)


ElectronD3PDObject.defineBlock (2, 'Rings',
                                egammaD3PDMaker.egammaDetailFillerTool,
    Details = [egammaParameters.etringnoisedR03Sig2,
               'EtringnoisedR03sig2',
               egammaParameters.etringnoisedR03Sig3,
               'EtringnoisedR03sig3',
               egammaParameters.etringnoisedR03Sig4,
               'EtringnoisedR03sig4',
               ])
ElectronD3PDObject.defineBlock (2, 'ElecDiscrim',
                                egammaD3PDMaker.egammaPIDFillerTool,
    PID  = [egammaPID.IsolationLikelihood_jets,
            'isolationlikelihoodjets',
            egammaPID.IsolationLikelihood_HQDelectrons,
            'isolationlikelihoodhqelectrons',
            egammaPID.ElectronWeight,
            'electronweight',
            egammaPID.BgWeight,
            'electronbgweight',
            egammaPID.SofteElectronWeight,
            'softeweight',
            egammaPID.SofteBgWeight,
            'softebgweight',
            egammaPID.NeuralNet,
            'neuralnet',
            egammaPID.Hmatrix,
            'Hmatrix',
            egammaPID.Hmatrix5,
            'Hmatrix5',
            egammaPID.AdaBoost,
            'adaboost',
            egammaPID.SofteNeuralNet,
            'softeneuralnet',
            ])
ElectronD3PDObject.defineBlock (2, 'Pointing',
                                egammaD3PDMaker.egammaDetailFillerTool,
                                Details = [egammaParameters.zvertex,
                                           'zvertex',
                                           egammaParameters.errz,
                                           'errz',
                                           egammaParameters.etap,
                                           'etap',
                                           egammaParameters.depth,
                                           'depth'
                                           ])
ElectronD3PDObject.defineBlock (2, 'Brem',
                                egammaD3PDMaker.egammaDetailFillerTool,
    Details = [egammaParameters.bremInvpT,
               'breminvpt',
               egammaParameters.bremRadius,
               'bremradius',
               egammaParameters.bremX,
               'bremx',
               egammaParameters.bremClusterRadius,
               'bremclusterradius',
               egammaParameters.bremInvpTerr,
               'breminvpterr',
               egammaParameters.bremTrackAuthor,
               'bremtrackauthor',
               egammaParameters.hasBrem,
               'hasbrem',
               egammaParameters.bremDeltaQoverP,
               'bremdeltaqoverp',
               egammaParameters.bremMaterialTraversed,
               'bremmaterialtraversed',
               ])
ElectronD3PDObject.defineBlock (2, 'RefittedTrk',
                                egammaD3PDMaker.egammaDetailFillerTool,
    Details = [egammaParameters.refittedTrack_qOverP,
               'refittedtrackqoverp',
               egammaParameters.refittedTrack_d0,
               'refittedtrackd0',
               egammaParameters.refittedTrack_z0,
               'refittedtrackz0',
               egammaParameters.refittedTrack_theta,
               'refittedtracktheta',
               egammaParameters.refittedTrack_phi0,
               'refittedtrackphi',
               ])

ElectronClusterAssoc = SimpleAssociation \
    (ElectronD3PDObject,
     egammaD3PDMaker.egammaClusterAssociationTool)
ElectronClusterAssoc.defineBlock \
    (2, 'Samplings', EventCommonD3PDMaker.ClusterEMSamplingFillerTool)
from EventCommonD3PDMaker import ClusterMomentFillerTool as CMFT
ElectronClusterAssoc.defineBlock \
    (1, 'FwdEVars', CMFT,
     Moments = [CMFT.FIRST_ENG_DENS,   'firstEdens',
                CMFT.ENG_FRAC_MAX,     'cellmaxfrac',
                CMFT.LONGITUDINAL,     'longitudinal',
                CMFT.SECOND_LAMBDA,    'secondlambda',
                CMFT.LATERAL,          'lateral',
                CMFT.SECOND_R,         'secondR',
                CMFT.CENTER_LAMBDA,    'centerlambda',
                ])


ElectronD3PDObject.defineBlock (3, 'RefittedTrkCov',
                                egammaD3PDMaker.egammaDetailFillerTool,
    Details = [egammaParameters.refittedTrack_Covd0d0,
               'refittedtrackcovd0',
               egammaParameters.refittedTrack_Covz0z0,
               'refittedtrackcovz0',
               egammaParameters.refittedTrack_Covphiphi,
               'refittedtrackcovphi',
               egammaParameters.refittedTrack_Covthetatheta,
               'refittedtrackcovtheta',
               egammaParameters.refittedTrack_CovqOverPqOverP,
               'refittedtrackcovqoverp',
               egammaParameters.refittedTrack_Covd0z0,
               'refittedtrackcovd0z0',
               egammaParameters.refittedTrack_Covz0phi,
               'refittedtrackcovz0phi',
               egammaParameters.refittedTrack_Covz0theta,
               'refittedtrackcovz0theta',
               egammaParameters.refittedTrack_Covz0qOverP,
               'refittedtrackcovz0qoverp',
               egammaParameters.refittedTrack_Covd0phi,
               'refittedtrackcovd0phi',
               egammaParameters.refittedTrack_Covd0theta,
               'refittedtrackcovd0theta',
               egammaParameters.refittedTrack_Covd0qOverP,
               'refittedtrackcovd0qoverp',
               egammaParameters.refittedTrack_Covphitheta,
               'refittedtrackcovphitheta',
               egammaParameters.refittedTrack_CovphiqOverP,
               'refittedtrackcovphiqoverp',
               egammaParameters.refittedTrack_CovthetaqOverP,
               'refittedtrackcovthetaqoverp',
               ])



ElectronTPAssoc = SimpleAssociation \
    (ElectronD3PDObject,
     egammaD3PDMaker.egammaTrackParticleAssociationTool,
     matched = 'hastrack',
     blockname = 'TrkInfo')
TrackParticlePerigeeAssoc = SimpleAssociation \
    (ElectronTPAssoc,
     EventCommonD3PDMaker.TrackParticlePerigeeAssociationTool,
     prefix = 'track')
TrackParticlePerigeeAssoc.defineBlock (1, 'Trk',
                                       EventCommonD3PDMaker.PerigeeFillerTool,
                                       WriteEta = True,
                                       WritePt = True)
TrackParticlePerigeeAssoc.defineBlock \
    (3, 'TrkCovDiag', EventCommonD3PDMaker.PerigeeCovDiagFillerTool)
TrackParticlePerigeeAssoc.defineBlock \
    (3, 'TrkCovOffDiag', EventCommonD3PDMaker.PerigeeCovOffDiagFillerTool)

ElectronTPAssoc.defineBlock (2, 'TrkFitQuality',
                             EventCommonD3PDMaker.FitQualityFillerTool,
                             prefix = 'trackfit')


ElectronTPAssoc.defineBlock (1, 'IDHits', IDHitsBlock)
ElectronTPAssoc.defineBlock (1, 'IDHits2', IDHitsBlock2)
ElectronTPAssoc.defineBlock (1, 'IDHitsExtra',
                             egammaD3PDMaker.egammaIDHitsExtraFillerTool)
ElectronTPAssoc.defineBlock (2, 'Vertex',
                             EventCommonD3PDMaker.TrackParticleVertexFillerTool)


############################################################################
# From UserData
#

if D3PDMakerFlags.HaveEgammaUserData() or D3PDMakerFlags.MakeEgammaUserData():
    ElectronD3PDObject.defineBlock \
      (1, 'UDLayer1Shape',
       D3PDMakerCoreComps.UserDataFillerTool,
       UDPrefix = D3PDMakerFlags.EgammaUserDataPrefix(),
       Vars = ['deltaEmax2', '', 'float',
               ])


############################################################################
# Jet associations
#

EleJetD3PDAssoc = DRAssociation (ElectronD3PDObject,
                                 'JetCollection',
                                 D3PDMakerFlags.JetSGKey(),
                                 0.2,
                                 'jet_',
                                 level = 2,
                                 blockname = 'JetMatch')
EleJetD3PDAssoc.defineBlock (2, 'JetKinematics',
                             EventCommonD3PDMaker.FourMomFillerTool,
                             WriteE = True)


if rec.doTruth():
    JetTruthJetD3PDAssoc = DRAssociation (EleJetD3PDAssoc,
                                          'JetCollection',
                                          D3PDMakerFlags.TruthJetSGKey(),
                                          0.2,
                                          'truth_',
                                          level = 2,
                                          blockname = 'TrueJetMatch')
    JetTruthJetD3PDAssoc.defineBlock (2, 'TrueJetKinematics',
                                      EventCommonD3PDMaker.FourMomFillerTool,
                                      WriteE = True)


############################################################################
# Trigger matching
#


if D3PDMakerFlags.DoTrigger():
    ElectronEFAssoc = SimpleAssociation \
        (ElectronD3PDObject,
         egammaD3PDMaker.egammaEFTriggerObjectAssociationTool,
         matched = 'matched',
         blockname = 'EFInfo',
         prefix = 'EF_',
         ChainPattern = 'EF_e.*')
    ElectronEFAssoc.defineBlock (1, 'EFKinematics',
                                 EventCommonD3PDMaker.FourMomFillerTool,
                                 WriteE = True,
                                 WriteEt = True,
                                 WriteM = False)
    ElectronEFAssoc.defineBlock (1, 'EFCharge',
                                 EventCommonD3PDMaker.ChargeFillerTool)
    ElectronEFAssoc.defineBlock (1, 'EFHadLeakage',
                                 egammaD3PDMaker.egammaDetailFillerTool,
                                 Details = [egammaParameters.ethad,
                                            'Ethad',
                                            egammaParameters.ethad1,
                                            'Ethad1',
                                            ])
    ElectronEFAssoc.defineBlock (1, 'EFLayer1Shape',
                                 egammaD3PDMaker.egammaDetailFillerTool,
                                 Details = [egammaParameters.f1,
                                            'f1',
                                            egammaParameters.emins1,
                                            'Emins1',
                                            egammaParameters.fracs1,
                                            'fside',
                                            egammaParameters.e2tsts1,
                                            'Emax2',
                                            egammaParameters.weta1,
                                            'ws3',
                                            egammaParameters.wtots1,
                                            'wstot',
                                            ])
    ElectronEFAssoc.defineBlock (1, 'EFLayer2Shape',
                                 egammaD3PDMaker.egammaDetailFillerTool,
                                 Details = [egammaParameters.e233,
                                            'E233',
                                            egammaParameters.e237,
                                            'E237',
                                            egammaParameters.e277,
                                            'E277',
                                            egammaParameters.weta2,
                                            'weta2',
                                            ])
    ElectronEFAssoc.defineBlock (1, 'EFIso',
                                 egammaD3PDMaker.egammaDetailFillerTool,
                                 Details = [egammaParameters.r33over37allcalo,
                                            'rphiallcalo',
                                            ])
    ElectronEFAssoc.defineBlock (1, 'EFTrkMatch',
                                 egammaD3PDMaker.egammaDetailFillerTool,
                                 Details = [egammaParameters.deltaEta1,
                                            'deltaeta1',
                                            egammaParameters.deltaEta2,
                                            'deltaeta2',
                                            egammaParameters.deltaPhi2,
                                            'deltaphi2',
                                        ])

    ElectronEFAssoc.defineBlock (2, 'EFIso2',
                                 egammaD3PDMaker.egammaDetailFillerTool,
                                 Details = [egammaParameters.etcone,
                                            'Etcone45',
                                            egammaParameters.etcone20,
                                            'Etcone20',
                                            egammaParameters.etcone30,
                                            'Etcone30',
                                            egammaParameters.etcone40,
                                            'Etcone40',
                                            ])
    ElectronEFAssoc.defineBlock (2, 'EFTrkMatch2',
                                 egammaD3PDMaker.egammaDetailFillerTool,
                                 Details = [egammaParameters.EtaCorrMag,
                                            'etacorrmag',
                                        ])
    ElectronEFAssoc.defineBlock (2, 'EFPointing',
                                 egammaD3PDMaker.egammaDetailFillerTool,
                                 Details = [egammaParameters.zvertex,
                                            'zvertex',
                                            egammaParameters.errz,
                                            'errz',
                                            ])

    ElectronEFTPAssoc = SimpleAssociation \
        (ElectronEFAssoc,
         egammaD3PDMaker.egammaTrackParticleAssociationTool,
         matched = 'hastrack',
         blockname = 'EFTrkInfo')
    EFTrackParticlePerigeeAssoc = SimpleAssociation \
        (ElectronEFTPAssoc,
         EventCommonD3PDMaker.TrackParticlePerigeeAssociationTool,
         prefix = 'track')
    EFTrackParticlePerigeeAssoc.defineBlock (1, 'EFTrk',
                                           EventCommonD3PDMaker.PerigeeFillerTool,
                                           WriteEta = True,
                                           WritePt = True)
    ElectronEFTPAssoc.defineBlock (1, 'EFIDHitsExtra',
                                 egammaD3PDMaker.egammaIDHitsExtraFillerTool)
    ElectronEFTPAssoc.defineBlock (1, 'EFIDHits', IDHitsBlock)


    ElectronL2Assoc = SimpleAssociation \
        (ElectronD3PDObject,
         egammaD3PDMaker.ElectronL2TriggerObjectAssociationTool,
         matched = 'matched',
         blockname = 'L2Info',
         prefix = 'L2_')
    ElectronL2Assoc.defineBlock (1, 'L2Kinematics',
                                 EventCommonD3PDMaker.FourMomFillerTool,
                                 WriteE = True,
                                 WriteEt = True,
                                 WriteM = False)
    ElectronL2Assoc.defineBlock (1, 'L2Charge',
                                 egammaD3PDMaker.TrigElectronChargeFillerTool)
    ElectronL2Assoc.defineBlock (1, 'L2Calo1',
                                 egammaD3PDMaker.TrigElectronCalo1FillerTool)
    ElectronL2Assoc.defineBlock (1, 'L2Track1',
                                 egammaD3PDMaker.TrigElectronTrack1FillerTool)
    ElectronL2Assoc.defineBlock (2, 'L2Track2',
                                 egammaD3PDMaker.TrigElectronTrack2FillerTool)
    ElectronL2ClusAssoc = SimpleAssociation \
       (ElectronL2Assoc,
        egammaD3PDMaker.TrigElectronClusterAssociationTool)
    ElectronL2ClusAssoc.defineBlock (2, 'L2Clus2',
                                     egammaD3PDMaker.TrigEMClusterVarsFillerTool)


    ElectronL1Assoc = SimpleAssociation \
        (ElectronD3PDObject,
         egammaD3PDMaker.egammaL1TriggerObjectAssociationTool,
         matched = 'matched',
         blockname = 'L1Info',
         prefix = 'L1_')
    ElectronL1Assoc.defineBlock (1, 'L1Kinematics',
                                 EventCommonD3PDMaker.FourMomFillerTool,
                                 WriteEt = True,
                                 WriteM = False)
    ElectronL1Assoc.defineBlock (1, 'L1Isol',
                                 egammaD3PDMaker.EmTau_ROIIsoFillerTool)
