#/////////////////////////////////////
#
#    Haifeng Li <Haifeng.Li@cern.ch>
#    13 Aug. 2009
#
#/////////////////////////////////////


from egammaD3PDMaker.isem_version import isem_version
import egammaD3PDMaker
import EventCommonD3PDMaker
import D3PDMakerCoreComps
from EventCommonD3PDMaker.DRAssociation import DRAssociation
from D3PDMakerCoreComps.D3PDObject import make_SGDataVector_D3PDObject
from D3PDMakerCoreComps.SimpleAssociation import SimpleAssociation
from D3PDMakerConfig.D3PDMakerFlags import D3PDMakerFlags
import PyCintex
PyCintex.loadDictionary('egammaEnumsDict')
from ROOT import egammaParameters
from ROOT import egammaPID
from RecExConfig.RecFlags import rec


PhotonD3PDObject = \
           make_SGDataVector_D3PDObject ('PhotonContainer',
                                         D3PDMakerFlags.PhotonSGKey(),
                                         'ph_')


PhotonD3PDObject.defineBlock (0, 'Kinematics',
                              EventCommonD3PDMaker.FourMomFillerTool,
                              WriteE  = True,
                              WriteEt = True,
                              WriteRect = True)
PhotonD3PDObject.defineBlock (0, 'Author',
                              egammaD3PDMaker.egammaAuthorFillerTool,
                              RecoveredFlag = True)
PhotonD3PDObject.defineBlock (0, 'IsEM',
                              egammaD3PDMaker.egammaIsEMoneFillerTool
                              )
PhotonD3PDObject.defineBlock (0, 'Conversion0',
                              egammaD3PDMaker.egammaConversion0FillerTool,
                              )

if rec.doTruth():
    PhotonGenPartAssoc = SimpleAssociation \
        (PhotonD3PDObject,
         egammaD3PDMaker.PhotonGenParticleAssociationTool,
         prefix = 'truth_',
         matched = 'matched',
         blockname = 'Truth',
         DRVar = 'deltaRRecPhoton')
    PhotonGenPartAssoc.defineBlock (0, 'Truth',
                                    EventCommonD3PDMaker.GenParticleFillerTool,
                                    WriteE = True,
                                    WriteM = False)


if isem_version() == 1:
    PhotonD3PDObject.defineBlock (0, 'IsEMCuts',
                                  egammaD3PDMaker.egammaIsEMFillerTool,
                                  IsEM  = [egammaPID.PhotonTightOLDRel,
                                           'tight',
                                           ])
else:
    PhotonD3PDObject.defineBlock (0, 'IsEMCuts',
                                  egammaD3PDMaker.egammaIsEMFillerTool,
                                  IsEM  = [egammaPID.PhotonLoose,
                                           'loose',
                                           egammaPID.PhotonTight,
                                           'tight',
                                           egammaPID.PhotonTightIso,
                                           'tightIso',
                                           ])


PhotonD3PDObject.defineBlock (1, 'HadLeakage',
                                egammaD3PDMaker.egammaDetailFillerTool,
                                Details = [egammaParameters.ethad,
                                           'Ethad',
                                           egammaParameters.ethad1,
                                           'Ethad1',
                                           ])
PhotonD3PDObject.defineBlock (1, 'Layer0Shape',
                              egammaD3PDMaker.egammaDetailFillerTool,
                              Details = [egammaParameters.e033,
                                         'E033'
                                         ])
PhotonD3PDObject.defineBlock (1, 'Layer1Shape',
                                egammaD3PDMaker.egammaDetailFillerTool,
                                Details = [egammaParameters.f1,
                                           'f1',
                                           egammaParameters.f1core,
                                           'f1core',
                                           egammaParameters.emins1,
                                           'Emins1',
                                           egammaParameters.fracs1,
                                           'fside',
                                           egammaParameters.e2tsts1,
                                           'Emax2',
                                           egammaParameters.weta1,
                                           'ws3',
                                           egammaParameters.wtots1,
                                           'wstot',
                                           egammaParameters.e132,
                                           'E132',
                                           egammaParameters.e1152,
                                           'E1152',
                                           ])
PhotonD3PDObject.defineBlock (1, 'Layer1ShapeExtra',
                              egammaD3PDMaker.egammaLayer1ExtraFillerTool)
PhotonD3PDObject.defineBlock (1, 'Layer2Shape',
                                egammaD3PDMaker.egammaDetailFillerTool,
                                Details = [egammaParameters.e233,
                                           'E233',
                                           egammaParameters.e237,
                                           'E237',
                                           egammaParameters.e277,
                                           'E277',
                                            egammaParameters.weta2,
                                           'weta2',
                                           ])
PhotonD3PDObject.defineBlock (1, 'Layer3Shape',
                                egammaD3PDMaker.egammaDetailFillerTool,
                                Details = [egammaParameters.f3,
                                           'f3',
                                           egammaParameters.f3core,
                                           'f3core',
                                           ])
PhotonD3PDObject.defineBlock (1, 'Iso',
                                egammaD3PDMaker.egammaDetailFillerTool,
                                Details = [egammaParameters.r33over37allcalo,
                                           'rphiallcalo',
                                           egammaParameters.etcone,
                                           'Etcone45',
                                           egammaParameters.etcone20,
                                           'Etcone20',
                                           egammaParameters.etcone30,
                                           'Etcone30',
                                           egammaParameters.etcone40,
                                           'Etcone40',
                                           ])
PhotonD3PDObject.defineBlock (1, 'ConvFlags',
                                egammaD3PDMaker.egammaDetailFillerTool,
                                Details = [egammaParameters.convAngleMatch,
                                           'convanglematch',
                                           egammaParameters.convTrackMatch,
                                           'convtrackmatch',
                                           ])
PhotonD3PDObject.defineBlock (1, 'Conversion',
                              egammaD3PDMaker.egammaConversionFillerTool)
PhotonD3PDObject.defineBlock (1, 'Retaphi',
                              egammaD3PDMaker.egammaRetaphiFillerTool)
                                           


PhotonD3PDObject.defineBlock (2, 'Rings',
                                egammaD3PDMaker.egammaDetailFillerTool,
    Details = [egammaParameters.etringnoisedR03Sig2,
               'EtringnoisedR03sig2',
               egammaParameters.etringnoisedR03Sig3,
               'EtringnoisedR03sig3',
               egammaParameters.etringnoisedR03Sig4,
               'EtringnoisedR03sig4',
               ])
PhotonD3PDObject.defineBlock (2, 'PhotDiscrim',
                              egammaD3PDMaker.egammaPIDFillerTool,
    PID  = [egammaPID.IsolationLikelihood_jets,
            'isolationlikelihoodjets',
            egammaPID.IsolationLikelihood_HQDelectrons,
            'isolationlikelihoodhqelectrons',
            egammaPID.PhotonWeight,
            'loglikelihood',
            egammaPID.PhotonWeight,
            'photonweight',
            egammaPID.BgPhotonWeight,
            'photonbgweight',
            egammaPID.NeuralNet,
            'neuralnet',
            egammaPID.Hmatrix,
            'Hmatrix',
            egammaPID.Hmatrix5,
            'Hmatrix5',
            egammaPID.AdaBoost,
            'adaboost',
            ])
PhotonD3PDObject.defineBlock (2, 'Pointing',
                                egammaD3PDMaker.egammaDetailFillerTool,
                                Details = [egammaParameters.zvertex,
                                           'zvertex',
                                           egammaParameters.errz,
                                           'errz',
                                           egammaParameters.etap,
                                           'etap',
                                           egammaParameters.depth,
                                           'depth'
                                           ])

PhotonClusterAssoc = SimpleAssociation \
    (PhotonD3PDObject,
     egammaD3PDMaker.egammaClusterAssociationTool)
PhotonClusterAssoc.defineBlock \
    (2, 'Samplings', EventCommonD3PDMaker.ClusterEMSamplingFillerTool)


############################################################################
# From UserData
#

if D3PDMakerFlags.HaveEgammaUserData() or D3PDMakerFlags.MakeEgammaUserData():
    if rec.doTruth():
        PhotonD3PDObject.defineBlock \
          (0, 'UDTruthFlags',
           D3PDMakerCoreComps.UserDataFillerTool,
           UDPrefix = D3PDMakerFlags.EgammaUserDataPrefix(),
           Vars = ['truth_isConv',               '', 'bool',
                   'truth_isBrem',               '', 'bool',
                   'truth_isFromHardProc',       '', 'bool',
                   'truth_isPhotonFromHardProc', '', 'bool',
                   ])

        PhotonD3PDObject.defineBlock \
          (1, 'UDTruthConv',
           D3PDMakerCoreComps.UserDataFillerTool,
           UDPrefix = D3PDMakerFlags.EgammaUserDataPrefix(),
           Vars = ['truth_Rconv', '', 'float',
                   'truth_zconv', '', 'float'
                   ])

    PhotonD3PDObject.defineBlock \
      (1, 'UDLayer1Shape',
       D3PDMakerCoreComps.UserDataFillerTool,
       UDPrefix = D3PDMakerFlags.EgammaUserDataPrefix(),
       Vars = ['deltaEmax2', '', 'float',
               ])

    PhotonD3PDObject.defineBlock \
      (2, 'UDTopoCones',
       D3PDMakerCoreComps.UserDataFillerTool,
       UDPrefix = D3PDMakerFlags.EgammaUserDataPrefix(),
       Vars = ['topoEtcone20', '', 'float',
               'topoEtcone40', '', 'float',
               'topoEtcone60', '', 'float',
               ])



############################################################################
# Jet associations
#

PhotonJetD3PDAssoc = DRAssociation (PhotonD3PDObject,
                                    'JetCollection',
                                    D3PDMakerFlags.JetSGKey(),
                                    0.2,
                                    'jet_',
                                    level = 2,
                                    blockname = 'JetMatch')
PhotonJetD3PDAssoc.defineBlock (2, 'JetKinematics',
                                EventCommonD3PDMaker.FourMomFillerTool,
                                WriteE = True)


if rec.doTruth():
    JetTruthJetD3PDAssoc = DRAssociation (PhotonJetD3PDAssoc,
                                          'JetCollection',
                                          D3PDMakerFlags.TruthJetSGKey(),
                                          0.2,
                                          'truth_',
                                          level = 2,
                                          blockname = 'TrueJetMatch')
    JetTruthJetD3PDAssoc.defineBlock (2, 'TrueJetKinematics',
                                      EventCommonD3PDMaker.FourMomFillerTool,
                                      WriteE = True)




############################################################################
# Topo cluster associations.
#


PhotonTopoD3PDAssoc = DRAssociation (PhotonD3PDObject,
                                     'CaloClusterContainer',
                                     D3PDMakerFlags.ClusterSGKey(),
                                     0.1,
                                     'topo',
                                     level = 2,
                                     blockname = 'TopoMatch')
PhotonTopoD3PDAssoc.defineBlock (2, 'TopoKinematics',
                                 EventCommonD3PDMaker.FourMomFillerTool,
                                 WriteM = False)

PhotonTopoEMD3PDAssoc = DRAssociation (PhotonD3PDObject,
                                       'CaloClusterContainer',
                                       D3PDMakerFlags.EMTopoClustSGKey(),
                                       0.1,
                                       'topoEM',
                                       level = 2,
                                       blockname = 'TopoEMMatch')
PhotonTopoEMD3PDAssoc.defineBlock (2, 'TopoEMKinematics',
                                   EventCommonD3PDMaker.FourMomFillerTool,
                                   WriteM = False)


############################################################################
# Trigger matching
#

if D3PDMakerFlags.DoTrigger():
    PhotonEFAssoc = SimpleAssociation \
        (PhotonD3PDObject,
         egammaD3PDMaker.egammaEFTriggerObjectAssociationTool,
         matched = 'matched',
         blockname = 'EFInfo',
         prefix = 'EF_',
         ChainPattern = 'EF_g.*')
    PhotonEFAssoc.defineBlock (1, 'EFKinematics',
                                 EventCommonD3PDMaker.FourMomFillerTool,
                                 WriteE = True,
                                 WriteEt = True,
                                 WriteM = False)
    PhotonEFAssoc.defineBlock (1, 'EFHadLeakage',
                                 egammaD3PDMaker.egammaDetailFillerTool,
                                 Details = [egammaParameters.ethad,
                                            'Ethad',
                                            egammaParameters.ethad1,
                                            'Ethad1',
                                            ])
    PhotonEFAssoc.defineBlock (1, 'EFLayer1Shape',
                                 egammaD3PDMaker.egammaDetailFillerTool,
                                 Details = [egammaParameters.f1,
                                            'f1',
                                            egammaParameters.emins1,
                                            'Emins1',
                                            egammaParameters.fracs1,
                                            'fside',
                                            egammaParameters.e2tsts1,
                                            'Emax2',
                                            egammaParameters.weta1,
                                            'ws3',
                                            egammaParameters.wtots1,
                                            'wstot',
                                            ])
    PhotonEFAssoc.defineBlock (1, 'EFLayer2Shape',
                                 egammaD3PDMaker.egammaDetailFillerTool,
                                 Details = [egammaParameters.e233,
                                            'E233',
                                            egammaParameters.e237,
                                            'E237',
                                            egammaParameters.e277,
                                            'E277',
                                            egammaParameters.weta2,
                                            'weta2',
                                            ])
    PhotonEFAssoc.defineBlock (1, 'EFIso',
                                 egammaD3PDMaker.egammaDetailFillerTool,
                                 Details = [egammaParameters.r33over37allcalo,
                                            'rphiallcalo',
                                            ])

    PhotonEFAssoc.defineBlock (2, 'EFIso2',
                                 egammaD3PDMaker.egammaDetailFillerTool,
                                 Details = [egammaParameters.etcone,
                                            'Etcone45',
                                            egammaParameters.etcone20,
                                            'Etcone20',
                                            egammaParameters.etcone30,
                                            'Etcone30',
                                            egammaParameters.etcone40,
                                            'Etcone40',
                                            ])
    PhotonEFAssoc.defineBlock (2, 'EFPointing',
                               egammaD3PDMaker.egammaDetailFillerTool,
                               Details = [egammaParameters.zvertex,
                                          'zvertex',
                                          egammaParameters.errz,
                                          'errz',
                                          ])



    PhotonL2Assoc = SimpleAssociation \
        (PhotonD3PDObject,
         egammaD3PDMaker.PhotonL2TriggerObjectAssociationTool,
         matched = 'matched',
         blockname = 'L2Info',
         prefix = 'L2_')
    PhotonL2Assoc.defineBlock (1, 'L2Kinematics',
                               EventCommonD3PDMaker.FourMomFillerTool,
                               WriteE = True,
                               WriteEt = True,
                               WriteM = False)
    PhotonL2Assoc.defineBlock (1, 'L2Calo1',
                               egammaD3PDMaker.TrigPhotonCalo1FillerTool)
    PhotonL2ClusAssoc = SimpleAssociation \
       (PhotonL2Assoc,
        egammaD3PDMaker.TrigPhotonClusterAssociationTool)
    PhotonL2ClusAssoc.defineBlock (2, 'L2Clus2',
                                   egammaD3PDMaker.TrigEMClusterVarsFillerTool)

    PhotonL1Assoc = SimpleAssociation \
        (PhotonD3PDObject,
         egammaD3PDMaker.egammaL1TriggerObjectAssociationTool,
         matched = 'matched',
         blockname = 'L1Info',
         prefix = 'L1_')
    PhotonL1Assoc.defineBlock (1, 'L1Kinematics',
                               EventCommonD3PDMaker.FourMomFillerTool,
                               WriteEt = True,
                               WriteM = False)
    PhotonL1Assoc.defineBlock (1, 'L1Isol',
                               egammaD3PDMaker.EmTau_ROIIsoFillerTool)
