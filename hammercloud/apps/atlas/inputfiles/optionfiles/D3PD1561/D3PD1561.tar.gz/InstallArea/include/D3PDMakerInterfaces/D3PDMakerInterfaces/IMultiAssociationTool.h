// This file's extension implies that it's C, but it's really -*- C++ -*-.
// $Id$
/**
 * @file D3PDMakerInterfaces/IMultiAssociationTool.h
 * @author scott snyder <snyder@bnl.gov>
 * @date Jul, 2009
 * @brief Abstract interface to form a multi-way association.
 */

#ifndef D3PDMAKERINTERFACES_IMULTIASSOCIATIONTOOL_H
#define D3PDMAKERINTERFACES_IMULTIASSOCIATIONTOOL_H


#include "GaudiKernel/IAlgTool.h"
#include <typeinfo>


namespace D3PD {


class IAddVariable;


/// Interface definition.
static const InterfaceID
IID_IMultiAssociationTool ("D3PD::IMultiAssociationTool", 1, 0);


/**
 * @brief Abstract interface to form a multi-way association.
 *
 * This tool forms a multiple association.  That is, it associates
 * from a single object to a collection of objects.  The interface
 * is similar to @c ICollectionGetterTool, except that the @c reset
 * method takes a pointer to the source object for the association.
 * @c next then iterates over the association results.
 */
class IMultiAssociationTool
  : virtual public IAlgTool
{
public:
  /// Gaudi interface definition.
  static const InterfaceID& interfaceID()
  { return IID_IMultiAssociationTool; }


  /**
   * @brief Configure during initialization: type-check.
   * @param tree Our parent for tuple making.
   * @param ti Gives the type of the object being passed to @c resetUntyped.
   *
   * @c configure should check that the type of the object coming as input
   * (to @c resetUntyped)
   * is compatible with what it expects, and raise an error otherwise.
   */
  virtual StatusCode configure (IAddVariable* tree,
                                const std::type_info& ti) = 0;


  /**
   * @brief Declare tuple variables.
   *
   * This is called at the start of the first event.
   */
  virtual StatusCode book() = 0;


  /**
   * @brief Return the element type for the target of the association.
   *
   * I.e., @c nextUntyped returns a pointer to this type.
   */
  virtual const std::type_info& elementTypeinfo() const = 0;


  /**
   * @brief Start the iteration for a new association.
   * @param p The object from which to associate.
   */
  virtual StatusCode resetUntyped (const void* p) = 0;


  /**
   * @brief Return a pointer to the next element in the association.
   *
   * Return 0 when the association has been exhausted.
   */
  virtual const void* nextUntyped() = 0;
};


} // namespace D3PD


#endif // not D3PDMAKERINTERFACES_IMULTIASSOCIATIONTOOL_H
