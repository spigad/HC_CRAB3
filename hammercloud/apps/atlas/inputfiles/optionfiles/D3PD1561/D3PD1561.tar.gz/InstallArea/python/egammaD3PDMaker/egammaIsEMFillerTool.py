from egammaD3PDMaker import egammaD3PDMakerConf



class egammaIsEMFillerTool (egammaD3PDMakerConf.D3PD__egammaIsEMFillerTool):
    def __init__ (self,
                  name,
                  IsEM = [],
                  **kwargs):
        IsEM = [str(x) for x in IsEM]
        egammaD3PDMakerConf.D3PD__egammaIsEMFillerTool.__init__ (self,
                                                                 name,
                                                                 IsEM = IsEM,
                                                                 **kwargs)
        
