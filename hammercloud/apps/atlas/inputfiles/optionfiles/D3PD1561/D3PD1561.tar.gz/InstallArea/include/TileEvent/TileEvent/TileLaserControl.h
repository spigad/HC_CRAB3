/*author Renato Febbraro*/
/*date 3/7/2007*/
/*modified 27/5/2008 transfer PLC methods in a new class*/
/*renato.febbraro@cern.ch*/

#ifndef TILELASERCONTROL_H
#define TILELASERCONTROL_H

#include <time.h>

namespace TileLaser {

  class TileLaserControl {

  public:
    
    double getPumpDiodeTemp() const;
    int getTimeLastMeasP() const;
    double getDiodeBoxTemp() const;
    int getTimeLastMeasD() const;
    double getGasFlux() const;
    int getTimeLastMeasF() const;
    double getHumidity() const;
    int getTimeLastMeasH() const;
    time_t getLastPedMeas() const;
    time_t getLastAlphaMeas() const;

    void setControl(const double pumpDiodeTemp, 
                  const int timeLastMeasP, 
                  const double diodeBoxTemp, 
		  const int timeLastMeasD,
                  const double gasFlux, 
		  const int timeLastMeasF,
                  const double humidity, 
		  const int timeLastMeasH,
                  const time_t lastPedMeas,
		  const time_t lastAlphaMeas );

    
  private:
    
    double m_pumpDiodeTemp;
    int m_timeLastMeasP;
    double m_diodeBoxTemp;
    int m_timeLastMeasD;
    double m_gasFlux;
    int m_timeLastMeasF;
    double m_humidity;
    int m_timeLastMeasH;
    time_t m_lastPedMeas;
    time_t m_lastAlphaMeas;
    
  };

 inline void TileLaserControl::setControl(const double pumpDiodeTemp, 
					  const int timeLastMeasP, 
					  const double diodeBoxTemp,
					  const int timeLastMeasD, 
					  const double gasFlux,
					  const int timeLastMeasF, 
					  const double humidity, 
					  const int timeLastMeasH, 
      					  const time_t lastPedMeas,
					  const time_t lastAlphaMeas) 
 
  {
    m_pumpDiodeTemp=pumpDiodeTemp;
    m_timeLastMeasP=timeLastMeasP;
    m_diodeBoxTemp=diodeBoxTemp;
    m_timeLastMeasD=timeLastMeasD;
    m_gasFlux=gasFlux;
    m_timeLastMeasF=timeLastMeasF;
    m_humidity=humidity;
    m_timeLastMeasH=timeLastMeasH;
    m_lastPedMeas=lastPedMeas;
    m_lastAlphaMeas=lastAlphaMeas;
    
 }

inline double TileLaserControl::getPumpDiodeTemp() const {return m_pumpDiodeTemp;}
inline int TileLaserControl::getTimeLastMeasP() const {return m_timeLastMeasP;}
inline double TileLaserControl::getDiodeBoxTemp() const {return m_diodeBoxTemp;}
inline int TileLaserControl::getTimeLastMeasD() const {return m_timeLastMeasD;}
inline double TileLaserControl::getGasFlux() const {return m_gasFlux;}
inline int TileLaserControl::getTimeLastMeasF() const {return m_timeLastMeasF;}
inline double TileLaserControl::getHumidity() const {return m_humidity;}
inline int TileLaserControl::getTimeLastMeasH() const {return m_timeLastMeasH;}
inline time_t TileLaserControl::getLastPedMeas() const {return m_lastPedMeas;}
inline time_t TileLaserControl::getLastAlphaMeas() const {return m_lastAlphaMeas;}
}


#endif

  
