/*author Renato Febbraro*/
/*date 3/7/2007*/
/*renato.febbraro@cern.ch*/

#ifndef TILELASERPMT_H
#define TILELASERPMT_H

namespace TileLaser{

class TileLaserPmt {

 public:

  int getPMADC() const;
  int getTDC() const;
  double getPMPedestal() const;
  double getPMSigmaPedestal() const;
  

  void setPmt(const int pmAdc, 
	      const int tdc, 
	      const double pmPedestal, 
	      const double pmSigmaPedestal);

 private:

  int m_PMADC;
  int m_TDC;
  double m_pmPedestal;
  double m_pmSigmaPedestal;
 
};


  inline void TileLaserPmt::setPmt(const int pmAdc, 
                                   const int tdc, 
                                   const double pmPedestal, 
                                   const double pmSigmaPedestal)
{
  m_PMADC=pmAdc;
  m_TDC=tdc;
  m_pmPedestal=pmPedestal;
  m_pmSigmaPedestal=pmSigmaPedestal;
 
}

inline int TileLaserPmt::getPMADC() const {return m_PMADC;}
inline int TileLaserPmt::getTDC() const {return m_TDC;}
inline double TileLaserPmt::getPMPedestal() const {return m_pmPedestal;}
inline double TileLaserPmt::getPMSigmaPedestal() const {return m_pmSigmaPedestal;}

}
#endif
