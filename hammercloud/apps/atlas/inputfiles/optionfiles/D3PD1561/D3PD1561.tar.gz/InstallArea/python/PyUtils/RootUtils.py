# @file PyUtils.RootUtils
# @author Sebastien Binet
# @purpose a few utils to ease the day-to-day work with ROOT
# @date November 2009

from __future__ import with_statement

__doc__ = "a few utils to ease the day-to-day work with ROOT"
__version__ = "$Revision: 228792 $"
__author__ = "Sebastien Binet"

__all__ = [
    'import_root',
    'root_compile',
    ]

### imports -------------------------------------------------------------------
from .Decorators import memoize

### functions -----------------------------------------------------------------
def import_root(batch=True):
    """a helper method to wrap the 'import ROOT' statement to prevent ROOT
    from screwing up the display or loading graphics libraries when in batch
    mode (which is the default.)

    e.g.
    >>> ROOT = import_root(batch=True)
    >>> f = ROOT.TFile.Open(...)
    """
    import sys
    if batch:
        sys.argv.insert(1, '-b')
    import ROOT
    ROOT.gROOT.SetBatch(batch)
    if batch:
        del sys.argv[1]
    import PyCintex
    PyCintex.Cintex.Enable()
    return ROOT

def root_compile(src=None, fname=None, batch=True):
    """a helper method to compile a set of C++ statements (via ``src``) or
    a C++ file (via ``fname``) via ACLiC
    """
    if src is not None and fname is not None:
        raise ValueError("'src' xor 'fname' should be not None, *not* both")

    if src is None and fname is None:
        raise ValueError("'src' xor 'fname' should be None, *not* both")

    import os
    from .Helpers import ShutUp as root_shutup
    
    ROOT = import_root(batch=batch)
    compile_options = "f"
    if 'dbg' in os.environ.get('CMTCONFIG', 'opt'):
        compile_options += 'g'
    else:
        compile_options += 'O'

    src_file = None
    if src:
        import textwrap
        import tempfile
        src_file = tempfile.NamedTemporaryFile(prefix='root_aclic_',
                                               suffix='.cxx')
        src_file.write(textwrap.dedent(src))
        src_file.flush()
        src_file.seek(0)
        fname = src_file.name
        pass

    elif fname:
        import os.path as osp
        fname = osp.expanduser(osp.expandvars(fname))
        pass
        
    assert os.access(fname, os.R_OK), "could not read [%s]"%(fname,)
    orig_root_lvl = ROOT.gErrorIgnoreLevel
    ROOT.gErrorIgnoreLevel = ROOT.kWarning
    try:
        with root_shutup():
            sc = ROOT.gSystem.CompileMacro(fname, compile_options)
        if sc == ROOT.kFALSE:
            raise RuntimeError(
                'problem compiling ROOT macro (rc=%s)'%(sc,)
                )
    finally:
        ROOT.gErrorIgnoreLevel = orig_root_lvl
    return
        
@memoize
def _pythonize_tfile():
    import PyCintex; PyCintex.Cintex.Enable()
    root = import_root()
    PyCintex.loadDict("RootUtilsPyROOTDict")
    rootutils = getattr(root, "RootUtils")
    pybytes = getattr(rootutils, "PyBytes")
    read_root_file = getattr(rootutils, "_pythonize_read_root_file")
    tell_root_file = getattr(rootutils, "_pythonize_tell_root_file")
    def read(self, size=-1):
        """read([size]) -> read at most size bytes, returned as a string.

        If the size argument is negative or omitted, read until EOF is reached.
        Notice that when in non-blocking mode, less data than what was requested
        may be returned, even if no size parameter was given.

        FIXME: probably doesn't follow python file-like conventions...
        """
        SZ = 4096
        
        if size>=0:
            #size = _adjust_sz(size)
            #print "-->0",self.tell(),size
            c_buf = read_root_file(self, size)
            if c_buf and c_buf.sz:
                #print "-->1",self.tell(),c_buf.sz
                #self.seek(c_buf.sz+self.tell())
                #print "-->2",self.tell()
                buf = c_buf.buffer()
                buf.SetSize(c_buf.sz)
                return str(buf[:])
            return ''
        else:
            size = SZ
            out = []
            while True:
                #size = _adjust_sz(size)
                c_buf = read_root_file(self, size)
                if c_buf and c_buf.sz:
                    buf = c_buf.buffer()
                    buf.SetSize(c_buf.sz)
                    out.append(str(buf[:]))
                else:
                    break
            return ''.join(out)
    root.TFile.read = read
    del read
    
    root.TFile.seek = root.TFile.Seek
    root.TFile.tell = lambda self: tell_root_file(self)
    ## import os
    ## def tell(self):
    ##     fd = os.dup(self.GetFd())
    ##     return os.fdopen(fd).tell()
    ## root.TFile.tell = tell
    ## del tell
    return 


### test support --------------------------------------------------------------
def _test_main():
    root = import_root()
    def no_raise(msg, fct, *args, **kwds):
        caught = False
        try:
            fct(*args, **kwds)
        except Exception, err:
            caught = True
        assert not caught, "%s:\n%s\nERROR" % (msg, err,)

    no_raise("problem pythonizing TFile", fct=_pythonize_tfile)
    no_raise("problem compiling dummy one-liner",
             root_compile, "void foo1() { return ; }")
    no_raise("problem compiling dummy one-liner w/ kwds",
             fct=root_compile, src="void foo1() { return ; }")
    import tempfile
    with tempfile.NamedTemporaryFile(prefix="foo_",suffix=".cxx") as tmp:
        print >> tmp, "void foo2() { return ; }"
        tmp.flush()
        no_raise("problem compiling a file",
                 fct=root_compile, fname=tmp.name)

    print "OK"

if __name__ == "__main__":
    _test_main()
    
