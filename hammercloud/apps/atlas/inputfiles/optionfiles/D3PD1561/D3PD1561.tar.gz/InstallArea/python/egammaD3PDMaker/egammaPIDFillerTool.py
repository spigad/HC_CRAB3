from egammaD3PDMaker import egammaD3PDMakerConf



class egammaPIDFillerTool (egammaD3PDMakerConf.D3PD__egammaPIDFillerTool):
    def __init__ (self,
                  name,
                  PID = [],
                  **kwargs):
        PID = [str(x) for x in PID]
        egammaD3PDMakerConf.D3PD__egammaPIDFillerTool.__init__ (self,
                                                                name,
                                                                PID = PID,
                                                                **kwargs)
        
