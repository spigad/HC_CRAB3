# $Id$
#
# @file D3PDMakerCoreComps/python/MakerAlg.py
# @author scott snyder <snyder@bnl.gov>
# @date Aug, 2009
# @brief Configure algorithm for making a D3PD tree.
#

from D3PDMakerCoreComps import D3PDMakerCoreCompsConf
import D3PDMakerCoreComps


def _stream_from_file (file, seq, tuplename):
    """Infer the Athena stream name from the file name.
    Create a new stream if needed.
"""

    # Make sure that THistSvc exists.
    from AthenaCommon.AppMgr import ServiceMgr
    if not hasattr (ServiceMgr, 'THistSvc'):
        from GaudiSvc.GaudiSvcConf import THistSvc
        ServiceMgr += THistSvc()

    # Search existing streams for one writing to this file.
    # If we find one, return it.
    # Also build a list of the names of all existing streams.
    streams = {}
    for s in ServiceMgr.THistSvc.Output:
        stream = s.split()[0]
        streams[stream] = 1
        sfile = None
        ifile = s.find ("DATAFILE='")
        if ifile >= 0:
            ifile += 10
            i2 = s.find ("'", ifile)
            if i2 >= 0:
                sfile = s[ifile:i2]
        if sfile == file:
            return stream

    # Didn't find the stream.  We'll need to create a new one.
    # This involves making another algorithm, so we need to have
    # the sequence available.
    if not seq:
        raise TypeError ("Need to create a new stream for tuple %s, "
                         "but sequence wasn't specified." % tuplename)

    # Find a unique name for the new stream.
    istream = 1
    while True:
        stream = 'AANT%d' % istream
        if not streams.has_key (stream): break
        istream += 1

    # Create the stream, and add it to the sequence.
    from AnalysisTools.AthAnalysisToolsConf import AANTupleStream
    st = AANTupleStream (stream,
                         ExtraRefNames = ['StreamESD',
                                          'StreamRDO',
                                          'StreamAOD'],
                         OutputName = file,
                         WriteInputDataHeader = True,
                         StreamName = stream)
    seq += [st]

    # Register with THistSvc.
    ServiceMgr.THistSvc.Output += ["%s DATAFILE='%s' OPT='RECREATE'" %
                                   (stream, file)]
    return stream


class MakerAlg (D3PDMakerCoreCompsConf.D3PD__MakerAlg):
    """Configure algorithm for making a D3PD tree.

    Each distinct D3PD tree is make by a separate algorithm.
    This Configurable class is used to configure these algorithms.

    The constructor takes the following arguments:

      name: The name of the algorithm (required).
      seq:  The Gaudi sequence to which this algorithm should be added,
            or None to skip adding the algorithm to a sequence.
      file: Name of the file containing the tuple.  Only used
            if both stream and TuplePath are None.
      stream: Athena stream for the tuple.  Only used if TuplePath
              is None.  If this is supplied, the stream must have already
              been created.  If omitted, the stream will be inferred
              from the file name, and will be implicitly created if needed.
              The Gaudi sequence must be provided for this implicit
              creation to work.
      tuplename: Name to the tuple.  Defaults to the algorithm name.
                 Only used if TuplePath is None.
      TuplePath: The full name of the tuple.  If given, this overrides
                 all other specifications.  The interpretation of this
                 is up to the D3PDSvc.
      D3PDSvc: D3PDSvc instance to use to create the tuple.
               Defaults to RootD3PDSvc.


    Once the algorithm is created, object filler tools should be added
    to it using +=.  This will automatically properly set the
    collection getter registry for the contained tools.
    
    Typical usage is like this:

      alg = D3PDMakerCoreComps.MakerAlg ('testtuple', topSequence,
                                         file = 'tuplefile.root')
      alg += FooObject()
      alg += BarObject()
"""

    def __init__ (self,
                  name,
                  seq = None,
                  file = None,
                  stream = None,
                  tuplename = None,
                  TuplePath = None,
                  **kwargs):
        """MakerAlg constructor.  See the class documentation for a full description.
"""

        # Work around initialization order issue.
        seq.__iadd__ (D3PDMakerCoreComps.DummyInitAlg (name + 'DummyInit'),
                      index = 0)

        # If the tuple path wasn't supplied, build it from the other args.
        if TuplePath == None:
            # tuple name defaults to the algorithm name.
            if tuplename == None:
                tuplename = name

            if stream == None:
                # If no stream was given, infer it from the file.
                # This creates the stream if needed.
                if file == None:
                    raise TypeError ("Neither stream nor file specified "
                                     "for tuple %s" % tuplename)
                stream = _stream_from_file (file, seq, tuplename)
            TuplePath = '/%s/%s' % (stream, tuplename)

        # Create the algorithm Configurable.
        D3PDMakerCoreCompsConf.D3PD__MakerAlg.__init__ (self, name,
                                               TuplePath = TuplePath,
                                               **kwargs)

        # Add to the supplied sequence.
        if seq:
            seq += [self]

        # Create a unique collection getter registry tool for this tree.
        from AthenaCommon.AppMgr import ToolSvc
        self._registry = \
           D3PDMakerCoreComps.CollectionGetterRegistryTool (self.name() +
                                                   '_CollectionGetterRegistry')
        ToolSvc += self._registry
        return


    def __iadd__( self, configs ):
        """Add a new IObjFillerTool to a tree."""

        # FIXME: should make sure name is unique within alg.
        if type(configs) != type([]):
            configs = [configs]
        self.Tools += configs

        # Rescan all children to set the proper collection getter registry.
        self._setRegistry (self)
        return self


    def _setRegistry (self, conf):
        """Scan CONF and all children to set the proper
        collection getter registry for this tree.
"""
        
        if conf.properties().has_key ('CollectionGetterRegistry'):
            conf.CollectionGetterRegistry = self._registry
        for c in conf.getAllChildren():
            self._setRegistry (c)
        return
    
       



