#Mon Dec 21 20:55:01 2009
"""Automatically generated. DO NOT EDIT please"""
from GaudiKernel.GaudiHandles import *
from GaudiKernel.Proxy.Configurable import *

class D3PD__RootD3PDSvc( ConfigurableService ) :
  __slots__ = { 
    'OutputLevel' : 7, # int
    'AuditServices' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditReInitialize' : False, # bool
    'AuditReStart' : False, # bool
    'HistSvc' : ServiceHandle('THistSvc'), # GaudiHandle
    'DoBranchRef' : True, # bool
    'MasterTree' : 'CollectionTree', # str
    'IndexMajor' : 'RunNumber', # str
    'IndexMinor' : 'EventNumber', # str
    'BasketSize' : 2048, # int
    'EntryOffsetLen' : 512, # int
  }
  _propertyDocDct = { 
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(D3PD__RootD3PDSvc, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'D3PDMakerRoot'
  def getType( self ):
      return 'D3PD::RootD3PDSvc'
  pass # class D3PD__RootD3PDSvc
