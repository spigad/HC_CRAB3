# steering file for RDO->ESD step without trigger
# see myTopOptions.py for more info

doCBNT=False
doTrigger=False
doWriteRDO=False
if not 'doWriteESD' in dir():
    doWriteESD=True
doWriteAOD=False
doAOD=False 
doWriteTAG=False 

# RecExCommon

include ("RecExCommon/RecExCommon_topOptions.py")

# D3PDMaker track and vertex blocks

from D3PDMakerCoreComps.MakerAlg import *
from TrackD3PDMaker.TrackD3PDObject import *
from TrackD3PDMaker.VertexD3PDObject import *
from EventCommonD3PDMaker.EventInfoD3PDObject import *

alg = MakerAlg("trackD3PD", topSequence, file = "trackD3PD.root", D3PDSvc = 'D3PD::RootD3PDSvc')
alg += EventInfoD3PDObject (10)
alg += TrackD3PDObject (10)
alg += VertexD3PDObject (10)

topSequence += alg
                

