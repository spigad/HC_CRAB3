// This file's extension implies that it's C, but it's really -*- C++ -*-.
// $Id$
/**
 * @file D3PDMakerInterfaces/IObjGetterTool.h
 * @author scott snyder <snyder@bnl.gov>
 * @date Jul, 2009
 * @brief Abstract interface to get an object to put in the tuple.
 */

#ifndef D3PDMAKERINTERFACES_IOBJGETTERTOOL_H
#define D3PDMAKERINTERFACES_IOBJGETTERTOOL_H


#include "GaudiKernel/IAlgTool.h"


namespace D3PD {


/// Interface definition.
static const InterfaceID IID_IObjGetterTool ("D3PD::IObjGetterTool", 1, 0);


/**
 * @brief Abstract interface to get an object to put in the tuple.
 *
 * The input to an object filler tool is provided by a tool of type
 * @c IObjGetterTool.  This will return an object or an object container
 * of a given type.  It is expected that the usual case for this will
 * be to fetch an object from StoreGate; generic code will be provided
 * for this case and for the case of retrieving the results of a particle
 * selection algorithm.  Other tools can be defined for specific
 * special cases, such as using selections stored in a top inputs object,
 * or for performing additional selections.
 *
 * User-defined getters generally shouldn't implement this interface
 * directly, but instead use the type-safe wrappers
 * provided by @c ObjGetterTool.
 */
class IObjGetterTool
  : virtual public IAlgTool
{
public:
  /// Gaudi interface definition.
  static const InterfaceID& interfaceID() { return IID_IObjGetterTool; }


  /**
   * @brief Return the type of object retrieved by this tool.
   */
  virtual const std::type_info& typeinfo() const = 0;


  /**
   * @brief Return the target object.
   * @param allowMissing If true, then we should not generate errors
   *        if the requested object is missing.
   *
   * Should be of the type given by @c typeinfo.
   * Return 0 on failure.
   */
  virtual const void* getUntyped (bool allowMissing = false) = 0;


  /**
   * @brief Type-safe wrapper for @c get.
   *
   * Return the object as a pointer to @c T.
   * Return 0 if the get fails or if the pointer can't be converted.
   *
   * This is implemented in terms of @c getTypeinfo().
   */
  template <class T>
  const T* get();


  /**
   * @brief Test type compatibility.
   *
   * Test to see if the object being returned by the tool can be converted
   * to a pointer to @c T.  This can be used to perform type checks during job
   * initialization.
   *
   * This is implemented in terms of @c configureTypeinfo.
   */
  template <class T>
  StatusCode configure();


  /**
   * @brief Return the target object cast to a different pointer type.
   * @param ti The desired type.
   *
   * Return the object as a pointer to the @c ti type.
   * Return 0 if the get fails or if the pointer can't be converted.
   */
  virtual const void* getTypeinfo (const std::type_info& ti) = 0;


  /**
   * @brief Test type compatibility.
   * @param ti The desired type.
   *
   * Test to see if the object being returned by the tool can be converted
   * to a pointer to @c T.  This can be used to perform type checks during job
   * initialization.
   */
  virtual StatusCode configureTypeinfo (const std::type_info& ti) = 0;
};


} // namespace D3PD


#include "D3PDMakerInterfaces/IObjGetterTool.icc"


#endif // not D3PDMAKERINTERFACES_IOBJGETTERTOOL_H
