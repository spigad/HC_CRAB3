#ifndef TILEEVENT_TILEFASTRAWCHANNEL_H
#define TILEEVENT_TILEFASTRAWCHANNEL_H

/*
	Author : Denis Oliveira Damazio
	Date : 01/18/2006
	Very simple class to hold, during HLT operation,
	the channel output before combining into cells.
*/

#include "Identifier/HWIdentifier.h"

class TileFastRawChannel {

public:
  TileFastRawChannel();
  ~TileFastRawChannel();

  inline HWIdentifier adc_HWID( void ) const { return m_adcid; }
  inline double amplitude( void ) const { return m_amplitude; }
  inline double time( void ) const { return m_time; }
  inline double quality( void ) const { return m_quality; }

  inline void set(HWIdentifier id, double amplitude,
                  double time, double quality) 
                 { m_adcid = id; m_amplitude = amplitude;
                   m_time=time; m_quality=quality;}

private:
  HWIdentifier m_adcid;
  double m_amplitude;
  double m_time;
  double m_quality;
};


#endif

