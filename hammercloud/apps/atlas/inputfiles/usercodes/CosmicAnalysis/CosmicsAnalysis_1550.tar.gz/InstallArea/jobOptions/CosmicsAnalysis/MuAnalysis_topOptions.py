import glob
from AthenaCommon.AthenaCommonFlags import athenaCommonFlags
from AthenaCommon.GlobalFlags import globalflags
from AthenaCommon.AlgSequence import AlgSequence
from AthenaCommon.AppMgr import ToolSvc,theApp,ServiceMgr
from AthenaCommon.Resilience import treatException,protectedInclude

globalflags.DataSource.set_Value_and_Lock('data')
# Detector geometry and magnetic field 
globalflags.DetDescrVersion.set_Value_and_Lock('ATLAS-GEO-03-00-00')
include("RecExCond/AllDet_detDescr.py")
#from RecExCommission.RecExCommission_MagneticFieldConfig import setFieldConfig
#setFieldConfig(RunNumber)      
topSequence = AlgSequence()

# Conditions
globalflags.ConditionsTag.set_Value_and_Lock('COMCOND-REPC-002-13') # for current remote DB  !!!!SLOW!!!!
#include("RecJobTransforms/UseOracle.py") # for current remote DB  !!!!SLOW!!!!
from IOVDbSvc.CondDB import conddb
conddb.setGlobalTag(globalflags.ConditionsTag())

# Trigger
from TriggerJobOpts.TriggerConfigGetter import TriggerConfigGetter
cfg = TriggerConfigGetter('ReadPool')

# The Main Job Options
include("RecExCommission/RecExCommission.py")                

# POOL input
import AthenaPoolCnvSvc.ReadAthenaPool
svcMgr.PoolSvc.AttemptCatalogPatch=True
fileList = glob.glob('/afs/cern.ch/user/j/jboyd/gencomm/data08_cosmag.00091900.physics_IDCosmic.recon.ESD.o4_r653_tid050556/ESD.050556.*')
svcMgr.EventSelector.InputCollections = fileList

# Set output level threshold (2=DEBUG, 3=INFO, 4=WARNING, 5=ERROR, 6=FATAL )
ServiceMgr.MessageSvc.OutputLevel = INFO
theApp.EvtMax = 10

# Load MuAnalysis
from CosmicsAnalysis.CosmicsAnalysisConf import MuAnalysis
m = MuAnalysis()
m.OutputLevel = WARNING
m.tilemuon_filler = "TileCosmicMuonHT"
#m.specmuon_filler = "StacoMuonCollection"
m.specmuon_filler = "MuidMuonCollection"
m.calocell_filler = "AllCalo"
m.calomuon_filler = "CaloMuonCollection"
m.OutputLevel = INFO
m.OutputFile = "Cosmic_09Data_IDCosmic.root"
topSequence += m


#from GaudiSvc.GaudiSvcConf import AuditorSvc
#ServiceMgr.AuditorSvc.Auditors  += [ "ChronoAuditor"]
#AthenaPoolCnvSvc = Service("AthenaPoolCnvSvc")
#AthenaPoolCnvSvc.UseDetailChronoStat = TRUE

