
/*******************************
 *                             *
 * Created by: Nathan Gardner  *
 * Date: June 9, 2009          *
 * HEP Argonne                 *
 *                             *
 *******************************/
#include <iostream>
#include <cmath>
#include <vector>
#include "TROOT.h"
#include "TFile.h"
#include "TTree.h"
#include "TH1F.h"
#include "TGaxis.h"
#include "TF1.h"
#include "TH3F.h"
#include "TH2F.h"
#include "TGraphErrors.h"
#include "TChain.h"
#include "TVector3.h"
#include "TProfile.h"
#include <sys/types.h>
#include <dirent.h>
#include <errno.h>
#include <string>
#include <sstream>
#include <iostream>
#include <math.h>
#include <iomanip>
#include "langaus.h"




using namespace std; 

/*function... */
int getdir (TString dir, vector<string> &files)
{
    DIR *dp;
    struct dirent *dirp;
    if((dp  = opendir(dir)) == NULL) {
        cout << "Error(" << errno << ") opening " << dir << endl;
        return errno;
    }

    while ((dirp = readdir(dp)) != NULL) {
        files.push_back(string(dirp->d_name));
    }
    closedir(dp);
    return 0;
} 

int GetPBin (double P, int size);

int main(int argc, char** argv)
{
	gROOT->ProcessLine("#include <vector>");
	
	TString dir = argv[1];
	TString output = argv[2];
    vector<string> files = vector<string>();
	getdir(dir,files);
	if (argc != 3) return 3;
	int nfiles = files.size();
	
	TChain t("MuTree");
	
	for (int z = 1; z < (nfiles - 1); z++) 
		{
			TString path = dir+(files.at(z));
			cout << "file loop2: " << path << endl;
			t.Add(path);
		}	
	
	//t.Add("/users/brianmartin/public/test.root");
	//t.Add("/users/garnat07/cosmic/data/run_data/P_E_RunOutput_RPC.root");
	//t.Add("/users/garnat07/testarea/15.1.0/runArea/P_E_RunOutput_IDCosmic.root");
	//TTree *t = (TTree*) f->Get("MuTree");

	TFile *Histogram_Output = new TFile(output,"recreate"); //save file
		//Local Declarations : 
	vector<double>* SpecP = 0;
	vector<double>* CombP = 0;
	vector<double>* InDetP = 0;
	vector<double>* Spec_pt = 0;
    vector<double>* Comb_pt = 0;
    vector<double>* InDet_pt = 0;
   	vector<double>* Spec_phi = 0;
   	vector<double>* InDet_phi = 0;
   	vector<double>* Comb_phi = 0;
   	vector<double>* Spec_eta = 0;
   	vector<double>* InDet_eta = 0;
   	vector<double>* Comb_eta = 0;
   	vector<double>* Spec_E = 0;
   	vector<double>* InDet_E = 0;
   	vector<double>* Comb_E = 0;
	vector<double>* Spec_x = 0;
    vector<double>* InDet_x = 0;
    vector<double>* Comb_x = 0;
    vector<double>* Spec_y = 0;
    vector<double>* InDet_y = 0;
    vector<double>* Comb_y = 0;
    vector<double>* Spec_z = 0;
    vector<double>* InDet_z = 0;
    vector<double>* Comb_z = 0;
    Int_t event = 0;
   	Int_t MuOriginal_n = 0;
   	Int_t TileMu_n = 0;
   	Int_t Spec_n = 0;
   	Int_t Comb_n = 0;
   	Int_t InDet_n = 0;
  	vector<double>* mu_eloss = 0;
    vector<double>* original_P = 0;
    vector<double>* original_phi = 0;
    vector<double>* original_eta = 0;
    vector<double>* tile_e = 0;
    vector<double>* tile_path = 0;
    vector<double>* tile_phi = 0;
   	vector<double>* tile_theta = 0;
 	vector<double>* tile_x = 0;
	vector<double>* tile_y = 0;
	vector<double>* tile_z = 0;
			//not branches
	const int N = 20;
	Double_t Y[N], eY[N], Y2[N], eY2[N], X[N];
	//int binMin[N] = {18,28,38,48,58,68,78,88,98,108,118,128,138,148,158,168,178,188,198};
	//Double_t X[N] = {20,30,40,50,60,70,80,90,100,110,120,130,140,150,160,170,180,190,200};
	//int binMax[N] = {22,32,42,52,62,72,82,92,102,112,122,132,142,152,162,172,182,192,202};
	vector<TH1F*> histVec;

		//Branch Addresses :
	t.SetBranchAddress("MuSpecP", &SpecP);
	t.SetBranchAddress("MuInDetP", &InDetP);							//Momentum
	t.SetBranchAddress("MuCombinedP", &CombP);
	t.SetBranchAddress("MuSpec_pt", &Spec_pt);
	t.SetBranchAddress("MuInDet_pt", &InDet_pt);						//Transverse Momentum
	t.SetBranchAddress("MuCombined_pt", &Comb_pt);
	t.SetBranchAddress("MuSpec_E", &Spec_E);
	t.SetBranchAddress("MuInDet_E", &InDet_E);							//Energy
    t.SetBranchAddress("MuComb_E", &Comb_E);
   	t.SetBranchAddress("MuSpec_phi", &Spec_phi);
	t.SetBranchAddress("MuInDet_phi", &InDet_phi);						//Phi
	t.SetBranchAddress("MuComb_phi", &Comb_phi);
	t.SetBranchAddress("MuSpec_eta", &Spec_eta);
	t.SetBranchAddress("MuInDet_eta", &InDet_eta);						//Eta
	t.SetBranchAddress("MuComb_eta", &Comb_eta);
	t.SetBranchAddress("MuSpec_perigee_x", &Spec_x);
	t.SetBranchAddress("MuInDet_perigee_x", &InDet_x);					//X of perigee
	t.SetBranchAddress("MuComb_perigee_x", &Comb_x);
	t.SetBranchAddress("MuSpec_perigee_y", &Spec_y);
	t.SetBranchAddress("MuInDet_perigee_y", &InDet_y);					//Y of perigee
	t.SetBranchAddress("MuComb_perigee_y", &Comb_y);				
	t.SetBranchAddress("MuSpec_perigee_z", &Spec_z);
	t.SetBranchAddress("MuInDet_perigee_z", &InDet_z);					//Z of perigee
	t.SetBranchAddress("MuComb_perigee_z", &Comb_z);
	t.SetBranchAddress("nEvent", &event);
	t.SetBranchAddress("MuOriginal_n", &MuOriginal_n);
	t.SetBranchAddress("TileMu_n", &TileMu_n);
	t.SetBranchAddress("MuSpec_n", &Spec_n);							//Number of ...
	t.SetBranchAddress("MuComb_n", &Comb_n);
	t.SetBranchAddress("MuInDet_n", &InDet_n);
	t.SetBranchAddress("MuSpec_eloss", &mu_eloss);
	t.SetBranchAddress("MuOriginal_P", &original_P);					//Original Muon container
	t.SetBranchAddress("MuOriginal_phi", &original_phi);
	t.SetBranchAddress("MuOriginal_eta", &original_eta);
	t.SetBranchAddress("Tile_E", &tile_e);
	t.SetBranchAddress("Tile_Path", &tile_path);						//Tile Cosmic muons
	t.SetBranchAddress("Tile_Phi", &tile_phi);
	t.SetBranchAddress("Tile_Theta", &tile_theta);
	t.SetBranchAddress("Tile_x", &tile_x);
	t.SetBranchAddress("Tile_y", &tile_y);
	t.SetBranchAddress("Tile_z", &tile_z);
	
		//Histogram Declarations
	TH1F *h_SpecP = new TH1F("SpecP", "Spec track P", 100, 0, 500000);
	TH1F *h_CombP = new TH1F("CombP", "Combined track P", 50, 0, 500000);
	TH1F *h_InDetP = new TH1F("InDetP", "In Detector track P", 50, 0, 500000);
	TH1F *h_Spec_CombP = new TH1F("Spec_CombP", "Spec-Comb P", 50, 0, 100000);
	TH1F *h_Spec_InDetP = new TH1F("Spec_InDetP", "Spec-InDet P", 50, 0, 100000);
	TH1F *h_Spec_CombP_SpecP = new TH1F("h_Spec_CombP_SpecP", "SpecP-InDetP/SpecP", 50, 0, 1);
	TH2F *h_SpecP_vs_InDetP = new TH2F("h_Spec_vs_InDetP", "SpecP vs InDetP", 50, 0, 500000, 50, 0, 500000);
	TH1F *h_Spec_E = new TH1F("h_Spec_E", "Spectrometer track E", 50, 0, 500000);
	TH1F *h_Comb_E = new TH1F("h_Comb_E", "Combination track E", 50, 0, 500000);
	TH1F *h_InDet_E = new TH1F("h_InDet_E", "inner detector track E", 50, 0, 500000);
	TH2F *h_Specphi_vs_Combphi = new TH2F("h_Specphi_vs_Combphi", "spec tack vs comb track: phi", 50, -3.3, 3.3, 50, 		-3.3, 3.3);
	TH2F *h_Specphi_vs_InDetphi = new TH2F("h_Specphi_vs_InDetphi", "spec track vs in det track: phi", 50, -3.3, 		3.3, 50, -3.3, 3.3);
	TH2F *h_Speceta_vs_Combeta = new TH2F("h_Speceta_vs_Combeta", "spec tack vs comb track: eta", 50, -3.3, 3.3, 50, 		-3.3, 3.3);
	TH2F *h_Speceta_vs_InDeteta = new TH2F("h_Speceta_vs_InDeteta", "spec track vs in det track: eta", 50, -3.3, 		3.3, 50, -3.3, 3.3);
	TH1F *h_InDet_CombP = new TH1F("Comb_InDetP", "Comb-InDet P", 60, -40000, 80000);
	TH1F *h_InDet_CombP_SpecP = new TH1F("CombP_InDetP_CombP", "CombP-InDetP/CombP", 50, -1, 1);
	TH2F *h_InDetphi_vs_Combphi = new TH2F("h_InDetphi_vs_Combphi", "inner track vs comb track: phi", 50, -3.3, 3.3, 		50, -3.3, 3.3);
	TH2F *h_InDeteta_vs_Combeta = new TH2F("h_InDeteta_vs_Combeta", "inner track vs comb track: eta", 50, -3.3, 3.3, 		50, -3.3, 3.3);
	TH1F *h_Spec_pt = new TH1F("Spec_pt","Spec pt", 100, 0, 400000);
	TH1F *h_Spec_phi = new TH1F("Spec_phi","Spec phi", 50, -3.3, 3.3);
	TH1F *h_Spec_eta = new TH1F("Spec_eta","Spec eta", 50, -3.3, 3.3);
	TH1F *h_Comb_pt = new TH1F("Comb_pt","Comb pt", 100, 0, 400000);
	TH1F *h_Comb_phi = new TH1F("Comb_phi","Comb phi", 50, -3.3, 3.3);
	TH1F *h_Comb_eta = new TH1F("Comb_eta","Comb eta", 50, -3.3, 3.3);
	TH1F *h_InDet_pt = new TH1F("InDet_pt","InDet pt", 100, 0, 400000);
	TH1F *h_InDet_phi = new TH1F("InDet_phi","InDet phi", 50, -3.3, 3.3);
	TH1F *h_InDet_eta = new TH1F("InDet_eta","InDet eta", 50, -3.3, 3.3);
	TH2F *h_Specx_vs_Specy = new TH2F("Specx_vs_Specy", "Spec X vs Y",150, -11500, 11500, 150, -11500, 11500);
	TH2F *h_Spec_P_vs_E = new TH2F("h_Spec_P_vs_E", "Spec P vs E",100, 0, 500000, 100, 0, 500000);
	TH1F *h_Spec_y = new TH1F("Spec_y", "Spec Perigee y", 100, -11500, 11500);
	TH1F *h_Spec_1sty = new TH1F("Spec_1sty", "Spec Perigee y for first muon", 100, -11000, 11000);
	TH1F *h_Spec_Rad = new TH1F("Spec_Rad", "Spec perigee radius", 100, 0, 12000);
	TH1F *h_Spec_Rad_cut = new TH1F("Spec_Rad_cut", "Spec perigee radius cut to |z| < 3000", 100, 0, 12000);
	TH1F *h_2ndSpecP = new TH1F("2ndSpecP", "Spec track P from muons passed through", 100, 0, 400000);
	TH1F *h_SpecP_Cut = new TH1F("SpecP_Cut", "Spec track P cut to 1st muon", 100, 0, 400000);
	TH1F *h_realSpecP = new TH1F("realSpecP", "Spec track P w/ passed muons cut", 100, 0, 400000);
	TH1F *h_SpecP_1st_2nd = new TH1F("h_SpecP_1st_2nd", "SpecP - P when passed through", 100, -1000, 105000);
	TH1F *h_InDetP_2ndSpec = new TH1F("h_InDetP_2ndSpec", "InDetP - passed SpecP", 100, -20000, 105000);
	TH1F *h_tile_phi = new TH1F("tile_phi","tile trk phi", 50, -3.3, 3.3);
	TH1F *h_tile_eta = new TH1F("tile_eta","tile trk eta", 50, -3.3, 3.3);
	TH1F *h_tile_x = new TH1F("tile_x", "tile muon x", 100, 7000, 7000);
	TH1F *h_tile_y = new TH1F("tile_y", "tile muon y", 100, 7000, 7000);
	TH1F *h_tile_z = new TH1F("tile_z", "tile muon z", 100, 7000, 7000);
	TH1F *h_tile_E = new TH1F("tile_E", "tile track E", 100, 0, 70000);
	TH1F *h_tile_path = new TH1F("tile_path", "tile track path (mm)", 100, 0, 30000);
	//TH1F *h_mu_eloss = new TH1F("h_mu_eloss", "muon E loss", 50, 0, 100000);
	TH1F *h_cut_Spec_InDetP = new TH1F("e_cut_Spec_InDetP", "Spec-InDet P cut to 1 muon", 100, -50000, 100000);
	TH1F *h_cut_tile_E = new TH1F("h_cut_tile_E", "tile track E cut to 1 muon", 50, 0, 100000);
	TH1F *h_percent_difference_tile_Pdiff = new TH1F("h_percent_difference_tile_Pdiff", "percent difference: tile_E amd Pdiff ", 100, 0, 1.3);
 	TH1F *h_OrigMu_n = new TH1F("h_OrigMu_n", "number of muons per event ",12, 0, 6);
	TH1F *h_OrigMu_P = new TH1F("h_OrigMu_P", "P of muon container ", 100, 0, 500000);
	TH1F *h_OrigMu_phi = new TH1F("h_OrigMu_phi", "phi of muon container ", 100, -3.3, 3.3);
	TH1F *h_OrigMu_eta = new TH1F("h_OrigMu_eta", "et of muon container",100, -3.3, 3.3);
	TH2F *h_orig_vs_tile_eta = new TH2F("h_orig_vs_tile_eta", "container track vs tile track: eta", 100, -3.3, 		3.3, 100, -3.3, 3.3); 
	TH1F *h_TileMu_n = new TH1F("TileMu_n", "number of tile muons per event ",12, 0, 6);
	TH1F *h_Spec_n = new TH1F("Spec_n", "number of spec muons per event ",12, 0, 6);
	TH1F *h_Comb_n = new TH1F("Comb_n", "number of comb muons per event ",12, 0, 6);
	TH1F *h_InDet_n = new TH1F("InDet_n", "number of inner det muons per event ",12, 0, 6);
	TH1F *h_E_mm = new TH1F("h_E_mm", "tile E/Path (MeV/mm) ",50, 0, 6);
	TH2F *h_tile_indet_phi = new TH2F("h_tile_indet_phi", "tile track vs inner detector track: phi", 200, -3.3, 	3.3, 200, -3.3, 3.3);
	TH2F *h_tile_x_z = new TH2F("h_tile_x_z", "tile track x vs tile track z", 200, -5000, 5000, 200, -5000, 	  5000);
	TH2F *h_InDetP_vs_Emm = new TH2F("h_InDetP_vs_Emm", "log inner P (GeV) vs tile E/path (MeV/mm)", 200, 0, 3, 	200, 0,6); 
	TH1F *h_E_mm50 = new TH1F("h_E_mm50", "tile E/Path (MeV/mm) 50GeV muons",50, 0, 6);
	TH1F *h_E_mm100 = new TH1F("h_E_mm100", "tile E/Path (MeV/mm) 100GeV muons",50, 0, 6);
	TH1F *h_E_mm150 = new TH1F("h_E_mm150", "tile E/Path (MeV/mm) 150GeV muons",50, 0, 6);
	TH1F *h_E_mm175 = new TH1F("h_E_mm175", "tile E/Path (MeV/mm) 175GeV muons",50, 0, 6);
	TProfile *P_Emm_prof = new TProfile("P_Emm_prof", "Inner P (GeV) vs track E/path (MeV/mm)", 200, 0, 200, 0, 6);
	TProfile *P_Emm_prof2 = new TProfile("P_Emm_prof", "Inner P (GeV) vs track E/path (MeV/mm)", 200, 0, 700, 0, 4);
	TProfile *P_Spec_Inner_prof = new TProfile("e_Spec_Inner_prof", "Inner P (GeV) vs Momentum Difference (GeV)", 100, 18, 205, 0, 200);
	TProfile *P_Spec_Inner_big_prof = new TProfile("e_Spec_Inner_big_prof", "Inner P (GeV) vs Momentum Difference (GeV)", 150, 18, 700, 0, 200);
	TH2F *h_Pdiff_vs_InDetP = new TH2F("e_Pdiff_vs_InDetP", "InDetP (GeV) vs P difference (GeV)",100 , 0, 220, 100, 0, 50);
	TH1F *h_tile_e_compare = new TH1F("e_tile_e_compare", "tile_e_compare", 100, -50000, 100000);
	TH2F *h_tile_e_vs_Pdiff = new TH2F("e_tile_e_vs_Pdiff", "tile_e_vs_Pdiff", 100, -50000, 100000, 100, -50000, 100000);
	TH1F *h_spec_indet_phi = new TH1F("e_spec_indet_phi", "spec-indet: phi", 100, -3.3, 3.3);
	TProfile *P_tile_e_vs_Pdiff_prof = new TProfile("e_tile_e_vs_Pdiff_prof", "tile_e_vs_Pdiff", 100, 0, 100000, -50000, 100000);
	TH2F *h_Spec_phi_vs_P = new TH2F("Spec_phi_vs_P", "Spec_phi_vs_P", 200, -3.3, 3.3, 100, 0, 500000);
	TH1F *h_tile_e_mm = new TH1F("tile_e_mm", "Tile E/Path (MeV/mm)",100, 0, 4);
	TH1F *h_Spec_phi_ppt = new TH1F("h_Spec_phi_ppt", "phi of spectometer track ", 100, -3.3, 3.3);
	TH1F *h_InDet_phi_ppt = new TH1F("h_InDet_phi_ppt", "phi of inner track ", 100, -3.3, 3.3);
	TH1F *h_tile_phi_ppt = new TH1F("h_tile_phi_ppt", "phi tile track ", 100, -3.3, 3.3);
	TH2F *h_tile_phi_ppt_InDet_phi = new TH2F("h_tile_phi_ppt_InDet_phi", "tile_phi_ppt_InDet_phi", 100, -3.3, 3.3, 100, -3.3, 3.3);
	TH2F *h_tile_phi_ppt_Spec_phi = new TH2F("h_tile_phi_ppt_Spec_phi", "tile_phi_ppt_Spec_phi", 100, -3.3, 3.3, 100, -3.3, 3.3);
	TH1F *h_Spec_eta_ppt = new TH1F("h_Spec_eta_ppt", "eta of spectometer track ", 200, -3, 3);
	TH1F *h_InDet_eta_ppt = new TH1F("h_InDet_eta_ppt", "eta of inner track ", 100, -3, 3);
	TH1F *h_tile_eta_ppt = new TH1F("h_tile_eta_ppt", "eta tile track ", 200, -3, 3);
	TH2F *h_speceta_vs_tileeta = new TH2F("h_speceta_vs_tileeta", "speceta_vs_tileeta", 100, -3, 3, 100, -3, 3);
	TH2F *h_tileeta_vs_indeteta = new TH2F("h_tileeta_vs_indeteta", "h_tileeta_vs_indeteta", 100, -3, 3, 100, -3, 3);
	 TH1F *h_20_50_Pdiff = new TH1F("h_20_50_Pdiff", "Spec-InDet P cut 20 - 50 GeV", 100, -50000, 60000);
	 TH1F *h_5_20_Pdiff = new TH1F("h_5_20_Pdiff", "Spec-InDet P cut 5 - 20 GeV", 100, -25000, 25000);	 
	 TH1F *h_50_60_Pdiff = new TH1F("h_50_60_Pdiff", "Spec-InDet P cut 50 - 60 GeV", 50, -50000, 65000);
	 TH1F *h_5_10_Pdiff = new TH1F("h_5_10_Pdiff", "Spec-InDet P cut 5 - 10 GeV", 50, -8000, 10000);	 
	 TH1F *h_5_10_tileE = new TH1F("h_5_10_tileE", "Tile E cut 5 - 10 GeV", 50, -8000, 10000);
	 TProfile *h_5_10_tileE_Pdiff = new TProfile("h_5_10_tileE_Pdiff", "Tile E vs Pdiff cut 5 - 10 GeV", 50, -1000, 8000, -8000, 10000);
						/////Look at Pdiff and TileE cut out bad indet eta 5 - 15 GeV
	 TH1F *h_5_15_Pdiff_etacut = new TH1F("h_5_15_Pdiff_etacut", "Spec-InDet P cut 5 - 15 GeV", 50, -8000, 10000);	 
	 TH1F *h_5_15_tileE_etacut = new TH1F("h_5_15_tileE_etacut", "Tile E cut 5 - 15 GeV", 50, -8000, 10000);
	 TProfile *h_5_15_tileE_Pdiff_etacut = new TProfile("h_5_15_tileE_Pdiff_etacut", "Tile E vs Pdiff cut 5 - 15 GeV", 50, -1000, 8000, -8000, 10000);
	
	 TProfile *h_tileE_tileeta = new TProfile("h_tileE_tileeta", "tile eta vs. tile E", 100, -1.5, 1.5, -100, 12000);
	 TProfile *h_speceta_Pdiff = new TProfile("h_speceta_Pdiff", "spec eta vs. P diff", 100, -1.5, 1.5, -10000, 12000);
	 
	 			//////Tile E/mm cut to 100 to 150 GeV muons, phi -1.35 to -1.45 binned by Eta//////
	 TH1F *h_Emm_eta_n7_n5 = new TH1F("h_Emm_eta_n7_n5", "Tile E/Path (MeV/mm) cut to eta -0.7 to -0.5 for 100-150 GeV muons",50, 0, 4);
	 TH1F *h_Emm_eta_n5_n3 = new TH1F("h_Emm_eta_n5_n3", "Tile E/Path (MeV/mm) cut to eta -0.5 to -0.3 for 100-150 GeV muons",50, 0, 4);
	 TH1F *h_Emm_eta_n3_n1 = new TH1F("h_Emm_eta_n3_n1", "Tile E/Path (MeV/mm) cut to eta -0.3 to -0.1 for 100-150 GeV muons",50, 0, 4);
	 TH1F *h_Emm_eta_n1_1 = new TH1F("h_Emm_eta_n1_1", "Tile E/Path (MeV/mm) cut to eta -0.1 to 0.1 for 100-150 GeV muons",50, 0, 4);
	 TH1F *h_Emm_eta_3_1 = new TH1F("h_Emm_eta_3_1", "Tile E/Path (MeV/mm) cut to eta 0.1 to 0.3 for 100-150 GeV muons",50, 0, 4);
	 TH1F *h_Emm_eta_5_3 = new TH1F("h_Emm_eta_5_3", "Tile E/Path (MeV/mm) cut to eta 0.3 to 0.5 for 100-150 GeV muons",50, 0, 4);
	 TH1F *h_Emm_eta_7_5 = new TH1F("h_Emm_eta_7_5", "Tile E/Path (MeV/mm) cut to eta 0.5 to 0.7 for 100-150 GeV muons",50, 0, 4);
	 		//////Tile E/mm cut to 100 to 150 GeV muons, eta -0.4 to -0.4 binned by Phi//////
	 TH1F *h_Emm_phi_n3_n25 = new TH1F("h_Emm_phi_n3_n25", "Tile E/Path (MeV/mm) cut to phi -3 to -2.5 for 100-150 GeV muons",50, 0, 4);
	 TH1F *h_Emm_phi_n25_n2 = new TH1F("h_Emm_phi_n25_n2", "Tile E/Path (MeV/mm) cut to phi -2.5 to -2 for 100-150 GeV muons",50, 0, 4);
	 TH1F *h_Emm_phi_n2_n15 = new TH1F("h_Emm_phi_n2_n15", "Tile E/Path (MeV/mm) cut to phi -2 to -1.5 for 100-150 GeV muons",50, 0, 4);
	 TH1F *h_Emm_phi_n15_n1 = new TH1F("h_Emm_phi_n15_n1", "Tile E/Path (MeV/mm) cut to phi -1.5 to -1 for 100-150 GeV muons",50, 0, 4);
	 TH1F *h_Emm_phi_n1_n5 = new TH1F("h_Emm_phi_n1_n5", "Tile E/Path (MeV/mm) cut to phi -1 to -0.5 for 100-150 GeV muons",50, 0, 4);
	 TH1F *h_Emm_phi_n5_0 = new TH1F("h_Emm_phi_n5_0", "Tile E/Path (MeV/mm) cut to phi -0.5 to 0 for 100-150 GeV muons",50, 0, 4);
	 TH1F *h_Emm_phi_0_3 = new TH1F("h_Emm_phi_0_3", "Tile E/Path (MeV/mm) cut to phi 0 to 3 for 100-150 GeV muons",50, 0, 4);
	TH1F *h_Pdiff_eta_cut = new TH1F("h_Pdiff_eta_cut", "Spec-InDet P cut InDet_eta != 0", 150, -50000, 100000);
				////Histograms for Comb track comparisons/// 
	TH2F *h_tileeta_vs_combeta = new TH2F("h_tileeta_vs_combeta", "h_tileeta_vs_combeta", 100, -3, 3, 100, -3, 3);
	TH1F *h_Comb_phi_ppt = new TH1F("h_Comb_phi_ppt", "phi of comb track ", 100, -3.3, 3.3);
	TH1F *h_Comb_eta_ppt = new TH1F("h_Comb_eta_ppt", "eta of comb track ", 200, -3, 3);
	TH2F *h_tile_phi_ppt_Comb_phi = new TH2F("h_tile_phi_ppt_Comb_phi", "tile_phi_ppt_Comb_phi", 100, -3.3, 3.3, 100, -3.3, 3.3);
	//TH1F *h_Pdiffc = new TH1F("h_Pdiffc", "Spec-Comb P", 150, -50000, 100000);
	TH1F *h_5_10_Pdiffc = new TH1F("h_5_10_Pdiffc", "Spec-Comb P cut 5 - 10 GeV", 50, -8000, 10000);
	TProfile *h_5_10_tileE_Pdiffc = new TProfile("h_5_10_tileE_Pdiffc", "Tile E vs Pdiffc cut 5 - 10 GeV", 50, -1000, 8000, -8000, 10000);
	 TProfile *h_tilePath_tileeta = new TProfile("h_tilePath_tileeta", "tile eta vs. tile Path", 100, -1.5, 1.5, -100, 12000);
	 TProfile *h_Pdiff_tileeta = new TProfile("h_Pdiff_tileeta", "tile eta vs. Pdiff", 100, -1.5, 1.5, -100, 12000);
					//calculated tile values
	TH2F *h_tile_Z_path = new TH2F("h_tile_Z_path", "tile_Z_path", 100, -6000, 6000, 100, 0, 8000);
	TH2F *h_tile_X_path = new TH2F("h_tile_X_path", "tile_X_path", 100, -6000, 6000, 100, 0, 8000);
	TH1F *h_calc_Theta = new TH1F("h_calc_Theta", "calc_Theta", 100, -3.3, 3.3);
	TH1F *h_calc_Phi = new TH1F("h_calc_Phi", "calc_Phi", 100, -3.3, 3.3);
	TH3F *h_tile_X_Z_path = new TH3F("h_tile_X_Z_path", "tile_X_Z_path", 100, -6000, 6000, 100, -6000, 6000, 100, 0, 8000); 

	TH1F *h_tile_e_oneside = new TH1F("h_tile_e_oneside", "Tile E/1.8 (rough estimate) ", 100, -8000, 10000);
	TH1F *h_Pdiffc = new TH1F("h_Pdiffc", "Spec-Comb P", 100, -8000, 10000);	 	 	 	 
				//HistVec	
	TString title = "E_mm";
		for (int nb = 0; nb < N; nb++)
			{
				//TString binStr = "";
				double stat = ((log10(220) - log10(20))/20);
				double min = ((log10(20)) + (stat*nb));
				double max = (min + stat);
				double gev_min = pow(10,min);
				double gev_max = pow(10,max);
				stringstream name;
				name << setprecision (4) << gev_min << "-" << gev_max;
				//double xpoint = (min + (stat/2));
				//binStr += "_";
				//binStr += (min);
				//binStr += "_";
				//binStr += (max);
				TH1F* htmp = new TH1F(title+name.str(), title+name.str(), 50, 0, 6);
				histVec.push_back(htmp);
			}
	
	
///////////////Statements/////////////////////////////////////////////////////////////////
	
		Int_t nEvent = t.GetEntries(); 
		cout << "number of events: " << nEvent << endl;  
	for (int i = 0; i < nEvent; i++)
		{
			t.GetEntry(i);
			int muspec = SpecP->size();
			int mucomb = CombP->size();
			int muid = InDetP->size();
			int tile = tile_e->size();
			int original = original_P->size();
			
			if( (i % 1000) == 0) cout << "event #: " << i << endl;
				
					//Tile info
			for (int d = 0; d < tile; d++)
				{
					//cout << "Tile If" << endl;
					h_TileMu_n->Fill(TileMu_n);
					h_tile_E->Fill(tile_e->at(d));
					h_tile_path->Fill(tile_path->at(d));
					h_tile_phi->Fill(tile_phi->at(d));
					double eta = -(log(tan((tile_theta->at(d))/2.0)));
					h_tile_eta->Fill(eta);
					h_tile_x->Fill(tile_x->at(d));
					h_tile_y->Fill(tile_y->at(d));
					h_tile_z->Fill(tile_z->at(d));
					h_tile_x_z->Fill((tile_x->at(d)),(tile_z->at(d)));
					if((tile_path->at(d)) > 10 && (tile_path->at(d)) < 10000)
						{
							h_tile_e_mm->Fill((tile_e->at(d))/(tile_path->at(d)));
								//math for coordinates to r from IP
							double R = 4250;
							double top1 = ((tan(tile_phi->at(d)))*(tan(tile_phi->at(d))));
							double top2 = ((R*R)-((tile_x->at(d))*(tile_x->at(d))));
							double temp_top = (sqrt(top1*top2));
							double temp_bot = (sqrt(1+((tan(tile_phi->at(d)))*(tan(tile_phi->at(d))))));
							double Y = (temp_top/temp_bot);
							double X = (sqrt((R*R)-(Y*Y)));
							double Phi = (atan(Y/X));
							double x_1 = (X - (tile_x->at(d)));
							double r_1 = (sqrt((x_1*x_1)+(Y*Y)));
							double z_1 = (r_1/(tile_theta->at(d)));
							double Z = (z_1 + (tile_z->at(d)));
							double Theta = (atan(R/Z));
							
							h_tile_Z_path->Fill(Z,(tile_path->at(d)));
							h_tile_X_path->Fill(X,(tile_path->at(d)));
							h_calc_Theta->Fill(Theta);
							h_calc_Phi->Fill(Phi);
							h_tile_X_Z_path->Fill(X, Z, (tile_path->at(d)));
						}
					
				}
					//Compare tile, spec, and inner
			if ((muspec == 2 || muspec == 1) && muid == 1 && tile == 1 && mucomb == 1)
				{
					for (int f = 0; f < 1; f++)
						{
							if(Spec_y->at(f) > 0)
							 {
							 	double phi_tile = tile_phi->at(f);
							 	double eta_t = -(log(tan((tile_theta->at(f))/2.0)));
							 	double eta_indet = (InDet_eta->at(f));
								double eta_comb = (Comb_eta->at(f));
							 	h_Spec_phi_ppt->Fill(Spec_phi->at(f));
							 	h_InDet_phi_ppt->Fill(InDet_phi->at(f));
							 	h_Comb_phi_ppt->Fill(Comb_phi->at(f));
							 	h_tile_phi_ppt->Fill(phi_tile);
							 	h_tile_phi_ppt_InDet_phi->Fill(phi_tile,InDet_phi->at(f));
							 	h_tile_phi_ppt_Comb_phi->Fill(phi_tile,Comb_phi->at(f));
							 	h_tile_phi_ppt_Spec_phi->Fill(phi_tile,Spec_phi->at(f));
							 	h_Spec_eta_ppt->Fill(Spec_eta->at(f));
							 	h_InDet_eta_ppt->Fill(eta_indet);
								h_Comb_eta_ppt->Fill(eta_comb);
								h_tile_eta_ppt->Fill(eta_t);
							 	h_speceta_vs_tileeta->Fill(Spec_eta->at(f),eta_t);
							 	h_tileeta_vs_indeteta->Fill(eta_t,eta_indet);
							 	h_tileeta_vs_combeta->Fill(eta_t,eta_comb);
						
							if(Spec_y->at(f) >0 && (tile_path->at(f)) > 10 && (tile_path->at(f)) < 10000 && (fabs((Spec_phi->at(f))-(InDet_phi->at(f)))) < 0.2)
							 {
								//cout << "Big IF" << endl;
								double P_Spec = SpecP->at(f);
								double P_InDet = InDetP->at(f);
								double P_Comb = CombP->at(f);
								double Pdiff = (P_Spec-P_InDet);
								double Pdiffc = (P_Spec-P_Comb);
								h_Pdiffc->Fill(Pdiffc);
								if(eta_indet < -0.07 || eta_indet > 0.07)h_Pdiff_eta_cut->Fill(Pdiff);
								double E_tile = tile_e->at(f);
								double E_Path = (E_tile/(tile_path->at(f)));
								h_tileE_tileeta->Fill(eta_t, E_tile);
								h_tilePath_tileeta->Fill(eta_t,(tile_path->at(f)));
								h_Pdiff_tileeta->Fill(eta_t,Pdiff);
								h_speceta_Pdiff->Fill(Spec_eta->at(f), Pdiff);
								if(P_Spec > 20000 && P_Spec < 50000) h_20_50_Pdiff->Fill(Pdiff);
								if(P_Spec > 5000 && P_Spec < 20000) h_5_20_Pdiff->Fill(Pdiff);
								if(P_Spec > 5000 && P_Spec < 10000) 
									{	
										h_5_10_Pdiff->Fill(Pdiff);
										h_5_10_tileE->Fill(E_tile);
										h_5_10_tileE_Pdiff->Fill(E_tile,Pdiff);
										h_5_10_Pdiffc->Fill(Pdiffc);
										h_5_10_tileE_Pdiffc->Fill(E_tile,Pdiffc);
									}
								if(P_Spec > 5000 && P_Spec < 15000 && (eta_indet < -0.07 || eta_indet > 0.07)) 
									{	
										h_5_15_Pdiff_etacut->Fill(Pdiff);
										h_5_15_tileE_etacut->Fill(E_tile);
										h_5_15_tileE_Pdiff_etacut->Fill(E_tile,Pdiff); 
									}	
								if(P_Spec > 50000 && P_Spec < 60000) h_50_60_Pdiff->Fill(Pdiff);
								if(P_Spec > 50000 && P_Spec < 100000 && phi_tile < -1.2 && phi_tile > -1.6)
									{ 
										if(eta_t > -0.7 && eta_t < -0.5) h_Emm_eta_n7_n5->Fill(E_Path);
										if(eta_t > -0.5 && eta_t < -0.3) h_Emm_eta_n5_n3->Fill(E_Path);
										if(eta_t > -0.3 && eta_t < -0.1) h_Emm_eta_n3_n1->Fill(E_Path);
										if(eta_t > -0.1 && eta_t < 0.1) h_Emm_eta_n1_1->Fill(E_Path);
										if(eta_t > 0.1 && eta_t < 0.3) h_Emm_eta_3_1->Fill(E_Path);
										if(eta_t > 0.3 && eta_t < 0.5) h_Emm_eta_5_3->Fill(E_Path);
										if(eta_t > 0.5 && eta_t < 0.7) h_Emm_eta_7_5->Fill(E_Path);
									}
								if(P_Spec > 50000 && P_Spec < 100000 && eta_t < 0.4 && eta_t > -0.4)
									{ 
										if(phi_tile > -3 && phi_tile < -2.5) h_Emm_phi_n3_n25->Fill(E_Path);
										if(phi_tile > -2.5 && phi_tile < -2) h_Emm_phi_n25_n2->Fill(E_Path);
										if(phi_tile > -2 && phi_tile < -1.5) h_Emm_phi_n2_n15->Fill(E_Path);
										if(phi_tile > -1.5 && phi_tile < -1) h_Emm_phi_n15_n1->Fill(E_Path);
										if(phi_tile > -1 && phi_tile < -0.5) h_Emm_phi_n1_n5->Fill(E_Path);
										if(phi_tile > -0.5 && phi_tile < 0) h_Emm_phi_n5_0->Fill(E_Path);
										if(phi_tile > 0 && phi_tile < 3) h_Emm_phi_0_3->Fill(E_Path);
									}
								h_tile_e_compare->Fill(E_tile);
								h_tile_e_oneside->Fill(E_tile/1.8);
								h_cut_Spec_InDetP->Fill(Pdiff);
								h_tile_e_vs_Pdiff->Fill(E_tile, Pdiff);
								P_tile_e_vs_Pdiff_prof->Fill(E_tile, Pdiff);
								h_Pdiff_vs_InDetP->Fill((P_InDet/1000), (Pdiff/1000));
								if (Pdiff >= 0 && Pdiff < 40000 && (fabs((tile_phi->at(f)) - (Spec_phi->at(f))) < 0.2) && (fabs((tile_phi->at(f)) - (InDet_phi->at(f))) < 0.2))
									{
										
										
										double percdiff = (fabs(Pdiff-E_tile)/((Pdiff+E_tile)/2));
										h_percent_difference_tile_Pdiff->Fill(percdiff); 
									}
								P_Spec_Inner_prof->Fill((P_InDet/1000),(Pdiff/1000));
								P_Spec_Inner_big_prof->Fill((P_InDet/1000),(Pdiff/1000));
								h_spec_indet_phi->Fill((Spec_phi->at(f))-(InDet_phi->at(f)));
							}}
						}
				} 	
						//Compare Tile to Muon Container 
			for (int co = 0; co < tile && co < original; co++)
				{
					double tile_eta = -(log(tan((tile_theta->at(co))/2.0)));
					double orig_eta = (original_eta->at(co));
					h_orig_vs_tile_eta->Fill(orig_eta, tile_eta);
				}
					//Compare Tile to Inner Detector 
			for (int z = 0; z < tile && z < muid; z++)
				{
					h_tile_indet_phi->Fill((tile_phi->at(z)), (InDet_phi->at(z)));
					if((tile_path->at(z)) > 10 && (tile_path->at(z)) < 10000)
						{
							double e_mm = ((tile_e->at(z))/(tile_path->at(z)));
							h_E_mm->Fill(e_mm);
							double GeV = ((InDetP->at(z))/1000);
							double logP = (log10(GeV));
							int Pbin = GetPBin(logP, N);
							if(Pbin != -1)
								{ 
									histVec[Pbin]->Fill(e_mm);
						        }	
							if(logP >= 1.3 && logP <= 2.3)
								{
									h_InDetP_vs_Emm->Fill(logP, e_mm, 1);
									P_Emm_prof->Fill(logP, e_mm);
									P_Emm_prof2->Fill(logP, e_mm);
								}
									
						}
				}

					
					//Original Muon Container
			for (int a = 0; a <	original; a++)	
				{	
					//cout << "1" << endl;
					h_OrigMu_n->Fill(MuOriginal_n);
					h_OrigMu_P->Fill(original_P->at(a));
					h_OrigMu_phi->Fill(original_phi->at(a));
					h_OrigMu_eta->Fill(original_eta->at(a));
				}
					//cout << "2" << endl;
							//Spectrometer track Histograms
					for (int b = 0; b < muspec; b++)
						{
							//cout << "Spectrometer If" << endl;
							h_Spec_n->Fill(Spec_n);
							h_SpecP->Fill(SpecP->at(b));
							h_Spec_E->Fill(Spec_E->at(b));
							h_Spec_pt->Fill(Spec_pt->at(b));
							h_Spec_phi->Fill(Spec_phi->at(b));
							h_Spec_eta->Fill(Spec_eta->at(b));
							h_Spec_P_vs_E->Fill(SpecP->at(b), Spec_E->at(b));
							if(Spec_y->at(b) > 0) h_Spec_phi_vs_P->Fill((Spec_phi->at(b)),(SpecP->at(b)));
							h_Spec_y->Fill(Spec_y->at(b));
							h_Specx_vs_Specy->Fill(Spec_x->at(b), Spec_y->at(b));
							//h_mu_eloss->Fill(mu_eloss->at(b));
							if (b == 0)
								{	
									h_Spec_1sty->Fill(Spec_y->at(b));
									h_SpecP_Cut->Fill(SpecP->at(b));
							 		if (fabs(Spec_z->at(b)) <= 3000) h_Spec_Rad_cut->Fill(sqrt((Spec_y->at(b))*									(Spec_y->at(b))+(Spec_x->at(b))*(Spec_x->at(b))));
								}
							h_Spec_Rad->Fill(sqrt((Spec_y->at(b))*(Spec_y->at(b))+(Spec_x->at(b))*(Spec_x->at(b))));
							if (Spec_y->at(b) < -3000) 
					  		 	{ 	
					   				double cut_specp = (SpecP->at(b));
					   				h_2ndSpecP->Fill(cut_specp);
					  			 }
							else 
								{	
									double real_specp = (SpecP->at(b));
									h_realSpecP->Fill(real_specp);
								} 
					
						}	
					//cout << "5" << endl;
									//Combined track Histograms
					for (int c = 0; c < mucomb; c++)
						{
							//cout << "Combination If" << endl;
							h_Comb_n->Fill(Comb_n);
							h_CombP->Fill(CombP->at(c));
							h_Comb_E->Fill(Comb_E->at(c));
							h_Spec_CombP->Fill((SpecP->at(c))-(CombP->at(c)));
							h_Spec_CombP_SpecP->Fill(((SpecP->at(c))-(CombP->at(c)))/(SpecP->at(c)));
							h_Specphi_vs_Combphi->Fill((Spec_phi->at(c)),(Comb_phi->at(c)));
							h_Speceta_vs_Combeta->Fill((Spec_eta->at(c)),(Comb_eta->at(c)));
							h_Comb_pt->Fill(Comb_pt->at(c));
							h_Comb_phi->Fill(Comb_phi->at(c));
							h_Comb_eta->Fill(Comb_eta->at(c));
								
										//inner track comparison
							//cout << "6" << endl;		
							h_InDet_CombP->Fill((InDetP->at(c))-(CombP->at(c)));
							h_InDet_CombP_SpecP->Fill(((InDetP->at(c))-(CombP->at(c)))/(InDetP->at(c)));
							h_InDetphi_vs_Combphi->Fill((Comb_phi->at(c)),(InDet_phi->at(c)));
							h_InDeteta_vs_Combeta->Fill((Comb_eta->at(c)),(InDet_eta->at(c)));	
											
						}
					//cout << "7" << endl;
									//Inner Detector track Histograms
					for (int h = 0; h < muid; h++)
						{
							//cout << "8" << endl;	
							h_InDet_n->Fill(InDet_n);
							h_InDetP->Fill(InDetP->at(h));
							h_InDet_E->Fill(InDet_E->at(h));
							h_InDet_pt->Fill(InDet_pt->at(h));
							h_InDet_phi->Fill(InDet_phi->at(h));
							h_InDet_eta->Fill(InDet_eta->at(h));
							//cout << "9" << endl;	
							if (h < muspec)
								{	
									//cout << "10" << endl;	
									double diffp = (((SpecP->at(h))-(InDetP->at(h))));
									h_Spec_InDetP->Fill(diffp);
									h_SpecP_vs_InDetP->Fill((SpecP->at(h)),(InDetP->at(h)));
									h_Specphi_vs_InDetphi->Fill((Spec_phi->at(h)),(InDet_phi->at(h)));
									h_Speceta_vs_InDeteta->Fill((Spec_eta->at(h)),(InDet_eta->at(h)));
									if (Spec_y->at(h) < -3000) 
					   					{ 	
					   						double cut_specp2 = (SpecP->at(h));
					   						h_InDetP_2ndSpec->Fill((InDetP->at(h))-cut_specp2);
					   					}	
					   			} 
						}	
						
						/*if (muspec == 2) 
							{ 
								if ((SpecP->at(0)) > (SpecP->at(1)))
									{	h_SpecP_1st_2nd->Fill((SpecP->at(0))-(SpecP->at(1)));	}
								else 
									{	h_SpecP_1st_2nd->Fill((SpecP->at(1))-(SpecP->at(0)));	}
							} */
			//cout << "11" << endl;	
		
	}	
	
	for (int fit = 0; fit < N; fit++) 
	 	{		
	  			 // Setting fit range and start values
   			Double_t fr[2];
   			Double_t sv[4], pllo[4], plhi[4], fp[4], fpe[4];
   			//fr[0]=0.3*(histVec[fit]->GetMean());
  			//fr[1]=3.0*(histVec[fit]->GetMean());
  			fr[0]= 0.0;
  			fr[1]= 4.0;
			
 			 	pllo[0]=0.01; pllo[1]=1.1; pllo[2]=5.0; pllo[3]=0.1;
  			 	plhi[0]=0.5; plhi[1]=1.9; plhi[2]=700.0; plhi[3]=0.8;
				sv[2] = (70);
  				 sv[0]=0.08; sv[1]=1.35; /*sv[2]=1000.0;*/ sv[3]=0.5;
  					 
  			Double_t chisqr;
   			Int_t    ndf;
   			TF1 *fitsnr = langaufit(histVec[fit],fr,sv,pllo,plhi,fp,fpe,&chisqr,&ndf);
   			Y[fit] = fp[1];
			eY[fit] = fpe[1];
 			double stat = ((log10(220) - log10(20))/20);
			double min = (log10(20));
			double xpoint = (min + (stat*fit)) + (stat/2);
			X[fit] = pow(10,xpoint);
			//fitsnr->Write();
   		}
   	
   	cout << "***Fitting Tile E/Path***" << endl;	
   		
   		{		
	  			 // Setting fit range and start values
   			Double_t fr[2];
   			Double_t sv[4], pllo[4], plhi[4], fp[4], fpe[4];
  			fr[0]= 0.0;
  			fr[1]= 4.0;
			pllo[0]=0.01; pllo[1]=1.1; pllo[2]=5.0; pllo[3]=0.1;               ////Fit for Tile E/Path
  			plhi[0]=0.5; plhi[1]=1.9; plhi[2]=200000.0; plhi[3]=0.8;
			sv[2] = (300000);
  			sv[0]=0.08; sv[1]=1.45; /*sv[2]=1000.0;*/ sv[3]=0.5;
			Double_t chisqr;
   			Int_t    ndf;
   			TF1 *langaufitter = langaufit(h_tile_e_mm,fr,sv,pllo,plhi,fp,fpe,&chisqr,&ndf);
   		
   		}

	cout << "***Done Fitting***" << endl;
	
	
	/*for (int fit2 = 0; fit2 < N; fit2++) 
	 		{
	 			if(fit2 < 4) histVec[fit2]->Fit("gaus","","", 0, 1.8);
	 			else if(fit2 > 3 && fit2 < 8) histVec[fit2]->Fit("gaus","","", 0, 2.0);
				else if(fit2 > 14 && fit2 < 18) histVec[fit2]->Fit("gaus","","", 0, 2.3);
	 			else if(fit2 > 17) histVec[fit2]->Fit("gaus","","", 0, 2.5);
				else histVec[fit2]->Fit("gaus","","", 0, 2.1);
	 			TF1 *fitpar = histVec[fit2]->GetFunction("gaus");
	 			double p1 = (fitpar->GetParameter(1));
	 			double e1 = (fitpar->GetParError(1));
	 			Y2[fit2] = p1;
				eY2[fit2] = e1; 
				eX2[fit2] = 2.5;
			} */

	TGraphErrors *InP_Emm_graph = new TGraphErrors(N, X, Y, 0, eY);

		
		//Histograms to write
	 h_SpecP->Write();
	 h_CombP->Write();
	 h_InDetP->Write();
	 h_Spec_CombP->Write();
	 h_Spec_InDetP->Write();
	 h_Spec_CombP_SpecP->Write();
	 h_SpecP_vs_InDetP->Write();
	 h_Comb_E->Write();
	 h_InDet_E->Write();
	 h_Spec_E->Write();
	 h_Specphi_vs_Combphi->Write();
	 h_Specphi_vs_InDetphi->Write();
	 h_Speceta_vs_Combeta->Write();
	 h_Speceta_vs_InDeteta->Write();
	 h_InDet_CombP->Write();
	 h_InDet_CombP_SpecP->Write();
	 h_InDetphi_vs_Combphi->Write();
	 h_InDeteta_vs_Combeta->Write();
	 h_Spec_pt->Write();
	 h_Spec_phi->Write();
	 h_Spec_eta->Write();
	 h_Comb_pt->Write();
	 h_Comb_phi->Write();
	 h_Comb_eta->Write();
	 h_InDet_pt->Write();
	 h_InDet_phi->Write();
	 h_InDet_eta->Write();
	 h_Spec_P_vs_E->Write();
	 h_Spec_y->Write();
	 h_Spec_1sty->Write();
	 h_Spec_Rad->Write();
	 h_Spec_Rad_cut->Write();
	 h_2ndSpecP->Write();
	 h_SpecP_Cut->Write();
	 h_realSpecP->Write();
	 h_SpecP_1st_2nd->Write();
	 h_InDetP_2ndSpec->Write();
	// h_mu_eloss->Write();
	 h_tile_E->Write();
	 h_tile_path->Write();
	 h_tile_phi->Write();
	 h_tile_eta->Write();
	 h_tile_x->Write();
	 h_tile_y->Write();
	 h_tile_z->Write();
	 h_tile_e_mm->Write();
	 h_cut_tile_E->Write();
	 h_cut_Spec_InDetP->Write();
	 h_percent_difference_tile_Pdiff->Write();
	 h_OrigMu_n->Write();
	 h_OrigMu_P->Write();
	 h_OrigMu_phi->Write();
	 h_OrigMu_eta->Write();
	 h_TileMu_n->Write();
	 h_Spec_n->Write();
	 h_Comb_n->Write();
	 h_InDet_n->Write();
	 h_orig_vs_tile_eta->Write();
	 h_tile_x_z->Write();
	 h_tile_indet_phi->Write();
	 h_E_mm->Write();
	 h_InDetP_vs_Emm->Write();
	 /*h_E_mm50->Write();
	 h_E_mm100->Write();
	 h_E_mm150->Write();
	 h_E_mm175->Write();*/
	 P_Emm_prof->Write();
	 P_Emm_prof2->Write(); 
	 InP_Emm_graph->Write();
	// InP_Emm_graph_gaus->Write();
	 P_Spec_Inner_prof->Write();
	 P_Spec_Inner_big_prof->Write();
	 h_Pdiff_vs_InDetP->Write();
	 h_tile_e_compare->Write();
	 h_tile_e_vs_Pdiff->Write();
	 h_spec_indet_phi->Write();
	 P_tile_e_vs_Pdiff_prof->Write();
	 h_Spec_phi_vs_P->Write();
	 h_Specx_vs_Specy->Write();
	 h_Spec_phi_ppt->Write();
	 h_InDet_phi_ppt->Write();
	 h_tile_phi_ppt->Write();
	 h_tile_phi_ppt_InDet_phi->Write();
	 h_tile_phi_ppt_Spec_phi->Write();
	 h_tile_eta_ppt->Write();
	 h_Spec_eta_ppt->Write();
	 h_InDet_eta_ppt->Write();
	 h_speceta_vs_tileeta->Write();
	 h_tileeta_vs_indeteta->Write();
	 h_20_50_Pdiff->Write();
	 h_5_20_Pdiff->Write();
	 h_50_60_Pdiff->Write();
 	 h_5_10_Pdiff->Write();
 	 h_5_10_tileE->Write();
 	 h_5_10_tileE_Pdiff->Write();
	 h_tileE_tileeta->Write();
	 h_speceta_Pdiff->Write();
	 h_Emm_eta_n7_n5->Write();
	 h_Emm_eta_n5_n3->Write();
	 h_Emm_eta_n3_n1->Write();
	 h_Emm_eta_n1_1->Write();
	 h_Emm_eta_3_1->Write();
	 h_Emm_eta_5_3->Write();
	 h_Emm_eta_7_5->Write();
	 h_Emm_phi_n3_n25->Write();
	 h_Emm_phi_n25_n2->Write();
	 h_Emm_phi_n2_n15->Write();
	 h_Emm_phi_n15_n1->Write();
	 h_Emm_phi_n1_n5->Write();
	 h_Emm_phi_n5_0->Write();
	 h_Emm_phi_0_3->Write();
	 h_Pdiff_eta_cut->Write();
	 h_5_15_Pdiff_etacut->Write();
	 h_5_15_tileE_etacut->Write();
	 h_5_15_tileE_Pdiff_etacut->Write();
	 h_tileeta_vs_combeta->Write();
	 h_Comb_phi_ppt->Write();
	 h_tile_phi_ppt_Comb_phi->Write();
	 h_Comb_eta_ppt->Write();
	 h_5_10_Pdiffc->Write();
	 h_5_10_tileE_Pdiffc->Write();
	 h_Pdiffc->Write();
	 h_tilePath_tileeta->Write();
	 h_Pdiff_tileeta->Write();
	 h_tile_Z_path->Write();
	 h_tile_X_path->Write();
	 h_calc_Theta->Write();
	 h_calc_Phi->Write();
	 h_tile_X_Z_path->Write();
	 h_tile_e_oneside->Write();
 	 
 	 
	 for (int num = 0; num < N; num++) 
	 	{
	 		histVec[num]->Write();
		}
	  
	Histogram_Output->Close();

	return 0;	}
	

int GetPBin (double P, int size)
{
	double stat = ((log10(220) - log10(20))/20);
	double min = (log10(20));
	double max = min + stat;
	//int binMin[20] = {min,28,38,48,58,68,78,88,98,108,118,128,138,148,158,168,178,188,198};
	//int binMax[20] = {22,32,42,52,62,72,82,92,102,112,122,132,142,152,162,172,182,192,202};
	for(int i = 0; i < size; i++)
		{
			double minloop = (min + (stat*i));
			double maxloop = (max + (stat*i));
			if(P > minloop && P < maxloop) 
				{
					return i;
				}
		}	
	return -1;	
}
	
	
	
	
