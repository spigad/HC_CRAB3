#include "CosmicsAnalysis/MuAnalysis.h"

#include "TileEvent/TileCosmicMuonContainer.h"
#include "TileEvent/TileCosmicMuon.h"
#include "CaloEvent/CaloCellContainer.h"
#include "CaloEvent/CaloCell.h"
#include "CaloIdentifier/CaloCell_ID.h"
#include "CaloEvent/CaloClusterContainer.h"
#include "CaloEvent/CaloCluster.h"
#include "Particle/TrackParticle.h"
#include "Particle/TrackParticleContainer.h"
#include "muonEvent/Muon.h"
#include "muonEvent/MuonContainer.h"
#include "TrigDecisionTool/ChainGroup.h"

#include "TFile.h" 
#include "TTree.h"
#include "TH1F.h"

using namespace Analysis;

////////////////////////////////////////////////////////////////////////////////////////////////
/// Constructor 

MuAnalysis::MuAnalysis(const std::string& name, ISvcLocator* pSvcLocator) :
	Algorithm(name, pSvcLocator),
	m_trigDec("Trig::TrigDecisionTool/TrigDecisionTool")
{
							//Properties to be filled in Job Options
			
	//declareProperty("muon_filler",m_muonfill = "CaloMuonCollection");
	declareProperty("tilemuon_filler",m_tilemu_fill = "TileCosmicMuonHT");
	declareProperty("calocell_filler",m_cellfill = "AllCalo");
	declareProperty("calocluster_filler",m_clusterfill = "LArMuClusterCandidates");
	declareProperty("calomuon_filler",m_calomufill = "CaloMuonCollection");
	declareProperty("specmuon_filler",m_specmu_fill = "StacoMuonCollection");
	declareProperty("MaxLArMuCandidates", LAr_max_mu = 30);
	//declareProperty("idmuon_filler",m_idmuon_filler = "StacoMuonCollection");

	declareProperty("OutputFile",m_OutputFile = "output.HIST.root");  //Output File - Name in job options   
	     
	
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// Destructor

	MuAnalysis::~MuAnalysis() {}

///////////////////////////////////////////////////////////////////////////////////////////////////////////
/// Initialize

	StatusCode MuAnalysis::initialize()
	{
		StatusCode sc;
		MsgStream mLog( messageService(), name() );
		
		sc = service("StoreGateSvc", m_storeGate);
		if (sc.isFailure())
		 {
			mLog << MSG::ERROR
				<< "Unable to retrieve pointer to StoreGateSvc"
				<< endreq;
			return sc;
		}

		sc = service("DetectorStore",m_detStore);
		if (sc.isFailure()) {
		  mLog << MSG::ERROR
		      << "Unable to get pointer to Detector Store Service" << endreq;
		  return sc;
		}

		if ( m_trigDec.retrieve().isFailure() ) {
			mLog << MSG::ERROR << "Could not retrieve TrigDecisionTool!" << endreq;
			return StatusCode::FAILURE;
		}

		sc = m_detStore->retrieve(m_calo_id_man);
		if (sc.isFailure()) {
		  mLog << MSG::ERROR << "Unable to retrieve CaloIdManager from DetectorStore" << endreq;
		  return sc;
		} else {
		  mLog << MSG::DEBUG << "Successfully retrieved CaloIdManager from DetectorStore" << endreq;
		}     

		m_calo_helper = m_calo_id_man->getCaloCell_ID();
		if (sc.isFailure()) {
		  mLog << MSG::ERROR
		      << "Unable to retrieve calo helper from DetectorStore" << endreq;
		  return sc;
		}

		//save file
		mufile = new TFile(m_OutputFile.c_str(),"recreate"); 
	
		t = new TTree("MuTree", "MuTTree");	
		nEvent = 0;
		nCombmu = 0;
		mu_spec_n = 0;
		mu_comb_n = 0;
		mu_indet_n = 0;
		tile_n = 0;
    LAr_ncand = 0;
					//Vectors 
		mu_spec_P = new std::vector<double>;
		mu_comb_P = new std::vector<double>;
		mu_id_P = new std::vector<double>;
		mu_spec_pt = new std::vector<double>;
		mu_comb_pt = new std::vector<double>;
		mu_id_pt = new std::vector<double>;
		mu_spec_phi = new std::vector<double>;
		mu_id_phi = new std::vector<double>;
		mu_comb_phi = new std::vector<double>;
		mu_spec_eta = new std::vector<double>;
		mu_id_eta = new std::vector<double>;
		mu_comb_eta = new std::vector<double>;
		mu_spec_E = new std::vector<double>;
		mu_id_E = new std::vector<double>;
		mu_comb_E = new std::vector<double>;
		mu_spec_x = new std::vector<double>;
		mu_id_x = new std::vector<double>;
		mu_comb_x = new std::vector<double>;
		mu_spec_y = new std::vector<double>;
		mu_id_y = new std::vector<double>;
		mu_comb_y = new std::vector<double>;
		mu_spec_z = new std::vector<double>;
		mu_id_z = new std::vector<double>;
		mu_comb_z = new std::vector<double>;
		mu_eloss = new std::vector<double>;		
		tile_e = new std::vector<double>;
		tile_path_topA = new std::vector<double>;
		tile_path_bottomA = new std::vector<double>;
		tile_path_topBC = new std::vector<double>;
		tile_path_bottomBC = new std::vector<double>;
		tile_path_topD = new std::vector<double>;
		tile_path_bottomD = new std::vector<double>;
		tile_path_total = new std::vector<double>;
		tile_path_top = new std::vector<double>;
		tile_path_bottom = new std::vector<double>;
		tile_E_topA = new std::vector<double>;
		tile_E_bottomA = new std::vector<double>;
		tile_E_topBC = new std::vector<double>;
		tile_E_bottomBC = new std::vector<double>;
		tile_E_topD = new std::vector<double>;
		tile_E_bottomD = new std::vector<double>;
		tile_E_top = new std::vector<double>;
		tile_E_bottom = new std::vector<double>;
		tile_E_total = new std::vector<double>;
		tile_path = new std::vector<double>;
		tile_phi = new std::vector<double>;
		tile_theta = new std::vector<double>;
		tile_x = new std::vector<double>;
		tile_y = new std::vector<double>;
		tile_z = new std::vector<double>;
		combmu_P = new std::vector<double>;
		combmu_phi = new std::vector<double>; 
		combmu_eta  = new std::vector<double>;
		combmu_x  = new std::vector<double>;
		combmu_y  = new std::vector<double>;
		combmu_z  = new std::vector<double>;
		cell_e = new std::vector<double>;
		calomu_e = new std::vector<double>;
		LAr_eta1 = new std::vector<double>;
		LAr_phi1 = new std::vector<double>;
		LAr_eta2 = new std::vector<double>;
		LAr_phi2 = new std::vector<double>;
		LAr_energy = new std::vector<double>;
		LAr_senergy = new std::vector<double>;
		LAr_nbmcells = new std::vector<long>;
		LAr_nbscells = new std::vector<long>;

		
						//TTree and TBranch
		t->Branch("MuSpecP", &mu_spec_P);
		t->Branch("MuCombinedP", &mu_comb_P);					//Momentum
		t->Branch("MuInDetP", &mu_id_P);
		t->Branch("MuSpec_pt", &mu_spec_pt);
		t->Branch("MuCombined_pt", &mu_comb_pt);				//Transverse Momentum
		t->Branch("MuInDet_pt", &mu_id_pt);
		t->Branch("nEvent", &nEvent);
		t->Branch("MuOriginal_n", &nCombmu);
		t->Branch("TileMu_n", &tile_n);
		t->Branch("MuSpec_n", &mu_spec_n);					//Number of ...
		t->Branch("MuComb_n", &mu_comb_n);
		t->Branch("MuInDet_n", &mu_indet_n);
		t->Branch("LAr_ncand", &LAr_ncand);
		t->Branch("LAr_max_mu", &LAr_max_mu);

		t->Branch("MuSpec_phi", &mu_spec_phi);
		t->Branch("MuInDet_phi", &mu_id_phi);					//Phi
		t->Branch("MuComb_phi", &mu_comb_phi);
		t->Branch("MuSpec_eta", &mu_spec_eta);
		t->Branch("MuInDet_eta", &mu_id_eta);					//Eta
		t->Branch("MuComb_eta", &mu_comb_eta);
		t->Branch("MuSpec_E", &mu_spec_E);
		t->Branch("MuInDet_E", &mu_id_E);					//Energy
		t->Branch("MuComb_E", &mu_comb_E);
		t->Branch("MuSpec_perigee_x", &mu_spec_x);
		t->Branch("MuInDet_perigee_x", &mu_id_x);				//X of perigee
		t->Branch("MuComb_perigee_x", &mu_comb_x);
		t->Branch("MuSpec_perigee_y", &mu_spec_y);
		t->Branch("MuInDet_perigee_y", &mu_id_y);				//Y of perigee
		t->Branch("MuComb_perigee_y", &mu_comb_y);
		t->Branch("MuSpec_perigee_z", &mu_spec_z);
		t->Branch("MuInDet_perigee_z", &mu_id_z);				//Z of Perigee
		t->Branch("MuComb_perigee_z", &mu_comb_z);
		t->Branch("MuOriginal_P", &combmu_P);
		t->Branch("MuOriginal_phi", &combmu_phi);				
		t->Branch("MuOriginal_eta", &combmu_eta);				//Original muon container
		t->Branch("MuOriginal_x", &combmu_x);
		t->Branch("MuOriginal_y", &combmu_y);
		t->Branch("MuOriginal_z", &combmu_z);
		t->Branch("MuSpec_eloss", &mu_eloss);
		
		// Tile Muons
		t->Branch("Tile_E", &tile_e);
		t->Branch("Tile_Path", &tile_path);	
		t->Branch("Tile_Path_Top", &tile_path_top);
		t->Branch("Tile_Path_Bottom", &tile_path_bottom);		
		t->Branch("Tile_Path_TopA", &tile_path_topA);
		t->Branch("Tile_Path_BottomA", &tile_path_bottomA);
		t->Branch("Tile_Path_TopBC", &tile_path_topBC);
		t->Branch("Tile_Path_BottomBC", &tile_path_bottomBC);
		t->Branch("Tile_Path_TopD", &tile_path_topD);
		t->Branch("Tile_Path_BottomD", &tile_path_bottomD);
		t->Branch("Tile_Path_Total", &tile_path_total);
		t->Branch("Tile_E_TopA", &tile_E_topA);
		t->Branch("Tile_E_BottomA", &tile_E_bottomA);
		t->Branch("Tile_E_TopBC", &tile_E_topBC);
		t->Branch("Tile_E_BottomBC", &tile_E_bottomBC);
		t->Branch("Tile_E_TopD", &tile_E_topD);
		t->Branch("Tile_E_BottomD", &tile_E_bottomD);
		t->Branch("Tile_E_Top", &tile_E_top);
		t->Branch("Tile_E_Bottom", &tile_E_bottom);
		t->Branch("Tile_E_Total", &tile_E_total);
		t->Branch("Tile_Phi", &tile_phi);
		t->Branch("Tile_Theta", &tile_theta);
		t->Branch("Tile_x", &tile_x);						
		t->Branch("Tile_y", &tile_y);
		t->Branch("Tile_z", &tile_z);
		t->Branch("Cell_E", &cell_e);
		t->Branch("CaloMu_E", &calomu_e);
		t->Branch("LAr_eta1",&LAr_eta1);
		t->Branch("LAr_phi1",&LAr_phi1);
		t->Branch("LAr_eta2",&LAr_eta2);
		t->Branch("LAr_phi2",&LAr_phi2);
		t->Branch("LAr_energy",&LAr_energy);                        //LAr Clusters
		t->Branch("LAr_senergy",&LAr_senergy);
		t->Branch("LAr_nbmcells",&LAr_nbmcells);
		t->Branch("LAr_nbscells",&LAr_nbscells);
		
		return sc;
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////////////////
/// Finalize

	StatusCode MuAnalysis::finalize() 
	{
    	StatusCode sc;
    	MsgStream mLog( messageService(), name() );	
    	mufile->cd();
    	mLog << MSG::DEBUG << "I am the FINALIZOR !!" << endreq;
			mufile->Write();
			mufile->Close();
			return sc;
	}
	
/////////////////////////////////////////////////////////////////////////////////////////////////////
/// Execute - on event by event

	StatusCode MuAnalysis::execute() 
	{
		StatusCode sc;
		MsgStream mLog( messageService(), name() );
		
		// Reset Counters
		nEvent += 1;
		nCombmu = 0;
		mu_spec_n = 0;
		mu_comb_n = 0;
		mu_indet_n = 0;
		tile_n = 0;

///////////////////////////////// Access Trigger Information //////////////////////////////////////////
		const Trig::ChainGroup* L1Items = m_trigDec->getChainGroup("L1_.*");
		std::vector<std::string> L1names = L1Items->getListOfTriggers();
		mLog << MSG::DEBUG << "# L1 Items available: " << L1names << endreq;
		std::vector<std::string>::iterator	itrL1 = L1names.begin();
		for(;itrL1 != L1names.end();itrL1++)
		{
			if(m_trigDec->isPassed(*itrL1)) mLog << MSG::INFO << "L1 Item: " << *itrL1 << " fired" << endreq;
		}


////////////////////////////////////// Tile Cosmic Muons //////////////////////////////////////////////

	  const TileCosmicMuonContainer* tilemuon = 0;
		sc = m_storeGate->retrieve( tilemuon, m_tilemu_fill);
		if( sc.isFailure()  ||  !tilemuon)
		{
			mLog << MSG::WARNING << "No ESD tile cosmic muon container found in TDS" << endreq;
		}
		mLog << MSG::DEBUG << "TileCosmicMuonContainer accessed" << endreq;
				
		//Loop over Tile muons
		TileCosmicMuonContainer::const_iterator tilemuonItr = tilemuon->begin();
		TileCosmicMuonContainer::const_iterator tilemuonItrE = tilemuon->end();
		for (; tilemuonItr != tilemuonItrE; tilemuonItr++)
		{
			mLog << MSG::DEBUG << "Tile Loop is working" << endreq;
			double tile_muE = ((*tilemuonItr)->GetFullEnergy());
			double tile_muPath = ((*tilemuonItr)->GetFullPath());	
			//double tile_muQuality = ((*tilemuonItr)->GetFitQuality());

			////Start of Tile Path Investigation////
			tile_path_topA->push_back((*tilemuonItr)->GetPathTop(0));
			tile_path_bottomA->push_back((*tilemuonItr)->GetPathBottom(0));
			tile_path_topBC->push_back((*tilemuonItr)->GetPathTop(1));
			tile_path_bottomBC->push_back((*tilemuonItr)->GetPathBottom(1));
			tile_path_topD->push_back((*tilemuonItr)->GetPathTop(2));
			tile_path_bottomD->push_back((*tilemuonItr)->GetPathBottom(2));
			double path_top = (((*tilemuonItr)->GetPathTop(0))+((*tilemuonItr)->GetPathTop(1))+((*tilemuonItr)->GetPathTop(2)));
			double path_bottom = (((*tilemuonItr)->GetPathBottom(0))+((*tilemuonItr)->GetPathBottom(1))+((*tilemuonItr)->GetPathBottom(2)));
			tile_path_top->push_back(path_top);
			tile_path_bottom->push_back(path_bottom);
			double path_total = (path_top + path_bottom);
			tile_path_total->push_back(path_total);
			////End of Tile Path Investigation////

			////Start of Tile Energy Investigation////
			tile_E_topA->push_back((*tilemuonItr)->GetEnergyTop(0));
			tile_E_bottomA->push_back((*tilemuonItr)->GetEnergyBottom(0));
			tile_E_topBC->push_back((*tilemuonItr)->GetEnergyTop(1));
			tile_E_bottomBC->push_back((*tilemuonItr)->GetEnergyBottom(1));
			tile_E_topD->push_back((*tilemuonItr)->GetEnergyTop(2));
			tile_E_bottomD->push_back((*tilemuonItr)->GetEnergyBottom(2));
			double E_top = (((*tilemuonItr)->GetEnergyTop(0))+((*tilemuonItr)->GetEnergyTop(1))+((*tilemuonItr)->GetEnergyTop(2)));
			double E_bottom = (((*tilemuonItr)->GetEnergyBottom(0))+((*tilemuonItr)->GetEnergyBottom(1))+((*tilemuonItr)->GetEnergyBottom(2)));
			tile_E_top->push_back(E_top);
			tile_E_bottom->push_back(E_bottom);
			double E_total = (E_top + E_bottom);
			tile_E_total->push_back(E_total);
			mLog << MSG::DEBUG << "tile_muE: " << endreq;
			////End of Tile Energy Investigation////

			double tile_muPhi = ((*tilemuonItr)->GetDirectionPhi());
			double tile_muTheta = ((*tilemuonItr)->GetDirectionTheta());

			//nTuple data
			tile_n++;
			tile_e->push_back(tile_muE);
			tile_path->push_back(tile_muPath); 
			tile_phi->push_back(tile_muPhi);
			tile_theta->push_back(tile_muTheta);
			tile_x->push_back((*tilemuonItr)->GetPositionX());
			tile_y->push_back((*tilemuonItr)->GetPositionY());
			tile_z->push_back((*tilemuonItr)->GetPositionZ());
		} 


 ////////////////////////////////////// Muons and Tracks //////////////////////////////////////////////
 //////////////////////////////////// Momentum and Energy//////////////////////////////////////////////
 
 		const MuonContainer* specmuon = 0;
		sc = m_storeGate->retrieve( specmuon, m_specmu_fill);
		if( sc.isFailure()  ||  !specmuon)
		{
			mLog << MSG::WARNING << "No ESD spec muon container found in TDS" << endreq;
		}
		mLog << MSG::DEBUG << "spec MuonContainer accessed" << endreq;
		
		//Loop over muons in container
		MuonContainer::const_iterator specmuonItr = specmuon->begin();
		MuonContainer::const_iterator specmuonItrE = specmuon->end();
		for (; specmuonItr != specmuonItrE; specmuonItr++)
		{
			mLog << MSG::DEBUG << "Muon Loop is working" << endreq;
			combmu_P->push_back((*specmuonItr)->p());
			combmu_phi->push_back((*specmuonItr)->phi());
			combmu_eta->push_back((*specmuonItr)->eta());
			nCombmu++;

			//	//Muon Spectrometer Track//	//
			const Rec::TrackParticle* tempSpecTrack = ((*specmuonItr)->muonSpectrometerTrackParticle());
			mLog << MSG::DEBUG << "check 1" << endreq;
			if(tempSpecTrack != 0)
			{
				mLog << MSG::DEBUG << "1st if works" << endreq;
				mu_spec_n++;
				mu_spec_P->push_back(tempSpecTrack->p());
				mu_spec_pt->push_back(tempSpecTrack->pt());
				mu_spec_E->push_back(tempSpecTrack->e());
				mu_spec_phi->push_back(tempSpecTrack->phi()); 
				mu_spec_eta->push_back(tempSpecTrack->eta());
				mu_spec_x ->push_back(tempSpecTrack->perigee()->position().x());
				mu_spec_y->push_back(tempSpecTrack->perigee()->position().y());
				mu_spec_z->push_back(tempSpecTrack->perigee()->position().z()); 
			}

			//	//Combined Track//	//
			if((*specmuonItr)->hasCombinedMuonTrackParticle())
			{	
				mu_comb_n++;
				mu_comb_P->push_back((*specmuonItr)->combinedMuonTrackParticle()->p());
				mu_comb_pt->push_back((*specmuonItr)->combinedMuonTrackParticle()->pt());
				mu_comb_E->push_back((*specmuonItr)->combinedMuonTrackParticle()->e());
				mu_comb_phi->push_back((*specmuonItr)->combinedMuonTrackParticle()->phi());
				mu_comb_eta->push_back((*specmuonItr)->combinedMuonTrackParticle()->eta()); 
				mu_comb_x->push_back((*specmuonItr)->combinedMuonTrackParticle()->perigee()->position().x());
				mu_comb_y->push_back((*specmuonItr)->combinedMuonTrackParticle()->perigee()->position().y());
				mu_comb_z->push_back((*specmuonItr)->combinedMuonTrackParticle()->perigee()->position().z());
			}	

			//	//Inner Detector Track//	//
			if((*specmuonItr)->hasInDetTrackParticle())
			{
				mu_indet_n++;
				mu_id_P->push_back((*specmuonItr)->inDetTrackParticle()->p());
				mu_id_pt->push_back((*specmuonItr)->inDetTrackParticle()->pt());
				mu_id_E->push_back((*specmuonItr)->inDetTrackParticle()->e()); 
				mu_id_phi->push_back((*specmuonItr)->inDetTrackParticle()->phi()); 
				mu_id_eta->push_back((*specmuonItr)->inDetTrackParticle()->eta()); 
				mu_id_x->push_back((*specmuonItr)->inDetTrackParticle()->perigee()->position().x()); 
				mu_id_y->push_back((*specmuonItr)->inDetTrackParticle()->perigee()->position().y());
				mu_id_z->push_back((*specmuonItr)->inDetTrackParticle()->perigee()->position().z()); 
			} 

		}


///////////////////////////////////////////Calo Cluster//////////////////////////////////////////////////////
//////////////////////////////////////////Liquid Argonne/////////////////////////////////////////////////////


		const CaloClusterContainer* calocluster = 0;
		sc = m_storeGate->retrieve( calocluster, m_clusterfill);
		if( sc.isFailure()  ||  !calocluster)
		{
			mLog << MSG::WARNING << "No ESD CaloCluster LArmuon container found in TDS" << endreq;
		}
		mLog << MSG::DEBUG << "CaloClusterContainer accessed" << endreq;
		//				//Loop over muons in container
		//		CaloClusterContainer::const_iterator caloclusterItr = calocluster->begin();
		//	   		CaloClusterContainer::const_iterator caloclusterItrE = calocluster->end();
		//std::cout << "Number of Calo Clusters: " << calocluster->size() << std::endl;
		//for (; caloclusterItr != caloclusterItrE; caloclusterItr++)
		//{
		//mLog << MSG::DEBUG << "cluster Loop is working" << endreq;
		//double clustere = ((*caloclusterItr)->e());	
		//mLog << MSG::DEBUG << "cluster energy: " << clustere << endreq;		   
		//calomu_e->push_back((*caloclusterItr)->e()); 
		//} 
		int index = 0;
		CaloClusterContainer::const_iterator f_cluster = calocluster->begin();
		CaloClusterContainer::const_iterator l_cluster = calocluster->end();
		mLog << MSG::DEBUG << "Cluster Iterator set" << endreq;

		// loop over all clusters
		for ( ; f_cluster!=l_cluster; ++f_cluster) {

			const CaloCluster* cluster = (*f_cluster) ;

			if ( index < LAr_max_mu )
			{

				bool barrel =false;
				bool endcap =false;

				CaloCluster::cell_iterator cellIter    = cluster->cell_begin();
				CaloCluster::cell_iterator cellIterEnd = cluster->cell_end();
				mLog << MSG::DEBUG << "Cell Iterator set" << endreq;
				int ncells_strips = 0;
				int ncells_middle = 0;
				// loop over all cells
				for( ;cellIter!=cellIterEnd;cellIter++) {
					const CaloCell* cell = (*cellIter) ;
					mLog << MSG::DEBUG << "Looping over cells" << endreq;
					Identifier id  = cell->ID();
					mLog << MSG::DEBUG << "Identifier: " << id << endreq;
					CaloCell_ID::CaloSample calo_sample=(CaloCell_ID::CaloSample)m_calo_helper->calo_sample(id) ;
					if ( calo_sample == CaloCell_ID::EMB1 )
					{
						ncells_strips++;
						barrel = true ;
					}
					else if ( calo_sample == CaloCell_ID::EMB2 )
					{
						ncells_middle++;
						barrel = true ;
					}
					else if ( calo_sample == CaloCell_ID::EME1 )
					{
						ncells_strips++;
						endcap = true ;
					}
					else if ( calo_sample == CaloCell_ID::EME2 )
					{
						ncells_middle++;
						endcap = true ;
					}
					else
					{
						mLog << MSG::ERROR << "all cells should be middle or strips ! " <<  m_calo_helper->calo_sample(id) << endreq;
					}
				}
				LAr_nbscells->push_back(ncells_strips);
				LAr_nbmcells->push_back(ncells_middle);


				if(barrel){
					LAr_eta1->push_back(cluster->etaSample(CaloSampling::EMB1));
					LAr_phi2->push_back(cluster->phiSample(CaloSampling::EMB2));
					LAr_eta2->push_back(cluster->etaSample(CaloSampling::EMB2));
					LAr_phi1->push_back(cluster->phiSample(CaloSampling::EMB1));
					LAr_senergy->push_back((float)cluster->eSample(CaloSampling::EMB1));

				}else
					if(endcap){
						LAr_eta1->push_back(cluster->etaSample(CaloSampling::EME1));
						LAr_phi2->push_back(cluster->phiSample(CaloSampling::EME2));
						LAr_eta2->push_back(cluster->etaSample(CaloSampling::EME2));
						LAr_phi1->push_back(cluster->phiSample(CaloSampling::EME1));
						LAr_senergy->push_back((float)cluster->eSample(CaloSampling::EME1));
					}
					else{
						LAr_eta1->push_back(-99999.);
						LAr_phi2->push_back(-99999.);
						LAr_eta2->push_back(-99999.);
						LAr_phi1->push_back(-99999.);
						LAr_senergy->push_back(-99999.);

						mLog << MSG::ERROR << " neither barrel nor endcap  " << endreq;
					}
				LAr_energy->push_back(cluster->energy());
				//      m_nbcells[index] = cluster->getNumberOfCells();;

				index++;
			}
			else
			{
				if (LAr_max_mu==index) {
					mLog << MSG::WARNING << " Too many LAr Mu Candidates. Save only "
						<< LAr_max_mu << endreq ;
					break ;
				}
			}
		}
		LAr_ncand = index;
		mLog << MSG::DEBUG << "nbr of mu candidates: " << LAr_ncand << endreq;


		mLog << MSG::DEBUG << "Post Loops" << endreq;
		t->Fill();
		mLog << MSG::DEBUG << "t->Fill success" << endreq;

				//	//RESET VECTORS//	//
		mu_spec_P->clear();
		mu_comb_P->clear();
		mu_id_P->clear();
		mu_spec_pt->clear();
		mu_comb_pt->clear();
		mu_id_pt->clear();
		mu_spec_phi->clear();
		mu_id_phi->clear();
		mu_comb_phi->clear();
		mu_spec_eta->clear();
		mu_id_eta->clear();
		mu_comb_eta->clear();
		mu_spec_E->clear();
		mu_id_E->clear();
		mu_comb_E->clear();
		mu_spec_x->clear();
		mu_id_x->clear();
		mu_comb_x->clear();
		mu_spec_y->clear();
		mu_id_y->clear();
		mu_comb_y->clear();
		mu_spec_z->clear();
		mu_id_z->clear();
		mu_comb_z->clear();
		mu_eloss->clear();		
		tile_e->clear();
		tile_path->clear();
		tile_phi->clear();
		tile_theta->clear();
		tile_x->clear();
		tile_y->clear();
		tile_z->clear();
		combmu_P->clear();
		combmu_phi->clear();
		combmu_eta->clear();
		combmu_x->clear();
		combmu_y->clear();
		combmu_z->clear();
		calomu_e->clear();
		LAr_ncand=0;
		LAr_eta1->clear();
		LAr_phi1->clear();
		LAr_eta2->clear();
		LAr_phi2->clear();
		LAr_energy->clear();
		LAr_nbmcells->clear();
		LAr_nbscells->clear();
		LAr_senergy->clear();
		tile_path_topA->clear();
		tile_path_bottomA->clear();
		tile_path_topBC->clear();
		tile_path_bottomBC->clear();
		tile_path_topD->clear();
		tile_path_bottomD->clear();
		tile_path_top->clear();
		tile_path_bottom->clear();
		tile_path_total->clear();
		tile_E_topA->clear();
		tile_E_bottomA->clear();
		tile_E_topBC->clear();
		tile_E_bottomBC->clear();
		tile_E_topD->clear();
		tile_E_bottomD->clear();
		tile_E_top->clear();
		tile_E_bottom->clear();
		tile_E_total->clear();

	 	mLog << MSG::DEBUG << "vector clear success" << endreq; 	
	
		return sc;
	}

	

	
	
	
	
	
	
	
	
	
