//////////////////////////////////////////////////////////
// This class has been automatically generated on
// Fri Dec 15 14:28:25 2006 by ROOT version 5.10/00e
// from TTree CollectionTree/CollectionTree
// found on file: SAN.root
//////////////////////////////////////////////////////////

#ifndef AnalysisSkeleton_h
#define AnalysisSkeleton_h

/******************************************************************************
Author: Ketevi A. Assamagan
Date: December 2006
Questions and comments: ketevi@bnl.gov
******************************************************************************/

#include <TROOT.h>
#include <TChain.h>
#include <TFile.h>
#include <TSelector.h>
#include <TH1F.h>

#include <vector>
#include <string>
#include <map>

#include "UserAnalysisEvent/TrackParticle.h"
#include "UserAnalysisEvent/CaloCluster.h"
#include "UserAnalysisEvent/Electron.h"
#include "UserAnalysisEvent/Muon.h"
#include "UserAnalysisEvent/Photon.h"
#include "UserAnalysisEvent/TauJet.h"
#include "UserAnalysisEvent/ParticleJet.h"
#include "UserAnalysisEvent/MissingET.h"
#include "UserAnalysisEvent/Neutrino.h"
#include "UserAnalysisEvent/RecVertex.h"
#include "UserAnalysisEvent/TruthParticle.h"
#include "UserAnalysisEvent/IParticle.h"

#include "UserAnalysisEvent/ElectronConstituent.h"
#include "UserAnalysisEvent/MuonConstituent.h"
#include "UserAnalysisEvent/JetConstituent.h"
#include "UserAnalysisEvent/TrackConstituents.h"
#include "UserAnalysisEvent/CaloClusterConstituents.h"
#include "UserAnalysisEvent/CaloSampling.h"

using namespace User;

static const double GeV = 1000.0;
static const double OverlapDeltaR = 0.2;

class AnalysisSkeleton : public TSelector {

 public:

  /** pointer to the analyzed TTree or TChain */
  TTree          *fChain;  
 
  /** constructor, desctror and user methods */
  AnalysisSkeleton(TTree * tree=0);
  virtual ~AnalysisSkeleton();
  virtual Int_t   Version() const { return 1; }
  virtual void    Begin(TTree *tree);
  virtual void    SlaveBegin(TTree *tree);
  virtual void    Init(TTree *tree);
  virtual Bool_t  Notify();
  virtual Bool_t  Process(Long64_t entry);
  virtual void    SetOption(const char *option) { fOption = option; }
  virtual void    SetObject(TObject *obj) { fObject = obj; }
  virtual void    SetInputList(TList *input) { fInput = input; }
  virtual TList  *GetOutputList() const { return fOutput; }
  virtual void    SlaveTerminate();
  virtual void    Terminate();

  /** User Modethods */
  void Reset();
  void Cleanup();
  void readEvent (Long64_t entry);
 
  void removeOverlaps(Long64_t entry);
  void muonOverlaps();
  void photonOverlaps();
  void electronOverlaps();
  void tauJetOverlaps();
  void particleJetOverlaps();
  void standAloneMuonOverlaps();
  void clear();
  double deltaR ( const IParticle * particle1, const IParticle * particle2 );
  double deltaR ( const IParticle & particle1, const IParticle & particle2 );

  /** matching to Monte Carlo truth - the function return 
      the deltaR of the match and the index of the match */
  bool matchToTruth ( const IParticle& particle, double& deltaR, 
		      unsigned int& index, const std::vector<TruthParticle>* mcTruth );

  bool matchToTruth ( const ParticleJet& jet, double& deltaR, 
		      unsigned int& index, const std::vector<TruthParticle>* mcTruth );

  /** Optional selection methods */
  bool selectTrackParticle ( const TrackParticle& track );
  bool selectCaloCluster   ( const CaloCluster& cluster );
  bool selectElectron      ( const Electron& electron );
  bool selectPhoton        ( const Photon& photon );
  bool selectMuon          ( const Muon& muon );
  bool selectTauJet        ( const TauJet& tauJet );
  bool selectParticleJet   ( const ParticleJet& jet );
  bool selectBTaggedJet    ( const ParticleJet& jet );
  bool isTrackIsolated     ( const TrackParticle& track );

 public:

  /** Athena-aware variables */
  Int_t     m_runNumber;
  TBranch * m_runNumberBranch;   

  Int_t     m_eventNumber;
  TBranch * m_eventNumberBranch;  

  Char_t    m_streamESD_ref;
  TBranch * m_streamESD_refBranch;   

  Char_t    m_stream1_ref[153];
  TBranch * m_stream1_refBranch;  

  Char_t    m_token[153];
  TBranch * m_tokenBranch;   

  Int_t     m_run;
  TBranch * m_runBranch;   

  Int_t     m_event;
  TBranch * m_eventBranch;   

  Int_t     m_time;
  TBranch * m_timeBranch;  

  Double_t  m_weight;
  TBranch * m_weightBranch;  

  Int_t     m_iEvent;
  TBranch * m_iEventBranch;   
 
  /** Reconstructed Vertices */
  std::vector<RecVertex> * m_recVertex;
  TBranch * m_recVertexBranch;

  /** Inner Det TrackParticle */
  std::vector<TrackParticle> * m_innerDetTrack;
  TBranch * m_innerDetTrackBranch;

  /** Muon TrackParticles */
  std::vector<TrackParticle> * m_muonSpectrometerTrack;
  TBranch * m_muonSpectrometerTrackBranch;

  std::vector<TrackParticle> * m_muonExTrack;
  TBranch * m_muonExTrackBranch;

  std::vector<TrackParticle> * m_muonCombinedTrack;
  TBranch * m_muonCombinedTrackBranch;

  std::vector<TrackParticle> * m_muonLowPtTrack;
  TBranch * m_muonLowPtTrackBranch;

  /** Calorimeter clusters */
  std::vector<CaloCluster> * m_lArClusterEM;
  TBranch * m_lArClusterEMBranch;

  std::vector<CaloCluster> * m_lArClusterEM37;
  TBranch * m_lArClusterEM37Branch;

  std::vector<CaloCluster> * m_lArClusterEMSofte;
  TBranch * m_lArClusterEMSofteBranch;

  std::vector<CaloCluster> * m_combinedCluster;
  TBranch * m_combinedClusterBranch;

  std::vector<CaloCluster> * m_emTopoCluster;
  TBranch * m_emTopoClusterBranch;

  std::vector<CaloCluster> * m_caloCalTopoCluster;
  TBranch * m_caloCalTopoClusterBranch;

  std::vector<CaloCluster> * m_lArClusterEMgam35;
  TBranch * m_lArClusterEMgam35Branch;

  std::vector<CaloCluster> * m_lArClusterEMgam;
  TBranch * m_lArClusterEMgamBranch;

  /** Electron */
  std::vector<Electron> * m_electron;
  TBranch * m_electronBranch;

  /** Photon */
  std::vector<Photon> * m_photon;
  TBranch * m_photonBranch;

  /** Muon */
  std::vector<Muon> * m_muon;
  TBranch * m_muonBranch;

  /** TauJet */
  std::vector<TauJet> * m_tauJet;
  TBranch * m_tauJetBranch;

  /** ParticleJet */
  std::vector<ParticleJet> * m_particleJet;
  TBranch * m_particleJetBranch;

  /** Missing ET */
  MissingET * m_missingEt;
  TBranch * m_missingEtBranch;

  /** TruthParticle */
  std::vector<TruthParticle> * m_truthParticle;
  TBranch * m_truthParticleBranch;

  /** Truth ParticleJet */
  std::vector<ParticleJet> * m_truthParticleJet;
  TBranch * m_truthParticleJetBranch;

  /** Truth Missing ET */
  MissingET * m_truthMissingEt;
  TBranch * m_truthMissingEtBranch;

  /** overlap removed containers */
  std::vector<Photon>      * m_nonOverlappingPhoton;
  std::vector<Electron>    * m_nonOverlappingElectron;
  std::vector<Muon>        * m_nonOverlappingMuon;
  std::vector<TauJet>      * m_nonOverlappingTauJet;
  std::vector<ParticleJet> * m_nonOverlappingParticleJet;

  /** counters */
  unsigned int m_nmuons;
  unsigned int m_nphotons;
  unsigned int m_nelectrons;
  unsigned int m_ntauJets;
  unsigned int m_njets;

  /** User Histograms for electrons */
  TH1F * m_electronPt;
  TH1F * m_electronEta;
  TH1F * m_electronPhi;
  TH1F * m_electronEoverP;
  TH1F * m_electronIsolationEt;
  TH1F * m_electronIsEM;
  TH1F * m_softElectronIsEM;
  TH1F * m_electronAuthor;
  TH1F * m_electronNumberOfPixelHits;
  TH1F * m_electronNumberOfSCTHits;
  TH1F * m_electronNumberOfTRTHits;
  TH1F * m_electronNumberOfTRTHighThresholdHits;
  TH1F * m_electronNumberOfBLayerHits;

  /** user Histograms for associated MC Truth */
  TH1F * m_mcElectronEta;
  TH1F * m_electronDeltaRMatch;
  TH1F * m_electronPtRatio;

  ClassDef(AnalysisSkeleton,0);

};

#endif

