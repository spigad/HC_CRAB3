#include <sstream>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <vector>

#include "TSystem.h"
#include "TTree.h"
#include "TBranch.h"
#include "TString.h"
#include "TCanvas.h"
#include "TKey.h"
#include "TFile.h"
#include "TClassTable.h"
#include "TStopwatch.h"

#include "UserAnalysisEvent/CovarianceMatrix.h"
#include "UserAnalysisEvent/ErrorMatrix.h"
#include "UserAnalysisEvent/FitQuality.h"
#include "UserAnalysisEvent/RecVertex.h"
#include "UserAnalysisEvent/TrackSummary.h"
#include "UserAnalysisEvent/MeasuredPerigee.h"
#include "UserAnalysisEvent/TrackParticle.h"

using namespace User;

void trackParticleAnalysis () {

  TFile *  f = new TFile("SAN.root");
  TTree *  tree = (TTree*)gDirectory->Get("CollectionTree");

  /** TrackParticle */
  std::vector<TrackParticle> * pTrack=0;
  tree->SetBranchAddress("TrackParticleCandidate",&pTrack);
  TBranch * trackBranch = tree->GetBranch("TrackParticleCandidate");

  /** measured Perigee */
  std::vector<MeasuredPerigee> * pPerigee=0;
  tree->SetBranchAddress("MeasuredPerigee",&pPerigee);
  TBranch * perigeeBranch = tree->GetBranch("MeasuredPerigee");

  /** reconstructed vertices */
  std::vector<RecVertex> * pVertex=0;
  tree->SetBranchAddress("VxPrimaryCandidate",&pVertex);
  TBranch * vertexBranch = tree->GetBranch("VxPrimaryCandidate");

  Long64_t nentries = tree->GetEntriesFast();
  int nbytes = 0; 
  int nb = 0;
  
  for (Long64_t jentry=0; jentry<nentries;jentry++) {

    std::cout << "Event Number = " << (jentry+1) << std::endl;
    std::cout << " " << std::endl;

    /** Read the RecVertices -
        If you do not need the vertices don't read them, it will run faster. */
    nb = vertexBranch->GetEntry(jentry);  nbytes += nb;

    /** Read the MeasuredPeriges -
        If you do not need the MeasurePerigee don't read, it will run faster. 
        The TrackParticle itself has the 4-Momentum so read the perigee only
        for details */
    nb = perigeeBranch->GetEntry(jentry);  nbytes += nb;

    /** Read the TrackParticles */
    nb = trackBranch->GetEntry(jentry);  nbytes += nb;

    /** loop over tracks and do something */
    std::vector<TrackParticle>::const_iterator trackItr  = pTrack->begin();
    std::vector<TrackParticle>::const_iterator trackItrE = pTrack->end();
    for (; trackItr != trackItrE; ++trackItr) {

      std::cout << "TrackParticle pt()   = " <<  (*trackItr).pt() << std::endl;
      std::cout << "TrackParticle eta() = " <<  (*trackItr).eta() << std::endl;
      std::cout << "TrackParticle phi() = " <<  (*trackItr).phi() << std::endl;
      std::cout << "TrackParticle charge() = " <<  (*trackItr).charge() << std::endl;

      /** reconstructed vertex */
      const RecVertex * vertex = (*trackItr).reconstructedVertex(); 
      if ( vertex ) {
         const TVector3 position = vertex->position();
	 std::cout << "vertex position X, Y, Z (mm) = " << position.X() << " " << position.Y() << " " 
      		   << position.Z() << std::endl;

         /** for release 13 and beyond 
	 const FitQuality quality = vertex->fitQuality();
	 std::cout << "Vertex Fit chi2 = " << quality.chiSquared() << std::endl;
	 std::cout << "Vertex Fit DoF = " << quality.numberDoF() << std::endl;
	 */

	 /** for release 12.0.5 */
	 const FitQuality * quality = (*trackItr).fitQuality();
	 std::cout << "Track Fit chi2 " << quality->chiSquared() << std::endl;
	 std::cout << "Track Fit DoF " << quality->numberDoF() << std::endl; 

         /** error matrix of the vertex */

         const ErrorMatrix positionError = vertex->errorPosition(); 
         const CovarianceMatrix matrix = positionError.covariance();
         int numCov = matrix.GetNrows();
         if ( numCov > 0 ) {
           for (int i=0; i< numCov; ++i) {
             for (int j=0; j< numCov; ++j) {
               std::cout <<"Error matrix on the vertex " << i << " " << j << " " << matrix[i][j] << std::endl;
             }
           }
         }

      }

      /** Origin type */
      std::cout << "TrackParticle Origin Type = " << (*trackItr).particleOriginType() << std::endl;
      
      /** Track Fit Quality */
      const FitQuality * quality = (*trackItr).fitQuality();
      std::cout << "Track Fit chi2 = " << quality->chiSquared() << std::endl;
      std::cout << "Track Fit DOF = " << quality->numberDoF() << std::endl;

      /** Track summary */
      const TrackSummary* summary = (*trackItr).trackSummary();
      if (summary) {
         std::cout <<" Track summary information:"<< std::endl;
         std::cout <<" * Number of B layer hits : "<<summary->get(numberOfBLayerHits)<< std::endl;
         std::cout <<" * Number of pixel hits : "<<summary->get(numberOfPixelHits)<<  std::endl;
         std::cout <<" * Number of pixel holes : "<<summary->get(numberOfPixelHoles)<< std::endl;
         std::cout <<" * Number of SCT hits : "<<summary->get(numberOfSCTHits)<<  std::endl;
         std::cout <<" * Number of SCT holes : "<<summary->get(numberOfSCTHoles)<<  std::endl;
         std::cout <<" * Number of TRT hits : "<<summary->get(numberOfTRTHits)<<  std::endl;
         std::cout <<" * Number of TRT high threshold hits : "<<summary->get(numberOfTRTHighThresholdHits) 
		   <<  std::endl; 
      } 

      /** Perigee parameters */
      /*
      const MeasuredPerigee* perigee = (*trackItr).measuredPerigee();
      if (perigee) {
         std::cout << "Trk::Perigee parameters:" << std::endl;
         TVector parameters = perigee->parameters();
         std::cout << " * d_0   : "<< parameters(d0)       << std::endl;
         std::cout << " * z_0   : "<< parameters(z0)       << std::endl;
         std::cout << " * phi   : "<< parameters(phi)      << std::endl;
         std::cout << " * Theta : "<< parameters(theta)    << std::endl;
         std::cout << " * q/p   : "<< parameters(qOverP)   << std::endl;
      }
      */

      std::cout << " " << std::endl;

    }
    std::cout << "------------------------------------- " << std::endl;
  }
  
  f->Close();
  
  return;
  
}
