#j.backend.requirements.cloud = 'IT'
#j.backend.CE= 'ce01.scope.unina.it:2119/jobmanager-lcgpbs-atlas'
#j.backend.CE= 'atlasce01.na.infn.it:2119/jobmanager-lcgpbs-atlas_short'
#j.backend.CE= 'ce-01.roma3.infn.it:2119/jobmanager-lcgpbs-atlas'
#j.backend.CE= 'atlas-ce-01.roma1.infn.it:2119/jobmanager-lcglsf-atlasglong'
#j.splitter = DQ2JobSplitter()
#j.splitter.numsubjobs = 25
#j.backend.requirements.sites=['']
j = Job()
j.application=Athena()
j.application.exclude_from_user_area=["*.o","*.root*","*.exe","BPhys"]
j.application.option_file=['MuonTriggerAnalysis.py' ]
j.application.max_events=250
j.inputdata=DQ2Dataset()
j.inputdata.dataset="mc08.105200.T1_McAtNlo_Jimmy.recon.AOD.e357_s462_r635_tid045663" #UK FR DE
#j.inputdata.dataset="mc08.105200.T1_McAtNlo_Jimmy.merge.AOD.e357_s462_r635_t53_tid064820" #UK
#j.inputdata.dataset="mc08.105200.T1_McAtNlo_Jimmy.merge.AOD.e357_s462_r635_t53_tid064823" #IT
#j.inputdata.dataset="mc08.105200.T1_McAtNlo_Jimmy.recon.AOD.e357_s462_r579_tid028663"
#j.inputdata.dataset="mc08.105200.T1_McAtNlo_Jimmy.merge.AOD.e357_s462_r635_t53_tid064815"
#j.inputdata.dataset="mc08.105200.T1_McAtNlo_Jimmy.recon.AOD.e357_s462_d147_r641_tid046049"#UK
#j.inputdata.dataset="mc08.105200.T1_McAtNlo_Jimmy.recon.AOD.e357_s462_d150_r642_tid046040"#DE UK 
j.outputdata=DQ2OutputDataset()
j.outputdata.outputdata=['muTri.root']
j.splitter=DQ2JobSplitter()
j.splitter.numsubjobs=20
j.merger=AthenaOutputMerger()
#j.backend=LCG()
#j.backend.requirements.cloud='DE'
j.backend = Panda()
j.backend.requirements.cloud = "DE"
#j.backend.CE='t2-ce-01.mi.infn.it:2119/jobmanager-lcgpbs-short'
j.application.prepare()
#j.submit()

#dq2-ls mc08.105200.T1_McAtNlo_Jimmy\*\AOD.e\*s\*\tid\* | grep -v sub
