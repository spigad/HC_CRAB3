////////////////////////////////////////////////////////////////////////////////// 
/// StructuredNTuple
/// Author: Ketevi A. Assamagan
/// BNL, July 22, 2006
///
/// DESCRIPTION:
///	Skeleton for making Structured NTuple
///
///////////////////////////////////////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////////////////////////////////////

#include "GaudiKernel/MsgStream.h"
#include "GaudiKernel/AlgFactory.h"
#include "GaudiKernel/IToolSvc.h"
#include "GaudiKernel/ListItem.h"

#include "GaudiKernel/System.h"

#include "UserAnalysisUtils/UserSANToolBase.h"

#include "UserAnalysis/StructuredAAN.h"

#include "TProcessID.h"
#include "TSystem.h"

#include <ios>
#include <iomanip>

//////////////////////////////////////////////////////////////////////////////////////
/// Constructor

StructuredAAN::StructuredAAN(const std::string& name,
  ISvcLocator* pSvcLocator) : Algorithm(name, pSvcLocator) {

  /** tool configuration */
  declareProperty("AlgTools",m_toolNames);

}


/////////////////////////////////////////////////////////////////////////////////////
/// Destructor 

StructuredAAN::~StructuredAAN() {}

////////////////////////////////////////////////////////////////////////////////////
/// Initialize
/// initialize StoreGate
/// get a handle on the analysis tools
/// book histograms

StatusCode StructuredAAN::initialize() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "Initializing StructuredAAN" << endreq;
  
  /** check tool names */
  if ( m_toolNames.size() == 0 ) {
    mLog << MSG::ERROR << "No tools given for this algorithm." << endreq;
    return StatusCode::FAILURE;
  }

  /** get a handle on the tool service */
  IToolSvc* toolSvc;
  StatusCode sc = service("ToolSvc",toolSvc);
  if (StatusCode::SUCCESS != sc) {
     mLog << MSG::ERROR << " Can't get ToolSvc" << endreq;
     return StatusCode::FAILURE;
  }

  /** find tools */
  std::vector<std::string>::const_iterator firstName = m_toolNames.begin();
  std::vector<std::string>::const_iterator lastName  = m_toolNames.end();
  for ( ; firstName != lastName; firstName++ ) {
    IAlgTool* algToolPtr;
    ListItem sanAlgTool(*firstName);
    sc = toolSvc->retrieveTool(sanAlgTool.type(),sanAlgTool.name(),algToolPtr,this);
    if ( sc.isFailure() ) {
      mLog << MSG::INFO
	   << "Cannot find tool named <" << *firstName << ">" << endreq;
    } else {
      UserSANToolBase* theTool = dynamic_cast< UserSANToolBase* >(algToolPtr);
      if ( theTool != 0 ) m_tools.push_back(theTool);
    } 
  }

  /** Check that there is at least one tool to execute */
  if ( m_tools.size() == 0 ) {
    mLog << MSG::ERROR << "Could not allocate any tools!" << endreq;
    return StatusCode::FAILURE;
  }

  /** print the list of tools */
  std::vector<UserSANToolBase*>::const_iterator firstTool = m_tools.begin();
  std::vector<UserSANToolBase*>::const_iterator lastTool  = m_tools.end();
  mLog << MSG::INFO << " " << endreq;
  mLog << MSG::INFO << "List of SAN Tools in execution sequence:" << endreq;
  mLog << MSG::INFO << "----------------------------------------" << endreq;
  mLog << MSG::INFO << " " << endreq;

  unsigned int toolCtr = 0;
  for ( ; firstTool != lastTool; ++firstTool ) {
    toolCtr++;
    mLog << MSG::INFO 
	 << std::setw(2)     << std::setiosflags(std::ios_base::right)
	 << toolCtr << ".) " << std::resetiosflags(std::ios_base::right)
	 << std::setw(36) << std::setfill('.') 
	 << std::setiosflags(std::ios_base::left) << (*firstTool)->type()
	 << std::setfill('.')
	 << (*firstTool)->name()
	 << std::setfill(' ')
	 << endreq;
  }

  mLog << MSG::INFO << " " << endreq;
  mLog << MSG::INFO << "----------------------------------------" << endreq;

  /** the last one builds the reference table */
  unsigned int nTools = m_tools.size();
  m_tools[nTools-1]->setIsLast();

  return StatusCode::SUCCESS;
}		 

///////////////////////////////////////////////////////////////////////////////////
/// Finalize

StatusCode StructuredAAN::finalize() {
  MsgStream mLog( messageService(), name() );
  return StatusCode::SUCCESS;

}

//////////////////////////////////////////////////////////////////////////////////
/// Execute - on event by event

StatusCode StructuredAAN::execute() {
  MsgStream mLog( messageService(), name() );
  
  mLog << MSG::DEBUG << "In execute()" << endreq;
  
  TProcessID::SetObjectCount(1);

  /** Execute the SAN tools */
  std::vector<UserSANToolBase*>::const_iterator firstTool = m_tools.begin();
  std::vector<UserSANToolBase*>::const_iterator lastTool  = m_tools.end();
  StatusCode sc = StatusCode::SUCCESS;
  for (; firstTool != lastTool; ++firstTool ) {
    sc = (*firstTool)->execute();
    if ( sc.isFailure() ) {
      mLog << MSG::ERROR
	   << "Problems while or after processing tool \042"
	   << (*firstTool)->name()
	   << endreq;
    }  
  }

  return StatusCode::SUCCESS;
}

