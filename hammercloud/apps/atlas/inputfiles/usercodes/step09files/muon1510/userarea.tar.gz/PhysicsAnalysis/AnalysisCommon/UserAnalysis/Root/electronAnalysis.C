#include <sstream>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <vector>

#include "TSystem.h"
#include "TTree.h"
#include "TBranch.h"
#include "TString.h"
#include "TCanvas.h"
#include "TKey.h"
#include "TFile.h"
#include "TClassTable.h"
#include "TStopwatch.h"

#include "UserAnalysisEvent/TrackParticle.h"
#include "UserAnalysisEvent/CaloCluster.h"
#include "UserAnalysisEvent/Electron.h"

using namespace User;

void electronAnalysis () {

  TFile *  f = new TFile("SAN.root");
  TTree *  tree = (TTree*)gDirectory->Get("CollectionTree");

  /** TrackParticle */
  std::vector<TrackParticle> * pTrack=0;
  tree->SetBranchAddress("TrackParticleCandidate",&pTrack);
  TBranch * trackBranch = tree->GetBranch("TrackParticleCandidate");

  /** EM CaloClusters */
  std::vector<CaloCluster> * pLArClusterEM=0;
  tree->SetBranchAddress("LArClusterEM",&pLArClusterEM);
  TBranch * clusEMBranch = tree->GetBranch("LArClusterEM");

  std::vector<CaloCluster> * pLArClusterEM37=0;
  tree->SetBranchAddress("LArClusterEM37",&pLArClusterEM37);
  TBranch * clusEM37Branch = tree->GetBranch("LArClusterEM37");

  std::vector<CaloCluster> * pLArClusterEMSofte=0;
  tree->SetBranchAddress("LArClusterEMSofte",&pLArClusterEMSofte);
  TBranch * clusEMSofteBranch = tree->GetBranch("LArClusterEMSofte");

  /** Electron */
  std::vector<Electron> * pElectron=0;
  tree->SetBranchAddress("ElectronCollection",&pElectron);
  TBranch * elecBranch = tree->GetBranch("ElectronCollection");

  Long64_t nentries = tree->GetEntriesFast();
  int nbytes = 0; 
  int nb = 0;
  
  for (Long64_t jentry=0; jentry<nentries;jentry++) {

    std::cout << "Event Number = " << (jentry+1) << std::endl;
    std::cout << " " << std::endl;

    /** Read the Tracks */
    nb = trackBranch->GetEntry(jentry);  nbytes += nb;

    /** Read the EM clusters */
    nb = clusEMBranch->GetEntry(jentry);       nbytes += nb;
    nb = clusEM37Branch->GetEntry(jentry);     nbytes += nb;
    nb = clusEMSofteBranch->GetEntry(jentry);  nbytes += nb;

    /** Read the Electron */
    nb = elecBranch->GetEntry(jentry);   nbytes += nb;    

    /** Loop over Electrons and do something */
    std::vector<Electron>::const_iterator elecItr = pElectron->begin();
    std::vector<Electron>::const_iterator elecItrE = pElectron->end();
    for (; elecItr != elecItrE; ++elecItr) {

      std::cout << "Electron pt()  = " <<  (*elecItr).pt() << std::endl;
      std::cout << "Electron eta() = " <<  (*elecItr).eta() << std::endl;
      std::cout << "Electron phi() = " <<  (*elecItr).phi() << std::endl;

      /** The Electron Track */
      const TrackParticle * track = (*elecItr).track();
      if (track) {
        std::cout << "Electron charge is from the track = " << track->charge() << std::endl;
      } 

      /** The Electron Cluster */
      const CaloCluster * cluster = (*elecItr).cluster();
      if (cluster) {
        std::cout << "Electron cluster energy = " << cluster->e() << std::endl;
      }

      /** The E over P over the Electron */
      if ( cluster && track) {
         std::cout << "The E_over_P of the Electron is = " << (cluster->e() / track->p()) << std::endl;
      }

      /** Access to more Electron data */
      std::cout << "Electron number of PIX hits = " <<  (*elecItr).numberOfPixelHits() << std::endl;
      std::cout << "Electron number of SCT hits = " <<  (*elecItr).numberOfSCTHits() << std::endl;
      std::cout << "Electron number of TRT hits = " <<  (*elecItr).numberOfTRTHits() << std::endl;
      std::cout << "Electron number of TRH hits = " <<  (*elecItr).numberOfTRTHighThresholdHits() << std::endl;
      std::cout << "Electron number of BLA hits = " <<  (*elecItr).numberOfBLayerHits() << std::endl;
      std::cout << "Electron isEM = " << (*elecItr).isEM() << std::endl;
      std::cout << "Electron isolation in cone 0.45= " <<  (*elecItr).parameter(electronParameters::etcone) << std::endl;
      std::cout << "Electron author = " <<  (*elecItr).author() << std::endl;
      
      std::cout << " " << std::endl;
    }
    std::cout << "------------------------------------- " << std::endl;
  }
  
  f->Close();
  
  return;
  
}
