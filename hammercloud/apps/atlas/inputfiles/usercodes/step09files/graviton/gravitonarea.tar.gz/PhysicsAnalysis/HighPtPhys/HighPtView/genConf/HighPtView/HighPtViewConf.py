#Fri May 29 20:10:36 2009
"""Automatically generated. DO NOT EDIT please"""
from GaudiKernel.Proxy.Configurable import *
