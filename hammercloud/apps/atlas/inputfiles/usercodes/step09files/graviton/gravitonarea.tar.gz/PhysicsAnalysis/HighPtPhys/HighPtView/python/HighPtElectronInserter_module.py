from AthenaCommon.SystemOfUnits import GeV
from HighPtView.HighPtInserterBase_module import *
from EventViewInserters import egammaPID

class HighPtElectronInserter(HighPtInserterBase):

  def setAffiliation(self):
    self._group = "EV Team"
    self._author = "AS"
    self._description = "Electron Inserter with HighPt configuration"

  def __init__(self, name, mode="FullReco", Configuration=None, override={}):

    DefaultConfiguration={ "FullReco":
                           [  {"Name":"ElLoose", # Loose
                              "Configuration":
                              { "ContainerKey":"ElectronAODCollection",
                                "etCut":15*GeV,
                                "useIsEM":True,
                                "isEMMasks":[egammaPID.ElectronLoose],
                                "RejectLabels":["Muon"],
                                "RemoveOverlapWithSameType" : False,

                                "InsertedLabels":["Electron","Lepton"]}},
                             {"Name":"ElMedium", # Medium
                              "Configuration":
                              { "ContainerKey":"ElectronAODCollection",
                                "etCut":15*GeV,
                                "useIsEM":True,
                                "isEMMasks":[egammaPID.ElectronMedium],
                                "RejectLabels":["Muon"],
                                "RemoveOverlapWithSameType" : False,
                                "InsertedLabels":["Electron","Lepton"]}},
                             {"Name":"ElTight", # This is the original configuration for HPTV, corresponds to tight
                              "Configuration":
                              { "ContainerKey":"ElectronAODCollection",
                                "etCut":15*GeV,
                                "useIsEM":True,
                                "isEMMasks":[egammaPID.ElectronTight],
                                "RejectLabels":["Muon"],
                                "RemoveOverlapWithSameType" : False,
                                "InsertedLabels":["Electron","Lepton"]}}
                             ],
                           "FastSim":
                           [ {"Name":"ElDefault",
                              "Configuration":
                              {"ContainerKey":"AtlfastElectronCollection",
                               "etCut":15*GeV,
                               "DoPreselection":False,
                               "deltaRCut":.1,
                               "RemoveOverlapWithSameType" : False,
                               #"RemoveOverlapWithMuon" : False,
                               "InsertedLabels":["Atlfast", "Electron","Lepton"]}}
                             ]}
    
    HighPtInserterBase.__init__(self, name, "EVElectronInserter", mode, DefaultConfiguration, Configuration, override)


      
