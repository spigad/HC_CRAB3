from ROOT import ceil,TCanvas,TLegend
import ROOT

class NiceEfficiencyPlots:
    def __init__(self,results,vars=["p_T","eta","phi"],MinFigs=1,
                 MaxFigs=3,MaxPlotsPerFig=8,LogCutoff=.2,FitFunc="pol0",SortParam=0,MinValue=0.,
                 HistRequire="Eff_",HistAttributes=[],HistMin=-1,HistMax=-1,
                 PrintPrefix="",PrintType=".gif"):
        self.results=results
        self.vars=vars
        self.MaxFigs=MaxFigs
        self.MaxPlotsPerFig=MaxPlotsPerFig
        self.LogCutoff=LogCutoff
        self.FitFunc=FitFunc
        self.SortParam=SortParam
        self.MinValue=MinValue
        self.MinFigs=MinFigs
        self.HistRequire=HistRequire
        self.HistMin=HistMin
        self.HistMax=HistMax
        self.PrintPrefix=PrintPrefix
        self.PrintType=PrintType
        
        MS=.7
        if not len(HistAttributes)==0:
            self.DefaultAttributes=HistAttributes
        else:
            self.DefaultAttributes=[{ "LineColor":2 ,  "MarkerColor":2, "MarkerStyle":20, "MarkerSize":MS},
                                    { "LineColor":4 ,  "MarkerColor":4, "MarkerStyle":21, "MarkerSize":MS},
                                    { "LineColor":1 ,  "MarkerColor":1, "MarkerStyle":22, "MarkerSize":MS},
                                    { "LineColor":3 ,  "MarkerColor":3, "MarkerStyle":23, "MarkerSize":MS},
                                    { "LineColor":11,  "MarkerColor":11,"MarkerStyle":24, "MarkerSize":MS},
                                    { "LineColor":6 ,  "MarkerColor":6, "MarkerStyle":25, "MarkerSize":MS},
                                    { "LineColor":7 ,  "MarkerColor":7, "MarkerStyle":26, "MarkerSize":MS},
                                    { "LineColor":8 ,  "MarkerColor":8, "MarkerStyle":27, "MarkerSize":MS}
                                    ]
            
        self.FitParams={}

    def FindHists(self,thelist,prefix):
        out = []
        for item in thelist:
            if item.find(prefix)==0:
                out+=[thelist[item]]
        return out

    def FitHists(self,hists):
        for hist in hists:
            hist.Fit(self.FitFunc,"q")

    def FitParam(self,hist):
        hname=hist.GetName()
        if self.FitParams.has_key(hname):
            return self.FitParams[hname][0]

        if "Efficiency" in dir(hist):
            e=hist.EfficiencyErr
            v=hist.Efficiency
        elif "XSection" in dir(hist):
            v=hist.XSection
            e=hist.XSectionErr
        else:
            hist.Fit(self.FitFunc,"q")
            f=hist.GetListOfFunctions().pop()
            v=f.GetParameter(self.SortParam)
            e=f.GetParError(self.SortParam)
            
        self.FitParams[hname]=[v,e]
        
        return v

    def SortHists(self,hists):
        def Compare(x,y):
            a=self.FitParam(x)
            b=self.FitParam(y)
            return cmp(b,a)

        hists.sort(Compare)

    def NicePrintGroup(self,groups):
        I=0
        for group in groups:
            print "Group", I,":"
            self.NicePrint(group)
            I+=1

    def NicePrint(self,hists):
        for hist in hists:
            print hist.GetName(),self.FitParam(hist)

    def FindLastPlottable(self,Hists):
        for i in xrange(0,len(Hists)):
#            print i,self.FitParam(Hists[i]),self.MinValue
            if self.FitParam(Hists[i])<=self.MinValue:
                return i

        return len(Hists)

    def FindHistsForLogPlot(self,Hists):
        for i in xrange(len(Hists)-1,-1,-1):
          #  print i,self.FitParam(Hists[i]),self.LogCutoff
            if self.FitParam(Hists[i])>self.LogCutoff:
                return i+1

        return len(Hists)

    def CalcNumGroupsAndHists(self,NHists):
        NGroups=int(ceil(float(NHists)/float(self.MaxPlotsPerFig)))

        if NGroups<=self.MinFigs:
            NGroups=self.MinFigs

        if NGroups<1:
            NGroups=1

        NHistsPerGroup=ceil(float(NHists)/float(NGroups))

        if NGroups>self.MaxFigs or NHistsPerGroup>self.MaxPlotsPerFig:
            print "Warning: Cannot fit",NHists,"into", self.MaxFigs, "figures with",
            print self.MaxPlotsPerFig, "in each figure. Dropping histograms."

            NGroups=self.MaxFigs
            NHistsPerGroup=self.MaxPlotsPerFig

        return [NGroups,NHistsPerGroup]

    def MakeHistGroups(self,Hists):
        NHists=len(Hists)
        [NGroups,NHistsPerGroup]=self.CalcNumGroupsAndHists(NHists)

        HistI=0

        Groups=[]
        
        for GroupI in xrange(0,NGroups):
            Groups+=[[]]
            while HistI<NHists and len(Groups[GroupI])<NHistsPerGroup:
                Groups[GroupI]+=[Hists[HistI]]
                HistI+=1

        if not HistI==NHists:
            print "Warning: Placed",HistI,"out of",NHists,"histograms into figures."
                
        return Groups

    def ApplyToHistInGroup(self,HistGroup,func):
        for Group in HistGroup:
            for Hist in Group:
                func(Hist)

    def GroupHists(self, Hists):
        Groups=[]
        
        LastPlottable=self.FindLastPlottable(Hists)

        if LastPlottable<0:
            print "No Good Hists to plot!"
            return []

        FirstLog=self.FindHistsForLogPlot(Hists)

        GoodHists=Hists[:FirstLog]
        LogHists=Hists[FirstLog:LastPlottable]

        GoodHistsGroup=self.MakeHistGroups(GoodHists)
        LogHistsGroup=self.MakeHistGroups(LogHists)

#        print "LogHists",len(LogHists), len(LogHistsGroup)
        return [GoodHistsGroup,LogHistsGroup]
    
    def GetPlots(self, require):
        Hists=self.FindHists(self.results,self.HistRequire+require)
        self.SortHists(Hists)

        #self.NicePrint(Hists)

        print "Found",len(Hists),"histograms statisfying,",self.HistRequire+require
        return Hists
        
    def GetHistsPerVar(self, require):
        PlotVarGroups=[]
        for var in self.vars:
            PlotVarGroups+=[self.GetPlots(require+var)]

        return PlotVarGroups

    def CanvasSize(self,NFigs):
        x=1
        y=1
        toggle=False
        while x*y<NFigs:
            if toggle:
                x+=1
            else:
                y+=1
            toggle=not toggle

        return [x,y]

    def PadID(self,x,y,I):
        II=0
        for yI in xrange(0,y):
            for xI in xrange(0,x):
                if I==II:
                    return [xI,yI]
                II+=1

    def SetHistAttributes(self,Hist,I):
        Hist.SetStats(0)
        Title=Hist.GetTitle()
        Hist.SetTitle(Title[:Title.find("__")])
        for attribute in self.DefaultAttributes[I]:
            eval("Hist.Set"+attribute+"("+str(self.DefaultAttributes[I][attribute])+")")

    def LegendString(self,hist):
        HName=hist.GetName()
        i=HName.find("__")
        if i>-1 and i+2<len(HName):
            s=HName[i+2:]
        else:
            s=HName

        if s.find("_Matched")>0:
            s=s[:s.find("_Matched")]

        fp=self.FitParams[HName]
        
        vals=`" %(v)1.3f #pm %(e)1.3f"` %{"v":fp[0],"e":fp[1]}

        return "#splitline{"+s+"}{"+vals[1:-1]+"}"

    def LegendString2(self,hist):
        HName=hist.GetName()

        fp=self.FitParams[HName]
        
        vals=`" %(v)1.3f #pm %(e)1.3f"` %{"v":fp[0],"e":fp[1]}

        
        return vals[1:-1]

    def PlotGroup(self,Canvas,PadI,Group,Min=-1.,Max=-1):
        Pad=Canvas.cd(PadI)
        Pad.SetRightMargin(.3)
        first=True

        NHists=len(Group)
        
#        Legend=TLegend(0.8,0.95-.1*NHists,.95,.95);
        Legend=TLegend(0.72,0.1,.98,.98);
        ROOT.SetOwnership(Legend,False)
        
        I=0
        for Hist in Group:
            if Min>0.:
                Hist.SetMinimum(Min)
            if Max>0.:
                Hist.SetMaximum(Max)

            self.SetHistAttributes(Hist,I)
            Legend.AddEntry(Hist,self.LegendString(Hist))
#            Legend.AddEntry(Hist,self.LegendString2(Hist))
            if first:
                Hist.Draw("e")
            else:
                Hist.Draw("e,same")
            first=False
            I+=1

        Legend.Draw()


        return I

    def PlotGroups(self,name,HistGroup,LogHistGroup):
        NFigures=len(HistGroup)+len(LogHistGroup)
        
        Canvas=TCanvas(name,name,0,0,1024,768)
        ROOT.SetOwnership(Canvas,False)
        [x,y]=self.CanvasSize(NFigures)
        Canvas.Divide(x,y)

        PadI=1

        for Group in HistGroup:
            NPlotted=self.PlotGroup(Canvas,PadI,Group,self.HistMin,self.HistMax)
            PadI+=1

        for Group in LogHistGroup:
            NPlotted=self.PlotGroup(Canvas,PadI,Group)
            if NPlotted>0:
                if Canvas.GetPad(PadI) != None:
                    Canvas.GetPad(PadI).SetLogy()
            PadI+=1

        if not self.PrintPrefix=="":
            Canvas.Print(self.PrintPrefix+name+self.PrintType)


    def PlotAll(self,require):
        VarGroups=self.GetHistsPerVar(require)

        I=0
        for VarGroup in VarGroups:
            GroupedHists=self.GroupHists(VarGroup)
            if len(GroupedHists)>0:
                print "Plotting ",require+self.vars[I]
                print "-----------------------------------------------"
                self.NicePrintGroup(GroupedHists[0])
                print "Log Plots:"
                self.NicePrintGroup(GroupedHists[1])
                self.PlotGroups(require+self.vars[I],GroupedHists[0],GroupedHists[1])
            I+=1
            
        
    

