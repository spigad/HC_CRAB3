from HighPtView.HighPtViewModule import *
from EventViewConfiguration.DefaultModules.TruthParticleUDInfo_module import *
from EventViewConfiguration.DefaultModules.JetUDInfo_module import *


class HighPtTruthCalculator(HighPtViewModule):

  def setAffiliation(self):
    self._group = "EV Team"
    self._author = "AS"
    self._description = "Truth object data calculators"
  
  def __init__(self, name, onlyKin=True, recoMatch=True, MatchEV="RecoView",
               JetContainers=[["Kt6_","KtTruthJets","Kt6"],
                              ["Kt4_","Kt4TruthJets","Kt4"],
                              ["C7_","ConeTruthJets","Cone7"],
                              ["C4_","Cone4TruthJets","Cone4"],
                              ],
               Labels={}):
    self.MatchEV=MatchEV
    self.onlyKin=onlyKin
    self.JetContainers=JetContainers
    self.RecoMatch=recoMatch
    self.Labels=Labels
    HighPtViewModule.__init__(self, name)

  def GetLabels(self,name):
    if self.Labels.has_key(name):
      return self.Labels[name]
    else:
      return []
  
  def schedule(self):  
    
    if self.onlyKin:
      detailLevel=["Kinematics"]
    else:
      detailLevel=["FullStandardAOD"]

    detailLevelJets=["Kinematics"]
    
    if self.RecoMatch:
      detailLevel+=["RecoMatch"] #"CheckLabels"] This doesn't work... need a new EVUDLabelCalc tool
      detailLevelJets+=["RecoMatch"]
      
    self += TruthParticleUDInfo("El_T_Info", Level=detailLevel, Prefix="El_", RequireLabels=["Truth", "Stable", "Electron"],
                                RecoEVName=self.MatchEV, RecoType="Electron", matchR=0.05, MatchLabels=self.GetLabels("Electron"))
    self += TruthParticleUDInfo("Mu_T_Info", Level=detailLevel, Prefix="Mu_", RequireLabels=["Truth", "Stable", "Muon"],
                                RecoEVName=self.MatchEV, RecoType="Muon", matchR=0.05, MatchLabels=self.GetLabels("Muon"))
    self += TruthParticleUDInfo("Ph_T_Info", Level=detailLevel, Prefix="Ph_", RequireLabels=["Truth", "Stable", "Photon"],
                                RecoEVName=self.MatchEV, RecoType="Photon", matchR=0.1, MatchLabels=self.GetLabels("Photon"))

    # Oops! Truth Taus are composite not truth particles! Should be OK... but not optimal. Fix this.
    self += TruthParticleUDInfo("Tau_T_Info", Level=detailLevel, Prefix="Tau_", RequireLabels=["TruthTau", "Stable"],
                                RecoEVName=self.MatchEV, RecoType="TauJet", matchR=0.1, MatchLabels=self.GetLabels("Tau"))

    for JetC in self.JetContainers:
      self += JetUDInfo(JetC[0]+"Jet_T_Info",Level=detailLevelJets,RecoEVName=self.MatchEV,RecoType="Jet",matchR=0.3,
                                RequireLabels=["TruthJet",JetC[2]],MatchRequireLabels=["Jet", JetC[2]], Prefix="Jet_"+JetC[0])


    self += TruthParticleUDInfo("UnStable_T_Info", Level=["FullStandardAOD"], Prefix="Sp_",
                                RejectLabels=["Stable", "Jet"])
    
