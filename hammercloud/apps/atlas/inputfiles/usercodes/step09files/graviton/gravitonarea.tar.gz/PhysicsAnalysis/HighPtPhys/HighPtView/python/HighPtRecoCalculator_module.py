from HighPtView.HighPtViewModule import *
from EventViewConfiguration.DefaultModules.ElectronUDInfo_module import *
from EventViewConfiguration.DefaultModules.MuonUDInfo_module import *
from EventViewConfiguration.DefaultModules.PhotonUDInfo_module import *
from EventViewConfiguration.DefaultModules.TauJetUDInfo_module import *
from EventViewConfiguration.DefaultModules.JetUDInfo_module import *

class HighPtRecoCalculator(HighPtViewModule):

  def setAffiliation(self):
    self._group = "EV Team"
    self._author = "AS"
    self._description = "Reco object data calculators"
  
  def __init__(self, name, onlyKin=False, DetailLevel=["BasicAOD"],
               truthMatch=True,TruthEVName="TruthView",
               JetContainers=[["Kt6_","Kt6TruthJets","Kt6"],
                              ["Kt4_","Kt4TruthJets","Kt4"],
                              ["C7_","ConeTruthJets","Cone7"],
                              ["C4_","Cone4TruthJets","Cone4"],
                                                            ],
               triggerMatch=True,triggerLevels=[ "L1", "L2", "EF",
                                                 "Muon", "E/Gamma", "Electron", "Photon", "Tau",
                                                 "Jet", "MissingEt" ],
               saveHLTMET=False,
               Labels={}
               ):
    self.onlyKin=onlyKin
    self.JetContainers=JetContainers
    self.TriggerMatch=triggerMatch
    self.TriggerLevels=triggerLevels
    self.TruthMatch=truthMatch
    self.TruthEVName=TruthEVName
    self.DetailLevel=DetailLevel
    self.SaveHLTMET=saveHLTMET
    self.Labels=Labels
    HighPtViewModule.__init__(self, name)

  def GetLabels(self,name):
    if self.Labels.has_key(name):
      return self.Labels[name]
    else:
      return []

  def schedule(self):  
    
    if self.onlyKin:
      detailLevel=["Kinematics"]
    else:
      detailLevel=self.DetailLevel

    if self.TruthMatch:
      detailLevel+=["TruthEVMatch"]

    if self.TriggerMatch:
      detailLevel+=["TriggerMatch",
                    "El_L1_TriggerL1RoIAssoc:FullStandardAOD",
                    "Ph_L1_TriggerL1RoIAssoc:FullStandardAOD",
                    "Mu_L1_TriggerL1RoIAssoc:FullStandardAOD",
                    "Tau_L1_TriggerL1RoIAssoc:FullStandardAOD",
                    "Jet_L1_TriggerL1RoIAssoc:FullStandardAOD",
                    
                    "El_L2_TriggerL2Assoc:FullStandardAOD",
                    "Ph_L2_TriggerL2Assoc:FullStandardAOD",
                    "Mu_L2_TriggerL2Assoc:FullStandardAOD",
                    "Tau_L2_TriggerL2Assoc:FullStandardAOD",
                    "Jet_L2_TriggerL2Assoc:FullStandardAOD",
                    
                    "El_EF_TriggerEFAssoc:FullStandardAOD",
                    "Ph_EF_TriggerEFAssoc:FullStandardAOD",
                    "Mu_EF_TriggerEFAssoc:FullStandardAOD",
                    "Tau_EF_TriggerEFAssoc:FullStandardAOD",
                    "Jet_EF_TriggerEFAssoc:FullStandardAOD",
                    ]

    detailLevel+=["CheckLabels"]
#    print detailLevel
      
    self += ElectronUDInfo("El_Info", Level=detailLevel, TruthEVName=self.TruthEVName, Labels=self.GetLabels("Electron"))
    self += PhotonUDInfo("Ph_Info", Level=detailLevel, TruthEVName=self.TruthEVName, Labels=self.GetLabels("Photon"))
    self += MuonUDInfo("Mu_Info", Level=detailLevel, TruthEVName=self.TruthEVName, Labels=self.GetLabels("Muon"))
    self += TauJetUDInfo("Tau_Info", Level=detailLevel, TruthEVName=self.TruthEVName, Labels=self.GetLabels("Tau"))
    for JetContainer in self.JetContainers:
      self += JetUDInfo("Jet_Info_"+JetContainer[0],
                                Level=detailLevel,
                                TruthEVName=self.TruthEVName,
                                MatchRequireLabels=["TruthJet",JetContainer[2]],
                                TruthJetContainers=[JetContainer],
                                RequireLabels=["Jet",JetContainer[2]],
                                Prefix="Jet_"+JetContainer[0],
                                Labels=self.GetLabels("Jet"))

###    for JetContainer in self.JetContainers:
###      self += JetUDInfo("Jet_Info_"+JetContainer[0],
###                        Level=detailLevel,
###                        TruthEVName=self.TruthEVName,
###                        MatchRequireLabels=["TruthJet",JetContainer[2]],
###                        TruthJetContainers=[JetContainer],
###                        RequireLabels=["Jet",JetContainer[2]],
###                        Prefix="Jet_"+JetContainer[0],
###                        Labels=self.GetLabels("Jet"))



    if self.TriggerMatch:

###      self += [EVTriggerDecisionUserData("EVTriggerDecision")]
###
###      self.EVTriggerDecision.setProperties(TriggerDecisionKey="MyTriggerDecision",
###                                           CopyAllSignatures=True,
###                                           UseInt=True
###                                           #TriggerNames=["E25i"]
###                                           )

      self += [EVL1MissingEtUserData("L1MissingEtUserData" )]

      if self.SaveHLTMET:
        self += [EVHLTMissingEtUserData("HLTMissingEtUserData" )]
        
        self.HLTMissingEtUserData.setProperties(ObjectKey="TrigEFMissingET")
