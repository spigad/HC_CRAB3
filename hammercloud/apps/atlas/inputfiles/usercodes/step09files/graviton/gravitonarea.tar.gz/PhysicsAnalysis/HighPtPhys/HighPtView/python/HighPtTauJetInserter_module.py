from AthenaCommon.SystemOfUnits import GeV
from HighPtView.HighPtInserterBase_module import *

class HighPtTauJetInserter(HighPtInserterBase):

  def __init__(self, name, mode="FullReco,TauRec", Configuration=None, override={}):

    from EventViewInserters import TauJetParameters   

    DefaultConfiguration={ "FullReco,TauRec":
                           [ {"Name":"TauDefault", # This is the original configuration for HPTV
                              "Configuration": 
                              {"ContainerKey":"TauRecContainer",
                               "etCut":30*GeV,
                               "ParamPID_CutList": [TauJetParameters.Likelihood,TauJetParameters.TauElTauLikelihood],
                               "ParamPID_CutValues": [4,0],
                               "ParamPID_CutIsGreaterThan":[True,True],
                               "ParamVetoFlags_CutList": [], 
                               "MultiTrackMassCut":999*GeV,
                               "RequireChargeToBeOne":False,
                               "Require3orLessTracks": False,
                               # not applying hadronic energy fraction
                               "HadronicEnergyFraction":-1,
                               "RequireChargeToBeOne":True,
                               "deltaRCut":.1,
                               "MultiTrackMassCut":1400*GeV,
                               "RemoveOverlapWithSameType" : False,
                               "InsertedLabels":["TauRec", "TauJet","Lepton"],
                               }}],
                           "FullReco,Tau1p3p":
                           [ {"Name":"TauDefault", # This is the original configuration for HPTV
                              "Configuration": 
                              {"ContainerKey":"Tau1P3PContainer",
                               "etCut":15*GeV,
                               "onlyTauRec": False,
#                               "ParamPID_CutList" : [TauJetParameters.DiscCut],
#                               "ParamPID_CutValues" : [0.5],
                               "ParamPID_CutList" : [TauJetParameters.DiscNN],
                               "ParamPID_CutValues" : [0.2],                               
                               "ParamPID_CutIsGreaterThan" : [True],
                               "ParamVetoFlags_CutList" : [TauJetParameters.ElectronFlag, TauJetParameters.MuonFlag],
                               "MultiTrackMassCut":1.5*GeV,
                               "RequireChargeToBeOne":True,
                               "Require3orLessTracks": False,
                               # not applying hadronic energy fraction
                               "HadronicEnergyFraction":-1,
                               "deltaRCut":.1,
                               "MultiTrackMassCut":1400*GeV,
                               "RemoveOverlapWithSameType" : False,
                               "InsertedLabels":["1p3p", "TauJet","Lepton"],
                               }}],
                           "FastSim,TauRec":
                           [ {"Name":"TauDefault", # This is the original configuration for HPTV
                              "Configuration": 
                              {"ContainerKey":"AtlfastTauJetContainer",
                               "DoPreselection":False,
                               "InsertedLabels":["Atlfast", "TauJet","Lepton", "TauRec"],
                               "etCut":30*GeV,
                               }}],
                           "FastSim,1p3p":
                           [ {"Name":"TauDefault", # This is the original configuration for HPTV
                              "Configuration": 
                              {"ContainerKey":"AtlfastTauJetContainer",
                               "DoPreselection":False,
                               "InsertedLabels":["Atlfast", "1p3p","Lepton", "TauRec"],
                               "etCut":15*GeV,
                               "onlyTauRec": False,
                               "ParamPID_CutList":[TauJetParameters.DiscNN],
                               "ParamPID_CutValues":[0.2],
                               }}]
                           }
    HighPtInserterBase.__init__(self, name, "EVTauJetInserter", mode, DefaultConfiguration, Configuration, override)
