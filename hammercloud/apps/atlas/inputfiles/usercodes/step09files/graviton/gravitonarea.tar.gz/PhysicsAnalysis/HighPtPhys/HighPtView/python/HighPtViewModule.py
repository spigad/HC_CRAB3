##################################################################
#
# File: TopView/python/TopViewModuleBase.py
# Author: Akira Shibata (ashibata@cern.ch)
#
##################################################################

from AthenaCommon.SystemOfUnits import GeV
from AthenaCommon.Logging import logging
from AthenaCommon.Constants import *
from EventViewConfiguration.EVModule import *
from EventViewConfiguration.EVTool import *

class HighPtViewModule(EVModule):

  """ Interface for HighPtView modules

      author: Akira Shibata (ashibata@cern.ch)

  This class provides some interface for creating your own tool
  out of a combination of the "EventViewBuilder" tools.

  Inherit from this class and implement schedule() and setEVDefaults() 
  methods which schedules EVtools to the given looper and set default 
  parameters respectively.

  self.__attributes are the EVtools that are used in this module
  and are accessible through getAttribute. You can decide not to 
  put small tools into self.__attributes and make it invisible from
  outside."""

  
  def __init__(self, name=""):
    EVModule.__init__(self, name)        
    
  def setAffiliation(self):
    self._group = "HighPt"
    self._author = "EentViewTeam"
    self._description = "HighPtView Module"

