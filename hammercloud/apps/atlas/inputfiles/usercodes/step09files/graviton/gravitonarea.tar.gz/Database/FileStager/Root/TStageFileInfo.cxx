#include "FileStager/TStageFileInfo.h"

ClassImp(TStageFileInfo)

