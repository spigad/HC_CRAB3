from SPyRoot import TTreeAlgorithm,TTreeHelpers
from ROOT import *

class EfficiencyPlotter(TTreeAlgorithm):
    def __init__(self,name, Vars, NObjVar,  BaseLineCut, BaseLineCutObj, Cuts, Branches=["*"]):
        self.Vars= Vars

        self.Cuts=[]
        self.CutNames=[]
        
        for Cut in Cuts:
            if isinstance(Cut,list):
                self.CutNames+=[Cut[0]]
                self.Cuts+=[Cut[1]]
            else:
                self.CutNames+=[Cut]
                self.Cuts+=[Cut]
        
        self.BaseLineCut=BaseLineCut
        self.BaseLineCutObj=BaseLineCutObj
        self.NObjVar=NObjVar
        self.NEvents=0
        self.ThisEventFilledHists={}
        TTreeAlgorithm.__init__(self,name,Branches)

    def SetHistTitles(self,Var,Hist,Norm="Events"):
        if len(Var) > 4:
            Units=Var[4]
        else:
            Units=""
            
        Hist.SetXTitle(Var[0]+" "+Units)
        BinWidth=abs((Var[3]-Var[2])/float(Var[1]))
        Hist.SetYTitle( Norm+"/"+str(BinWidth)+" "+Units )

    def initialize(self,T,AllEntriesData,GlobalData):
        self.ThisEventFilledHists={}
        self.NEvents=0
        for Var in self.Vars:
            D=TH1F(self.HistName(Var[0],"N",-1),
                   self.HistTitle(Var[0],"N",-1),
                   Var[1],Var[2],Var[3])

            AllEntriesData[self.HistName(Var[0],"N",-1)]=D
            self.SetHistTitles(Var,D)
            D.NPassed=0
            
            for CutI in xrange(0,len(self.Cuts)):
                N=TH1F(self.HistName(Var[0],"N",CutI),
                       self.HistTitle(Var[0],"N",CutI),
                       Var[1],Var[2],Var[3])
                AllEntriesData[self.HistName(Var[0],"N",CutI)]=N
                N.NPassed=0
                self.SetHistTitles(Var,N)
        return True

    def HistName(self,Var,Hist,CutI):
        if CutI>-1:
            x=Hist+"_"+Var+"__"+self.CutNames[CutI]
        else:
            x=Hist+"_"+Var+"__NoCut"
        return x
    
    def HistTitle(self,Var,Hist,CutI):
        return Hist+" vs. "+Var 

    def IndexVar(self,Var,Index):
        return Var.replace("[i]","["+str(Index)+"]")

    def FillVars(self,AllEntriesData,Hist,CutI,I,T):
        out=[]
        for VarI in xrange(0,len(self.Vars)):
            Var=self.Vars[VarI]
            v=eval("T."+Var[0])
            x=v[I]
            out +=[float(x)]
            self.FillHisto(AllEntriesData,self.HistName(Var[0],Hist,CutI),float(x))

        return out

    def FillVarsCached(self,AllEntriesData,Hist,CutI,Results):
        for I in xrange(0,len(Results)):
            Var=self.Vars[I]
            self.FillHisto(AllEntriesData,self.HistName(Var[0],Hist,CutI),Results[I])

    def FillHisto(self,AllEntriesData,histName,val):
        h=AllEntriesData[histName]
        h.Fill(val)
        if not self.ThisEventFilledHists.has_key(histName):
            self.ThisEventFilledHists[histName]=True
            h.NPassed+=1

    def execute(self,T,AllEntriesData,GlobalData,ThisEntryData):
        self.NEvents+=1
        self.ThisEventFilledHists={}
        if eval(self.BaseLineCut):
            for i in range(0,eval("T."+self.NObjVar)):
                if eval(self.IndexVar(self.BaseLineCutObj,i)):
                    res=self.FillVars(AllEntriesData,"N",-1,i,T)
                    for CutI in xrange(0,len(self.Cuts)):
                        if eval(self.IndexVar(self.Cuts[CutI],i)):
                            self.FillVarsCached(AllEntriesData,"N",CutI,res)
        return True

    def UpdateStats(self,hist,Stats):
        HistStats={}
        if "XSection" in dir(hist):
            HistStats["XSection"]=hist.XSection
            HistStats["XSectionErr"]=hist.XSectionErr

        if "Efficiency" in dir(hist):
            HistStats["Efficiency"]=hist.Efficiency
            HistStats["EfficiencyErr"]=hist.EfficiencyErr

        Stats[hist.GetName()]=HistStats
        
    def finalize(self,T,AllEntriesData,GlobalData):

        Stats={}
        for Var in self.Vars:
            HistD=AllEntriesData[self.HistName(Var[0],"N",-1)]
            HistD.Sumw2()

            if "XSection" in dir(T):
                if self.NEvents==0:
                    self.NEvents=1
                    
                if T.XSection>0:
                    EventEff=float(HistD.NPassed)/float(self.NEvents)
                    HistD.XSection=T.XSection* EventEff
                    if(self.NEvents>0):
                        HistD.XSectionErr=T.XSection* sqrt(EventEff*(1-EventEff)/float(self.NEvents))
                    HistD.SetNormFactor(HistD.XSection)
                    self.SetHistTitles(Var,HistD,"x-section (pb)")

                self.UpdateStats(HistD,Stats)

            for CutI in xrange(0,len(self.Cuts)):
                HistE=TH1F(self.HistName(Var[0],"Eff",CutI),
                           self.HistTitle(Var[0],"Efficiency",CutI),Var[1],Var[2],Var[3])
                self.SetHistTitles(Var,HistE)
                AllEntriesData[self.HistName(Var[0],"Eff",CutI)]=HistE

                HistN=AllEntriesData[self.HistName(Var[0],"N",CutI)]
                HistN.Sumw2()

                HistE.Divide(HistN,HistD,1.,1.,"B")

                Eff=0
                EffErr2=0
                
                if(HistD.GetEntries()>0):
                    Eff=float(HistN.GetEntries())/float(HistD.GetEntries())
                    EffErr2=(Eff*(1-Eff))/HistD.GetEntries()

                HistE.Efficiency=Eff

                if(EffErr2>0.):
                    HistE.EfficiencyErr=sqrt(EffErr2)
                else:
                    HistE.EfficiencyErr=0

                if "XSection" in dir(T):
                    if T.XSection>0:
                        EventEff=float(HistN.NPassed)/float(self.NEvents)
                        HistN.XSection=T.XSection* EventEff
                        if(self.NEvents>0):
                            HistN.XSectionErr=T.XSection* sqrt(EventEff*(1-EventEff)/float(self.NEvents))
                        HistN.SetNormFactor(HistN.XSection)
                        self.SetHistTitles(Var,HistN,"x-section (pb)")

                self.UpdateStats(HistN,Stats)
                self.UpdateStats(HistE,Stats)


            AllEntriesData[self.name+"Stats"]=Stats
        return True
