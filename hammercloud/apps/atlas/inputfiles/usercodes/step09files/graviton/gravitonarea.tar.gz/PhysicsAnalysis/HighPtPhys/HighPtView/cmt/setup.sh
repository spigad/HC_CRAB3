# echo "Setting HighPtView HighPtView-14-02-05 in /afs/cern.ch/user/e/elmsheus/athena/testarea/14.5.0/PhysicsAnalysis/HighPtPhys"

if test "${CMTROOT}" = ""; then
  CMTROOT=/afs/cern.ch/sw/contrib/CMT/v1r20p20090520; export CMTROOT
fi
. ${CMTROOT}/mgr/setup.sh

tempfile=`${CMTROOT}/mgr/cmt -quiet build temporary_name`
if test ! $? = 0 ; then tempfile=/tmp/cmt.$$; fi
${CMTROOT}/mgr/cmt setup -sh -pack=HighPtView -version=HighPtView-14-02-05 -path=/afs/cern.ch/user/e/elmsheus/athena/testarea/14.5.0/PhysicsAnalysis/HighPtPhys  -no_cleanup $* >${tempfile}; . ${tempfile}
/bin/rm -f ${tempfile}

