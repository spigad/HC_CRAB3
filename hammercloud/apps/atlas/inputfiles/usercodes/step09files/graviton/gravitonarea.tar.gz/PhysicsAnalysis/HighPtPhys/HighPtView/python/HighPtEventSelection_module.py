
from HighPtView.HighPtViewModule import *

class HighPtEventSelection(HighPtViewModule):

  def setAffiliation(self):
    self._group = "EV team"
    self._author = "AS"
    self._description = "Event selection cuts"

  def __init__(self, name):
    HighPtViewModule.__init__(self, name)

  def schedule(self):

    self+=[
        EVUDSimpleCut("tt_LooseCuts", self),
    ]

  def setEVDefaults(self):

    self.tt_LooseCuts.setProperty({
      "cutList" : [ "double MissingEt>50GeV"],
      "filterMOEV" : False,
      "saveResult" : True,
      "cutName" : 'PassMETCut',
    })
      
    self.OutputLevel=3
