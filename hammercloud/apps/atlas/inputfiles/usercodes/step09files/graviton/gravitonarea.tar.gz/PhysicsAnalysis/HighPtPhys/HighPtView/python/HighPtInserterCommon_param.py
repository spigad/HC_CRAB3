
from AthenaCommon.SystemOfUnits import GeV
from HighPtView.HighPtViewModule import *

class HighPtInserterCommon_Parameters(HighPtViewModule):

  def setAffiliation(self):
    self._group = "HighPt"
    self._author = "AS"
    self._description = "Common inserter parameters for HighPtView"

  def __init__(self, name):
    HighPtViewModule.__init__(self,name)    


    # Common Parameters
    self.CommonParameters={
      "OverlapNoCopyLabels":[],
      "NoInsert":False,
      #"DoPreselection":True,
      "NoOverlapCheck":False,
      "InsertOnOverlap":False,
      "makeEtaCuts": False,
      "EtaMinCut": 0,
      "EtaMaxCut": 100,
    }

