from AthenaCommon.SystemOfUnits import GeV
from HighPtView.HighPtInserterBase_module import *

class HighPtMuonInserter(HighPtInserterBase):

  def __init__(self, name, mode="FullReco,Muid", Configuration=None, override={}):

    DefaultConfiguration={ "FullReco,Muid":
                           [ {"Name":"MuDefault", # This is the original configuration for HPTV, corresponds to tight
                              "Configuration":
                              { "ContainerKey" :"MuidMuonCollection",
                                "etCut" : 15*GeV,
                                "onlyHighPt" : False,
                                "relativeIsolationCut" : 1.,
                                "chi2NdofCut":10,
                                "chi2MatchCut":100000000, # Large number to effectively remove cut
                                "deltaRCut":.1,
                                "RemoveOverlapWithSameType" : False,
                                "InsertedLabels":["Muid", "Muon","Lepton"],
                                }}],
                           "FullReco,Staco":
                           [ {"Name":"MuDefault", # This is the original configuration for HPTV, corresponds to tight
                              "Configuration":
                              { "ContainerKey" : "StacoMuonCollection",
                                "etCut" : 15*GeV,
                                "onlyHighPt" : False,
                                "relativeIsolationCut" : 1.,
                                "chi2NdofCut":10,
                                "chi2MatchCut":100000000, # Large number to effectively remove cut
                                "deltaRCut":.1,
                                "RemoveOverlapWithSameType" : False,
                                 "InsertedLabels":["Staco", "Muon", "Lepton"] 
                                }}],
                           "FastSim":
                           [ {"Name": "MuDefault",
                              "Configuration":
                              { "ContainerKey" :"AtlfastMuonCollection",
                                "etCut":15*GeV,
                                "DoPreselection": False,
                                "deltaRCut":.1,
                                "RemoveOverlapWithSameType" : False,
                                "InsertedLabels":["Atlfast", "Muon","Lepton"],
                                }}]}

    HighPtInserterBase.__init__(self, name, "EVMuonInserter", mode, DefaultConfiguration, Configuration, override)

      
