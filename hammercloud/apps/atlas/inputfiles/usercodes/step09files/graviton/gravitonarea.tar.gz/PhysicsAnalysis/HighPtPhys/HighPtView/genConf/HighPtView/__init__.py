## Hook for HighPtView genConf module
