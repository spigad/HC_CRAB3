from ROOT import *
from TTreeAlgorithm import *

class GeneralProfiler(TTreeAlgorithm):
    def __init__(self, name, VarY, VarX, Branches, MinEvents=5):
        self.VarY=VarY
        self.VarX=VarX
        self.MinEvents=MinEvents
	TTreeAlgorithm.__init__(self,name,Branches)
        
    def	initialize(self,T,AllEntriesData,GlobalData):
        for Vary in self.VarY:
            for Varx in self.VarX:
                N=Varx[1]
                AllEntriesData[self.histogram("Mean",str(Vary[0]),str(Varx[0]))]=TH1F(self.histogram("Mean",str(Vary[0]),str(Varx[0])),self.histogram("Mean",str(Vary[0]),str(Varx[0])),N,Varx[2],Varx[3])
                AllEntriesData[self.histogram("RMS",str(Vary[0]),str(Varx[0]))]=TH1F(self.histogram("RMS",str(Vary[0]),str(Varx[0])),self.histogram("RMS",str(Vary[0]),str(Varx[0])),N,Varx[2],Varx[3])
                AllEntriesData[self.histogram("GaussMean",str(Vary[0]),str(Varx[0]))]=TH1F(self.histogram("GaussMean",str(Vary[0]),str(Varx[0])),self.histogram("GaussMean",str(Vary[0]),str(Varx[0])),N,Varx[2],Varx[3])
                AllEntriesData[self.histogram("GaussSigma",str(Vary[0]),str(Varx[0]))]=TH1F(self.histogram("GaussSigma",str(Vary[0]),str(Varx[0])),self.histogram("GaussSigma",str(Vary[0]),str(Varx[0])),N,Varx[2],Varx[3])
                for I in xrange(0,N):
                    AllEntriesData[self.histname(Varx[0],"F",I)]= TH1F(self.histname(Varx[0],"F",I),self.histname(Varx[0],"F",I),Vary[1],Vary[2],Vary[3])
        return True


    def histname(self,Var,Hist,I):
        return Var+"_bin_"+Hist+"_"+str(I)

    def histogram(self,Var,Yaxis,Xaxis):
        return Var+"_"+Yaxis+"_vs._"+Xaxis
    
    def VariableName(self,Var,Index):
        return "T."+Var+"["+str(Index)+"]"

    def ReplaceIndex(self,Var,Index):
        return Var.replace("[i]","["+str(Index)+"]")
    
    def execute(self,T,AllEntriesData,GlobalData,ThisEntryData):
        for Vary in self.VarY:
            for Varx in self.VarX:
                N=Varx[1]
                #print Varx[1]
                bin_width= (Varx[3]-Varx[2])/float(N)
#                print "BW:",Varx[3],Varx[2],N,bin_width

                bin_min=Varx[2]
                bin_max=Varx[3]

                if eval("T."+Vary[4])>0:
                    for J in xrange(0,eval("T."+Vary[4])):
                        if eval(self.ReplaceIndex(Vary[5],J)):
                            s=eval(self.ReplaceIndex(Varx[0],J))
                            for I in xrange(0,N):
                                x=0
                                bin_edge_low = bin_min+I*bin_width
                                bin_edge_high= bin_min+(I+1)*bin_width
#                                print I,s, bin_edge_low, bin_edge_high
                                if bin_edge_low <s< bin_edge_high:
                                    #print "YOU ARE HERE"
                                    x=eval(self.ReplaceIndex(Vary[0],J))
#                                    print "x=",x
                                    AllEntriesData[self.histname(Varx[0],"F",I)].Fill(float(x))
                                    continue
        return True
                                            
    def finalize(self,T,AllEntriesData,GlobalData):
        for Vary in self.VarY:
            #print Vary
            for Varx in self.VarX:
                #print Varx
                N=Varx[1]
                #print N
                for I in xrange(0,N):
                    HistF=AllEntriesData[self.histname(Varx[0],"F",I)]
                    if HistF.GetEntries()>self.MinEvents:

                        HistF.Fit("gaus","q")
                        f=HistF.GetListOfFunctions().pop()
                        mean1=f.GetParameter(1)
                        meanerror1=f.GetParError(1)
                        rms1=f.GetParameter(2)
                        rmserror1=f.GetParError(2)
                        
                        mean2=HistF.GetMean()
                        rms2=HistF.GetRMS()
                        meanerror2=HistF.GetMeanError()
                        rmserror2=HistF.GetRMSError()
                        
                        AllEntriesData[self.histogram("GaussMean",str(Vary[0]),str(Varx[0]))].SetBinContent(I,mean1)
                        AllEntriesData[self.histogram("GaussMean",str(Vary[0]),str(Varx[0]))].SetBinError(I,meanerror1)
                        AllEntriesData[self.histogram("GaussSigma",str(Vary[0]),str(Varx[0]))].SetBinContent(I,rms1)
                        AllEntriesData[self.histogram("GaussSigma",str(Vary[0]),str(Varx[0]))].SetBinError(I,rmserror1)
                        
                        AllEntriesData[self.histogram("Mean",str(Vary[0]),str(Varx[0]))].SetBinContent(I,mean2)
                        AllEntriesData[self.histogram("Mean",str(Vary[0]),str(Varx[0]))].SetBinError(I,meanerror2)
                        AllEntriesData[self.histogram("RMS",str(Vary[0]),str(Varx[0]))].SetBinContent(I,rms2)
                        AllEntriesData[self.histogram("RMS",str(Vary[0]),str(Varx[0]))].SetBinError(I,rmserror2)

#                print AllEntriesData[self.histogram("Mean",str(Vary[0]),str(Varx[0]))]
#                print AllEntriesData[self.histogram("RMS",str(Vary[0]),str(Varx[0]))]
                #print AllEntriesData
        return True
            
                                                      
            
                        
                    
            
    

