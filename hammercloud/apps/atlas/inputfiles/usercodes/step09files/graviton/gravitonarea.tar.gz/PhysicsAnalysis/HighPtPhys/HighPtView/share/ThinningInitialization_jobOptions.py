from AthenaServices.Configurables import ThinningSvc
svcMgr += ThinningSvc( OutputLevel = VERBOSE )

from EventViewBuilderAlgs.EventViewBuilderAlgsConf import *
from EventViewSelectors.EventViewSelectorsConf import *

thinEVAlg = EVMultipleOutputToolLooper("thinEV")
thinEVAlg += EVHackToInitializeThinning("EVHackToInitializeThinning")
thinEVAlg.EVHackToInitializeThinning.ThinTracks=True
thinEVAlg.EVHackToInitializeThinning.ThinClusters=False
thinEVAlg.EVHackToInitializeThinning.ExcludedKeys = ["AODCellContainer"]
theJob+=thinEVAlg

from AthenaCommon.GlobalFlags import GlobalFlags
GlobalFlags.DetGeo.set_atlas()
GlobalFlags.Luminosity.set_zero()
GlobalFlags.DataSource.set_geant4()
GlobalFlags.InputFormat.set_pool()

from AthenaCommon.DetFlags import DetFlags
DetFlags.Calo_setOn()  #Switche on
DetFlags.ID_setOn()    #Switche on
DetFlags.Muon_setOff()
DetFlags.Truth_setOff()
DetFlags.LVL1_setOff()
DetFlags.digitize.all_setOff()


#Set up GeoModel (not really needed but crashes without)
include ("AtlasGeoModel/SetGeometryVersion.py")
include ("AtlasGeoModel/GeoModelInit.py")
