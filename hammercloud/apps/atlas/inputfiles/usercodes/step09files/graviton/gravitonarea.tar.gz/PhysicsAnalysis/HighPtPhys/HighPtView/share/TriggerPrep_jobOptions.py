from EventViewTrigger import *


if TriggerView:

  # include full trigger tree  
  triggerLooper = EVMultipleOutputToolLooper( "triggerLooper" )
  triggerLooper.EventViewCollectionOutputName = "TriggerView"
  theJob += triggerLooper
  theJob.triggerLooper += TriggerPreparators( "trigPreparators", slices = [ "Muon", "Electron", "Photon", "Tau", "Jet"  ] )
  theJob.triggerLooper += TriggerInserters( "trigInserters", slices = [ "Muon", "Electron", "Photon", "Tau", "Jet"  ] )
  theJob.triggerLooper += TriggerCalculators( "trigCalculators", slices = [ "Muon", "Electron", "Jet", "Tau", "Photon" ] )
  theJob.triggerLooper += EVTrigDecisionUserDataAOD("trigDecisionAOD") 
  if DoScreenDump:
    theJob.triggerLooper += EVScreenDump("ScreenDumperTrigger", printUD=ShowUserData)
 
  theJob.triggerLooper += AANtupleFromUserData( "TriggerAADumper", filename = "Trigger_"+NtupleName,
                                                sequencer = theJob, EventTree = True,
                                                CandTree = False, Prefix = "Trigger" )

else:
  TriggerPrepLooper= EVMultipleOutputToolLooper("TriggerPrepLooper")
  TriggerPrepLooper.EventViewCollectionOutputName="DummyTriggerView"
  theJob += TriggerPrepLooper
  if "L1" in TriggerLevels:
    TriggerPrepLooper += LVL1Preparator("L1TrigPrep")
  if "L2" in TriggerLevels: 
    TriggerPrepLooper += LVL2Preparators("L2TrigPrep")     
  if "EF" in TriggerLevels:
    TriggerPrepLooper += EFPreparators("EFTrigPrep")
