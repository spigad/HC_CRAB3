from AthenaCommon.SystemOfUnits import GeV
from HighPtView.HighPtInserterBase_module import *

class HighPtJetInserter(HighPtInserterBase):

  def __init__(self, name, mode="FullReco", Configuration=None, override={}):

    DefaultConfiguration={ "FullReco,Cone4":
                           [ {"Name":"JetDefault", # This is the original configuration for HPTV
                              "Configuration":
                              {"ContainerKey":"Cone4H1TowerJets",
                               "etCut":0*GeV,
                               "deltaRCut":.3,
                               "RemoveOverlapWithSameType" : False,
                               "RemoveOverlapWithMuon" : False,
                               "InsertedLabels":["Cone4", "Jet"],
                               "RejectLabels":["TauJet"]
                               }}],
                           "FullReco,Cone7":
                           [ {"Name":"JetDefault", # This is the original configuration for HPTV
                              "Configuration":
                              {"ContainerKey":"Cone7H1TowerJets",
                               "etCut":0*GeV,
                               "deltaRCut":.3,
                               "RemoveOverlapWithSameType" : False,
                               "RemoveOverlapWithMuon" : False,
                               "InsertedLabels":["Cone7", "Jet"],
                               "RejectLabels":["TauJet"]
                               }}],
                           "FullReco,Kt4":
                           [ {"Name":"JetDefault", # This is the original configuration for HPTV
                              "Configuration":
                              {"ContainerKey":"Kt4H1TowerJets",
                               "etCut":0*GeV,
                               "deltaRCut":.3,
                               "RemoveOverlapWithSameType" : False,
                               "RemoveOverlapWithMuon" : False,
                               "InsertedLabels":["Kt4", "Jet"],
                               "RejectLabels":["TauJet"]
                               }}],
                           "FullReco,Kt6":
                           [ {"Name":"JetDefault", # This is the original configuration for HPTV
                              "Configuration":
                              {"ContainerKey":"Kt6H1TowerJets",
                               "etCut":0*GeV,
                               "deltaRCut":.3,
                               "RemoveOverlapWithSameType" : False,
                               "RemoveOverlapWithMuon" : False,
                               "InsertedLabels":["Kt6", "Jet"],
                               "RejectLabels":["TauJet"]
                               }}],
                           "FastSim":
                           [ {"Name":"JetDefault", # This is the original configuration for HPTV
                              "Configuration":
                              {"ContainerKey":"AtlfastJetContainer",
                               "DoPreselection":False,
                               "etCut":20*GeV,
                               "RemoveOverlapWithSameType" : False,
                               "RemoveOverlapWithMuon" : False,
                               "InsertedLabels":["Atlfast", "Jet", "Cone4"],
                               "RejectLabels":["TauJet"]
                               }}]}
      
    HighPtInserterBase.__init__(self, name, "EVJetInserter", mode, DefaultConfiguration, Configuration, override)
