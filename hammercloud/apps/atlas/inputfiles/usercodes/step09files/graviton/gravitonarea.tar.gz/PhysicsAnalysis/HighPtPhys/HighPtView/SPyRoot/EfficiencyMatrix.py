from SPyRoot import TTreeAlgorithm,TTreeHelpers
from ROOT import *

class EfficiencyMatrix(TTreeAlgorithm):
    def __init__(self,name, SourceTypes, Branches=["*"]):
        self.SourceTypes=SourceTypes
        TTreeAlgorithm.__init__(self,name,Branches)

    def FilterBeginStringList(self,string,list):
        out=[]
        for item in list:
            if item.find(string)==0:
                out+=[item]
        return out

    def initialize(self,T,AllEntriesData,GlobalData):
        Matrix={}
        
        MatchVarNames = TTreeHelpers.GetLeafNames(T,"Matched")
        for Source in self.SourceTypes:
            ListOfMatchVars=self.FilterBeginStringList(Source,MatchVarNames)
            Column={}

            for MatchVar in ListOfMatchVars:
                Column[MatchVar]=[0,0]

            Matrix[Source]=Column

        AllEntriesData["Matrix"]=Matrix
        return True


    def execute(self,T,AllEntriesData,GlobalData,ThisEntryData):

        Matrix=AllEntriesData["Matrix"]
        
        for Source in Matrix:
            for i in xrange(0,eval("T."+Source+"N")):
                Column=Matrix[Source]
                for Item in Column:
                    Val=Column[Item]
                    Val[1]+=1
                    if eval("T."+Item+"["+str(i)+"]")==1:
                        Val[0]+=1
                    Column[Item]=Val
                Matrix[Source]=Column

        AllEntriesData["Matrix"]=Matrix

        return True



class MatrixPrinter:
    def __init__(self,Matrix,ColumnWidth=15,Exact=False):
        self.Matrix=Matrix
        self.Exact=Exact
        self.ColumnWidth=ColumnWidth

    def NicePrint(self,x):
        NumWidth=str(floor(self.ColumnWidth/2) -1)
        s="%(N)"+NumWidth+"i/%(D)"+NumWidth+"i "
        print s %{"N": x[0],"D":x[1]} ,

    def FilterBadName(self,BadColumnNames,n):
        if len(BadColumnNames)==0:
            return n

        for ColumnName in BadColumnNames:
            if n.find(ColumnName)>-1:
                return ""

        return n
            

    def FilterName(self,ColumnNames,BadColumnNames,x,remove=""):
        if x.find(remove)==0:
            n=x[len(remove):]
        else:
            return ""

        for ColumnName in ColumnNames:
            if self.Exact:
                if n==ColumnName:
                    return self.FilterBadName(BadColumnNames,n)
            else:
                if n.find(ColumnName)>-1:
                    return self.FilterBadName(BadColumnNames,n)

        return ""
                
            
    def SelectColumns(self,ColumnNames,BadColumnNames):
        GoodColumnNames={}
        
        for Column in self.Matrix:
            for name in self.Matrix[Column]:
                n=self.FilterName(ColumnNames,BadColumnNames,name,Column)
                if not n=="":
                    GoodColumnNames[n]=n

        return GoodColumnNames

    
    def PrintMatrix(self,ColumnNames=[""],BadColumnNames=[],ColumnWidth=None,Exact=None):
        if not Exact==None:
            self.Exact=Exact
        if not ColumnWidth==None:
            self.ColumnWidth=ColumnWidth

        TheColumnNames=self.SelectColumns(ColumnNames,BadColumnNames)

        GoodColumnNames=[]
        for Column in TheColumnNames:
            GoodColumnNames+=[Column]

        GoodColumnNames.sort()

        Rows=[]
        for Row in self.Matrix:
            Rows+=[Row]
        Rows.sort()
        
        for i in xrange(0,self.ColumnWidth):
            print "",
            
        for name in GoodColumnNames:
            pos=name.find("Matched")
            if pos>0:
                thename=name[:pos]
            else:
                thename=name
            s="%(N)"+str(self.ColumnWidth)+"s"
            print s %{"N":thename},
        print 
            
        for Row in Rows:
            TheRow=self.Matrix[Row]
            s="%(N)"+str(self.ColumnWidth)+"s"
            print s %{"N":Row},
            for name in GoodColumnNames:
                if TheRow.has_key(Row+name):
                    self.NicePrint(TheRow[Row+name])
                else:
                    print "N/A",
            print ""

        
        
