#include "GaudiKernel/LoadFactoryEntries.h"
 
LOAD_FACTORY_ENTRIES ( HighPtView )
