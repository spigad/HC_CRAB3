# Flags configuration
doWriteAOD= True
from ParticleBuilderOptions.AODFlags import AODFlags
AODFlags.Trigger = DoTrigger

import AthenaPoolCnvSvc.WriteAthenaPool

include( "EventAthenaPool/EventAthenaPool_joboptions.py" )
include( "EventCommonAthenaPool/EventCommonAthenaPool_joboptions.py" )
include( "ParticleBuilderOptions/AOD_PoolCnv_jobOptions.py")
include( "ParticleBuilderOptions/McAOD_PoolCnv_jobOptions.py")
include( "RecAthenaPool/RecAthenaPool_joboptions.py" )

include( "ParticleBuilderOptions/AOD_OutputList_jobOptions.py" )

from AthenaPoolCnvSvc.WriteAthenaPool import AthenaPoolOutputStream
outStream = AthenaPoolOutputStream("OutStream")

if not "DPDFileName" in dir():  DPDFileName="DPD"

OUTPUT=DPDFileName+".pool.root"

if os.path.exists( OUTPUT ):
    os.remove( OUTPUT )
outStream.OutputFile = OUTPUT
outStream.ForceRead  = True  #force read of output data objs

# List of selected objects to write out
outStream.ItemList =["EventInfo#*"]
#outStream.ItemList+=["EventView#*"]
outStream.ItemList+=["ElectronContainer#ElectronAODCollection"]
outStream.ItemList+=["Analysis::MuonContainer#MuidMuonCollection"]
outStream.ItemList+=["JetCollection#Cone4H1TowerJets"]

# These are not in the EventView but are thinned by EVMuon2DPD, etc.
outStream.ItemList+=["Rec::TrackParticleContainer#MooreTrackParticles"]
outStream.ItemList+=["Rec::TrackParticleContainer#MuidCombTrackParticles"]
outStream.ItemList+=["Rec::TrackParticleContainer#MuidExtrTrackParticles"]
outStream.ItemList+=["Rec::TrackParticleContainer#TrackParticleCandidate"]
outStream.ItemList+=["egDetailContainer#egDetailAOD"]

# These are not yet thinned
outStream.ItemList+=["CaloClusterContainer#CaloCalTopoCluster"]
outStream.ItemList+=["CaloClusterContainer#CombinedCluster"]
outStream.ItemList+=["CaloClusterContainer#EMTopoCluster"]
outStream.ItemList+=["CaloClusterContainer#LArCluseterEMSofte"]
outStream.ItemList+=["CaloClusterContainer#egClusterCollection"]
outStream.ItemList+=["VxContainer#*"]
outStream.ItemList+=["MissingET#*"]

#outStream.ItemList+=["McEventCollection#GenAOD"]
outStream.ItemList+=["McEventCollection#GEN_EV"]
#outStream.ItemList+=["TruthParticleContainer#SpclMC"]
outStream.ItemList+=["TruthParticleContainer#EVTruthParticles"]
outStream.ItemList+=["JetCollection#Cone4TruthJets"]

#debugging
#print "Inpsect AlgSequence"
#for i in AlgSequence().getChildren(): print i.getFullName()
