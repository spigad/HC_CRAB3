# by Wim

__all__ = []

def init():
   import glob, os, sys

   oldpath = sys.path[:]
   basedir = os.path.dirname( __file__)
   sys.path.append( basedir )
 
   children = map( lambda x: os.path.basename( x )[:-3],
                   glob.glob( os.path.join( basedir, '[!_]*.py' ) ) )
 
   self = sys.modules[ __name__ ]

   global __all__
   for mod in children:
      c = __import__( mod )
      if hasattr( c, '__all__' ):
         all = c.__all__
      else:
         all = dir(c)
 
      for name in all:
         if name[0] != '_':
            __all__.append( name )
            self.__dict__[ name ] = getattr( c, name )
 
   sys.path = oldpath
 
init()
del init
