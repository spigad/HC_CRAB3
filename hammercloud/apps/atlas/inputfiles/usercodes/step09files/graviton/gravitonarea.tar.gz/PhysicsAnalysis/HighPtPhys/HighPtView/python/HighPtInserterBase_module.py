from AthenaCommon.SystemOfUnits import GeV
from HighPtView.HighPtViewModule import HighPtViewModule
from EventViewInserters.EventViewInsertersConf import *

class HighPtInserterBase(HighPtViewModule):

  def setAffiliation(self):
    self._group = "EV Team"
    self._author = "AF"
    self._description = "Base HPTV Inserter"

  def FindModeKey(self,Mode,Dict):
    for m in Dict:
      sp=m.split(",")
      NMatch=0
      for s in sp:
        if s in Mode:
          NMatch+=1
      if NMatch==len(sp):
        return m

    return ""

  def FindInserterConfig(self,config,name):
    for inserterconfig in config:
      if inserterconfig["Name"]==name:
        return inserterconfig["Configuration"]
    return None

  def __init__(self, name, InserterToolName, mode, DefaultConfiguration, Configuration, override):

    self.mode=mode
    self.myoverride=override
    self.Labels=[]
    self.InserterToolName=InserterToolName
    self.InserterTools=[]
    
    modekey=self.FindModeKey(self.mode,DefaultConfiguration)

    if modekey=="":
      print name,"Error:",self.mode,"not found in configuration."

    self.Configuration=DefaultConfiguration[modekey]
    
    if not Configuration==None:
      modekey2=self.FindModeKey(self.mode,Configuration)

      if not modekey2=="" and Configuration.has_key(modekey2):
        self.Configuration=[]

        ThisModeConfig=Configuration[modekey2]
        for InserterSpec in ThisModeConfig:
          InserterName=InserterSpec["Name"]
          if InserterSpec.has_key("Configuration"):
            InserterConfig=InserterSpec["Configuration"]
          else:
            InserterConfig={}
          DefConfig=self.FindInserterConfig(DefaultConfiguration[modekey],InserterName)
          if not DefConfig==None:
            AConf=DefConfig
            self.AppendDicts(AConf,InserterConfig)
          else:
            AConf=InserterConfig
          self.Configuration+=[ {"Name":InserterName,
                                 "Configuration":AConf} ]


#    print name,"End Conf",self.Configuration
    # Each Inserter will label selected objects with it's name 
    for InserterSpec in self.Configuration:
      InserterName=InserterSpec["Name"]
      InserterConfig=InserterSpec["Configuration"]
      
      SelectedLabels=[InserterName]
      if InserterConfig.has_key("SelectedLabels"):
        SelectedLabels=InserterConfig["SelectedLabels"]

      InserterConfig["SelectedLabels"]=SelectedLabels
      self.Labels+=[InserterName]
      
    HighPtViewModule.__init__(self, name)

  def AppendDicts(self,a,b):
    for key in b:
      a[key]=b[key]

  def schedule(self):
    for InserterSpec in self.Configuration:
      InserterName=InserterSpec["Name"]
      command="ATool = "+self.InserterToolName+"('"+InserterName+self.name()+self.mode.replace(",","_")+"')"
#      print "command in HighPtInserterBase is ",command
      exec(command)
#      ATool=anEVTool(self.InserterToolName+"/HighPtInserter_"+InserterName+self.name())
      self.InserterTools+=[ATool]
      self += ATool

  def setEVDefaults(self):
    First=True
    for InserterSpec in self.Configuration:
      InserterName=InserterSpec["Name"]
      InserterConfig=InserterSpec["Configuration"]

      Tool=self[InserterName+self.name()+self.mode.replace(",","_")]
      self.overrideToolParams(Tool,self.myoverride)
      Tool.setProperty(InserterConfig)
      if not First:
        Tool.setProperties(SelectorMode=True,
                           SelectorLabel=self.Configuration[0]["Name"])
      else:
        First=False
      
  def overrideToolParams(self, Tool, *override):
    for i in override:
      Tool.setProperty(i)

  def overrideToolParamsI(self, ToolI, *override):
    for i in override:
      self.InserterTools[ToolI].setProperty(i)

  def override(self, *override):
    if len(self.InserterTools)>0:
      for i in override:
        self.InserterTools[0].setProperty(i)
    else:
      print "Warning: No First Tool Found."

