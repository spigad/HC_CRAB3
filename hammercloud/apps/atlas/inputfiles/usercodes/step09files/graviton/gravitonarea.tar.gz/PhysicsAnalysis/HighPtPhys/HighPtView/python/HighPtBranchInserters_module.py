from AthenaCommon.SystemOfUnits import GeV
from HighPtView.HighPtViewModule import HighPtViewModule
from HighPtView.HighPtInserterCommon_param import *
from HighPtView.HighPtElectronInserter_module import *
from HighPtView.HighPtMuonInserter_module import *
from HighPtView.HighPtPhotonInserter_module import *
from HighPtView.HighPtTauJetInserter_module import *
from HighPtView.HighPtJetInserter_module import *
from HighPtView.HighPtMissingEtInserter_module import *

class HighPtBranchInserters(HighPtViewModule):

  def setAffiliation(self):
    self._group = "EV Team"
    self._author = "AS"
    self._description = "Multi branch inserters"

  def __init__(self, name, mode="FullReco"):

    self.mode=mode
    HighPtViewModule.__init__(self, name)

  def schedule(self):

    InserterParameter = HighPtInserterCommon_Parameters("common")
    commonParam=InserterParameter.CommonParameters

    el       = HighPtElectronInserter("el", self.mode ,commonParam)
    muid     = HighPtMuonInserter("muid", self.mode+"Muid", commonParam)
    staco    = HighPtMuonInserter("staco", self.mode+"Staco", commonParam)
    ph       = HighPtPhotonInserter("ph", self.mode, commonParam)
    taurec   = HighPtTauJetInserter("taurec", self.mode+"TauRec", commonParam)
    tau1p3p  = HighPtTauJetInserter("tau1p3p", self.mode+"1p3p", commonParam)
    jetcone4 = HighPtJetInserter("jet04", self.mode+"Cone4", commonParam, )
    jetcone7 = HighPtJetInserter("jet07", self.mode+"Cone7", commonParam)
    jetkt4   = HighPtJetInserter("jetkt", self.mode+"Kt4", commonParam)
    jetkt6   = HighPtJetInserter("jetkt", self.mode+"Kt6", commonParam)
    met      = HighPtMissingEtInserter("met", self.mode)

    self += BranchLooper("HighPtBranch")
    self.HighPtBranch.addBranch([ muid, el, ph, taurec, jetcone4, jetcone7, jetkt4, jetkt6, met], "MuidTauRec")
    self.HighPtBranch.addBranch([ muid, el, ph, tau1p3p, jetcone4, jetcone7, jetkt4, jetkt6, met], "MuidTau1p3p")
    self.HighPtBranch.addBranch([ staco, el, ph, taurec, jetcone4, jetcone7, jetkt4, jetkt6, met], "StacoTauRec")
    self.HighPtBranch.addBranch([ staco, el, ph, tau1p3p, jetcone4, jetcone7, jetkt4, jetkt6, met], "StacoTau1p3p")

  def setEVDefaults(self):
    
    pass

  def getBranchNames(self):
    return self.HighPtBranch.branches
