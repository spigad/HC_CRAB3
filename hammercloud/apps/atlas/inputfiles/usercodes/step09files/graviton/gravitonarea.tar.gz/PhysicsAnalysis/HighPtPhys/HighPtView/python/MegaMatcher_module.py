from EventViewConfiguration.EVModule import *

from EventViewBuilderAlgs.EventViewBuilderAlgsConf import *
from EventViewUserData.EventViewUserDataConf import *

class MegaMatcher(EVModule):


  def __init__(self, name, RootEVSpec, TargetEVSpecs=[], TargetContainerSpecs=[], SaveDeltaR=False ):

      self.RootEVSpec=RootEVSpec
      self.TargetEVSpecs=TargetEVSpecs
      self.TargetContainerSpecs=TargetContainerSpecs
      self.SaveDeltaR=SaveDeltaR
      
      EVModule.__init__(self, name)

  def schedule(self):

      EVName = 'dummy'
      for RootObjSpec in self.RootEVSpec:
          RootPrefix=RootObjSpec["Properties"]["Prefix"]
          
          LooperToolName=RootPrefix+"MMLooper"
          Looper=EVUDFinalStateLooper(LooperToolName)
          self += Looper
          Looper.setProperties(**RootObjSpec["Properties"])

          if RootObjSpec.has_key("LabelsToSave"):
              LabelerToolName=RootPrefix+"MMLabeler"
              Labeler=EVUDLabelCalc(LabelerToolName)
              Labeler.Labels=RooObjSpec("LabelsToSave")
              Looper+=Labeler

          if RootObjSpec.has_key("SaveKin"):
              if RootObjSpec["SaveKin"]:
                  KinCalcToolName=RootPrefix+"MMKinCalc_"+EVName
                  Looper+=KinCalc
                  KinCalc=EVUD4MomCalc(KinCalcToolName)

          for EVSpec in self.TargetEVSpecs:
              EVName=EVSpec["EventView"]

              for EVObjSpec in EVSpec["Objects"]:
                  TargetPrefix=EVObjSpec["Properties"]["Prefix"]
                  AssocToolName=RootPrefix+TargetPrefix+"MMAssoc_"+EVName
                  AssocTool=EVUDToEVINav4MomAssociator(AssocToolName)
                  AssocTool.setProperties(EventViewInputName=EVName,deltaRmatch=.1,saveDeltaR=self.SaveDeltaR)
                  AssocTool.setProperties(**EVObjSpec["Properties"])
                  Looper+=AssocTool

                  if EVObjSpec.has_key("LabelsToSave"):
                      LabelerToolName=RootPrefix+TargetPrefix+"MMLabeler_"+EVName
                      Labeler=EVUDLabelCalc(LabelerToolName)
                      Labeler.Labels=EVObjSpec("LabelsToSave")
                      AssocTool+=Labeler

                  if EVObjSpec.has_key("SaveKin"):
                      if EVObjSpec["SaveKin"]:
                          KinCalcToolName=RootPrefix+TargetPrefix+"MMKinCalc_"+EVName
                          KinCalc=EVUD4MomCalc(KinCalcToolName)
                          AssocTool+=KinCalc
                  
          for ContSpec in self.TargetContainerSpecs:

              TargetPrefix=ContSpec["Properties"]["Prefix"]
              AssocToolName=RootPrefix+TargetPrefix+"MMAssoc_"+EVName

              if ContSpec.has_key("Associator"):
                TheAssocToolName=ContSpec["Associator"]
              else:
                TheAssocToolName="EVUDINav4MomAssociator"
                
              exec("AssocTool="+TheAssocToolName+"('"+AssocToolName+"')")
              AssocTool.setProperties(deltaRmatch=.1,saveDeltaR=self.SaveDeltaR)
              AssocTool.setProperties(**ContSpec["Properties"])
              Looper+=AssocTool

              if ContSpec.has_key("SaveKin"):
                  if ContSpec["SaveKin"]:
                      KinCalcToolName=RootPrefix+TargetPrefix+"MMKinCalc_"+EVName
                      KinCalc=EVUD4MomCalc(KinCalcToolName)
                      AssocTool+=KinCalc
                  
                  
                                     




              


