from AthenaCommon.SystemOfUnits import GeV
from HighPtView.HighPtInserterBase_module import *

from EventViewInserters import egammaPID

class HighPtPhotonInserter(HighPtInserterBase):

  def __init__(self, name, mode="FullReco", Configuration=None, override={}):

    DefaultConfiguration={ "FullReco":
                           [ {"Name":"PhDefault", # This is the original configuration for HPTV
                              "Configuration": 
                              { "ContainerKey":"PhotonAODCollection",
                                "etCut":3*GeV,
                                "useIsEM":False,
                                "isEMMasks" : [],
##==##                                "useShowerShapes":False, # The parameters below will be ignored
                                "deltaRCut":.2,
                                "useIsolation":False,
                                "isolationCone":0.45,
                                "absoluteIsolationCut":10*GeV,
                                "UseTrackIsol":False,
                                "RemoveOverlapWithSameType" : False,
                                "InsertedLabels":["Photon"],
                                #"RemoveOverlapWithMuon" : False,
##==##                                "CutHadLeakage_photons":[0.010,0.0030,0.0120,0.011,0.025],
##==##                                "ratio1_photons" :[0.91,0.925,0.90,0.92,0.925,
##==##                                                   0.935,0.933,0.912,0.925,0.91,
##==##                                                   0.943,0.942,0.92,0.940,0.93,
##==##                                                   0.953,0.947,0.925,0.945,0.93],
##==##                                "ratio2_photons" :[0.65,0.65,0.76,0.80,0.75,
##==##                                                   0.75,0.75,0.77,0.80,0.84,
##==##                                                   0.83,0.83,0.85,0.88,0.88,
##==##                                                   0.89,0.89,0.91,0.91,0.92],
##==##                                "weta2_photons" :[0.0109,0.0115,0.0130,0.0117,0.0120,
##==##                                                  0.0105,0.0110,0.0125,0.0112,0.0120,
##==##                                                  0.0101,0.0107,0.0121,0.0109,0.0118,
##==##                                                  0.0100,0.0104,0.0115,0.0105,0.0115],
##==##                                "emax2r_photons" :[180.,270.,400.,350.,350.,
##==##                                                   180.,270.,450.,300.,300.,
##==##                                                   180.,210.,450.,300.,500.],
##==##                                "deltae_photons" :[140.*GeV,120.*GeV,300.*GeV,210.*GeV,250.*GeV,
##==##                                                   140.*GeV,120.*GeV,350.*GeV,230.*GeV,300.*GeV,
##==##                                                   140.*GeV,120.*GeV,350.*GeV,230.*GeV,300.*GeV],
##==##                                "wtot_photons" :[2.5,2.7,3.0,2.1,1.45,
##==##                                                 2.4,2.7,2.9,2.1,1.45,
##==##                                                 2.2,2.7,2.8,2.1,1.45],
##==##                                "fracm_photons" :[0.33,0.45,0.47,0.30,0.19,
##==##                                                  0.30,0.43,0.47,0.27,0.18,
##==##                                                  0.25,0.35,0.45,0.22,0.18],
##==##                                "w1_photons" :[0.67,0.70,0.75,0.67,0.65,
##==##                                               0.67,0.70,0.73,0.65,0.63,
##==##                                               0.65,0.69,0.73,0.65,0.63],
                                } } ],
                           "FastSim":
                           [ {"Name":"PhDefault",
                              "Configuration":
                              {"ContainerKey":"AtlfastPhotonCollection",
                               "etCut":15*GeV,
                               "DoPreselection":False,
                               "RemoveOverlapWithSameType" : False,
                               "InsertedLabels":["Atlfast", "Photon"]}}] }
                               
    HighPtInserterBase.__init__(self, name, "EVPhotonInserter", mode, DefaultConfiguration, Configuration, override)
      
