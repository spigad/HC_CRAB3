from EventViewConfiguration.DefaultModules.AANtupleFromUserData_module import *
from EventViewConfiguration.DefaultModules.EVScreenDump_module import *

from EventViewPerformance import *
from EventViewBuilderAlgs.EventViewBuilderAlgsConf import *
from EventViewTrigger import *

from HighPtView.EventDataCalculator_module import *
from HighPtView.HighPtBranchInserters_module import *
from HighPtView.HighPtElectronInserter_module import *
from HighPtView.HighPtEventSelection_module import *
from HighPtView.HighPtInserterCommon_param import *
from HighPtView.HighPtJetInserter_module import *
from HighPtView.HighPtMissingEtInserter_module import *
from HighPtView.HighPtMuonInserter_module import *
from HighPtView.HighPtPhotonInserter_module import *
from HighPtView.HighPtRecoCalculator_module import *
from HighPtView.HighPtSingleInserters_module import *
from HighPtView.HighPtTauJetInserter_module import *
from HighPtView.HighPtTruthCalculator_module import *
from HighPtView.HighPtTruthInserter import *
from HighPtView.HighPtViewAnalysis import *
from HighPtView.HighPtViewModule import *
from HighPtView.MegaMatcher_module import *

class HighPtViewAnalysis:
    def __init__(self,
                 sequencer,
                 mode=["FullReco", "Truth", "Atlfast"],
                 doTrigger=True,
                 doNtupleDump=True,
                 doScreenDump=False,
                 outputLevel=3,
                 kinematicsOnly=False,
                 showUserData=False,
                 detailLevel=["BasicAOD"],
                 saveHLTMET=False,
                 TruthInserter=HighPtTruthInserter,
                 RecoInserter=HighPtSingleInserters,
                 AnalysisModules={},
                 extraMETKeys=[],
                 InserterConfiguration=None,
                 PerfSaveDeltaR=False,
                 trigDecInFullRecTree=True
                ):
        self.theJob=sequencer
        self.Mode=mode
        self.doTrigger=doTrigger
        self.doNtupleDump=doNtupleDump
        self.doScreenDump=doScreenDump
        self.OutputLevel=outputLevel
        self.KinematicsOnly=kinematicsOnly
        self.showUserData=showUserData
        self.DetailLevel=detailLevel
        self.SaveHLTMET=saveHLTMET
        
        self.TruthInserter=TruthInserter
        self.RecoInserter=RecoInserter
        self.AnalysisModules=AnalysisModules

        self.ExtraMETKeys=extraMETKeys
        self.trigDecInFullRecTree=trigDecInFullRecTree
        self.InserterConfiguration=InserterConfiguration

        if "Truth" in self.Mode:
            self.TruthMatch=True
        else:
            self.TruthMatch=False

        self.PerfSaveDeltaR=PerfSaveDeltaR

    def AddAnalysis(self, mode, looper):
        if self.AnalysisModules.has_key(mode):
            Analysis=self.AnalysisModules[mode]
            for ModuleSpec in Analysis:
                Module=ModuleSpec["Module"](name=ModuleSpec["Name"],
                                            **ModuleSpec["Parameters"])
                looper+=Module
        
            
    def schedule(self,name,options="",NtupleName="HighPtView", TreePrefix=""):
        print "Configuring",name,"Branch"
        OutLoopers=[]
        OutStreamAlg=[]
        
        # Truth Insertion
        if "Truth" in self.Mode:
            TruthLooper = EVMultipleOutputToolLooper("TruthLooper"+name)
            TruthLooper.EventViewCollectionOutputName="TruthView"+name
            OutLoopers += [TruthLooper]
            TruthLooper.OutputLevel=self.OutputLevel
            
            TruthLooper += self.TruthInserter("Inserter"+name)
            TruthLooper += HighPtMissingEtInserter("met"+name,"Truth") 
            #this next one is from TopView, shouldn't be here
            TruthLooper += EventDataCalculator("EventData"+name)
            
            # need latest EventViewPerformance
            #TruthLooper += EVUDFinalStateLooper("FSLooper")
            #TruthLooper.FSLooper.Labels=["Truth"]
            #TruthLooper.FSLooper += TruthPdgLabeller("pdglabel")

            # This is a not understood work around for a known problem
            TruthLooperDummy = EVMultipleOutputToolLooper("TruthLooperDummy"+name)
            TruthLooperDummy.EventViewCollectionInputName="TruthView"+name
            TruthLooperDummy.EventViewCollectionOutputName="TruthViewDummy"+name

            OutLoopers += [TruthLooperDummy]


        # Full Reco Insertion And Calculation
        if "FullReco" in self.Mode:
            FullRecoLooper = EVMultipleOutputToolLooper("FullRecoLooper"+name)
            FullRecoLooper.EventViewCollectionOutputName="FullRecoView"+name
            OutLoopers+=[FullRecoLooper]
            FullRecoLooper.OutputLevel=self.OutputLevel

            # Insert objects and label them
            RInserter=self.RecoInserter("Inserters"+name, mode="FullReco",
                                        SaveTruthMET="Truth" in self.Mode,
                                        alg=name,ExtraMETKeys=self.ExtraMETKeys,
                                        Configuration=self.InserterConfiguration)

            FullRecoLooper += RInserter

            if "Truth" in self.Mode:
                FullRecoLooper += EventDataCalculator("EventData"+name)

            # example selection cuts
            #FullRecoLooper += HighPtEventSelection("Selection"+name)

            # fill userdata
            FullRecoLooper +=HighPtRecoCalculator("Calculator"+name, onlyKin=self.KinematicsOnly, truthMatch=self.TruthMatch,
                                                  triggerMatch=self.doTrigger,TruthEVName="TruthView"+name,
                                                  DetailLevel=self.DetailLevel, saveHLTMET=self.SaveHLTMET,
                                                  Labels=RInserter.Labels)

            if self.doTrigger and self.trigDecInFullRecTree:
                from EventViewTrigger.TrigDecisionToolOnAOD_module import TrigDecisionToolOnAOD
                TrigDecisionToolOnAOD().setRelease( "13.0.30" )      
                FullRecoLooper += EVTrigDecisionUserDataAOD( "trigDecision" )

            # UserAnalysis
            self.AddAnalysis("FullReco",FullRecoLooper)
        
            if self.doScreenDump: 
                FullRecoLooper += EVScreenDump("ScreenDumper"+name, printUD=self.showUserData)

            if self.doNtupleDump:
                FullRecoLooper += AANtupleFromUserData("RecoAADumper"+name, filename=NtupleName, \
                                                       sequencer=OutStreamAlg, EventTree=True, CandTree=False,
                                                       Prefix=TreePrefix+"FullRec")

            # This is a not understood work around for a known problem
            RecoLooperDummy = EVMultipleOutputToolLooper("RecoLooperDummy"+name)
            RecoLooperDummy.EventViewCollectionInputName="FullRecoView"+name
            RecoLooperDummy.EventViewCollectionOutputName="FullRecoViewDummy"+name
            OutLoopers += [RecoLooperDummy]


        # AtlFast Insertion and Calculation
        if "Atlfast" in self.Mode:
            FastLooper = EVMultipleOutputToolLooper("fastEVLooper"+name)
            FastLooper.EventViewCollectionOutputName="FastView"+name

            OutLoopers+=[FastLooper]
            FastLooper.OutputLevel=self.OutputLevel

            FRInserter=self.RecoInserter("FInserters"+name, mode="FastSim",
                                         SaveTruthMET="Truth" in self.Mode,
                                         alg=name, ExtraMETKeys=self.ExtraMETKeys,
                                         Configuration=self.InserterConfiguration)
            FastLooper += FRInserter

            FastLooper += HighPtRecoCalculator("FCalculator"+name, DetailLevel=["Kinematics","Jet_Info_C4_:BasicAtlFastAOD"],
                                               triggerMatch=False, truthMatch=self.TruthMatch,
                                               TruthEVName="TruthView"+name,
                                               JetContainers=[["C4_","Cone4TruthJets","Cone4"]],
                                               Labels=FRInserter.Labels)

            if "Truth" in self.Mode:
                FastLooper += EventDataCalculator("EventData"+name)
            
            #FastLooper += HighPtEventSelection("Selection"+name)

            # UserAnalysis
            self.AddAnalysis("Atlfast",FastLooper)

            if self.doScreenDump: 
                FastLooper+=EVScreenDump("ScreenDumper"+name, printUD=self.showUserData)

            if self.doNtupleDump:
                FastLooper += AANtupleFromUserData("FastAADumper"+name, filename=NtupleName, \
                                                   sequencer=OutStreamAlg, EventTree=True, CandTree=False,
                                                   Prefix=TreePrefix+"FastSim")

        # Truth Calculation
        if "Truth" in self.Mode:
            TruthLooperPost = EVMultipleOutputToolLooper("TruthLooperPost"+name)
            TruthLooperPost.EventViewCollectionInputName="TruthView"+name
            TruthLooperPost.EventViewCollectionOutputName="TruthViewPost"+name
            OutLoopers += [TruthLooperPost]
            
            TruthLooperPost.OutputLevel=self.OutputLevel

            if "FullReco" in self.Mode:
                RecoMatch=True
#                RecoMatch=False
                TLabels=RInserter.Labels
            else:
                RecoMatch=False
                TLabels={}
                
            TruthLooperPost += HighPtTruthCalculator("TCalculator"+name,onlyKin=self.KinematicsOnly,
                                                     recoMatch=RecoMatch, MatchEV="FullRecoView"+name,
                                                     Labels=TLabels);

            # UserAnalysis
            self.AddAnalysis("Truth",TruthLooperPost)

            if "Performance" in self.Mode:
                self.AddPerformance(name,TruthLooperPost)

            if self.doScreenDump: 
                TruthLooperPost+=EVScreenDump("TruthScreenDumper"+name, printUD=self.showUserData)

            if self.doNtupleDump: 
                TruthLooperPost+=AANtupleFromUserData("TruthAADumper"+name, filename=NtupleName, \
                                                      sequencer=OutStreamAlg, EventTree=True, CandTree=False,
                                                      Prefix=TreePrefix+"Truth")

        for Alg in OutStreamAlg:
            Same=False
            for Alg2 in OutLoopers:
                if Alg==Alg2:
                    Same=True
            if not Same:
                OutLoopers+=[Alg]
                
        return OutLoopers


    def AddPerformance(self,name,Looper):

        MyTargetEVSpecs =  []

        if "FullReco" in self.Mode:
            MyTargetEVSpecs+=[ { "EventView":"FullRecoView"+name,
                                 "Objects": [ {"Properties": {"Prefix": "R_Mu_",
                                                              "RequireLabels":["Muon"],
                                                              "deltaRmatch":0.05},
                                               "SaveKin":False},
                                              {"Properties": {"Prefix": "R_El_",
                                                              "RequireLabels":["Electron"],
                                                              "deltaRmatch":0.05},
                                               "SaveKin":False},
                                              {"Properties": {"Prefix": "R_Ph_",
                                                              "RequireLabels":["Photon"],
                                                              "deltaRmatch":0.1},
                                               "SaveKin":False},
                                              {"Properties": {"Prefix": "R_Tau_",
                                                              "RequireLabels":["TauJet"],
                                                              "deltaRmatch":0.1}},
                                              {"Properties": {"Prefix":"R_Jet_C7_",
                                                              "RequireLabels": ["Jet","Cone7"],
                                                              "deltaRmatch":0.3}},
                                              {"Properties": {"Prefix":"R_Jet_C4_",
                                                              "RequireLabels": ["Jet","Cone4"],
                                                              "deltaRmatch":0.3}},
                                              {"Properties": {"Prefix":"R_Jet_Kt4_",
                                                              "RequireLabels": ["Jet","Kt4"],
                                                              "deltaRmatch":0.3}},
                                              {"Properties": {"Prefix":"R_Jet_Kt6_",
                                                              "RequireLabels": ["Jet","Kt6"],
                                                              "deltaRmatch":0.3}}
                                              ] }]

        if "Atlfast" in self.Mode:
            MyTargetEVSpecs+=[ { "EventView":"FastView"+name,
                                 "Objects": [ {"Properties": {"Prefix": "F_Mu_",
                                                              "RequireLabels":["Muon"],
                                                              "deltaRmatch":0.05},
                                               "SaveKin":False},
                                              {"Properties": {"Prefix": "F_El_",
                                                              "RequireLabels":["Electron"],
                                                              "deltaRmatch":0.05},
                                               "SaveKin":False},
                                              {"Properties": {"Prefix": "F_Ph_",
                                                              "RequireLabels":["Photon"],
                                                              "deltaRmatch":0.1},
                                               "SaveKin":False},
                                              {"Properties": {"Prefix": "F_Tau_",
                                                              "RequireLabels":["TauJet"],
                                                              "deltaRmatch":0.1}},
                                              {"Properties": {"Prefix":"F_Jet_C4_",
                                                              "RequireLabels": ["Jet","Cone4"],
                                                              "deltaRmatch":0.3}}
                                              ] } ] 
            
        Looper+=MegaMatcher("Perf"+name, SaveDeltaR=self.PerfSaveDeltaR,
                            RootEVSpec = [ {"Properties": {"Prefix":"Mu_",
                                                           "RequireLabels": ["Muon","Stable"], }},
                                           {"Properties": {"Prefix":"El_",
                                                           "RequireLabels": ["Electron","Stable"] }},
                                           {"Properties": {"Prefix":"Ph_",
                                                           "RequireLabels": ["Photon","Stable"] }},
                                           {"Properties": {"Prefix":"Tau_",
                                                           "RequireLabels": ["TruthTau","Stable"] }},
                                           {"Properties": {"Prefix":"Jet_C7_",
                                                           "RequireLabels": ["TruthJet","Cone7"] }},
                                           {"Properties": {"Prefix":"Jet_C4_",
                                                           "RequireLabels": ["TruthJet","Cone4"] }},
                                           {"Properties": {"Prefix":"Jet_Kt4_",
                                                           "RequireLabels": ["TruthJet","Kt4"] }},
                                           {"Properties": {"Prefix":"Jet_Kt6_",
                                                           "RequireLabels": ["TruthJet","Kt6"] }},
                                           ],
                            TargetEVSpecs=MyTargetEVSpecs,
                            TargetContainerSpecs= [  {"Properties": {"Prefix":"C_El_",
                                                                     "ContainerKey":"ElectronCollection",
                                                                     "deltaRmatch":0.05},
                                                      "Associator":"EVUDToElectronAssociator"},
                                                     {"Properties": {"Prefix":"C_Ph_",
                                                                     "ContainerKey":"PhotonCollection",
                                                                     "deltaRmatch":0.1},
                                                      "Associator":"EVUDToPhotonAssociator"},
                                                     {"Properties": {"Prefix":"C_Mu_Mi_",
                                                                     "ContainerKey":"MuidMuonCollection",
                                                                     "deltaRmatch":0.05},
                                                      "Associator":"EVUDToMuonAssociator"},
                                                     {"Properties": {"Prefix":"C_Mu_St_",
                                                                     "ContainerKey":"StacoMuonCollection",
                                                                     "deltaRmatch":0.105},
                                                      "Associator":"EVUDToMuonAssociator"},
                                                     {"Properties": {"Prefix":"C_Tau_1p3p_",
                                                                     "ContainerKey":"TauJet1p3pCollection",
                                                                     "deltaRmatch":0.1},
                                                      "Associator":"EVUDToTauJetAssociator"},
                                                     {"Properties": {"Prefix":"C_Tau_Rec_",
                                                                     "ContainerKey":"TauJetCollection",
                                                                     "deltaRmatch":0.1},
                                                      "Associator":"EVUDToTauJetAssociator"},
                                                     {"Properties": {"Prefix":"C_Jet_C7_",
                                                                     "ContainerKey":"ConeTowerJets",
                                                                     "deltaRmatch":0.3}},
                                                     {"Properties": {"Prefix":"C_Jet_C4_",
                                                                     "ContainerKey":"Cone4TowerJets",
                                                                     "deltaRmatch":0.3}},
                                                     {"Properties": {"Prefix":"C_Jet_Kt4_",
                                                                     "ContainerKey":"Kt4TowerJets",
                                                                     "deltaRmatch":0.3}},
                                                     {"Properties": {"Prefix":"C_Jet_Kt6_",
                                                                     "ContainerKey":"Kt6TowerJets",
                                                                     "deltaRmatch":0.3}},
                                                     {"Properties": {"Prefix":"C_L1_EmTau_ROI_",
                                                                     "ContainerKey":"Temp_EmTauRoIContainer",
                                                                     "deltaRmatch":0.1}},
                                                     {"Properties": {"Prefix":"C_L1_EmTau_",
                                                                     "ContainerKey":"Temp_EmTauObjContainer",
                                                                     "deltaRmatch":0.1}},
                                                     {"Properties": {"Prefix":"C_L1_Jet_",
                                                                     "ContainerKey":"Temp_JetObjContainer",
                                                                     "deltaRmatch":0.3}},
                                                     {"Properties": {"Prefix":"C_L1_Jet_ROI_",
                                                                     "ContainerKey":"Temp_JetRoIContainer",
                                                                     "deltaRmatch":0.3}},
                                                     {"Properties": {"Prefix":"C_L1_Mu_",
                                                                     "ContainerKey":"Temp_MuonRoIContainer",
                                                                     "deltaRmatch":0.1}},
                                                     {"Properties": {"Prefix":"C_L2_El_",
                                                                     "ContainerKey":"Temp_L2ElectronContainer",
                                                                     "deltaRmatch":0.1}},
                                                     {"Properties": {"Prefix":"C_L2_Mu_",
                                                                     "ContainerKey":"Temp_L2MuonContainer",
                                                                     "deltaRmatch":0.1}},
                                                     {"Properties": {"Prefix":"C_L2_Tau_",
                                                                     "ContainerKey":"Temp_L2TauContainer",
                                                                     "deltaRmatch":0.1}},
                                                     {"Properties": {"Prefix":"C_L2_Ph_",
                                                                     "ContainerKey":"Temp_L2PhotonContainer",
                                                                     "deltaRmatch":0.1}},
                                                     {"Properties": {"Prefix":"C_L2_Jet_",
                                                                     "ContainerKey":"Temp_L2JetContainer",
                                                                     "deltaRmatch":0.3}},
                                                     {"Properties": {"Prefix":"C_EF_El_",
                                                                     "ContainerKey":"Temp_EFElectronContainer",
                                                                     "deltaRmatch":0.1}},
                                                     {"Properties": {"Prefix":"C_EF_Mu_",
                                                                     "ContainerKey":"Temp_EFMuonContainer",
                                                                     "deltaRmatch":0.1}},
                                                     {"Properties": {"Prefix":"C_EF_Tau_",
                                                                     "ContainerKey":"Temp_EFTauContainer",
                                                                     "deltaRmatch":0.1}},
                                                     {"Properties": {"Prefix":"C_EF_Jet_",
                                                                     "ContainerKey":"Temp_EFJetContainer",
                                                                     "deltaRmatch":0.3}},
                                                     ]
                            )
            
        
