# Author: Kyle Cranmer
# Modified for EVCopyReco and EVCopyTruth by Frank Paige, February 2006

########### Reco EventView
# Use EV*Inserter tools to make RecoView for reconstruction and
# TruthView for MC truth. Modified from DefaultEventView_jobOptions.py.
# We avoid using UserData and so include MissingET objects in output.

from EventViewCopiers.EventViewCopiersConf import *
from McParticleTools.McParticleToolsConf import *

# Modified from TruthEventView_jobOptions. New EVTruthParticleInserter
# takes a list of pdgId codes. Some standard lists:

pdgBottom = [511, 521, 531, 5122, 5112, 5212, 5222]
pdgCharm  = [411, 421, 431, 4122, 4222,4212, 4112]
pdgSM     = [4, 5, 6, 15, 23, 24, 25]
pdgHiggs  = [35, 36, 37, 51] # heavy higgs and h0 in susy
pdgSUSY   = [1000001, 1000002, 1000003, 1000004, 1000005, 1000006,
    1000011, 1000012, 1000013, 1000014, 1000015, 1000016, 
    2000001, 2000002, 2000003, 2000004, 2000005, 2000006,
    2000011, 2000013, 2000015,
    1000021, 1000022, 1000023, 1000024, 1000025, 1000035, 1000037, 
    2000012, 2000014, 2000016,
    1000039]

truthEV = EVToolLooper("truthEV")

truthEV.EventViewOutputName="TruthView"

# The order of these tools matters.  The first tool has the highest
# precdent when resolving overlap. Use deltaRCut<0 for no removal.

truthEV+=EVTruthParticleInserter("truthElectrons")
truthEV+=EVTruthParticleInserter("truthMuons")
truthEV+=EVTruthParticleInserter("truthStable")
truthEV+=EVTruthParticleInserter("truthSpcl")
truthEV+=EVTruthParticleInserter("truthNu")
truthEV+=EVMissingEtUserData("truthMet")

truthEV.truthElectrons.ContainerKey="SpclMC"
truthEV.truthElectrons.pdgCode=[11]
truthEV.truthElectrons.useIsolation=False
truthEV.truthElectrons.onlyStable=True
truthEV.truthElectrons.NoOverlapCheck=True
truthEV.truthElectrons.etCut=5*GeV

truthEV.truthMuons.ContainerKey="SpclMC"
truthEV.truthMuons.pdgCode=[13]
truthEV.truthMuons.useIsolation=False
truthEV.truthMuons.onlyStable=True
truthEV.truthMuons.NoOverlapCheck=True
truthEV.truthMuons.etCut=5*GeV

truthEV.truthStable.ContainerKey="SpclMC"
truthEV.truthStable.pdgCode=[]
truthEV.truthStable.useIsolation=True
truthEV.truthStable.onlyStable=True
truthEV.truthStable.NoOverlapCheck=True
truthEV.truthStable.etCut=5*GeV

truthEV.truthSpcl.ContainerKey="SpclMC"
truthEV.truthSpcl.pdgCode=pdgSM+pdgBottom+pdgCharm+pdgSUSY+pdgHiggs
truthEV.truthSpcl.onlyStable=False
truthEV.truthSpcl.NoOverlapCheck=True

truthEV.truthNu.ContainerKey="SpclMC"
truthEV.truthNu.pdgCode=[12,14,16]
truthEV.truthNu.onlyStable=True
truthEV.truthNu.etCut=5*GeV
truthEV.truthNu.NoOverlapCheck=True

truthEV.truthMet.MissingETTruthKeys=["MET_Truth"]

theJob += truthEV

##################################################
########### Copy Objects and create new EventViews
##################################################

truthCopy = EVCopyTruth("truthCopy")

# These are for the *output* McEventCollection/TruthParticleContainer
truthCopy.EventViewInputName="TruthView"
truthCopy.EventViewOutputName="truthEVOut"
truthCopy.HepMcInputName="GEN_AOD"
truthCopy.HepMcOutputName="GEN_EV"

truthCopy+= EVTruthParticleCopier("EVTruthParticleCopier")

theJob +=  truthCopy 

