from AthenaCommon.SystemOfUnits import GeV
from HighPtView.HighPtViewModule import HighPtViewModule
from EventViewUserData.EventViewUserDataConf import *

class HighPtMissingEtInserter(HighPtViewModule):

  def setAffiliation(self):
    self._group = "EV Team"
    self._author = "AS"
    self._description = "EtMiss Inserter with HighPt configuration"

  def __init__(self, name, mode="FullReco", SaveTruthMET=False, ExtraMETKeys=[], *override):

    self.overrideParam=override
    self.mode=mode
    self.SaveTruthMET=SaveTruthMET
    self.RecoKeys=["MET_Final","MET_Base","MET_Calib","MET_Muon","MET_MuonBoy","MET_Final","MET_Cryo","MET_CryoCone","MET_Topo", "MET_RefFinal", "ObjMET_Final"]+ExtraMETKeys

    
    HighPtViewModule.__init__(self, name)

  def schedule(self):

    self += EVMissingEtUserData("HighPtMissEtInserter"),

  def setEVDefaults(self):
    
    if "FullReco" in self.mode:
      self.HighPtMissEtInserter.setProperty({
        "MissingETKeys" : self.RecoKeys ,
      })

      if self.SaveTruthMET:
        self.HighPtMissEtInserter.setProperty({
          "MissingETTruthKeys" : ["MET_Truth","MET_Truth_PileUp"],
          "MissingETTruthSources" : ["Int","NonInt","IntCentral","IntFwd","IntOutCover","Muons"],
          })

    if "FastSim" in self.mode:
      self.HighPtMissEtInserter.setProperty({
        "MissingETKeys" : ["AtlfastMissingEt"],
      })

    if "Truth" in self.mode:
      self.HighPtMissEtInserter.setProperty({
        "MissingETKeys" : [],
        "MissingETTruthKeys" : ["MET_Truth","MET_Truth_PileUp"],
        "MissingETTruthSources" : ["Int","NonInt","IntCentral","IntFwd","IntOutCover","Muons"],
      })
      # We want the true MET in the Reco EV

    for i in self.overrideParam:
      self.HighPtMissEtInserter.setProperty(i)

  def override(self,*override):
    for i in override:
      self.HighPtMissEtInserter.setProperty(i)
      
