from EventViewInserters.EventViewInsertersConf import *
from HighPtView.HighPtViewModule import *

class HighPtTruthInserter(HighPtViewModule):
  """Truth inseter"""

  def setAffiliation(self):
    self._group = "EV team"
    self._author = "AS"
    self._description = "Inserters for truth objects"

  def __init__(self, name):
    HighPtViewModule.__init__(self, name)

  def schedule(self):
    self +=  EVTruthParticleInserter("TruthMuInserter")
    self +=  EVTruthParticleInserter("TruthElInserter")
    self +=  EVTruthParticleInserter("TruthPhInserter")
    self +=  EVTruthParticleInserter("TruthInserter")

    self +=  EVTruthTauDecayCompositeCreator("TauCreator")
    self +=  EVCompositeParticleInserter("TauInserter")
    self +=  EVJetInserter("TruthJetInserterCone4")
    self +=  EVJetInserter("TruthJetInserterCone7")
    self +=  EVJetInserter("TruthJetInserterKt4")
    self +=  EVJetInserter("TruthJetInserterKt6")

  def setEVDefaults(self):

    self.TruthMuInserter.setProperty({
      "ContainerKey":"EVTruthParticles",
      "NoOverlapCheck":True,
#      "useIsolation":True,  # No truth isolation requirement for Muons
#      "absoluteIsolationCut":5*GeV,
      "SelectedLabels":["Visible", "Stable", "Muon", "Truth"],
      "onlyStable":True,
      "makeEtaCuts":False,
      "pdgCode" : [13],
      "etCut":0,
    })

    self.TruthElInserter.setProperty({
      "ContainerKey":"EVTruthParticles",
      "NoOverlapCheck":True,
      "useIsolation":True,
      "absoluteIsolationCut":5*GeV,
      "SelectedLabels":["Visible", "Stable", "Electron", "Truth"],
      "onlyStable":True,
      "makeEtaCuts":False,
      "pdgCode" : [11],
      "etCut":0,
    })
    
    self.TruthPhInserter.setProperty({
      "ContainerKey":"EVTruthParticles",
      "NoOverlapCheck":True,
      "useIsolation":True,
      "absoluteIsolationCut":5*GeV,
      "SelectedLabels":["Visible", "Stable", "Photon", "Truth"],
      "onlyStable":True,
      "makeEtaCuts":False,
      "pdgCode" : [22],
      "etCut":0,
    })

    #Insert Everything else
    self.TruthInserter.setProperty({
      "ContainerKey":"EVTruthParticles",
      "DoPreselection":False,
      "makeEtaCuts":False,
      "etCut":0,
      "deltaRCut":0.00001, # We don't want to reinsert Mu, El, Ph
      "InsertedLabels":["Truth"],
    })

    self.TauCreator.setProperties(
      LabelToAssocTo="TruTau",
      OutputContainerKey="VisibleTruthTauDecayProducts"+self.name(),
      KeepLeptonicDecays=False
      )

    self.TauInserter.setProperties(
      ContainerKey="VisibleTruthTauDecayProducts"+self.name(),
      usePdgCodeSign=False,
      onlyStable=False,
      useIsolation=False,
      relativeIsolationCut=1.,
      NoOverlapCheck = True, # loses a lot due to overlap with photon
      InsertedLabels=["TruthTau", "Visible", "Stable"],
      )

    TruJetProperty={
      "NoOverlapCheck":False,
      "deltaRCut" : 0.3,
      "DoPreselection":False,
      "makeEtaCuts":False,
      "etCut":0,
      "RejectLabels":["Muon"],
      "RequireLabels":["Visible", "Stable"],
      "RemoveOverlapWithSameType" : False,
    }

    self.TruthJetInserterCone4.setProperty(TruJetProperty)
    self.TruthJetInserterCone4.setProperties(ContainerKey="Cone4TruthJets", InsertedLabels=["TruthJet","Cone4"])
    self.TruthJetInserterCone7.setProperty(TruJetProperty)
    self.TruthJetInserterCone7.setProperties(ContainerKey="Cone7TruthJets", InsertedLabels=["TruthJet", "Cone7"])
    self.TruthJetInserterKt4.setProperty(TruJetProperty)
    self.TruthJetInserterKt4.setProperties(ContainerKey="Kt4TruthJets", InsertedLabels=["TruthJet", "Kt4"])
    self.TruthJetInserterKt6.setProperty(TruJetProperty)
    self.TruthJetInserterKt6.setProperties(ContainerKey="Kt6TruthJets", InsertedLabels=["TruthJet", "Kt6"])
    
