j = Job()
j.application=Athena()
j.application.option_file=['HighPtViewNtuple_topOptions.py' ]
j.application.athena_compile=False
j.application.collect_stats=True
j.application.prepare()
j.inputdata=DQ2Dataset()
j.inputdata.dataset='mc08.105401.SU1_jimmy_susy.recon.AOD.e352_s462_r541_tid026109'
j.outputdata=DQ2OutputDataset()
j.splitter=DQ2JobSplitter()
#j.splitter.numsubjobs = 25
j.backend=Panda()
j.backend.cloud = 'DE'
j.submit() 
