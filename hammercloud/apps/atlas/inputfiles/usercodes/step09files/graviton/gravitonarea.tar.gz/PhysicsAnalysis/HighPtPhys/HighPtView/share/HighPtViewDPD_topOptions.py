##################################################################
# Author: Akira Shibata (ashibata@cern.ch)
#         Amir Farbin (afarbin@cern.ch)
##################################################################

###########################################
# Common imports and includes (no need to edit)
###########################################
from AthenaCommon.Constants import *
from AthenaCommon.AppMgr import theApp
from AthenaCommon.AppMgr import ServiceMgr as svcMgr
import AthenaPoolCnvSvc.ReadAthenaPool

from EventViewPerformance import *
from HighPtView.HighPtViewAnalysis import *

#from TopView import *
#theApp.Dlls += ["TopView"]
theApp.Dlls += ["EventViewPerformance"]
theApp.Dlls += ["EventViewTrigger"]
theApp.Dlls += ["EventViewSelectors"]
include("EventViewConfiguration/EventViewFullInclude_jobOptions.py")

###########################################
# Job Properties setting (change as appr)
###########################################
# specify input filea

if not isinstance(EventSelector.InputCollections,list):
  EventSelector.InputCollections = ["AOD.pool.root"]

###########################################
# Pre-config settings (change as appropriate)
###########################################
# instanciate the top alg sequence for athena, only one is required
theJob = AlgSequence()

# you can set the following option from outside either by using -c option of athena
# or including another joboption BEFORE this jobOption. That's what the "if not..." does
# so the following is the default
if not "Mode" in dir():                Mode=["FullReco", "Truth", "Atlfast"]
if not "Branches" in dir():            Branches= ["MuidTau1p3p"] #,"MuidTauRec","StacoTau1p3p","StacoTauRec"]
if not "KinematicsOnly" in dir():      KinematicsOnly=False # This overrides DetailLevel setting it to Kinematics
if not "DPDFileName" in dir():         DPDFileName="HighPtView.DPD"
if not "DoScreenDump" in dir():        DoScreenDump=False
if not "ShowUserData" in dir():        ShowUserData=False
if not "DoNtupleDump" in dir():        DoNtupleDump=True
if not "OutputLevel" in dir():         OutputLevel=3
if not "DoTrigger" in dir():           DoTrigger=False
if not "OutputDirectory" in dir():     OutputDirectory="."
if not 'SingleHPTVFile' in dir():      SingleHPTVFile=False
if not "TriggerLevels" in dir():       TriggerLevels=[ "L1", "L2", "EF",
                                                       "Muon", "E/Gamma", "Electron", "Photon", "Tau",
                                                       "Jet", "MissingEt" ]
if not "SaveHLTMET" in dir():          SaveHLTMET=True # Our test AOD sample didn't have this info

if not "TruthInserter" in dir():       TruthInserter=HighPtTruthInserter
if not "RecoInserter" in dir():        RecoInserter=HighPtSingleInserters
if not "AnalysisModules" in dir():     AnalysisModules={}

if not "ExtraMETKeys" in dir():        ExtraMETKeys=[]

if not "TriggerView" in dir():         TriggerView=False

if not "InserterConfiguration" in dir(): InserterConfiguration=None

if not "PerfSaveDeltaR" in dir():      PerfSaveDataR=False

if not "OutputPOOLBasedDPD" in dir(): OutputPOOLBasedDPD=True

if not "DetailLevel" in dir():
  DetailLevel=[] 

if DoNtupleDump and DetailLevel==[]:  DetailLevel+=["BasicAOD"] # Or "FullStandardAOD", "Kinematics", ...

if OutputPOOLBasedDPD:  DetailLevel+=["Thin"] # Or "FullStandardAOD", "Kinematics", ...

if not "StoreGateDump" in dir():       StoreGateDump=False
if not "PerfMon" in dir():             PerfMon=False
if not "DumpIN4M" in dir():            DumpIN4M=False

NtupleName=DPDFileName+".AANT.root"

###############################
# Various Standard Athena Dumping
###############################
if StoreGateDump:
  print "Setting StoreGateDump"
  StoreGateSvc = Service( "StoreGateSvc" )
  StoreGateSvc.Dump = True  

if PerfMon:
  from PerfMonComps.PerfMonFlags import jobproperties
  jobproperties.PerfMonFlags.doMonitoring = True
  jobproperties.PerfMonFlags.doPersistencyMonitoring = True
  jobproperties.PerfMonFlags.OutputFile = "thinned.atlfast.aod.pmon.gz"

  from PerfMonComps.JobOptCfg import PerfMonSvc
  svcMgr += PerfMonSvc( "PerfMonSvc", OutputLevel = INFO )

if DumpIN4M:
  from EventCommonAlgs.EventCommonAlgsConf import INav4MomDumper
  theJob += INav4MomDumper(
    INav4Moms    = ["Cone4H1TowerJets","ElectronAODCollection"],
    OutputStream = DPDFileName+"thinned.inav4moms.log",
    OutputLevel  = INFO
    )

###############################
# Prepare for thinning 
###############################
if OutputPOOLBasedDPD:
  include("HighPtView/ThinningInitialization_jobOptions.py")
  
###########################################
# Prepare Truth Objects
###########################################
if "Truth" in Mode:
  include("HighPtView/TruthThinning_jobOptions.py")

###########################################
# Prepare Trigger Objects
###########################################
if DoTrigger:
  include("HighPtView/TriggerPrep_jobOptions.py")

print "Configuring HighPtView..."
###########################################
# General Configuration
###########################################

MyAnalysis=HighPtViewAnalysis(theJob,
                              mode=Mode,
                              doTrigger=DoTrigger,
                              doNtupleDump=DoNtupleDump,
                              doScreenDump=DoScreenDump,
                              outputLevel=OutputLevel,
                              kinematicsOnly=KinematicsOnly,
                              showUserData=ShowUserData,
                              detailLevel=DetailLevel,
                              saveHLTMET=SaveHLTMET,
                              TruthInserter=TruthInserter,
                              RecoInserter=RecoInserter,
                              AnalysisModules=AnalysisModules,
                              extraMETKeys=ExtraMETKeys,
                              InserterConfiguration=InserterConfiguration)

###########################################
# The Analysis
###########################################
branchNum=0

HPTVSequence=[]

for Branch in Branches:
  if 'HPTVNtupleOutput' in dir():
    if SingleHPTVFile:
      HPTVSequence+=MyAnalysis.schedule(Branch,NtupleName=SingleHPTVNtupleOutput, TreePrefix=Branch+"_")
    else:
      HPTVSequence+=MyAnalysis.schedule(Branch,NtupleName=HPTVNtupleOutput[branchNum])
    branchNum+=1
  else:
    if SingleHPTVFile:
      HPTVSequence+=MyAnalysis.schedule(Branch,NtupleName=OutputDirectory+"/"+NtupleName, TreePrefix=Branch+"_")
    else:
      HPTVSequence+=MyAnalysis.schedule(Branch,NtupleName=OutputDirectory+"/"+Branch+"_"+NtupleName)

# Move ntuple streams to the END

NtupleStreams=[]

for Step in HPTVSequence:
  if 'EVAANtupleDump' in Step.name():
    NtupleStreams+=[Step]
  else:
    theJob+=Step

theJob+=NtupleStreams

if OutputPOOLBasedDPD:
  include("HighPtView/POOLDPDOutput_jobOptions.py")

print "Done Configuring HighPtView..."

###########################################
# Final setup (no need to edit)
###########################################
MessageSvc.Format = "% F%70W%S%7W%R%T %0W%M"
SCService=Service("StatusCodeSvc")
SCService.SuppressCheck=True
print theJob
print "TopAlg:"
print theApp.TopAlg
