##################################################################
#
# File: TopView/python/EventDataCalculator.py
# Author: Akira Shibata (ashibata@cern.ch)
#
##################################################################

# calculate event-scale variables such as Missing Et, event weight etc

from HighPtView.HighPtViewModule import *
from EventViewUserData.EventViewUserDataConf import *

class EventDataCalculator(HighPtViewModule):
  
  def setAffiliation(self):
    self._group = "HighPt"
    self._author = "AS"
    self._description = "Event data calculators"

  def __init__(self, name):
    HighPtViewModule.__init__(self,name)

  def schedule(self):
    self += [ 
              EVEventInfoUserData("EventInfo"),
            ]

  def setEVDefaults(self):
    self.OutputLevel=3
