from AthenaCommon.SystemOfUnits import GeV
from HighPtView.HighPtViewModule import HighPtViewModule
from HighPtView.HighPtElectronInserter_module import *
from HighPtView.HighPtMuonInserter_module import *
from HighPtView.HighPtPhotonInserter_module import *
from HighPtView.HighPtTauJetInserter_module import *
from HighPtView.HighPtJetInserter_module import *
from HighPtView.HighPtJetInserter_module import *
from HighPtView.HighPtMissingEtInserter_module import *
from HighPtView.HighPtInserterCommon_param import *


class HighPtSingleInserters(HighPtViewModule):

  def setAffiliation(self):
    self._group = "EV Team"
    self._author = "AS"
    self._description = "Single branch inserters"

  def __init__(self, name, mode="FullReco", SaveTruthMET=False, alg="",ExtraMETKeys=[],
               JetAlgs=["Cone4", "Cone7", "Kt4", "Kt6"],
               Configuration={}):
    """ alg is Muid, Staco, TauRec, 1p3p"""
    self.mode=mode
    self.alg=alg
    self.JetAlgs=JetAlgs
    self.SaveTruthMET=SaveTruthMET
    self.ExtraMETKeys=ExtraMETKeys
    self.Configuration=Configuration
    self.Labels={}
    HighPtViewModule.__init__(self, name)

  def FindConfiguration(self,Name):
    if type(self.Configuration) == dict:
      if self.Configuration.has_key(Name):
        return self.Configuration[Name]

    return None

  def GetLabels(self,name,inserter):
    L=[] 
    if "Labels" in dir(inserter):
      if len(inserter.Labels)>1:
        L=inserter.Labels

    if self.Labels.has_key(name):
      self.Labels[name]+=L
    else:
      self.Labels[name]=L

  def AppendDicts(self,a,b):
    for key in b:
      a[key]=b[key]

  def schedule(self):

    InserterParameter = HighPtInserterCommon_Parameters("common")

    commonParam=InserterParameter.CommonParameters

    if type(self.Configuration) == dict:
      if self.Configuration.has_key("CommonParameters"):
        self.AppendDicts(commonParam,self.Configuration["CommonParameters"])

    el       = HighPtElectronInserter("Electron", self.mode ,override=commonParam,
                                      Configuration=self.FindConfiguration("Electron"))
    mu       = HighPtMuonInserter("Muon", self.mode+self.alg, override=commonParam,
                                  Configuration=self.FindConfiguration("Muon"))
    ph       = HighPtPhotonInserter("Photon", self.mode, override=commonParam,
                                    Configuration=self.FindConfiguration("Photon"))
    tau      = HighPtTauJetInserter("Tau", self.mode+self.alg,override=commonParam,
                                    Configuration=self.FindConfiguration("Tau"))
    self.GetLabels("Electron",el)
    self.GetLabels("Muon",mu)
    self.GetLabels("Photon",ph)
    self.GetLabels("Tau",tau)
    
    jetAlgs=[]
    jetconf=Configuration=self.FindConfiguration("Jet")
    if "Cone4" in self.JetAlgs:
      jetcone4 = HighPtJetInserter("JetC4", self.mode+"Cone4",
                                   override=commonParam,Configuration=jetconf);
      jetAlgs+=[jetcone4]
      self.GetLabels("Jet",jetcone4)
    if "Cone7" in self.JetAlgs:
      jetcone7 = HighPtJetInserter("JetC7", self.mode+"Cone7",
                                   override=commonParam,Configuration=jetconf);
      jetAlgs+=[jetcone7]
      self.GetLabels("Jet",jetcone7)
    if "Kt4" in self.JetAlgs:
      jetkt4   = HighPtJetInserter("JetKt4", self.mode+"Kt4",
                                   override=commonParam,Configuration=jetconf);
      jetAlgs+=[jetkt4]
      self.GetLabels("Jet",jetkt4)
    if "Kt6" in self.JetAlgs:
      jetkt6   = HighPtJetInserter("JetKt6", self.mode+"Kt6",
                                           override=commonParam,Configuration=jetconf);
      jetAlgs+=[jetkt6]
      self.GetLabels("Jet",jetkt6)
      
    met      = HighPtMissingEtInserter("met", self.mode, SaveTruthMET=self.SaveTruthMET, ExtraMETKeys=self.ExtraMETKeys)

    InserterList=[]

    if "FullReco" in self.mode:
      InserterList += [ mu, el, ph, tau ]
      InserterList += jetAlgs
      InserterList += [ met ]

    if "FastSim" in self.mode:
      InserterList += [ mu, el, ph, tau, jetcone4, met ]

    self += InserterList

  def setEVDefaults(self):
    
    pass
