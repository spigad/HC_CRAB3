# -----------------------------------------------------------
# HPTV Standard Performance Plot SPyRoot Macro
#
# Author: Amir Farbin
#
# NOTE: YOU WILL NEED ROOT VERSION >= 5.15
#
# -----------------------------------------------------------

# Use SPyRoot's file/sample book-keeping:
from SPyRoot import SampleHandler
Data=SampleHandler.SampleGroup()

#--------------------------------------------------------------
# Add Files to the data sample
#--------------------------------------------------------------
# Syntax:
# Data.AddFile(<SampleName>,<filename>,<TTreeName>,<XSection>)
# In example below:
#
# <SampleName> is the name you will use to refer to this sample.
#   Note that SPyRoot can simultaneously handle multiple samples.
#
# <filename> is the name of the input root file. You can chain
#   multiple files in the same sample by simply calling this
#   function with different filename and same <samplename>.
#
# <TTreeName> is the name of the TTree in the file. In this 
#   example we use the HPTV Truth0 tree.
#
# <XSection> (optional). SPyRoot uses XSection for properly
#   normalizing plots. In this example, we use it to plot rates.
#
#--------------------------------------------------------------

# Single file read example:
# ******* Change this to point to YOUR HPTV ntuple output *******
#Data.AddFile("SU3","./MuidTauRec_SUSYView.AAN.root","Truth0",19.)
Data.AddFile("SU3","/data/afarbin/MuidTau1p3p_HighPtAANtuple.root","Truth0",19.)

# The following example chains all files in a directory which have
# "MuidTau1p3p" in their names.
#Data.AddDirectory("SU3","/data/afarbin/","Truth0","MuidTau1p3p",19.)

# We'll use "TheSample" string to specify which sample we will use
# for plots. 
TheSample='SU3'

# Get the TTree from the Data Sample Handler. We will use it to
# figure out what variables are in the ntuple.
ExampleTree=Data.Samples[TheSample].Chain

#--------------------------------------------------------------
# Load Basic SPyRoot TTree looping tools
#--------------------------------------------------------------

from SPyRoot import TTreeAlgorithmLooper,TTreeHelpers

#--------------------------------------------------------------
# Load the Eff Matrix calculator and plotter algorithms from HighPtView/SPyRoot
#--------------------------------------------------------------
from EfficiencyMatrix import *
from EfficiencyPlotter import *
from GeneralProfiler import *

#--------------------------------------------------------------
# Create a new "Analysis"
#--------------------------------------------------------------
Analysis=TTreeAlgorithmLooper("PerformanceAnalysis")

#--------------------------------------------------------------
# List of prefixes for truth objects in Truth0 tree.
#--------------------------------------------------------------
TruthObjTypes=["Mu_","El_","Ph_","Tau_","Jet_C4_",] #"Jet_C7_","Jet_Kt4_","Jet_Kt6_"]

#--------------------------------------------------------------
# Add for any additional labels to check for each type
#--------------------------------------------------------------
LabelsToCheck={}
LabelsToCheck["El_"]=["El_R_ElTight","El_R_ElMedium","El_R_ElLoose"]

#--------------------------------------------------------------
# Add the Efficiency Matrix Algorithm.
# (Branches specifies what Branches to activate)
# Uncomment this if you want to print out matrices
#--------------------------------------------------------------
#Analysis.AddAlgorithm( EfficiencyMatrix("Matrix",TruthObjTypes,Branches=["*Matched","*_N"]))

#--------------------------------------------------------------
# Small macro to find all variables with "Matched" in their names
# and create a cut.
#--------------------------------------------------------------
def cuts(require,T):
    return map(lambda x: [x[len(require):], "T."+x+"[i]==1"],
               filter(lambda x: x.find(require)==0,
                      TTreeHelpers.GetLeafNames( T, "Matched")))


#--------------------------------------------------------------
# Macro for cutting on Labels
#--------------------------------------------------------------
def labelcuts(Type):
    outcuts=[]
    if LabelsToCheck.has_key(Type):
        Labels=LabelsToCheck[Type]
        for Label in Labels:
            outcuts+=[[Label,"T."+Label+"[i]==1"]]
            
    return outcuts
    
#--------------------------------------------------------------
# Small macro to define what histograms to make
#--------------------------------------------------------------
def vars(require):
    return [[require+"p_T",100, 10000, 500000, "(MeV)"],
            [require+"phi",64, -3.15, 3.15, "(rad)"],
            [require+"eta",50,-5,5]]

#--------------------------------------------------------------
# Small macro to help add multiple instances of the EfficiencyPlotter
# Algorithm... one per truth type.
#--------------------------------------------------------------
def EfficiencyPlotterObj(require):
    print cuts(require,ExampleTree)+labelcuts(require)
    return EfficiencyPlotter(require+"Eff",
                             vars(require),
                             require+"N",
                             "T."+require+"N>0",
                             "T."+require+"p_T[i]>10000",
                             cuts(require,ExampleTree), #+labelcuts(require),
                             [require+"p_T",
                              require+"eta",
                              require+"phi",
                              require+"*Matched",
                              require+"N"])

#--------------------------------------------------------------
# Add one EfficiencyPlotter Algorithm per Truth type
#--------------------------------------------------------------
for ObjType in TruthObjTypes:
    Analysis.AddAlgorithm( EfficiencyPlotterObj(ObjType))


Analysis.AddAlgorithm(GeneralProfiler(
    "Try1",
    [
     #["T.El_R_p_T[i]-T.El_p_T[i]",50,1000,100000,"El_N","T.El_R_Matched[i]==1"],
     ["T.El_R_p_T[i]/T.El_p_T[i]",50,-1.0,2.0,"El_N","T.El_R_Matched[i]==1"]
    ],
    [
     #["El_p_T",50,1000,100000,"El_N","El_R_Matched"],
     ["T.El_eta[i]",20,-4.0,4.0,"El_N"],
     #["El_phi",50,-3.14,3.14,"El_N","El_R_Matched"]
    ],
    ["*","El_p_T","El_eta","El_phi","El_N","El_R_Matched","El_R_p_T"]))
                             

#--------------------------------------------------------------
# Print Event Number every 100 events
#--------------------------------------------------------------
Analysis.SetDebug(1,100)

#--------------------------------------------------------------
# Run the analysis on events in the HPTV Truth0 TTree.
# MaxEntries is optional. (-1 means all)
#--------------------------------------------------------------
Results=Analysis.Loop(Data.Samples[TheSample].Chain,MaxEntries=-1)

# Results Now holds a efficiency matrix, lots of efficiency and rate plots.

#--------------------------------------------------------------
# Now make some nice plots. (Examples here... but you can do this interactively)
# Specify PrintPrefix to get the plots printed.
# Change default print type by specifying PrintType=".eps" (for example)
#--------------------------------------------------------------
import NiceEfficiencyPlots

# Make the Efficiency Plots
NEP=NiceEfficiencyPlots.NiceEfficiencyPlots(Results,MaxFigs=12,MaxPlotsPerFig=4) #,PrintPrefix="Eff_"+TheSample+"_")
# Plot Efficiency of reco'ing/selecting Electron (Muon) as almost any type in the AOD.
# Specify different/more truth types if you like.
NEP.PlotAll("El_")
NEP.PlotAll("Mu_")

# Plot the rate of truth jets to be reco'ed/selected as almost any type in the AOD.
NEP2=NiceEfficiencyPlots.NiceEfficiencyPlots(Results,MaxFigs=12,MaxPlotsPerFig=4,HistRequire="N_") #,PrintPrefix="Rate_"+TheSample+"_")
NEP2.PlotAll("Jet_C4_")

#--------------------------------------------------------------
# Print out Eff/Mis-id matrix.
#--------------------------------------------------------------
#EM=MatrixPrinter(res['Matrix'])

#Everything!
#EM.PrintMatrix()

#Any column which has El_ or Em_ (for L1 Electrons)
#EM.PrintMatrix(["El_","Em_"])

