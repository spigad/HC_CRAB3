#ifndef BUSTOP_TTREE_WRITER_H
#define BUSTOP_TTREE_WRITER_H

#include "GaudiKernel/Algorithm.h"

#include "CLHEP/Units/SystemOfUnits.h"

#include "StoreGate/StoreGateSvc.h"

#include "GaudiKernel/ToolHandle.h"

#include <stdint.h>
#include <string>

class ITHistSvc;
class TH1F;
class TH2F;
class TTree;

class IAnalysisTools;
class IEventTool;
class IEventTagTool;

namespace Analysis{
  class MuonContainer;
}

class ElectronContainer;
class JetCollection;
class Jet;
class MissingET;
class CompositeParticleContainer;
class NeutrinoContainer;

class BUSTopTTreeWriter : public Algorithm {

 public:

   BUSTopTTreeWriter(const std::string& name, ISvcLocator* pSvcLocator);
   ~BUSTopTTreeWriter();

   StatusCode initialize();
   StatusCode finalize();
   StatusCode execute();
  
 private:
   StoreGateSvc*  m_storeGate;
   ITHistSvc*     m_histSvc;
   IEventTool*    m_eventTool;
   IEventTagTool* m_tagTool;

   double m_eventWeight;
   std::string m_jetWeightTagger;

   double m_primary_lepton_pt;
   double m_primary_lepton_isolation;
   double m_secondary_lepton_pt;

   double m_et_miss;

   double m_n_bjets;
   double m_total_jet_weight;
   double m_primary_bjet_weight;
   double m_primary_bjet_truth;
   double m_primary_bjet_pt;
   double m_secondary_bjet_pt;

   double m_n_ljets;
   double m_primary_ljet_eta;
   double m_primary_ljet_pt;
   double m_primary_ljet_e;
   double m_secondary_ljet_e;

   double m_selected_jet_centrality;

   double m_lep_chi;
   double m_b_chi;
   double m_b_lep_chi;

   double m_top_mass;

   std::string m_electronContainerName;
   std::string m_muonContainerName;
   std::string m_bjetContainerName;
   std::string m_ljetContainerName;
   std::string m_metContainerName;

   std::string m_neutrinoContainerName;
   std::string m_wContainerName;
   std::string m_topContainerName;

   virtual void registerHistograms();
   virtual void registerTTrees();
   virtual void getEventWeight();

   virtual void clearTreeVariables();
   virtual void writeTreeVariables();

   virtual void getLeptonVariables();
   virtual void getJetVariables();
   virtual void getEtMissVariables();
   virtual void getTopVariables();

   virtual void getSpinVariables();

   virtual double getFlavourTagWeight(const Jet* j);
   virtual double getFlavourTagTruth(const Jet* j);
   virtual std::string getTruthLabel(const Jet* j);

   virtual void getStoregateContainers();

   TTree* t_passed;

   const Analysis::MuonContainer* muonTES;
   const ElectronContainer* elecTES;
   const JetCollection* bjetTES;
   const JetCollection* ljetTES;
   const MissingET* metTES;

   const NeutrinoContainer* nuTES;
   const CompositeParticleContainer* topTES;
   const CompositeParticleContainer* wTES;
};

#endif // BUSTOP_TTREE_WRITER_H


