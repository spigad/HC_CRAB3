#include "BUSTopTools/METHistograms.h"
#include "BUSTopTools/BUSTopHistogrammer.h"

#include "StoreGate/StoreGateSvc.h"
#include "StoreGate/DataHandle.h"

#include "McParticleEvent/TruthParticleContainer.h"
#include "EventKernel/PdtPdg.h"
#include "AnalysisUtils/IParticleFilter.h"
#include "AnalysisUtils/AnalysisMisc.h"

#include <iostream>
#include <string>
#include <queue>

#include "TH1.h"
#include "TH2.h"

METHistograms::METHistograms(IBUSTopHistogrammer* parent, std::string algName, std::string dirName, std::string hN){
  std::stringstream fname, hname, title;

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "_etx";
  fname << "/AANT/"<< algName <<"/" << dirName << "/" << hname.str();
  title << "E_{T}^{x}";
  parent->registerHistogram(etx, fname.str(), hname.str(), title.str(), "E_{T}^{x} [GeV]", 300, 0, 300);

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "_ety";
  fname << "/AANT/"<< algName <<"/" << dirName << "/" << hname.str();
  title << "E_{T}^{y}";
  parent->registerHistogram(ety, fname.str(), hname.str(), title.str(), "E_{T}^{y} [GeV]", 300, 0, 300);

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "_et";
  fname << "/AANT/"<< algName <<"/" << dirName << "/" << hname.str();
  title << "E_{T}";
  parent->registerHistogram(et, fname.str(), hname.str(), title.str(), "E_{T} [GeV]", 100, 0, 500);

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "_phi";
  fname << "/AANT/"<< algName <<"/" << dirName << "/" << hname.str();
  title << "\\phi";
  parent->registerHistogram(phi, fname.str(), hname.str(), title.str(), "\\phi [rad]", 100, -M_PI, M_PI);
}

