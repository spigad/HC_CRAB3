from BUSTopAnalysis.BUSTopAnalysisConf import BUSTopJetAnalysis
Sequencer += BUSTopJetAnalysis()
BUSTopJetAnalysis.OutputLevel = WARNING

BUSTopJetAnalysis.TruthAvailable                   = DoTruth
BUSTopJetAnalysis.TruthMatchDeltaR                 = 0.2	

BUSTopJetAnalysis.PlotJetWeights                   = IsMC
BUSTopJetAnalysis.JetWeightTagger                  = RootJetTagger       
                                                                   # IP3DSV1 - default
                                                                   # IP2D

BUSTopJetAnalysis.InputJetContainer                = BUSTopOverlap.InputJetContainer
BUSTopJetAnalysis.OverlapJetContainer              = BUSTopOverlap.OutputJetContainer
BUSTopJetAnalysis.OverlapEJetContainer             = BUSTopOverlap.OutputEJetContainer

BUSTopJetAnalysis.ElectronContainer                = BUSTopElectronFilter.ElectronOutputContainer
BUSTopJetAnalysis.MuonContainer                    = BUSTopPreselection.InputMuonContainer
BUSTopJetAnalysis.BJetContainer                    = BUSTopBJetTagger.OutputBJetContainer
BUSTopJetAnalysis.LightJetContainer                = BUSTopBJetTagger.OutputLJetContainer

BUSTopJetAnalysis.PreselectedElectronContainer     = BUSTopPreselection.OutputElectronContainer
BUSTopJetAnalysis.PreselectedMuonContainer         = BUSTopPreselection.OutputMuonContainer
BUSTopJetAnalysis.PreselectedBJetContainer         = BUSTopPreselection.OutputBJetContainer
BUSTopJetAnalysis.PreselectedLightJetContainer     = BUSTopPreselection.OutputLightJetContainer

BUSTopJetAnalysis.CSCSelectedElectronContainer     = BUSTopCSCSelection.OutputElectronContainer
BUSTopJetAnalysis.CSCSelectedMuonContainer         = BUSTopCSCSelection.OutputMuonContainer
BUSTopJetAnalysis.CSCSelectedBJetContainer         = BUSTopCSCSelection.OutputBJetContainer
BUSTopJetAnalysis.CSCSelectedLightJetContainer     = BUSTopCSCSelection.OutputLightJetContainer

if DoSelection:
	BUSTopJetAnalysis.B1SelectedBJetContainer  = BUSTopSelection.OutputB1JetContainer
	BUSTopJetAnalysis.LJSelectedLJetContainer  = BUSTopSelection.OutputLJetContainer


