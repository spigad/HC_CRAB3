#include "BUSTopAnalysis/BUSTopInitAlg.h"
#include "BUSTopAnalysis/BUSTopAlg.h"
#include "BUSTopAnalysis/BUSTopSelection.h"
#include "BUSTopAnalysis/BUSTopSpinAnalysis.h"
#include "BUSTopAnalysis/BUSTopCSCSelection.h"
#include "BUSTopAnalysis/BUSTopNeutrinoAnalysis.h"
#include "BUSTopAnalysis/BUSTopWAnalysis.h"
#include "BUSTopAnalysis/BUSTopTAnalysis.h"
#include "BUSTopAnalysis/BUSTopEtMissAnalysis.h"
#include "BUSTopAnalysis/BUSTopJetAnalysis.h"
#include "BUSTopAnalysis/BUSTopElectronAnalysis.h"
#include "BUSTopAnalysis/BUSTopMuonAnalysis.h"
#include "BUSTopAnalysis/BUSTopHistogramDump.h"
#include "BUSTopAnalysis/BUSTopZSelection.h"
#include "BUSTopAnalysis/BUSTopTTreeWriter.h"

#include "GaudiKernel/DeclareFactoryEntries.h"

DECLARE_ALGORITHM_FACTORY( BUSTopInitAlg )
DECLARE_ALGORITHM_FACTORY( BUSTopAlg )
DECLARE_ALGORITHM_FACTORY( BUSTopSelection )
DECLARE_ALGORITHM_FACTORY( BUSTopSpinAnalysis )
DECLARE_ALGORITHM_FACTORY( BUSTopCSCSelection )
DECLARE_ALGORITHM_FACTORY( BUSTopNeutrinoAnalysis )
DECLARE_ALGORITHM_FACTORY( BUSTopWAnalysis )
DECLARE_ALGORITHM_FACTORY( BUSTopTAnalysis )
DECLARE_ALGORITHM_FACTORY( BUSTopEtMissAnalysis )
DECLARE_ALGORITHM_FACTORY( BUSTopJetAnalysis )
DECLARE_ALGORITHM_FACTORY( BUSTopElectronAnalysis )
DECLARE_ALGORITHM_FACTORY( BUSTopMuonAnalysis )
DECLARE_ALGORITHM_FACTORY( BUSTopHistogramDump )
DECLARE_ALGORITHM_FACTORY( BUSTopZSelection )
DECLARE_ALGORITHM_FACTORY( BUSTopTTreeWriter )

DECLARE_FACTORY_ENTRIES( BUSTopAnalysis ) {
  DECLARE_ALGORITHM( BUSTopAlg )
  DECLARE_ALGORITHM( BUSTopInitAlg )
  DECLARE_ALGORITHM( BUSTopSelection )
  DECLARE_ALGORITHM( BUSTopSpinAnalysis )
  DECLARE_ALGORITHM( BUSTopCSCSelection )
  DECLARE_ALGORITHM( BUSTopNeutrinoAnalysis )
  DECLARE_ALGORITHM( BUSTopWAnalysis )
  DECLARE_ALGORITHM( BUSTopTAnalysis )
  DECLARE_ALGORITHM( BUSTopEtMissAnalysis )
  DECLARE_ALGORITHM( BUSTopJetAnalysis )
  DECLARE_ALGORITHM( BUSTopElectronAnalysis )
  DECLARE_ALGORITHM( BUSTopMuonAnalysis )
  DECLARE_ALGORITHM( BUSTopHistogramDump )
  DECLARE_ALGORITHM( BUSTopZSelection )
  DECLARE_ALGORITHM( BUSTopTTreeWriter )
}
