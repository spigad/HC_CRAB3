from BUSTopPreselection.BUSTopPreselectionConf import BUSTopElectronFilter
Sequencer += BUSTopElectronFilter()
BUSTopElectronFilter.OutputLevel = WARNING

BUSTopElectronFilter.ElectronInputContainer          = RootElectronContainer
BUSTopElectronFilter.ElectronOutputContainer         = "FilteredElectrons"
BUSTopElectronFilter.RejectedOutputContainer         = "RejectedFilterElectrons"
BUSTopElectronFilter.FilterLevel                     = "Medium"

if DoTruth:
	BUSTopElectronFilter.TruthAvailable = 1
else:
	BUSTopElectronFilter.TruthAvailable = 0



