#include "GaudiKernel/IToolSvc.h"
#include "GaudiKernel/ITHistSvc.h"

#include "TH1.h"
#include "TH2.h"
#include "TFile.h"
#include "TMVA/Reader.h"

#include "McParticleEvent/TruthParticle.h"
#include "McParticleEvent/TruthParticleContainer.h"
#include "HepMC/GenEvent.h"
#include "HepMC/GenParticle.h"
#include "GeneratorObjects/McEventCollection.h"

#include "CompositeParticleEvent/CompositeParticleContainer.h"
#include "CompositeParticleEvent/CompositeParticle.h"

#include "egammaEvent/ElectronContainer.h"
#include "egammaEvent/Electron.h"
#include "muonEvent/MuonContainer.h"

#include "JetEvent/JetCollection.h"
#include "JetTagEvent/TrackAssociation.h"
#include "Particle/TrackParticleContainer.h"
#include "Particle/TrackParticle.h"

#include "MissingETEvent/MissingET.h"
#include "JetTagEvent/TrackConstituents.h"
#include "ParticleEvent/NeutrinoContainer.h"
#include "ParticleEvent/Neutrino.h"

#include "DataModel/ElementLink.h"
#include "JetTagInfo/TruthInfo.h"

#include "AnalysisTools/IAnalysisTools.h"

#include "BUSTopTools/EventTool.h"
#include "BUSTopTools/EventTagTool.h"
#include "BUSTopTools/INuSolutionTool.h"
#include "BUSTopTools/IBUSTopHistogrammer.h"

#include "BUSTopAnalysis/BUSTopSpinAnalysis.h"

#include <stdint.h>
#include <algorithm>
#include <math.h>
#include <functional>

BUSTopSpinAnalysis::BUSTopSpinAnalysis(const std::string& name, ISvcLocator* pSvcLocator) : 
                     Algorithm(name, pSvcLocator){

  declareProperty("TruthAvailable", m_truthAvailable);
  
  declareProperty("InputElectronContainer", m_electronContainerName);
  declareProperty("InputTopContainer", m_topContainerName);
  declareProperty("InputBJetContainer", m_bJetContainerName);
  declareProperty("InputLightJetContainer", m_lightJetContainerName);
  declareProperty("InputMuonContainer", m_muonContainerName);
  declareProperty("InputNeutrinoContainer", m_neutrinoContainerName);
  declareProperty("InputMETContainer", m_metContainerName);

  declareProperty("FilterTags", m_filterTags);

}

BUSTopSpinAnalysis::~BUSTopSpinAnalysis(){
}

StatusCode BUSTopSpinAnalysis::initialize() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << "Initializing BUSTopSpinAnalysis" << endreq;

  if (service("StoreGateSvc", m_storeGate).isFailure()) {
     mLog << MSG::ERROR << "Unable to retrieve pointer to StoreGateSvc" << endreq;
     return StatusCode::FAILURE;
  }

  service("THistSvc", m_histSvc);

  IToolSvc * toolSvc;
  service("ToolSvc", toolSvc);

  IAlgTool *tmp_eventTool = 0;
  toolSvc->retrieveTool("EventTool", tmp_eventTool);
  m_eventTool = dynamic_cast<IEventTool *>(tmp_eventTool);

  IAlgTool *tmp_tagTool = 0;
  toolSvc->retrieveTool("EventTagTool", tmp_tagTool);
  m_tagTool = dynamic_cast<IEventTagTool *>(tmp_tagTool);

  IAlgTool *tmp_nuSolTool;
  toolSvc->retrieveTool("NuSolutionTool", tmp_nuSolTool); 
  m_nuSolTool = dynamic_cast<INuSolutionTool *>(tmp_nuSolTool);

  IAlgTool *tmp_histogramTool;
  toolSvc->retrieveTool("BUSTopHistogrammer", tmp_histogramTool);
  m_histogrammer = dynamic_cast<IBUSTopHistogrammer *>(tmp_histogramTool);

  registerHistograms();
  registerTTrees();

  return StatusCode::SUCCESS;
}

void BUSTopSpinAnalysis::registerHistograms(){
  std::stringstream fname, hname, title;
  std::string hN = "";

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "h_truth_lep_angle";
  fname << "/AANT/"<< "Truth" <<"/" << "Spin" << "/" << hname.str();
  title << "\\chi^{t}_{l}";
  m_histogrammer->registerHistogram(h_truth_lep_angle, fname.str(), hname.str(), title.str(), "cos \\chi^{t}_{l}", 100, -1.0, 1.0);

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "h_truth_lep_angle_preselected";
  fname << "/AANT/"<< "Truth" <<"/" << "Spin" << "/" << hname.str();
  title << "\\chi^{t}_{l}";
  m_histogrammer->registerHistogram(h_truth_lep_angle_preselected, fname.str(), hname.str(), title.str(), "cos \\chi^{t}_{l}", 100, -1.0, 1.0);

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "h_truth_lep_angle_selected";
  fname << "/AANT/"<< "Truth" <<"/" << "Spin" << "/" << hname.str();
  title << "\\chi^{t}_{l}";
  m_histogrammer->registerHistogram(h_truth_lep_angle_selected, fname.str(), hname.str(), title.str(), "cos \\chi^{t}_{l}", 100, -1.0, 1.0);

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "h_truth_lep_trans_angle";
  fname << "/AANT/"<< "Truth" <<"/" << "Spin" << "/" << hname.str();
  title << "Transverse \\chi^{t}_{l}";
  m_histogrammer->registerHistogram(h_truth_lep_trans_angle, fname.str(), hname.str(), title.str(), "cos \\chi^{t}_{l}", 100, -1.0, 1.0);

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "h_lep_angle";
  fname << "/AANT/"<< "Selection" <<"/" << "Spin" << "/" << hname.str();
  title << "Recon \\chi^{t}_{l}";
  m_histogrammer->registerHistogram(h_lep_angle, fname.str(), hname.str(), title.str(), "cos \\chi^{t}_{l}", 100, -1.0, 1.0);

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "h_lep_angle_spec_pos";
  fname << "/AANT/"<< "Selection" <<"/" << "Spin" << "/" << hname.str();
  title << "Recon \\chi^{t}_{l}";
  m_histogrammer->registerHistogram(h_lep_angle_spec_pos, fname.str(), hname.str(), title.str(), "cos \\chi^{t}_{l}", 100, -1.0, 1.0);

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "h_lep_angle_spec_neg";
  fname << "/AANT/"<< "Selection" <<"/" << "Spin" << "/" << hname.str();
  title << "Recon \\chi^{t}_{l}";
  m_histogrammer->registerHistogram(h_lep_angle_spec_neg, fname.str(), hname.str(), title.str(), "cos \\chi^{t}_{l}", 100, -1.0, 1.0);

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "h_lep_angle_beam_pos";
  fname << "/AANT/"<< "Selection" <<"/" << "Spin" << "/" << hname.str();
  title << "Recon \\chi^{t}_{l}";
  m_histogrammer->registerHistogram(h_lep_angle_beam_pos, fname.str(), hname.str(), title.str(), "cos \\chi^{t}_{l}", 100, -1.0, 1.0);

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "h_lep_angle_beam_neg";
  fname << "/AANT/"<< "Selection" <<"/" << "Spin" << "/" << hname.str();
  title << "Recon \\chi^{t}_{l}";
  m_histogrammer->registerHistogram(h_lep_angle_beam_neg, fname.str(), hname.str(), title.str(), "cos \\chi^{t}_{l}", 100, -1.0, 1.0);

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "h_b_angle";
  fname << "/AANT/"<< "Selection" <<"/" << "Spin" << "/" << hname.str();
  title << "Recon \\chi^{t}_{b}";
  m_histogrammer->registerHistogram(h_b_angle, fname.str(), hname.str(), title.str(), "cos \\chi^{t}_{b}", 100, -1.0, 1.0);

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "h_lep_b_angle";
  fname << "/AANT/"<< "Selection" <<"/" << "Spin" << "/" << hname.str();
  title << "Recon \\chi^{t}_{b}";
  m_histogrammer->registerHistogram(h_lep_b_angle, fname.str(), hname.str(), title.str(), "cos \\chi^{t}_{b}", 100, -1.0, 1.0);

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "h_lep_angle_2d";
  fname << "/AANT/"<< "Selection" <<"/" << "Spin" << "/" << hname.str();
  title << "Recon \\chi^{t}_{l}";
  m_histogrammer->registerHistogram(h_lep_angle_2d, fname.str(), hname.str(), title.str(), "cos \\chi^{l}_{j}", 100, -1.0, 1.0, "-cos \\chi^{l}_{b}", 100, -1.0, 1.0);
}

void BUSTopSpinAnalysis::registerTTrees(){
}

StatusCode BUSTopSpinAnalysis::finalize(){
  MsgStream mLog( messageService(), name() );
  
  return StatusCode::SUCCESS;
}

StatusCode BUSTopSpinAnalysis::execute() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << "execute()" << endreq;

  getEventWeight();
  getStoregateContainers();
  createTemporaryContainers();

  spinAnalysis();

  if(m_truthAvailable == true){
    getTruthContainers();
    truthAnalysis(h_truth_lep_angle);
    
    if(m_tagTool->tagged(IEventTagTool::PRESELECTION)){
      truthAnalysis(h_truth_lep_angle_preselected);
    }

    BUSTopTags tags;
    tags.push_back(IEventTagTool::B1SELECTION);
    tags.push_back(IEventTagTool::LJSELECTION);
    tags.push_back(IEventTagTool::NUSELECTION);

    if(m_tagTool->allTagged(tags)){
      truthAnalysis(h_truth_lep_angle_selected);
    }
  }

  registerSelected();

  destroyTemporaryContainers();
 
  return StatusCode::SUCCESS;
}

void BUSTopSpinAnalysis::getEventWeight(){
  if(m_tagTool->tagged(IEventTagTool::IS_ATLFAST) == false && m_tagTool->tagged(IEventTagTool::IS_MC) == true){
    m_eventWeight = m_eventTool->getEventWeight();
  }else{
    m_eventWeight = 1.0;
  }
}

void BUSTopSpinAnalysis::getStoregateContainers(){
  MsgStream mLog( messageService(), name() );

  m_storeGate->retrieve(topTES, m_topContainerName);
  if(topTES == 0){
    mLog << MSG::WARNING << "Problem getting Top container" << endreq;
  }

  m_storeGate->retrieve(ljTES, m_lightJetContainerName);
  if(ljTES == 0){
    mLog << MSG::WARNING << "Problem getting light jet container" << endreq;
  }

  m_storeGate->retrieve(bjTES, m_bJetContainerName);
  if(bjTES == 0){
    mLog << MSG::WARNING << "Problem getting b jet container" << endreq;
  }

  m_storeGate->retrieve(elecTES, m_electronContainerName);
  if(elecTES == 0){
    mLog << MSG::WARNING << "Problem getting electron container" << endreq;
  }

  m_storeGate->retrieve(muonTES, m_muonContainerName);
  if(muonTES == 0){
    mLog << MSG::WARNING << "Problem getting muon container" << endreq;
  }else{
    mLog << MSG::DEBUG << "Muon Container Size = " << muonTES->size() << endreq;
  }

  m_storeGate->retrieve(metTES, m_metContainerName);
  if(metTES == 0){
    mLog << MSG::WARNING << "Problem getting met container" << endreq;
  }

  m_storeGate->retrieve(nuTES, m_neutrinoContainerName);
  if(nuTES == 0){
    mLog << MSG::WARNING << "Problem getting nu container" << endreq;
  }

}

void BUSTopSpinAnalysis::createTemporaryContainers(){
}

void BUSTopSpinAnalysis::registerSelected(){
  MsgStream mLog( messageService(), name() );
  
  mLog << MSG::DEBUG << "registerSelected()" << endreq;
}

void BUSTopSpinAnalysis::destroyTemporaryContainers(){
  MsgStream mLog( messageService(), name() );
    
  mLog << MSG::DEBUG << "destroyTemporaryContainers(...)" << endreq;
}  

void BUSTopSpinAnalysis::getTruthContainers(){
  MsgStream mLog( messageService(), name() );

  m_storeGate->retrieve(c_truthLJ, "BUSTopTruth_lj");
  if(c_truthLJ == 0){
    mLog << MSG::WARNING << "Problem getting truth jet container" << endreq;
  }

  m_storeGate->retrieve(c_truthTop, "BUSTopTruth_t");
  if(c_truthTop == 0){
    mLog << MSG::WARNING << "Problem getting truth top container" << endreq;
  }

  m_storeGate->retrieve(c_truthElec, "BUSTopTruth_e");
  if(c_truthElec == 0){  
    mLog << MSG::WARNING << "Problem getting truth electron container" << endreq;
  }
  
  m_storeGate->retrieve(c_truthMuon, "BUSTopTruth_mu");
  if(c_truthMuon == 0){
    mLog << MSG::WARNING << "Problem getting truth mu container" << endreq;
  }
}

void BUSTopSpinAnalysis::spinAnalysis(){
  MsgStream mLog( messageService(), name() );

  //Assume that first particle in containers is correct particle

  mLog << MSG::DEBUG << "ljTES size = " << ljTES->size() << endreq;
  mLog << MSG::DEBUG << "topTES size = " << topTES->size() << endreq;

  if(m_tagTool->allTagged(m_filterTags) && topTES->size() > 0 && ljTES->size() > 0){
    mLog << MSG::DEBUG << "Passed Tag count" << endreq;

    const HepLorentzVector topVector = topTES->at(0)->hlv();
    const IParticle* lepVector = 0;

    int elec_tag = m_filterTags.at(0) + 1;
    int muon_tag = m_filterTags.at(0) + 2;

    double charge = 0.0;

    if(m_tagTool->tagged(elec_tag) && elecTES->size() > 0){
      mLog << MSG::DEBUG << "SpinAnalysis on Electron" << endreq;
      lepVector = elecTES->at(0);
      charge = elecTES->at(0)->charge();
    }else if(m_tagTool->tagged(muon_tag) && muonTES->size() > 0){
      mLog << MSG::DEBUG << "SpinAnalysis on Muon" << endreq;
      lepVector = muonTES->at(0);
      charge = muonTES->at(0)->charge();
    }

    const HepLorentzVector ljVector = ljTES->at(0)->hlv();

    if(lepVector != 0){
      mLog << MSG::DEBUG << "Calculating angle" << endreq;
      double chiLJ = getSpectatorAngle(topVector, lepVector->hlv(), ljVector);
      mLog << MSG::DEBUG << "Calculating beam angle" << endreq;
      double chiBeam = getBeamAngle(topVector, lepVector->hlv(), ljVector);

      mLog << MSG::DEBUG << "Filling h_lep_angle" << endreq;
      h_lep_angle->Fill(cos(chiLJ), m_eventWeight);

      mLog << MSG::DEBUG << "Filling h_b_angle" << endreq;
      double chiBJ = getSpectatorAngle(topVector, bjTES->at(0)->hlv(), ljVector);
      h_b_angle->Fill(cos(chiBJ), m_eventWeight);

      mLog << MSG::DEBUG << "Filling h_lep_b_angle" << endreq;
      double chiLB = getSpectatorAngle(topVector, bjTES->at(0)->hlv(), lepVector->hlv());
      h_lep_b_angle->Fill(cos(chiLB), m_eventWeight);
      h_lep_angle_2d->Fill(cos(chiLJ), -1.0*cos(chiLB), m_eventWeight);

      mLog << MSG::DEBUG << "Doing charge specific" << endreq;
      if(charge > 0){
        mLog << MSG::DEBUG << "Positive" << endreq;
        h_lep_angle_spec_pos->Fill(cos(chiLJ), m_eventWeight);
        mLog << MSG::DEBUG << "Positive second" << endreq;
        h_lep_angle_beam_pos->Fill(cos(chiBeam), m_eventWeight);
      }else{
        mLog << MSG::DEBUG << "Negative" << endreq;
        h_lep_angle_spec_neg->Fill(cos(chiLJ), m_eventWeight);
        mLog << MSG::DEBUG << "Negative second" << endreq;
        h_lep_angle_beam_neg->Fill(cos(chiBeam), m_eventWeight);
      }
    }
  }

  mLog << MSG::DEBUG << "All done :-)" << endreq;
}

void BUSTopSpinAnalysis::truthAnalysis(TH1F* h){
  MsgStream mLog( messageService(), name() );
      
  //get truth top
  //get truth electron
  //boost lepton into top rest frame
  //calculate angle
    
  TruthParticleContainer::const_iterator topIter = c_truthTop->begin();
  TruthParticleContainer::const_iterator topIterEnd = c_truthTop->end();
      
  //iterate over all tops
  while(topIter < topIterEnd){
  
    //Locate truth lepton
    TruthParticleContainer::const_iterator lepIter;
    TruthParticleContainer::const_iterator lepIterEnd;
    
    if(m_tagTool->tagged(IEventTagTool::ELECTRON_TRUTH)){
      lepIter = c_truthElec->begin();
      lepIterEnd = c_truthElec->end();
    }else if(m_tagTool->tagged(IEventTagTool::MUON_TRUTH)){
      lepIter = c_truthMuon->begin();
      lepIterEnd = c_truthMuon->end();
    }

    //If found lepton, iterate.
    while(lepIter < lepIterEnd){
      if(c_truthLJ->size() > 0){   

        double chi = getSpectatorAngle((*topIter)->hlv(), (*lepIter)->hlv(), c_truthLJ->at(0)->hlv());

        h->Fill(cos(chi), m_eventWeight);
      }
      
      lepIter++;
    }
    
    topIter++;
  }
}

void BUSTopSpinAnalysis::transverseTruthAnalysis(){
  MsgStream mLog( messageService(), name() );
      
  //get truth top
  //get truth electron
  //boost lepton into top rest frame
  //calculate angle
    
  TruthParticleContainer::const_iterator topIter = c_truthTop->begin();
  TruthParticleContainer::const_iterator topIterEnd = c_truthTop->end();
      
  //iterate over all tops
  while(topIter < topIterEnd){
  
    //Locate truth lepton
    TruthParticleContainer::const_iterator lepIter;
    TruthParticleContainer::const_iterator lepIterEnd;
    
    if(m_tagTool->tagged(IEventTagTool::ELECTRON_TRUTH)){
      lepIter = c_truthElec->begin();
      lepIterEnd = c_truthElec->end();
    }else if(m_tagTool->tagged(IEventTagTool::MUON_TRUTH)){
      lepIter = c_truthMuon->begin();
      lepIterEnd = c_truthMuon->end();
    }

    //If found lepton, iterate.
    while(lepIter < lepIterEnd){
      if(c_truthLJ->size() > 0){   

        HepLorentzVector* transverseTop = getTransverseVector((*topIter)->hlv());
        HepLorentzVector* transverseLep = getTransverseVector((*lepIter)->hlv());
        HepLorentzVector* transverseLJ = getTransverseVector(c_truthLJ->at(0)->hlv());

        double chi = getSpectatorAngle(*transverseTop, *transverseLep, *transverseLJ);

        h_truth_lep_trans_angle->Fill(cos(chi), m_eventWeight);

      }
      
      lepIter++;
    }
    
    topIter++;
  }
}

HepLorentzVector* BUSTopSpinAnalysis::getTransverseVector(const HepLorentzVector& hlv){
  HepLorentzVector* trans = new HepLorentzVector;

  trans->setPx(hlv.px());
  trans->setPy(hlv.py());
  trans->setPz(0);
  trans->setE(hlv.et());
  
  return trans;
}

double BUSTopSpinAnalysis::getSpectatorAngle(const HepLorentzVector& top, const HepLorentzVector& lep, const HepLorentzVector& jet){
  HepLorentzVector topRest(top);
  topRest.boost(top.findBoostToCM());

  HepLorentzVector lepRest(lep);
  lepRest.boost(top.findBoostToCM());

  HepLorentzVector ljRest(jet);
  ljRest.boost(top.findBoostToCM());

  return lepRest.angle(ljRest);
}

double BUSTopSpinAnalysis::getBeamAngle(const HepLorentzVector& top, const HepLorentzVector& lep, const HepLorentzVector& jet){
  HepLorentzVector topRest(top);
  topRest.boost(top.findBoostToCM());

  HepLorentzVector lepRest(lep);
  lepRest.boost(top.findBoostToCM());

  HepLorentzVector ljRest(jet);
  ljRest.boost(top.findBoostToCM());

  HepLorentzVector beam;
  beam.setPz(ljRest.getZ());
  beam.setE(ljRest.getT());

  return lepRest.angle(beam);
}

