#include "GaudiKernel/IToolSvc.h"
#include "GaudiKernel/ITHistSvc.h"

#include "TH1.h"
#include "TH2.h"

#include "EventKernel/PdtPdg.h"
#include "McParticleEvent/TruthParticle.h"
#include "McParticleEvent/TruthParticleContainer.h"

#include "DataModel/ElementLink.h"
#include "JetTagInfo/TruthInfo.h"

#include "AnalysisTools/IAnalysisTools.h"

#include "BUSTopTools/DecayVector.h"
#include "BUSTopTools/EventTool.h"
#include "BUSTopTools/EventTagTool.h"

#include "BUSTopPreselection/BUSTopTruthFilter.h"

#include <stdint.h>
#include <algorithm>
#include <math.h>
#include <functional>

BUSTopTruthFilter::BUSTopTruthFilter(const std::string& name, ISvcLocator* pSvcLocator) : 
                     Algorithm(name, pSvcLocator){

  declareProperty("MCTruthContainer", m_mcContainerName);
  declareProperty("DatasetID", m_datasetID);
  declareProperty("SelectChildren1", m_selectChildren1);
  declareProperty("SelectChildren2", m_selectChildren2);
}

BUSTopTruthFilter::~BUSTopTruthFilter(){
}

StatusCode BUSTopTruthFilter::initialize() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << "Initializing BUSTopTruthFilter" << endreq;

  m_eventCount = 0;
  m_taggedCount = 0;

  if (service("StoreGateSvc", m_storeGate).isFailure()) {
     mLog << MSG::ERROR << "Unable to retrieve pointer to StoreGateSvc" << endreq;
     return StatusCode::FAILURE;
  }

  service("THistSvc", m_histSvc);

  IToolSvc * toolSvc;
  service("ToolSvc", toolSvc);

  IAlgTool *tmp_decayTool;
  toolSvc->retrieveTool("DecayVector", tmp_decayTool);
  m_truthVector = dynamic_cast<IDecayVector *>(tmp_decayTool);

  IAlgTool *tmp_eventTool;
  toolSvc->retrieveTool("EventTool", tmp_eventTool);
  m_eventTool = dynamic_cast<IEventTool *>(tmp_eventTool);

  IAlgTool *tmp_eventTagTool;
  toolSvc->retrieveTool("EventTagTool", tmp_eventTagTool);
  m_tagTool = dynamic_cast<IEventTagTool *>(tmp_eventTagTool);

  registerHistograms();

  return StatusCode::SUCCESS;
}

void BUSTopTruthFilter::registerHistograms(){
  std::stringstream fName, hName;
  std::string title;

  fName.str("");
  hName.str("");
  hName << "tf_eventCount";
  fName << "/AANT/BUSTopTruthFilter/Event/" << hName.str();
  title = "Event Count";
  h_eventCount = new TH1F(hName.str().c_str(), title.c_str(), 1, 0, 1);
  m_histSvc->regHist(fName.str().c_str(), h_eventCount);

  fName.str("");
  hName.str("");
  hName << "tf_tagged";
  fName << "/AANT/BUSTopTruthFilter/Event/" << hName.str();
  title = "Event Tagged";
  h_eventTagged = new TH1F(hName.str().c_str(), title.c_str(), 1, 0, 1);
  m_histSvc->regHist(fName.str().c_str(), h_eventTagged);
}


StatusCode BUSTopTruthFilter::finalize() {
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "eventCount = " << m_eventCount << endreq;
  mLog << MSG::DEBUG << "tagged = " << m_taggedCount << endreq;

  h_eventCount->Fill(1.0, m_eventCount);
  h_eventTagged->Fill(1.0, m_taggedCount);

  return StatusCode::SUCCESS;
}

StatusCode BUSTopTruthFilter::execute() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << "execute()" << endreq;

  getEventWeight();
  getStoregateContainers();

  switch(m_datasetID){
    case 5200:
      do5200Filter();
      break;
    case 5500:
      do5500Filter();
      break;
    case 5501:
      do5501Filter();
      break;
    case 5502:
      do5502Filter();
      break;
    default:
      setFilterPassed(true);
      break;
  }

  m_truthVector->clear();

  m_eventCount += m_eventWeight;

  StatusCode sc = StatusCode::SUCCESS;

  return sc;
}

void BUSTopTruthFilter::getStoregateContainers(){
  m_storeGate->retrieve(mcTES, m_mcContainerName);
}

bool BUSTopTruthFilter::doFilter(std::vector<int>& v, PDG::pidType pid, bool sign){
  MsgStream mLog( messageService(), name() );

  m_truthVector->fill(mcTES, pid, false, sign, 3);

  std::vector<int>::const_iterator iter = v.begin(); 
  std::vector<int>::const_iterator iterEnd = v.end();
  
  bool result = false;
  
  while(iter < iterEnd && result == false){
    PDG::pidType pdgId = (PDG::pidType)(*iter);

    TruthParticleContainer* c = m_truthVector->filter(pdgId, false);
    if(c->size() > 0){
      TruthParticleContainer::const_iterator mcIter = c->begin();
      TruthParticleContainer::const_iterator mcIterEnd = c->end();

      while(mcIter < mcIterEnd){
        const TruthParticle* prev = getPreviousParticle(*mcIter);
        if(abs(prev->mother(0)->pdgId()) == 24){
          result = true;
        }
        mcIter++;
      }
    }
    delete c;
    iter++;
  }

  return result;  
}

const TruthParticle* BUSTopTruthFilter::getPreviousParticle(const TruthParticle* c){
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "getPreviousParticle()" << endreq;
  if(c->nParents() > 0){
    if(c->mother(0)->pdgId() == c->pdgId()){
      return getPreviousParticle(c->mother(0));
    }else{
      return c;
    }
  }else{
    return c;
  }
}

void BUSTopTruthFilter::do5200Filter(){
  MsgStream mLog( messageService(), name() );

  bool resultA = doFilter(m_selectChildren1, PDG::t, true);
  bool resultB = false;
  if(resultA == true){
    resultB = doFilter(m_selectChildren2, PDG::anti_t, true);
  }else{
    resultA = doFilter(m_selectChildren1, PDG::anti_t, true);
    if(resultA == true){
      resultB = doFilter(m_selectChildren2, PDG::t, true);
    }
  }

  if(resultA == true && resultB == true){
    m_taggedCount += m_eventWeight;
    setFilterPassed(true);
  }else{
    setFilterPassed(false);
  }
}

void BUSTopTruthFilter::do5500Filter(){
  MsgStream mLog( messageService(), name() );

  m_truthVector->fill(mcTES, PDG::t, false);

  std::vector<int>::const_iterator iter = m_selectChildren1.begin();
  std::vector<int>::const_iterator iterEnd = m_selectChildren1.end();

  bool result = false;

  while(iter < iterEnd && result == false){
    PDG::pidType pdgId = (PDG::pidType)(*iter);
    TruthParticleContainer* c = m_truthVector->filter(pdgId, false);
    if(c->size() > 0){
      result = true;
    }
    delete c;
    iter++;
  }

  if(result == true){
    m_taggedCount += m_eventWeight;
    setFilterPassed(true);
  }else{
    setFilterPassed(false);
  }
}

void BUSTopTruthFilter::do5501Filter(){
  MsgStream mLog( messageService(), name() );

  m_truthVector->fill(mcTES, PDG::t, false);

  std::vector<int>::const_iterator iter = m_selectChildren1.begin();
  std::vector<int>::const_iterator iterEnd = m_selectChildren1.end();

  bool result = false;

  while(iter < iterEnd && result == false){
    PDG::pidType pdgId = (PDG::pidType)(*iter);
    TruthParticleContainer* c = m_truthVector->filter(pdgId, false);
    if(c->size() > 0){
      result = true;
    }

    delete c;
    iter++;
  }

  if(result == true){
    m_taggedCount += m_eventWeight;
    setFilterPassed(true);
  }else{
    setFilterPassed(false);
  }
}

void BUSTopTruthFilter::do5502Filter(){
  MsgStream mLog( messageService(), name() );

  m_truthVector->fill(mcTES, PDG::t, false);

  std::vector<int>::const_iterator iter = m_selectChildren1.begin();
  std::vector<int>::const_iterator iterEnd = m_selectChildren1.end();

  bool result = false;

  while(iter < iterEnd && result == false){
    PDG::pidType pdgId = (PDG::pidType)(*iter);
    TruthParticleContainer* c = m_truthVector->filter(pdgId, false);
    if(c->size() > 0){
      result = true;
    }

    delete c;
    iter++;
  }

  if(result == true){
    m_taggedCount += m_eventWeight;
    setFilterPassed(true);
  }else{
    setFilterPassed(false);
  }
}

void BUSTopTruthFilter::getEventWeight(){
  if(m_tagTool->tagged(IEventTagTool::IS_ATLFAST) == false && m_tagTool->tagged(IEventTagTool::IS_MC) == true){
    m_eventWeight = m_eventTool->getEventWeight();
  }else{
    m_eventWeight = 1.0;
  }
}

