#ifndef ELECTRON_HISTOGRAMS_H
#define ELECTRON_HISTOGRAMS_H

#include "GaudiKernel/AlgTool.h"
#include "GaudiKernel/MsgStream.h"
#include "GaudiKernel/AlgFactory.h"
#include "StoreGate/StoreGateSvc.h"
#include "StoreGate/DataHandle.h"
#include "AIDA/IHistogram1D.h"
#include "AIDA/IHistogram2D.h"
#include "GaudiKernel/ITHistSvc.h"
#include "EventKernel/PdtPdg.h"

#include "BUSTopTools/KinematicHistograms.h"

class IBUSTopHistogrammer;
class TH1F;
class TH2F;
class ElectronContainer;

namespace Analysis{
  class Electron;
}

class ElectronHistograms: public KinematicHistograms{
   public:
     ElectronHistograms(IBUSTopHistogrammer* parent, std::string algName, std::string dirName, std::string hname);
     virtual ~ElectronHistograms(){};

     TH1F** author;
     TH1F** classification;
     TH1F** etcone20;

     void plotContainer(const ElectronContainer* c, double w, int maxCount = -1, bool plotIsoCone = true);
     void plot(const Analysis::Electron* particle, double w, bool plotIsoCone = true);
};

#endif

