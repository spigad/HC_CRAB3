#include "GaudiKernel/IToolSvc.h"
#include "GaudiKernel/ITHistSvc.h"

#include "TH1.h"
#include "TH2.h"

#include "McParticleEvent/TruthParticle.h"
#include "McParticleEvent/TruthParticleContainer.h"
#include "egammaEvent/ElectronContainer.h"
#include "muonEvent/Muon.h"
#include "MissingETEvent/MissingET.h"
#include "CompositeParticleEvent/CompositeParticleContainer.h"
#include "CompositeParticleEvent/CompositeParticle.h"
#include "ParticleEvent/NeutrinoContainer.h"
#include "ParticleEvent/Neutrino.h"

#include "SpecialUtils/NeutrinoUtils.h"

#include "DataModel/ElementLink.h"
#include "JetTagInfo/TruthInfo.h"

#include "AnalysisTools/IAnalysisTools.h"

#include "BUSTopTools/IBUSTopHistogrammer.h"
#include "BUSTopTools/KinematicHistograms.h"
#include "BUSTopTools/ResolutionHistograms.h"
#include "BUSTopTools/METResolutionHistograms.h"
#include "BUSTopTools/EventTool.h"
#include "BUSTopTools/EventTagTool.h"
#include "BUSTopTools/TruthMatch.h"

#include "BUSTopAnalysis/BUSTopTAnalysis.h"

#include <stdint.h>
#include <algorithm>
#include <math.h>
#include <functional>

BUSTopTAnalysis::BUSTopTAnalysis(const std::string& name, ISvcLocator* pSvcLocator) : 
                                             Algorithm(name, pSvcLocator){

  declareProperty("TruthAvailable", m_truthAvailable);

  declareProperty("Top", m_topName);
  declareProperty("PreselectedTop", m_preselectedTopName);
  declareProperty("CSCSelectedTop", m_cscSelectedTopName);

  declareProperty("SelectedTop", m_selectedTopName);
}

BUSTopTAnalysis::~BUSTopTAnalysis(){
}

StatusCode BUSTopTAnalysis::initialize() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << "Initializing BUSTopTAnalysis" << endreq;

  if (service("StoreGateSvc", m_storeGate).isFailure()) {
     mLog << MSG::ERROR << "Unable to retrieve pointer to StoreGateSvc" << endreq;
     return StatusCode::FAILURE;
  }

  service("THistSvc", m_thistSvc);

  IToolSvc * toolSvc;
  service("ToolSvc", toolSvc);

  IAlgTool *tmp_eventTool;
  toolSvc->retrieveTool("EventTool", tmp_eventTool);
  m_eventTool = dynamic_cast<IEventTool *>(tmp_eventTool);

  IAlgTool *tmp_truthMatch;
  toolSvc->retrieveTool("TruthMatch", tmp_truthMatch);
  m_truthMatchTool = dynamic_cast<ITruthMatch *>(tmp_truthMatch);

  IAlgTool *tmp_tagTool;
  toolSvc->retrieveTool("EventTagTool", tmp_tagTool);
  m_tagTool = dynamic_cast<IEventTagTool *>(tmp_tagTool);

  IAlgTool *tmp_histogramTool;
  toolSvc->retrieveTool("BUSTopHistogrammer", tmp_histogramTool);
  m_histogrammer = dynamic_cast<IBUSTopHistogrammer *>(tmp_histogramTool);

  registerHistograms();

  return StatusCode::SUCCESS;
}

void BUSTopTAnalysis::registerHistograms(){
  std::stringstream fName, hName;
  std::string title;

  fName.str("");
  hName.str("");
  hName << "t_topMass";
  fName << "/AANT/TopAnalysis/" << hName.str();
  title = "M_{t}";
  h_topMass = new TH1F(hName.str().c_str(), title.c_str(), 100, 0, 300);
  m_thistSvc->regHist(fName.str().c_str(), h_topMass);
      
  h_top = new KinematicHistograms(m_histogrammer, "TopAnalysis", "", "t_top");

  fName.str("");
  hName.str("");
  hName << "t_preselectedTopMass";
  fName << "/AANT/TopAnalysis/" << hName.str();
  title = "M_{t}";
  h_preselectedTopMass = new TH1F(hName.str().c_str(), title.c_str(), 100, 0, 300);
  m_thistSvc->regHist(fName.str().c_str(), h_preselectedTopMass);
      
  h_preselectedTop = new KinematicHistograms(m_histogrammer, "TopAnalysis", "", "t_preselectedTop");

  fName.str("");
  hName.str("");
  hName << "t_cscSelectedTopMass";
  fName << "/AANT/TopAnalysis/" << hName.str();
  title = "M_{t}";
  h_cscSelectedTopMass = new TH1F(hName.str().c_str(), title.c_str(), 100, 0, 300);
  m_thistSvc->regHist(fName.str().c_str(), h_cscSelectedTopMass);
      
  h_cscSelectedTop = new KinematicHistograms(m_histogrammer, "TopAnalysis", "", "t_cscSelectedTop");

  fName.str("");
  hName.str("");
  hName << "t_selectedTopMass";
  fName << "/AANT/TopAnalysis/" << hName.str();
  title = "M_{t}";
  h_selectedTopMass = new TH1F(hName.str().c_str(), title.c_str(), 100, 0, 300);
  m_thistSvc->regHist(fName.str().c_str(), h_selectedTopMass);
      
  h_selectedTop = new KinematicHistograms(m_histogrammer, "TopAnalysis", "", "t_selectedTop");

  if(m_truthAvailable){
    h_selectedRes = new ResolutionHistograms(m_histogrammer, "TopAnalysis", "Resolution", "t_selectedRes");
  }

}


StatusCode BUSTopTAnalysis::finalize() {
  MsgStream mLog( messageService(), name() );
  
  return StatusCode::SUCCESS;
}

StatusCode BUSTopTAnalysis::execute() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << "execute()" << endreq;

  getEventWeight();
  getStoregateContainers();
  createTemporaryContainers();

  plotTop(c_top, h_top, h_topMass);
  plotTop(c_preselectedTop, h_preselectedTop, h_preselectedTopMass);
  plotTop(c_cscSelectedTop, h_cscSelectedTop, h_cscSelectedTopMass);

  if(m_tagTool->tagged(IEventTagTool::B1SELECTION)){
    plotTop(c_selectedTop, h_selectedTop, h_selectedTopMass);
  }

  if(m_truthAvailable){
    getTruthContainers();

    if(m_tagTool->tagged(IEventTagTool::B1SELECTION)){
      plotTopRes(c_selectedTop, h_selectedRes);
    }
  }

  destroyTemporaryContainers();
  
  StatusCode sc = StatusCode::SUCCESS;

  return sc;
}

void BUSTopTAnalysis::getTruthContainers(){
  MsgStream mLog( messageService(), name() );
 
  m_storeGate->retrieve(c_topTruth, "BUSTopTruth_t");
  if(c_topTruth == 0){
    mLog << MSG::ERROR << "Problem getting Top Container" << endreq;
  }  
}

void BUSTopTAnalysis::plotTopRes(const CompositeParticleContainer* tc, ResolutionHistograms* th){
  if(tc->size() > 0){
    TruthParticleContainer::const_iterator mcIter = c_topTruth->begin();
    TruthParticleContainer::const_iterator mcIterEnd = c_topTruth->end();

    while(mcIter < mcIterEnd){
      unsigned int index = 0;
      m_truthMatchTool->matchR(*mcIter, tc, index);
      th->plot(*mcIter, tc->at(index), m_eventWeight);
      mcIter++;
    }
  }
}

void BUSTopTAnalysis::plotTop(const CompositeParticleContainer* tc, KinematicHistograms* th, TH1F* tMass){
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "plotTop()" << endreq;

  if(tc->size() > 0){

    CompositeParticleContainer::const_iterator topIter = tc->begin();
    CompositeParticleContainer::const_iterator topIterEnd = tc->end();
  
    while(topIter < topIterEnd){
      tMass->Fill((*topIter)->m()/GeV, m_eventWeight);
      th->plot(*topIter, m_eventWeight);
      topIter++;
    }
  }

  th->n[0]->Fill(tc->size(), m_eventWeight);
} 

void BUSTopTAnalysis::getStoregateContainers(){
  MsgStream mLog( messageService(), name() );

  m_storeGate->retrieve(c_top, m_topName);
  if(c_top == 0){
    mLog << MSG::ERROR << "Problem getting Top Container" << endreq;
  }

  m_storeGate->retrieve(c_preselectedTop, m_preselectedTopName);
  if(c_preselectedTop == 0){
    mLog << MSG::ERROR << "Problem getting Preselected Top Container" << endreq;
  }

  m_storeGate->retrieve(c_cscSelectedTop, m_cscSelectedTopName);
  if(c_cscSelectedTop == 0){
    mLog << MSG::ERROR << "Problem getting CSCSelected Top Container" << endreq;
  }

  if(m_tagTool->tagged(IEventTagTool::B1SELECTION)){
    m_storeGate->retrieve(c_selectedTop, m_selectedTopName);
    if(c_selectedTop == 0){
      mLog << MSG::ERROR << "Problem getting Selected Top Container" << endreq;
    }
  }
}

void BUSTopTAnalysis::createTemporaryContainers(){
  if(m_truthAvailable == true){
  }
}

void BUSTopTAnalysis::destroyTemporaryContainers(){
  if(m_truthAvailable == true){
  }
}

void BUSTopTAnalysis::getEventWeight(){
  if(m_tagTool->tagged(IEventTagTool::IS_ATLFAST) == false && m_tagTool->tagged(IEventTagTool::IS_MC) == true){
    m_eventWeight = m_eventTool->getEventWeight();
  }else{
    m_eventWeight = 1.0;
  }
}
