from BUSTopAnalysis.BUSTopAnalysisConf import BUSTopHistogramDump
Sequencer += BUSTopHistogramDump()
BUSTopHistogramDump.OutputLevel = DEBUG

BUSTopHistogramDump.InputMuonContainer                 = RootMuonContainer
BUSTopHistogramDump.InputElectronContainer             = RootElectronContainer
BUSTopHistogramDump.InputMetContainer                  = RootMetContainer
BUSTopHistogramDump.InputBJetContainer                 = BUSTopBJetTagger.OutputBJetContainer
BUSTopHistogramDump.InputLJetContainer                 = BUSTopBJetTagger.OutputLJetContainer

BUSTopHistogramDump.IsAtlfast                          = IsAtlfast;
BUSTopHistogramDump.JetWeightTagger                    = RootJetTagger

BUSTopHistogramDump.TruthAvailable                     = DoTruth;
BUSTopHistogramDump.DumpTruth                          = DoTruth;
BUSTopHistogramDump.DoOverlapRemoval                   = True;

BUSTopHistogramDump.MinElectronPt                      = 20.0
BUSTopHistogramDump.MinElectronEta                     = -1000.0
BUSTopHistogramDump.MaxElectronEta                     =  1000.0
BUSTopHistogramDump.InclusiveElectronEta               = True

BUSTopHistogramDump.MinMuonPt                          = 20.0
BUSTopHistogramDump.MinMuonEta                         = -1000.0
BUSTopHistogramDump.MaxMuonEta                         =  1000.0
BUSTopHistogramDump.InclusiveMuonEta                   = True

BUSTopHistogramDump.MinBJetPt                          = 0.0
BUSTopHistogramDump.MinBJetEta                         = -5.1
BUSTopHistogramDump.MaxBJetEta                         =  5.1
BUSTopHistogramDump.InclusiveBJetEta                   = True

BUSTopHistogramDump.MinJetPt                           = 0.0
BUSTopHistogramDump.MinJetEta                          = -5.1
BUSTopHistogramDump.MaxJetEta                          =  5.1
BUSTopHistogramDump.InclusiveJetEta                    = True

