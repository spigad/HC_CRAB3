#include "GaudiKernel/IToolSvc.h"
#include "GaudiKernel/ITHistSvc.h"

#include "TH1.h"
#include "TH2.h"

#include "ParticleEvent/ParticleBaseContainer.h"

#include "egammaEvent/ElectronContainer.h"
#include "egammaEvent/Electron.h"
#include "muonEvent/MuonContainer.h"

#include "JetEvent/JetCollection.h"
#include "JetEvent/Jet.h"

#include "AnalysisTools/IAnalysisTools.h"

#include "BUSTopTools/BUSTopHistogrammer.h"
#include "BUSTopTools/EventTool.h"
#include "BUSTopTools/EventTagTool.h"

#include "BUSTopPreselection/BUSTopOverlap.h"

#include <stdint.h>
#include <algorithm>
#include <math.h>
#include <functional>

BUSTopOverlap::BUSTopOverlap(const std::string& name,
  ISvcLocator* pSvcLocator) : Algorithm(name, pSvcLocator)
{
  /// switches to control the analysis through job options :: these are the default
  /// to changed in the job options

  declareProperty("InputElectronContainer", m_electronInputContainerName); 
  declareProperty("InputMuonContainer", m_muonInputContainerName); 

  declareProperty("InputJetContainer", m_jetInputContainerName);
  declareProperty("OutputJetContainer", m_jetOutputContainerName);
  declareProperty("OutputEJetContainer", m_ejetOutputContainerName);

  declareProperty("DeltaRCut", m_deltaRCut);

  declareProperty("TruthAvailable", m_truthAvailable);
}


/////////////////////////////////////////////////////////////////////////////////////
/// Destructor - check up memory allocation
/// delete any memory allocation on the heap

BUSTopOverlap::~BUSTopOverlap() {
}

////////////////////////////////////////////////////////////////////////////////////
/// Initialize
/// initialize StoreGate
/// get a handle on the analysis tools
/// book histograms

StatusCode BUSTopOverlap::initialize() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO
       << "Initializing BUSTopOverlap"
       << endreq;

  StatusCode sc;
  
  sc = service("StoreGateSvc", m_storeGate);
  if(sc.isFailure()){
    mLog << MSG::ERROR 
         << "Unable to retrieve pointer to StoreGateSvc"
	 << endreq;
    return sc;
  }
  
  sc = service("THistSvc", m_thistSvc);
  if(sc.isFailure()){
    mLog << MSG::ERROR 
         << "Unable to retrieve pointer to THistSvc"
	 << endreq;
    return sc;
  }

  IToolSvc * toolSvc;
  service("ToolSvc", toolSvc);

  IAlgTool *tmp_eventTool;
  toolSvc->retrieveTool("EventTool", tmp_eventTool);
  m_eventTool = dynamic_cast<IEventTool *>(tmp_eventTool);

  IAlgTool *tmp_eventTagTool;
  toolSvc->retrieveTool("EventTagTool", tmp_eventTagTool);
  m_tagTool = dynamic_cast<IEventTagTool *>(tmp_eventTagTool);

  IAlgTool *tmp_histogramTool;
  toolSvc->retrieveTool("BUSTopHistogrammer", tmp_histogramTool);
  m_histogrammer = dynamic_cast<IBUSTopHistogrammer *>(tmp_histogramTool);

  registerHistograms();

  mLog << MSG::INFO << "Done initialising Overlap" << endreq;
  return StatusCode::SUCCESS;
}

void BUSTopOverlap::registerHistograms(){
  std::stringstream fName, hName;
  std::string title;

  fName.str("");
  hName.str("");
  hName << "o_ejet_deltaR";
  fName << "/AANT/Overlap/" << hName.str();
  title = "Electron/Jet Overlap \\Delta R";
  h_ejet_deltaR = new TH1F(hName.str().c_str(), title.c_str(), 100, 0, m_deltaRCut);
  m_thistSvc->regHist(fName.str().c_str(), h_ejet_deltaR);

  fName.str("");
  hName.str("");
  hName << "o_mjet_deltaR";
  fName << "/AANT/Overlap/" << hName.str();
  title = "Muon/Jet Overlap \\Delta R";
  h_mjet_deltaR = new TH1F(hName.str().c_str(), title.c_str(), 100, 0, m_deltaRCut);
  m_thistSvc->regHist(fName.str().c_str(), h_mjet_deltaR);

  fName.str("");
  hName.str("");
  hName << "o_ejet_deltaEnergy";
  fName << "/AANT/Overlap/" << hName.str();
  title = "Electron/Jet Overlap \\Delta E";
  h_ejet_deltaEnergy = new TH1F(hName.str().c_str(), title.c_str(), 100, -100, 100);
  m_thistSvc->regHist(fName.str().c_str(), h_ejet_deltaEnergy);

  fName.str("");
  hName.str("");
  hName << "o_mjet_deltaEnergy";
  fName << "/AANT/Overlap/" << hName.str();
  title = "Muon/Jet Overlap \\Delta E";
  h_mjet_deltaEnergy = new TH1F(hName.str().c_str(), title.c_str(), 100, -100, 100);
  m_thistSvc->regHist(fName.str().c_str(), h_mjet_deltaEnergy);
}

StatusCode BUSTopOverlap::finalize() {
  MsgStream mLog( messageService(), name() );

  return StatusCode::SUCCESS;

}

//////////////////////////////////////////////////////////////////////////////////
/// Execute - called by the event loop on event by event

StatusCode BUSTopOverlap::execute() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << "execute()" << endreq;

  getEventWeight();
  getStoregateContainers();
  createTemporaryContainers();

  removeMuons();
  removeElectrons();

  tagEvent();

  registerContainers();

  destroyTemporaryContainers();
  
  return StatusCode::SUCCESS;
}

void BUSTopOverlap::getStoregateContainers(){
  MsgStream mLog( messageService(), name() );  
  
  muonTES = 0;
  elecTES = 0;
  jetTES = 0;

  m_storeGate->retrieve(muonTES, m_muonInputContainerName);
  if(muonTES == 0){
    mLog << MSG::ERROR << "Problem getting MuonContainer" << endreq;
  }

  m_storeGate->retrieve(elecTES, m_electronInputContainerName);
  if(elecTES == 0){
    mLog << MSG::ERROR << "Problem getting ElectronContainer" << endreq;
  }

  m_storeGate->retrieve(jetTES, m_jetInputContainerName);
  if(jetTES == 0){
    mLog << MSG::ERROR << "Problem getting Jet Container" << endreq;
  }

}

void BUSTopOverlap::createTemporaryContainers(){
  c_jet_eremoved = new JetCollection(SG::VIEW_ELEMENTS);
  c_ejet = new JetCollection(SG::VIEW_ELEMENTS);

  c_jet_mremoved = new JetCollection(SG::VIEW_ELEMENTS);
  c_mjet = new JetCollection(SG::VIEW_ELEMENTS);
}

void BUSTopOverlap::destroyTemporaryContainers(){
  delete c_jet_mremoved;
}

void BUSTopOverlap::registerContainers(){
  registerJets(c_mjet, m_mjetOutputContainerName);
  registerJets(c_ejet, m_ejetOutputContainerName);
  registerJets(c_jet_eremoved, m_jetOutputContainerName);
}

void BUSTopOverlap::registerJets(JetCollection* jc, std::string n){
  MsgStream mLog( messageService(), name() );  

  m_storeGate->record(jc, n);
  AnalysisUtils::Sort::pT(jc);
  m_storeGate->setConst(jc);

  JetCollection::const_iterator iter = jc->begin();
  JetCollection::const_iterator iterEnd = jc->end();

  while(iter < iterEnd){
    mLog << MSG::DEBUG << "WEIGHT = " << (*iter)->getFlavourTagWeight() << endreq;
    iter++;
  }

}

//Remove electrons from jet containers.
void BUSTopOverlap::removeMuons(){
  MsgStream mLog( messageService(), name() );  

  JetCollection::const_iterator jIter = jetTES->begin();
  JetCollection::const_iterator jIterEnd = jetTES->end();

  while(jIter < jIterEnd){
    bool jetPassed = true;
    Analysis::MuonContainer::const_iterator mIter = muonTES->begin();
    Analysis::MuonContainer::const_iterator mIterEnd = muonTES->end();

    double deltaR = 0;
    while(mIter < mIterEnd){
      deltaR = AnalysisUtils::Delta::R(*mIter, *jIter);

      if(deltaR < m_deltaRCut){
        jetPassed = false;
        break;
      }

      mIter++;
    }
    
    if(jetPassed == true){
      c_jet_mremoved->push_back(*jIter);
    }else{
      c_mjet->push_back(*jIter);
      h_mjet_deltaR->Fill(deltaR, m_eventWeight);
      h_mjet_deltaEnergy->Fill(((*mIter)->e() - (*jIter)->e())/GeV, m_eventWeight);
    }

    jIter++;
  }
}

//Remove electrons from jet containers.
void BUSTopOverlap::removeElectrons(){
  MsgStream mLog( messageService(), name() );  

  JetCollection::const_iterator jIter = c_jet_mremoved->begin();
  JetCollection::const_iterator jIterEnd = c_jet_mremoved->end();

  while(jIter < jIterEnd){
    bool jetPassed = true;
    ElectronContainer::const_iterator eIter = elecTES->begin();
    ElectronContainer::const_iterator eIterEnd = elecTES->end();

    double deltaR = 0;
    while(eIter < eIterEnd){
      deltaR = AnalysisUtils::Delta::R(*eIter, *jIter);

      if(deltaR < m_deltaRCut){
        jetPassed = false;
        break;
      }

      eIter++;
    }
    
    if(jetPassed == true){
      c_jet_eremoved->push_back(*jIter);
    }else{
      c_ejet->push_back(*jIter);
      h_ejet_deltaR->Fill(deltaR, m_eventWeight);
      h_ejet_deltaEnergy->Fill(((*eIter)->e() - (*jIter)->e())/GeV, m_eventWeight);
    }

    jIter++;
  }
}

void BUSTopOverlap::getEventWeight(){
  if(m_tagTool->tagged(IEventTagTool::IS_ATLFAST) == false && m_tagTool->tagged(IEventTagTool::IS_MC) == true){
    m_eventWeight = m_eventTool->getEventWeight();
  }else{
    m_eventWeight = 1.0;
  }
}

void BUSTopOverlap::tagEvent(){
  int size = 0;

  if(muonTES->size() > 0){
    size = 2;
  }

  if(elecTES->size() > 0){
    size += 1;
  }

  m_tagTool->tag(IEventTagTool::EVENT);
  if(size == 3){
    if(muonTES->at(0)->pt() > elecTES->at(0)->pt()){
       m_tagTool->tag(IEventTagTool::EVENT_MUON);
    }else{
      m_tagTool->tag(IEventTagTool::EVENT_ELECTRON);
    }
  }else if(size == 2){
    m_tagTool->tag(IEventTagTool::EVENT_MUON);
  }else if(size == 1){
    m_tagTool->tag(IEventTagTool::EVENT_ELECTRON);
  }
}
