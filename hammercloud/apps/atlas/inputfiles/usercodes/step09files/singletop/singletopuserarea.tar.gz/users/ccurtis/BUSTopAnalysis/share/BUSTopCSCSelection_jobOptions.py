from BUSTopAnalysis.BUSTopAnalysisConf import BUSTopCSCSelection
Sequencer += BUSTopCSCSelection()
BUSTopCSCSelection.OutputLevel = WARNING

BUSTopCSCSelection.InputElectronContainer  = BUSTopPreselection.OutputElectronContainer
BUSTopCSCSelection.InputBJetContainer      = BUSTopPreselection.OutputBJetContainer
BUSTopCSCSelection.InputLightJetContainer  = BUSTopPreselection.OutputLightJetContainer
BUSTopCSCSelection.InputMuonContainer      = BUSTopPreselection.OutputMuonContainer
BUSTopCSCSelection.InputMETContainer       = BUSTopPreselection.OutputMETContainer

BUSTopCSCSelection.OutputElectronContainer = BUSTopCSCSelection.InputElectronContainer
BUSTopCSCSelection.OutputMuonContainer     = BUSTopCSCSelection.InputMuonContainer
BUSTopCSCSelection.OutputBJetContainer     = BUSTopCSCSelection.InputBJetContainer
BUSTopCSCSelection.OutputLightJetContainer = BUSTopCSCSelection.InputLightJetContainer

#BUSTopCSCSelection.OutputElectronContainer = "CSCElectrons"
#BUSTopCSCSelection.OutputMuonContainer     = "CSCMuons"
#BUSTopCSCSelection.OutputBJetContainer     = "CSCBJets"
#BUSTopCSCSelection.OutputLightJetContainer = "CSCLightJets"

BUSTopCSCSelection.TruthAvailable = DoTruth

	
