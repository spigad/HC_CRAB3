#ifndef BUSTOP_BJET_TAGGER_H
#define BUSTOP_BJET_TAGGER_H

#include "GaudiKernel/Algorithm.h"

#include "CLHEP/Units/SystemOfUnits.h"

#include "StoreGate/StoreGateSvc.h"

#include "GaudiKernel/ToolHandle.h"

#include <stdint.h>
#include <string>

class ITHistSvc;
class TH1F;
class TH2F;

class IAnalysisTools;
class TruthParticle;

namespace Analysis {
  class Electron;
  class Muon;
  class TauJet;
}

class Jet;
class JetCollection;
class IEventTool;
class IEventTagTool;

class BUSTopBJetTagger : public Algorithm {

 public:

   BUSTopBJetTagger(const std::string& name, ISvcLocator* pSvcLocator);
   ~BUSTopBJetTagger();

   StatusCode initialize();
   StatusCode finalize();
   StatusCode execute();
  
 private:
   StoreGateSvc* m_storeGate;
   ITHistSvc*    m_histSvc;
   IEventTool*   m_eventTool;
   IEventTagTool*   m_tagTool;

   std::string m_inputJetContainerName;
   std::string m_outputBJetContainerName;
   std::string m_outputLightJetContainerName;

   std::string m_jetWeightTagger;
   bool m_useRelativeTag;
   double m_weightCut;

   bool m_truthAvailable;
   double m_eventWeight;

   const JetCollection* jetTES;
   JetCollection* c_bjets;
   JetCollection* c_ljets;

   virtual void registerHistograms();
   virtual void getEventWeight();
   virtual void getStoregateContainers();
   virtual void createTemporaryContainers();
   virtual void destroyTemporaryContainers();

   virtual void registerContainers();
   virtual void registerContainer(JetCollection* j, std::string name);

   virtual void tagBJets();
   virtual void tagBestJet();
};

#endif // BUSTOP_BJET_TAGGER_H


