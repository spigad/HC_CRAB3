#include "BUSTopTools/DecayVector.h"

#include "StoreGate/StoreGateSvc.h"
#include "StoreGate/DataHandle.h"

#include "McParticleEvent/TruthParticleContainer.h"
#include "EventKernel/PdtPdg.h"
#include "AnalysisUtils/IParticleFilter.h"
#include "AnalysisUtils/AnalysisMisc.h"

#include <iostream>
#include <string>
#include <queue>


DecayVector::DecayVector(const std::string& t, const std::string& n, 
const IInterface* p):AlgTool(t, n, p), m_log(msgSvc(), n){
  declareInterface<IDecayVector>(this);
  
  m_truthVector = new TruthParticleContainer();
}

DecayVector::~DecayVector(){
  delete m_truthVector;
  m_truthVector = 0;
}

StatusCode DecayVector::initialize(){
  m_log.setLevel(outputLevel());
  
  service("StoreGateSvc", m_storeGate);
  m_log << MSG::DEBUG << "Initialising DecayVector Tool" << endreq;

  return StatusCode::SUCCESS;
}

StatusCode DecayVector::finalize(){
  return StatusCode::SUCCESS;
}

void DecayVector::fill(const TruthParticleContainer* mcTES, PDG::pidType pid, bool siblings, bool sign, int maxDepth){
  TruthParticleContainer::const_iterator iter = mcTES->begin();
  TruthParticleContainer::const_iterator iterEnd = mcTES->end();

  IParticleFilter mcFilter;
  mcFilter.setPdgId(pid);
  mcFilter.setMatchSign(sign);

  while(iter != iterEnd){
    if(mcFilter.isAccepted(*iter) && (*iter)->status() == 3){
      fill((*iter), siblings, maxDepth);
    }

    iter++;
  }
}

void DecayVector::fill(const TruthParticleContainer* mcTES, PDG::pidType pid, bool siblings){
  fill(mcTES, pid, siblings, false);
}

void DecayVector::fill(const TruthParticle *p, bool siblings, int maxDepth){
  m_log.setLevel(outputLevel());

  m_truthVector->clear();

  //Use queue q to track through decay
  //products and fill member vector
  std::queue<const TruthParticle*> q;

  //Don't add parents, but add all siblings.
  if(siblings == true){
    if(p->nParents() > 0){
      const TruthParticle* parent = p->mother(0);
      for(unsigned int i = 0; i < parent->nDecay(); i++){
        const TruthParticle* c = getFinalParticle(parent->child(i));
        q.push(c);
        m_truthVector->push_back(new TruthParticle(*c));
      }
    }
  }else{
    if(p->nParents() > 0){
      const TruthParticle* parent = p->mother(0);
      for(unsigned int i = 0; i < parent->nDecay(); i++){
        const TruthParticle* c = getFinalParticle(parent->child(i));
        if(p->pdgId() == c->pdgId()){
          q.push(c);
          m_truthVector->push_back(new TruthParticle(*c));
        }
      }
    }
  }

  int depthCount = 0;
  int maxChildren = 0;
  int newChildren = 0;
  int runningTot = 0;

  while(q.size() > 0){
    const TruthParticle *qp = q.front();
    q.pop();

    if(maxDepth != -1){
      if(depthCount >= maxDepth){
        break;
      }else{
        runningTot++;
        newChildren += qp->nDecay();

        if(runningTot >= maxChildren){
          maxChildren = newChildren;
          newChildren = 0;
          runningTot = 0;
          depthCount++;
        } 
      }
    }

    for(unsigned int i = 0; i < qp->nDecay(); i++){
      const TruthParticle* c = getFinalParticle(qp->child(i));
      q.push(c);
      m_truthVector->push_back(new TruthParticle(*c));
    }

  }

  if(m_truthVector->size() > 1){
    AnalysisUtils::Sort::pT(m_truthVector);
  }
}

const TruthParticle* DecayVector::getFinalParticle(const TruthParticle* p){
  if(p->nDecay() == 1 && p->child(0)->pdgId() == p->pdgId()){
    return getFinalParticle(p->child(0));
  }else{
    return p;
  }
}

TruthParticleContainer* DecayVector::getTruthVector(){
  return m_truthVector;
}

/**
 *  Caller gains owner ship of this Container!
 */
TruthParticleContainer* DecayVector::filter(PDG::pidType id, bool matchSign){
  TruthParticleContainer* v = new TruthParticleContainer(SG::VIEW_ELEMENTS);

  IParticleFilter filter;
  filter.setPdgId(id);
  filter.setMatchSign(matchSign);

  TruthParticleContainer::const_iterator iter = m_truthVector->begin();
  TruthParticleContainer::const_iterator iterEnd = m_truthVector->end();

  while(iter < iterEnd){
    if(filter.isAccepted(*iter) == true){
      v->push_back(*iter);
    }
    iter++;
  }
  AnalysisUtils::Sort::pT(v);
  return v;
}

TruthParticleContainer* 
DecayVector::filterFailed(const TruthParticleContainer* mcTES, PDG::pidType id, bool 
matchSign){
  TruthParticleContainer* v = new TruthParticleContainer(SG::VIEW_ELEMENTS);
  TruthParticleContainer* passed = filter(id, matchSign);
  
  TruthParticleContainer::const_iterator iter = mcTES->begin();
  TruthParticleContainer::const_iterator iterEnd = mcTES->end();

  IParticleFilter filter;
  filter.setPdgId(id);
  filter.setMatchSign(matchSign);

  //iterator over truth
  //if electron is found, iterate over all passed
  //if not already matched, push_back.
  //ensure that status is equal only to 3!
  while(iter < iterEnd){
    if(filter.isAccepted(*iter) == true && (*iter)->status() == 3){
      TruthParticleContainer::const_iterator passedIter = passed->begin();
      TruthParticleContainer::const_iterator passedIterEnd = passed->end();

      bool tagged = false;
      while(passedIter < passedIterEnd){
        if((*passedIter)->barcode() == (*iter)->barcode()){
          tagged = true;
          break;
        }
        passedIter++;
      }
      if(tagged == false){
        v->push_back(*iter);
      }
    }
    iter++;
  }
  AnalysisUtils::Sort::pT(v);
  return v;
}

void DecayVector::clear(){
  m_truthVector->clear();
}
