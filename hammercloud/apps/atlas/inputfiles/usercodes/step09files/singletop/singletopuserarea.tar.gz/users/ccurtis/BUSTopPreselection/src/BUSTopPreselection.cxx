#include "GaudiKernel/IToolSvc.h"
#include "GaudiKernel/ITHistSvc.h"

#include "TH1.h"
#include "TH2.h"

#include "DataModel/DataVector.h"
#include "ParticleEvent/ParticleBaseContainer.h"
#include "egammaEvent/ElectronContainer.h"
#include "egammaEvent/Electron.h"
#include "egammaEvent/egammaParamDefs.h"
#include "egammaEvent/EMShower.h"
#include "muonEvent/MuonContainer.h"
#include "muonEvent/MuonParamDefs.h"

#include "JetEvent/JetCollection.h"
#include "JetEvent/Jet.h"

#include "MissingETEvent/MissingET.h"
#include "MissingETEvent/MissingEtCalo.h"
#include "MissingETEvent/MissingEtTruth.h"

#include "AnalysisTools/IAnalysisTools.h"
#include "AnalysisUtils/AnalysisCombination.h"
#include "AnalysisUtils/AnalysisMisc.h"
#include "AnalysisUtils/IParticleFilter.h"

#include "BUSTopTools/BUSTopHistogrammer.h"
#include "BUSTopTools/IBUSTopHistogrammer.h"
#include "BUSTopTools/EventTool.h"
#include "BUSTopTools/EventTagTool.h"

#include "BUSTopPreselection/BUSTopPreselection.h"

#include <stdint.h>
#include <algorithm>
#include <math.h>
#include <functional>
#include <iostream>
#include <string>
#include <sstream>
#include <stdint.h>
#include <vector>

//////////////////////////////////////////////////////////////////////////////////////
/// Constructor

BUSTopPreselection::BUSTopPreselection(const std::string& name,
  ISvcLocator* pSvcLocator) : Algorithm(name, pSvcLocator)
{
  /// switches to control the analysis through job options :: these are the default
  /// to changed in the job options


  declareProperty("FilterResults", m_filterID); 
  declareProperty("PreselectionResult", m_preselectionResultName); 

  declareProperty("InputElectronContainer", m_electronContainerName); 
  declareProperty("InputBJetContainer", m_bJetContainerName); 
  declareProperty("InputLightJetContainer", m_lightJetContainerName); 
  declareProperty("InputMuonContainer", m_muonContainerName); 
  declareProperty("InputMETContainer", m_metContainerName); 

  declareProperty("OutputElectronContainer", m_electronOutputContainerName); 
  declareProperty("OutputBJetContainer", m_bjetOutputContainerName); 
  declareProperty("OutputLightJetContainer", m_ljetOutputContainerName); 
  declareProperty("OutputMuonContainer", m_muonOutputContainerName); 
  declareProperty("OutputMETContainer", m_metOutputContainerName); 

  declareProperty("TruthAvailable", m_truthAvailable); 
  declareProperty("QuitOnFail", m_quitOnFail); 

  m_metPassed = true;
  m_lightJetPassed = true;
  m_bJetPassed = true;
  m_elecPassed = true;
  m_muonPassed = true;
  m_leptonPassed = true;
}


/////////////////////////////////////////////////////////////////////////////////////
/// Destructor - check up memory allocation
/// delete any memory allocation on the heap

BUSTopPreselection::~BUSTopPreselection() {
}

////////////////////////////////////////////////////////////////////////////////////
/// Initialize
/// initialize StoreGate
/// get a handle on the analysis tools
/// book histograms

StatusCode BUSTopPreselection::initialize() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO
       << "Initializing BUSTopPreselection"
       << endreq;

  StatusCode sc;
  
  sc = service("StoreGateSvc", m_storeGate);
  if(sc.isFailure()){
    mLog << MSG::ERROR 
         << "Unable to retrieve pointer to StoreGateSvc"
	 << endreq;
    return sc;
  }
  
  sc = service("THistSvc", m_thistSvc);
  if(sc.isFailure()){
    mLog << MSG::ERROR 
         << "Unable to retrieve pointer to THistSvc"
	 << endreq;
    return sc;
  }

  IToolSvc * toolSvc;
  service("ToolSvc", toolSvc);

  IAlgTool *tmp_eventTool;
  toolSvc->retrieveTool("EventTool", tmp_eventTool);
  m_eventTool = dynamic_cast<IEventTool *>(tmp_eventTool);

  IAlgTool *tmp_tagTool;
  toolSvc->retrieveTool("EventTagTool", tmp_tagTool);
  m_tagTool = dynamic_cast<IEventTagTool *>(tmp_tagTool);

  IAlgTool *tmp_histogramTool;
  toolSvc->retrieveTool("BUSTopHistogrammer", tmp_histogramTool);
  m_histogrammer = dynamic_cast<IBUSTopHistogrammer *>(tmp_histogramTool);  registerHistograms();
  
  return StatusCode::SUCCESS;
}

void BUSTopPreselection::registerHistograms(){
  std::stringstream fName, hName;
  std::string title;

  fName.str("");
  hName.str("");
  hName << "pr_met_result";
  fName << "/AANT/Preselection/" << hName.str();
  title = "MET Preselection Result";
  h_met_result = new TH1F(hName.str().c_str(), title.c_str(), 4, 0, 4);
  m_thistSvc->regHist(fName.str().c_str(), h_met_result);

  fName.str("");
  hName.str("");
  hName << "pr_jet_result";
  fName << "/AANT/Preselection/" << hName.str();
  title = "Jet Preselection Result";
  h_jet_result = new TH1F(hName.str().c_str(), title.c_str(), 5, 0, 5);
  m_thistSvc->regHist(fName.str().c_str(), h_jet_result);

  fName.str("");
  hName.str("");
  hName << "pr_elec_result";
  fName << "/AANT/Preselection/" << hName.str();
  title = "Electron Preselection Result";
  h_elec_result = new TH1F(hName.str().c_str(), title.c_str(), 8, 0, 8);
  m_thistSvc->regHist(fName.str().c_str(), h_elec_result);

  fName.str("");
  hName.str("");
  hName << "pr_muon_result";
  fName << "/AANT/Preselection/" << hName.str();
  title = "Muon Preselection Result";
  h_muon_result = new TH1F(hName.str().c_str(), title.c_str(), 8, 0, 8);
  m_thistSvc->regHist(fName.str().c_str(), h_muon_result);

  fName.str("");
  hName.str("");
  hName << "pr_full_result_emj";
  fName << "/AANT/Preselection/" << hName.str();
  title = "Electron Preselection Result";
  h_full_result_emj = new TH1F(hName.str().c_str(), title.c_str(), 11, 0, 11);
  m_thistSvc->regHist(fName.str().c_str(), h_full_result_emj);

  fName.str("");
  hName.str("");
  hName << "pr_full_result_mmj";
  fName << "/AANT/Preselection/" << hName.str();
  title = "Muon Preselection Result";
  h_full_result_mmj = new TH1F(hName.str().c_str(), title.c_str(), 11, 0, 11);
  m_thistSvc->regHist(fName.str().c_str(), h_full_result_mmj);

  fName.str("");
  hName.str("");
  hName << "pr_full_result_lmj";
  fName << "/AANT/Preselection/" << hName.str();
  title = "Preselection Result";
  h_full_result_lmj = new TH1F(hName.str().c_str(), title.c_str(), 11, 0, 11);
  m_thistSvc->regHist(fName.str().c_str(), h_full_result_lmj);

  fName.str("");
  hName.str("");
  hName << "pr_passed";
  fName << "/AANT/Preselection/" << hName.str();
  title = "Number Passed";
  h_passed = new TH1F(hName.str().c_str(), title.c_str(), 1, 0, 1);
  m_thistSvc->regHist(fName.str().c_str(), h_passed);
}

StatusCode BUSTopPreselection::finalize() {
  MsgStream mLog( messageService(), name() );

  //reformat histograms....

  formatResultsHistogram(h_elec_result);
  formatResultsHistogram(h_muon_result);
  formatResultsHistogram(h_jet_result);
  formatResultsHistogram(h_met_result);
  formatResultsHistogram(h_full_result_emj);
  formatResultsHistogram(h_full_result_mmj);
  formatResultsHistogram(h_full_result_lmj);

  return StatusCode::SUCCESS;
}

void BUSTopPreselection::formatResultsHistogram(TH1F* h){
  for(int i = 2; i <= (h->GetNbinsX()); i++){
    double total = h->GetBinContent(i-1) - h->GetBinContent(i);
    h->SetBinContent(i, total);
  }
}

//////////////////////////////////////////////////////////////////////////////////
/// Execute - called by the event loop on event by event

StatusCode BUSTopPreselection::execute() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << "execute()" << endreq;

  getEventWeight();
  getStoregateContainers();

  int met_result = 0;
  int jet_result = 0;

  int elec_result = 0;
  int muon_result = 0;
  int lep_result = 0;

  if(m_tagTool->tagged(IEventTagTool::TRIGGERED) || m_tagTool->tagged(IEventTagTool::IS_ATLFAST)){

    met_result = preselectMET();
    jet_result = preselectJets();

    elec_result = preselectElectrons();
    muon_result = preselectMuons();

    if(muon_result == LEP_PASSED || elec_result == LEP_PASSED){
      lep_result = LEP_PASSED;
      m_leptonPassed = true;
    }else{
      if(muon_result > elec_result){
        lep_result = muon_result;
      }else{
        lep_result = elec_result;
      }
      m_leptonPassed = false;
    }

  }else{
    met_result = MET_FAILED_TRIGGER;
    jet_result = JET_FAILED_TRIGGER;
    elec_result = LEP_FAILED_TRIGGER;
    muon_result = LEP_FAILED_TRIGGER;

    m_metPassed = false;
    m_lightJetPassed = false;
    m_bJetPassed = false;
    m_elecPassed = false;
    m_muonPassed = false;
    m_leptonPassed = false;
  }

  mLog << MSG::DEBUG << "met_result = " << met_result << endreq;
  mLog << MSG::DEBUG << "jet_result = " << jet_result << endreq;
  mLog << MSG::DEBUG << "elec_result = " << elec_result << endreq;
  mLog << MSG::DEBUG << "muon_result = " << muon_result << endreq;

  h_met_result->Fill(0.0, m_eventWeight);
  h_met_result->Fill(met_result, m_eventWeight);

  h_jet_result->Fill(0.0, m_eventWeight);
  h_jet_result->Fill(jet_result, m_eventWeight);

  h_elec_result->Fill(0.0, m_eventWeight);
  h_elec_result->Fill(elec_result, m_eventWeight);

  h_muon_result->Fill(0.0, m_eventWeight);
  h_muon_result->Fill(muon_result, m_eventWeight);

  h_full_result_emj->Fill(0.0, m_eventWeight);
  h_full_result_mmj->Fill(0.0, m_eventWeight);
  h_full_result_lmj->Fill(0.0, m_eventWeight);

  if(elec_result != LEP_PASSED){
    h_full_result_emj->Fill(elec_result, m_eventWeight);
  }else if(met_result != MET_PASSED){
    h_full_result_emj->Fill(LEP_PASSED+met_result-2, m_eventWeight);
  }else{
    h_full_result_emj->Fill(MET_PASSED+LEP_PASSED+jet_result-4, m_eventWeight);
  }

  if(muon_result != LEP_PASSED){
    h_full_result_mmj->Fill(muon_result, m_eventWeight);
  }else if(met_result != MET_PASSED){
    h_full_result_mmj->Fill(LEP_PASSED+met_result-2, m_eventWeight);
  }else{
    h_full_result_mmj->Fill(MET_PASSED+LEP_PASSED+jet_result-4, m_eventWeight);
  }

  if(lep_result != LEP_PASSED){
    h_full_result_lmj->Fill(lep_result, m_eventWeight);
  }else if(met_result != MET_PASSED){
    h_full_result_lmj->Fill(LEP_PASSED+met_result-2, m_eventWeight);
  }else{
    h_full_result_lmj->Fill(MET_PASSED+LEP_PASSED+jet_result-4, m_eventWeight);
  }

  registerPreselected();
  tagEvent();

  resetFlags();

  if(m_quitOnFail == true && m_tagTool->tagged(IEventTagTool::PRESELECTION) == false){
    setFilterPassed(false);
  }
  
  return StatusCode::SUCCESS;
}

void BUSTopPreselection::getStoregateContainers(){
  MsgStream mLog( messageService(), name() );

  metTES = 0;
  m_storeGate->retrieve(metTES, m_metContainerName);
  if(metTES == 0){
    mLog << MSG::ERROR << "Could not retrieve MET Container from Storegate" << endreq;
  }

  elecTES = 0;
  m_storeGate->retrieve(elecTES, m_electronContainerName);
  if(elecTES == 0){
    mLog << MSG::ERROR << "Could not retrieve Electron Container from Storegate" << endreq;
  }

  bjetTES = 0;
  m_storeGate->retrieve(bjetTES, m_bJetContainerName);
  if(bjetTES == 0){
    mLog << MSG::ERROR << "Could not retrieve BJet Container from Storegate" << endreq;
  }

  ljetTES = 0;
  m_storeGate->retrieve(ljetTES, m_lightJetContainerName);
  if(ljetTES == 0){
    mLog << MSG::ERROR << "Could not retrieve LightJet Container from Storegate" << endreq;
  }

  muonTES = 0;
  m_storeGate->retrieve(muonTES, m_muonContainerName);
  if(muonTES == 0){
    mLog << MSG::ERROR << "Could not retrieve Muon Container from Storegate" << endreq;
  }
}

void BUSTopPreselection::createTemporaryContainers(){
}

int BUSTopPreselection::preselectMET(){
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "preselectMET()" << endreq;

  if(metTES->et() > 20*GeV){
    m_metPassed = true;
    return MET_PASSED;
  }else{
    m_metPassed = false;
    return MET_FAILED;
  }
}

int BUSTopPreselection::preselectJets(){
  MsgStream mLog( messageService(), name() );

  int nLJet = ljetTES->size();
  int nBJet = bjetTES->size();

  int nLower = 0;
  IParticleFilter centralB;
  centralB.setEtaMin(-5.0);
  centralB.setEtaMax(5.0);

  for(int i = 0; i < nLJet; i++){
    if(ljetTES->at(i)->pt() > 15*GeV){
      if(centralB.isAccepted(ljetTES->at(i)) == true){
        nLower++;
      }
    }else{
      break;
    }  
  }

  for(int i = 0; i < nBJet; i++){
    if(bjetTES->at(i)->pt() > 15*GeV){
      if(centralB.isAccepted(bjetTES->at(i)) == true){
        nLower++;
      }
    }else{
      break;
    }  
  }

  if(nLower > 4){
    m_lightJetPassed = false;
    m_bJetPassed = false;
    return JET_FAILED_MIN;
  }

  int nBUpper = 0;
  int nLUpper = 0;

  for(int i = 0; i < nLJet; i++){
    if(ljetTES->at(i)->pt() > 30*GeV){
      if(centralB.isAccepted(ljetTES->at(i)) == true){
        nLUpper++;
      }
    }else{
      break;
    }  
  }

  centralB.setEtaMin(-2.5);
  centralB.setEtaMax(2.5);

  for(int i = 0; i < nBJet; i++){
    if(bjetTES->at(i)->pt() > 30*GeV){
      if(centralB.isAccepted(bjetTES->at(i)) == true){
        nBUpper++;
      }
    }else{
      break;
    }  
  }

  mLog << MSG::DEBUG << "nBUpper = " << nBUpper << endreq;
  mLog << MSG::DEBUG << "nLUpper = " << nLUpper << endreq;

  if(nBUpper < 1 || (nBUpper + nLUpper) < 2){
    m_lightJetPassed = false;
    m_bJetPassed = false;
    return JET_FAILED_MAX;
  }


  m_lightJetPassed = true;
  m_bJetPassed = true;
  
  return JET_PASSED;
}

int BUSTopPreselection::preselectElectrons(){
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "preselectElectrons()" << endreq;

  if(elecTES->size() < 1){
    m_elecPassed = false;
    return LEP_FAILED_N;
  }

  if(elecTES->at(0)->pt() < 30*GeV){
    m_elecPassed = false;
    return LEP_FAILED_PE;
  }

  //This isn't perfect - what if there are other electrons which pass the test?
  const EMShower* m_EMShower = elecTES->at(0)->detail<EMShower>("egDetailAOD");
  if(m_EMShower->parameter(egammaParameters::etcone20) > 6*GeV){
    mLog << MSG::DEBUG << "Failed in electron isolation" << endreq;
    m_elecPassed = false;
    return LEP_FAILED_ISO;
  }

  IParticleFilter centralB, crackA, crackC;

  centralB.setEtaMin(-2.5);
  centralB.setEtaMax(2.5);

  crackA.setEtaMin(1.37);
  crackA.setEtaMax(1.52);
 
  crackC.setEtaMin(-1.52);
  crackC.setEtaMax(-1.37);
  
  //only need to check the first electron due secondary cut beloe
  if(centralB.isAccepted(elecTES->at(0)) == false || crackA.isAccepted(elecTES->at(0)) == true || crackC.isAccepted(elecTES->at(0)) == true){
    m_elecPassed = false;
    return LEP_FAILED_CRACK;
  }

  for(unsigned int i = 1; i < elecTES->size(); i++){
    if(elecTES->at(i)->pt() > 10*GeV){
      m_elecPassed = false;
      return LEP_FAILED_SE;
    }
  }

  for(unsigned int i = 0; i < muonTES->size(); i++){
    if(muonTES->at(i)->pt() > 10*GeV){
      m_elecPassed = false;
      return LEP_FAILED_MUON;
    }
  }

  m_elecPassed = true;
  return LEP_PASSED;
}

int BUSTopPreselection::preselectMuons(){
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "preselectMuons()" << endreq;

  if(muonTES->size() < 1){
    m_muonPassed = false;
    return LEP_FAILED_N;
  }

  if(muonTES->at(0)->pt() < 30*GeV){
    m_muonPassed = false;
    return LEP_FAILED_PE;
  }

  //This isn't perfect - what if there are other electrons which pass the test?
  //const EMShower* m_EMShower = muonTES->at(0)->detail<EMShower>("egDetailAOD");
  //if(m_EMShower->parameter(egammaParameters::etcone20) > 6*GeV){

  if(muonTES->at(0)->parameter(MuonParameters::etcone20) > 6*GeV){
    mLog << MSG::DEBUG << "Failed in muon isolation" << endreq;
    m_muonPassed = false;
    return LEP_FAILED_ISO;
  }

  for(unsigned int i = 0; i < elecTES->size(); i++){
    if(elecTES->at(i)->pt() > 10*GeV){
      m_muonPassed = false;
      return LEP_FAILED_MUON;
    }
  }

  for(unsigned int i = 1; i < muonTES->size(); i++){
    if(muonTES->at(i)->pt() > 10*GeV){
      m_muonPassed = false;
      return LEP_FAILED_SE;
    }
  }

  m_muonPassed = true;
  return LEP_PASSED;
}

void BUSTopPreselection::registerPreselected(){
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "registerPreselected()" << endreq;

  if(m_leptonPassed == true && m_metPassed == true && m_lightJetPassed == true && m_bJetPassed == true){
    h_passed->Fill(0.0, m_eventWeight);
  }
}

void BUSTopPreselection::resetFlags(){
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "resetFlags()" << endreq;

  m_metPassed = true;
  m_bJetPassed = true;
  m_lightJetPassed = true;
  m_elecPassed = true;
  m_muonPassed = true;
  m_leptonPassed = true;
}

void BUSTopPreselection::destroyTemporaryContainers(){
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "destroyTemporaryContainers(...)" << endreq;
}

void BUSTopPreselection::getEventWeight(){
  if(m_tagTool->tagged(IEventTagTool::IS_ATLFAST) == false && m_tagTool->tagged(IEventTagTool::IS_MC) == true){
    m_eventWeight = m_eventTool->getEventWeight();
  }else{
    m_eventWeight = 1.0;
  }
}

void BUSTopPreselection::tagEvent(){
  MsgStream mLog( messageService(), name() );

 if(m_leptonPassed == true && m_metPassed == true && m_lightJetPassed == true && m_bJetPassed == true){
    //Tag event...
    m_tagTool->tag(IEventTagTool::PRESELECTION);
    mLog << MSG::DEBUG << "Preselection: Tagging " << m_tagTool->tagged(IEventTagTool::PRESELECTION) << endreq;
    if(m_elecPassed == true){   
      m_tagTool->tag(IEventTagTool::ELECTRON_PRESELECTION);
      m_tagTool->tag(IEventTagTool::ELECTRON_PRESELECTION);
      mLog << MSG::DEBUG << "Preselection: Tagging Electron " << m_tagTool->tagged(IEventTagTool::ELECTRON_PRESELECTION) << endreq;
    }else if(m_muonPassed == true){
      m_tagTool->tag(IEventTagTool::MUON_PRESELECTION);
      m_tagTool->tag(IEventTagTool::MUON_PRESELECTION);
      mLog << MSG::DEBUG << "Preselection: Tagging Muon " << m_tagTool->tagged(IEventTagTool::MUON_PRESELECTION) << endreq;
    }else{
      mLog << MSG::DEBUG << "Preselection: not electron or muon" << endreq;
    }
  }else{
    mLog << MSG::DEBUG << "Preselection: Failed" << endreq;
  }
}
