from BUSTopAnalysis.BUSTopAnalysisConf import BUSTopInitAlg

BUSTopInitAlg = BUSTopInitAlg( "BUSTopInitAlg" )
BUSTopInitAlg.OutputLevel = WARNING

Sequencer += BUSTopInitAlg

BUSTopInitAlg.IsAtlfast = IsAtlfast;
BUSTopInitAlg.IsMC = IsMC;

