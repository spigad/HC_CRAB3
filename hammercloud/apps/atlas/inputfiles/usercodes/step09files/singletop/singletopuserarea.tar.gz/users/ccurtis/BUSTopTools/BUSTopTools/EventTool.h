#ifndef EVENT_TOOL_H
#define EVENT_TOOL_H

#include "GaudiKernel/AlgTool.h"
#include "GaudiKernel/MsgStream.h"
#include "GaudiKernel/AlgFactory.h"
#include "StoreGate/StoreGateSvc.h"
#include "BUSTopTools/IEventTool.h"

class EventInfo;
class EventType;

class EventTool: virtual public IEventTool, public AlgTool{
   public:
     EventTool(const std::string&, const std::string&, const IInterface*);
     virtual ~EventTool();
     virtual StatusCode initialize();
     virtual StatusCode finalize();

     virtual const EventInfo* getEventInfo();
     virtual double getEventWeight();
     virtual double getEventWeight(const EventType* et);

   private:
     mutable MsgStream m_log;
     StoreGateSvc* m_storeGate;

     virtual double getOldEventWeight();

};

#endif
