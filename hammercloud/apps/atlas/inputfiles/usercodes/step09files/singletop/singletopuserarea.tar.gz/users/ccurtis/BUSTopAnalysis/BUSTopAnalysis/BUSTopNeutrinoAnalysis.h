#ifndef BUSTOP_NEUTRINO_ANALYSIS_H
#define BUSTOP_NEUTRINO_ANALYSIS_H

#include "GaudiKernel/Algorithm.h"

#include "CLHEP/Units/SystemOfUnits.h"

#include "StoreGate/StoreGateSvc.h"

#include "GaudiKernel/ToolHandle.h"

#include <stdint.h>
#include <string>

class ITHistSvc;
class TH1F;
class TH2F;

class IAnalysisTools;

namespace Analysis {
  class MuonContainer;
}

class TruthParticleContainer;
class ElectronContainer;
class MissingET;
class IBUSTopHistogrammer;
class INuSolutionTool;
class ITruthMatch;
class IEventTool;
class IEventTagTool;

class KinematicHistograms;
class ResolutionHistograms;
class METResolutionHistograms;

class BUSTopNeutrinoAnalysis : public Algorithm {

 public:

   BUSTopNeutrinoAnalysis(const std::string& name, ISvcLocator* pSvcLocator);
   ~BUSTopNeutrinoAnalysis();

   StatusCode initialize();
   StatusCode finalize();
   StatusCode execute();
  
 private:
   StoreGateSvc* m_storeGate;
   ITHistSvc*    m_thistSvc;
   IBUSTopHistogrammer *m_histogrammer;
   INuSolutionTool *m_nuSolTool;
   ITruthMatch* m_truthMatchTool;
   IEventTool *m_eventTool;
   IEventTagTool *m_tagTool;

   std::string m_fullElectronsName;
   std::string m_fullMuonsName;
   std::string m_preselectedElectronsName;
   std::string m_preselectedMuonsName;
   std::string m_cscSelectedElectronsName;
   std::string m_cscSelectedMuonsName;
   std::string m_metName;

   std::string m_nuName;
   std::string m_preselectedNuName;
   std::string m_cscSelectedNuName;
   std::string m_selectedNuName;

   double m_wWidth;
   double m_metSigma;

   double m_eventWeight;
   bool m_truthAvailable;

   virtual void registerHistograms();

   virtual void getEventWeight();
   virtual void getStoregateContainers();
   virtual void getTruthContainers();

   virtual void plotMETRes();
   virtual void plotTruthRes();
   virtual void plotTruthRes(const TruthParticleContainer* t);

   const NeutrinoContainer* c_nu;
   const NeutrinoContainer* c_preselectedNu;
   const NeutrinoContainer* c_cscSelectedNu;
   const NeutrinoContainer* c_selectedNu;

   const MissingET* metTES;

   const TruthParticleContainer* c_enuTruth;
   const TruthParticleContainer* c_munuTruth;

   KinematicHistograms* h_nu_full;
   KinematicHistograms* h_nu_preselection;
   KinematicHistograms* h_nu_cscselection;
   KinematicHistograms* h_nu_selection;

   METResolutionHistograms* h_met_res_large_eta;
   METResolutionHistograms* h_met_res_small_eta;

   ResolutionHistograms* h_nu_res_large_eta;
   ResolutionHistograms* h_nu_res_small_eta;
};

#endif // BUSTOP_NEUTRINO_ANALYSIS_H


