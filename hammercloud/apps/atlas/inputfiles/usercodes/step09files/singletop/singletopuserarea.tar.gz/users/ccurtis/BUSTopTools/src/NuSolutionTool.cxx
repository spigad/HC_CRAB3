#include "GaudiKernel/MsgStream.h"
#include "BUSTopTools/NuSolutionTool.h"

NuSolutionTool::NuSolutionTool(const std::string& t, const std::string & n, const IInterface* p): INuSolutionTool(t, n, p){
  declareInterface<NuSolutionTool>(this);
}

StatusCode NuSolutionTool::initialize(){
  MsgStream m_log(msgSvc(), name());
  m_log << "Initializing NuSolutionTool" << endreq;
  return StatusCode::SUCCESS;
}
