#ifndef INU_SOLUTION_TOOL_H
#define INU_SOLUTION_TOOL_H

#include "CLHEP/Units/SystemOfUnits.h"
#include "GaudiKernel/AlgTool.h"

class TruthParticle;
class NeutrinoContainer;

class INuSolutionTool: public AlgTool{
   public:
     INuSolutionTool(const std::string& t, const std::string& n, const IInterface* p): AlgTool(t, n, p){}
     virtual ~INuSolutionTool(){}

     template <class LEPTON, class MET> bool getSolutions(const LEPTON* l, const MET* met, double& sol1, double& sol2, double mass = 80.4*GeV);
     template <class LEPTON, class MET> bool getSolutions(const LEPTON* l, const MET* met, NeutrinoContainer* nc, double mass = 80.4*GeV);
     template <class LEPTON> bool getSolutions(const LEPTON* l, double ptmissx, double ptmissy, double& sol1, double& sol2, double mw = 80.4*GeV);
     template <class LEPTON> bool getSolutions(const LEPTON* l, double ptmissx, double ptmissy, NeutrinoContainer* nc, double mw = 80.4*GeV);

     template <class LEPTON, class MET> bool etaSolution(const LEPTON* l, const MET* met, NeutrinoContainer* nc);
     template <class LEPTON, class MET> bool massSolution(const LEPTON* l, const MET* met, NeutrinoContainer* nc, double mass, double width);
     template <class LEPTON, class MET> bool metSolution(const LEPTON* l, const MET* met, NeutrinoContainer* nc, double res, double mass = 80.4*GeV);
     
};

#include "BUSTopTools/INuSolutionTool.icc"

#endif

