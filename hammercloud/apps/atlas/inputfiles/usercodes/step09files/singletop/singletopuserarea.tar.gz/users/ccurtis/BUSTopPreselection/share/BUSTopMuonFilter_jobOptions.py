from BUSTopPreselection.BUSTopPreselectionConf import BUSTopMuonFilter
Sequencer += BUSTopMuonFilter()
BUSTopMuonFilter.OutputLevel = WARNING

BUSTopMuonFilter.MuonInputContainer          = RootMuonContainer
BUSTopMuonFilter.MuonOutputContainer         = "FilteredMuons"

if DoTruth:
	BUSTopMuonFilter.TruthAvailable = 1
else:
	BUSTopMuonFilter.TruthAvailable = 0



