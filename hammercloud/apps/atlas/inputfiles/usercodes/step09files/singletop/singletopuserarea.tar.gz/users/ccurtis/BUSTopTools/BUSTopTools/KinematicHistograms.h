#ifndef KINEMATIC_HISTOGRAMS_H
#define KINEMATIC_HISTOGRAMS_H

#include "GaudiKernel/AlgTool.h"
#include "GaudiKernel/MsgStream.h"
#include "GaudiKernel/AlgFactory.h"
#include "StoreGate/StoreGateSvc.h"
#include "StoreGate/DataHandle.h"
#include "AIDA/IHistogram1D.h"
#include "AIDA/IHistogram2D.h"
#include "GaudiKernel/ITHistSvc.h"
#include "EventKernel/PdtPdg.h"

class IBUSTopHistogrammer;
class TruthParticle;
class TH1F;
class TH2F;
class TH1I;

class KinematicHistograms{
   public:
     KinematicHistograms(IBUSTopHistogrammer* parent, std::string algName, std::string dirName, std::string hname);
     virtual ~KinematicHistograms(){};

     TH1I** n;				//[0] = combined, [1] = pos, [2] = neg
     TH1I** weight;			//[0] = combined, [1] = pos, [2] = neg
     TH1F** phi;
     TH1F** eta;
     TH1F** p;
     TH1F** px;
     TH1F** py;
     TH1F** pz;
     TH1F** pt;
     TH1F** ipt;
     TH1F** costheta;
     TH1F** ptop;
     TH1F** etoe;
     TH1F** e;

     template<class C> void plotContainer(C* c, double w);
     template<class P> void plot(const P* p, double w);
};

#include "BUSTopTools/KinematicHistograms.icc"

#endif

