from BUSTopAnalysis.BUSTopAnalysisConf import BUSTopElectronAnalysis
Sequencer += BUSTopElectronAnalysis()
BUSTopElectronAnalysis.OutputLevel = WARNING

BUSTopElectronAnalysis.ElectronInputContainer         = BUSTopSelection.InputElectronContainer
BUSTopElectronAnalysis.SelectedElectronContainer      = BUSTopSelection.OutputElectronContainer

BUSTopElectronAnalysis.FilteredElectronContainer      = BUSTopElectronFilter.ElectronOutputContainer
BUSTopElectronAnalysis.FilteredJetContainer           = BUSTopOverlap.OutputJetContainer
BUSTopElectronAnalysis.FilterRejectsElectronContainer = BUSTopElectronFilter.RejectedOutputContainer

BUSTopElectronAnalysis.PreselectedElectronContainer   = BUSTopPreselection.OutputElectronContainer
BUSTopElectronAnalysis.PreselectedBJetContainer       = BUSTopPreselection.OutputBJetContainer
BUSTopElectronAnalysis.PreselectedLJetContainer       = BUSTopPreselection.OutputLightJetContainer
BUSTopElectronAnalysis.PreselectedMuonContainer       = BUSTopPreselection.OutputMuonContainer

if DoTruth:
	BUSTopElectronAnalysis.TruthAvailable     = 1
else:
	BUSTopElectronAnalysis.TruthAvailable     = 0

BUSTopElectronAnalysis.TruthMatchDeltaR   = 0.2

BUSTopElectronAnalysis.DoTrigger = DoTrigger
