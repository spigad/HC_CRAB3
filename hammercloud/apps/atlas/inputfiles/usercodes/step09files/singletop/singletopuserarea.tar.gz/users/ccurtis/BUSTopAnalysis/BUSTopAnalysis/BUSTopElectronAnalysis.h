#ifndef BUSTOP_ELECTRON_ANALYSIS_H
#define BUSTOP_ELECTRON_ANALYSIS_H

#include "GaudiKernel/Algorithm.h"

#include "CLHEP/Units/SystemOfUnits.h"

#include "StoreGate/StoreGateSvc.h"

#include "GaudiKernel/ToolHandle.h"
#include "TrigDecision/TrigDecisionTool.h"

#include <stdint.h>
#include <string>

class ElectronContainer;
class Electron;
class JetCollection;
class TruthParticleContainer;
class IAnalysisTools;
class IDecayVector;
class ITruthMatch;
class IEventTool;
class IEventTagTool;
class IBUSTopHistogrammer;
class ElectronHistograms;
class MuonHistograms;
class ResolutionHistograms;
class TH1F;
class TH2F;

namespace Analysis{
  class MuonContainer;
  class Muon;
}

class BUSTopElectronAnalysis : public Algorithm {

 public:

   BUSTopElectronAnalysis(const std::string& name, ISvcLocator* pSvcLocator);
   ~BUSTopElectronAnalysis();

   StatusCode initialize();
   StatusCode finalize();
   StatusCode execute();

 private:

   StoreGateSvc* m_storeGate;
   ITHistSvc *m_thistSvc;
   IAnalysisTools *m_analysisTools;
   IDecayVector *m_truthVector;
   ITruthMatch *m_truthMatchTool;
   IEventTool *m_eventTool;
   IEventTagTool *m_tagTool;
   IBUSTopHistogrammer* m_histogrammer;
   ToolHandle<TrigDec::TrigDecisionTool> m_trigDec;

   std::string m_inputElectronContainerName;
   std::string m_selectedElectronContainerName;

   std::string m_filteredElectronContainerName;
   std::string m_filteredJetContainerName;
   std::string m_filterRejectsContainerName;
   std::string m_preselectedElectronContainerName;
   std::string m_preselectedLJetContainerName;
   std::string m_preselectedBJetContainerName;
   std::string m_preselectedMuonContainerName;

   bool m_truthAvailable;
   double m_truthMatchDeltaR;
   double m_eventWeight;
   bool m_doTrigger;

   ElectronHistograms* h_full_elec;

   ElectronHistograms* h_filtered_elec;
   ElectronHistograms* h_matched_filter_rejects_elec;
   ResolutionHistograms* h_matched_filter_rejects_elec_res;

   ElectronHistograms* h_triggered_eprim;
   ElectronHistograms* h_selected_e;

   ElectronHistograms* h_epre_efull;
   ElectronHistograms* h_epre_eprim;
   ElectronHistograms* h_epre_esec;
   MuonHistograms* h_epre_musec;

   ElectronHistograms* h_matched_preselected_elec;
   ResolutionHistograms* h_matched_preselected_elec_res;

   TH1F* h_trigger_pt30;
   TH1F* h_matched_preselected_elec_index;
   TH1F* h_filtered_eJet_deltaR;
   TH1F* h_preselected_eJet_deltaR;

   TH1F* h_filt_trig_elec;
   TH1F* h_matched_selected_elec_index;

   const ElectronContainer* elecTES;
   const ElectronContainer* c_selectedElectrons;
   const ElectronContainer* c_filtered;
   const ElectronContainer* c_filter_rejects;
   const ElectronContainer* c_preselected;  

   const JetCollection* c_filtered_jets;  
   const JetCollection* c_preselected_ljets;  
   const JetCollection* c_preselected_bjets;  

   const Analysis::MuonContainer* c_preselected_muons;

   const TruthParticleContainer* c_elecTruth;

   virtual void registerHistograms();

   virtual void getEventWeight();
   virtual void getStoregateContainers();
   virtual void clearParticleContainers();

   virtual void plotElectrons();

   virtual void filterAnalysis();
   virtual void preselectionAnalysis();
   virtual void selectionAnalysis();
   virtual void triggerAnalysis();

   virtual void eJetIsolation();
   virtual void filteredEJetIsolation();
   virtual void preselectedEJetIsolation();
};

#endif // BUSTOP_ELECTRON_ANALYSIS_H



