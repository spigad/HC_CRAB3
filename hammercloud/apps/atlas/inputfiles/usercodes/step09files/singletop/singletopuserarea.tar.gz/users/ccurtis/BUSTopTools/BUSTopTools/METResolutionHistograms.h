#ifndef MET_RESOLUTION_HISTOGRAMS_H
#define MET_RESOLUTION_HISTOGRAMS_H

#include "GaudiKernel/AlgTool.h"
#include "GaudiKernel/MsgStream.h"
#include "GaudiKernel/AlgFactory.h"
#include "StoreGate/DataHandle.h"
#include "AIDA/IHistogram1D.h"
#include "AIDA/IHistogram2D.h"

#include <string>

class MissingET;
class IBUSTopHistogrammer;
class TruthParticle;
class TH1F;

class METResolutionHistograms{
   public:
     TH1F* phi;
     TH1F* etx;
     TH1F* ety;
     TH1F* et;

     METResolutionHistograms(IBUSTopHistogrammer* parent, std::string algName, std::string dirName, std::string hname);
     virtual ~METResolutionHistograms(){};

     template <class PARTICLE> void plot(PARTICLE* p, const MissingET* q, double w);
};

#include "BUSTopTools/METResolutionHistograms.icc"

#endif
