from BUSTopReconstruction.BUSTopReconstructionConf import BUSTopNeutrinoReconstruction

###############################################################################
#  Reconstructed Neutrinos based on output from Preselection algorithm        #
###############################################################################
BUSTopNuRecon_Full = BUSTopNeutrinoReconstruction( "BUSTopNuRecon_Full" )
BUSTopNuRecon_Full.OutputLevel = WARNING

BUSTopNuRecon_Full.InputElectronContainer   = BUSTopPreselection.InputElectronContainer
BUSTopNuRecon_Full.InputMuonContainer       = BUSTopPreselection.InputMuonContainer
BUSTopNuRecon_Full.InputMETContainer        = BUSTopJES.METOutputContainer

BUSTopNuRecon_Full.FilterTags               = [TRIGGERED]
BUSTopNuRecon_Full.ExclusiveNeutrino        = False
BUSTopNuRecon_Full.OutputNeutrinoContainer  = "FullNeutrinos"

###############################################################################
#  Reconstructed Neutrinos based on output from Preselection algorithm        #
###############################################################################
BUSTopNuRecon_Preselection = BUSTopNeutrinoReconstruction( "BUSTopNuRecon_Preselection" )
BUSTopNuRecon_Preselection.OutputLevel = WARNING

BUSTopNuRecon_Preselection.InputElectronContainer   = BUSTopPreselection.OutputElectronContainer
BUSTopNuRecon_Preselection.InputMuonContainer       = BUSTopPreselection.OutputMuonContainer
BUSTopNuRecon_Preselection.InputMETContainer        = BUSTopPreselection.OutputMETContainer

BUSTopNuRecon_Preselection.FilterTags               = [PRESELECTION]
BUSTopNuRecon_Preselection.ExclusiveNeutrino        = False

BUSTopNuRecon_Preselection.OutputNeutrinoContainer  = "PreselectionNeutrinos"

###############################################################################
#  Reconstructed Neutrinos based on output from Preselection algorithm        #
###############################################################################
BUSTopNuRecon_CSCSelection = BUSTopNeutrinoReconstruction( "BUSTopNuRecon_CSCSelection" )
BUSTopNuRecon_CSCSelection.OutputLevel = WARNING

BUSTopNuRecon_CSCSelection.InputElectronContainer   = BUSTopCSCSelection.OutputElectronContainer
BUSTopNuRecon_CSCSelection.InputMuonContainer       = BUSTopCSCSelection.OutputMuonContainer
BUSTopNuRecon_CSCSelection.InputMETContainer        = BUSTopPreselection.OutputMETContainer

BUSTopNuRecon_CSCSelection.FilterTags               = [CSCSELECTION]
BUSTopNuRecon_CSCSelection.ExclusiveNeutrino        = False

BUSTopNuRecon_CSCSelection.OutputNeutrinoContainer  = "CSCSelectionNeutrinos"

###############################################################################
#  Reconstructed Neutrinos based on output from Preselection algorithm        #
###############################################################################
if DoSelection:
	BUSTopNuRecon_Selection = BUSTopNeutrinoReconstruction( "BUSTopNuRecon_Selection" )
	BUSTopNuRecon_Selection.OutputLevel = WARNING

	BUSTopNuRecon_Selection.InputElectronContainer   = BUSTopSelection.OutputElectronContainer
	BUSTopNuRecon_Selection.InputMuonContainer       = BUSTopSelection.OutputMuonContainer
	BUSTopNuRecon_Selection.InputMETContainer        = BUSTopJES.METOutputContainer

	BUSTopNuRecon_Selection.FilterTags               = [LEPTON_SELECTION]
	BUSTopNuRecon_Selection.ExclusiveNeutrino        = True
	BUSTopNuRecon_Selection.OutputNeutrinoContainer  = "SelectedNeutrinos"

###############################################################################
#  Append Algorithms to main Sequencer                                        #
###############################################################################

Sequencer += BUSTopNuRecon_Full
Sequencer += BUSTopNuRecon_Preselection
Sequencer += BUSTopNuRecon_CSCSelection

if DoSelection:
	Sequencer += BUSTopNuRecon_Selection

