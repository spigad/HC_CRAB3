#include "GaudiKernel/IToolSvc.h"
#include "GaudiKernel/ITHistSvc.h"

#include "TH1.h"
#include "TH2.h"

#include "DataModel/DataVector.h"
#include "ParticleEvent/ParticleBaseContainer.h"
#include "egammaEvent/ElectronContainer.h"
#include "egammaEvent/Electron.h"
#include "egammaEvent/egammaParamDefs.h"
#include "egammaEvent/EMShower.h"
#include "muonEvent/MuonContainer.h"
#include "muonEvent/MuonParamDefs.h"

#include "JetEvent/JetCollection.h"

#include "MissingETEvent/MissingET.h"
#include "MissingETEvent/MissingEtCalo.h"
#include "MissingETEvent/MissingEtTruth.h"

#include "AnalysisTools/IAnalysisTools.h"
#include "AnalysisUtils/AnalysisCombination.h"
#include "AnalysisUtils/AnalysisMisc.h"
#include "AnalysisUtils/IParticleFilter.h"

#include "BUSTopTools/BUSTopHistogrammer.h"
#include "BUSTopTools/IBUSTopHistogrammer.h"
#include "BUSTopTools/EventTool.h"
#include "BUSTopTools/EventTagTool.h"

#include "BUSTopAnalysis/BUSTopCSCSelection.h"

#include <stdint.h>
#include <algorithm>
#include <math.h>
#include <functional>
#include <iostream>
#include <string>
#include <sstream>
#include <stdint.h>
#include <vector>

//////////////////////////////////////////////////////////////////////////////////////
/// Constructor

BUSTopCSCSelection::BUSTopCSCSelection(const std::string& name,
  ISvcLocator* pSvcLocator) : Algorithm(name, pSvcLocator)
{
  /// switches to control the analysis through job options :: these are the default
  /// to changed in the job options

  declareProperty("InputElectronContainer", m_electronContainerName); 
  declareProperty("InputBJetContainer", m_bJetContainerName); 
  declareProperty("InputLightJetContainer", m_lightJetContainerName); 
  declareProperty("InputMuonContainer", m_muonContainerName); 
  declareProperty("InputMETContainer", m_metContainerName); 

  declareProperty("OutputElectronContainer", m_selectedElectronContainerName); 
  declareProperty("OutputMuonContainer", m_selectedMuonContainerName); 
  declareProperty("OutputBJetContainer", m_selectedBJetContainerName); 
  declareProperty("OutputLightJetContainer", m_selectedLightJetContainerName); 

  declareProperty("TruthAvailable", m_truthAvailable); 
}


/////////////////////////////////////////////////////////////////////////////////////
/// Destructor - check up memory allocation
/// delete any memory allocation on the heap

BUSTopCSCSelection::~BUSTopCSCSelection() {
}

////////////////////////////////////////////////////////////////////////////////////
/// Initialize
/// initialize StoreGate
/// get a handle on the analysis tools
/// book histograms

StatusCode BUSTopCSCSelection::initialize() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO
       << "Initializing BUSTopCSCSelection"
       << endreq;

  StatusCode sc;
  
  sc = service("StoreGateSvc", m_storeGate);
  if(sc.isFailure()){
    mLog << MSG::ERROR 
         << "Unable to retrieve pointer to StoreGateSvc"
	 << endreq;
    return sc;
  }
  
  sc = service("THistSvc", m_thistSvc);
  if(sc.isFailure()){
    mLog << MSG::ERROR 
         << "Unable to retrieve pointer to THistSvc"
	 << endreq;
    return sc;
  }

  IToolSvc * toolSvc;
  service("ToolSvc", toolSvc);

  IAlgTool *tmp_eventTool;
  toolSvc->retrieveTool("EventTool", tmp_eventTool);
  m_eventTool = dynamic_cast<IEventTool *>(tmp_eventTool);

  IAlgTool *tmp_tagTool;
  toolSvc->retrieveTool("EventTagTool", tmp_tagTool);
  m_tagTool = dynamic_cast<IEventTagTool *>(tmp_tagTool);

  IAlgTool *tmp_histogramTool;
  toolSvc->retrieveTool("BUSTopHistogrammer", tmp_histogramTool);
  m_histogrammer = dynamic_cast<IBUSTopHistogrammer *>(tmp_histogramTool);

  registerHistograms();
  
  return StatusCode::SUCCESS;
}

void BUSTopCSCSelection::registerHistograms(){
  std::stringstream fName, hName;
  std::string title;

  fName.str("");
  hName.str("");
  hName << "csc_full_result";
  fName << "/AANT/CSC/" << hName.str();
  title = "CSC Result";
  h_full_result = new TH1F(hName.str().c_str(), title.c_str(), 3, 0, 3);
  m_thistSvc->regHist(fName.str().c_str(), h_full_result);

  fName.str("");
  hName.str("");
  hName << "csc_passed";
  fName << "/AANT/CSC/" << hName.str();
  title = "Number Passed";
  h_passed = new TH1F(hName.str().c_str(), title.c_str(), 1, 0, 1);
  m_thistSvc->regHist(fName.str().c_str(), h_passed);

}

StatusCode BUSTopCSCSelection::finalize() {
  MsgStream mLog( messageService(), name() );

  //reformat histograms....

  return StatusCode::SUCCESS;
}

//////////////////////////////////////////////////////////////////////////////////
/// Execute - called by the event loop on event by event

StatusCode BUSTopCSCSelection::execute() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << "execute()" << endreq;

  getEventWeight();
  getStoregateContainers();
  createTemporaryContainers();
  resetFlags();

  h_full_result->Fill(0.0, m_eventWeight);
  
  if(m_tagTool->tagged(IEventTagTool::PRESELECTION)){
    m_bjetPassed = cutBJets();
    m_ljetPassed = cutLJets();

    if(m_bjetPassed == true){
      h_full_result->Fill(1.0, m_eventWeight);
      if(m_ljetPassed == true){
        h_full_result->Fill(2.0, m_eventWeight);
      }
    }
  }
  
  registerSelected();
  tagEvent();

  destroyTemporaryContainers();

  mLog << MSG::DEBUG << "Done" << endreq;
  
  return StatusCode::SUCCESS;
}

void BUSTopCSCSelection::getStoregateContainers(){
  MsgStream mLog( messageService(), name() );

  metTES = 0;
  m_storeGate->retrieve(metTES, m_metContainerName);
  if(metTES == 0){
    mLog << MSG::ERROR << "Could not retrieve MET Container from Storegate" << endreq;
  }

  elecTES = 0;
  m_storeGate->retrieve(elecTES, m_electronContainerName);
  if(elecTES == 0){
    mLog << MSG::ERROR << "Could not retrieve Electron Container from Storegate" << endreq;
  }

  bjetTES = 0;
  m_storeGate->retrieve(bjetTES, m_bJetContainerName);
  if(bjetTES == 0){
    mLog << MSG::ERROR << "Could not retrieve BJet Container from Storegate" << endreq;
  }

  ljetTES = 0;
  m_storeGate->retrieve(ljetTES, m_lightJetContainerName);
  if(ljetTES == 0){
    mLog << MSG::ERROR << "Could not retrieve LightJet Container from Storegate" << endreq;
  }

  muonTES = 0;
  m_storeGate->retrieve(muonTES, m_muonContainerName);
  if(muonTES == 0){
    mLog << MSG::ERROR << "Could not retrieve Muon Container from Storegate" << endreq;
  }
}

bool BUSTopCSCSelection::cutBJets(){
  if(bjetTES->size() > 0 && bjetTES->at(0)->pt() > 50*GeV){
    return true;
  }else{
    return false;
  }
}

bool BUSTopCSCSelection::cutLJets(){
  if(ljetTES->size() > 0 && fabs(ljetTES->at(0)->eta()) > 2.5){
    return true;
  }else{
    return false;
  }
}

void BUSTopCSCSelection::createTemporaryContainers(){
  c_selectedBJets = new JetCollection(SG::VIEW_ELEMENTS);
  c_selectedLightJets = new JetCollection(SG::VIEW_ELEMENTS);
}

void BUSTopCSCSelection::registerSelected(){
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "registerSelected()" << endreq;

  if(m_bjetPassed == true && m_ljetPassed == true){
    h_passed->Fill(0.0, m_eventWeight);
    //registerSelected(elecTES, m_selectedElectronContainerName);
    //registerSelected(muonTES, m_selectedMuonContainerName);
    //registerSelected(bjetTES, m_selectedBJetContainerName);
    //registerSelected(ljetTES, m_selectedLightJetContainerName);
  }else{
    //ElectronContainer* elecTmp = new ElectronContainer(SG::VIEW_ELEMENTS);
    //Analysis::MuonContainer* muonTmp = new Analysis::MuonContainer(SG::VIEW_ELEMENTS);
    //JetCollection* j1Tmp = new JetCollection(SG::VIEW_ELEMENTS);
    //JetCollection* j2Tmp = new JetCollection(SG::VIEW_ELEMENTS);

    //registerSelected(elecTmp, m_selectedElectronContainerName);
    //registerSelected(muonTmp, m_selectedMuonContainerName);
    //registerSelected(j1Tmp, m_selectedBJetContainerName);
    //registerSelected(j2Tmp, m_selectedLightJetContainerName);
  }
}

void BUSTopCSCSelection::registerSelected(const ElectronContainer* c, std::string n){
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "registerSelected(...)" << endreq;

  ElectronContainer* tmp = new ElectronContainer();

  m_storeGate->record(tmp, n);

  ElectronContainer::const_iterator elecIter = c->begin();
  ElectronContainer::const_iterator elecIterEnd = c->end();

  while(elecIter < elecIterEnd){
    tmp->push_back(new Analysis::Electron(**elecIter));
    elecIter++;
  }

  m_storeGate->setConst(tmp);
}

void BUSTopCSCSelection::registerSelected(const Analysis::MuonContainer* c, std::string n){
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "registerSelected(...)" << endreq;

  Analysis::MuonContainer* tmp = new Analysis::MuonContainer();

  m_storeGate->record(tmp, n);

  Analysis::MuonContainer::const_iterator muonIter = c->begin();
  Analysis::MuonContainer::const_iterator muonIterEnd = c->end();

  while(muonIter < muonIterEnd){
    tmp->push_back(new Analysis::Muon(**muonIter));
    muonIter++;
  }

  m_storeGate->setConst(tmp);
}

void BUSTopCSCSelection::registerSelected(const JetCollection* c, std::string n){
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "registerSelected(...)" << endreq;

  JetCollection* tmp = new JetCollection(SG::VIEW_ELEMENTS);

  m_storeGate->record(tmp, n);

  JetCollection::const_iterator jIter = c->begin();
  JetCollection::const_iterator jIterEnd = c->end();

  while(jIter < jIterEnd){
    tmp->push_back(new Jet(**jIter));
    jIter++;
  }

  m_storeGate->setConst(tmp);
}

void BUSTopCSCSelection::destroyTemporaryContainers(){
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "destroyTemporaryContainers(...)" << endreq;

  delete c_selectedBJets;
  //c_selectedBJets = 0;

  delete c_selectedLightJets;
  //c_selectedLightJets = 0;

}

void BUSTopCSCSelection::resetFlags(){
  m_bjetPassed = false;
  m_ljetPassed = false;
}

void BUSTopCSCSelection::getEventWeight(){
  if(m_tagTool->tagged(IEventTagTool::IS_ATLFAST) == false && m_tagTool->tagged(IEventTagTool::IS_MC) == true){
    m_eventWeight = m_eventTool->getEventWeight();
  }else{
    m_eventWeight = 1.0;
  }
}

void BUSTopCSCSelection::tagEvent(){
  MsgStream mLog( messageService(), name() );

  if(m_bjetPassed == true && m_ljetPassed == true){
    mLog << MSG::DEBUG << "Passed CSC Selection" << endreq;
    m_tagTool->tag(IEventTagTool::CSCSELECTION);
    if(m_tagTool->tagged(IEventTagTool::ELECTRON_PRESELECTION) == true){
      mLog << MSG::DEBUG << "Electron" << endreq;
      m_tagTool->tag(IEventTagTool::ELECTRON_CSCSELECTION);
    }else if(m_tagTool->tagged(IEventTagTool::MUON_PRESELECTION) == true){
      mLog << MSG::DEBUG << "Muon" << endreq;
      m_tagTool->tag(IEventTagTool::MUON_CSCSELECTION);
    }
  }
}
