#include "GaudiKernel/MsgStream.h"
#include "GaudiKernel/AlgFactory.h"
#include "GaudiKernel/IToolSvc.h"
#include "GaudiKernel/ITHistSvc.h"
#include "StoreGate/StoreGateSvc.h"
#include "StoreGate/DataHandle.h"

#include "TH1.h"
#include "TH2.h"

#include "McParticleEvent/TruthParticle.h"
#include "McParticleEvent/TruthParticleContainer.h"
#include "ParticleEvent/Neutrino.h"

#include "AnalysisTools/IAnalysisTools.h"

#include "SpecialUtils/NeutrinoUtils.h"
#include "ParticleEvent/NeutrinoContainer.h"
#include "ParticleEvent/Neutrino.h"

#include <iostream>
#include <iomanip>
#include <stdint.h>
#include <algorithm>
#include <math.h>
#include <functional>

#include <TRandom.h>

#include "AnalysisTools/IAnalysisTools.h"
#include "AnalysisUtils/AnalysisCombination.h"
#include "AnalysisUtils/AnalysisMisc.h"

#include "BUSTopTools/IDecayVector.h"
#include "BUSTopTools/EventTool.h"
#include "BUSTopTools/EventTagTool.h"
#include "BUSTopTools/IBUSTopHistogrammer.h"
#include "BUSTopTools/INuSolutionTool.h"
#include "BUSTopTools/TruthHistograms.h"

#include "BUSTopPreselection/BUSTopTruth.h"

//////////////////////////////////////////////////////////////////////////////////////
/// Constructor

BUSTopTruth::BUSTopTruth(const std::string& name,
  ISvcLocator* pSvcLocator) : Algorithm(name, pSvcLocator)
{
  /// switches to control the analysis through job options :: these are the default
  /// to changed in the job options

  declareProperty("MCTruthContainer", m_mcContainerName="SpclMC");
  declareProperty("PrintTable", m_printTable);
}


/////////////////////////////////////////////////////////////////////////////////////
/// Destructor - check up memory allocation
/// delete any memory allocation on the heap

BUSTopTruth::~BUSTopTruth() {
/*  delete h_top;
  delete h_b1;
  delete h_w;
  delete h_b2;
  delete h_e;
  delete h_enu;
  delete h_mu;
  delete h_munu;
  delete h_tau;
  delete h_taunu;*/
}

////////////////////////////////////////////////////////////////////////////////////
/// Initialize
/// initialize StoreGate
/// get a handle on the analysis tools
/// book histograms

StatusCode BUSTopTruth::initialize() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO
       << "Initializing BUSTopTruth"
       << endreq;

  StatusCode sc;
  
  sc = service("StoreGateSvc", m_storeGate);
  if(sc.isFailure()){
    mLog << MSG::ERROR 
         << "Unable to retrieve pointer to StoreGateSvc"
	 << endreq;
    return sc;
  }
  
  sc = service("THistSvc", m_thistSvc);
  if(sc.isFailure()){
    mLog << MSG::ERROR 
         << "Unable to retrieve pointer to THistSvc"
	 << endreq;
    return sc;
  }

  sc = service("ToolSvc", m_toolSvc);
  if(sc.isFailure()){
     mLog << MSG::ERROR
          << "Unable to retrieve pointer to ToolSvc"
          << endreq;
     return sc;    
  }

  IAlgTool *tmp_eventTool;
  m_toolSvc->retrieveTool("EventTool", tmp_eventTool);
  m_eventTool = dynamic_cast<IEventTool *>(tmp_eventTool);

  IAlgTool *tmp_tagTool;
  m_toolSvc->retrieveTool("EventTagTool", tmp_tagTool);
  m_tagTool = dynamic_cast<IEventTagTool *>(tmp_tagTool);

  IAlgTool *tmp_decayTool;
  m_toolSvc->retrieveTool("DecayVector", tmp_decayTool);
  m_truthVector = dynamic_cast<IDecayVector *>(tmp_decayTool);

  IAlgTool *tmp_histogramTool;
  m_toolSvc->retrieveTool("BUSTopHistogrammer", tmp_histogramTool);
  m_histogrammer = dynamic_cast<IBUSTopHistogrammer *>(tmp_histogramTool);

  IAlgTool *tmp_nuSolTool;
  m_toolSvc->retrieveTool("NuSolutionTool", tmp_nuSolTool);
  m_nuSolTool = dynamic_cast<INuSolutionTool *>(tmp_nuSolTool);
 
  registerHistograms();

  return StatusCode::SUCCESS;
}

void BUSTopTruth::registerHistograms(){
  h_top = new TruthHistograms(m_histogrammer, "Truth", "top", "tr_top");
  h_b1 = new TruthHistograms(m_histogrammer, "Truth", "b1", "tr_b1");
  h_b3 = new TruthHistograms(m_histogrammer, "Truth", "b3", "tr_b3");

  h_lj = new TruthHistograms(m_histogrammer, "Truth", "lj", "tr_lj");

  h_w1 = new TruthHistograms(m_histogrammer, "Truth", "w1", "tr_w1");

  h_e = new TruthHistograms(m_histogrammer, "Truth", "e", "tr_e");
  h_enu = new TruthHistograms(m_histogrammer, "Truth", "enu", "tr_enu");

  h_mu = new TruthHistograms(m_histogrammer, "Truth", "mu", "tr_mu");
  h_munu = new TruthHistograms(m_histogrammer, "Truth", "munu", "tr_munu");

  h_tau = new TruthHistograms(m_histogrammer, "Truth", "tau", "tr_tau");
  h_taunu = new TruthHistograms(m_histogrammer, "Truth", "taunu", "tr_taunu");

  std::stringstream fname, hname, title;
  std::string hN = "";

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "h_t_mother";
  fname << "/AANT/"<< "Truth" <<"/" << "Family" << "/" << hname.str();
  title << "Top Mother";
  m_histogrammer->registerHistogram(h_t_mother, fname.str(), hname.str(), title.str(), "Pdg ID", 50, -25.5, 24.5);

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "h_t_mother_child";
  fname << "/AANT/"<< "Truth" <<"/" << "Family" << "/" << hname.str();
  title << "Top Mother Children";
  m_histogrammer->registerHistogram(h_t_mother_child, fname.str(), hname.str(), title.str(), "Pdg ID", 50, -25.5, 24.);

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "h_t_mother_child_n";
  fname << "/AANT/"<< "Truth" <<"/" << "Family" << "/" << hname.str();
  title << "Top Mother Children";
  m_histogrammer->registerHistogram(h_t_mother_child_n, fname.str(), hname.str(), title.str(), "N", 10, -0.5, 9.5);
}

StatusCode BUSTopTruth::finalize() {
  MsgStream mLog( messageService(), name() );
  
  return StatusCode::SUCCESS;

}

//////////////////////////////////////////////////////////////////////////////////
/// Execute - called by the event loop on event by event

StatusCode BUSTopTruth::execute() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << "execute()" << endreq;

  getEventWeight();
  getContainers();
  publishContainers();
  fillHistograms();

  tagEvent();

  if(m_printTable == true){
    printTruthVector();
  }

  clearContainers();

  return StatusCode::SUCCESS;
}

void BUSTopTruth::getContainers(){
  MsgStream mLog( messageService(), name() );

  m_storeGate->retrieve(mcTES, m_mcContainerName);

  m_truthVector->fill(mcTES, PDG::t, true);

  c_top = m_truthVector->filter(PDG::t, false);
  c_w1 = m_truthVector->filter(PDG::W_minus, false);
  c_e = m_truthVector->filter(PDG::e_minus, false);
  c_enu = m_truthVector->filter(PDG::nu_e, false);
  c_mu = m_truthVector->filter(PDG::mu_minus, false);
  c_munu = m_truthVector->filter(PDG::nu_mu, false);
  c_tau = m_truthVector->filter(PDG::tau_minus, false);
  c_taunu = m_truthVector->filter(PDG::nu_tau, false);

  //Need to add b2, b3, w2 and light jet
  //Do we want them to be in separate containers though?
  c_lj = new TruthParticleContainer(SG::VIEW_ELEMENTS);
  c_j = new TruthParticleContainer(SG::VIEW_ELEMENTS);
  c_b = new TruthParticleContainer(SG::VIEW_ELEMENTS);
  c_b1 = new TruthParticleContainer(SG::VIEW_ELEMENTS);
  c_b3 = new TruthParticleContainer(SG::VIEW_ELEMENTS);

  //get the top quark, then its parents, then its parents siblings.

  if(c_top->size() > 0){

    TruthParticle* topQuark = c_top->at(0);

    const TruthParticle* mother = topQuark->mother(0);

    int motherPdgId = mother->pdgId();
    h_t_mother->Fill(motherPdgId, m_eventWeight);

    if(abs(motherPdgId) == PDG::g){
      h_t_mother_child_n->Fill(mother->nDecay(), m_eventWeight);
    } 
      
    for(unsigned int j = 0; j < mother->nDecay(); j++){
      int pdgId = mother->child(j)->pdgId();

      if(abs(pdgId) == PDG::b){
        c_b3->push_back(const_cast<TruthParticle*>(mother->child(j)));
        c_b->push_back(const_cast<TruthParticle*>(mother->child(j)));
        c_j->push_back(const_cast<TruthParticle*>(mother->child(j)));
      }else if(abs(pdgId) < PDG::b && abs(pdgId) > 0){
        c_lj->push_back(const_cast<TruthParticle*>(mother->child(j)));
        c_j->push_back(const_cast<TruthParticle*>(mother->child(j)));
      } 

      if(abs(motherPdgId) == PDG::g){
        h_t_mother_child->Fill(pdgId, m_eventWeight);
      } 
    }
  }

  TruthParticleContainer* tmp_b = m_truthVector->filter(PDG::b, false);
  TruthParticleContainer::const_iterator bIter = tmp_b->begin();
  TruthParticleContainer::const_iterator bIterEnd = tmp_b->end();

  while(bIter < bIterEnd){
    int motherPdgId = abs((*bIter)->mother(0)->pdgId());

    if(motherPdgId == PDG::t){
      c_b1->push_back(const_cast<TruthParticle*>(*bIter));
      c_b->push_back(const_cast<TruthParticle*>(*bIter));    
      c_j->push_back(const_cast<TruthParticle*>(*bIter));    
    }

    mLog << MSG::DEBUG << "getContainers(): motherPdgId = " << motherPdgId << endreq;

    bIter++;
  }

  delete tmp_b;
  
  mLog << MSG::DEBUG << "getContainers() c_b->size() = " << c_b->size() << endreq;
  mLog << MSG::DEBUG << "getContainers() c_b1->size() = " << c_b1->size() << endreq;
  mLog << MSG::DEBUG << "getContainers() c_b3->size() = " << c_b3->size() << endreq;
  mLog << MSG::DEBUG << "getContainers() c_lj->size() = " << c_lj->size() << endreq;
  mLog << MSG::DEBUG << "getContainers() c_j->size() = " << c_j->size() << endreq;
  mLog << MSG::DEBUG << "getContainers() c_e->size() = " << c_e->size() << endreq;
}

void BUSTopTruth::publishContainers(){
  publishContainer(c_top, "BUSTopTruth_t");
  publishContainer(c_b, "BUSTopTruth_b");
  publishContainer(c_b1, "BUSTopTruth_b1");
  publishContainer(c_b3, "BUSTopTruth_b3");
  publishContainer(c_lj, "BUSTopTruth_lj");
  publishContainer(c_j, "BUSTopTruth_j");
  publishContainer(c_w1, "BUSTopTruth_w1");
  publishContainer(c_e, "BUSTopTruth_e");
  publishContainer(c_enu, "BUSTopTruth_enu");
  publishContainer(c_mu, "BUSTopTruth_mu");
  publishContainer(c_munu, "BUSTopTruth_munu");
  publishContainer(c_tau, "BUSTopTruth_tau");
  publishContainer(c_taunu, "BUSTopTruth_taunu");
}

void BUSTopTruth::publishContainer(const TruthParticleContainer* c, std::string name){
  m_storeGate->record(c, name);
  m_storeGate->setConst(c);
}

void BUSTopTruth::clearContainers(){
}

void BUSTopTruth::fillHistograms(){
  h_top->plotContainer(c_top, m_eventWeight);

  h_b1->plotContainer(c_b1, m_eventWeight);
  h_b3->plotContainer(c_b3, m_eventWeight);

  h_w1->plotContainer(c_w1, m_eventWeight);

  h_lj->plotContainer(c_lj, m_eventWeight);

  h_e->plotContainer(c_e, m_eventWeight);
  h_enu->plotContainer(c_enu, m_eventWeight);
  h_mu->plotContainer(c_mu, m_eventWeight);
  h_munu->plotContainer(c_munu, m_eventWeight);
  h_tau->plotContainer(c_tau, m_eventWeight);
  h_taunu->plotContainer(c_taunu, m_eventWeight);
}

//This is only meant to be used over a couple of events!
void BUSTopTruth::printTruthVector(){
  MsgStream mLog( messageService(), name() );

  TruthParticleContainer* process = m_truthVector->getTruthVector();

  TruthParticleContainer::const_iterator mcIter = process->begin();
  TruthParticleContainer::const_iterator mcIterEnd = process->end();

  while(mcIter < mcIterEnd){
    std::vector<int> parents;

    for(unsigned int i = 0; i < (*mcIter)->nParents(); i++){
      parents.push_back((*mcIter)->mother(i)->barcode());
      parents.push_back((*mcIter)->mother(i)->pdgId());
    }

    std::vector<int> children;
    for(unsigned int i = 0; i < (*mcIter)->nDecay(); i++){
      children.push_back((*mcIter)->child(i)->barcode());
      children.push_back((*mcIter)->child(i)->pdgId());
    }
   
    for(int i = 0; i < 60; i++){
      mLog << MSG::INFO << "*";
    }
    mLog << MSG::INFO << endreq;
   
    mLog << MSG::INFO << std::setw(10) << (*mcIter)->barcode();
    mLog << MSG::INFO << std::setw(10) << (*mcIter)->pdgId();

    if(parents.size() > 1){
      mLog << MSG::INFO << std::setw(10) << parents.at(0);
      mLog << MSG::INFO << std::setw(10) << parents.at(1);
    }else{
      mLog << MSG::INFO << std::setw(10) << " ";
    }

    if(children.size() > 0){
      mLog << MSG::INFO << std::setw(10) << children.at(0);
      mLog << MSG::INFO << std::setw(10) << children.at(1);
    }else{
      mLog << MSG::INFO << std::setw(10) << " ";
    }

    unsigned int max_size = 0;
    if(children.size() > parents.size()){
      max_size = children.size();
    }else{
      max_size = parents.size();
    }

    mLog << MSG::INFO << endreq;    

    for(unsigned int i = 2; i < max_size; i+=2){

      mLog << MSG::INFO << std::setw(10) << " ";
      mLog << MSG::INFO << std::setw(10) << " ";

      if(parents.size() > i){
        mLog << MSG::INFO << std::setw(10) << parents.at(i);
        mLog << MSG::INFO << std::setw(10) << parents.at(i+1);
      }else{
        mLog << MSG::INFO << std::setw(10) << " ";
        mLog << MSG::INFO << std::setw(10) << " ";
      }

      if(children.size() > i){
        mLog << MSG::INFO << std::setw(10) << children.at(i);
        mLog << MSG::INFO << std::setw(10) << children.at(i+1);
      }else{
        mLog << MSG::INFO << std::setw(10) << " ";
        mLog << MSG::INFO << std::setw(10) << " ";
      }

      mLog << MSG::INFO << endreq;    

    }

    mLog << MSG::INFO << endreq;    

    mcIter++;
  }
}

void BUSTopTruth::getEventWeight(){
  if(m_tagTool->tagged(IEventTagTool::IS_ATLFAST) == false && m_tagTool->tagged(IEventTagTool::IS_MC) == true){
    m_eventWeight = m_eventTool->getEventWeight();
  }else{
    m_eventWeight = 1.0;
  }
}

void BUSTopTruth::tagEvent(){
  if(c_e->size() > 0){
    m_tagTool->tag(IEventTagTool::ELECTRON_TRUTH);
  }

  if(c_mu->size() > 0){
    m_tagTool->tag(IEventTagTool::MUON_TRUTH);
  }

  if(c_tau->size() > 0){
    m_tagTool->tag(IEventTagTool::TAU_TRUTH);
  }

}
