#include "GaudiKernel/IToolSvc.h"
#include "GaudiKernel/ITHistSvc.h"

#include "TH1.h"
#include "TH2.h"

#include "DataModel/DataVector.h"
#include "ParticleEvent/ParticleBaseContainer.h"
#include "McParticleEvent/TruthParticleContainer.h"
#include "egammaEvent/ElectronContainer.h"
#include "egammaEvent/Electron.h"
#include "egammaEvent/egammaParamDefs.h"
#include "egammaEvent/EMShower.h"
#include "muonEvent/MuonContainer.h"
#include "muonEvent/MuonParamDefs.h"

#include "JetEvent/JetCollection.h"

#include "MissingETEvent/MissingET.h"
#include "MissingETEvent/MissingEtCalo.h"
#include "MissingETEvent/MissingEtTruth.h"

#include "AnalysisTools/IAnalysisTools.h"
#include "AnalysisUtils/AnalysisCombination.h"
#include "AnalysisUtils/AnalysisMisc.h"
#include "AnalysisUtils/IParticleFilter.h"

#include "BUSTopTools/BUSTopHistogrammer.h"
#include "BUSTopTools/IBUSTopHistogrammer.h"
#include "BUSTopTools/EventTool.h"
#include "BUSTopTools/EventTagTool.h"

#include "BUSTopPreselection/BUSTopTriggerDecision.h"

#include <stdint.h>
#include <algorithm>
#include <math.h>
#include <functional>
#include <iostream>
#include <string>
#include <sstream>
#include <stdint.h>
#include <vector>

//////////////////////////////////////////////////////////////////////////////////////
/// Constructor

BUSTopTriggerDecision::BUSTopTriggerDecision(const std::string& name,
  ISvcLocator* pSvcLocator) : Algorithm(name, pSvcLocator), m_trigDec("TrigDec::TrigDecisionTool")
{
  /// switches to control the analysis through job options :: these are the default
  /// to changed in the job options

  declareProperty("InputElectronContainer", m_electronContainerName); 
  declareProperty("InputMuonContainer", m_muonContainerName); 

  declareProperty("TruthAvailable", m_truthAvailable); 
  declareProperty("RunTrigger", m_runTrigger); 
  declareProperty("PrintMenu", m_printMenu); 

  declareProperty("ElectronTriggerItems", m_electronTriggerItems);
  declareProperty("MuonTriggerItems", m_muonTriggerItems);

  declareProperty("ElectronPtCut", m_elecPtCut);
  declareProperty("MuonPtCut", m_muonPtCut);

  declareProperty("TrigDecisionTool", m_trigDec, "The tool to access TrigDecision");
}


/////////////////////////////////////////////////////////////////////////////////////
/// Destructor - check up memory allocation
/// delete any memory allocation on the heap

BUSTopTriggerDecision::~BUSTopTriggerDecision() {
}

////////////////////////////////////////////////////////////////////////////////////
/// Initialize
/// initialize StoreGate
/// get a handle on the analysis tools
/// book histograms

StatusCode BUSTopTriggerDecision::initialize() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO
       << "Initializing BUSTopTriggerDecision"
       << endreq;

  StatusCode sc;
  
  sc = service("StoreGateSvc", m_storeGate);
  if(sc.isFailure()){
    mLog << MSG::ERROR 
         << "Unable to retrieve pointer to StoreGateSvc"
	 << endreq;
    return sc;
  }
  
  sc = service("THistSvc", m_thistSvc);
  if(sc.isFailure()){
    mLog << MSG::ERROR 
         << "Unable to retrieve pointer to THistSvc"
	 << endreq;
    return sc;
  }

  IToolSvc * toolSvc;
  service("ToolSvc", toolSvc);

  IAlgTool *tmp_eventTool;
  toolSvc->retrieveTool("EventTool", tmp_eventTool);
  m_eventTool = dynamic_cast<IEventTool *>(tmp_eventTool);

  IAlgTool *tmp_tagTool;
  toolSvc->retrieveTool("EventTagTool", tmp_tagTool);
  m_tagTool = dynamic_cast<IEventTagTool *>(tmp_tagTool);

  IAlgTool *tmp_histogramTool;
  toolSvc->retrieveTool("BUSTopHistogrammer", tmp_histogramTool);
  m_histogrammer = dynamic_cast<IBUSTopHistogrammer *>(tmp_histogramTool);

  sc = m_trigDec.retrieve();
  if(sc.isFailure()){
    mLog << MSG::ERROR << "Could not retrieve TrigDecisionTool!" << endreq;
    return sc;
  }

  registerHistograms();
  
  return StatusCode::SUCCESS;
}

void BUSTopTriggerDecision::registerHistograms(){
  std::stringstream fName, hName;
  std::string title;

  fName.str("");
  hName.str("");
  hName << "td_number_passed";
  fName << "/AANT/TriggerDecision/" << hName.str();
  title = "Number Passed";
  h_number_passed = new TH1F(hName.str().c_str(), title.c_str(), 1, 0, 1);
  m_thistSvc->regHist(fName.str().c_str(), h_number_passed);

  int size = m_electronTriggerItems.size() + m_muonTriggerItems.size();

  fName.str("");
  hName.str("");
  hName << "td_trigger_passed";
  fName << "/AANT/TriggerDecision/" << hName.str();
  title = "Trigger Passed";
  h_trigger_passed = new TH1F(hName.str().c_str(), title.c_str(), (size+1), 0, (size+1));
  m_thistSvc->regHist(fName.str().c_str(), h_trigger_passed);
}

StatusCode BUSTopTriggerDecision::finalize() {
  MsgStream mLog( messageService(), name() );

  return StatusCode::SUCCESS;
}

//////////////////////////////////////////////////////////////////////////////////
/// Execute - called by the event loop on event by event

StatusCode BUSTopTriggerDecision::execute() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << "execute()" << endreq;

  getEventWeight();
  getStoregateContainers();

  bool result = true;
  if(m_runTrigger == true){
    result = passedTrigger();
    if(result == true){
      m_tagTool->tag(IEventTagTool::TRIGGERED);
    }
  }else{
    m_tagTool->tag(IEventTagTool::TRIGGERED);
    
    if(elecTES->size() > 0 && elecTES->at(0)->pt() > m_elecPtCut*GeV){
      m_tagTool->tag(IEventTagTool::TRIGGERED_ELECTRON);
    }

    if(muonTES->size() > 0 && muonTES->at(0)->pt() > m_muonPtCut*GeV){
      m_tagTool->tag(IEventTagTool::TRIGGERED_MUON);
    }
  }

  if(m_tagTool->tagged(IEventTagTool::TRIGGERED_ELECTRON)){
    mLog << MSG::DEBUG << "Triggered On Electron" << endreq;
  }

  if(m_tagTool->tagged(IEventTagTool::TRIGGERED_MUON)){
    mLog << MSG::DEBUG << "Triggered On Muon" << endreq;
  }

  if(m_printMenu == true){
    printTriggerMenu();
  }

  return StatusCode::SUCCESS;
}

bool BUSTopTriggerDecision::passedTrigger(){
  MsgStream mLog( messageService(), name() );
  
  bool result = false;

  for(unsigned int i = 0; i < m_electronTriggerItems.size(); i++){
    if(m_trigDec->isPassed(m_electronTriggerItems.at(i))){
      result = true;
      m_tagTool->tag(IEventTagTool::TRIGGERED_ELECTRON);
      h_trigger_passed->Fill((i+1), m_eventWeight);
    }  
  }

  for(unsigned int i = 0; i < m_muonTriggerItems.size(); i++){
    if(m_trigDec->isPassed(m_muonTriggerItems.at(i))){
      result = true;
      m_tagTool->tag(IEventTagTool::TRIGGERED_MUON);
      h_trigger_passed->Fill((i+m_electronTriggerItems.size()+1), m_eventWeight);
    }  
  }

  if(result == true){
    h_number_passed->Fill(0.0, m_eventWeight);
  }else{
    h_trigger_passed->Fill(0.0, m_eventWeight);
  }

  return result;
}

void BUSTopTriggerDecision::getStoregateContainers(){
  MsgStream mLog( messageService(), name() );

  elecTES = 0;
  m_storeGate->retrieve(elecTES, m_electronContainerName);
  if(elecTES == 0){
    mLog << MSG::ERROR << "Could not retrieve Electron Container from Storegate" << endreq;
  }

  muonTES = 0;
  m_storeGate->retrieve(muonTES, m_muonContainerName);
  if(muonTES == 0){
    mLog << MSG::ERROR << "Could not retrieve Muon Container from Storegate" << endreq;
  }

  if(m_truthAvailable == true){
  }
}

void BUSTopTriggerDecision::createTemporaryContainers(){
}

void BUSTopTriggerDecision::registerPassed(bool result){
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "registerPassed()" << endreq;
}

void BUSTopTriggerDecision::registerPassed(const ElectronContainer* c, std::string n){
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "registerPassed(...)" << endreq;

  m_storeGate->record(c, n);
  m_storeGate->setConst(c);
}

void BUSTopTriggerDecision::registerPassed(const Analysis::MuonContainer* c, std::string n){
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "registerPassed(...)" << endreq;

  m_storeGate->record(c, n);
  m_storeGate->setConst(c);
}

void BUSTopTriggerDecision::registerPassed(const JetCollection* c, std::string n){
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "registerPassed(...)" << endreq;

  m_storeGate->record(c, n);
  m_storeGate->setConst(c);
}

void BUSTopTriggerDecision::destroyTemporaryContainers(){
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "destroyTemporaryContainers(...)" << endreq;
}

void BUSTopTriggerDecision::getEventWeight(){
  if(m_tagTool->tagged(IEventTagTool::IS_ATLFAST) == false && m_tagTool->tagged(IEventTagTool::IS_MC) == true){
    m_eventWeight = m_eventTool->getEventWeight();
  }else{
    m_eventWeight = 1.0;
  }
}

void BUSTopTriggerDecision::printTriggerMenu(){
  MsgStream mLog( messageService(), name() );

  for(unsigned int i = 0; i < m_electronTriggerItems.size(); i++){
    std::string mychain = m_electronTriggerItems.at(i);
    const HLT::Chain* chain = m_trigDec->getHLTChain(mychain);

    if(0 == chain){
      mLog << MSG::INFO << "Chain " << mychain << " is not defined" << endreq;
    }else{
      mLog << MSG::INFO << "Chain " << mychain << ": " << *chain << " passed: " << chain->chainPassed() << endreq;
    }
  }

  for(unsigned int i = 0; i < m_muonTriggerItems.size(); i++){
    std::string mychain = m_muonTriggerItems.at(i);
    const HLT::Chain* chain = m_trigDec->getHLTChain(mychain);

    if(0 == chain){
      mLog << MSG::INFO << "Chain " << mychain << " is not defined" << endreq;
    }else{
      mLog << MSG::INFO << "Chain " << mychain << ": " << *chain << " passed: " << chain->chainPassed() << endreq;
    }
  }
}


