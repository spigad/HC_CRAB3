from BUSTopAnalysis.BUSTopAnalysisConf import BUSTopTAnalysis
Sequencer += BUSTopTAnalysis()
BUSTopTAnalysis.OutputLevel = WARNING

BUSTopTAnalysis.Top              = BUSTopTRecon_Full.OutputTops
BUSTopTAnalysis.PreselectedTop   = BUSTopTRecon_Preselection.OutputTops
BUSTopTAnalysis.CSCSelectedTop   = BUSTopTRecon_CSCSelection.OutputTops

if DoSelection:
	BUSTopTAnalysis.SelectedTop   = BUSTopTRecon_Selection.OutputTops

BUSTopTAnalysis.TruthAvailable    = DoTruth


