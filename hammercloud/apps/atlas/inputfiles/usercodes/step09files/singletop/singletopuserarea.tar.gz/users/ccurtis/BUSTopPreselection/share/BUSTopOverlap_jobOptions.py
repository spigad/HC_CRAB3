from BUSTopPreselection.BUSTopPreselectionConf import BUSTopOverlap
Sequencer += BUSTopOverlap()
BUSTopOverlap.OutputLevel = WARNING

BUSTopOverlap.InputMuonContainer                  = BUSTopMuonFilter.MuonOutputContainer
BUSTopOverlap.InputElectronContainer              = BUSTopElectronFilter.ElectronOutputContainer
BUSTopOverlap.InputJetContainer                   = RootJetContainer
BUSTopOverlap.OutputJetContainer                  = "FilteredJets"
BUSTopOverlap.OutputEJetContainer                 = "ElectronJets"
BUSTopOverlap.OutputMJetContainer                 = "MuonJets"

BUSTopOverlap.DeltaRCut                           = 0.1

if DoTruth:
	BUSTopOverlap.TruthAvailable              = 1
else:
	BUSTopOverlap.TruthAvailable              = 0
		
