#ifndef BUSTOP_SPIN_ANALYSIS_H
#define BUSTOP_SPIN_ANALYSIS_H

#include "GaudiKernel/Algorithm.h"

#include "CLHEP/Units/SystemOfUnits.h"

#include "StoreGate/StoreGateSvc.h"

#include "GaudiKernel/ToolHandle.h"

#include "BUSTopTools/IEventTagTool.h"

#include <stdint.h>
#include <string>

class ITHistSvc;
class TH1;
class TH1F;
class TH1D;
class TH2F;
class TFile;

class IAnalysisTools;
class TruthParticleContainer;
class CompositeParticleContainer;

namespace Analysis {
  class MuonContainer;
}

namespace CLHEP{
  class HepLorentzVector;
}

class JetCollection;
class ElectronContainer;
class NeutrinoContainer;
class MissingET;
class IEventTool;
class INuSolutionTool;
class IBUSTopHistogrammer;

class BUSTopSpinAnalysis : public Algorithm {

 public:

   BUSTopSpinAnalysis(const std::string& name, ISvcLocator* pSvcLocator);
   ~BUSTopSpinAnalysis();

   StatusCode initialize();
   StatusCode finalize();
   StatusCode execute();

   static double getSpectatorAngle(const CLHEP::HepLorentzVector&, const CLHEP::HepLorentzVector&, const CLHEP::HepLorentzVector&);
   static double getBeamAngle(const CLHEP::HepLorentzVector&, const CLHEP::HepLorentzVector&, const CLHEP::HepLorentzVector&);
  
 private:
   StoreGateSvc* m_storeGate;
   ITHistSvc*    m_histSvc;
   IEventTool*   m_eventTool;
   IEventTagTool*   m_tagTool;
   INuSolutionTool* m_nuSolTool;
   IBUSTopHistogrammer* m_histogrammer;

   std::string m_electronContainerName;
   std::string m_bJetContainerName;
   std::string m_lightJetContainerName;
   std::string m_muonContainerName;
   std::string m_neutrinoContainerName;
   std::string m_metContainerName;
   std::string m_topContainerName;

   double m_eventWeight;
   bool m_truthAvailable;

   BUSTopTags m_filterTags;

   virtual void getEventWeight();
   virtual void registerHistograms();
   virtual void registerTTrees();

   virtual void getStoregateContainers();
   virtual void createTemporaryContainers();
   virtual void registerSelected();
   virtual void destroyTemporaryContainers();

   virtual void spinAnalysis();
   virtual void truthAnalysis(TH1F* h);
   virtual void transverseTruthAnalysis();
   virtual void getTruthContainers();

   virtual CLHEP::HepLorentzVector* getTransverseVector(const CLHEP::HepLorentzVector&);

   const TruthParticleContainer* c_truthTop;
   const TruthParticleContainer* c_truthElec;
   const TruthParticleContainer* c_truthMuon;
   const TruthParticleContainer* c_truthLJ;

   const JetCollection* ljTES;
   const JetCollection* bjTES;

   const ElectronContainer* elecTES;
   const Analysis::MuonContainer* muonTES;

   const MissingET* metTES;
   const NeutrinoContainer* nuTES;

   const CompositeParticleContainer* topTES;

   TH1F* h_b_angle;
   TH1F* h_lep_angle;
   TH1F* h_lep_angle_spec_pos;
   TH1F* h_lep_angle_spec_neg;
   TH1F* h_lep_angle_beam_pos;
   TH1F* h_lep_angle_beam_neg;
   TH1F* h_lep_b_angle;

   TH2F* h_lep_angle_2d;

   TH1F* h_truth_lep_angle;
   TH1F* h_truth_lep_angle_preselected;
   TH1F* h_truth_lep_angle_selected;
   TH1F* h_truth_lep_trans_angle;
};

#endif // BUSTOP_SPIN_ANALYSIS_H


