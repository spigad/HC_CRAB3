#ifndef IEVENT_TOOL_H
#define IEVENT_TOOL_H

#include <vector>

static const InterfaceID IID_IEventTool("IEventTool", 1, 0);

class EventInfo;
class EventType;

class IEventTool: virtual public IAlgTool{
   public:
     static const InterfaceID& interfaceID();

     virtual const EventInfo* getEventInfo() = 0;
     virtual double getEventWeight() = 0;
     virtual double getEventWeight(const EventType* et) = 0;
};

inline const InterfaceID& IEventTool::interfaceID(){
   return IID_IEventTool;
 }

#endif
