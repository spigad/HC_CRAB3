#ifndef BUSTOP_ELECTRON_FILTER_H
#define BUSTOP_ELECTRON_FILTER_H

#include "GaudiKernel/Algorithm.h"

#include "CLHEP/Units/SystemOfUnits.h"

#include "StoreGate/StoreGateSvc.h"

#include "GaudiKernel/ToolHandle.h"

#include <stdint.h>
#include <string>

class ITHistSvc;
class TH1F;
class TH2F;

class IAnalysisTools;
class ElectronContainer;
class IEventTool;
class IEventTagTool;

class BUSTopElectronFilter : public Algorithm {

 public:

   BUSTopElectronFilter(const std::string& name, ISvcLocator* pSvcLocator);
   ~BUSTopElectronFilter();

   StatusCode initialize();
   StatusCode finalize();
   StatusCode execute();
  
 private:
   StoreGateSvc*  m_storeGate;
   ITHistSvc*     m_histSvc;
   IEventTool*    m_eventTool;
   IEventTagTool* m_tagTool;

   std::string m_inputElectronContainerName;
   std::string m_outputElectronContainerName;
   std::string m_rejectedContainerName;

   std::string m_filterLevel;

   bool m_truthAvailable;
   double m_eventWeight;

   const ElectronContainer* elecTES;

   ElectronContainer* c_filtered_electrons;
   ElectronContainer* c_rejected_electrons;

   virtual void getEventWeight();
   virtual void registerHistograms();
   virtual void getStoregateContainers();
   virtual void createTemporaryContainers();
   virtual void destroyTemporaryContainers();

   virtual void registerContainers();
   virtual void registerContainer(ElectronContainer* e, std::string n);

   virtual void filterElectrons();
};

#endif // BUSTOP_BJET_TAGGER_H


