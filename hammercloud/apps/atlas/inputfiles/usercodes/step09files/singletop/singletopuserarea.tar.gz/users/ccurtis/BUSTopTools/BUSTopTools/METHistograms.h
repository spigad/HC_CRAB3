#ifndef MET_HISTOGRAMS_H
#define MET_HISTOGRAMS_H

#include "GaudiKernel/AlgTool.h"
#include "GaudiKernel/MsgStream.h"
#include "GaudiKernel/AlgFactory.h"
#include "StoreGate/StoreGateSvc.h"
#include "StoreGate/DataHandle.h"
#include "AIDA/IHistogram1D.h"
#include "AIDA/IHistogram2D.h"
#include "GaudiKernel/ITHistSvc.h"
#include "EventKernel/PdtPdg.h"

class IBUSTopHistogrammer;
class TH1F;
class TH2F;

class METHistograms{
   public:
     METHistograms(IBUSTopHistogrammer* parent, std::string algName, std::string dirName, std::string hname);
     virtual ~METHistograms(){};

     TH1F* etx;
     TH1F* ety;
     TH1F* et;
     TH1F* phi;

     template<class P> void plot(P* particle, double w);
};

#include "BUSTopTools/METHistograms.icc"

#endif

