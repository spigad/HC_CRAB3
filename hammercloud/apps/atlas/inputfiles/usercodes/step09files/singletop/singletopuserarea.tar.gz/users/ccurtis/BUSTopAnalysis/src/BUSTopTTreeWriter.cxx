#include "GaudiKernel/IToolSvc.h"
#include "GaudiKernel/ITHistSvc.h"

#include "TH1.h"
#include "TH2.h"
#include "TTree.h"

#include "AnalysisTools/IAnalysisTools.h"

#include "BUSTopTools/EventTool.h"
#include "BUSTopTools/EventTagTool.h"

#include "egammaEvent/ElectronContainer.h"
#include "egammaEvent/Electron.h"
#include "egammaEvent/egammaParamDefs.h"
#include "egammaEvent/EMShower.h"

#include "muonEvent/MuonContainer.h"
#include "muonEvent/MuonParamDefs.h"

#include "JetEvent/JetCollection.h"
#include "JetEvent/Jet.h"
#include "JetTagInfo/TruthInfo.h"

#include "MissingETEvent/MissingET.h"

#include "ParticleEvent/NeutrinoContainer.h"

#include "CompositeParticleEvent/CompositeParticleContainer.h"

#include "BUSTopAnalysis/BUSTopSpinAnalysis.h"
#include "BUSTopAnalysis/BUSTopTTreeWriter.h"

BUSTopTTreeWriter::BUSTopTTreeWriter(const std::string& name, ISvcLocator* pSvcLocator) : Algorithm(name, pSvcLocator){

  declareProperty("InputElectronContainer", m_electronContainerName);
  declareProperty("InputBJetContainer", m_bjetContainerName);
  declareProperty("InputLightJetContainer", m_ljetContainerName);
  declareProperty("InputMuonContainer", m_muonContainerName);
  declareProperty("InputMETContainer", m_metContainerName);

  declareProperty("InputNeutrinoContainer", m_neutrinoContainerName);
  declareProperty("InputWContainer", m_wContainerName);
  declareProperty("InputTopContainer", m_topContainerName);

  declareProperty("JetWeightTagger", m_jetWeightTagger);
}

BUSTopTTreeWriter::~BUSTopTTreeWriter(){
}

StatusCode BUSTopTTreeWriter::initialize() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << "Initializing BUSTopTTreeWriter " << endreq;

  if (service("StoreGateSvc", m_storeGate).isFailure()) {
     mLog << MSG::ERROR << "Unable to retrieve pointer to StoreGateSvc" << endreq;
     return StatusCode::FAILURE;
  }

  service("THistSvc", m_histSvc);

  IToolSvc * toolSvc;
  service("ToolSvc", toolSvc);

  IAlgTool *tmp_eventTool = 0;
  toolSvc->retrieveTool("EventTool", tmp_eventTool);
  m_eventTool = dynamic_cast<IEventTool *>(tmp_eventTool);

  IAlgTool *tmp_tagTool = 0;
  toolSvc->retrieveTool("EventTagTool", tmp_tagTool);
  m_tagTool = dynamic_cast<IEventTagTool *>(tmp_tagTool);

  registerHistograms();
  registerTTrees();

  return StatusCode::SUCCESS;
}

void BUSTopTTreeWriter::registerHistograms(){
}

void BUSTopTTreeWriter::registerTTrees(){
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "registerTTrees()" << endreq;

  clearTreeVariables();

  t_passed = new TTree("BUSTopPassed", "BUSTopPassed");
  m_histSvc->regTree("/TREES/Selection/BUSTopPassed", t_passed);

  t_passed->Branch("eventWeight", &m_eventWeight, "eventWeight/D");

  t_passed->Branch("primary_lepton_isolation", &m_primary_lepton_isolation, "primary_lepton_isolation/D");
  t_passed->Branch("primary_lepton_pt", &m_primary_lepton_pt, "primary_lepton_pt/D");
  t_passed->Branch("secondary_lepton_pt", &m_secondary_lepton_pt, "secondary_lepton_pt/D");

  t_passed->Branch("n_bjets", &m_n_bjets, "n_bjets/D");
  t_passed->Branch("primary_bjet_weight", &m_primary_bjet_weight, "primary_bjet_weight/D");
  t_passed->Branch("primary_bjet_truth", &m_primary_bjet_truth, "primary_bjet_truth/D");
  t_passed->Branch("total_jet_weight", &m_total_jet_weight, "total_jet_weight/D");
  t_passed->Branch("primary_bjet_pt", &m_primary_bjet_pt, "primary_bjet_pt/D");
  t_passed->Branch("secondary_bjet_pt", &m_secondary_bjet_pt, "secondary_bjet_pt/D");

  t_passed->Branch("n_ljets", &m_n_ljets, "n_ljets/D");
  t_passed->Branch("primary_ljet_eta", &m_primary_ljet_eta, "primary_ljet_eta/D");
  t_passed->Branch("primary_ljet_pt", &m_primary_ljet_pt, "primary_ljet_pt/D");
  t_passed->Branch("primary_ljet_e", &m_primary_ljet_e, "primary_ljet_e/D");
  t_passed->Branch("secondary_ljet_e", &m_secondary_ljet_e, "secondary_ljet_e/D");

  t_passed->Branch("et_miss", &m_et_miss, "et_miss/D");

  t_passed->Branch("selected_jet_centrality", &m_selected_jet_centrality, "selected_jet_centrality/D");

  t_passed->Branch("lep_chi", &m_lep_chi, "lep_chi/D");  
  t_passed->Branch("b_chi", &m_b_chi, "b_chi/D");  
  t_passed->Branch("b_lep_chi", &m_b_lep_chi, "b_lep_chi/D");  

  t_passed->Branch("top_mass", &m_top_mass, "top_mass/D");
}

StatusCode BUSTopTTreeWriter::finalize() {
  MsgStream mLog( messageService(), name() );
  
  return StatusCode::SUCCESS;
}

StatusCode BUSTopTTreeWriter::execute() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << "execute()" << endreq;
 
  clearTreeVariables();

  getEventWeight(); 

  getStoregateContainers();

  //obtain variables;
  getLeptonVariables();
  getJetVariables();
  getEtMissVariables();
  getTopVariables();
  getSpinVariables();

  writeTreeVariables();

  StatusCode sc = StatusCode::SUCCESS;

  return sc;
}

void BUSTopTTreeWriter::getEventWeight(){
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "getEventWeight()" << endreq;

  if(m_tagTool->tagged(IEventTagTool::IS_ATLFAST) == false && m_tagTool->tagged(IEventTagTool::IS_MC) == true){
    m_eventWeight = m_eventTool->getEventWeight();
  }else{
    m_eventWeight = 1.0;
  }
}

void BUSTopTTreeWriter::getStoregateContainers(){
  MsgStream mLog( messageService(), name() );

  metTES = 0;
  m_storeGate->retrieve(metTES, m_metContainerName);
  if(metTES == 0){
    mLog << MSG::ERROR << "Could not retrieve MET Container from Storegate" << endreq;
  }

  elecTES = 0;
  m_storeGate->retrieve(elecTES, m_electronContainerName);
  if(elecTES == 0){
    mLog << MSG::ERROR << "Could not retrieve Electron Container from Storegate" << endreq;
  }

  bjetTES = 0;
  m_storeGate->retrieve(bjetTES, m_bjetContainerName);
  if(bjetTES == 0){
    mLog << MSG::ERROR << "Could not retrieve BJet Container from Storegate" << endreq;
  }

  ljetTES = 0;
  m_storeGate->retrieve(ljetTES, m_ljetContainerName);
  if(ljetTES == 0){
    mLog << MSG::ERROR << "Could not retrieve LightJet Container from Storegate" << endreq;
  }

  muonTES = 0;
  m_storeGate->retrieve(muonTES, m_muonContainerName);
  if(muonTES == 0){
    mLog << MSG::ERROR << "Could not retrieve Muon Container from Storegate" << endreq;
  }

  nuTES = 0;
  m_storeGate->retrieve(nuTES, m_neutrinoContainerName);
  if(nuTES == 0){
    mLog << MSG::ERROR << "Could not retrieve Neutrino Container from Storegate" << endreq;
  }

  wTES = 0;
  m_storeGate->retrieve(wTES, m_wContainerName);
  if(wTES == 0){
    mLog << MSG::ERROR << "Could not retrieve W Container from Storegate" << endreq;
  }

  topTES = 0;
  m_storeGate->retrieve(topTES, m_topContainerName);
  if(topTES == 0){
    mLog << MSG::ERROR << "Could not retrieve Top Container from Storegate" << endreq;
  }
}

void BUSTopTTreeWriter::clearTreeVariables(){
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "clearTreeVariables()" << endreq;

  m_eventWeight = 0.0;

  m_primary_lepton_pt = 0.0;
  m_primary_lepton_isolation = 0.0;
  m_secondary_lepton_pt = 0.0;

  m_n_bjets = 0.0;
  m_primary_bjet_weight = 0.0;
  m_primary_bjet_truth = 0.0;
  m_total_jet_weight = 0.0;
  m_primary_bjet_pt = 0.0;
  m_secondary_bjet_pt = 0.0;

  m_n_ljets = 0.0;
  m_primary_ljet_eta = 10.0;  //Want this to be upsurd if failed
  m_primary_ljet_pt = 0.0;
  m_primary_ljet_e = 0.0;
  m_secondary_ljet_e = 0.0;

  m_selected_jet_centrality = 0.0;

  m_et_miss = 0.0;

  m_lep_chi = -2.0;    //Want this to be upsurd if failed
  m_b_chi = -2.0;    //Want this to be upsurd if failed
  m_b_lep_chi = -2.0;    //Want this to be upsurd if failed

  m_top_mass = 0.0;
}

void BUSTopTTreeWriter::writeTreeVariables(){
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "writeTreeVariables()" << endreq;

  BUSTopTags tags;
  tags.push_back(IEventTagTool::B1SELECTION);
  tags.push_back(IEventTagTool::LJSELECTION);
  tags.push_back(IEventTagTool::LEPTON_SELECTION);

  if(m_tagTool->allTagged(tags) && topTES->size() > 0){
    t_passed->Fill();
  }

  mLog << MSG::DEBUG << "writeTreeVariables() done " << endreq;
}

void BUSTopTTreeWriter::getLeptonVariables(){
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "getLeptonVariables()" << endreq;

  if(m_tagTool->tagged(IEventTagTool::MUON_SELECTION) && muonTES->size() > 0){
    m_primary_lepton_pt = muonTES->at(0)->pt();
    m_primary_lepton_isolation = muonTES->at(0)->parameter(MuonParameters::etcone20);

    m_secondary_lepton_pt = 0.0;

    if(muonTES->size() > 1){
      m_secondary_lepton_pt = muonTES->at(1)->pt();
    }

    if(elecTES->size() > 0 && elecTES->at(0)->pt() > m_secondary_lepton_pt){
      m_secondary_lepton_pt = elecTES->at(0)->pt();
    }
  }

  if(m_tagTool->tagged(IEventTagTool::ELECTRON_SELECTION) && elecTES->size() > 0){
    m_primary_lepton_pt = elecTES->at(0)->pt();
    
    const EMShower* m_EMShower = elecTES->at(0)->detail<EMShower>("egDetailAOD");
    m_primary_lepton_isolation = m_EMShower->parameter(egammaParameters::etcone20);

    m_secondary_lepton_pt = 0.0;

    if(elecTES->size() > 1){
      m_secondary_lepton_pt = elecTES->at(1)->pt();
    }

    if(muonTES->size() > 0 && muonTES->at(0)->pt() > m_secondary_lepton_pt){
      m_secondary_lepton_pt = muonTES->at(0)->pt();
    }
  }  
}

void BUSTopTTreeWriter::getJetVariables(){
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "getJetVariables()" << endreq;

  BUSTopTags tags;
  tags.push_back(IEventTagTool::B1SELECTION);
  tags.push_back(IEventTagTool::LJSELECTION);

  if(m_tagTool->allTagged(tags) && bjetTES->size() > 0 && ljetTES->size() > 0){
    m_n_bjets = bjetTES->size();
    m_primary_bjet_weight = getFlavourTagWeight(bjetTES->at(0));
    m_primary_bjet_truth = getFlavourTagTruth(bjetTES->at(0));
    m_primary_bjet_pt = bjetTES->at(0)->pt();

    if(bjetTES->size() > 1){
      m_secondary_bjet_pt = bjetTES->at(1)->pt();
    }

    m_n_ljets = ljetTES->size();
    m_primary_ljet_eta = fabs(ljetTES->at(0)->eta());
    m_primary_ljet_pt = ljetTES->at(0)->pt();
    m_primary_ljet_e = ljetTES->at(0)->e();

    if(ljetTES->size() > 1){
      m_secondary_ljet_e = ljetTES->at(1)->e();
    }

    double num = ljetTES->at(0)->pt() + bjetTES->at(0)->pt();
    double denom = ljetTES->at(0)->p() + bjetTES->at(0)->p();

    if(denom > 0){
      m_selected_jet_centrality = num/denom;
    }

    JetCollection::const_iterator jIter = bjetTES->begin();
    JetCollection::const_iterator jIterEnd = bjetTES->end();
    while(jIter < jIterEnd){
      m_total_jet_weight += getFlavourTagWeight(*jIter);
      jIter++;
    }

    jIter = ljetTES->begin();
    jIterEnd = ljetTES->end();
    while(jIter < jIterEnd){
      m_total_jet_weight += getFlavourTagWeight(*jIter);
      jIter++;
    }
  }
}

void BUSTopTTreeWriter::getEtMissVariables(){
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "getEtMissVariables()" << endreq;

  m_et_miss = metTES->et();
}

void BUSTopTTreeWriter::getTopVariables(){
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "getTopVariables()" << endreq;

  if(topTES->size() > 0){
    mLog << MSG::DEBUG << "top mass = " << topTES->at(0)->m() << endreq;
    m_top_mass = topTES->at(0)->m();
  }
}

void BUSTopTTreeWriter::getSpinVariables(){
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "getSpinVariables()" << endreq;

  BUSTopTags tags;
  tags.push_back(IEventTagTool::B1SELECTION);
  tags.push_back(IEventTagTool::LJSELECTION);
  tags.push_back(IEventTagTool::LEPTON_SELECTION);

  if(m_tagTool->allTagged(tags) && topTES->size() > 0){
    
    const HepLorentzVector topVector = topTES->at(0)->hlv();
    const IParticle* lepVector = 0;
      
    double charge = 0.0;
      
    if(m_tagTool->tagged(IEventTagTool::ELECTRON_SELECTION) && elecTES->size() > 0){
      lepVector = elecTES->at(0);
      charge = elecTES->at(0)->charge();
    }else if(m_tagTool->tagged(IEventTagTool::MUON_SELECTION) && muonTES->size() > 0){
      lepVector = muonTES->at(0);
      charge = muonTES->at(0)->charge();
    }
    
    const HepLorentzVector ljVector = ljetTES->at(0)->hlv();
    const HepLorentzVector bVector = bjetTES->at(0)->hlv();
      
    if(lepVector != 0){
      m_b_lep_chi = cos(BUSTopSpinAnalysis::getSpectatorAngle(topVector, lepVector->hlv(), bVector));

      if(charge > 0){  
        m_lep_chi = cos(BUSTopSpinAnalysis::getSpectatorAngle(topVector, lepVector->hlv(), ljVector));
        m_b_chi = cos(BUSTopSpinAnalysis::getSpectatorAngle(topVector, bVector, ljVector));
      }else{
        m_lep_chi = cos(BUSTopSpinAnalysis::getBeamAngle(topVector, lepVector->hlv(), ljVector));
        m_b_chi = cos(BUSTopSpinAnalysis::getBeamAngle(topVector, bVector, ljVector));
      }
    }
  }   
}

double BUSTopTTreeWriter::getFlavourTagWeight(const Jet* j){
  if(m_jetWeightTagger == "Default"){
    return j->getFlavourTagWeight();
  }else{
    return j->getFlavourTagWeight(m_jetWeightTagger);
  }
}

double BUSTopTTreeWriter::getFlavourTagTruth(const Jet* j){
  double result = 0.0;

  if(m_tagTool->tagged(IEventTagTool::IS_MC)){
    std::string label = getTruthLabel(j);
    if(label == "B"){
      result = 1.0;
    }
  }

  return result;
}

std::string BUSTopTTreeWriter::getTruthLabel(const Jet* j){
  std::string label = "";
  const Analysis::TruthInfo* mcInfo = 0;
  mcInfo = j->tagInfo<Analysis::TruthInfo>("TruthInfo");
  if(mcInfo != 0){
    label = mcInfo->jetTruthLabel();
  }
 
  return label;
}

