#ifndef NU_SOLUTION_TOOL_H
#define NU_SOLUTION_TOOL_H

#include "BUSTopTools/INuSolutionTool.h"

static const InterfaceID IID_INuSolutionTool("NuSolutionTool", 1, 0);

class NuSolutionTool: public INuSolutionTool{
   public:
     NuSolutionTool(const std::string&, const std::string&, const IInterface*);
     StatusCode initialize();
     
     static const InterfaceID& interfaceID(){ return IID_INuSolutionTool; }

};

#endif
