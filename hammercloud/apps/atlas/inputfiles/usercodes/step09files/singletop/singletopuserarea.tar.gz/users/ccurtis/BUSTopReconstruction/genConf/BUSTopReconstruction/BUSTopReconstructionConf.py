#Fri May  8 13:57:21 2009
"""Automatically generated. DO NOT EDIT please"""
from GaudiKernel.Proxy.Configurable import *

class BUSTopNeutrinoReconstruction( ConfigurableAlgorithm ) :
  __slots__ = { 
    'OutputLevel' : 0, # int
    'Enable' : True, # bool
    'ErrorMax' : 1, # int
    'ErrorCount' : 0, # int
    'AuditAlgorithms' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditReinitialize' : False, # bool
    'AuditExecute' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditBeginRun' : False, # bool
    'AuditEndRun' : False, # bool
    'MonitorService' : 'MonitorSvc', # str
    'InputElectronContainer' : '', # str
    'InputMuonContainer' : '', # str
    'InputMETContainer' : '', # str
    'FilterTags' : [  ], # list
    'OutputNeutrinoContainer' : '', # str
    'TruthAvailable' : True, # bool
    'ExclusiveNeutrino' : True, # bool
    'ExclusiveOutputContainer' : '', # str
  }
  _propertyDocDct = { 
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(BUSTopNeutrinoReconstruction, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'BUSTopReconstruction'
  def getType( self ):
      return 'BUSTopNeutrinoReconstruction'
  pass # class BUSTopNeutrinoReconstruction

class BUSTopWReconstruction( ConfigurableAlgorithm ) :
  __slots__ = { 
    'OutputLevel' : 0, # int
    'Enable' : True, # bool
    'ErrorMax' : 1, # int
    'ErrorCount' : 0, # int
    'AuditAlgorithms' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditReinitialize' : False, # bool
    'AuditExecute' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditBeginRun' : False, # bool
    'AuditEndRun' : False, # bool
    'MonitorService' : 'MonitorSvc', # str
    'InputElectrons' : '', # str
    'InputMuons' : '', # str
    'InputNeutrinos' : '', # str
    'OutputWName' : '', # str
    'TruthAvailable' : False, # bool
    'FilterTags' : [  ], # list
  }
  _propertyDocDct = { 
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(BUSTopWReconstruction, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'BUSTopReconstruction'
  def getType( self ):
      return 'BUSTopWReconstruction'
  pass # class BUSTopWReconstruction

class BUSTopTReconstruction( ConfigurableAlgorithm ) :
  __slots__ = { 
    'OutputLevel' : 0, # int
    'Enable' : True, # bool
    'ErrorMax' : 1, # int
    'ErrorCount' : 0, # int
    'AuditAlgorithms' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditReinitialize' : False, # bool
    'AuditExecute' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditBeginRun' : False, # bool
    'AuditEndRun' : False, # bool
    'MonitorService' : 'MonitorSvc', # str
    'TruthAvailable' : False, # bool
    'FilterTags' : [  ], # list
    'InputBJets' : '', # str
    'InputWs' : '', # str
    'OutputTops' : '', # str
    'ApplyMassVeto' : False, # bool
    'LowMassVeto' : 0.0, # float
    'HighMassVeto' : 0.0, # float
  }
  _propertyDocDct = { 
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(BUSTopTReconstruction, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'BUSTopReconstruction'
  def getType( self ):
      return 'BUSTopTReconstruction'
  pass # class BUSTopTReconstruction
