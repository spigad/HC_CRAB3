if DoTruthFilter:
	from BUSTopPreselection.BUSTopPreselectionConf import BUSTopTruthFilter
	Sequencer += BUSTopTruthFilter()
	BUSTopTruthFilter.OutputLevel = WARNING

	BUSTopTruthFilter.MCTruthContainer   = "SpclMC"
	BUSTopTruthFilter.DatasetID          = 5502
	BUSTopTruthFilter.SelectChildren1    = [11, 13]
	BUSTopTruthFilter.SelectChildren2    = [1, 2, 3, 4]

if DoTruth:
	from BUSTopPreselection.BUSTopPreselectionConf import BUSTopTruth
	Sequencer += BUSTopTruth()
	BUSTopTruth.OutputLevel = WARNING

	BUSTopTruth.MCTruthContainer   = "SpclMC"
	BUSTopTruth.PrintTable         = 0


