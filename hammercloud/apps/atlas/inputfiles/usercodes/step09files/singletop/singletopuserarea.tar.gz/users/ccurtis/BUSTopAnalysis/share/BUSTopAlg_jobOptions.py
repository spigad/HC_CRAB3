from BUSTopAnalysis.BUSTopAnalysisConf import BUSTopAlg

BUSTopAlg = BUSTopAlg( "BUSTopAlg" )
BUSTopAlg.OutputLevel = WARNING

Sequencer += BUSTopAlg


