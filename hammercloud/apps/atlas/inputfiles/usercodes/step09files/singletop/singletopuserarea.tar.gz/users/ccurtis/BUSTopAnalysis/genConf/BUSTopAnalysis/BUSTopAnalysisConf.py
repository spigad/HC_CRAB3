#Fri May  8 14:00:26 2009
"""Automatically generated. DO NOT EDIT please"""
from GaudiKernel.GaudiHandles import *
from GaudiKernel.Proxy.Configurable import *

class BUSTopInitAlg( ConfigurableAlgorithm ) :
  __slots__ = { 
    'OutputLevel' : 0, # int
    'Enable' : True, # bool
    'ErrorMax' : 1, # int
    'ErrorCount' : 0, # int
    'AuditAlgorithms' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditReinitialize' : False, # bool
    'AuditExecute' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditBeginRun' : False, # bool
    'AuditEndRun' : False, # bool
    'MonitorService' : 'MonitorSvc', # str
    'IsAtlfast' : False, # bool
    'IsMC' : False, # bool
  }
  _propertyDocDct = { 
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(BUSTopInitAlg, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'BUSTopAnalysis'
  def getType( self ):
      return 'BUSTopInitAlg'
  pass # class BUSTopInitAlg

class BUSTopAlg( ConfigurableAlgorithm ) :
  __slots__ = { 
    'OutputLevel' : 0, # int
    'Enable' : True, # bool
    'ErrorMax' : 1, # int
    'ErrorCount' : 0, # int
    'AuditAlgorithms' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditReinitialize' : False, # bool
    'AuditExecute' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditBeginRun' : False, # bool
    'AuditEndRun' : False, # bool
    'MonitorService' : 'MonitorSvc', # str
  }
  _propertyDocDct = { 
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(BUSTopAlg, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'BUSTopAnalysis'
  def getType( self ):
      return 'BUSTopAlg'
  pass # class BUSTopAlg

class BUSTopSelection( ConfigurableAlgorithm ) :
  __slots__ = { 
    'OutputLevel' : 0, # int
    'Enable' : True, # bool
    'ErrorMax' : 1, # int
    'ErrorCount' : 0, # int
    'AuditAlgorithms' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditReinitialize' : False, # bool
    'AuditExecute' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditBeginRun' : False, # bool
    'AuditEndRun' : False, # bool
    'MonitorService' : 'MonitorSvc', # str
    'InputElectronContainer' : '', # str
    'InputBJetContainer' : '', # str
    'InputLightJetContainer' : '', # str
    'InputMuonContainer' : '', # str
    'InputMETContainer' : '', # str
    'OutputElectronContainer' : '', # str
    'OutputMuonContainer' : '', # str
    'OutputB1JetContainer' : '', # str
    'OutputB3JetContainer' : '', # str
    'OutputLJetContainer' : '', # str
    'SortedLJetContainer' : '', # str
    'TruthAvailable' : True, # bool
    'FilterTags' : [  ], # list
    'LJSelection' : '', # str
    'ApplySecondaryLeptonCut' : True, # bool
    'SecondaryLeptonCut' : float('nan'), # float
    'ApplyLeptonIsolation' : True, # bool
    'LeptonIsolationCut' : 1.2095377e-312, # float
    'DoMuon' : False, # bool
    'DoElectron' : False, # bool
    'ApplySecondaryBJetCut' : True, # bool
    'SecondaryBJetCut' : 9.9783609e-315, # float
    'B1Selection' : '', # str
    'JetWeightTagger' : '', # str
    'NuSelection' : '', # str
  }
  _propertyDocDct = { 
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(BUSTopSelection, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'BUSTopAnalysis'
  def getType( self ):
      return 'BUSTopSelection'
  pass # class BUSTopSelection

class BUSTopSpinAnalysis( ConfigurableAlgorithm ) :
  __slots__ = { 
    'OutputLevel' : 0, # int
    'Enable' : True, # bool
    'ErrorMax' : 1, # int
    'ErrorCount' : 0, # int
    'AuditAlgorithms' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditReinitialize' : False, # bool
    'AuditExecute' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditBeginRun' : False, # bool
    'AuditEndRun' : False, # bool
    'MonitorService' : 'MonitorSvc', # str
    'TruthAvailable' : True, # bool
    'InputElectronContainer' : '', # str
    'InputTopContainer' : '', # str
    'InputBJetContainer' : '', # str
    'InputLightJetContainer' : '', # str
    'InputMuonContainer' : '', # str
    'InputNeutrinoContainer' : '', # str
    'InputMETContainer' : '', # str
    'FilterTags' : [  ], # list
  }
  _propertyDocDct = { 
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(BUSTopSpinAnalysis, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'BUSTopAnalysis'
  def getType( self ):
      return 'BUSTopSpinAnalysis'
  pass # class BUSTopSpinAnalysis

class BUSTopCSCSelection( ConfigurableAlgorithm ) :
  __slots__ = { 
    'OutputLevel' : 0, # int
    'Enable' : True, # bool
    'ErrorMax' : 1, # int
    'ErrorCount' : 0, # int
    'AuditAlgorithms' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditReinitialize' : False, # bool
    'AuditExecute' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditBeginRun' : False, # bool
    'AuditEndRun' : False, # bool
    'MonitorService' : 'MonitorSvc', # str
    'InputElectronContainer' : '', # str
    'InputBJetContainer' : '', # str
    'InputLightJetContainer' : '', # str
    'InputMuonContainer' : '', # str
    'InputMETContainer' : '', # str
    'OutputElectronContainer' : '', # str
    'OutputMuonContainer' : '', # str
    'OutputBJetContainer' : '', # str
    'OutputLightJetContainer' : '', # str
    'TruthAvailable' : False, # bool
  }
  _propertyDocDct = { 
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(BUSTopCSCSelection, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'BUSTopAnalysis'
  def getType( self ):
      return 'BUSTopCSCSelection'
  pass # class BUSTopCSCSelection

class BUSTopNeutrinoAnalysis( ConfigurableAlgorithm ) :
  __slots__ = { 
    'OutputLevel' : 0, # int
    'Enable' : True, # bool
    'ErrorMax' : 1, # int
    'ErrorCount' : 0, # int
    'AuditAlgorithms' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditReinitialize' : False, # bool
    'AuditExecute' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditBeginRun' : False, # bool
    'AuditEndRun' : False, # bool
    'MonitorService' : 'MonitorSvc', # str
    'Electrons' : '', # str
    'PreselectedElectrons' : '', # str
    'CSCSelectedElectrons' : '', # str
    'Muons' : '', # str
    'PreselectedMuons' : '', # str
    'CSCSelectedMuons' : '', # str
    'Neutrinos' : '', # str
    'PreselectedNeutrinos' : '', # str
    'CSCSelectedNeutrinos' : '', # str
    'SelectedNeutrinos' : '', # str
    'MET' : '', # str
    'WWidth' : 8.4879832e-313, # float
    'METSigma' : 8.718172e-266, # float
    'TruthAvailable' : False, # bool
  }
  _propertyDocDct = { 
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(BUSTopNeutrinoAnalysis, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'BUSTopAnalysis'
  def getType( self ):
      return 'BUSTopNeutrinoAnalysis'
  pass # class BUSTopNeutrinoAnalysis

class BUSTopWAnalysis( ConfigurableAlgorithm ) :
  __slots__ = { 
    'OutputLevel' : 0, # int
    'Enable' : True, # bool
    'ErrorMax' : 1, # int
    'ErrorCount' : 0, # int
    'AuditAlgorithms' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditReinitialize' : False, # bool
    'AuditExecute' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditBeginRun' : False, # bool
    'AuditEndRun' : False, # bool
    'MonitorService' : 'MonitorSvc', # str
    'WName' : '', # str
    'PreselectedWName' : '', # str
    'CSCSelectedWName' : '', # str
    'SelectedWName' : '', # str
    'SelectedBJetName' : '', # str
    'TruthAvailable' : True, # bool
  }
  _propertyDocDct = { 
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(BUSTopWAnalysis, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'BUSTopAnalysis'
  def getType( self ):
      return 'BUSTopWAnalysis'
  pass # class BUSTopWAnalysis

class BUSTopTAnalysis( ConfigurableAlgorithm ) :
  __slots__ = { 
    'OutputLevel' : 0, # int
    'Enable' : True, # bool
    'ErrorMax' : 1, # int
    'ErrorCount' : 0, # int
    'AuditAlgorithms' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditReinitialize' : False, # bool
    'AuditExecute' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditBeginRun' : False, # bool
    'AuditEndRun' : False, # bool
    'MonitorService' : 'MonitorSvc', # str
    'TruthAvailable' : True, # bool
    'Top' : '', # str
    'PreselectedTop' : '', # str
    'CSCSelectedTop' : '', # str
    'SelectedTop' : '', # str
  }
  _propertyDocDct = { 
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(BUSTopTAnalysis, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'BUSTopAnalysis'
  def getType( self ):
      return 'BUSTopTAnalysis'
  pass # class BUSTopTAnalysis

class BUSTopEtMissAnalysis( ConfigurableAlgorithm ) :
  __slots__ = { 
    'OutputLevel' : 0, # int
    'Enable' : True, # bool
    'ErrorMax' : 1, # int
    'ErrorCount' : 0, # int
    'AuditAlgorithms' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditReinitialize' : False, # bool
    'AuditExecute' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditBeginRun' : False, # bool
    'AuditEndRun' : False, # bool
    'MonitorService' : 'MonitorSvc', # str
    'METContainer' : '', # str
    'NeutrinoContainer' : '', # str
    'PreselectedElectrons' : '', # str
    'PreselectedMuons' : '', # str
    'CSCSelectedElectrons' : '', # str
    'CSCSelectedMuons' : '', # str
    'TruthAvailable' : True, # bool
    'METCut' : 8.9658566e-308, # float
  }
  _propertyDocDct = { 
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(BUSTopEtMissAnalysis, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'BUSTopAnalysis'
  def getType( self ):
      return 'BUSTopEtMissAnalysis'
  pass # class BUSTopEtMissAnalysis

class BUSTopJetAnalysis( ConfigurableAlgorithm ) :
  __slots__ = { 
    'OutputLevel' : 0, # int
    'Enable' : True, # bool
    'ErrorMax' : 1, # int
    'ErrorCount' : 0, # int
    'AuditAlgorithms' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditReinitialize' : False, # bool
    'AuditExecute' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditBeginRun' : False, # bool
    'AuditEndRun' : False, # bool
    'MonitorService' : 'MonitorSvc', # str
    'InputJetContainer' : '', # str
    'OverlapJetContainer' : '', # str
    'OverlapEJetContainer' : '', # str
    'ElectronContainer' : '', # str
    'MuonContainer' : '', # str
    'BJetContainer' : '', # str
    'LightJetContainer' : '', # str
    'PreselectedBJetContainer' : '', # str
    'PreselectedLightJetContainer' : '', # str
    'PreselectedMuonContainer' : '', # str
    'PreselectedElectronContainer' : '', # str
    'B1SelectedBJetContainer' : '', # str
    'LJSelectedLJetContainer' : '', # str
    'CSCSelectedBJetContainer' : '', # str
    'CSCSelectedLightJetContainer' : '', # str
    'CSCSelectedMuonContainer' : '', # str
    'CSCSelectedElectronContainer' : '', # str
    'TruthAvailable' : False, # bool
    'PlotJetWeights' : True, # bool
    'JetWeightTagger' : '', # str
    'TruthMatchDeltaR' : 1.9902284e-298, # float
  }
  _propertyDocDct = { 
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(BUSTopJetAnalysis, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'BUSTopAnalysis'
  def getType( self ):
      return 'BUSTopJetAnalysis'
  pass # class BUSTopJetAnalysis

class BUSTopElectronAnalysis( ConfigurableAlgorithm ) :
  __slots__ = { 
    'OutputLevel' : 0, # int
    'Enable' : True, # bool
    'ErrorMax' : 1, # int
    'ErrorCount' : 0, # int
    'AuditAlgorithms' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditReinitialize' : False, # bool
    'AuditExecute' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditBeginRun' : False, # bool
    'AuditEndRun' : False, # bool
    'MonitorService' : 'MonitorSvc', # str
    'ElectronInputContainer' : '', # str
    'SelectedElectronContainer' : '', # str
    'FilteredElectronContainer' : '', # str
    'FilteredJetContainer' : '', # str
    'FilterRejectsElectronContainer' : '', # str
    'PreselectedElectronContainer' : '', # str
    'PreselectedLJetContainer' : '', # str
    'PreselectedBJetContainer' : '', # str
    'PreselectedMuonContainer' : '', # str
    'TruthMatchDeltaR' : 8.9658566e-308, # float
    'TruthAvailable' : True, # bool
    'TrigDecisionTool' : PublicToolHandle('TrigDec::TrigDecisionTool'), # GaudiHandle
    'DoTrigger' : True, # bool
  }
  _propertyDocDct = { 
    'TrigDecisionTool' : """ The tool to access TrigDecision """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(BUSTopElectronAnalysis, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'BUSTopAnalysis'
  def getType( self ):
      return 'BUSTopElectronAnalysis'
  pass # class BUSTopElectronAnalysis

class BUSTopMuonAnalysis( ConfigurableAlgorithm ) :
  __slots__ = { 
    'OutputLevel' : 0, # int
    'Enable' : True, # bool
    'ErrorMax' : 1, # int
    'ErrorCount' : 0, # int
    'AuditAlgorithms' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditReinitialize' : False, # bool
    'AuditExecute' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditBeginRun' : False, # bool
    'AuditEndRun' : False, # bool
    'MonitorService' : 'MonitorSvc', # str
    'InputMuonContainer' : '', # str
    'SelectedMuonContainer' : '', # str
    'PreselectedMuonContainer' : '', # str
    'PreselectedElectronContainer' : '', # str
    'PreselectedLJetContainer' : '', # str
    'PreselectedBJetContainer' : '', # str
    'TruthMatchDeltaR' : 8.9658566e-308, # float
    'TruthAvailable' : True, # bool
    'DoTrigger' : True, # bool
    'TrigDecisionTool' : PublicToolHandle('TrigDec::TrigDecisionTool'), # GaudiHandle
  }
  _propertyDocDct = { 
    'TrigDecisionTool' : """ The tool to access TrigDecision """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(BUSTopMuonAnalysis, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'BUSTopAnalysis'
  def getType( self ):
      return 'BUSTopMuonAnalysis'
  pass # class BUSTopMuonAnalysis

class BUSTopHistogramDump( ConfigurableAlgorithm ) :
  __slots__ = { 
    'OutputLevel' : 0, # int
    'Enable' : True, # bool
    'ErrorMax' : 1, # int
    'ErrorCount' : 0, # int
    'AuditAlgorithms' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditReinitialize' : False, # bool
    'AuditExecute' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditBeginRun' : False, # bool
    'AuditEndRun' : False, # bool
    'MonitorService' : 'MonitorSvc', # str
    'InputMuonContainer' : '', # str
    'InputElectronContainer' : '', # str
    'InputLJetContainer' : '', # str
    'InputBJetContainer' : '', # str
    'InputMetContainer' : '', # str
    'IsAtlfast' : True, # bool
    'JetWeightTagger' : '', # str
    'MinElectronPt' : 4.8458771e-304, # float
    'MinElectronEta' : 8.9658569e-308, # float
    'MaxElectronEta' : 8.7143863e-266, # float
    'InclusiveElectronEta' : False, # bool
    'MinMuonPt' : 0.0, # float
    'MinMuonEta' : 8.9658566e-308, # float
    'MaxMuonEta' : 8.9658566e-308, # float
    'InclusiveMuonEta' : True, # bool
    'MinBJetPt' : 8.9658566e-308, # float
    'MinBJetEta' : 8.9658566e-308, # float
    'MaxBJetEta' : 8.9658566e-308, # float
    'InclusiveBJetEta' : True, # bool
    'MinJetPt' : 8.9658566e-308, # float
    'MinJetEta' : 8.9658566e-308, # float
    'MaxJetEta' : 0.0, # float
    'InclusiveJetEta' : True, # bool
    'TruthAvailable' : True, # bool
    'DumpTruth' : True, # bool
    'DoOverlapRemoval' : True, # bool
  }
  _propertyDocDct = { 
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(BUSTopHistogramDump, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'BUSTopAnalysis'
  def getType( self ):
      return 'BUSTopHistogramDump'
  pass # class BUSTopHistogramDump

class BUSTopZSelection( ConfigurableAlgorithm ) :
  __slots__ = { 
    'OutputLevel' : 0, # int
    'Enable' : True, # bool
    'ErrorMax' : 1, # int
    'ErrorCount' : 0, # int
    'AuditAlgorithms' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditReinitialize' : False, # bool
    'AuditExecute' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditBeginRun' : False, # bool
    'AuditEndRun' : False, # bool
    'MonitorService' : 'MonitorSvc', # str
    'ElectronInputContainer' : '', # str
    'METInputContainer' : '', # str
  }
  _propertyDocDct = { 
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(BUSTopZSelection, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'BUSTopAnalysis'
  def getType( self ):
      return 'BUSTopZSelection'
  pass # class BUSTopZSelection

class BUSTopTTreeWriter( ConfigurableAlgorithm ) :
  __slots__ = { 
    'OutputLevel' : 0, # int
    'Enable' : True, # bool
    'ErrorMax' : 1, # int
    'ErrorCount' : 0, # int
    'AuditAlgorithms' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditReinitialize' : False, # bool
    'AuditExecute' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditBeginRun' : False, # bool
    'AuditEndRun' : False, # bool
    'MonitorService' : 'MonitorSvc', # str
    'InputElectronContainer' : '', # str
    'InputBJetContainer' : '', # str
    'InputLightJetContainer' : '', # str
    'InputMuonContainer' : '', # str
    'InputMETContainer' : '', # str
    'InputNeutrinoContainer' : '', # str
    'InputWContainer' : '', # str
    'InputTopContainer' : '', # str
    'JetWeightTagger' : '', # str
  }
  _propertyDocDct = { 
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(BUSTopTTreeWriter, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'BUSTopAnalysis'
  def getType( self ):
      return 'BUSTopTTreeWriter'
  pass # class BUSTopTTreeWriter
