#ifndef BUSTOP_T_ANALYSIS_H
#define BUSTOP_T_ANALYSIS_H

#include "GaudiKernel/Algorithm.h"

#include "CLHEP/Units/SystemOfUnits.h"

#include "StoreGate/StoreGateSvc.h"

#include "GaudiKernel/ToolHandle.h"

#include <stdint.h>
#include <string>

class ITHistSvc;
class TH1F;
class TH2F;

class IAnalysisTools;

class TruthParticleContainer;
class CompositeParticleContainer;
class IBUSTopHistogrammer;
class IEventTool;
class IEventTagTool;
class ITruthMatch;

class KinematicHistograms;
class ResolutionHistograms;
class METResolutionHistograms;

class BUSTopTAnalysis : public Algorithm {

 public:

   BUSTopTAnalysis(const std::string& name, ISvcLocator* pSvcLocator);
   ~BUSTopTAnalysis();

   StatusCode initialize();
   StatusCode finalize();
   StatusCode execute();
  
 private:
   StoreGateSvc* m_storeGate;
   ITHistSvc*    m_thistSvc;
   IBUSTopHistogrammer *m_histogrammer;
   IEventTool *m_eventTool;
   IEventTagTool *m_tagTool;
   ITruthMatch *m_truthMatchTool;

   std::string m_topName;
   std::string m_preselectedTopName;
   std::string m_cscSelectedTopName;
   std::string m_selectedTopName;

   double m_eventWeight;
   bool m_truthAvailable;

   virtual void registerHistograms();

   virtual void getEventWeight();
   virtual void getStoregateContainers();
   virtual void getTruthContainers();
   virtual void createTemporaryContainers();
   virtual void destroyTemporaryContainers();

   virtual void plotTop(const CompositeParticleContainer* tc, KinematicHistograms* th, TH1F* tMass);
   virtual void plotTopRes(const CompositeParticleContainer* tc, ResolutionHistograms* th);

   const CompositeParticleContainer* c_top;
   const CompositeParticleContainer* c_preselectedTop;
   const CompositeParticleContainer* c_cscSelectedTop;
   const CompositeParticleContainer* c_selectedTop;

   const TruthParticleContainer* c_topTruth;

   TH1F* h_topMass;
   TH1F* h_preselectedTopMass;
   TH1F* h_cscSelectedTopMass;
   TH1F* h_selectedTopMass;

   KinematicHistograms* h_top;
   KinematicHistograms* h_preselectedTop;
   KinematicHistograms* h_cscSelectedTop;
   KinematicHistograms* h_selectedTop;

   ResolutionHistograms* h_selectedRes;
};

#endif // BUSTOP_T_ANALYSIS_H


