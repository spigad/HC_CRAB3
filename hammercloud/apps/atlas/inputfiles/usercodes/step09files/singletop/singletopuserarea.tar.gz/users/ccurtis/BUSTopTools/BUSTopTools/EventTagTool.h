#ifndef EVENT_TAG_TOOL_H
#define EVENT_TAG_TOOL_H

#include "GaudiKernel/AlgTool.h"
#include "GaudiKernel/MsgStream.h"
#include "GaudiKernel/AlgFactory.h"
#include "StoreGate/StoreGateSvc.h"
#include "BUSTopTools/IEventTagTool.h"

class EventTagTool: virtual public IEventTagTool, public AlgTool{
   public:
     EventTagTool(const std::string&, const std::string&, const IInterface*);
     virtual ~EventTagTool();
     virtual StatusCode initialize();
     virtual StatusCode finalize();

     virtual void initialiseTags();
     virtual void tag(int t);
     virtual bool tagged(int t);
     virtual bool allTagged(BUSTopTags& t);
     virtual bool anyTagged(BUSTopTags& t);
     virtual int numberOfTags();
     virtual void printTags();

   private:
     mutable MsgStream m_log;
     StoreGateSvc* m_storeGate;

     BUSTopTags* tags;
};

#endif
