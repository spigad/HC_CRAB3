#ifndef BUSTOP_TRIGGER_DECISION_H
#define BUSTOP_TRIGGER_DECISION_H

#include "GaudiKernel/Algorithm.h"

#include "CLHEP/Units/SystemOfUnits.h"

#include "StoreGate/StoreGateSvc.h"

#include "GaudiKernel/ToolHandle.h"

#include "muonEvent/MuonContainer.h"
#include "TrigDecision/TrigDecisionTool.h"

#include <stdint.h>
#include <string>
#include <vector>

class ITHistSvc;
class TH1F;
class TH1I;

class IAnalysisTools;
class ElectronContainer;
class MissingET;
class JetCollection;

class IBUSTopHistogrammer;
class IEventTool;
class IEventTagTool;

class ElectronContainer;
class TruthParticleContainer;
class ParticleJetContainer;
class MissingET;

namespace Analysis{
   class MuonContainer;
}

class BUSTopTriggerDecision : public Algorithm {

 public:

   BUSTopTriggerDecision(const std::string& name, ISvcLocator* pSvcLocator);
   ~BUSTopTriggerDecision();

   StatusCode initialize();
   StatusCode finalize();
   StatusCode execute();

 private:

   StoreGateSvc* m_storeGate;
   ITHistSvc *m_thistSvc;
   IBUSTopHistogrammer* m_histogrammer;
   IEventTool *m_eventTool;
   IEventTagTool *m_tagTool;
   ToolHandle<TrigDec::TrigDecisionTool> m_trigDec;

   std::string m_electronContainerName;

   std::string m_bJetContainerName;
   std::string m_lightJetContainerName;

   std::string m_muonContainerName;
   std::string m_metContainerName;

   double m_elecPtCut;
   double m_muonPtCut;

   std::vector<std::string> m_electronTriggerItems;
   std::vector<std::string> m_muonTriggerItems;

   bool m_truthAvailable;
   bool m_runTrigger;
   bool m_printMenu;
   double m_eventWeight;

   const ElectronContainer* elecTES;
   const Analysis::MuonContainer* muonTES;
   const MissingET* metTES;
   const JetCollection* bjetTES;
   const JetCollection* ljetTES;

   virtual void registerHistograms();

   virtual void getEventWeight();   
   virtual void getStoregateContainers();
   virtual void createTemporaryContainers();
   virtual void destroyTemporaryContainers();

   virtual bool passedTrigger();

   virtual void registerPassed(bool result);
   virtual void registerPassed(const ElectronContainer* c, std::string n);
   virtual void registerPassed(const Analysis::MuonContainer* c, std::string n);
   virtual void registerPassed(const JetCollection* c, std::string n);

   virtual void printTriggerMenu();

   TH1F* h_number_passed;
   TH1F* h_trigger_passed;

};

#endif // BUSTOP_TRIGGER_DECISION_H



