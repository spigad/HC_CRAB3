from BUSTopPreselection.BUSTopPreselectionConf import BUSTopPreselection
Sequencer += BUSTopPreselection()
BUSTopPreselection.OutputLevel = WARNING

BUSTopPreselection.FilterResults           = 0
BUSTopPreselection.QuitOnFail              = 0

BUSTopPreselection.InputElectronContainer  = BUSTopElectronFilter.ElectronOutputContainer
BUSTopPreselection.InputBJetContainer      = BUSTopBJetTagger.OutputBJetContainer
BUSTopPreselection.InputLightJetContainer  = BUSTopBJetTagger.OutputLJetContainer
BUSTopPreselection.InputMuonContainer      = BUSTopMuonFilter.MuonOutputContainer
BUSTopPreselection.InputMETContainer       = BUSTopJES.METOutputContainer

BUSTopPreselection.OutputElectronContainer  = BUSTopElectronFilter.ElectronOutputContainer
BUSTopPreselection.OutputBJetContainer      = BUSTopBJetTagger.OutputBJetContainer
BUSTopPreselection.OutputLightJetContainer  = BUSTopBJetTagger.OutputLJetContainer
BUSTopPreselection.OutputMuonContainer      = BUSTopMuonFilter.MuonOutputContainer
BUSTopPreselection.OutputMETContainer       = BUSTopJES.METOutputContainer

BUSTopPreselection.TruthAvailable = DoTruth

	
