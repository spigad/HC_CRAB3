from BUSTopAnalysis.BUSTopAnalysisConf import BUSTopWAnalysis
Sequencer += BUSTopWAnalysis()
BUSTopWAnalysis.OutputLevel = WARNING

BUSTopWAnalysis.WName                            = BUSTopWRecon_Full.OutputWName
BUSTopWAnalysis.PreselectedWName                 = BUSTopWRecon_Preselection.OutputWName
BUSTopWAnalysis.CSCSelectedWName                 = BUSTopWRecon_CSCSelection.OutputWName

if DoSelection:
	BUSTopWAnalysis.SelectedWName            = BUSTopWRecon_Selection.OutputWName
	BUSTopWAnalysis.SelectedBJetName         = BUSTopSelection.OutputB1JetContainer

BUSTopWAnalysis.TruthAvailable                   = DoTruth




