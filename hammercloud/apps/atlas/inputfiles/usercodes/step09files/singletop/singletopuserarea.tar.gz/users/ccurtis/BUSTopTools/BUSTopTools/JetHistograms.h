#ifndef JET_HISTOGRAMS_H
#define JET_HISTOGRAMS_H

#include "GaudiKernel/AlgTool.h"
#include "GaudiKernel/MsgStream.h"
#include "GaudiKernel/AlgFactory.h"
#include "StoreGate/StoreGateSvc.h"
#include "StoreGate/DataHandle.h"
#include "AIDA/IHistogram1D.h"
#include "AIDA/IHistogram2D.h"
#include "GaudiKernel/ITHistSvc.h"
#include "EventKernel/PdtPdg.h"

#include "BUSTopTools/KinematicHistograms.h"

class IBUSTopHistogrammer;
class TH1F;
class TH2F;
class TH3F;
class Jet;
class JetCollection;

class JetHistograms: public KinematicHistograms{
   public:
     JetHistograms(IBUSTopHistogrammer* parent, std::string algName, std::string dirName, std::string hname, std::string tagger);
     virtual ~JetHistograms(){};

     TH1F** weight;				//[0] = combined, [1] = pos, [2] = neg
     TH1F** nTrks;				//[0] = combined, [1] = pos, [2] = neg
     TH1F** bestQTrk;				//[0] = combined, [1] = pos, [2] = neg

     std::string m_tagger;

     void useTagger(std::string t);
     void plotContainer(const JetCollection* c, double w, int maxCount = -1);
     void plot(const Jet* particle, double w);
};

#endif

