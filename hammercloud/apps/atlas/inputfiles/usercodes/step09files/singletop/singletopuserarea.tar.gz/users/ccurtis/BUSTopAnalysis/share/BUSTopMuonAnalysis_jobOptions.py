from BUSTopAnalysis.BUSTopAnalysisConf import BUSTopMuonAnalysis
Sequencer += BUSTopMuonAnalysis()
BUSTopMuonAnalysis.OutputLevel = WARNING

BUSTopMuonAnalysis.InputMuonContainer             = BUSTopSelection.InputMuonContainer
BUSTopMuonAnalysis.SelectedMuonContainer          = BUSTopSelection.OutputMuonContainer

BUSTopMuonAnalysis.PreselectedMuonContainer       = BUSTopPreselection.OutputMuonContainer
BUSTopMuonAnalysis.PreselectedElectronContainer   = BUSTopPreselection.OutputElectronContainer
BUSTopMuonAnalysis.PreselectedBJetContainer       = BUSTopPreselection.OutputBJetContainer
BUSTopMuonAnalysis.PreselectedLJetContainer       = BUSTopPreselection.OutputLightJetContainer

if DoTruth:
	BUSTopMuonAnalysis.TruthAvailable     = 1
else:
	BUSTopMuonAnalysis.TruthAvailable     = 0

BUSTopMuonAnalysis.TruthMatchDeltaR   = 0.2
BUSTopMuonAnalysis.DoTrigger = DoTrigger


