#include "GaudiKernel/MsgStream.h"
#include "GaudiKernel/AlgFactory.h"
#include "GaudiKernel/IToolSvc.h"
#include "GaudiKernel/ITHistSvc.h"
#include "StoreGate/StoreGateSvc.h"
#include "StoreGate/DataHandle.h"

#include "TH1.h"
#include "TH2.h"

#include "McParticleEvent/TruthParticle.h"
#include "McParticleEvent/TruthParticleContainer.h"
#include "egammaEvent/ElectronContainer.h"
#include "egammaEvent/Electron.h"
#include "muonEvent/MuonContainer.h"
#include "muonEvent/Muon.h"

#include "JetEvent/JetCollection.h"

#include "MissingETEvent/MissingET.h"

#include "AnalysisTools/IAnalysisTools.h"
#include "AnalysisUtils/AnalysisCombination.h"
#include "AnalysisUtils/AnalysisMisc.h"
#include "AnalysisUtils/IParticleFilter.h"

#include "BUSTopTools/IBUSTopHistogrammer.h"
#include "BUSTopTools/MuonHistograms.h"
#include "BUSTopTools/METHistograms.h"
#include "BUSTopTools/ElectronHistograms.h"
#include "BUSTopTools/JetHistograms.h"
#include "BUSTopTools/DecayVector.h"
#include "BUSTopTools/TruthMatch.h"
#include "BUSTopTools/EventTool.h"
#include "BUSTopTools/EventTagTool.h"

#include "BUSTopAnalysis/BUSTopHistogramDump.h"

#include <stdint.h>
#include <algorithm>
#include <math.h>
#include <functional>
#include <iostream>
#include <fstream>

BUSTopHistogramDump::BUSTopHistogramDump(const std::string& name,
  ISvcLocator* pSvcLocator) : Algorithm(name, pSvcLocator)
{
  /// switches to control the analysis through job options :: these are the default
  /// to changed in the job options

  declareProperty("InputMuonContainer", m_inputMuonContainerName);
  declareProperty("InputElectronContainer", m_inputElectronContainerName);

  declareProperty("InputLJetContainer", m_inputLJetContainerName);
  declareProperty("InputBJetContainer", m_inputBJetContainerName);

  declareProperty("InputMetContainer", m_inputMetContainerName);

  declareProperty("IsAtlfast", m_isAtlfast);
  declareProperty("JetWeightTagger", m_jetWeightTagger);

  declareProperty("MinElectronPt", m_elecPtMin);
  declareProperty("MinElectronEta", m_elecEtaMin);
  declareProperty("MaxElectronEta", m_elecEtaMax);
  declareProperty("InclusiveElectronEta", m_inclusiveElectronEta);

  declareProperty("MinMuonPt", m_muonPtMin);
  declareProperty("MinMuonEta", m_muonEtaMin);
  declareProperty("MaxMuonEta", m_muonEtaMax);
  declareProperty("InclusiveMuonEta", m_inclusiveMuonEta);

  declareProperty("MinBJetPt", m_bjetPtMin);
  declareProperty("MinBJetEta", m_bjetEtaMin);
  declareProperty("MaxBJetEta", m_bjetEtaMax);
  declareProperty("InclusiveBJetEta", m_inclusiveBJetEta);

  declareProperty("MinJetPt", m_ljetPtMin);
  declareProperty("MinJetEta", m_ljetEtaMin);
  declareProperty("MaxJetEta", m_ljetEtaMax);
  declareProperty("InclusiveJetEta", m_inclusiveJetEta);

  declareProperty("TruthAvailable", m_truthAvailable);
  declareProperty("DumpTruth", m_dumpTruth);
  declareProperty("DoOverlapRemoval", m_doOverlapRemoval);
}


/////////////////////////////////////////////////////////////////////////////////////
/// Destructor - check up memory allocation
/// delete any memory allocation on the heap

BUSTopHistogramDump::~BUSTopHistogramDump() {
}

////////////////////////////////////////////////////////////////////////////////////
/// Initialize
/// initialize StoreGate
/// get a handle on the analysis tools
/// book histograms

StatusCode BUSTopHistogramDump::initialize() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO
       << "Initializing BUSTopHistogramDump"
       << endreq;

  StatusCode sc;
  
  sc = service("StoreGateSvc", m_storeGate);
  if(sc.isFailure()){
    mLog << MSG::ERROR 
         << "Unable to retrieve pointer to StoreGateSvc"
	 << endreq;
    return sc;
  }
  
  sc = service("THistSvc", m_thistSvc);
  if(sc.isFailure()){
    mLog << MSG::ERROR 
         << "Unable to retrieve pointer to THistSvc"
	 << endreq;
    return sc;
  }

  IToolSvc * toolSvc;
  service("ToolSvc", toolSvc);

  IAlgTool *tmp_analysisTools;
  toolSvc->retrieveTool("AnalysisTools", tmp_analysisTools);
  m_analysisTools = dynamic_cast<IAnalysisTools *>(tmp_analysisTools);

  IAlgTool *tmp_eventTool;
  toolSvc->retrieveTool("EventTool", tmp_eventTool);
  m_eventTool = dynamic_cast<IEventTool *>(tmp_eventTool);

  IAlgTool *tmp_tagTool;
  toolSvc->retrieveTool("EventTagTool", tmp_tagTool);
  m_tagTool = dynamic_cast<IEventTagTool *>(tmp_tagTool);

  IAlgTool *tmp_decayTool;
  toolSvc->retrieveTool("DecayVector", tmp_decayTool);
  m_truthVector = dynamic_cast<IDecayVector *>(tmp_decayTool);

  IAlgTool *tmp_histogramTool;
  toolSvc->retrieveTool("BUSTopHistogrammer", tmp_histogramTool);
  m_histogrammer = dynamic_cast<IBUSTopHistogrammer *>(tmp_histogramTool);

  registerHistograms();

  if(m_truthAvailable == true && m_dumpTruth == true){
    std::ofstream fout("TruthDump.dat");
    fout << "<root>" << std::endl;
  }
  
  return StatusCode::SUCCESS;
}

void BUSTopHistogramDump::registerHistograms(){
  h_full_muon = new MuonHistograms(m_histogrammer, "HistogramDump", "Muon", "hd_muon");
  h_full_elec = new ElectronHistograms(m_histogrammer, "HistogramDump", "Electron", "hd_elec");
  h_full_met = new METHistograms(m_histogrammer, "HistogramDump", "MET", "hd_met");
  h_full_bjet = new JetHistograms(m_histogrammer, "HistogramDump", "BJet", "hd_bjet", m_jetWeightTagger);
  h_full_ljet = new JetHistograms(m_histogrammer, "HistogramDump", "LJet", "hd_ljet", m_jetWeightTagger);
}

StatusCode BUSTopHistogramDump::finalize() {
  MsgStream mLog( messageService(), name() );

  if(m_truthAvailable == true && m_dumpTruth == true){
    std::ofstream fout("TruthDump.dat", std::ios_base::app);
    fout << "</root>" << std::endl;
  }

  return StatusCode::SUCCESS;
}

//////////////////////////////////////////////////////////////////////////////////
/// Execute - called by the event loop on event by event

StatusCode BUSTopHistogramDump::execute() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << "execute()" << endreq;

  getEventWeight();  
  getStoregateContainers();

  if(muonTES != 0){
    mLog << MSG::DEBUG << "plotting muons " << muonTES->size() << endreq;
    plotMuons();
  }

  if(elecTES != 0){
    mLog << MSG::DEBUG << "plotting elec " << elecTES->size() << endreq;
    plotElectrons();
  }
  
  if(metTES != 0){
    mLog << MSG::DEBUG << "plotting met " << endreq;
    h_full_met->plot(metTES, m_eventWeight);
  }

  if(bjetTES != 0){
    mLog << MSG::DEBUG << "plotting bjets " << bjetTES->size() << endreq;
    IParticleFilter filter, etaFilter;
    filter.setPtMin(m_bjetPtMin*GeV);

    etaFilter.setEtaMin(m_bjetEtaMin);
    etaFilter.setEtaMax(m_bjetEtaMax);

    if(m_doOverlapRemoval){
      JetCollection* jc = electronOverlapRemoval(bjetTES);
      plotJets(jc, h_full_bjet, filter, etaFilter, m_inclusiveBJetEta);
      delete jc;
    }else{
      plotJets(bjetTES, h_full_bjet, filter, etaFilter, m_inclusiveBJetEta);
    }
  }

  if(ljetTES != 0){
    mLog << MSG::DEBUG << "plotting ljets " << ljetTES->size() << endreq;
    IParticleFilter filter, etaFilter;
    filter.setPtMin(m_ljetPtMin*GeV);

    etaFilter.setEtaMin(m_ljetEtaMin);
    etaFilter.setEtaMax(m_ljetEtaMax);

    if(m_doOverlapRemoval){
      JetCollection* jc = electronOverlapRemoval(ljetTES);
      plotJets(jc, h_full_ljet, filter, etaFilter, m_inclusiveJetEta);
      delete jc;
    }else{
      plotJets(ljetTES, h_full_ljet, filter, etaFilter, m_inclusiveJetEta);
    }
  }

  if(m_truthAvailable == true && m_dumpTruth == true){
    dumpTruth();
  }

  clearParticleContainers();

  return StatusCode::SUCCESS;
}

void BUSTopHistogramDump::plotMuons(){
  IParticleFilter filter, etaFilter;
  filter.setPtMin(m_muonPtMin*GeV);
  etaFilter.setEtaMin(m_muonEtaMin);
  etaFilter.setEtaMax(m_muonEtaMax);

  int muonCount = 0;
  Analysis::MuonContainer::const_iterator iter = muonTES->begin();
  Analysis::MuonContainer::const_iterator iterEnd = muonTES->end();
  while(iter < iterEnd){
    if(filter.isAccepted(*iter) && etaFilter.isAccepted(*iter) == m_inclusiveMuonEta){
      h_full_muon->plot(*iter, m_eventWeight);      
      muonCount++;
    }
    iter++;
  }
  
  h_full_muon->n[0]->Fill(muonCount, m_eventWeight);
}

void BUSTopHistogramDump::plotElectrons(){
  MsgStream mLog( messageService(), name() );

  IParticleFilter filter, etaFilter;
  filter.setPtMin(m_elecPtMin*GeV);
  etaFilter.setEtaMin(m_elecEtaMin);
  etaFilter.setEtaMax(m_elecEtaMax);

  int elecCount = 0;
  ElectronContainer::const_iterator iter = elecTES->begin();
  ElectronContainer::const_iterator iterEnd = elecTES->end();
  while(iter < iterEnd){
    if(filter.isAccepted(*iter) && etaFilter.isAccepted(*iter) == m_inclusiveElectronEta){
      h_full_elec->plot(*iter, m_eventWeight);      
      elecCount++;
    }
    iter++;
  }
  
  h_full_elec->n[0]->Fill(elecCount, m_eventWeight);

  int loose = 0;
  int medium = 0;
  int tight = 0;
  int author = 0;

  iter = elecTES->begin();
  iterEnd = elecTES->end();
  while(iter < iterEnd){

    if((*iter)->author() == egammaParameters::AuthorElectron){
      author++;
    }

    if((*iter)->isem(egammaPID::ElectronLoose) == 0){
      loose++;
    }

    if((*iter)->isem(egammaPID::ElectronMedium) == 0){
      medium++;
    }

    if((*iter)->isem(egammaPID::ElectronTight) == 0){
      tight++;
    }
    iter++;
  }

  mLog << MSG::DEBUG << "elecTES->size() = " << elecTES->size() << endreq;
  mLog << MSG::DEBUG << "Authos = " << author << endreq;
  mLog << MSG::DEBUG << "Loose = " << loose << endreq;
  mLog << MSG::DEBUG << "Medium = " << medium << endreq;
  mLog << MSG::DEBUG << "Tight = " << tight << endreq;
}

void BUSTopHistogramDump::plotJets(const JetCollection* jc, JetHistograms* h, IParticleFilter& filter, IParticleFilter& etaFilter, bool etaResult){
  int jetCount = 0;
  JetCollection::const_iterator iter = jc->begin();
  JetCollection::const_iterator iterEnd = jc->end();
  while(iter < iterEnd){
    if(filter.isAccepted(*iter) && etaFilter.isAccepted(*iter) == etaResult){
      h->plot(*iter, m_eventWeight);      
      jetCount++;
    }
    iter++;
  }
  
  h->n[0]->Fill(jetCount, m_eventWeight);
}


void BUSTopHistogramDump::getStoregateContainers(){
  MsgStream mLog( messageService(), name() );

  muonTES = 0;
  m_storeGate->retrieve(muonTES, m_inputMuonContainerName);
  if(muonTES == 0){
    mLog << MSG::ERROR << "Problem getting Input MuonContainer" << endreq;
  }

  elecTES = 0;
  m_storeGate->retrieve(elecTES, m_inputElectronContainerName);
  if(elecTES == 0){
    mLog << MSG::ERROR << "Problem getting Input ElecContainer" << endreq;
  }

  metTES = 0;
  m_storeGate->retrieve(metTES, m_inputMetContainerName);
  if(metTES == 0){
    mLog << MSG::ERROR << "Problem getting Input MetContainer" << endreq;
  }

  bjetTES = 0;
  m_storeGate->retrieve(bjetTES, m_inputBJetContainerName);
  if(bjetTES == 0){
    mLog << MSG::ERROR << "Problem getting Input BJetContainer" << endreq;
  }

  ljetTES = 0;
  m_storeGate->retrieve(ljetTES, m_inputLJetContainerName);
  if(ljetTES == 0){
    mLog << MSG::ERROR << "Problem getting Input ljetContainer" << endreq;
  }

  if(m_truthAvailable){
    mcTES = 0;
    m_storeGate->retrieve(mcTES, "SpclMC");
    if(mcTES == 0){
      mLog << MSG::ERROR << "Problem getting Input Truth Container" << endreq;
    }
  }
}

void BUSTopHistogramDump::clearParticleContainers(){
  muonTES = 0;
  elecTES = 0;
  metTES = 0;
  bjetTES = 0;
  ljetTES = 0;

  mcTES = 0;
}

void BUSTopHistogramDump::getEventWeight(){
  if(m_tagTool->tagged(IEventTagTool::IS_ATLFAST) == false && m_tagTool->tagged(IEventTagTool::IS_MC) == true){  
    m_eventWeight = m_eventTool->getEventWeight();
  }else{
    m_eventWeight = 1.0;
  }
}

void BUSTopHistogramDump::dumpTruth(){
  //Get TruthVector of particles, including top siblings
  //Print out masses, momenta, energy, barcode and parent's barcode (0 if its a root node)

  m_truthVector->fill(mcTES, PDG::t, true);
  TruthParticleContainer::const_iterator iter = m_truthVector->getTruthVector()->begin();
  TruthParticleContainer::const_iterator iterEnd = m_truthVector->getTruthVector()->end();

  std::ofstream fout("TruthDump.dat", std::ios_base::app);
  fout << "<event>" << std::endl;
  while(iter != iterEnd){
    fout << "<particle>" << std::endl;
    fout << "<attribute name=\"pdgID\" value=\""<< (*iter)->pdgId() << "\" />" << std::endl;
    fout << "<attribute name=\"Barcode\" value=\"" << (*iter)->barcode() << "\" />" << std::endl;
    if((*iter)->nParents() > 0){
      fout << "<attribute name=\"ParentBarcode\" value=\"" << (*iter)->mother(0)->barcode() << "\" />" << std::endl;
      fout << "<attribute name=\"parentPdgID\" value=\""<< (*iter)->mother(0)->pdgId() << "\" />" << std::endl;
    }
    fout << "<attribute name=\"Energy\" value=\"" << (*iter)->e()/GeV << "\" />" << std::endl;
    fout << "<attribute name=\"Mass\" value=\"" << (*iter)->m()/GeV << "\" />" << std::endl;
    fout << "<attribute name=\"Px\" value=\"" << (*iter)->px()/GeV << "\" />" << std::endl;
    fout << "<attribute name=\"Py\" value=\"" << (*iter)->py()/GeV << "\" />" << std::endl;
    fout << "<attribute name=\"Pz\" value=\"" << (*iter)->pz()/GeV << "\" />" << std::endl;
    fout << "<attribute name=\"Eta\" value=\"" << (*iter)->eta() << "\" />" << std::endl;
    fout << "<attribute name=\"Phi\" value=\"" << (*iter)->phi() << "\" />" << std::endl;
    fout << "</particle>" << std::endl;

    iter++;
  }
  fout << "</event>" << std::endl;
  fout.close();
}

JetCollection* BUSTopHistogramDump::electronOverlapRemoval(const JetCollection* jcTES){
  JetCollection* jc = new JetCollection(SG::VIEW_ELEMENTS);

  JetCollection::const_iterator jet = jcTES->begin();
  JetCollection::const_iterator jetEnd = jcTES->end();

  while(jet < jetEnd){
    ElectronContainer::const_iterator elec = elecTES->begin();
    ElectronContainer::const_iterator elecEnd = elecTES->end();

    bool result = true;
    while(elec < elecEnd){
      double deltaR = AnalysisUtils::Delta::R(*jet, *elec);
      if(deltaR < 0.1){
        result = false;
      }

      elec++;
    }

    if(result == true){
      jc->push_back(*jet);
    }

    jet++;
  }

  return jc;
}
