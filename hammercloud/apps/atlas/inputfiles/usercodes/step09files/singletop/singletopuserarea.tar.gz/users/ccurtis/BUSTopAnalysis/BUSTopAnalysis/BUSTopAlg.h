#ifndef BUSTOP_ALG_H
#define BUSTOP_ALG_H

#include "GaudiKernel/Algorithm.h"

#include "CLHEP/Units/SystemOfUnits.h"

#include "StoreGate/StoreGateSvc.h"

#include "GaudiKernel/ToolHandle.h"

#include <stdint.h>
#include <string>

class ITHistSvc;
class TH1F;
class TH2F;

class IAnalysisTools;
class ParticleJet;
class IEventTool;
class IEventTagTool;

class BUSTopAlg : public Algorithm {

 public:

   BUSTopAlg(const std::string& name, ISvcLocator* pSvcLocator);
   ~BUSTopAlg();

   StatusCode initialize();
   StatusCode finalize();
   StatusCode execute();
  
 private:
   StoreGateSvc*  m_storeGate;
   ITHistSvc*     m_histSvc;
   IEventTool*    m_eventTool;
   IEventTagTool* m_tagTool;

   double m_eventCount;
   double m_eventWeight;

   TH1F* h_eventCount;
   TH1F* h_eventWeight;

   virtual void registerHistograms();
   virtual void getEventWeight();
};

#endif // BUSTOP_ALG_H


