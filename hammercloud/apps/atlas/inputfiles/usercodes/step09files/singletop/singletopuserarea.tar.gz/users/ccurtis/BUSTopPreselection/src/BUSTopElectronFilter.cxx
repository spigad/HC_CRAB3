#include "GaudiKernel/IToolSvc.h"
#include "GaudiKernel/ITHistSvc.h"

#include "TH1.h"
#include "TH2.h"

#include "McParticleEvent/TruthParticle.h"
#include "McParticleEvent/TruthParticleContainer.h"
#include "egammaEvent/ElectronContainer.h"

#include "DataModel/ElementLink.h"
#include "JetTagInfo/TruthInfo.h"

#include "AnalysisTools/IAnalysisTools.h"
#include "AnalysisUtils/IParticleFilter.h"

#include "BUSTopTools/EventTool.h"
#include "BUSTopTools/EventTagTool.h"

#include "BUSTopPreselection/BUSTopElectronFilter.h"

#include <stdint.h>
#include <algorithm>
#include <math.h>
#include <functional>

BUSTopElectronFilter::BUSTopElectronFilter(const std::string& name, ISvcLocator* pSvcLocator) : 
                     Algorithm(name, pSvcLocator){

  declareProperty("ElectronInputContainer", m_inputElectronContainerName);
  declareProperty("ElectronOutputContainer", m_outputElectronContainerName);
  declareProperty("RejectedOutputContainer", m_rejectedContainerName);
  declareProperty("FilterLevel", m_filterLevel);

  declareProperty("TruthAvailable", m_truthAvailable);
}

BUSTopElectronFilter::~BUSTopElectronFilter(){
}

StatusCode BUSTopElectronFilter::initialize() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << "Initializing BUSTopElectronFilter" << endreq;

  if (service("StoreGateSvc", m_storeGate).isFailure()) {
     mLog << MSG::ERROR << "Unable to retrieve pointer to StoreGateSvc" << endreq;
     return StatusCode::FAILURE;
  }

  service("THistSvc", m_histSvc);

  IToolSvc * toolSvc;
  service("ToolSvc", toolSvc);

  IAlgTool *tmp_eventTool;
  toolSvc->retrieveTool("EventTool", tmp_eventTool);
  m_eventTool = dynamic_cast<IEventTool *>(tmp_eventTool);

  IAlgTool *tmp_eventTagTool;
  toolSvc->retrieveTool("EventTagTool", tmp_eventTagTool);
  m_tagTool = dynamic_cast<IEventTagTool *>(tmp_eventTagTool);


  registerHistograms();

  return StatusCode::SUCCESS;
}

void BUSTopElectronFilter::registerHistograms(){
}

StatusCode BUSTopElectronFilter::finalize() {
  MsgStream mLog( messageService(), name() );
  
  return StatusCode::SUCCESS;
}

StatusCode BUSTopElectronFilter::execute() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << "execute()" << endreq;

  getEventWeight();
  getStoregateContainers();
  createTemporaryContainers();

  filterElectrons();

  registerContainers();
  destroyTemporaryContainers();

  StatusCode sc = StatusCode::SUCCESS;

  return sc;

}

void BUSTopElectronFilter::getStoregateContainers(){
  MsgStream mLog( messageService(), name() );

  elecTES = 0;

  m_storeGate->retrieve(elecTES, m_inputElectronContainerName);
  if(elecTES == 0){
    mLog << MSG::ERROR << "Problem getting input ElectronContainer" << endreq;
  }
}

void BUSTopElectronFilter::createTemporaryContainers(){
  c_filtered_electrons = new ElectronContainer(SG::VIEW_ELEMENTS);
  c_rejected_electrons = new ElectronContainer(SG::VIEW_ELEMENTS);
}

void BUSTopElectronFilter::destroyTemporaryContainers(){
  delete c_filtered_electrons;
  c_filtered_electrons = 0;

  delete c_rejected_electrons;
  c_rejected_electrons = 0;
}

void BUSTopElectronFilter::registerContainers(){
  registerContainer(c_filtered_electrons, m_outputElectronContainerName);
  registerContainer(c_rejected_electrons, m_rejectedContainerName);
}

void BUSTopElectronFilter::registerContainer(ElectronContainer* e, std::string n){
  MsgStream mLog( messageService(), name() );

  ElectronContainer* tmp = new ElectronContainer();

  m_storeGate->record(tmp, n);

  ElectronContainer::iterator eIter = e->begin();
  ElectronContainer::iterator eIterEnd = e->end();

  while(eIter < eIterEnd){
    tmp->push_back(new Analysis::Electron(**eIter));
    eIter++;
  }

  AnalysisUtils::Sort::pT(tmp);

  m_storeGate->setConst(tmp);

  if(tmp->size() > 1){
    mLog << MSG::DEBUG << "Electron Pt: " << tmp->at(0)->pt() << endreq;
    mLog << MSG::DEBUG << "Electron Pt: " << tmp->at(1)->pt() << endreq;
  }
}

void BUSTopElectronFilter::filterElectrons(){
  MsgStream mLog( messageService(), name() );

  ElectronContainer::const_iterator eIter = elecTES->begin();
  ElectronContainer::const_iterator eIterEnd = elecTES->end();

  //filter on central region eta
  //filter out cracks

  int fl = egammaPID::ElectronLoose;

  if(m_filterLevel == "Tight"){
    fl = egammaPID::ElectronTight;
  }else if(m_filterLevel == "Medium"){
    fl = egammaPID::ElectronMedium;
  }

  while(eIter < eIterEnd){
    if((*eIter)->isem(fl) == 0){
      c_filtered_electrons->push_back(*eIter);
    }else{
      c_rejected_electrons->push_back(*eIter);
    }
    eIter++;
  }

  mLog << MSG::DEBUG << "done filtering electrons..." << endreq;
}

void BUSTopElectronFilter::getEventWeight(){
  if(m_tagTool->tagged(IEventTagTool::IS_ATLFAST) == false && m_tagTool->tagged(IEventTagTool::IS_MC) == true){
    m_eventWeight = m_eventTool->getEventWeight();
  }else{
    m_eventWeight = 1.0;
  }
}

