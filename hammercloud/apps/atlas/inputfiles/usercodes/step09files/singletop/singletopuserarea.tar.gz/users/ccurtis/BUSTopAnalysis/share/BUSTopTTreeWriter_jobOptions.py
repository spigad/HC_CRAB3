if DoSelection:
        from BUSTopAnalysis.BUSTopAnalysisConf import BUSTopTTreeWriter

        Sequencer += BUSTopTTreeWriter()
        BUSTopTTreeWriter.OutputLevel = WARNING

        BUSTopTTreeWriter.InputElectronContainer  = BUSTopPreselection.InputElectronContainer
        BUSTopTTreeWriter.InputBJetContainer      = BUSTopPreselection.InputBJetContainer
        BUSTopTTreeWriter.InputLightJetContainer  = BUSTopSelection.SortedLJetContainer
       	BUSTopTTreeWriter.InputMuonContainer      = BUSTopPreselection.InputMuonContainer
       	BUSTopTTreeWriter.InputMETContainer       = BUSTopJES.METOutputContainer

        BUSTopTTreeWriter.InputNeutrinoContainer  = BUSTopNuRecon_Selection.OutputNeutrinoContainer
        BUSTopTTreeWriter.InputWContainer         = BUSTopWRecon_Selection.OutputWName
        BUSTopTTreeWriter.InputTopContainer       = BUSTopTRecon_Selection.OutputTops

        BUSTopTTreeWriter.TruthAvailable          = DoTruth
        BUSTopTTreeWriter.JetWeightTagger         = RootJetTagger
