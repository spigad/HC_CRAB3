if DoSelection:
        from BUSTopAnalysis.BUSTopAnalysisConf import BUSTopSelection

        Sequencer += BUSTopSelection()
        BUSTopSelection.OutputLevel = WARNING

        if TriggerLevel_Selection:
                BUSTopSelection.FilterTags              = [TRIGGERED]
        else:
                BUSTopSelection.FilterTags              = [PRESELECTION]

        BUSTopSelection.InputElectronContainer  = BUSTopPreselection.InputElectronContainer
        BUSTopSelection.InputBJetContainer      = BUSTopPreselection.InputBJetContainer
        BUSTopSelection.InputLightJetContainer  = BUSTopPreselection.InputLightJetContainer
       	BUSTopSelection.InputMuonContainer      = BUSTopPreselection.InputMuonContainer
       	BUSTopSelection.InputMETContainer       = BUSTopJES.METOutputContainer

        BUSTopSelection.OutputElectronContainer = "SelectionElectrons"
        BUSTopSelection.OutputMuonContainer     = "SelectionMuons"
        BUSTopSelection.OutputB1JetContainer    = "SelectionB1Jets"
        BUSTopSelection.OutputB3JetContainer    = "SelectionB3Jets"
        BUSTopSelection.OutputLJetContainer     = "SelectionLightJets"
        BUSTopSelection.SortedLJetContainer     = "SortedSelectionLightJets"

        BUSTopSelection.TruthAvailable          = DoTruth
        BUSTopSelection.JetWeightTagger         = RootJetTagger

        BUSTopSelection.ApplySecondaryBJetCut   = 0		#True if isolation requirement to be applied
        BUSTopSelection.SecondaryBJetCut        = 45
        BUSTopSelection.B1Selection             = "Pt"		#Pt, E, Et, Weight - top when ordered
							      	#CSC - Pt ordered
								#TMVA - doesn't do anything

        BUSTopSelection.LJSelection             = "E"		#Pt, E, Et - top when ordered

        BUSTopSelection.ApplyLeptonIsolation    = 0		#True if isolation requirement to be applied
        BUSTopSelection.LeptonIsolationCut      = 6		#etcone20 no higher than this in GeV

        BUSTopSelection.ApplySecondaryLeptonCut = 0		#True if isolation requirement to be applied
        BUSTopSelection.SecondaryLeptonCut      = 15		#Allow other leptons with a pt no higher than this.
        BUSTopSelection.DoMuon                  = 1		#Search for muons
        BUSTopSelection.DoElectron              = 1		#Search for electrons


