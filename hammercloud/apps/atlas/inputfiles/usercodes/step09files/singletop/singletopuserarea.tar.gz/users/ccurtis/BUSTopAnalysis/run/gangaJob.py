j = Job()
j.name='5502'
j.application=Athena()
j.application.option_file=[
'/disk/f8b/home/mws/hc/chris/14.5.0.5/users/ccurtis/BUSTopAnalysis/run/BUSTop.py'
 ]
j.application.prepare()
j.splitter=DQ2JobSplitter()
#j.splitter.numsubjobs=
#j.splitter.use_blacklist = False
j.inputdata=DQ2Dataset()
j.inputdata.dataset='mc08.105502.AcerMC_tchan.recon.AOD.e352_s462_r541/'
j.outputdata=DQ2OutputDataset()
#j.outputdata.outputdata=['BUSTopAlg.root', 'BUSTopAlgTrees.root']
j.backend=Panda()

j.submit()


