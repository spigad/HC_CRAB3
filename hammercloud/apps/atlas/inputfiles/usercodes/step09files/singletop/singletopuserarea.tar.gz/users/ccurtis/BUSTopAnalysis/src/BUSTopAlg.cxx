#include "GaudiKernel/IToolSvc.h"
#include "GaudiKernel/ITHistSvc.h"

#include "TH1.h"
#include "TH2.h"

#include "AnalysisTools/IAnalysisTools.h"

#include "BUSTopTools/EventTool.h"
#include "BUSTopTools/EventTagTool.h"

#include "BUSTopAnalysis/BUSTopAlg.h"

BUSTopAlg::BUSTopAlg(const std::string& name, ISvcLocator* pSvcLocator) : 
                     Algorithm(name, pSvcLocator){
  m_eventCount = 0;
}

BUSTopAlg::~BUSTopAlg(){
}

StatusCode BUSTopAlg::initialize() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << "Initializing BUSTopAlg " << endreq;

  if (service("StoreGateSvc", m_storeGate).isFailure()) {
     mLog << MSG::ERROR << "Unable to retrieve pointer to StoreGateSvc" << endreq;
     return StatusCode::FAILURE;
  }

  service("THistSvc", m_histSvc);

  IToolSvc * toolSvc;
  service("ToolSvc", toolSvc);

  IAlgTool *tmp_eventTool = 0;
  toolSvc->retrieveTool("EventTool", tmp_eventTool);
  m_eventTool = dynamic_cast<IEventTool *>(tmp_eventTool);

  IAlgTool *tmp_tagTool = 0;
  toolSvc->retrieveTool("EventTagTool", tmp_tagTool);
  m_tagTool = dynamic_cast<IEventTagTool *>(tmp_tagTool);

  registerHistograms();

  return StatusCode::SUCCESS;
}

void BUSTopAlg::registerHistograms(){
  std::stringstream fName, hName;
  std::string title;

  fName.str("");
  hName.str("");
  hName << "bust_eventCount";
  fName << "/AANT/BUSTopAlg/Event/" << hName.str();
  title = "Event Count";
  h_eventCount = new TH1F(hName.str().c_str(), title.c_str(), 1, 0, 1);
  m_histSvc->regHist(fName.str().c_str(), h_eventCount);

  fName.str("");
  hName.str("");
  hName << "bust_weight";
  fName << "/AANT/BUSTopAlg/Event/" << hName.str();
  title = "Event Weight";
  h_eventWeight = new TH1F(hName.str().c_str(), title.c_str(), 100, -5, 5);
  m_histSvc->regHist(fName.str().c_str(), h_eventWeight);
}

StatusCode BUSTopAlg::finalize() {
  MsgStream mLog( messageService(), name() );
  
  h_eventCount->Fill(0.0, m_eventCount);

  return StatusCode::SUCCESS;
}

StatusCode BUSTopAlg::execute() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << "execute()" << endreq;
 
  getEventWeight(); 
  m_eventCount += m_eventWeight;

  h_eventWeight->Fill(m_eventWeight, 1.0);

  StatusCode sc = StatusCode::SUCCESS;

  return sc;
}

void BUSTopAlg::getEventWeight(){
  if(m_tagTool->tagged(IEventTagTool::IS_ATLFAST) == false && m_tagTool->tagged(IEventTagTool::IS_MC) == true){  
    m_eventWeight = m_eventTool->getEventWeight();
  }else{
    m_eventWeight = 1.0;
  }
}

