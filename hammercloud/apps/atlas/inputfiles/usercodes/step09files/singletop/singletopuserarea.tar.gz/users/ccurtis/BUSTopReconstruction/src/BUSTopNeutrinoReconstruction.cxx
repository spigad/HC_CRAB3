#include "GaudiKernel/IToolSvc.h"
#include "GaudiKernel/ITHistSvc.h"

#include "TH1.h"
#include "TH2.h"
#include "TFile.h"

#include "McParticleEvent/TruthParticle.h"
#include "McParticleEvent/TruthParticleContainer.h"
#include "egammaEvent/ElectronContainer.h"
#include "egammaEvent/Electron.h"
#include "muonEvent/MuonContainer.h"

#include "MissingETEvent/MissingET.h"
#include "ParticleEvent/NeutrinoContainer.h"
#include "ParticleEvent/Neutrino.h"

#include "DataModel/ElementLink.h"

#include "AnalysisTools/IAnalysisTools.h"

#include "BUSTopTools/EventTool.h"
#include "BUSTopTools/EventTagTool.h"
#include "BUSTopTools/INuSolutionTool.h"

#include "BUSTopReconstruction/BUSTopNeutrinoReconstruction.h"

#include <stdint.h>
#include <algorithm>
#include <math.h>
#include <functional>

BUSTopNeutrinoReconstruction::BUSTopNeutrinoReconstruction(const std::string& name, ISvcLocator* pSvcLocator) : 
                     Algorithm(name, pSvcLocator){

  declareProperty("InputElectronContainer", m_electronContainerName);
  declareProperty("InputMuonContainer", m_muonContainerName);
  declareProperty("InputMETContainer", m_metContainerName);
  declareProperty("FilterTags", m_filterTags);
  declareProperty("OutputNeutrinoContainer", m_outputNeutrinoContainerName);
  declareProperty("TruthAvailable", m_truthAvailable);
  declareProperty("ExclusiveNeutrino", m_exclusiveNeutrino);
  declareProperty("ExclusiveOutputContainer", m_outputSelectedNeutrinoContainerName);
}

BUSTopNeutrinoReconstruction::~BUSTopNeutrinoReconstruction(){
}

StatusCode BUSTopNeutrinoReconstruction::initialize() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << "Initializing BUSTopNeutrinoReconstruction" << endreq;

  if (service("StoreGateSvc", m_storeGate).isFailure()) {
     mLog << MSG::ERROR << "Unable to retrieve pointer to StoreGateSvc" << endreq;
     return StatusCode::FAILURE;
  }

  service("THistSvc", m_histSvc);

  IToolSvc * toolSvc;
  service("ToolSvc", toolSvc);

  IAlgTool *tmp_eventTool = 0;
  toolSvc->retrieveTool("EventTool", tmp_eventTool);
  m_eventTool = dynamic_cast<IEventTool *>(tmp_eventTool);

  IAlgTool *tmp_tagTool = 0;
  toolSvc->retrieveTool("EventTagTool", tmp_tagTool);
  m_tagTool = dynamic_cast<IEventTagTool *>(tmp_tagTool);

  IAlgTool *tmp_nuSolTool;
  toolSvc->retrieveTool("NuSolutionTool", tmp_nuSolTool); 
  m_nuSolTool = dynamic_cast<INuSolutionTool *>(tmp_nuSolTool);

  registerHistograms();

  return StatusCode::SUCCESS;
}

void BUSTopNeutrinoReconstruction::registerHistograms(){
  std::stringstream fName, hName;
  std::string title;

  fName.str("");
  hName.str("");
  hName << "nr_recon";
  fName << "/AANT/NuReconstruction/" << m_outputNeutrinoContainerName << "/" << hName.str();
  title = "N Recon Pass";
  h_recon = new TH1F(hName.str().c_str(), title.c_str(), 1, 0, 1);
  m_histSvc->regHist(fName.str().c_str(), h_recon);

  fName.str("");
  hName.str("");
  hName << "nr_size";
  fName << "/AANT/NuReconstruction/" << m_outputNeutrinoContainerName << "/" << hName.str();
  title = "N Recon Size";
  h_size = new TH1F(hName.str().c_str(), title.c_str(), 10, 0, 10);
  m_histSvc->regHist(fName.str().c_str(), h_size);
}

StatusCode BUSTopNeutrinoReconstruction::finalize() {
  MsgStream mLog( messageService(), name() );
  
  return StatusCode::SUCCESS;
}

StatusCode BUSTopNeutrinoReconstruction::execute() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << "execute()" << endreq;

  getEventWeight();
  getStoregateContainers();
  createTemporaryContainers();

  if(m_tagTool->allTagged(m_filterTags)){
    mLog << MSG::DEBUG << "Reconstructing Neutrinos..." << endreq;
    reconstructNeutrinos();
  }

  if((c_muonNeutrinos->size() + c_elecNeutrinos->size()) > 1 && m_exclusiveNeutrino){
    filterNeutrinos();
  }

  registerContainers();
  destroyTemporaryContainers();
 
  return StatusCode::SUCCESS;
}

void BUSTopNeutrinoReconstruction::getEventWeight(){
  if(m_tagTool->tagged(IEventTagTool::IS_ATLFAST) == false && m_tagTool->tagged(IEventTagTool::IS_MC) == true){
    m_eventWeight = m_eventTool->getEventWeight();
  }else{
    m_eventWeight = 1.0;
  }
}

void BUSTopNeutrinoReconstruction::getStoregateContainers(){
  MsgStream mLog( messageService(), name() );
  
  metTES = 0;
  m_storeGate->retrieve(metTES, m_metContainerName);
  if(metTES == 0){
    mLog << MSG::ERROR << "Could not retrieve MET Container from Storegate" << endreq;
  }
  
  elecTES = 0;
  m_storeGate->retrieve(elecTES, m_electronContainerName);
  if(elecTES == 0){
    mLog << MSG::ERROR << "Could not retrieve Electron Container from Storegate" << endreq;
  }
  
  muonTES = 0;
  m_storeGate->retrieve(muonTES, m_muonContainerName);
  if(muonTES == 0){  
    mLog << MSG::ERROR << "Could not retrieve Muon Container from Storegate" << endreq;
  }
}

void BUSTopNeutrinoReconstruction::createTemporaryContainers(){
  c_muonNeutrinos = new NeutrinoContainer(SG::OWN_ELEMENTS);
  c_elecNeutrinos = new NeutrinoContainer(SG::OWN_ELEMENTS);
  c_filteredNeutrino = new NeutrinoContainer(SG::OWN_ELEMENTS);
}

void BUSTopNeutrinoReconstruction::registerContainers(){
  MsgStream mLog( messageService(), name() );
  
  mLog << MSG::DEBUG << "registerReconstructed()" << endreq;

  if(m_exclusiveNeutrino){
    registerContainer(c_filteredNeutrino, m_outputNeutrinoContainerName);
    h_recon->Fill(0.0, m_eventWeight);
    h_size->Fill(c_filteredNeutrino->size(), m_eventWeight);
  }else{
    NeutrinoContainer* merged = mergeContainers(c_elecNeutrinos, c_muonNeutrinos);
    registerContainer(merged, m_outputNeutrinoContainerName);
    h_recon->Fill(0.0, m_eventWeight);
    h_size->Fill(merged->size(), m_eventWeight);
  }
}

NeutrinoContainer* BUSTopNeutrinoReconstruction::mergeContainers(NeutrinoContainer* a, NeutrinoContainer* b){
  NeutrinoContainer* c = new NeutrinoContainer(SG::OWN_ELEMENTS);

  NeutrinoContainer::const_iterator iter = a->begin();
  NeutrinoContainer::const_iterator iterEnd = a->end();

  while(iter < iterEnd){
    c->push_back(new Neutrino(**iter));
    iter++;
  }

  iter = b->begin();
  iterEnd = b->end();

  while(iter < iterEnd){
    c->push_back(new Neutrino(**iter));
    iter++;
  }

  return c;
}

void BUSTopNeutrinoReconstruction::registerContainer(NeutrinoContainer* c, std::string n){
  m_storeGate->record(c, n);
  m_storeGate->setConst(c);
}

void BUSTopNeutrinoReconstruction::destroyTemporaryContainers(){
  MsgStream mLog( messageService(), name() );
    
  mLog << MSG::DEBUG << "destroyTemporaryContainers(...)" << endreq;

  delete c_elecNeutrinos;
  delete c_muonNeutrinos;
}  

void BUSTopNeutrinoReconstruction::reconstructNeutrinos(){
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "reconstructNeutrinos()" << endreq;
  mLog << MSG::DEBUG << "tag size = " << m_tagTool->numberOfTags() << endreq;

  mLog << MSG::DEBUG << "testing filter tags..." << endreq;

  unsigned int elecTag = m_filterTags.at(0) + 1;
  unsigned int muonTag = m_filterTags.at(0) + 2;

  if(m_tagTool->tagged(muonTag) && muonTES->size() > 0){
    m_nuSolTool->getSolutions(muonTES->at(0), metTES, c_muonNeutrinos);
  }  

  if(m_tagTool->tagged(elecTag) && elecTES->size() > 0){
    m_nuSolTool->getSolutions(elecTES->at(0), metTES, c_elecNeutrinos);
  }  

  mLog << MSG::DEBUG << "Number of MuonNeutrinos: " << c_muonNeutrinos->size() << endreq;
  mLog << MSG::DEBUG << "Number of ElectronNeutrinos: " << c_elecNeutrinos->size() << endreq;
}

void BUSTopNeutrinoReconstruction::filterNeutrinos(){
  int size = 0; 

  unsigned int elecTag = m_filterTags.at(0) + 1;
  unsigned int muonTag = m_filterTags.at(0) + 2;

  if(m_tagTool->tagged(muonTag) && muonTES->size() > 0){
    size = 2;
  }

  if(m_tagTool->tagged(elecTag) && elecTES->size() > 0){
    size += 1;
  }

  NeutrinoContainer* tmp = 0;

  if(size == 3){
    if(muonTES->at(0)->pt() > elecTES->at(0)->pt()){
      tmp = c_muonNeutrinos;
    }else{
      tmp = c_elecNeutrinos;
    }
  }else if(size == 2){
    tmp = c_muonNeutrinos;
  }else if(size == 1){
    tmp = c_elecNeutrinos;
  }

  if(tmp != 0){
    int index = 0;
    int i = 0;
    double eta = 10.0;
    NeutrinoContainer::const_iterator iter = tmp->begin();
    NeutrinoContainer::const_iterator iterEnd = tmp->end();

    while(iter < iterEnd){
      if(fabs((*iter)->eta()) < eta){
        eta = fabs((*iter)->eta());
        index = i;
      }
      i++;
      iter++;
    }

    c_filteredNeutrino->push_back(new Neutrino(*(tmp->at(index))));
    m_tagTool->tag(IEventTagTool::NUSELECTION);
  }
}
