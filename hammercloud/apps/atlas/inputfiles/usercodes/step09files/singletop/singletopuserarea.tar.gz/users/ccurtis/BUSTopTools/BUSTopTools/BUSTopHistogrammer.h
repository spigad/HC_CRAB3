#ifndef BUSTOP_HISTOGRAMMER_H
#define BUSTOP_HISTOGRAMMER_H

#include "GaudiKernel/AlgTool.h"
#include "GaudiKernel/MsgStream.h"
#include "GaudiKernel/AlgFactory.h"
#include "StoreGate/StoreGateSvc.h"
#include "StoreGate/DataHandle.h"
#include "AIDA/IHistogram1D.h"
#include "AIDA/IHistogram2D.h"
#include "GaudiKernel/ITHistSvc.h"
#include "EventKernel/PdtPdg.h"

#include "BUSTopTools/IBUSTopHistogrammer.h"

class TH1F;
class TH2F;

class BUSTopHistogrammer: virtual public IBUSTopHistogrammer, public AlgTool{
   public:
     BUSTopHistogrammer(const std::string&, const std::string&, const IInterface*);
     virtual ~BUSTopHistogrammer();
     virtual StatusCode initialize();
     virtual StatusCode finalize();

     virtual void registerHistogram(TH1I * &h, std::string fname, std::string hname, std::string title, std::string xname, int bins, double l, double u);
     virtual void registerHistogram(TH1F * &h, std::string fname, std::string hname, std::string title, std::string xname, int bins, double l, double u);
     virtual void registerHistogram(TH1I** &h, std::string fname, std::string hname, std::string title, std::string xname, int bins, double l, double u);
     virtual void registerHistogram(TH1F** &h, std::string fname, std::string hname, std::string title, std::string xname, int bins, double l, double u);
     virtual void registerHistogram(TH2F*  &h, std::string fname, std::string hname, std::string title,
                                               std::string xname, int xbins, double xl, double xu,
                                               std::string yname, int ybins, double yl, double yu);
     virtual void registerHistogram(TH2F** &h, std::string fname, std::string hname, std::string title,
                                               std::string xname, int xbins, double xl, double xu,
                                               std::string yname, int ybins, double yl, double yu);
     virtual void registerHistogram(TH3F** &h, std::string fname, std::string hname, std::string title,
                                               std::string xname, int xbins, double xl, double xu,
                                               std::string yname, int ybins, double yl, double yu,
                                               std::string zname, int zbins, double zl, double zu);

   private:
     mutable MsgStream m_log;
     mutable ITHistSvc* m_thistSvc;
};

#endif

