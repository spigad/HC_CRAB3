#include "GaudiKernel/IToolSvc.h"
#include "GaudiKernel/ITHistSvc.h"

#include "TH1.h"
#include "TH2.h"
#include "TFile.h"
#include "TMVA/Reader.h"

#include "McParticleEvent/TruthParticle.h"
#include "McParticleEvent/TruthParticleContainer.h"
#include "egammaEvent/ElectronContainer.h"
#include "egammaEvent/Electron.h"
#include "egammaEvent/egammaParamDefs.h"
#include "egammaEvent/EMShower.h"
#include "muonEvent/MuonContainer.h"
#include "muonEvent/MuonParamDefs.h"

#include "JetEvent/JetCollection.h"
#include "JetEvent/Jet.h"
#include "JetTagEvent/TrackAssociation.h"
#include "Particle/TrackParticleContainer.h"
#include "Particle/TrackParticle.h"

#include "MissingETEvent/MissingET.h"
#include "JetTagEvent/TrackConstituents.h"
#include "ParticleEvent/NeutrinoContainer.h"
#include "ParticleEvent/Neutrino.h"

#include "DataModel/ElementLink.h"
#include "JetTagInfo/TruthInfo.h"

#include "AnalysisTools/IAnalysisTools.h"

#include "BUSTopTools/EventTool.h"
#include "BUSTopTools/EventTagTool.h"
#include "BUSTopTools/INuSolutionTool.h"
#include "BUSTopTools/IBUSTopHistogrammer.h"

#include "BUSTopTools/KinematicHistograms.h"

#include "BUSTopAnalysis/BUSTopSelection.h"

#include <stdint.h>
#include <algorithm>
#include <math.h>
#include <functional>

BUSTopSelection::BUSTopSelection(const std::string& name, ISvcLocator* pSvcLocator) : 
                     Algorithm(name, pSvcLocator){

  declareProperty("InputElectronContainer", m_electronContainerName);
  declareProperty("InputBJetContainer", m_bJetContainerName);
  declareProperty("InputLightJetContainer", m_lightJetContainerName);
  declareProperty("InputMuonContainer", m_muonContainerName);
  declareProperty("InputMETContainer", m_metContainerName);

  declareProperty("OutputElectronContainer", m_selectedElectronContainerName);
  declareProperty("OutputMuonContainer", m_selectedMuonContainerName);
  declareProperty("OutputB1JetContainer", m_selectedB1JetContainerName);
  declareProperty("OutputB3JetContainer", m_selectedB3JetContainerName);
  declareProperty("OutputLJetContainer", m_selectedLJetContainerName);
  declareProperty("SortedLJetContainer", m_sortedLJetContainerName);

  declareProperty("TruthAvailable", m_truthAvailable);
  declareProperty("FilterTags", m_filterTags);

  declareProperty("LJSelection", m_ljSelectionMethod);

  declareProperty("ApplySecondaryLeptonCut", m_applySecondaryLeptonCut);
  declareProperty("SecondaryLeptonCut", m_secondaryLeptonCut);
  declareProperty("ApplyLeptonIsolation", m_applyLeptonIsolation);
  declareProperty("LeptonIsolationCut", m_leptonIsolationCut);
  declareProperty("DoMuon", m_doMuon);
  declareProperty("DoElectron", m_doElectron);


  declareProperty("ApplySecondaryBJetCut", m_applySecondaryBJetCut);
  declareProperty("SecondaryBJetCut", m_secondaryBJetCut);

  declareProperty("B1Selection", m_b1SelectionMethod);
  declareProperty("JetWeightTagger", m_jetWeightTagger);

  declareProperty("NuSelection", m_nuSelectionMethod);

}

BUSTopSelection::~BUSTopSelection(){
}

StatusCode BUSTopSelection::initialize() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << "Initializing BUSTopSelection" << endreq;

  if (service("StoreGateSvc", m_storeGate).isFailure()) {
     mLog << MSG::ERROR << "Unable to retrieve pointer to StoreGateSvc" << endreq;
     return StatusCode::FAILURE;
  }

  service("THistSvc", m_histSvc);

  IToolSvc * toolSvc;
  service("ToolSvc", toolSvc);

  IAlgTool *tmp_eventTool = 0;
  toolSvc->retrieveTool("EventTool", tmp_eventTool);
  m_eventTool = dynamic_cast<IEventTool *>(tmp_eventTool);

  IAlgTool *tmp_tagTool = 0;
  toolSvc->retrieveTool("EventTagTool", tmp_tagTool);
  m_tagTool = dynamic_cast<IEventTagTool *>(tmp_tagTool);

  IAlgTool *tmp_nuSolTool;
  toolSvc->retrieveTool("NuSolutionTool", tmp_nuSolTool); 
  m_nuSolTool = dynamic_cast<INuSolutionTool *>(tmp_nuSolTool);

  IAlgTool *tmp_histogramTool;
  toolSvc->retrieveTool("BUSTopHistogrammer", tmp_histogramTool);
  m_histogrammer = dynamic_cast<IBUSTopHistogrammer *>(tmp_histogramTool);

  registerHistograms();
  registerTTrees();

  return StatusCode::SUCCESS;
}

void BUSTopSelection::registerHistograms(){
  std::stringstream fName, hName;
  std::string title;

  h_primary_lepton = new KinematicHistograms(m_histogrammer, "Selection", "LeptonAnalysis", "sa_primary_lepton");
  h_secondary_lepton = new KinematicHistograms(m_histogrammer, "Selection", "LeptonAnalysis", "sa_secondary_lepton");

  h_primary_bjet = new KinematicHistograms(m_histogrammer, "Selection", "JetAnalysis", "sa_primary_bjet");
  h_secondary_bjet = new KinematicHistograms(m_histogrammer, "Selection", "JetAnalysis", "sa_secondary_bjet");

  h_primary_ljet = new KinematicHistograms(m_histogrammer, "Selection", "JetAnalysis", "sa_primary_ljet");
  h_secondary_ljet = new KinematicHistograms(m_histogrammer, "Selection", "JetAnalysis", "sa_secondary_ljet");

  fName.str("");
  hName.str("");
  hName << "sa_ljet_e_fraction";
  fName << "/AANT/Selection/" << "JetAnalysis" << "/" << hName.str();
  title = "E_{jet}^{Sec}/E_{jet}^{prim}";
  h_ljet_e_fraction = new TH1F(hName.str().c_str(), title.c_str(), 100, 0, 1.0);
  m_histSvc->regHist(fName.str().c_str(), h_ljet_e_fraction);

  fName.str("");
  hName.str("");
  hName << "sa_bjet_pt_fraction";
  fName << "/AANT/Selection/" << "JetAnalysis" << "/" << hName.str();
  title = "Pt_{jet}^{Sec}/Pt_{jet}^{prim}";
  h_bjet_pt_fraction = new TH1F(hName.str().c_str(), title.c_str(), 100, 0, 1.0);
  m_histSvc->regHist(fName.str().c_str(), h_bjet_pt_fraction);
}

void BUSTopSelection::registerTTrees(){
}

StatusCode BUSTopSelection::finalize() {
  MsgStream mLog( messageService(), name() );
  
  return StatusCode::SUCCESS;
}

StatusCode BUSTopSelection::execute() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << "execute()" << endreq;

  getEventWeight();
  getStoregateContainers();
  createTemporaryContainers();

  //only do Selection if appropriate pre-selection is tagged

  if(m_tagTool->allTagged(m_filterTags)){
    mLog << MSG::DEBUG << "Proceeding to select objects..." << endreq;

    selectLepton();
    selectB1Jets();
    selectLJets();
  }

  bool result = m_tagTool->tagged(IEventTagTool::LEPTON_SELECTION);
  mLog << MSG::DEBUG << "selectLepton(): result = " << result << endreq;
  result = m_tagTool->tagged(IEventTagTool::B1SELECTION);
  mLog << MSG::DEBUG << "selectBJets(): result = " << result << endreq;
  result = m_tagTool->tagged(IEventTagTool::LJSELECTION);
  mLog << MSG::DEBUG << "selectLJets(): result = " << result << endreq;

  registerSelected();

  destroyTemporaryContainers();

  mLog << MSG::DEBUG << "m_tagTool->tagged(IS_ATLFAST) = " << m_tagTool->tagged(IEventTagTool::IS_ATLFAST) << endreq;
 
  return StatusCode::SUCCESS;
}

void BUSTopSelection::getEventWeight(){
  if(m_tagTool->tagged(IEventTagTool::IS_ATLFAST) == false && m_tagTool->tagged(IEventTagTool::IS_MC) == true){  
    m_eventWeight = m_eventTool->getEventWeight();
  }else{
    m_eventWeight = 1.0;
  }
}

void BUSTopSelection::getStoregateContainers(){
  MsgStream mLog( messageService(), name() );
  
  metTES = 0;
  m_storeGate->retrieve(metTES, m_metContainerName);
  if(metTES == 0){
    mLog << MSG::ERROR << "Could not retrieve MET Container from Storegate" << endreq;
  }

  elecTES = 0;
  m_storeGate->retrieve(elecTES, m_electronContainerName);
  if(elecTES == 0){
    mLog << MSG::ERROR << "Could not retrieve Electron Container from Storegate" << endreq;
  }
  
  bjetTES = 0; 
  m_storeGate->retrieve(bjetTES, m_bJetContainerName);
  if(bjetTES == 0){
    mLog << MSG::ERROR << "Could not retrieve BJet Container from Storegate" << endreq;
  }
  
  ljetTES = 0;
  m_storeGate->retrieve(ljetTES, m_lightJetContainerName);
  if(ljetTES == 0){
    mLog << MSG::ERROR << "Could not retrieve LightJet Container from Storegate" << endreq;
  }
     
  muonTES = 0;
  m_storeGate->retrieve(muonTES, m_muonContainerName);
  if(muonTES == 0){  
    mLog << MSG::ERROR << "Could not retrieve Muon Container from Storegate" << endreq;
  }
}

void BUSTopSelection::createTemporaryContainers(){
  c_b1 = new JetCollection();
  c_b3 = new JetCollection();
  c_lj = new JetCollection();

  c_sortedLightJets = new JetCollection(SG::VIEW_ELEMENTS);

  c_electron = new ElectronContainer();
  c_muon = new Analysis::MuonContainer();
}

void BUSTopSelection::registerSelected(){
  MsgStream mLog( messageService(), name() );
  
  mLog << MSG::DEBUG << "registerSelected()" << endreq;

  registerSelected(c_b1, m_selectedB1JetContainerName);
  registerSelected(c_b3, m_selectedB3JetContainerName);

  registerSelected(c_lj, m_selectedLJetContainerName);
  registerSelected(c_sortedLightJets, m_sortedLJetContainerName);

  registerSelected(c_electron, m_selectedElectronContainerName);
  registerSelected(c_muon, m_selectedMuonContainerName);
}

template <class COLL>
void BUSTopSelection::registerSelected(COLL* c, std::string n){
  m_storeGate->record(c, n);
  m_storeGate->setConst(c);
}

void BUSTopSelection::destroyTemporaryContainers(){
  MsgStream mLog( messageService(), name() );
    
  mLog << MSG::DEBUG << "destroyTemporaryContainers(...)" << endreq;
}


void BUSTopSelection::selectLepton(){
  MsgStream mLog( messageService(), name() );

  //Select ONE lepton

  int flag = 0;

  if(m_doMuon){
    if(m_tagTool->tagged(m_filterTags.at(0) + 2) && muonTES->size() > 0){
      flag = 2;
    }
  }

  if(m_doElectron){
    if(m_tagTool->tagged(m_filterTags.at(0) + 1) && elecTES->size() > 0){
      flag += 1;
    }
  }

  if(flag == 3){
    if(elecTES->at(0)->pt() > muonTES->at(0)->pt()){
      selectElectron();
    }else{
      selectMuon();
    }
  }else if(flag == 2){
    selectMuon();
  }else if(flag == 1){
    selectElectron();
  }
}

void BUSTopSelection::selectElectron(){
  /**
   *  Histogramming part...
   *
   *  Plot the primary electron kinematics, then find the next largest pt lepton
   *  and plot that too :-)
   */

  h_primary_lepton->plot(elecTES->at(0), m_eventWeight);
  
  double secElecPt = 0.0;
  bool secLep = false;
  if(elecTES->size() > 1){
    secLep = true;
    secElecPt = elecTES->at(1)->pt();
  }

  double secMuonPt = 0.0;
  if(muonTES->size() > 0){
    secLep = true;
    secMuonPt = muonTES->at(0)->pt();
  }

  if(secLep == true){
    if(secMuonPt > secElecPt){
      h_secondary_lepton->plot(muonTES->at(0), m_eventWeight);
    }else{
      h_secondary_lepton->plot(elecTES->at(1), m_eventWeight);
    }
  }

  /**
   *  Selection part :-)
   */

  if(m_applySecondaryLeptonCut){
    if(elecTES->size() > 1 && elecTES->at(1)->pt() > m_secondaryLeptonCut*GeV){
      //Failed the selection as there is another lepton with a high pt
      return;
    }

    if(muonTES->size() > 0 && muonTES->at(0)->pt() > m_secondaryLeptonCut*GeV){
      //Failed the selection as there is another lepton with a high pt
      return;
    }
  }

  if(m_applyLeptonIsolation){
    const EMShower* m_EMShower = elecTES->at(0)->detail<EMShower>("egDetailAOD");
    if(m_EMShower->parameter(egammaParameters::etcone20) > m_leptonIsolationCut*GeV){
      //Failed the isolation cut
      return;
    }
  }

  m_tagTool->tag(IEventTagTool::LEPTON_SELECTION);
  m_tagTool->tag(IEventTagTool::ELECTRON_SELECTION);
  c_electron->push_back(new Analysis::Electron(*(elecTES->at(0))));  
}

void BUSTopSelection::selectMuon(){
  /**
   *  Histogramming part...
   *
   *  Plot the primary electron kinematics, then find the next largest pt lepton
   *  and plot that too :-)
   */

  h_primary_lepton->plot(muonTES->at(0), m_eventWeight);
  
  double secElecPt = 0.0;
  bool secLep = false;
  if(elecTES->size() > 0){
    secLep = true;
    secElecPt = elecTES->at(0)->pt();
  }

  double secMuonPt = 0.0;
  if(muonTES->size() > 1){
    secLep = true;
    secMuonPt = muonTES->at(1)->pt();
  }

  if(secLep == true){
    if(secMuonPt > secElecPt){
      h_secondary_lepton->plot(muonTES->at(1), m_eventWeight);
    }else{
      h_secondary_lepton->plot(elecTES->at(0), m_eventWeight);
    }
  }

  /**
   * Actual selection part :-)
   */

  if(m_applySecondaryLeptonCut){
    if(elecTES->size() > 0 && elecTES->at(0)->pt() > m_secondaryLeptonCut*GeV){
      //Failed the selection as there is another lepton with a high pt
      return;
    }

    if(muonTES->size() > 1 && muonTES->at(1)->pt() > m_secondaryLeptonCut*GeV){
      //Failed the selection as there is another lepton with a high pt
      return;
    }
  }

  if((m_applyLeptonIsolation) && (muonTES->at(0)->parameter(MuonParameters::etcone20) > m_leptonIsolationCut*GeV)){
    //Failed the isolation cut
    return;
  }

  m_tagTool->tag(IEventTagTool::LEPTON_SELECTION);
  m_tagTool->tag(IEventTagTool::MUON_SELECTION);
  c_muon->push_back(new Analysis::Muon(*(muonTES->at(0))));
}

void BUSTopSelection::selectB1Jets(){
  if(bjetTES->size() > 0){
    if(m_b1SelectionMethod == "E"){
      JetESelection(bjetTES, c_b1, IEventTagTool::B1SELECTION);
    }else if(m_b1SelectionMethod == "Et"){
      JetEtSelection(bjetTES, c_b1, IEventTagTool::B1SELECTION);
    }else if(m_b1SelectionMethod == "Pt"){
      JetPtSelection(bjetTES, c_b1, IEventTagTool::B1SELECTION, m_applySecondaryBJetCut, m_secondaryBJetCut);
    }else if(m_b1SelectionMethod == "Weight"){
      JetWeightSelection(bjetTES, c_b1, IEventTagTool::B1SELECTION);
    }else if(m_b1SelectionMethod == "TMVA"){
      B1TMVASelection();
    }
  }

  if(bjetTES->size() > 0){
    h_primary_bjet->plot(bjetTES->at(0), m_eventWeight);
  }

  if(bjetTES->size() > 1){
    h_secondary_bjet->plot(bjetTES->at(1), m_eventWeight);
    h_bjet_pt_fraction->Fill(bjetTES->at(1)->pt()/bjetTES->at(0)->pt(), m_eventWeight);
  }
}

void BUSTopSelection::selectLJets(){
  if(ljetTES->size() > 0){
    if(m_ljSelectionMethod == "E"){
      JetESelection(ljetTES, c_lj, IEventTagTool::LJSELECTION);
    }else if(m_ljSelectionMethod == "Et"){
      JetEtSelection(ljetTES, c_lj, IEventTagTool::LJSELECTION);
    }else if(m_ljSelectionMethod == "Pt"){
      JetPtSelection(ljetTES, c_lj, IEventTagTool::LJSELECTION);
    }
  }

  sortLightJets();

  if(c_sortedLightJets->size() > 0){
    const Jet* j = c_sortedLightJets->at(0);
    h_primary_ljet->plot(j, m_eventWeight);
  }

  if(c_sortedLightJets->size() > 1){
    const Jet* j = c_sortedLightJets->at(1);
    h_secondary_ljet->plot(j, m_eventWeight);

    double secondaryE = c_sortedLightJets->at(1)->e();
    double primaryE = c_sortedLightJets->at(0)->e();

    h_ljet_e_fraction->Fill(secondaryE/primaryE, m_eventWeight);
  }
}

void BUSTopSelection::JetESelection(const JetCollection* inputColl, JetCollection* outputColl, int tag){
  MsgStream mLog( messageService(), name() );

  JetCollection::const_iterator jetIter = inputColl->begin();
  JetCollection::const_iterator jetIterEnd = inputColl->end();

  int index = 0;
  int eIndex = 0;
  while(jetIter < jetIterEnd){
    //Search for the most energetic light jet
    if((*jetIter)->e() > inputColl->at(eIndex)->e()){
      eIndex = index;
    }

    index++;
    jetIter++;
  }

  outputColl->push_back(new Jet(inputColl->at(eIndex)));
  m_tagTool->tag(tag);  
}

void BUSTopSelection::JetEtSelection(const JetCollection* inputColl, JetCollection* outputColl, int tag){
  MsgStream mLog( messageService(), name() );

  JetCollection::const_iterator jetIter = inputColl->begin();
  JetCollection::const_iterator jetIterEnd = inputColl->end();

  int index = 0;
  int eIndex = 0;
  while(jetIter < jetIterEnd){
    //Search for the most energetic light jet
    if((*jetIter)->et() > inputColl->at(eIndex)->et()){
      eIndex = index;
    }

    index++;
    jetIter++;
  }

  outputColl->push_back(new Jet(inputColl->at(eIndex)));
  m_tagTool->tag(tag);  
}

void BUSTopSelection::JetWeightSelection(const JetCollection* inputColl, JetCollection* outputColl, int tag){
  MsgStream mLog( messageService(), name() );

  JetCollection::const_iterator jetIter = inputColl->begin();
  JetCollection::const_iterator jetIterEnd = inputColl->end();

  int index = 0;
  int wIndex = 0;
  while(jetIter < jetIterEnd){
    //Search for the most energetic light jet
    if(getFlavourTagWeight(*jetIter) > getFlavourTagWeight(inputColl->at(wIndex))){
      wIndex = index;
    }

    index++;
    jetIter++;
  }

  outputColl->push_back(new Jet(inputColl->at(wIndex)));
  m_tagTool->tag(tag);  
}

void BUSTopSelection::JetPtSelection(const JetCollection* inputColl, JetCollection* outputColl, int tag, bool applyCut, double cut){
  MsgStream mLog( messageService(), name() );

  //Apply secondary cut
  if(applyCut){
    if(inputColl->size() > 1 && inputColl->at(1)->pt() > cut*GeV){
      //Failed on secondary cut
      return;
    }
  }

  if(inputColl->size() > 0){
    outputColl->push_back(new Jet(inputColl->at(0)));
    m_tagTool->tag(tag);  
  }
}

void BUSTopSelection::printHistogram(TH1* h){
  MsgStream mLog( messageService(), name() );

  for(int i = 0; i <= h->GetNbinsX(); i++){
    mLog << MSG::DEBUG << "h[" << i << "] = " << h->GetBinContent(i) << endreq;
  }  
}

void BUSTopSelection::B1TMVASelection(){
  MsgStream mLog( messageService(), name() );

  //This should really iterate over all jets, not just reject the first one.
  
  TMVA::Reader* reader = new TMVA::Reader();

  float bVars[9];

  reader->AddVariable("e", &bVars[0]);
  reader->AddVariable("eta", &bVars[1]);
  reader->AddVariable("lepDEta", &bVars[2]);
  reader->AddVariable("lepDPhi", &bVars[3]);
  reader->AddVariable("lepDR", &bVars[4]);
  reader->AddVariable("nTrks", &bVars[5]);
  reader->AddVariable("pt", &bVars[6]);
  reader->AddVariable("FracH", &bVars[7]);
  //reader->AddVariable("weight", &bVars[8]);

  reader->BookMVA("Likihood", "weights/B1Analysis_Likelihood.weights.txt");

  double likelihood;

  const Analysis::TrackAssociation* ta = bjetTES->at(0)->getAssociation<Analysis::TrackAssociation>("Tracks");
  std::vector<const Rec::TrackParticle*>* trks = ta->tracks();

  bVars[0] = bjetTES->at(0)->e()/GeV;
  bVars[1] = bjetTES->at(0)->eta()/GeV;

  bVars[2] = 1000.0;
  bVars[3] = 1000.0;
  bVars[4] = 1000.0;

  if(m_tagTool->tagged((m_filterTags.at(0) + 1))){
    bVars[2] = fabs(bjetTES->at(0)->eta() - elecTES->at(0)->eta());
    bVars[3] = AnalysisUtils::Delta::phi(bjetTES->at(0), elecTES->at(0));
    bVars[4] = AnalysisUtils::Delta::R(bjetTES->at(0), elecTES->at(0));
  }else if(m_tagTool->tagged((m_filterTags.at(0) + 2))){
    bVars[2] = fabs(bjetTES->at(0)->eta() - muonTES->at(0)->eta());
    bVars[3] = AnalysisUtils::Delta::phi(bjetTES->at(0), muonTES->at(0));
    bVars[4] = AnalysisUtils::Delta::R(bjetTES->at(0), muonTES->at(0));
  }

  bVars[5] = trks->size();
  bVars[6] = bjetTES->at(0)->pt()/GeV;
  bVars[7] = bjetTES->at(0)->getFlavourTagWeight() + 10;

  likelihood = reader->EvaluateMVA("Likihood");

  if(likelihood >= m_b1LHCut){
    c_b1->push_back(new Jet(*(bjetTES->at(0))));
  }

  mLog << MSG::DEBUG << "B1 TMVA = " << likelihood << endreq;

  delete reader;
}

double BUSTopSelection::getFlavourTagWeight(const Jet* j){
  if(m_jetWeightTagger == "Default"){
    return j->getFlavourTagWeight();
  }else{
    return j->getFlavourTagWeight(m_jetWeightTagger);
  }
}

void BUSTopSelection::sortLightJets(){
  JetCollection::const_iterator iter = ljetTES->begin();
  JetCollection::const_iterator iterEnd = ljetTES->end();

  while(iter < iterEnd){
    c_sortedLightJets->push_back(new Jet(**iter));
    iter++;
  }

  AnalysisUtils::Sort::e(c_sortedLightJets);
}
