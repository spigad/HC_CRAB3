#include "BUSTopTools/BUSTopHistogrammer.h"
#include "BUSTopTools/TruthHistograms.h"

#include "StoreGate/StoreGateSvc.h"
#include "StoreGate/DataHandle.h"

#include "McParticleEvent/TruthParticleContainer.h"
#include "HepMC/GenParticle.h"
#include "EventKernel/PdtPdg.h"
#include "AnalysisUtils/IParticleFilter.h"
#include "AnalysisUtils/AnalysisMisc.h"

#include <iostream>
#include <string>
#include <queue>

#include "TH1.h"
#include "TH2.h"

TruthHistograms::TruthHistograms(IBUSTopHistogrammer* parent, std::string algName, std::string dirName, std::string hN):KinematicHistograms(parent, algName, dirName, hN){
  weight = new TH1F*[3];
  status = new TH1F*[3];
  mass = new TH1F*[3];

  std::stringstream fname, hname, title;

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "_weight";
  fname << "/AANT/"<< algName <<"/" << dirName << "/" << hname.str();
  title << "Weight";
  parent->registerHistogram(weight, fname.str(), hname.str(), title.str(), "Weight", 50, -1.5, 1.5);

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "_status";
  fname << "/AANT/"<< algName <<"/" << dirName << "/" << hname.str();
  title << "Status";
  parent->registerHistogram(status, fname.str(), hname.str(), title.str(), "Status", 20, -10.5, 9.5);

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "_mass";
  fname << "/AANT/"<< algName <<"/" << dirName << "/" << hname.str();
  title << "Mass";
  parent->registerHistogram(mass, fname.str(), hname.str(), title.str(), "Status", 250, 0, 250.0);
}

void TruthHistograms::plotContainer(const TruthParticleContainer* c, double w){

  if(c->size() > 0){
    TruthParticleContainer::const_iterator iter = c->begin();
    TruthParticleContainer::const_iterator iterEnd = c->end();

    while(iter < iterEnd){

      plot(*iter, w);

      iter++;

    }

  }

  //n[0]->Fill(totCount, 1.0);
  //n[1]->Fill(posCount, 1.0);
  //n[2]->Fill(negCount, 1.0);

}


void TruthHistograms::plot(TruthParticle* particle, double w){

  phi[0]->Fill(particle->phi(), w);
  eta[0]->Fill(particle->eta(), w);
  p[0]->Fill(particle->p()/GeV, w);
  px[0]->Fill(particle->px()/GeV, w);
  py[0]->Fill(particle->py()/GeV, w);
  pz[0]->Fill(particle->pz()/GeV, w);
  pt[0]->Fill(particle->pt()/GeV, w);
  ipt[0]->Fill(GeV/particle->pt(), w);
  costheta[0]->Fill(particle->cosTh(), w);
  status[0]->Fill(particle->status(), w);
  mass[0]->Fill(particle->m()/GeV, w);
  ptop[0]->Fill(fabs(particle->pt()/particle->p()), w);
  etoe[0]->Fill(fabs(particle->et()/particle->e()), w);
  e[0]->Fill(particle->e()/GeV, w);

  weight[0]->Fill(w, 1.0);

  int index = 1;
  if(particle->charge() < 0){
    index = 2;
  }

  phi[index]->Fill(particle->phi(), w);
  eta[index]->Fill(particle->eta(), w);
  p[index]->Fill(particle->p()/GeV, w);
  px[index]->Fill(particle->px()/GeV, w);
  py[index]->Fill(particle->py()/GeV, w);
  pz[index]->Fill(particle->pz()/GeV, w);
  pt[index]->Fill(particle->pt()/GeV, w);
  ipt[index]->Fill(GeV/particle->pt(), w);
  costheta[index]->Fill(particle->cosTh(), w);
  status[index]->Fill(particle->status(), w);
  mass[index]->Fill(particle->m()/GeV, w);
  ptop[index]->Fill(fabs(particle->pt()/particle->p()), w);
  etoe[index]->Fill(fabs(particle->et()/particle->e()), w);
  e[index]->Fill(particle->e()/GeV, w);
  weight[index]->Fill(w, 1.0);
}

