#include "GaudiKernel/IToolSvc.h"
#include "GaudiKernel/ITHistSvc.h"

#include "TH1.h"
#include "TH2.h"

#include "egammaEvent/ElectronContainer.h"
#include "muonEvent/MuonContainer.h"
#include "muonEvent/Muon.h"
#include "MissingETEvent/MissingET.h"
#include "CompositeParticleEvent/CompositeParticleContainer.h"
#include "CompositeParticleEvent/CompositeParticle.h"
#include "ParticleEvent/NeutrinoContainer.h"
#include "ParticleEvent/Neutrino.h"

#include "SpecialUtils/NeutrinoUtils.h"

#include "DataModel/ElementLink.h"
#include "JetTagInfo/TruthInfo.h"

#include "AnalysisTools/IAnalysisTools.h"

#include "BUSTopTools/IBUSTopHistogrammer.h"
#include "BUSTopTools/INuSolutionTool.h"
#include "BUSTopTools/KinematicHistograms.h"
#include "BUSTopTools/ResolutionHistograms.h"
#include "BUSTopTools/METResolutionHistograms.h"
#include "BUSTopTools/ITruthMatch.h"
#include "BUSTopTools/EventTool.h"
#include "BUSTopTools/EventTagTool.h"

#include "BUSTopAnalysis/BUSTopNeutrinoAnalysis.h"

#include <stdint.h>
#include <algorithm>
#include <math.h>
#include <functional>

BUSTopNeutrinoAnalysis::BUSTopNeutrinoAnalysis(const std::string& name, ISvcLocator* pSvcLocator) : 
                                             Algorithm(name, pSvcLocator){

  declareProperty("Electrons", m_fullElectronsName);
  declareProperty("PreselectedElectrons", m_preselectedElectronsName);
  declareProperty("CSCSelectedElectrons", m_cscSelectedElectronsName);

  declareProperty("Muons", m_fullMuonsName);
  declareProperty("PreselectedMuons", m_preselectedMuonsName);
  declareProperty("CSCSelectedMuons", m_cscSelectedMuonsName);

  declareProperty("Neutrinos", m_nuName);
  declareProperty("PreselectedNeutrinos", m_preselectedNuName);
  declareProperty("CSCSelectedNeutrinos", m_cscSelectedNuName);
  declareProperty("SelectedNeutrinos", m_selectedNuName);

  declareProperty("MET", m_metName);

  declareProperty("WWidth", m_wWidth);
  declareProperty("METSigma", m_metSigma);

  declareProperty("TruthAvailable", m_truthAvailable);
}

BUSTopNeutrinoAnalysis::~BUSTopNeutrinoAnalysis(){
}

StatusCode BUSTopNeutrinoAnalysis::initialize() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << "Initializing BUSTopNeutrinoAnalysis" << endreq;

  if (service("StoreGateSvc", m_storeGate).isFailure()) {
     mLog << MSG::ERROR << "Unable to retrieve pointer to StoreGateSvc" << endreq;
     return StatusCode::FAILURE;
  }

  service("THistSvc", m_thistSvc);

  IToolSvc * toolSvc;
  service("ToolSvc", toolSvc);

  IAlgTool *tmp_eventTool;
  toolSvc->retrieveTool("EventTool", tmp_eventTool);
  m_eventTool = dynamic_cast<IEventTool *>(tmp_eventTool);

  IAlgTool *tmp_truthMatch;
  toolSvc->retrieveTool("TruthMatch", tmp_truthMatch);
  m_truthMatchTool = dynamic_cast<ITruthMatch *>(tmp_truthMatch);

  IAlgTool *tmp_tagTool;
  toolSvc->retrieveTool("EventTagTool", tmp_tagTool);
  m_tagTool = dynamic_cast<IEventTagTool *>(tmp_tagTool);

  IAlgTool *tmp_histogramTool;
  toolSvc->retrieveTool("BUSTopHistogrammer", tmp_histogramTool);
  m_histogrammer = dynamic_cast<IBUSTopHistogrammer *>(tmp_histogramTool);

  IAlgTool *tmp_nuSolTool;
  toolSvc->retrieveTool("NuSolutionTool", tmp_nuSolTool);
  m_nuSolTool = dynamic_cast<INuSolutionTool *>(tmp_nuSolTool);

  registerHistograms();

  return StatusCode::SUCCESS;
}

void BUSTopNeutrinoAnalysis::registerHistograms(){
  h_nu_full = new KinematicHistograms(m_histogrammer, "NeutrinoAnalysis", "Kinematic", "nua_nu_full");
  h_nu_preselection = new KinematicHistograms(m_histogrammer, "NeutrinoAnalysis", "Kinematic", "nua_nu_preselection");
  h_nu_cscselection = new KinematicHistograms(m_histogrammer, "NeutrinoAnalysis", "Kinematic", "nua_nu_cscselection");
  h_nu_selection = new KinematicHistograms(m_histogrammer, "NeutrinoAnalysis", "Kinematic", "nua_nu_selection");

  h_met_res_small_eta = new METResolutionHistograms(m_histogrammer, "NeutrinoAnalysis", "MET", "nua_met_res_small_eta");
  h_met_res_large_eta = new METResolutionHistograms(m_histogrammer, "NeutrinoAnalysis", "MET", "nua_met_res_large_eta");

  if(m_truthAvailable){
    h_nu_res_small_eta = new ResolutionHistograms(m_histogrammer, "NeutrinoAnalysis", "Truth", "nua_nu_res_small_eta", 0.1);
    h_nu_res_large_eta = new ResolutionHistograms(m_histogrammer, "NeutrinoAnalysis", "Truth", "nua_nu_res_large_eta", 0.1);
  }
}

StatusCode BUSTopNeutrinoAnalysis::finalize() {
  MsgStream mLog( messageService(), name() );
  
  return StatusCode::SUCCESS;
}

StatusCode BUSTopNeutrinoAnalysis::execute() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << "execute()" << endreq;

  getEventWeight();
  getStoregateContainers();

  h_nu_full->plotContainer(c_nu, m_eventWeight);
  
  if(m_tagTool->tagged(IEventTagTool::PRESELECTION)){
    h_nu_preselection->plotContainer(c_preselectedNu, m_eventWeight);
  }

  if(m_tagTool->tagged(IEventTagTool::CSCSELECTION)){
    h_nu_cscselection->plotContainer(c_cscSelectedNu, m_eventWeight);
  }

  if(m_tagTool->tagged(IEventTagTool::NUSELECTION)){
    h_nu_selection->plotContainer(c_selectedNu, m_eventWeight);
  }

  plotMETRes();
  if(m_truthAvailable == true){
    plotTruthRes();
  }

  StatusCode sc = StatusCode::SUCCESS;

  return sc;

}

void BUSTopNeutrinoAnalysis::plotMETRes(){
  if(m_tagTool->tagged(IEventTagTool::TRIGGERED)){
    if(c_nu->size() == 2){
      if(fabs(c_nu->at(0)->eta()) > fabs(c_nu->at(1)->eta())){
        h_met_res_large_eta->plot(c_nu->at(0), metTES, m_eventWeight);
        h_met_res_small_eta->plot(c_nu->at(1), metTES, m_eventWeight);
      }else{
        h_met_res_large_eta->plot(c_nu->at(1), metTES, m_eventWeight);
        h_met_res_small_eta->plot(c_nu->at(0), metTES, m_eventWeight);
      }
    }
  }
}

void BUSTopNeutrinoAnalysis::plotTruthRes(){
  if(m_tagTool->tagged(IEventTagTool::ELECTRON_TRUTH)){
    plotTruthRes(c_enuTruth);
  }else if(m_tagTool->tagged(IEventTagTool::MUON_TRUTH)){
    plotTruthRes(c_munuTruth);
  }
}

void BUSTopNeutrinoAnalysis::plotTruthRes(const TruthParticleContainer* t){
  if(m_tagTool->tagged(IEventTagTool::TRIGGERED)){
    if(c_nu->size() == 2 && t->size() > 0){
      if(fabs(c_nu->at(0)->eta()) > fabs(c_nu->at(1)->eta())){
        h_nu_res_large_eta->plot(t->at(0), c_nu->at(0), m_eventWeight);
        h_nu_res_small_eta->plot(t->at(0), c_nu->at(1), m_eventWeight);
      }else{
        h_nu_res_large_eta->plot(t->at(0), c_nu->at(1), m_eventWeight);
        h_nu_res_small_eta->plot(t->at(0), c_nu->at(0), m_eventWeight);
      }
    }
  }
}

void BUSTopNeutrinoAnalysis::getStoregateContainers(){
  MsgStream mLog( messageService(), name() );

  m_storeGate->retrieve(metTES, m_metName);  
  if(metTES == 0){
    mLog << MSG::ERROR << "Problem getting MetContainer" << endreq;   
  }  

  m_storeGate->retrieve(c_nu, m_nuName);
  if(c_nu == 0){
    mLog << MSG::ERROR << "Problem getting Nu Container" << endreq;
  }

  m_storeGate->retrieve(c_preselectedNu, m_preselectedNuName);
  if(c_preselectedNu == 0){
    mLog << MSG::ERROR << "Problem getting Nu Container" << endreq;
  }

  m_storeGate->retrieve(c_cscSelectedNu, m_cscSelectedNuName);
  if(c_cscSelectedNu == 0){
    mLog << MSG::ERROR << "Problem getting Nu Container" << endreq;
  }

  if(m_tagTool->tagged(IEventTagTool::NUSELECTION)){
    m_storeGate->retrieve(c_selectedNu, m_selectedNuName);
    if(c_selectedNu == 0){
      mLog << MSG::ERROR << "Problem getting Nu Container" << endreq;
    }
  }

  if(m_truthAvailable == true){
    getTruthContainers();
  }
}

void BUSTopNeutrinoAnalysis::getEventWeight(){
  if(m_tagTool->tagged(IEventTagTool::IS_ATLFAST) == false && m_tagTool->tagged(IEventTagTool::IS_MC) == true){  
    m_eventWeight = m_eventTool->getEventWeight();
  }else{
    m_eventWeight = 1.0;
  }
}

void BUSTopNeutrinoAnalysis::getTruthContainers(){
  MsgStream mLog( messageService(), name() );

  m_storeGate->retrieve(c_enuTruth, "BUSTopTruth_enu");
  if(c_enuTruth == 0){
    mLog << MSG::ERROR << "Problem getting enu Container" << endreq;
  }

  m_storeGate->retrieve(c_munuTruth, "BUSTopTruth_munu");
  if(c_munuTruth == 0){
    mLog << MSG::ERROR << "Problem getting munu Container" << endreq;
  }
}
