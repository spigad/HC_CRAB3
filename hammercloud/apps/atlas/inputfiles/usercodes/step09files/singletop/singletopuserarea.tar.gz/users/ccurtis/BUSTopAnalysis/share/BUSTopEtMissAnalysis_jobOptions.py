from BUSTopAnalysis.BUSTopAnalysisConf import BUSTopEtMissAnalysis
Sequencer += BUSTopEtMissAnalysis()
BUSTopEtMissAnalysis.OutputLevel = WARNING

BUSTopEtMissAnalysis.METContainer               = BUSTopJES.METOutputContainer
BUSTopEtMissAnalysis.JetContainer               = RootJetContainer
BUSTopEtMissAnalysis.NeutrinoContainer          = BUSTopNuRecon_Preselection.OutputNeutrinoContainer
BUSTopEtMissAnalysis.PreselectedElectrons       = BUSTopPreselection.OutputElectronContainer
BUSTopEtMissAnalysis.PreselectedMuons           = BUSTopPreselection.OutputMuonContainer
BUSTopEtMissAnalysis.CSCSelectedElectrons       = BUSTopCSCSelection.OutputElectronContainer
BUSTopEtMissAnalysis.CSCSelectedMuons           = BUSTopCSCSelection.OutputMuonContainer
BUSTopEtMissAnalysis.METCut                     = 5

if DoTruth:
	BUSTopEtMissAnalysis.TruthAvailable     = 1
else:
	BUSTopEtMissAnalysis.TruthAvailable     = 0

