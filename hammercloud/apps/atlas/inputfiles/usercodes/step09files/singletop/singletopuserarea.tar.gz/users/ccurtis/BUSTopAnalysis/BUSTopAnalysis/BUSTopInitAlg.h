#ifndef BUSTOP_INIT_ALG_H
#define BUSTOP_INIT_ALG_H

#include "GaudiKernel/Algorithm.h"

#include "CLHEP/Units/SystemOfUnits.h"

#include "StoreGate/StoreGateSvc.h"

#include "GaudiKernel/ToolHandle.h"

#include <stdint.h>
#include <string>

class ITHistSvc;
class TH1F;
class TH2F;

class IAnalysisTools;
class IEventTool;
class IEventTagTool;

class BUSTopInitAlg : public Algorithm {

 public:

   BUSTopInitAlg(const std::string& name, ISvcLocator* pSvcLocator);
   ~BUSTopInitAlg();

   StatusCode initialize();
   StatusCode finalize();
   StatusCode execute();
  
 private:
   StoreGateSvc*  m_storeGate;
   ITHistSvc*     m_histSvc;
   IEventTool*    m_eventTool;
   IEventTagTool* m_tagTool;

   bool m_isAtlfast;
   bool m_isMC;

   virtual void registerHistograms();
   virtual void getEventWeight();

   double m_eventWeight;
};

#endif // BUSTOP_INIT_ALG_H


