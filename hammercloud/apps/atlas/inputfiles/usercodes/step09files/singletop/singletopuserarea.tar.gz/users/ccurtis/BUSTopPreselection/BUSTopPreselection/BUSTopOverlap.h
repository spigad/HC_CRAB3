#ifndef BUSTOP_OVERLAP_H
#define BUSTOP_OVERLAP_H

#include "GaudiKernel/Algorithm.h"

#include "CLHEP/Units/SystemOfUnits.h"

#include "StoreGate/StoreGateSvc.h"

#include "GaudiKernel/ToolHandle.h"

#include "muonEvent/MuonContainer.h"

#include <stdint.h>
#include <string>

class ITHistSvc;
class TH1F;
class TH2F;

class IAnalysisTools;
class ElectronContainer;
class JetCollection;

class IBUSTopHistogrammer;
class IEventTool;
class IEventTagTool;

class BUSTopOverlap : public Algorithm {

 public:

   BUSTopOverlap(const std::string& name, ISvcLocator* pSvcLocator);
   ~BUSTopOverlap();

   StatusCode initialize();
   StatusCode finalize();
   StatusCode execute();

 private:

   StoreGateSvc* m_storeGate;
   ITHistSvc *m_thistSvc;
   IBUSTopHistogrammer* m_histogrammer;
   IEventTool* m_eventTool;
   IEventTagTool* m_tagTool;

   std::string m_muonInputContainerName;
   std::string m_electronInputContainerName;
   std::string m_jetInputContainerName;
   std::string m_jetOutputContainerName;
   std::string m_ejetOutputContainerName;
   std::string m_mjetOutputContainerName;

   bool m_truthAvailable;
   bool m_eventWeight;

   const Analysis::MuonContainer* muonTES;
   const ElectronContainer* elecTES;
   const JetCollection* jetTES;

   double m_deltaRCut;
   double m_deltaECut;

   JetCollection *c_jet_mremoved;
   JetCollection *c_jet_eremoved;
   JetCollection *c_mjet;
   JetCollection *c_ejet;

   virtual void getEventWeight();
   virtual void registerHistograms();
   virtual void getStoregateContainers();
   virtual void createTemporaryContainers();
   virtual void destroyTemporaryContainers();

   virtual void registerContainers();
   virtual void registerJets(JetCollection* jc, std::string name);

   virtual void removeMuons();
   virtual void removeElectrons();

   virtual void tagEvent();

   TH1F* h_mjet_deltaR;
   TH1F* h_mjet_deltaEnergy;
   TH1F* h_ejet_deltaR;
   TH1F* h_ejet_deltaEnergy;
};

#endif // BUSTOP_OVERLAP_H


