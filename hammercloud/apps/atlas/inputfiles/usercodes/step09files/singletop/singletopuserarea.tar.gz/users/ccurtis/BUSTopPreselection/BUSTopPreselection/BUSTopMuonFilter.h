#ifndef BUSTOP_MUON_FILTER_H
#define BUSTOP_MUON_FILTER_H

#include "GaudiKernel/Algorithm.h"

#include "CLHEP/Units/SystemOfUnits.h"

#include "StoreGate/StoreGateSvc.h"

#include "GaudiKernel/ToolHandle.h"

#include <stdint.h>
#include <string>

class ITHistSvc;
class TH1F;
class TH2F;

class IAnalysisTools;
class IEventTool;
class IEventTagTool;

namespace Analysis{
  class MuonContainer;
}

class BUSTopMuonFilter : public Algorithm {

 public:

   BUSTopMuonFilter(const std::string& name, ISvcLocator* pSvcLocator);
   ~BUSTopMuonFilter();

   StatusCode initialize();
   StatusCode finalize();
   StatusCode execute();
  
 private:
   StoreGateSvc*  m_storeGate;
   ITHistSvc*     m_histSvc;
   IEventTool*    m_eventTool;
   IEventTagTool* m_tagTool;

   std::string m_inputMuonContainerName;
   std::string m_outputMuonContainerName;

   bool m_truthAvailable;
   double m_eventWeight;

   const Analysis::MuonContainer* muonTES;

   Analysis::MuonContainer* c_filtered_muons;

   virtual void getEventWeight();
   virtual void registerHistograms();
   virtual void getStoregateContainers();
   virtual void createTemporaryContainers();
   virtual void destroyTemporaryContainers();

   virtual void registerContainers();
   virtual void registerContainer(const Analysis::MuonContainer* m, std::string n);

   virtual void filterMuons();
};

#endif // BUSTOP_MUON_FILTER_H


