#ifndef MUON_HISTOGRAMS_H
#define MUON_HISTOGRAMS_H

#include "GaudiKernel/AlgTool.h"
#include "GaudiKernel/MsgStream.h"
#include "GaudiKernel/AlgFactory.h"
#include "StoreGate/StoreGateSvc.h"
#include "StoreGate/DataHandle.h"
#include "AIDA/IHistogram1D.h"
#include "AIDA/IHistogram2D.h"
#include "GaudiKernel/ITHistSvc.h"
#include "EventKernel/PdtPdg.h"

#include "BUSTopTools/KinematicHistograms.h"

class IBUSTopHistogrammer;
class TH1F;
class TH2F;

namespace Analysis{
  class Muon;
  class MuonContainer;
}

class MuonHistograms: public KinematicHistograms{
   public:
     MuonHistograms(IBUSTopHistogrammer* parent, std::string algName, std::string dirName, std::string hname);
     virtual ~MuonHistograms(){};

     TH1F** etcone20;

     void plotContainer(const Analysis::MuonContainer* c, double w, int maxCount = -1);
     void plot(const Analysis::Muon* particle, double w);
};

#endif

