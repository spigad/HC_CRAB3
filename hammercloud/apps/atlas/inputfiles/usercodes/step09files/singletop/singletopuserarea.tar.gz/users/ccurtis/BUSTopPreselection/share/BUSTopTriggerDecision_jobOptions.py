from BUSTopPreselection.BUSTopPreselectionConf import BUSTopTriggerDecision
Sequencer += BUSTopTriggerDecision()
BUSTopTriggerDecision.OutputLevel = WARNING

if IsAtlfast == 0:
	BUSTopTriggerDecision.RunTrigger              = DoTrigger
	BUSTopTriggerDecision.PrintMenu               = 0
else:
	BUSTopTriggerDecision.RunTrigger              = 0
	BUSTopTriggerDecision.PrintMenu               = 0

BUSTopTriggerDecision.InputElectronContainer  = RootElectronContainer
BUSTopTriggerDecision.InputMuonContainer      = RootMuonContainer

BUSTopTriggerDecision.ElectronTriggerItems    = [ "EF_e20_loose" ]
BUSTopTriggerDecision.ElectronPtCut           = 20

BUSTopTriggerDecision.MuonTriggerItems        = [ "EF_mu10" ]
BUSTopTriggerDecision.MuonPtCut               = 10


BUSTopTriggerDecision.TruthAvailable = DoTruth

if IsAtlfast == 0:
	from AthenaCommon.GlobalFlags import GlobalFlags
	GlobalFlags.DetGeo.set_atlas()

	from TrigDecision.TrigDecisionConfig import TrigDecisionTool
	tdt = TrigDecisionTool()
	ToolSvc += tdt

	from RecExConfig.RecFlags  import rec
	rec.readRDO=False
	rec.readAOD=True
	rec.doWriteAOD=False
	rec.doWriteESD=False

	from TriggerJobOpts.TriggerFlags import TriggerFlags
	TriggerFlags.configurationSourceList = ['ds']

	from TriggerJobOpts.TriggerConfigGetter import TriggerConfigGetter
	cfg =  TriggerConfigGetter()

