#ifndef ITRUTH_MATCH_H
#define ITRUTH_MATCH_H

#include "GaudiKernel/AlgTool.h"

class TruthParticle;

class ITruthMatch: public AlgTool{
   public:
     ITruthMatch(const std::string& t, const std::string& n, const IInterface* p): AlgTool(t, n, p){}
     virtual ~ITruthMatch(){}
     template <class COLL> bool matchR(const TruthParticle* p, COLL *coll, unsigned int &index);
};

#include "BUSTopTools/ITruthMatch.icc"

#endif

