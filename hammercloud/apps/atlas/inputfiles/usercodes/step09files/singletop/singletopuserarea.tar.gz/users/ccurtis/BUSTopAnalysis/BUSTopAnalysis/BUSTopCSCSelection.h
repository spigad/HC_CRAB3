#ifndef BUSTOP_CSC_SELECTION_H
#define BUSTOP_CSC_SELECTION_H

#include "GaudiKernel/Algorithm.h"

#include "CLHEP/Units/SystemOfUnits.h"

#include "StoreGate/StoreGateSvc.h"

#include "GaudiKernel/ToolHandle.h"

#include "muonEvent/MuonContainer.h"

#include <stdint.h>
#include <string>

class ITHistSvc;
class TH1F;
class TH1I;

class IAnalysisTools;

class ElectronContainer;
class MissingET;
class JetCollection;

class IBUSTopHistogrammer;
class IEventTagTool;
class IEventTool;

namespace Analysis{
   class MuonContainer;
}

class BUSTopCSCSelection : public Algorithm {

 public:

   BUSTopCSCSelection(const std::string& name, ISvcLocator* pSvcLocator);
   ~BUSTopCSCSelection();

   StatusCode initialize();
   StatusCode finalize();
   StatusCode execute();

 private:

   StoreGateSvc* m_storeGate;
   ITHistSvc *m_thistSvc;
   IBUSTopHistogrammer* m_histogrammer;
   IEventTool *m_eventTool;
   IEventTagTool *m_tagTool;

   std::string m_electronContainerName;
   std::string m_bJetContainerName;
   std::string m_lightJetContainerName;
   std::string m_muonContainerName;
   std::string m_metContainerName;

   std::string m_selectedElectronContainerName;
   std::string m_selectedMuonContainerName;
   std::string m_selectedBJetContainerName;
   std::string m_selectedLightJetContainerName;

   bool m_truthAvailable;
   double m_eventWeight;
 
   bool m_bjetPassed;
   bool m_ljetPassed;

   TH1F* h_full_result;
   TH1F* h_passed;

   const ElectronContainer* elecTES;
   const Analysis::MuonContainer* muonTES;
   const MissingET* metTES;
   const JetCollection* bjetTES;
   const JetCollection* ljetTES;

   JetCollection* c_selectedBJets;
   JetCollection* c_selectedLightJets;

   virtual void registerHistograms();

   virtual void getEventWeight();   
   virtual void getStoregateContainers();
   virtual void createTemporaryContainers();
   virtual void destroyTemporaryContainers();
   virtual void resetFlags();

   virtual bool cutBJets();
   virtual bool cutLJets();

   virtual void registerSelected();
   virtual void registerSelected(const ElectronContainer* c, std::string n);
   virtual void registerSelected(const Analysis::MuonContainer* c, std::string n);
   virtual void registerSelected(const JetCollection* c, std::string n);

   virtual void tagEvent();

};

#endif // BUSTOP_CSC_SELECTION_H



