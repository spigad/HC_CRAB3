#include "GaudiKernel/MsgStream.h"
#include "GaudiKernel/AlgFactory.h"
#include "GaudiKernel/IToolSvc.h"
#include "GaudiKernel/ITHistSvc.h"
#include "StoreGate/StoreGateSvc.h"
#include "StoreGate/DataHandle.h"

#include "TH1.h"
#include "TH2.h"

#include "McParticleEvent/TruthParticle.h"
#include "McParticleEvent/TruthParticleContainer.h"
#include "egammaEvent/ElectronContainer.h"
#include "muonEvent/MuonContainer.h"
#include "muonEvent/Muon.h"

#include "CompositeParticleEvent/CompositeParticleContainer.h"
#include "CompositeParticleEvent/CompositeParticle.h"
#include "MissingETEvent/MissingET.h"
#include "ParticleEvent/NeutrinoContainer.h"
#include "ParticleEvent/Neutrino.h"

#include "AnalysisTools/IAnalysisTools.h"

#include "AnalysisTools/IAnalysisTools.h"
#include "AnalysisUtils/AnalysisCombination.h"

#include "BUSTopTools/IBUSTopHistogrammer.h"
#include "BUSTopTools/METHistograms.h"
#include "BUSTopTools/METResolutionHistograms.h"
#include "BUSTopTools/EventTool.h"
#include "BUSTopTools/EventTagTool.h"

#include "BUSTopAnalysis/BUSTopEtMissAnalysis.h"

#include <stdint.h>
#include <algorithm>
#include <math.h>
#include <functional>
#include <sstream>

BUSTopEtMissAnalysis::BUSTopEtMissAnalysis(const std::string& name,
  ISvcLocator* pSvcLocator) : Algorithm(name, pSvcLocator)
{
  /// switches to control the analysis through job options :: these are the default
  /// to changed in the job options

  declareProperty("METContainer", m_metContainerName);
  declareProperty("NeutrinoContainer", m_neutrinoContainerName);
  declareProperty("PreselectedElectrons", m_preselectedElectronsName);
  declareProperty("PreselectedMuons", m_preselectedMuonsName);
  declareProperty("CSCSelectedElectrons", m_cscSelectedElectronsName);
  declareProperty("CSCSelectedMuons", m_cscSelectedMuonsName);
  declareProperty("TruthAvailable", m_truthAvailable);

  declareProperty("METCut", m_metCut);
}


/////////////////////////////////////////////////////////////////////////////////////
/// Destructor - check up memory allocation
/// delete any memory allocation on the heap

BUSTopEtMissAnalysis::~BUSTopEtMissAnalysis() {
  //delete full_met;
  //full_met = 0;
}

////////////////////////////////////////////////////////////////////////////////////
/// Initialize
/// initialize StoreGate
/// get a handle on the analysis tools
/// book histograms

StatusCode BUSTopEtMissAnalysis::initialize() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO
       << "Initializing BUSTopEtMissAnalysis"
       << endreq;

  StatusCode sc;
  
  sc = service("StoreGateSvc", m_storeGate);
  if(sc.isFailure()){
    mLog << MSG::ERROR 
         << "Unable to retrieve pointer to StoreGateSvc"
	 << endreq;
    return sc;
  }
  
  sc = service("THistSvc", m_thistSvc);
  if(sc.isFailure()){
    mLog << MSG::ERROR 
         << "Unable to retrieve pointer to THistSvc"
	 << endreq;
    return sc;
  }

  IToolSvc * toolSvc;
  service("ToolSvc", toolSvc);

  IAlgTool *tmp_eventTool;
  toolSvc->retrieveTool("EventTool", tmp_eventTool);
  m_eventTool = dynamic_cast<IEventTool *>(tmp_eventTool);

  IAlgTool *tmp_tagTool;
  toolSvc->retrieveTool("EventTagTool", tmp_tagTool);
  m_tagTool = dynamic_cast<IEventTagTool *>(tmp_tagTool);

  IAlgTool *tmp_histogramTool;
  toolSvc->retrieveTool("BUSTopHistogrammer", tmp_histogramTool);
  m_histogrammer = dynamic_cast<IBUSTopHistogrammer *>(tmp_histogramTool);

  registerHistograms();

  return StatusCode::SUCCESS;
}

void BUSTopEtMissAnalysis::registerHistograms(){
  std::stringstream fName, hName;
  std::string title;

  h_full_met = new METHistograms(m_histogrammer, "EtMissAnalysis", "MET", "met_full_met");
  h_preselection_met = new METHistograms(m_histogrammer, "EtMissAnalysis", "Preselection", "met_preselection_met");
  h_cscSelection_met = new METHistograms(m_histogrammer, "EtMissAnalysis", "CSCSelection", "met_cscSelection_met");

  //truth dependent histograms
  if(m_truthAvailable == true){
    h_truth_res = new METResolutionHistograms(m_histogrammer, "EtMissAnalysis", "Truth", "met_truth_res");
    h_preselection_res = new METResolutionHistograms(m_histogrammer, "EtMissAnalysis", "Preselection", "met_preselection_res");
    h_cscSelection_res = new METResolutionHistograms(m_histogrammer, "EtMissAnalysis", "CSCSelection", "met_cscSelection_res");
  }
}

StatusCode BUSTopEtMissAnalysis::finalize() {
  MsgStream mLog( messageService(), name() );
  
  return StatusCode::SUCCESS;

}

//////////////////////////////////////////////////////////////////////////////////
/// Execute - called by the event loop on event by event

StatusCode BUSTopEtMissAnalysis::execute() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << "execute()" << endreq;

  getEventWeight();
  getParticleContainers();

  h_full_met->plot(metTES, m_eventWeight);

  if(m_tagTool->tagged(IEventTagTool::ELECTRON_PRESELECTION) || m_tagTool->tagged(IEventTagTool::MUON_PRESELECTION)){
    h_preselection_met->plot(metTES, m_eventWeight);
  }

  if(m_tagTool->tagged(IEventTagTool::ELECTRON_CSCSELECTION) || m_tagTool->tagged(IEventTagTool::MUON_CSCSELECTION)){
    h_cscSelection_met->plot(metTES, m_eventWeight);
  }

  if(m_truthAvailable == true){
    truthAnalysis();
    nuReconAnalysis();
  }

  clearParticleContainers();
  
  return StatusCode::SUCCESS;
}

void BUSTopEtMissAnalysis::getParticleContainers(){
  MsgStream mLog( messageService(), name() );

  metTES = 0;
  neutrinoTES = 0;
  c_preselected_elec = 0;
  c_preselected_muon = 0;
  c_cscSelected_elec = 0;
  c_cscSelected_muon = 0;
  c_truth_enu = 0;
  c_truth_e = 0;

  m_storeGate->retrieve(metTES, m_metContainerName);
  if(metTES == 0){
    mLog << MSG::ERROR << "Problem getting MetContainer" << endreq;
  }

  m_storeGate->retrieve(neutrinoTES, m_neutrinoContainerName);
  if(neutrinoTES == 0){
    mLog << MSG::ERROR << "Problem getting NeutrinoSolutions" << endreq;
  }

  m_storeGate->retrieve(c_preselected_elec, m_preselectedElectronsName);
  if(c_preselected_elec == 0){
    mLog << MSG::ERROR << "Problem getting Preselected Electron Container" << endreq;
  }

  m_storeGate->retrieve(c_preselected_muon, m_preselectedMuonsName);
  if(c_preselected_muon == 0){
    mLog << MSG::ERROR << "Problem getting Preselected Muon Container" << endreq;
  }

  m_storeGate->retrieve(c_cscSelected_elec, m_cscSelectedElectronsName);
  if(c_cscSelected_elec == 0){
    mLog << MSG::ERROR << "Problem getting CSCSelected Electron Container" << endreq;
  }

  m_storeGate->retrieve(c_cscSelected_muon, m_cscSelectedMuonsName);
  if(c_cscSelected_muon == 0){
    mLog << MSG::ERROR << "Problem getting CSCSelected Muon Container" << endreq;
  }

  if(m_truthAvailable == true){
    m_storeGate->retrieve(c_truth_enu, "BUSTopTruth_enu");
    if(c_truth_enu == 0){
      mLog << MSG::ERROR << "Problem getting BUSTopTruth_enu" << endreq;
    }

    m_storeGate->retrieve(c_truth_e, "BUSTopTruth_e");
    if(c_truth_e == 0){
      mLog << MSG::ERROR << "Problem getting BUSTopTruth_e" << endreq;
    }

    m_storeGate->retrieve(c_truth_munu, "BUSTopTruth_munu");
    if(c_truth_munu == 0){
      mLog << MSG::ERROR << "Problem getting BUSTopTruth_munu" << endreq;
    }

    m_storeGate->retrieve(c_truth_mu, "BUSTopTruth_mu");
    if(c_truth_mu == 0){
      mLog << MSG::ERROR << "Problem getting BUSTopTruth_mu" << endreq;
    }

    m_storeGate->retrieve(c_truth_taunu, "BUSTopTruth_taunu");
    if(c_truth_taunu == 0){
      mLog << MSG::ERROR << "Problem getting BUSTopTruth_taunu" << endreq;
    }

    m_storeGate->retrieve(c_truth_tau, "BUSTopTruth_tau");
    if(c_truth_tau == 0){
      mLog << MSG::ERROR << "Problem getting BUSTopTruth_tau" << endreq;
    }
  }
}

void BUSTopEtMissAnalysis::clearParticleContainers(){
  metTES = 0;
  c_preselected_elec = 0;
  c_preselected_muon = 0;
  c_cscSelected_elec = 0;
  c_cscSelected_muon = 0;

  c_truth_enu = 0;
  c_truth_e = 0;

  c_truth_munu = 0;
  c_truth_mu = 0;

  c_truth_taunu = 0;
  c_truth_tau = 0;
}

void BUSTopEtMissAnalysis::truthAnalysis(){
  plotResolution(h_truth_res);
}

void BUSTopEtMissAnalysis::plotResolution(METResolutionHistograms* h){
  CompositeParticle* p = new CompositeParticle();

  TruthParticleContainer::const_iterator nuIter = c_truth_enu->begin();  
  TruthParticleContainer::const_iterator nuIterEnd = c_truth_enu->end();  

  while(nuIter < nuIterEnd){
    p->add(*nuIter);
    nuIter++;
  }

  nuIter = c_truth_munu->begin();  
  nuIterEnd = c_truth_munu->end();  

  while(nuIter < nuIterEnd){
    p->add(*nuIter);
    nuIter++;
  }

  nuIter = c_truth_taunu->begin();  
  nuIterEnd = c_truth_taunu->end();  

  while(nuIter < nuIterEnd){
    p->add(*nuIter);
    nuIter++;
  }

  h->plot(p, metTES, m_eventWeight);

  delete p;
}

void BUSTopEtMissAnalysis::jetAnalysis(){
  //plot delta(MET, primary jet)
  //plot delta(MET, closest jet)
  //plot delta(closest jet, primary jet)
}

void BUSTopEtMissAnalysis::getEventWeight(){
  if(m_tagTool->tagged(IEventTagTool::IS_ATLFAST) == false && m_tagTool->tagged(IEventTagTool::IS_MC) == true){  
    m_eventWeight = m_eventTool->getEventWeight();
  }else{
    m_eventWeight = 1.0;
  }
}

void BUSTopEtMissAnalysis::nuReconAnalysis(){
  //Should Reconstruct Neutrino's in separate
  //algorithm and then make them available.

  //Get Neutrino container and match to the 
  //truth neutrino

  //Plot deltaR(nu, lep) etc
}
