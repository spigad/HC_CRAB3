from AthenaCommon.Constants import *
from AthenaCommon.AppMgr import theApp
from AthenaCommon.AppMgr import ServiceMgr
from AthenaCommon.AppMgr import ToolSvc
from AthenaCommon.AppMgr import AuditorSvc

import AthenaPoolCnvSvc.ReadAthenaPool

#-------------------------------------------------------------------------
# Message Service
#-------------------------------------------------------------------------
# Set output level threshold (2=DEBUG, 3=INFO, 4=WARNING, 5=ERROR, 6=FATAL )
ServiceMgr.MessageSvc.OutputLevel = WARNING

#theAuditorSvc = AuditorSvc()
#theAuditorSvc.Auditors = [ "NameAuditor", "ChronoAuditor" ]
#ChronoAuditor = theAuditorSvc.auditor("ChronoAuditor")
#ChronoAuditor.OutputLevel = INFO
#theApp.AuditAlgorithms = True

#-------------------------------------------------------------------------
# Algorithms
#-------------------------------------------------------------------------
from AthenaCommon.AlgSequence import AlgSequence
from AthenaCommon.AlgSequence import AthSequencer

job = AlgSequence()

Sequencer = AthSequencer("AnotherSequence")
Sequencer.StopOverride = False

job += Sequencer
#-------------------------------------------------------------------------
# Histogram and Tree Service
#-------------------------------------------------------------------------
from GaudiSvc.GaudiSvcConf import THistSvc
ServiceMgr += THistSvc()
ServiceMgr.THistSvc.Output = ["AANT DATAFILE='BUSTopAlg.root' OPT='RECREATE'"]
ServiceMgr.THistSvc.Output += ["TREES DATAFILE='BUSTopAlgTrees.root' OPT='RECREATE'"]

#-------------------------------------------------------------------------
# BUSTopAnalysis stuff
#-------------------------------------------------------------------------
RootElectronContainer   = "ElectronAODCollection"
RootMuonContainer       = "StacoMuonCollection"
RootJetContainer        = "Cone4H1TowerJets"
RootMetContainer        = "MET_RefFinal"

RootJetTagger           = "IP2D"

IsAtlfast               = 0;
IsMC                    = 1;
DoTruth                 = 0;
DoTruthFilter           = 0;
DoTrigger               = 1;
DoSelection             = 1;
TriggerLevel_Selection  = 1;

# Number of Events to process
theApp.EvtMax = -1
