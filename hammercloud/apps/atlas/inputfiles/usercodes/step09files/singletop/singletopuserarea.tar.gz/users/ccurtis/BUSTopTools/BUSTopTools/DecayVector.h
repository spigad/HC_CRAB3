#ifndef DECAY_VECTOR_H
#define DECAY_VECTOR_H

#include "GaudiKernel/AlgTool.h"
#include "GaudiKernel/MsgStream.h"
#include "GaudiKernel/AlgFactory.h"
#include "StoreGate/StoreGateSvc.h"
#include "EventKernel/PdtPdg.h"
#include "BUSTopTools/IDecayVector.h"

#include <vector>

class TruthParticle;
class TruthParticleContainer;

class DecayVector: virtual public IDecayVector, public AlgTool{
   public:
     DecayVector(const std::string&, const std::string&, const IInterface*);
     virtual ~DecayVector();
     virtual StatusCode initialize();
     virtual StatusCode finalize();

     virtual TruthParticleContainer* getTruthVector();
     virtual TruthParticleContainer* filter(PDG::pidType id, bool matchSign = false);
     virtual TruthParticleContainer* filterFailed(const TruthParticleContainer* mcTES, PDG::pidType id, bool matchSign = false);
     
     virtual void clear();
     virtual void fill(const TruthParticleContainer* mcTES, PDG::pidType pid, bool siblings, bool sign, int maxDepth = -1);
     virtual void fill(const TruthParticleContainer* mcTES, PDG::pidType pid, bool siblings = true);
     virtual void fill(const TruthParticle *p, bool siblings, int maxDepth = -1);

   private:
     mutable MsgStream m_log;
     StoreGateSvc* m_storeGate;
     std::string m_mcEventContainerName;
     TruthParticleContainer* m_truthVector;

     virtual const TruthParticle* getFinalParticle(const TruthParticle* p);
};

#endif
