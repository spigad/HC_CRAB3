#ifndef BUSTOP_SELECTION_H
#define BUSTOP_SELECTION_H

#include "GaudiKernel/Algorithm.h"

#include "CLHEP/Units/SystemOfUnits.h"

#include "StoreGate/StoreGateSvc.h"

#include "GaudiKernel/ToolHandle.h"

#include "BUSTopTools/IEventTagTool.h"

#include <stdint.h>
#include <string>

class ITHistSvc;
class TH1;
class TH1F;
class TH1D;
class TH2F;
class TFile;

class IAnalysisTools;
class TruthParticle;

namespace Analysis {
  class MuonContainer;
}

class JetCollection;
class Jet;
class ElectronContainer;
class NeutrinoContainer;
class MissingET;
class IEventTool;
class INuSolutionTool;
class IBUSTopHistogrammer;
class KinematicHistograms;

class BUSTopSelection : public Algorithm {

 public:

   BUSTopSelection(const std::string& name, ISvcLocator* pSvcLocator);
   ~BUSTopSelection();

   StatusCode initialize();
   StatusCode finalize();
   StatusCode execute();
  
 private:
   StoreGateSvc* m_storeGate;
   ITHistSvc*    m_histSvc;
   IEventTool*   m_eventTool;
   IEventTagTool*   m_tagTool;
   INuSolutionTool* m_nuSolTool;
   IBUSTopHistogrammer* m_histogrammer;

   double m_eventWeight;
   bool m_truthAvailable;

   BUSTopTags m_filterTags;

   double m_b1LHCut;
   std::string m_jetWeightTagger;

   bool m_applyLeptonIsolation;
   double m_leptonIsolationCut;
 
   bool m_applySecondaryLeptonCut;
   double m_secondaryLeptonCut;

   bool m_applySecondaryBJetCut;   
   double m_secondaryBJetCut;

   bool m_doMuon;
   bool m_doElectron;

   std::string m_electronContainerName;
   std::string m_bJetContainerName;
   std::string m_lightJetContainerName;
   std::string m_muonContainerName;
   std::string m_metContainerName;

   std::string m_selectedElectronContainerName;
   std::string m_selectedMuonContainerName;
   std::string m_selectedB1JetContainerName;
   std::string m_selectedB3JetContainerName;
   std::string m_selectedLJetContainerName;

   std::string m_sortedLJetContainerName;

   std::string m_ljSelectionMethod;
   std::string m_b1SelectionMethod;
   std::string m_nuSelectionMethod;

   virtual void getEventWeight();
   virtual void registerHistograms();
   virtual void registerTTrees();

   virtual void getStoregateContainers();
   virtual void createTemporaryContainers();
   virtual void registerSelected();
   template <class COLL> void registerSelected(COLL* c, std::string name);
   virtual void destroyTemporaryContainers();

   virtual void selectLepton();
   virtual void selectElectron();
   virtual void selectMuon();

   virtual void selectB1Jets();
   virtual void selectLJets();

   virtual void sortLightJets();

   virtual void JetESelection(const JetCollection*, JetCollection*, int);
   virtual void JetEtSelection(const JetCollection*, JetCollection*, int);
   virtual void JetPtSelection(const JetCollection*, JetCollection*, int, bool applyCut = false, double cut = 0.0);
   virtual void JetWeightSelection(const JetCollection*, JetCollection*, int);

   virtual void B1TMVASelection();
   virtual double getFlavourTagWeight(const Jet* j);

   virtual void printHistogram(TH1* h);

   const ElectronContainer* elecTES;
   const Analysis::MuonContainer* muonTES;
   const MissingET* metTES;
   const JetCollection* bjetTES;
   const JetCollection* ljetTES;

   JetCollection* c_b1;
   JetCollection* c_b3;
   JetCollection* c_lj;
   JetCollection* c_sortedLightJets;

   ElectronContainer* c_electron;
   Analysis::MuonContainer* c_muon;

   KinematicHistograms* h_primary_lepton;
   KinematicHistograms* h_secondary_lepton;

   KinematicHistograms* h_primary_bjet;
   KinematicHistograms* h_secondary_bjet;

   KinematicHistograms* h_primary_ljet;
   KinematicHistograms* h_secondary_ljet;

   TH1F* h_ljet_e_fraction;
   TH1F* h_bjet_pt_fraction;
};

#endif // BUSTOP_SELECTION_H


