#include "BUSTopTools/KinematicHistograms.h"
#include "BUSTopTools/BUSTopHistogrammer.h"

#include "StoreGate/StoreGateSvc.h"
#include "StoreGate/DataHandle.h"

#include "McParticleEvent/TruthParticleContainer.h"
#include "EventKernel/PdtPdg.h"
#include "AnalysisUtils/IParticleFilter.h"
#include "AnalysisUtils/AnalysisMisc.h"

#include <iostream>
#include <string>
#include <queue>

#include "TH1.h"
#include "TH2.h"
#include "TH3.h"

BUSTopHistogrammer::BUSTopHistogrammer(const std::string& t, const std::string& n, const IInterface* p):AlgTool(t, n, p), m_log(msgSvc(), n){
  declareInterface<IBUSTopHistogrammer>(this);  
}

BUSTopHistogrammer::~BUSTopHistogrammer(){
}

StatusCode BUSTopHistogrammer::initialize(){
  m_log.setLevel(outputLevel());  
  StatusCode sc = service("THistSvc", m_thistSvc);
  if(sc.isFailure()){
     m_log << MSG::ERROR
          << "Unable to retrieve DecayVector Tool"
          << endreq;
     return sc;
  }

  return StatusCode::SUCCESS;
}

StatusCode BUSTopHistogrammer::finalize(){
  return StatusCode::SUCCESS;
}

void BUSTopHistogrammer::registerHistogram(TH1F** &h, std::string fN, std::string hN, std::string title, std::string xName, int bins, double l, double u){
  std::stringstream fName, hName;

  fName.str("");
  hName.str("");
  fName << fN;
  hName << hN;
  h[0] = new TH1F(hName.str().c_str(), title.c_str(), bins, l, u);
  h[0]->GetXaxis()->SetTitle(xName.c_str());
  m_thistSvc->regHist(fName.str().c_str(), h[0]);

  fName.str("");
  hName.str("");
  fName << fN << "_pos";
  hName << hN << "_pos";
  h[1] = new TH1F(hName.str().c_str(), title.c_str(), bins, l, u);
  h[1]->GetXaxis()->SetTitle(xName.c_str());
  m_thistSvc->regHist(fName.str().c_str(), h[1]);

  fName.str("");
  hName.str("");
  fName << fN << "_neg";
  hName << hN << "_neg";
  h[2] = new TH1F(hName.str().c_str(), title.c_str(), bins, l, u);
  h[2]->GetXaxis()->SetTitle(xName.c_str());
  m_thistSvc->regHist(fName.str().c_str(), h[2]);
}

void BUSTopHistogrammer::registerHistogram(TH1I** &h, std::string fN, std::string hN, std::string title, std::string xName, int bins, double l, double u){
  std::stringstream fName, hName;

  fName.str("");
  hName.str("");
  fName << fN;
  hName << hN;
  h[0] = new TH1I(hName.str().c_str(), title.c_str(), bins, l, u);
  h[0]->GetXaxis()->SetTitle(xName.c_str());
  m_thistSvc->regHist(fName.str().c_str(), h[0]);

  fName.str("");
  hName.str("");
  fName << fN << "_pos";
  hName << hN << "_pos";
  h[1] = new TH1I(hName.str().c_str(), title.c_str(), bins, l, u);
  h[1]->GetXaxis()->SetTitle(xName.c_str());
  m_thistSvc->regHist(fName.str().c_str(), h[1]);

  fName.str("");
  hName.str("");
  fName << fN << "_neg";
  hName << hN << "_neg";
  h[2] = new TH1I(hName.str().c_str(), title.c_str(), bins, l, u);
  h[2]->GetXaxis()->SetTitle(xName.c_str());
  m_thistSvc->regHist(fName.str().c_str(), h[2]);
}

void BUSTopHistogrammer::registerHistogram(TH1I* &h, std::string fN, std::string hN, std::string title, std::string xName, int bins, double l, double u){
  std::stringstream fName, hName;

  fName.str("");
  hName.str("");
  fName << fN;
  hName << hN;
  h = new TH1I(hName.str().c_str(), title.c_str(), bins, l, u);
  h->GetXaxis()->SetTitle(xName.c_str());
  m_thistSvc->regHist(fName.str().c_str(), h);
}

void BUSTopHistogrammer::registerHistogram(TH1F* &h, std::string fN, std::string hN, std::string title, std::string xName, int bins, double l, double u){
  std::stringstream fName, hName;

  fName.str("");
  hName.str("");
  fName << fN;
  hName << hN;
  h = new TH1F(hName.str().c_str(), title.c_str(), bins, l, u);
  h->GetXaxis()->SetTitle(xName.c_str());
  m_thistSvc->regHist(fName.str().c_str(), h);
}

void BUSTopHistogrammer::registerHistogram(TH2F** &h, std::string fN, std::string hN, std::string title,
                                               std::string xName, int xbins, double xl, double xu,
                                               std::string yName, int ybins, double yl, double yu){

  std::stringstream fName, hName;

  fName.str("");
  hName.str("");
  fName << fN;
  hName << hN;
  h[0] = new TH2F(hName.str().c_str(), title.c_str(), xbins, xl, xu, ybins, yl, yu);
  h[0]->GetXaxis()->SetTitle(xName.c_str());
  h[0]->GetYaxis()->SetTitle(yName.c_str());
  m_thistSvc->regHist(fName.str().c_str(), h[0]);

  fName.str("");
  hName.str("");
  fName << fN << "_pos";
  hName << hN << "_pos";
  h[1] = new TH2F(hName.str().c_str(), title.c_str(), xbins, xl, xu, ybins, yl, yu);
  h[1]->GetXaxis()->SetTitle(xName.c_str());
  h[1]->GetYaxis()->SetTitle(yName.c_str());
  m_thistSvc->regHist(fName.str().c_str(), h[1]);

  fName.str("");
  hName.str("");
  fName << fN << "_neg";
  hName << hN << "_neg";
  h[2] = new TH2F(hName.str().c_str(), title.c_str(), xbins, xl, xu, ybins, yl, yu);
  h[2]->GetXaxis()->SetTitle(xName.c_str());
  h[2]->GetYaxis()->SetTitle(yName.c_str());
  m_thistSvc->regHist(fName.str().c_str(), h[2]);
}

void BUSTopHistogrammer::registerHistogram(TH2F* &h, std::string fN, std::string hN, std::string title,
                                               std::string xName, int xbins, double xl, double xu,
                                               std::string yName, int ybins, double yl, double yu){

  std::stringstream fName, hName;

  fName.str("");
  hName.str("");
  fName << fN;
  hName << hN;
  h = new TH2F(hName.str().c_str(), title.c_str(), xbins, xl, xu, ybins, yl, yu);
  h->GetXaxis()->SetTitle(xName.c_str());
  h->GetYaxis()->SetTitle(yName.c_str());
  m_thistSvc->regHist(fName.str().c_str(), h);
}

void BUSTopHistogrammer::registerHistogram(TH3F** &h, std::string fN, std::string hN, std::string title,
                                               std::string xName, int xbins, double xl, double xu,
                                               std::string yName, int ybins, double yl, double yu,
                                               std::string zName, int zbins, double zl, double zu){

  std::stringstream fName, hName;

  fName.str("");
  hName.str("");
  fName << fN;
  hName << hN;
  h[0] = new TH3F(hName.str().c_str(), title.c_str(), xbins, xl, xu, ybins, yl, yu, zbins, zl, zu);
  h[0]->GetXaxis()->SetTitle(xName.c_str());
  h[0]->GetYaxis()->SetTitle(yName.c_str());
  h[0]->GetZaxis()->SetTitle(zName.c_str());
  m_thistSvc->regHist(fName.str().c_str(), h[0]);

  fName.str("");
  hName.str("");
  fName << fN << "_pos";
  hName << hN << "_pos";
  h[1] = new TH3F(hName.str().c_str(), title.c_str(), xbins, xl, xu, ybins, yl, yu, zbins, zl, zu);
  h[1]->GetXaxis()->SetTitle(xName.c_str());
  h[1]->GetYaxis()->SetTitle(yName.c_str());
  h[1]->GetZaxis()->SetTitle(zName.c_str());
  m_thistSvc->regHist(fName.str().c_str(), h[1]);

  fName.str("");
  hName.str("");
  fName << fN << "_neg";
  hName << hN << "_neg";
  h[2] = new TH3F(hName.str().c_str(), title.c_str(), xbins, xl, xu, ybins, yl, yu, zbins, zl, zu);
  h[2]->GetXaxis()->SetTitle(xName.c_str());
  h[2]->GetYaxis()->SetTitle(yName.c_str());
  h[2]->GetZaxis()->SetTitle(zName.c_str());
  m_thistSvc->regHist(fName.str().c_str(), h[2]);
}

