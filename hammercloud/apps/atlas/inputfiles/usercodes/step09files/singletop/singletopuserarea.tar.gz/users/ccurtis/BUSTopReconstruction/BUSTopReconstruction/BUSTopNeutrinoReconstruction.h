#ifndef BUSTOP_NEUTRINO_RECONSTRUCTION_H
#define BUSTOP_NEUTRINO_RECONSTRUCTION_H

#include "GaudiKernel/Algorithm.h"

#include "CLHEP/Units/SystemOfUnits.h"

#include "StoreGate/StoreGateSvc.h"

#include "GaudiKernel/ToolHandle.h"

#include <stdint.h>
#include <string>

#include "AnalysisTools/IAnalysisTools.h"
#include "BUSTopTools/IEventTagTool.h"

class ITHistSvc;

class IAnalysisTools;

namespace Analysis {
  class MuonContainer;
}

class ElectronContainer;
class NeutrinoContainer;
class MissingET;
class IEventTool;
class INuSolutionTool;

class TH1F;

class BUSTopNeutrinoReconstruction : public Algorithm {

 public:

   BUSTopNeutrinoReconstruction(const std::string& name, ISvcLocator* pSvcLocator);
   ~BUSTopNeutrinoReconstruction();

   StatusCode initialize();
   StatusCode finalize();
   StatusCode execute();
  
 private:
   StoreGateSvc*    m_storeGate;
   ITHistSvc*       m_histSvc;
   IEventTool*      m_eventTool;
   IEventTagTool*   m_tagTool;
   INuSolutionTool* m_nuSolTool;

   double m_eventWeight;
   bool m_truthAvailable;
   bool m_exclusiveLepton;

   BUSTopTags m_filterTags;
  
   std::string m_electronContainerName;
   std::string m_muonContainerName;
   std::string m_metContainerName;

   std::string m_outputNeutrinoContainerName;

   bool m_exclusiveNeutrino;
   std::string m_outputSelectedNeutrinoContainerName;

   virtual void getEventWeight();
   virtual void registerHistograms();

   virtual void getStoregateContainers();
   virtual void createTemporaryContainers();
   virtual NeutrinoContainer* mergeContainers(NeutrinoContainer* a, NeutrinoContainer* b);
   virtual void registerContainers();
   virtual void registerContainer(NeutrinoContainer* c, std::string name);
   virtual void destroyTemporaryContainers();

   virtual void reconstructNeutrinos();
   virtual void filterNeutrinos();

   const ElectronContainer* elecTES;
   const Analysis::MuonContainer* muonTES;
   const MissingET* metTES;

   NeutrinoContainer* c_muonNeutrinos;
   NeutrinoContainer* c_elecNeutrinos;
   NeutrinoContainer* c_filteredNeutrino;

   TH1F* h_recon;
   TH1F* h_size;
};

#endif // BUSTOP_NEUTRINO_RECONSTRUCTION_H


