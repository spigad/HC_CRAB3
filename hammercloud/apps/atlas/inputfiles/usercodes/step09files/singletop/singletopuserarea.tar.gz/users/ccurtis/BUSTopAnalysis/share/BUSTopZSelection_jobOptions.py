from BUSTopAnalysis.BUSTopAnalysisConf import BUSTopZSelection

BUSTopZSelection = BUSTopZSelection( "BUSTopZSelection" )
BUSTopZSelection.OutputLevel = WARNING

Sequencer += BUSTopZSelection

BUSTopZSelection.ElectronInputContainer = RootElectronContainer
BUSTopZSelection.METInputContainer      = RootMetContainer

