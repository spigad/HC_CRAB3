#Fri May  8 13:56:24 2009
"""Automatically generated. DO NOT EDIT please"""
from GaudiKernel.GaudiHandles import *
from GaudiKernel.Proxy.Configurable import *

class BUSTopTruth( ConfigurableAlgorithm ) :
  __slots__ = { 
    'OutputLevel' : 0, # int
    'Enable' : True, # bool
    'ErrorMax' : 1, # int
    'ErrorCount' : 0, # int
    'AuditAlgorithms' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditReinitialize' : False, # bool
    'AuditExecute' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditBeginRun' : False, # bool
    'AuditEndRun' : False, # bool
    'MonitorService' : 'MonitorSvc', # str
    'MCTruthContainer' : 'SpclMC', # str
    'PrintTable' : False, # bool
  }
  _propertyDocDct = { 
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(BUSTopTruth, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'BUSTopPreselection'
  def getType( self ):
      return 'BUSTopTruth'
  pass # class BUSTopTruth

class BUSTopTruthFilter( ConfigurableAlgorithm ) :
  __slots__ = { 
    'OutputLevel' : 0, # int
    'Enable' : True, # bool
    'ErrorMax' : 1, # int
    'ErrorCount' : 0, # int
    'AuditAlgorithms' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditReinitialize' : False, # bool
    'AuditExecute' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditBeginRun' : False, # bool
    'AuditEndRun' : False, # bool
    'MonitorService' : 'MonitorSvc', # str
    'MCTruthContainer' : '', # str
    'DatasetID' : 0, # int
    'SelectChildren1' : [  ], # list
    'SelectChildren2' : [  ], # list
  }
  _propertyDocDct = { 
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(BUSTopTruthFilter, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'BUSTopPreselection'
  def getType( self ):
      return 'BUSTopTruthFilter'
  pass # class BUSTopTruthFilter

class BUSTopMuonFilter( ConfigurableAlgorithm ) :
  __slots__ = { 
    'OutputLevel' : 0, # int
    'Enable' : True, # bool
    'ErrorMax' : 1, # int
    'ErrorCount' : 0, # int
    'AuditAlgorithms' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditReinitialize' : False, # bool
    'AuditExecute' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditBeginRun' : False, # bool
    'AuditEndRun' : False, # bool
    'MonitorService' : 'MonitorSvc', # str
    'MuonInputContainer' : '', # str
    'MuonOutputContainer' : '', # str
    'TruthAvailable' : False, # bool
  }
  _propertyDocDct = { 
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(BUSTopMuonFilter, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'BUSTopPreselection'
  def getType( self ):
      return 'BUSTopMuonFilter'
  pass # class BUSTopMuonFilter

class BUSTopElectronFilter( ConfigurableAlgorithm ) :
  __slots__ = { 
    'OutputLevel' : 0, # int
    'Enable' : True, # bool
    'ErrorMax' : 1, # int
    'ErrorCount' : 0, # int
    'AuditAlgorithms' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditReinitialize' : False, # bool
    'AuditExecute' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditBeginRun' : False, # bool
    'AuditEndRun' : False, # bool
    'MonitorService' : 'MonitorSvc', # str
    'ElectronInputContainer' : '', # str
    'ElectronOutputContainer' : '', # str
    'RejectedOutputContainer' : '', # str
    'FilterLevel' : '', # str
    'TruthAvailable' : True, # bool
  }
  _propertyDocDct = { 
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(BUSTopElectronFilter, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'BUSTopPreselection'
  def getType( self ):
      return 'BUSTopElectronFilter'
  pass # class BUSTopElectronFilter

class BUSTopOverlap( ConfigurableAlgorithm ) :
  __slots__ = { 
    'OutputLevel' : 0, # int
    'Enable' : True, # bool
    'ErrorMax' : 1, # int
    'ErrorCount' : 0, # int
    'AuditAlgorithms' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditReinitialize' : False, # bool
    'AuditExecute' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditBeginRun' : False, # bool
    'AuditEndRun' : False, # bool
    'MonitorService' : 'MonitorSvc', # str
    'InputElectronContainer' : '', # str
    'InputMuonContainer' : '', # str
    'InputJetContainer' : '', # str
    'OutputJetContainer' : '', # str
    'OutputEJetContainer' : '', # str
    'DeltaRCut' : 1.5362447e-312, # float
    'TruthAvailable' : True, # bool
  }
  _propertyDocDct = { 
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(BUSTopOverlap, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'BUSTopPreselection'
  def getType( self ):
      return 'BUSTopOverlap'
  pass # class BUSTopOverlap

class BUSTopJES( ConfigurableAlgorithm ) :
  __slots__ = { 
    'OutputLevel' : 0, # int
    'Enable' : True, # bool
    'ErrorMax' : 1, # int
    'ErrorCount' : 0, # int
    'AuditAlgorithms' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditReinitialize' : False, # bool
    'AuditExecute' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditBeginRun' : False, # bool
    'AuditEndRun' : False, # bool
    'MonitorService' : 'MonitorSvc', # str
    'JetInputContainer' : '', # str
    'JetOutputContainer' : '', # str
    'METInputContainer' : '', # str
    'METOutputContainer' : '', # str
    'JESScale' : 1.0756649e-259, # float
    'TruthAvailable' : True, # bool
  }
  _propertyDocDct = { 
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(BUSTopJES, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'BUSTopPreselection'
  def getType( self ):
      return 'BUSTopJES'
  pass # class BUSTopJES

class BUSTopBJetTagger( ConfigurableAlgorithm ) :
  __slots__ = { 
    'OutputLevel' : 0, # int
    'Enable' : True, # bool
    'ErrorMax' : 1, # int
    'ErrorCount' : 0, # int
    'AuditAlgorithms' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditReinitialize' : False, # bool
    'AuditExecute' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditBeginRun' : False, # bool
    'AuditEndRun' : False, # bool
    'MonitorService' : 'MonitorSvc', # str
    'InputJetContainer' : '', # str
    'OutputBJetContainer' : '', # str
    'OutputLJetContainer' : '', # str
    'JetWeightTagger' : '', # str
    'RelativeTag' : True, # bool
    'WeightCut' : 6.01347e-154, # float
    'TruthAvailable' : True, # bool
  }
  _propertyDocDct = { 
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(BUSTopBJetTagger, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'BUSTopPreselection'
  def getType( self ):
      return 'BUSTopBJetTagger'
  pass # class BUSTopBJetTagger

class BUSTopTriggerDecision( ConfigurableAlgorithm ) :
  __slots__ = { 
    'OutputLevel' : 0, # int
    'Enable' : True, # bool
    'ErrorMax' : 1, # int
    'ErrorCount' : 0, # int
    'AuditAlgorithms' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditReinitialize' : False, # bool
    'AuditExecute' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditBeginRun' : False, # bool
    'AuditEndRun' : False, # bool
    'MonitorService' : 'MonitorSvc', # str
    'InputElectronContainer' : '', # str
    'InputMuonContainer' : '', # str
    'TruthAvailable' : True, # bool
    'RunTrigger' : False, # bool
    'PrintMenu' : False, # bool
    'ElectronTriggerItems' : [  ], # list
    'MuonTriggerItems' : [  ], # list
    'ElectronPtCut' : 8.6585264e+217, # float
    'MuonPtCut' : 7.0024742e+194, # float
    'TrigDecisionTool' : PublicToolHandle('TrigDec::TrigDecisionTool'), # GaudiHandle
  }
  _propertyDocDct = { 
    'TrigDecisionTool' : """ The tool to access TrigDecision """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(BUSTopTriggerDecision, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'BUSTopPreselection'
  def getType( self ):
      return 'BUSTopTriggerDecision'
  pass # class BUSTopTriggerDecision

class BUSTopPreselection( ConfigurableAlgorithm ) :
  __slots__ = { 
    'OutputLevel' : 0, # int
    'Enable' : True, # bool
    'ErrorMax' : 1, # int
    'ErrorCount' : 0, # int
    'AuditAlgorithms' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditReinitialize' : False, # bool
    'AuditExecute' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditBeginRun' : False, # bool
    'AuditEndRun' : False, # bool
    'MonitorService' : 'MonitorSvc', # str
    'FilterResults' : 170553168, # int
    'PreselectionResult' : '', # str
    'InputElectronContainer' : '', # str
    'InputBJetContainer' : '', # str
    'InputLightJetContainer' : '', # str
    'InputMuonContainer' : '', # str
    'InputMETContainer' : '', # str
    'OutputElectronContainer' : '', # str
    'OutputBJetContainer' : '', # str
    'OutputLightJetContainer' : '', # str
    'OutputMuonContainer' : '', # str
    'OutputMETContainer' : '', # str
    'TruthAvailable' : True, # bool
    'QuitOnFail' : True, # bool
  }
  _propertyDocDct = { 
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(BUSTopPreselection, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'BUSTopPreselection'
  def getType( self ):
      return 'BUSTopPreselection'
  pass # class BUSTopPreselection
