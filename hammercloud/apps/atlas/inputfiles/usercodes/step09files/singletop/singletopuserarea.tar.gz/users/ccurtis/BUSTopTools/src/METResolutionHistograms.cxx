#include "ParticleEvent/ParticleBase.h" 
#include "StoreGate/StoreGateSvc.h"
#include "StoreGate/DataHandle.h"

#include "McParticleEvent/TruthParticleContainer.h"
#include "MissingETEvent/MissingEtCalo.h"
#include "EventKernel/PdtPdg.h"
#include "AnalysisUtils/IParticleFilter.h"
#include "AnalysisUtils/AnalysisMisc.h"

#include "BUSTopTools/METResolutionHistograms.h" 
#include "BUSTopTools/BUSTopHistogrammer.h"

#include <iostream>
#include <string>
#include <queue>
#include <cmath>

#include "TH1.h"
#include "TH2.h"

METResolutionHistograms::METResolutionHistograms(IBUSTopHistogrammer* parent, std::string algName, std::string dirName, std::string hN){

  std::stringstream fname, hname, title;

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "_phi";
  fname << "/AANT/" << algName << "/" << dirName << "/" << hname.str();
  title << "Resolution \\phi";
  parent->registerHistogram(phi, fname.str(), hname.str(), title.str(), "\\Delta\\phi", 100, M_PI, M_PI);

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "_etx";
  fname << "/AANT/" << algName << "/" << dirName << "/" << hname.str();
  title << "Resolution E_{T}^{x}";
  parent->registerHistogram(etx, fname.str(), hname.str(), title.str(), "\\Delta E_{T}^{x} [GeV]", 200, -100, 100);

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "_ety";
  fname << "/AANT/" << algName << "/" << dirName << "/" << hname.str();
  title << "Resolution E_{T}^{y}";
  parent->registerHistogram(ety, fname.str(), hname.str(), title.str(), "\\Delta E_{T}^{y} [GeV]", 200, -100, 100);

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "_et";
  fname << "/AANT/" << algName << "/" << dirName << "/" << hname.str();
  title << "Resolution E_{T}";
  parent->registerHistogram(et, fname.str(), hname.str(), title.str(), "\\Delta E_{T} [GeV]", 200, -100, 100);

}

