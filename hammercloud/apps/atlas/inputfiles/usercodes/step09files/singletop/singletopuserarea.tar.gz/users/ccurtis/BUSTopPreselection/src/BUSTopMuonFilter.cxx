#include "GaudiKernel/IToolSvc.h"
#include "GaudiKernel/ITHistSvc.h"

#include "TH1.h"
#include "TH2.h"

#include "McParticleEvent/TruthParticle.h"
#include "McParticleEvent/TruthParticleContainer.h"
#include "muonEvent/MuonContainer.h"

#include "DataModel/ElementLink.h"

#include "AnalysisTools/IAnalysisTools.h"
#include "AnalysisUtils/IParticleFilter.h"

#include "BUSTopTools/EventTool.h"
#include "BUSTopTools/EventTagTool.h"

#include "BUSTopPreselection/BUSTopMuonFilter.h"

#include <stdint.h>
#include <algorithm>
#include <math.h>
#include <functional>

BUSTopMuonFilter::BUSTopMuonFilter(const std::string& name, ISvcLocator* pSvcLocator) : 
                     Algorithm(name, pSvcLocator){

  declareProperty("MuonInputContainer", m_inputMuonContainerName);
  declareProperty("MuonOutputContainer", m_outputMuonContainerName);

  declareProperty("TruthAvailable", m_truthAvailable);
}

BUSTopMuonFilter::~BUSTopMuonFilter(){
}

StatusCode BUSTopMuonFilter::initialize() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << "Initializing BUSTopMuonFilter" << endreq;

  if (service("StoreGateSvc", m_storeGate).isFailure()) {
     mLog << MSG::ERROR << "Unable to retrieve pointer to StoreGateSvc" << endreq;
     return StatusCode::FAILURE;
  }

  service("THistSvc", m_histSvc);

  IToolSvc * toolSvc;
  service("ToolSvc", toolSvc);

  IAlgTool *tmp_eventTool;
  toolSvc->retrieveTool("EventTool", tmp_eventTool);
  m_eventTool = dynamic_cast<IEventTool *>(tmp_eventTool);

  IAlgTool *tmp_eventTagTool;
  toolSvc->retrieveTool("EventTagTool", tmp_eventTagTool);
  m_tagTool = dynamic_cast<IEventTagTool *>(tmp_eventTagTool);

  registerHistograms();

  return StatusCode::SUCCESS;
}

void BUSTopMuonFilter::registerHistograms(){
}

StatusCode BUSTopMuonFilter::finalize() {
  MsgStream mLog( messageService(), name() );
  
  return StatusCode::SUCCESS;
}

StatusCode BUSTopMuonFilter::execute() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << "execute()" << endreq;

  getEventWeight();
  getStoregateContainers();
  createTemporaryContainers();

  filterMuons();

  registerContainers();
  destroyTemporaryContainers();

  StatusCode sc = StatusCode::SUCCESS;

  return sc;

}

void BUSTopMuonFilter::getStoregateContainers(){
  MsgStream mLog( messageService(), name() );

  muonTES = 0;

  m_storeGate->retrieve(muonTES, m_inputMuonContainerName);
  if(muonTES == 0){
    mLog << MSG::ERROR << "Problem getting input MuonContainer" << endreq;
  }
}

void BUSTopMuonFilter::createTemporaryContainers(){
  c_filtered_muons = new Analysis::MuonContainer(SG::VIEW_ELEMENTS);
}

void BUSTopMuonFilter::destroyTemporaryContainers(){
  delete c_filtered_muons;
  c_filtered_muons = 0;
}

void BUSTopMuonFilter::registerContainers(){
  registerContainer(muonTES, m_outputMuonContainerName);
}

void BUSTopMuonFilter::registerContainer(const Analysis::MuonContainer* m, std::string n){
  MsgStream mLog( messageService(), name() );

  Analysis::MuonContainer* tmp = new Analysis::MuonContainer();

  m_storeGate->record(tmp, n);

  Analysis::MuonContainer::const_iterator mIter = m->begin();
  Analysis::MuonContainer::const_iterator mIterEnd = m->end();

  while(mIter < mIterEnd){
    tmp->push_back(new Analysis::Muon(**mIter));
    mIter++;
  }

  AnalysisUtils::Sort::pT(tmp);

  m_storeGate->setConst(tmp);

  if(tmp->size() > 1){
    mLog << MSG::DEBUG << "Muon Pt: " << tmp->at(0)->pt() << endreq;
    mLog << MSG::DEBUG << "Muon Pt: " << tmp->at(1)->pt() << endreq;
  }
}

void BUSTopMuonFilter::filterMuons(){
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "done filtering muons..." << endreq;
}

void BUSTopMuonFilter::getEventWeight(){
  if(m_tagTool->tagged(IEventTagTool::IS_ATLFAST) == false && m_tagTool->tagged(IEventTagTool::IS_MC) == true){
    m_eventWeight = m_eventTool->getEventWeight();
  }else{
    m_eventWeight = 1.0;
  }
}

