from BUSTopReconstruction.BUSTopReconstructionConf import BUSTopWReconstruction

###############################################################################
#  Reconstructed W's based on output from AOD Inputs                          #
###############################################################################

BUSTopWRecon_Full = BUSTopWReconstruction( "BUSTopWRecon_Full" )
BUSTopWRecon_Full.OutputLevel = WARNING

BUSTopWRecon_Full.InputElectrons                         = BUSTopPreselection.InputElectronContainer
BUSTopWRecon_Full.InputMuons                             = BUSTopPreselection.InputMuonContainer
BUSTopWRecon_Full.InputNeutrinos                         = BUSTopNuRecon_Full.OutputNeutrinoContainer
BUSTopWRecon_Full.OutputWName                            = "FullW"
BUSTopWRecon_Full.TruthAvailable                         = DoTruth
BUSTopWRecon_Full.FilterTags                             = BUSTopNuRecon_Full.FilterTags

###############################################################################
#  Reconstructed W's based on output from Preselection algorithm              #
###############################################################################

BUSTopWRecon_Preselection = BUSTopWReconstruction( "BUSTopWRecon_Preselection" )
BUSTopWRecon_Preselection.OutputLevel = WARNING

BUSTopWRecon_Preselection.InputElectrons                         = BUSTopPreselection.OutputElectronContainer
BUSTopWRecon_Preselection.InputMuons                             = BUSTopPreselection.OutputMuonContainer
BUSTopWRecon_Preselection.InputNeutrinos                         = BUSTopNuRecon_Preselection.OutputNeutrinoContainer
BUSTopWRecon_Preselection.OutputWName                            = "PreselectedW"
BUSTopWRecon_Preselection.TruthAvailable                         = DoTruth
BUSTopWRecon_Preselection.FilterTags                             = BUSTopNuRecon_Preselection.FilterTags

###############################################################################
#  Reconstructed W's based on output from CSCSelection algorithm              #
###############################################################################

BUSTopWRecon_CSCSelection = BUSTopWReconstruction( "BUSTopWRecon_CSCSelection" )
BUSTopWRecon_CSCSelection.OutputLevel = WARNING

BUSTopWRecon_CSCSelection.InputElectrons                         = BUSTopCSCSelection.OutputElectronContainer
BUSTopWRecon_CSCSelection.InputMuons                             = BUSTopCSCSelection.OutputMuonContainer
BUSTopWRecon_CSCSelection.InputNeutrinos                         = BUSTopNuRecon_CSCSelection.OutputNeutrinoContainer
BUSTopWRecon_CSCSelection.OutputWName                            = "CSCSelectedW"
BUSTopWRecon_CSCSelection.TruthAvailable                         = DoTruth
BUSTopWRecon_CSCSelection.FilterTags                             = BUSTopNuRecon_CSCSelection.FilterTags

###############################################################################
#  Reconstructed W's based on output from Selection algorithm                 #
###############################################################################

if DoSelection:
	BUSTopWRecon_Selection = BUSTopWReconstruction( "BUSTopWRecon_Selection" )
	BUSTopWRecon_Selection.OutputLevel = WARNING

	BUSTopWRecon_Selection.InputElectrons         = BUSTopSelection.OutputElectronContainer
	BUSTopWRecon_Selection.InputMuons             = BUSTopSelection.OutputMuonContainer
	BUSTopWRecon_Selection.InputNeutrinos         = BUSTopNuRecon_Selection.OutputNeutrinoContainer
	BUSTopWRecon_Selection.OutputWName            = "SelectedW"
	BUSTopWRecon_Selection.TruthAvailable         = DoTruth
	BUSTopWRecon_Selection.FilterTags             = [LEPTON_SELECTION, NUSELECTION]

###############################################################################
#  Append Algorithms to main Sequencer                                        #
###############################################################################

Sequencer += BUSTopWRecon_Full
Sequencer += BUSTopWRecon_Preselection
Sequencer += BUSTopWRecon_CSCSelection

if DoSelection:
	Sequencer += BUSTopWRecon_Selection
