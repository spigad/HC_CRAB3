from BUSTopPreselection.BUSTopPreselectionConf import BUSTopJES

Sequencer += BUSTopJES()
BUSTopJES.OutputLevel = WARNING

BUSTopJES.JetInputContainer                      = BUSTopOverlap.OutputJetContainer
BUSTopJES.JetOutputContainer                     = "ScaledJets"

BUSTopJES.METInputContainer                      = RootMetContainer
BUSTopJES.METOutputContainer                     = "ScaledMET"

BUSTopJES.JESScale                                         = 1.00

if DoTruth:
        BUSTopJES.TruthAvailable     = 1
else:
        BUSTopJES.TruthAvailable     = 0


