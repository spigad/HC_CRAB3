#include "BUSTopTools/JetHistograms.h"
#include "BUSTopTools/BUSTopHistogrammer.h"

#include "StoreGate/StoreGateSvc.h"
#include "StoreGate/DataHandle.h"

#include "JetEvent/JetCollection.h"
#include "JetEvent/Jet.h"
#include "JetTagEvent/TrackAssociation.h"
#include "Particle/TrackParticleContainer.h"
#include "Particle/TrackParticle.h"

#include "EventKernel/PdtPdg.h"

#include "AnalysisUtils/IParticleFilter.h"
#include "AnalysisUtils/AnalysisMisc.h"

#include <iostream>
#include <string>
#include <queue>

#include "TH1.h"
#include "TH2.h"
#include "TH3.h"

JetHistograms::JetHistograms(IBUSTopHistogrammer* parent, std::string algName, std::string dirName, std::string hN, std::string tagger):KinematicHistograms(parent, algName, dirName, hN){
  weight = new TH1F*[3];
  nTrks = new TH1F*[3];
  bestQTrk = new TH1F*[3];

  m_tagger = tagger;

  std::stringstream fname, hname, title;

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "_weight";
  fname << "/AANT/"<< algName <<"/" << dirName << "/" << hname.str();
  title << "Weight";
  if(m_tagger == "JetProb"){
    parent->registerHistogram(weight, fname.str(), hname.str(), title.str(), "Weight", 100, 0.0, 1.0);
  }else{
    parent->registerHistogram(weight, fname.str(), hname.str(), title.str(), "Weight", 60, -9.95, 50.05);
  }

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "_nTrks";
  fname << "/AANT/"<< algName <<"/" << dirName << "/" << hname.str();
  title << "nTrks";
  parent->registerHistogram(nTrks, fname.str(), hname.str(), title.str(), "nTrks", 30, 0, 30);

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "_bestQTrk";
  fname << "/AANT/"<< algName <<"/" << dirName << "/" << hname.str();
  title << "bestQTrk";
  parent->registerHistogram(bestQTrk, fname.str(), hname.str(), title.str(), "bestQTrk", 100, 0, 100);
}

void JetHistograms::useTagger(std::string t){
  m_tagger = t;
}

void JetHistograms::plotContainer(const JetCollection* c, double w, int maxCount){

  int totCount = 0;

  if(c->size() > 0){
    JetCollection::const_iterator iter = c->begin();
    JetCollection::const_iterator iterEnd = c->end();

    if(maxCount == -1){
      while(iter < iterEnd){
        plot(*iter, w);
        iter++;
        totCount++;
      }
    }else{
      while(iter < iterEnd && totCount < maxCount){
        plot(*iter, w);
        iter++;
        totCount++;
      }
    }
  }

  n[0]->Fill(c->size(), w);
}

void JetHistograms::plot(const Jet* particle, double w){
  const Analysis::TrackAssociation* ta = particle->getAssociation<Analysis::TrackAssociation>("Tracks");
  std::vector<const Rec::TrackParticle*>* trks = ta->tracks();
  int trkCount = trks->size();

  delete trks;

  phi[0]->Fill(particle->phi(), w);
  eta[0]->Fill(particle->eta(), w);
  p[0]->Fill(particle->p()/GeV, w);
  px[0]->Fill(particle->px()/GeV, w);
  py[0]->Fill(particle->py()/GeV, w);
  pz[0]->Fill(particle->pz()/GeV, w);
  pt[0]->Fill(particle->pt()/GeV, w);
  ipt[0]->Fill(GeV/particle->pt(), w);
  costheta[0]->Fill(particle->cosTh(), w);
  ptop[0]->Fill(fabs(particle->pt()/particle->p()), w);
  etoe[0]->Fill(fabs(particle->et()/particle->e()), w);
  e[0]->Fill(particle->e()/GeV, w);

  if(m_tagger == "Default"){
    weight[0]->Fill(particle->getFlavourTagWeight(), w);
  }else{
    weight[0]->Fill(particle->getFlavourTagWeight(m_tagger.c_str()), w);
  }

  nTrks[0]->Fill(trkCount, w);

  int index = 1;
  if(particle->charge() < 0){
    index = 2;
  }

  phi[index]->Fill(particle->phi(), w);
  eta[index]->Fill(particle->eta(), w);
  p[index]->Fill(particle->p()/GeV, w);
  px[index]->Fill(particle->px()/GeV, w);
  py[index]->Fill(particle->py()/GeV, w);
  pz[index]->Fill(particle->pz()/GeV, w);
  pt[index]->Fill(particle->pt()/GeV, w);
  ipt[index]->Fill(GeV/particle->pt(), w);
  costheta[index]->Fill(particle->cosTh(), w);
  ptop[index]->Fill(fabs(particle->pt()/particle->p()), w);
  etoe[index]->Fill(fabs(particle->et()/particle->e()), w);
  e[index]->Fill(particle->e()/GeV, w);

  if(m_tagger == "Default"){
    weight[index]->Fill(particle->getFlavourTagWeight(), w);
  }else{
    weight[index]->Fill(particle->getFlavourTagWeight(m_tagger.c_str()), w);
  }
  nTrks[index]->Fill(trkCount, w);

}

