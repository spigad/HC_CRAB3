#ifndef BUSTOP_T_RECONSTRUCTION_H
#define BUSTOP_T_RECONSTRUCTION_H

#include "GaudiKernel/Algorithm.h"

#include "CLHEP/Units/SystemOfUnits.h"

#include "StoreGate/StoreGateSvc.h"

#include "GaudiKernel/ToolHandle.h"

#include "BUSTopTools/EventTagTool.h"

#include <stdint.h>
#include <string>

class ITHistSvc;
class TH1F;
class TH2F;

class IAnalysisTools;

class JetCollection;
class CompositeParticleContainer;

class IBUSTopHistogrammer;
class IEventTool;

class BUSTopTReconstruction : public Algorithm {

 public:

   BUSTopTReconstruction(const std::string& name, ISvcLocator* pSvcLocator);
   ~BUSTopTReconstruction();

   StatusCode initialize();
   StatusCode finalize();
   StatusCode execute();
  
 private:
   StoreGateSvc* m_storeGate;
   ITHistSvc*    m_histSvc;
   IBUSTopHistogrammer *m_histogrammer;
   IEventTool *m_eventTool;
   IEventTagTool *m_tagTool;

   std::string m_outputTopName;

   std::string m_inputWName;
   std::string m_inputBJetName;

   BUSTopTags m_filterTags;

   bool m_applyMassVeto;
   double m_lowMassVeto;
   double m_highMassVeto;

   double m_eventWeight;
   bool m_truthAvailable;

   virtual void registerHistograms();

   virtual void getEventWeight();
   virtual void getStoregateContainers();
   virtual void createTemporaryContainers();
   virtual void destroyTemporaryContainers();

   virtual void registerContainers();
   virtual void registerContainer(CompositeParticleContainer* c, std::string name);

   virtual void reconstructTop();

   const JetCollection* c_bJets;
   const CompositeParticleContainer* c_w;

   CompositeParticleContainer* c_top;

   TH1F* h_recon;
   TH1F* h_size;
};

#endif // BUSTOP_T_RECONSTRUCTION_H


