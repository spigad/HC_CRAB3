#include "GaudiKernel/IToolSvc.h"
#include "GaudiKernel/ITHistSvc.h"

#include "TH1.h"
#include "TH2.h"

#include "AnalysisTools/IAnalysisTools.h"

#include "BUSTopTools/EventTool.h"
#include "BUSTopTools/EventTagTool.h"

#include "BUSTopAnalysis/BUSTopInitAlg.h"

BUSTopInitAlg::BUSTopInitAlg(const std::string& name, ISvcLocator* pSvcLocator) : 
                     Algorithm(name, pSvcLocator){

  declareProperty("IsAtlfast", m_isAtlfast);
  declareProperty("IsMC", m_isMC);
}

BUSTopInitAlg::~BUSTopInitAlg(){
}

StatusCode BUSTopInitAlg::initialize() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << "Initializing BUSTopInitAlg " << endreq;

  if (service("StoreGateSvc", m_storeGate).isFailure()) {
     mLog << MSG::ERROR << "Unable to retrieve pointer to StoreGateSvc" << endreq;
     return StatusCode::FAILURE;
  }

  service("THistSvc", m_histSvc);

  IToolSvc * toolSvc;
  service("ToolSvc", toolSvc);

  IAlgTool *tmp_eventTool = 0;
  toolSvc->retrieveTool("EventTool", tmp_eventTool);
  m_eventTool = dynamic_cast<IEventTool *>(tmp_eventTool);

  IAlgTool* tmp_tagTool = 0;
  toolSvc->retrieveTool("EventTagTool", tmp_tagTool);
  m_tagTool = dynamic_cast<IEventTagTool *>(tmp_tagTool);

  registerHistograms();

  return StatusCode::SUCCESS;
}

void BUSTopInitAlg::registerHistograms(){
}

StatusCode BUSTopInitAlg::finalize() {
  MsgStream mLog( messageService(), name() );
  
  return StatusCode::SUCCESS;
}

StatusCode BUSTopInitAlg::execute() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << "execute()" << endreq;
 
  m_tagTool->initialiseTags();

  if(m_isAtlfast == true){
    m_tagTool->tag(IEventTagTool::IS_ATLFAST);
    m_tagTool->tag(IEventTagTool::IS_ATLFAST);
  }

  if(m_isMC == true){
    m_tagTool->tag(IEventTagTool::IS_MC);
    m_tagTool->tag(IEventTagTool::IS_MC);
  }

  getEventWeight(); 


  StatusCode sc = StatusCode::SUCCESS;

  return sc;
}

void BUSTopInitAlg::getEventWeight(){
  if(m_tagTool->tagged(IEventTagTool::IS_ATLFAST) == false && m_tagTool->tagged(IEventTagTool::IS_MC) == true){
    m_eventWeight = m_eventTool->getEventWeight();
  }else{
    m_eventWeight = 1.0;
  }
}

