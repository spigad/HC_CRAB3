#ifndef RESOLUTION_HISTOGRAMS_H
#define RESOLUTION_HISTOGRAMS_H

#include "GaudiKernel/AlgTool.h"
#include "GaudiKernel/MsgStream.h"
#include "GaudiKernel/AlgFactory.h"
#include "StoreGate/DataHandle.h"
#include "AIDA/IHistogram1D.h"
#include "AIDA/IHistogram2D.h"

#include <string>

class ParticleBase;
class IBUSTopHistogrammer;
class TruthParticle;
class TH1F;
class TH2F;

class ResolutionHistograms{
   public:
     TH1F** deltaR;
     TH2F** deltaRP;
     TH1F** phi;
     TH1F** eta;
     TH1F** p;
     TH1F** px;
     TH1F** py;
     TH1F** pz;
     TH1F** pt;
     TH1F** e;
     TH1F** et;
     TH1F** costheta;

     ResolutionHistograms(IBUSTopHistogrammer* parent, std::string algName, std::string dirName, std::string hname, double deltaRCut = 6.0);
     virtual ~ResolutionHistograms(){};

    template<class PARTICLE> void plot(const TruthParticle* p, const PARTICLE* q, double w);
};

#include "BUSTopTools/ResolutionHistograms.icc"

#endif
