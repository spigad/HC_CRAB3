from BUSTopPreselection.BUSTopPreselectionConf import BUSTopBJetTagger
Sequencer += BUSTopBJetTagger()
BUSTopBJetTagger.OutputLevel = WARNING

BUSTopBJetTagger.InputJetContainer           = BUSTopJES.JetOutputContainer
BUSTopBJetTagger.JetWeightTagger             = RootJetTagger
BUSTopBJetTagger.RelativeTag                 = 1
BUSTopBJetTagger.WeightCut                   = 1.08
BUSTopBJetTagger.OutputBJetContainer         = "BTaggedJets"
BUSTopBJetTagger.OutputLJetContainer         = "LightJets"

if DoTruth:
	BUSTopBJetTagger.TruthAvailable = 1
else:
	BUSTopBJetTagger.TruthAvailable = 0
		
