## Hook for BUSTopAnalysis genConf module
