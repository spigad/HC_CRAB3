#include "GaudiKernel/IToolSvc.h"
#include "GaudiKernel/ITHistSvc.h"

#include "egammaEvent/ElectronContainer.h"
#include "egammaEvent/Electron.h"
#include "CompositeParticleEvent/CompositeParticleContainer.h"
#include "CompositeParticleEvent/CompositeParticle.h"
#include "MissingETEvent/MissingET.h"

#include "TH1.h"
#include "TH2.h"

#include "AnalysisTools/IAnalysisTools.h"

#include "BUSTopTools/EventTool.h"
#include "BUSTopTools/EventTagTool.h"

#include "BUSTopAnalysis/BUSTopZSelection.h"

BUSTopZSelection::BUSTopZSelection(const std::string& name, ISvcLocator* pSvcLocator) : 
                     Algorithm(name, pSvcLocator){
  declareProperty("ElectronInputContainer", m_electronContainerName);
  declareProperty("METInputContainer", m_metContainerName);
}

BUSTopZSelection::~BUSTopZSelection(){
}

StatusCode BUSTopZSelection::initialize() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << "Initializing BUSTopZSelection " << endreq;

  if (service("StoreGateSvc", m_storeGate).isFailure()) {
     mLog << MSG::ERROR << "Unable to retrieve pointer to StoreGateSvc" << endreq;
     return StatusCode::FAILURE;
  }

  service("THistSvc", m_histSvc);

  IToolSvc * toolSvc;
  service("ToolSvc", toolSvc);

  IAlgTool *tmp_eventTool = 0;
  toolSvc->retrieveTool("EventTool", tmp_eventTool);
  m_eventTool = dynamic_cast<IEventTool *>(tmp_eventTool);

  IAlgTool *tmp_tagTool = 0;
  toolSvc->retrieveTool("EventTagTool", tmp_tagTool);
  m_tagTool = dynamic_cast<IEventTagTool *>(tmp_tagTool);

  registerHistograms();

  return StatusCode::SUCCESS;
}

void BUSTopZSelection::registerHistograms(){
  std::stringstream fName, hName;
  std::string title;

  std::string var[3];
  var[0] = "zs_elec_ll_mass";
  var[1] = "zs_elec_lm_mass";
  var[2] = "zs_elec_mm_mass";

  for(int i = 0; i < 3; i++){
    fName.str("");
    hName.str("");
    hName << var[i];
    fName << "/AANT/ZSelection/Electron/" << hName.str();
    title = "Z Mass";
    h_elec_z_mass[i] = new TH1F(hName.str().c_str(), title.c_str(), 150, 0, 150);
    m_histSvc->regHist(fName.str().c_str(), h_elec_z_mass[i]);

    fName.str("");
    hName.str("");
    hName << var[i] << "_count";
    fName << "/AANT/ZSelection/Electron/" << hName.str();
    title = "Z Mass";
    h_elec_z_mass_count[i] = new TH1F(hName.str().c_str(), title.c_str(), 10, 0, 10);
    m_histSvc->regHist(fName.str().c_str(), h_elec_z_mass_count[i]);
  }
}

StatusCode BUSTopZSelection::finalize() {
  MsgStream mLog( messageService(), name() );
  
  return StatusCode::SUCCESS;
}

StatusCode BUSTopZSelection::execute() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << "execute()" << endreq;
 
  getEventWeight(); 
  getStoregateContainers();

  if(m_tagTool->tagged(IEventTagTool::TRIGGERED_ELECTRON)){
    electronRecon();
  }

  StatusCode sc = StatusCode::SUCCESS;

  return sc;
}

void BUSTopZSelection::getEventWeight(){
  if(m_tagTool->tagged(IEventTagTool::IS_ATLFAST) == false && m_tagTool->tagged(IEventTagTool::IS_MC) == true){  
    m_eventWeight = m_eventTool->getEventWeight();
  }else{
    m_eventWeight = 1.0;
  }
}

void BUSTopZSelection::getStoregateContainers(){
  MsgStream mLog( messageService(), name() );
    
  mLog << MSG::DEBUG << "Getting storegateContainers..." << endreq;

  elecTES = 0;
  m_storeGate->retrieve(elecTES, m_electronContainerName);
  if(elecTES == 0){
    mLog << MSG::ERROR << "Problem getting Electron Container" << endreq;
  }

  metTES = 0;
  m_storeGate->retrieve(metTES, m_metContainerName);
  if(metTES == 0){
    mLog << MSG::ERROR << "Problem getting MET Container" << endreq;
  }
}

void BUSTopZSelection::electronRecon(){
  reconstructZ(h_elec_z_mass[0], h_elec_z_mass_count[0], egammaPID::ElectronLoose, egammaPID::ElectronLoose);
  reconstructZ(h_elec_z_mass[1], h_elec_z_mass_count[1], egammaPID::ElectronMedium, egammaPID::ElectronLoose);
  reconstructZ(h_elec_z_mass[2], h_elec_z_mass_count[2], egammaPID::ElectronMedium, egammaPID::ElectronMedium);
}

void BUSTopZSelection::reconstructZ(TH1F* h_mass, TH1F* h_count, int mask1, int mask2){
  
  MsgStream mLog( messageService(), name() );

  ElectronContainer::const_iterator e1 = elecTES->begin();
  ElectronContainer::const_iterator e1End = elecTES->end();

  int count = 0;

  while(e1 < e1End){
    //make sure that first electron passes mask
    if((*e1)->isem(mask1) == 0){
      mLog << MSG::DEBUG << "e1 passed mask" << endreq;

      ElectronContainer::const_iterator e2 = e1 + 1;
      ElectronContainer::const_iterator e2End = elecTES->end();

      while(e2 < e2End){
        if((*e2)->isem(mask2) == 0){
          bool result = reconstructZ(*e1, *e2);  
          if(result == true){
            CompositeParticle* z = new CompositeParticle();
            z->add(*e1);
            z->add(*e2);
            h_mass->Fill(z->m()/GeV, m_eventWeight);
            count++;
          }
        }
        e2++;
      }
    }
    e1++;
  }

  h_count->Fill(count, m_eventWeight);
}

bool BUSTopZSelection::reconstructZ(const Analysis::Electron* e1, const Analysis::Electron* e2){
  if(e1->charge() == e2->charge()){
    return false;
  }

  CompositeParticle* z = new CompositeParticle();
  z->add(e1);
  z->add(e2);

  if(z->m()/GeV > 100 || z->m()/GeV < 80){
    return false;
  }

  if(metTES->et() > 20*GeV){
    return false;
  }

  return true;
}
