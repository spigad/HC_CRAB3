#include "BUSTopTools/EventTool.h"

#include "StoreGate/StoreGateSvc.h"
#include "StoreGate/DataHandle.h"

#include "EventInfo/EventInfo.h"
#include "EventInfo/EventType.h"
#include "McParticleEvent/TruthParticleContainer.h"

#include <iostream>
#include <string>
#include <queue>


EventTool::EventTool(const std::string& t, const std::string& n, const IInterface* p):AlgTool(t, n, p), m_log(msgSvc(), n){
  declareInterface<IEventTool>(this);
}

EventTool::~EventTool(){
}

StatusCode EventTool::initialize(){
  m_log.setLevel(outputLevel());
  
  service("StoreGateSvc", m_storeGate);
  m_log << MSG::DEBUG << "Initialising EventTool" << endreq;

  return StatusCode::SUCCESS;
}

StatusCode EventTool::finalize(){
  return StatusCode::SUCCESS;
}

const EventInfo* EventTool::getEventInfo(){
  const EventInfo* tmp = 0;

  if(m_storeGate != 0){ 
    m_storeGate->retrieve(tmp);
  }

  return tmp;
}  

double EventTool::getEventWeight(){
  const EventInfo* ev = getEventInfo();
  const EventType* et = ev->event_type();
 
  return getEventWeight(et);
}

double EventTool::getEventWeight(const EventType* et){
  //return AtlasMcWeight::getEventWeight(*ei);
  double weight = et->mc_event_weight();

  if(weight != 0){
    return weight;
  }else{
    return getOldEventWeight();
  }
}

double EventTool::getOldEventWeight(){
  const TruthParticleContainer* mcTES = 0;
  m_storeGate->retrieve(mcTES, "SpclMc");

  if(mcTES == 0){
    m_log << MSG::ERROR << "Could not get proper weight, using 1.0 instead"  << endreq;
    return 1.0;
  }

  TruthParticleContainer::const_iterator evt = mcTES->begin();
  const HepMC::GenEvent* ge = (*evt)->genParticle()->parent_event();
  const HepMC::WeightContainer& wtCont = ge->weights();

  double evtWt = 0;
  unsigned int sz = wtCont.size();

  if(sz==1){
    evtWt  = wtCont[0];
  } else if(sz>=2) {
    evtWt  = wtCont[1];
  }

  return evtWt;
}

