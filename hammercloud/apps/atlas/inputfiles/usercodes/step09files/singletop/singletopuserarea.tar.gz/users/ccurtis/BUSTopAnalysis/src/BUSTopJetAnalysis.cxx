#include "GaudiKernel/MsgStream.h"
#include "GaudiKernel/AlgFactory.h"
#include "GaudiKernel/IToolSvc.h"
#include "GaudiKernel/ITHistSvc.h"

#include "StoreGate/StoreGateSvc.h"
#include "StoreGate/DataHandle.h"

#include "TH1.h"
#include "TH2.h"
#include "TTree.h"

#include "McParticleEvent/TruthParticle.h"
#include "McParticleEvent/TruthParticleContainer.h"
#include "egammaEvent/ElectronContainer.h"
#include "muonEvent/MuonContainer.h"
#include "muonEvent/Muon.h"

#include "JetEvent/JetCollection.h"
#include "JetEvent/Jet.h"
#include "JetTagInfo/TruthInfo.h"
#include "JetTagEvent/TrackConstituents.h"
#include "JetTagEvent/TrackAssociation.h"
#include "Particle/TrackParticleContainer.h"
#include "Particle/TrackParticle.h"

#include "Particle/TrackParticle.h"
#include "MissingETEvent/MissingET.h"

#include "AnalysisTools/IAnalysisTools.h"
#include "AnalysisUtils/AnalysisCombination.h"
#include "AnalysisUtils/AnalysisMisc.h"

#include "BUSTopTools/IBUSTopHistogrammer.h"
#include "BUSTopTools/JetHistograms.h"
#include "BUSTopTools/ResolutionHistograms.h"
#include "BUSTopTools/ITruthMatch.h"
#include "BUSTopTools/EventTool.h"
#include "BUSTopTools/EventTagTool.h"

#include "BUSTopAnalysis/BUSTopJetAnalysis.h"

#include <stdint.h>
#include <string>
#include <algorithm>
#include <math.h>
#include <functional>

#include <stdint.h>
#include <algorithm>
#include <math.h>
#include <functional>
#include <queue>


//////////////////////////////////////////////////////////////////////////////////////
/// Constructor

BUSTopJetAnalysis::BUSTopJetAnalysis(const std::string& name,
  ISvcLocator* pSvcLocator) : Algorithm(name, pSvcLocator)
{
  /// switches to control the analysis through job options :: these are the default
  /// to changed in the job options

  declareProperty("InputJetContainer", m_jetInputContainerName); 
  declareProperty("OverlapJetContainer", m_overlapJetContainerName); 
  declareProperty("OverlapEJetContainer", m_overlapEJetContainerName); 


  declareProperty("ElectronContainer", m_electronContainerName); 
  declareProperty("MuonContainer", m_muonContainerName); 
  declareProperty("BJetContainer", m_bJetContainerName); 
  declareProperty("LightJetContainer", m_lightJetContainerName); 

  declareProperty("PreselectedBJetContainer", m_preselectedBJetContainerName); 
  declareProperty("PreselectedLightJetContainer", m_preselectedLightJetContainerName); 
  declareProperty("PreselectedMuonContainer", m_preselectedMuonContainerName); 
  declareProperty("PreselectedElectronContainer", m_preselectedElectronContainerName); 

  declareProperty("B1SelectedBJetContainer", m_b1SelectedBJetContainerName); 
  declareProperty("LJSelectedLJetContainer", m_ljSelectedLJetContainerName); 

  declareProperty("CSCSelectedBJetContainer", m_cscSelectedBJetContainerName); 
  declareProperty("CSCSelectedLightJetContainer", m_cscSelectedLightJetContainerName); 
  declareProperty("CSCSelectedMuonContainer", m_cscSelectedMuonContainerName); 
  declareProperty("CSCSelectedElectronContainer", m_cscSelectedElectronContainerName); 

  declareProperty("TruthAvailable", m_truthAvailable);  
  declareProperty("PlotJetWeights", m_plotWeights);  
  declareProperty("JetWeightTagger", m_jetWeightTagger);  
  declareProperty("TruthMatchDeltaR", m_truthMatchDeltaR);  

}


/////////////////////////////////////////////////////////////////////////////////////
/// Destructor - check up memory allocation
/// delete any memory allocation on the heap

BUSTopJetAnalysis::~BUSTopJetAnalysis() {
}

////////////////////////////////////////////////////////////////////////////////////
/// Initialize
/// initialize StoreGate
/// get a handle on the analysis tools
/// book histograms

StatusCode BUSTopJetAnalysis::initialize() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO
       << "Initializing BUSTopJetAnalysis"
       << endreq;

  StatusCode sc;
  
  sc = service("StoreGateSvc", m_storeGate);
  if(sc.isFailure()){
    mLog << MSG::ERROR 
         << "Unable to retrieve pointer to StoreGateSvc"
	 << endreq;
    return sc;
  }
  
  sc = service("THistSvc", m_thistSvc);
  if(sc.isFailure()){
    mLog << MSG::ERROR 
         << "Unable to retrieve pointer to THistSvc"
	 << endreq;
    return sc;
  }

  IToolSvc * toolSvc;
  service("ToolSvc", toolSvc);

  IAlgTool *tmp_eventTool;
  toolSvc->retrieveTool("EventTool", tmp_eventTool);
  m_eventTool = dynamic_cast<IEventTool *>(tmp_eventTool);

  IAlgTool *tmp_tagTool;
  toolSvc->retrieveTool("EventTagTool", tmp_tagTool);
  m_tagTool = dynamic_cast<IEventTagTool *>(tmp_tagTool);

  IAlgTool *tmp_truthMatch;
  toolSvc->retrieveTool("TruthMatch", tmp_truthMatch);
  m_truthMatchTool = dynamic_cast<ITruthMatch *>(tmp_truthMatch);

  IAlgTool *tmp_histogramTool;
  toolSvc->retrieveTool("BUSTopHistogrammer", tmp_histogramTool);
  m_histogrammer = dynamic_cast<IBUSTopHistogrammer *>(tmp_histogramTool);

  registerHistograms();
  registerTTrees();

  return StatusCode::SUCCESS;
}

void BUSTopJetAnalysis::registerTTrees(){
}

void BUSTopJetAnalysis::registerB1TTree(TTree* &t, std::string n, float vars[9]){
  std::stringstream tName;

  t = new TTree(n.c_str(), n.c_str());
  tName << "/TREES/B1/" << n;
  m_thistSvc->regTree(tName.str(), t);

  t->Branch("e", &vars[0], "e/F");
  t->Branch("eta", &vars[1], "eta/F");
  t->Branch("lepDEta", &vars[2], "lepDEta/F");
  t->Branch("lepDPhi", &vars[3], "lepDPhi/F");
  t->Branch("lepDR", &vars[4], "lepDR/F");
  t->Branch("nTrks", &vars[5], "nTrks/F");
  t->Branch("pt", &vars[6], "pt/F");
  t->Branch("FracH", &vars[7], "FracH/F");
  t->Branch("EventWeight", &vars[8], "weight/F");
}

void BUSTopJetAnalysis::registerHistograms(){
  std::stringstream fName, hName;
  std::string title;

  std::string stub[4];
  stub[0] = "Full";
  stub[1] = "Preselection";
  stub[2] = "CSCSelection";
  stub[3] = "Truth";

  h_full_jet = new JetHistograms(m_histogrammer, "JetAnalysis", "Kinematic", "ja_full_jet", m_jetWeightTagger);
  h_overlap_jet = new JetHistograms(m_histogrammer, "JetAnalysis", "Kinematic", "ja_overlap_jet", m_jetWeightTagger);

  h_tagged_l_jets = new JetHistograms(m_histogrammer, "JetAnalysis", "Kinematic", "ja_tagged_l_jets", m_jetWeightTagger);
  h_tagged_primary_l_jets = new JetHistograms(m_histogrammer, "JetAnalysis", "Kinematic", "ja_tagged_primary_l_jets", m_jetWeightTagger);
  h_tagged_b_jets = new JetHistograms(m_histogrammer, "JetAnalysis", "Kinematic", "ja_tagged_b_jets", m_jetWeightTagger);

  h_pre_filter_bjets = new JetHistograms(m_histogrammer, "JetAnalysis", "Kinematic", "ja_pre_filter_bjets", m_jetWeightTagger);
  h_pre_filter_ljets = new JetHistograms(m_histogrammer, "JetAnalysis", "Kinematic", "ja_pre_filter_ljets", m_jetWeightTagger);

  h_preselected_l_jets = new JetHistograms(m_histogrammer, "JetAnalysis", "Kinematic", "ja_preselected_l_jets", m_jetWeightTagger);
  h_preselected_primary_l_jets = new JetHistograms(m_histogrammer, "JetAnalysis", "Kinematic", "ja_preselected_primary_l_jets", m_jetWeightTagger);
  h_preselected_b_jets = new JetHistograms(m_histogrammer, "JetAnalysis", "Kinematic", "ja_preselected_b_jets", m_jetWeightTagger);

  h_cscSelected_l_jets = new JetHistograms(m_histogrammer, "JetAnalysis", "Kinematic", "ja_cscSelected_l_jets", m_jetWeightTagger);
  h_cscSelected_primary_l_jets = new JetHistograms(m_histogrammer, "JetAnalysis", "Kinematic", "ja_cscSelected_primary_l_jets", m_jetWeightTagger);
  h_cscSelected_b_jets = new JetHistograms(m_histogrammer, "JetAnalysis", "Kinematic", "ja_cscSelected_b_jets", m_jetWeightTagger);

  h_selected_b_jets = new JetHistograms(m_histogrammer, "JetAnalysis", "Kinematic", "ja_selected_b_jets", m_jetWeightTagger);
  h_selected_b_30pt_jets = new JetHistograms(m_histogrammer, "JetAnalysis", "Kinematic", "ja_selected_b_30pt_jets", m_jetWeightTagger);
  h_selected_l_jets = new JetHistograms(m_histogrammer, "JetAnalysis", "Kinematic", "ja_selected_l_jets", m_jetWeightTagger);

  fName.str("");
  hName.str("");
  hName << "ja_selected_centrality";
  fName << "/AANT/JetAnalysis/" << "Kinematic" << "/" << hName.str();
  title = "Centrality";
  h_selected_centrality = new TH1F(hName.str().c_str(), title.c_str(), 100, 0.0, 1.0);
  m_thistSvc->regHist(fName.str().c_str(), h_selected_centrality);  

  //truth dependent histograms
  if(m_truthAvailable == true){
    h_overlap_b1_ejet_truth_res = new ResolutionHistograms(m_histogrammer, "JetAnalysis", "OverlapAnalysis", "ja_overlap_b1_ejet_truth_res", m_truthMatchDeltaR);
    h_overlap_b3_ejet_truth_res = new ResolutionHistograms(m_histogrammer, "JetAnalysis", "OverlapAnalysis", "ja_overlap_b3_ejet_truth_res", m_truthMatchDeltaR);

    h_b1_truth_match_full = new JetHistograms(m_histogrammer, "JetAnalysis", "Matched", "ja_b1_truth_match_full", m_jetWeightTagger);
    h_b3_truth_match_full = new JetHistograms(m_histogrammer, "JetAnalysis", "Matched", "ja_b3_truth_match_full", m_jetWeightTagger);

    h_lj_truth_match = new JetHistograms(m_histogrammer, "JetAnalysis", "Kinematic", "ja_lj_truth_match", m_jetWeightTagger);
    h_bj_truth_match = new JetHistograms(m_histogrammer, "JetAnalysis", "Kinematic", "ja_bj_truth_match", m_jetWeightTagger);

    h_lj_truth_match_res = new ResolutionHistograms(m_histogrammer, "JetAnalysis", "Kinematic", "ja_lj_truth_match_res", m_truthMatchDeltaR);
    h_bj_truth_match_res = new ResolutionHistograms(m_histogrammer, "JetAnalysis", "Kinematic", "ja_bj_truth_match_res", m_truthMatchDeltaR);

    fName.str("");
    hName.str("");
    hName << "ja_lj_truth_match_res_2";
    fName << "/AANT/JetAnalysis/" << "Kinematic" << "/" << hName.str();
    title = "Jet Res";
    h_lj_truth_match_res_2 = new TH2F(hName.str().c_str(), title.c_str(), 100, -50.0, 50.0, 100, 0.0, 5.0);
    m_thistSvc->regHist(fName.str().c_str(), h_lj_truth_match_res_2);  

    fName.str("");
    hName.str("");
    hName << "ja_bj_truth_match_res_2";
    fName << "/AANT/JetAnalysis/" << "Kinematic" << "/" << hName.str();
    title = "Jet Res";
    h_bj_truth_match_res_2 = new TH2F(hName.str().c_str(), title.c_str(), 100, -50.0, 50.0, 100, 0.0, 5.0);
    m_thistSvc->regHist(fName.str().c_str(), h_bj_truth_match_res_2);  

    fName.str("");
    hName.str("");
    hName << "ja_trig_overlap_jet_n";
    fName << "/AANT/JetAnalysis/" << "OverlapAnalysis" << "/" << hName.str();
    title = "Overlap Analysis";
    h_trig_overlap_jet_n = new TH1F(hName.str().c_str(), title.c_str(), 10, 0.0, 10.0);
    m_thistSvc->regHist(fName.str().c_str(), h_trig_overlap_jet_n);  

    fName.str("");
    hName.str("");
    hName << "ja_trig_overlap_b1_match";
    fName << "/AANT/JetAnalysis/" << "OverlapAnalysis" << "/" << hName.str();
    title = "Overlap Analysis";
    h_trig_overlap_b1_match = new TH1F(hName.str().c_str(), title.c_str(), 2, 0.0, 2.0);
    m_thistSvc->regHist(fName.str().c_str(), h_trig_overlap_b1_match);  

    fName.str("");
    hName.str("");
    hName << "ja_trig_overlap_lj_match";
    fName << "/AANT/JetAnalysis/" << "OverlapAnalysis" << "/" << hName.str();
    title = "Overlap Analysis";
    h_trig_overlap_lj_match = new TH1F(hName.str().c_str(), title.c_str(), 2, 0.0, 2.0);
    m_thistSvc->regHist(fName.str().c_str(), h_trig_overlap_lj_match);  

    fName.str("");
    hName.str("");
    hName << "h_matched_selected_bjet_index";
    fName << "/AANT/JetAnalysis/" << "SelectionAnalysis" << "/" << hName.str();
    title = "Selection Analysis";
    h_matched_selected_bjet_index = new TH1F(hName.str().c_str(), title.c_str(), 2, 0.0, 2.0);
    m_thistSvc->regHist(fName.str().c_str(), h_matched_selected_bjet_index);  

    fName.str("");
    hName.str("");
    hName << "h_matched_selected_ljet_index";
    fName << "/AANT/JetAnalysis/" << "SelectionAnalysis" << "/" << hName.str();
    title = "Selection Analysis";
    h_matched_selected_ljet_index = new TH1F(hName.str().c_str(), title.c_str(), 2, 0.0, 2.0);
    m_thistSvc->regHist(fName.str().c_str(), h_matched_selected_ljet_index);  

    registerTruthInfoHistogram(h_b1_truth_match_full_info, "Matched", "ja_b1_truth_match_full_info");
    registerTruthInfoHistogram(h_b3_truth_match_full_info, "Matched", "ja_b3_truth_match_full_info");

    registerTruthInfoHistogram(h_overlap_info, "OverlapAnalysis", "ja_overlap_info");
    registerTruthInfoHistogram(h_overlap_b1_bjet_truth_info, "OverlapAnalysis", "ja_overlap_b1_bjet_truth_info");
    registerTruthInfoHistogram(h_overlap_b1_ejet_truth_info, "OverlapAnalysis", "ja_overlap_b1_ejet_truth_info");
    registerTruthInfoHistogram(h_overlap_b3_bjet_truth_info, "OverlapAnalysis", "ja_overlap_b3_bjet_truth_info");
    registerTruthInfoHistogram(h_overlap_b3_ejet_truth_info, "OverlapAnalysis", "ja_overlap_b3_ejet_truth_info");

    registerTruthInfoHistogram(h_tagged_lj_info, "TaggingAnalysis", "ja_tagged_lj_info");
    registerTruthInfoHistogram(h_tagged_bj_info, "TaggingAnalysis", "ja_tagged_bj_info");

    registerTruthInfoHistogram(h_tagged_b1_truth_info, "TaggingAnalysis", "ja_tagged_b1_truth_info");
    registerTruthInfoHistogram(h_tagged_b3_truth_info, "TaggingAnalysis", "ja_tagged_b3_truth_info");
    registerTruthInfoHistogram(h_ntagged_b1_truth_info, "TaggingAnalysis", "ja_ntagged_b1_truth_info");
    registerTruthInfoHistogram(h_ntagged_b3_truth_info, "TaggingAnalysis", "ja_ntagged_b3_truth_info");

    registerTruthInfoHistogram(h_preselected_b_truth_info, "Matched", "ja_preselected_b_truth_info");
    registerTruthInfoHistogram(h_preselected_lj_truth_info, "Matched", "ja_preselected_lj_truth_info");

    fName.str("");
    hName.str("");
    hName << "ja_overlap_b1_bjet_truth_weight";
    fName << "/AANT/JetAnalysis/" << "OverlapAnalysis" << "/" << hName.str();
    title = "Overlap Weight";
    if(m_jetWeightTagger == "JetProb"){
      h_overlap_b1_bjet_truth_weight = new TH1F(hName.str().c_str(), title.c_str(), 100, 0.0, 1.0);
    }else{
      h_overlap_b1_bjet_truth_weight = new TH1F(hName.str().c_str(), title.c_str(), 60, -9.95, 50.05);
    }
    h_overlap_b1_bjet_truth_weight->GetXaxis()->SetTitle("B1 Weight");
    m_thistSvc->regHist(fName.str().c_str(), h_overlap_b1_bjet_truth_weight);  

    fName.str("");
    hName.str("");
    hName << "ja_overlap_b3_bjet_truth_weight";
    fName << "/AANT/JetAnalysis/" << "OverlapAnalysis" << "/" << hName.str();
    title = "Overlap Weight";
    if(m_jetWeightTagger == "JetProb"){
      h_overlap_b3_bjet_truth_weight = new TH1F(hName.str().c_str(), title.c_str(), 100, 0.0, 1.0);
    }else{
      h_overlap_b3_bjet_truth_weight = new TH1F(hName.str().c_str(), title.c_str(), 60, -9.95, 50.05);
    }
    h_overlap_b3_bjet_truth_weight->GetXaxis()->SetTitle("B3 Weight");
    m_thistSvc->regHist(fName.str().c_str(), h_overlap_b3_bjet_truth_weight);  

    fName.str("");
    hName.str("");
    hName << "ja_matched_b1_tag_eff_weight";
    fName << "/AANT/JetAnalysis/" << "TaggingAnalysis" << "/" << hName.str();
    title = "Weight";
    if(m_jetWeightTagger == "JetProb"){
      h_matched_b1_tag_eff_weight = new TH1F(hName.str().c_str(), title.c_str(), 100, 0.0, 1.0);
    }else{
      h_matched_b1_tag_eff_weight = new TH1F(hName.str().c_str(), title.c_str(), 60, -9.95, 50.05);
    }
    h_matched_b1_tag_eff_weight->GetXaxis()->SetTitle("B1 Weight");
    m_thistSvc->regHist(fName.str().c_str(), h_matched_b1_tag_eff_weight);  

    fName.str("");
    hName.str("");
    hName << "ja_matched_b3_tag_eff_weight";
    fName << "/AANT/JetAnalysis/" << "TaggingAnalysis" << "/" << hName.str();
    title = "Weight";
    if(m_jetWeightTagger == "JetProb"){
      h_matched_b3_tag_eff_weight = new TH1F(hName.str().c_str(), title.c_str(), 100, 0.0, 1.0);
    }else{
      h_matched_b3_tag_eff_weight = new TH1F(hName.str().c_str(), title.c_str(), 60, -9.95, 50.05);
    }
    h_matched_b3_tag_eff_weight->GetXaxis()->SetTitle("B3 Weight");
    m_thistSvc->regHist(fName.str().c_str(), h_matched_b3_tag_eff_weight);  

    stub[3] = "B1Selection";

    for(int i = 0; i < 4; i++){
      fName.str("");
      hName.str("");
      hName << "ja_1jet_" << stub[i] << "_recon";
      fName << "/AANT/JetAnalysis/" << stub[i] << "/" << hName.str();
      title = "1 Jet Recon";
      h_1jet_recon[i] = new TH1F(hName.str().c_str(), title.c_str(), 3, 0.0, 3.0);
      m_thistSvc->regHist(fName.str().c_str(), h_1jet_recon[i]);  

      fName.str("");
      hName.str("");
      hName << "ja_2jet_" << stub[i] << "_recon";
      fName << "/AANT/JetAnalysis/" << stub[i] << "/" << hName.str();
      title = "2 Jet Recon";
      h_2jet_recon[i] = new TH1F(hName.str().c_str(), title.c_str(), 3, 0.0, 3.0);
      m_thistSvc->regHist(fName.str().c_str(), h_2jet_recon[i]);  

      fName.str("");
      hName.str("");
      hName << "ja_bjet_" << stub[i] << "_recon";
      fName << "/AANT/JetAnalysis/" << stub[i] << "/" << hName.str();
      title = "BJet Recon";
      h_bjet_recon[i] = new TH1F(hName.str().c_str(), title.c_str(), 2, 0.0, 2.0);
      m_thistSvc->regHist(fName.str().c_str(), h_bjet_recon[i]);  

      fName.str("");
      hName.str("");
      hName << "ja_bjet_" << stub[i] << "_recon_ptIndex";
      fName << "/AANT/JetAnalysis/" << stub[i] << "/" << hName.str();
      title = "BJet Recon";
      h_bjet_recon_ptIndex[i] = new TH1F(hName.str().c_str(), title.c_str(), 20, 0.0, 20.0);
      m_thistSvc->regHist(fName.str().c_str(), h_bjet_recon_ptIndex[i]);  

      fName.str("");
      hName.str("");
      hName << "ja_bjet_" << stub[i] << "_recon_etaIndex";
      fName << "/AANT/JetAnalysis/" << stub[i] << "/" << hName.str();
      title = "BJet Recon Eta";
      h_bjet_recon_etaIndex[i] = new TH1F(hName.str().c_str(), title.c_str(), 20, 0.0, 20.0);
      m_thistSvc->regHist(fName.str().c_str(), h_bjet_recon_etaIndex[i]);  

      fName.str("");
      hName.str("");
      hName << "ja_bjet_" << stub[i] << "_recon_eIndex";
      fName << "/AANT/JetAnalysis/" << stub[i] << "/" << hName.str();
      title = "BJet Recon E";
      h_bjet_recon_eIndex[i] = new TH1F(hName.str().c_str(), title.c_str(), 20, 0.0, 20.0);
      m_thistSvc->regHist(fName.str().c_str(), h_bjet_recon_eIndex[i]);  

      fName.str("");
      hName.str("");
      hName << "ja_bjet_" << stub[i] << "_recon_etIndex";
      fName << "/AANT/JetAnalysis/" << stub[i] << "/" << hName.str();
      title = "BJet Recon E_{T}";
      h_bjet_recon_etIndex[i] = new TH1F(hName.str().c_str(), title.c_str(), 20, 0.0, 20.0);
      m_thistSvc->regHist(fName.str().c_str(), h_bjet_recon_etIndex[i]);  

      fName.str("");
      hName.str("");
      hName << "ja_bjet_" << stub[i] << "_recon_weightIndex";
      fName << "/AANT/JetAnalysis/" << stub[i] << "/" << hName.str();
      title = "BJet Recon Tag Weigth";
      h_bjet_recon_weightIndex[i] = new TH1F(hName.str().c_str(), title.c_str(), 20, 0.0, 20.0);
      m_thistSvc->regHist(fName.str().c_str(), h_bjet_recon_weightIndex[i]);  

      fName.str("");
      hName.str("");
      hName << "ja_ljet_" << stub[i] << "_recon";
      fName << "/AANT/JetAnalysis/" << stub[i] << "/" << hName.str();
      title = "Light Jet Recon";
      h_ljet_recon[i] = new TH1F(hName.str().c_str(), title.c_str(), 2, 0.0, 2.0);
      m_thistSvc->regHist(fName.str().c_str(), h_ljet_recon[i]);  

      fName.str("");
      hName.str("");
      hName << "ja_ljet_" << stub[i] << "_recon_ptIndex";
      fName << "/AANT/JetAnalysis/" << stub[i] << "/" << hName.str();
      title = "Light Jet Recon";
      h_ljet_recon_ptIndex[i] = new TH1F(hName.str().c_str(), title.c_str(), 20, 0.0, 20.0);
      m_thistSvc->regHist(fName.str().c_str(), h_ljet_recon_ptIndex[i]);  

      fName.str("");
      hName.str("");
      hName << "ja_ljet_" << stub[i] << "_recon_etaIndex";
      fName << "/AANT/JetAnalysis/" << stub[i] << "/" << hName.str();
      title = "Light Jet Recon Eta";
      h_ljet_recon_etaIndex[i] = new TH1F(hName.str().c_str(), title.c_str(), 20, 0.0, 20.0);
      m_thistSvc->regHist(fName.str().c_str(), h_ljet_recon_etaIndex[i]);  

      fName.str("");
      hName.str("");
      hName << "ja_ljet_" << stub[i] << "_recon_eIndex";
      fName << "/AANT/JetAnalysis/" << stub[i] << "/" << hName.str();
      title = "Light Jet Recon E";
      h_ljet_recon_eIndex[i] = new TH1F(hName.str().c_str(), title.c_str(), 20, 0.0, 20.0);
      m_thistSvc->regHist(fName.str().c_str(), h_ljet_recon_eIndex[i]);  

      fName.str("");
      hName.str("");
      hName << "ja_ljet_" << stub[i] << "_recon_etIndex";
      fName << "/AANT/JetAnalysis/" << stub[i] << "/" << hName.str();
      title = "Light Jet Recon E_{T}";
      h_ljet_recon_etIndex[i] = new TH1F(hName.str().c_str(), title.c_str(), 20, 0.0, 20.0);
      m_thistSvc->regHist(fName.str().c_str(), h_ljet_recon_etIndex[i]);  
    }
  }
}

void BUSTopJetAnalysis::registerTruthInfoHistogram(TH1F*& h, std::string a, std::string n){
  std::stringstream fName, hName;
  std::string title;

  fName.str("");
  hName.str("");
  hName << n;
  fName << "/AANT/JetAnalysis/" << a << "/" << hName.str();
  title = "Jet Truth Info";
  h = new TH1F(hName.str().c_str(), title.c_str(), 40, -20.5, 19.5);
  m_thistSvc->regHist(fName.str().c_str(), h);
}

StatusCode BUSTopJetAnalysis::finalize() {
  MsgStream mLog( messageService(), name() );
  
  return StatusCode::SUCCESS;

}

//////////////////////////////////////////////////////////////////////////////////
/// Execute - called by the event loop on event by event

StatusCode BUSTopJetAnalysis::execute() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << "execute()" << endreq;
  getEventWeight();  

  mLog << MSG::INFO << "getParticleContainers()" << endreq;
  getParticleContainers();

  mLog << MSG::INFO << "createTemporaryContainers()" << endreq;
  createTemporaryContainers();

  mLog << MSG::INFO << "plotJets()" << endreq;
  plotJets();
  plotSelectedCentrality();

  mLog << MSG::INFO << "done" << endreq;

  if(m_plotWeights == true){
    weightCutAnalysis();
  }

  if(m_truthAvailable == true){
    truthAnalysis();

    overlapAnalysis();
    taggingAnalysis();
    selectionAnalysis();
  }
  
  mLog << MSG::DEBUG << "Clearning containers..." << endreq;

  fillTrees();
  clearParticleContainers();

  mLog << MSG::DEBUG << "Returning" << endreq;

  return StatusCode::SUCCESS;
}

void BUSTopJetAnalysis::fillTrees(){
}

void BUSTopJetAnalysis::truthAnalysis(){
  MsgStream mLog( messageService(), name() );

  plotTruthMatch(c_truthB1, jetTES, h_b1_truth_match_full, h_b1_truth_match_full_info);
  plotTruthMatch(c_truthB3, jetTES, h_b3_truth_match_full, h_b3_truth_match_full_info);

  b1ReconAnalysis();

  bjetAnalysis();
  lightJetAnalysis();
}

void BUSTopJetAnalysis::weightCutAnalysis(){
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "Doing weightCutAnalysis..." << endreq;

  JetCollection::const_iterator iter = c_overlapJets->begin();
  JetCollection::const_iterator iterEnd = c_overlapJets->end();

  while(iter < iterEnd){
    std::string label = getTruthLabel(*iter);
    if(label == "B"){
      h_pre_filter_bjets->plot((*iter), m_eventWeight);
    }else{
      h_pre_filter_ljets->plot((*iter), m_eventWeight);
    }
    iter++;
  }
}

void BUSTopJetAnalysis::b1ReconAnalysis(){
  MsgStream mLog( messageService(), name() );
 
  mLog << MSG::DEBUG << "b1ReconAnalysis()..." << endreq;

  if(c_bjets->size() == 1){
    b1ReconAnalysis(c_bjets, c_ljets, 0);
  }else if(c_bjets->size() == 2){
    b12ReconAnalysis(c_bjets, c_ljets, 0);
  }

  if(m_tagTool->tagged(IEventTagTool::PRESELECTION)){
    if(c_preselectedBJets->size() == 1){
      mLog << MSG::DEBUG << "PRESELECTION B1" << endreq;
      b1ReconAnalysis(c_preselectedBJets, c_preselectedLJets, 1);
    }else if(c_preselectedBJets->size() == 2){
      b12ReconAnalysis(c_preselectedBJets, c_preselectedLJets, 1);
    }
  }

  if(m_tagTool->tagged(IEventTagTool::CSCSELECTION)){
    if(c_cscSelectedBJets->size() == 1){
      b1ReconAnalysis(c_cscSelectedBJets, c_cscSelectedLJets, 2);
    }else if(c_cscSelectedBJets->size() == 2){
      b12ReconAnalysis(c_cscSelectedBJets, c_cscSelectedLJets, 2);
    }
  }

  if(m_tagTool->tagged(IEventTagTool::B1SELECTION)){	
    if(c_b1SelectedBJets->size() == 1){
      b1ReconAnalysis(c_b1SelectedBJets, c_preselectedLJets, 3);
    }
  }
}

/**
 * Used to determine if an event with a single b tag is best matched to b1, b3 or lj
 */
void BUSTopJetAnalysis::b1ReconAnalysis(const JetCollection* bj, const JetCollection* lj, int index){
  MsgStream mLog( messageService(), name() );
 
  mLog << MSG::DEBUG << "b1ReconAnalysis(...)..." << endreq;

  double deltaR1 = AnalysisUtils::Delta::R(c_truthB1->at(0), bj->at(0));

  double deltaE1 = fabs(c_truthB1->at(0)->e() - bj->at(0)->e());
  double deltaE3 = fabs(c_truthB3->at(0)->e() - bj->at(0)->e());

  unsigned int ljIndex = 0;    
  double deltaLJ = 1000;
  double deltaELJ = 100*GeV;
  
  if(lj->size() > 0){
    m_truthMatchTool->matchR(c_truthB1->at(0), lj, ljIndex);
    deltaLJ = AnalysisUtils::Delta::R(lj->at(ljIndex), c_truthB1->at(0));
    deltaELJ = fabs(c_truthB1->at(0)->e() - lj->at(ljIndex)->e());
  }

  bool result = false;

  if(deltaE1 < deltaE3 && deltaR1 < m_truthMatchDeltaR){
    //final check - what if a lj is closer?

    if(deltaLJ < m_truthMatchDeltaR && deltaLJ < deltaR1){
      //DeltaR is better, but what about energy?
      if(deltaELJ < deltaE1){
        //complete failure - lj is B1.
        h_1jet_recon[index]->Fill(0.0, m_eventWeight);
      }else{
        //Bjet better match than lj
        h_1jet_recon[index]->Fill(2.0, m_eventWeight);
        result = true;
      }
    }else{
      //Bjet better match than lj
      h_1jet_recon[index]->Fill(2.0, m_eventWeight);
      result = true;
    }
  }else{
    //complete failure
    h_1jet_recon[index]->Fill(0.0, m_eventWeight);
  }

  //only write out the pre-preselection variables!
  if(index == 0 && bj->size() > 0){
    mLog << MSG::DEBUG << "result = " << result << endreq;
    mLog << MSG::DEBUG << "done." << endreq;
  }
}

void BUSTopJetAnalysis::b12ReconAnalysis(const JetCollection* bj, const JetCollection* lj, int index){
  MsgStream mLog( messageService(), name() );
 
  mLog << MSG::DEBUG << "b1ReconAnalysis(...)..." << endreq;

  double R[2][2];
  double E[2][2];
  bool result = false;

    
  for(int i = 0; i < 2; i++){
    R[i][0] = AnalysisUtils::Delta::R(c_truthB1->at(0), bj->at(i));
    R[i][1] = AnalysisUtils::Delta::R(c_truthB3->at(0), bj->at(i));

    E[i][0] = fabs(c_truthB1->at(0)->e() - bj->at(i)->e());
    E[i][1] = fabs(c_truthB3->at(0)->e() - bj->at(i)->e());
  }
   
  //If all b1 deltaRs outside of accceptable limit
  //Then its a definite failure
  if(R[0][0] > m_truthMatchDeltaR && R[1][0] > m_truthMatchDeltaR){
    h_2jet_recon[index]->Fill(0.0, m_eventWeight);
    return;
  }

  //Find out which is closest match to B1
  int b1Index = 0;
  int b3Index = 1;
  if(R[0][0] > R[1][0]){
    b1Index = 1;
    b3Index = 0;
  }

  unsigned int ljIndex = 0;    
  double deltaLJ = 1000;
  double deltaELJ = 100*GeV;

  if(lj->size() > 0){
    m_truthMatchTool->matchR(c_truthB1->at(0), lj, ljIndex);
    deltaLJ = AnalysisUtils::Delta::R(lj->at(ljIndex), c_truthB1->at(0));
    deltaELJ = fabs(c_truthB1->at(0)->e() - lj->at(ljIndex)->e());
  }

  //Compare with b3 match index.  If it's still the closest, winner!
  if(R[b1Index][0] < R[b1Index][1] && R[b1Index][0] < m_truthMatchDeltaR){
    
    //check against LJ...
    if(deltaLJ < m_truthMatchDeltaR && deltaLJ < R[b1Index][0]){
      //DeltaR is better, but what about energy?
      if(deltaELJ < E[b1Index][0]){
        //complete failure - lj is B1.
        h_2jet_recon[index]->Fill(0.0, m_eventWeight);
      }else{
        //Bjet better match than lj
        h_2jet_recon[index]->Fill(2.0, m_eventWeight);
      }
    }else{ 
      h_2jet_recon[index]->Fill(2.0, m_eventWeight);
    }
  }else if(R[b3Index][0] < R[b3Index][1] && R[b3Index][0] < m_truthMatchDeltaR){
    //check against LJ...
    if(deltaLJ < m_truthMatchDeltaR && deltaLJ < R[b3Index][0]){
      //DeltaR is better, but what about energy?
      if(deltaELJ < E[b3Index][0]){
        //complete failure - lj is B1.
        h_2jet_recon[index]->Fill(0.0, m_eventWeight);
      }else{
        //Bjet better match than lj
        h_2jet_recon[index]->Fill(2.0, m_eventWeight);
      }
    }else{ 
      h_2jet_recon[index]->Fill(2.0, m_eventWeight);
    }
  }else{
    h_2jet_recon[index]->Fill(0.0, m_eventWeight);
  }

  //only write out the pre-preselection variables!
  if(index == 0){
    mLog << MSG::DEBUG << "result = " << result << endreq;
  }
}

void BUSTopJetAnalysis::getParticleContainers(){
  MsgStream mLog( messageService(), name() );  

  jetTES = 0;
  m_storeGate->retrieve(jetTES, m_jetInputContainerName);

  if(jetTES == 0){
    mLog << MSG::WARNING << "Problem getting jet container" << endreq;
  } 

  c_overlapJets = 0;
  m_storeGate->retrieve(c_overlapJets, m_overlapJetContainerName);
  if(c_overlapJets == 0){
    mLog << MSG::WARNING << "Problem getting overlapped jet container" << endreq;
  } 

  c_overlapEJets = 0;
  m_storeGate->retrieve(c_overlapEJets, m_overlapEJetContainerName);
  if(c_overlapEJets == 0){
    mLog << MSG::WARNING << "Problem getting overlapped ejet container" << endreq;
  } 

  c_electrons = 0;
  m_storeGate->retrieve(c_electrons, m_electronContainerName);
  if(c_electrons == 0){
    mLog << MSG::WARNING << "Problem getting Electron container" << endreq;
  } 

  c_muons = 0;
  m_storeGate->retrieve(c_muons, m_muonContainerName);
  if(c_muons == 0){
    mLog << MSG::WARNING << "Problem getting Muon container" << endreq;
  } 

  c_bjets = 0;
  m_storeGate->retrieve(c_bjets, m_bJetContainerName);
  if(c_bjets == 0){
    mLog << MSG::WARNING << "Problem getting BJet container" << endreq;
  } 

  c_ljets = 0;
  m_storeGate->retrieve(c_ljets, m_lightJetContainerName);
  if(c_ljets == 0){
    mLog << MSG::WARNING << "Problem getting Light Jet container" << endreq;
  } 

  c_preselectedBJets = 0;
  m_storeGate->retrieve(c_preselectedBJets, m_preselectedBJetContainerName);
  if(c_preselectedBJets == 0){
    mLog << MSG::WARNING << "Problem getting Preselected BJet container" << endreq;
  } 

  c_preselectedLJets = 0;
  m_storeGate->retrieve(c_preselectedLJets, m_preselectedLightJetContainerName);
  if(c_preselectedLJets == 0){
    mLog << MSG::WARNING << "Problem getting Preselected Light Jet container" << endreq;
  } 

  c_preselectedElectrons = 0;
  m_storeGate->retrieve(c_preselectedElectrons, m_preselectedElectronContainerName);
  if(c_preselectedElectrons == 0){
    mLog << MSG::WARNING << "Problem getting Preselected Electron container" << endreq;
  } 

  c_preselectedMuons = 0;
  m_storeGate->retrieve(c_preselectedMuons, m_preselectedMuonContainerName);
  if(c_preselectedMuons == 0){
    mLog << MSG::WARNING << "Problem getting Preselected Muon container" << endreq;
  } 

  c_cscSelectedElectrons = 0;
  m_storeGate->retrieve(c_cscSelectedElectrons, m_cscSelectedElectronContainerName);
  if(c_cscSelectedElectrons == 0){
    mLog << MSG::WARNING << "Problem getting Preselected Electron container" << endreq;
  } 

  c_cscSelectedMuons = 0;
  m_storeGate->retrieve(c_cscSelectedMuons, m_cscSelectedMuonContainerName);
  if(c_cscSelectedMuons == 0){
    mLog << MSG::WARNING << "Problem getting CSCSelected Muon container" << endreq;
  } 

  c_cscSelectedBJets = 0;
  m_storeGate->retrieve(c_cscSelectedBJets, m_cscSelectedBJetContainerName);
  if(c_cscSelectedBJets == 0){
    mLog << MSG::WARNING << "Problem getting CSCSelected BJet container" << endreq;
  } 

  c_cscSelectedLJets = 0;
  m_storeGate->retrieve(c_cscSelectedLJets, m_cscSelectedLightJetContainerName);
  if(c_cscSelectedLJets == 0){
    mLog << MSG::WARNING << "Problem getting CSCSelected Light Jet container" << endreq;
  } 

  if(m_tagTool->tagged(IEventTagTool::B1SELECTION)){
    c_b1SelectedBJets = 0;
    m_storeGate->retrieve(c_b1SelectedBJets, m_b1SelectedBJetContainerName);
    if(c_b1SelectedBJets == 0){
      mLog << MSG::WARNING << "Problem getting B1Selected BJet container" << endreq;
    }
  }

  if(m_tagTool->tagged(IEventTagTool::LJSELECTION)){
    c_ljSelectedLJets = 0;
    m_storeGate->retrieve(c_ljSelectedLJets, m_ljSelectedLJetContainerName);
    if(c_ljSelectedLJets == 0){
      mLog << MSG::WARNING << "Problem getting LJSelected LJet container" << endreq;
    }else{
      JetCollection::const_iterator iter = c_ljSelectedLJets->begin();
      JetCollection::const_iterator iterEnd = c_ljSelectedLJets->end();
   
      while(iter < iterEnd){
        mLog << MSG::DEBUG << "LJet Weight = " << getFlavourTagWeight(*iter) << endreq;
        iter++;
      }
    }
  }

  c_truthB1 = 0;
  c_truthB3 = 0;
  c_truthLj = 0;

  if(m_truthAvailable == true){
    m_storeGate->retrieve(c_truthB1, "BUSTopTruth_b1");

    if(c_truthB1 == 0){
      mLog << MSG::WARNING << "Problem getting truth jet container" << endreq;
    }

    m_storeGate->retrieve(c_truthB3, "BUSTopTruth_b3");

    if(c_truthB3 == 0){
      mLog << MSG::WARNING << "Problem getting truth jet container" << endreq;
    }

    m_storeGate->retrieve(c_truthLj, "BUSTopTruth_lj");
    if(c_truthLj == 0){
      mLog << MSG::WARNING << "Problem getting truth jet container" << endreq;
    }

    m_storeGate->retrieve(c_truthElectron, "BUSTopTruth_e");
    if(c_truthElectron == 0){
      mLog << MSG::WARNING << "Problem getting truth electron container" << endreq;
    }

    m_storeGate->retrieve(c_truthMuon, "BUSTopTruth_mu");
    if(c_truthMuon == 0){
      mLog << MSG::WARNING << "Problem getting truth mu container" << endreq;
    }

    m_storeGate->retrieve(c_truthTau, "BUSTopTruth_tau");
    if(c_truthTau == 0){
      mLog << MSG::WARNING << "Problem getting truth tau container" << endreq;
    }

    m_storeGate->retrieve(c_truthW1, "BUSTopTruth_w1");
    if(c_truthW1 == 0){
      mLog << MSG::WARNING << "Problem getting truth w1 container" << endreq;
    }
  }
}

void BUSTopJetAnalysis::createTemporaryContainers(){
}

void BUSTopJetAnalysis::clearParticleContainers(){
  jetTES = 0;
  c_overlapJets = 0;
}

void BUSTopJetAnalysis::plotJets(){
  MsgStream mLog( messageService(), name() );  

  JetCollection::const_iterator jetIter;
  JetCollection::const_iterator jetIterEnd;

  mLog << MSG::DEBUG << "Input container" << endreq;
  h_full_jet->plotContainer(jetTES, m_eventWeight);

  mLog << MSG::DEBUG << "overlap container" << endreq;
  h_overlap_jet->plotContainer(c_overlapJets, m_eventWeight);

  //sum up energy of c_overlapJets...
  jetIter = c_overlapJets->begin();
  jetIterEnd = c_overlapJets->end();

  while(jetIter < jetIterEnd){
    m_overlapJetH += (*jetIter)->e();
    jetIter++;
  }

  mLog << MSG::DEBUG << "tagged containers" << endreq;
  h_tagged_b_jets->plotContainer(c_bjets, m_eventWeight);
  h_tagged_l_jets->plotContainer(c_ljets, m_eventWeight);

  mLog << MSG::DEBUG << "testing..." << endreq;
  
  if(m_tagTool->tagged(IEventTagTool::PRESELECTION)){
    mLog << MSG::DEBUG << "Preselection containers" << endreq;
    h_preselected_b_jets->plotContainer(c_preselectedBJets, m_eventWeight);
    h_preselected_l_jets->plotContainer(c_preselectedLJets, m_eventWeight);
  }

  if(m_tagTool->tagged(IEventTagTool::CSCSELECTION)){
    mLog << MSG::DEBUG << "CSCSelection containers" << endreq;
    h_cscSelected_b_jets->plotContainer(c_cscSelectedBJets, m_eventWeight);
    h_cscSelected_l_jets->plotContainer(c_cscSelectedLJets, m_eventWeight);
  }

  if(m_tagTool->tagged(IEventTagTool::B1SELECTION)){
    mLog << MSG::DEBUG << "B1Selection containers" << endreq;
    h_selected_b_jets->plotContainer(c_b1SelectedBJets, m_eventWeight);

    jetIter = c_b1SelectedBJets->begin();
    jetIterEnd = c_b1SelectedBJets->end();
    double n = 0;
    while(jetIter < jetIterEnd){
      if((*jetIter)->pt() > 30*GeV){
        h_selected_b_30pt_jets->plot(*jetIter, m_eventWeight);
	n += 1.0;
      }
      jetIter++;
    }

    h_selected_b_30pt_jets->n[0]->Fill(n, m_eventWeight);
  }

  if(m_tagTool->tagged(IEventTagTool::LJSELECTION)){
    h_selected_l_jets->plotContainer(c_ljSelectedLJets, m_eventWeight);
  }
}

void BUSTopJetAnalysis::plotTruthInfo(const JetCollection* j, TH1F* h){
  JetCollection::const_iterator iter = j->begin();
  JetCollection::const_iterator iterEnd = j->end();

  while(iter < iterEnd){
    plotTruthInfo(*iter, h);
    iter++;
  }
}

void BUSTopJetAnalysis::plotTruthInfo(const Jet* j, TH1F* h){
  std::string label;
  const Analysis::TruthInfo* mcInfo = 0;
  mcInfo = j->tagInfo<Analysis::TruthInfo>("TruthInfo");
  if(mcInfo != 0){
    label = mcInfo->jetTruthLabel();
    if(label == "N/A"){
      h->Fill(0.0, m_eventWeight);
    }else if(label == "B"){
      h->Fill(PDG::b, m_eventWeight);
    }else if(label == "C"){
      h->Fill(PDG::c, m_eventWeight);
    }else if(label == "T"){
      h->Fill(PDG::tau_minus, m_eventWeight);
    }
  }
}

std::string BUSTopJetAnalysis::getTruthLabel(const Jet* j){
  std::string label = "";
  const Analysis::TruthInfo* mcInfo = 0;
  mcInfo = j->tagInfo<Analysis::TruthInfo>("TruthInfo");
  if(mcInfo != 0){
    label = mcInfo->jetTruthLabel();
  }

  return label;
}

void BUSTopJetAnalysis::overlapAnalysis(){
  MsgStream mLog( messageService(), name() );  

  mLog << MSG::DEBUG << "overlapAnalysis()" << endreq;

  //plot full container so that rejection might be measured.
  JetCollection::const_iterator ojIter = c_overlapJets->begin();
  JetCollection::const_iterator ojIterEnd = c_overlapJets->end();

  while(ojIter < ojIterEnd){
    plotTruthInfo(*ojIter, h_overlap_info);
    ojIter++;
  }

  if(m_tagTool->tagged(IEventTagTool::TRIGGERED)){
    h_trig_overlap_jet_n->Fill(c_overlapEJets->size(), m_eventWeight);

    overlapAnalysis(c_truthB1, h_trig_overlap_b1_match);
    overlapAnalysis(c_truthLj, h_trig_overlap_lj_match);
  }

  overlapAnalysis(c_truthB1, h_overlap_b1_bjet_truth_info,  h_overlap_b1_bjet_truth_weight, h_overlap_b1_ejet_truth_info, h_matched_b1_tag_eff_weight, h_overlap_b1_ejet_truth_res);
  overlapAnalysis(c_truthB3, h_overlap_b3_bjet_truth_info,  h_overlap_b3_bjet_truth_weight, h_overlap_b3_ejet_truth_info, h_matched_b3_tag_eff_weight, h_overlap_b3_ejet_truth_res);
}

void BUSTopJetAnalysis::overlapAnalysis(const TruthParticleContainer* t, TH1F* h){
  MsgStream mLog( messageService(), name() );  

  mLog << MSG::DEBUG << "overlapAnalysis(...)" << endreq;

  TruthParticleContainer::const_iterator mcIter = t->begin();
  TruthParticleContainer::const_iterator mcIterEnd = t->end();

  unsigned int acceptedIndex;
  unsigned int rejectedIndex;

  while(mcIter < mcIterEnd){
    m_truthMatchTool->matchR(*mcIter, c_overlapEJets, rejectedIndex);
    m_truthMatchTool->matchR(*mcIter, c_overlapJets, acceptedIndex);

    double acceptedDeltaR = 1000.0;
    double rejectedDeltaR = 1000.0;

    if(c_overlapJets->size() > 0){
      acceptedDeltaR = AnalysisUtils::Delta::R(*mcIter, c_overlapJets->at(acceptedIndex));
    }

    if(c_overlapEJets->size() > 0){
      rejectedDeltaR = AnalysisUtils::Delta::R(*mcIter, c_overlapEJets->at(rejectedIndex));
    }

    if(rejectedDeltaR < acceptedDeltaR && rejectedDeltaR < m_truthMatchDeltaR){
      h->Fill(0.0, m_eventWeight);  
    }else{
      h->Fill(1.0, m_eventWeight);  
    }
    
    mcIter++;
  }
}

void BUSTopJetAnalysis::overlapAnalysis(const TruthParticleContainer* t, TH1F* acc, TH1F* accWeight, TH1F* rej, TH1F* effWeight, ResolutionHistograms* rh){
  MsgStream mLog( messageService(), name() );  

  mLog << MSG::DEBUG << "overlapAnalysis(...)" << endreq;

  TruthParticleContainer::const_iterator mcIter = t->begin();
  TruthParticleContainer::const_iterator mcIterEnd = t->end();

  unsigned int acceptedIndex;
  unsigned int rejectedIndex;

  IParticleFilter effFilter;
  effFilter.setEtaMin(-2.5);
  effFilter.setEtaMax(2.5);
  effFilter.setPtMin(15*GeV);

  while(mcIter < mcIterEnd){
    m_truthMatchTool->matchR(*mcIter, c_overlapEJets, rejectedIndex);
    m_truthMatchTool->matchR(*mcIter, c_overlapJets, acceptedIndex);

    double acceptedDeltaR = 1000.0;
    double rejectedDeltaR = 1000.0;

    if(c_overlapJets->size() > 0){
      acceptedDeltaR = AnalysisUtils::Delta::R(*mcIter, c_overlapJets->at(acceptedIndex));
    }

    if(c_overlapEJets->size() > 0){
      rejectedDeltaR = AnalysisUtils::Delta::R(*mcIter, c_overlapEJets->at(rejectedIndex));
    }

    if(rejectedDeltaR < acceptedDeltaR && rejectedDeltaR < m_truthMatchDeltaR){
      plotTruthInfo(c_overlapEJets->at(rejectedIndex), rej);
      rh->plot(*mcIter, c_overlapEJets->at(rejectedIndex), m_eventWeight);
    }else if(acceptedDeltaR < rejectedDeltaR && acceptedDeltaR < m_truthMatchDeltaR){
      //If jet is identified as truth bjet, plot weight.
      if(getTruthLabel(c_overlapJets->at(acceptedIndex)) == "B"){
        plotTruthInfo(c_overlapJets->at(acceptedIndex), acc);
        double tagWeight = getFlavourTagWeight(c_overlapJets->at(acceptedIndex));
        accWeight->Fill(tagWeight, m_eventWeight);

        if(effFilter.isAccepted(c_overlapJets->at(acceptedIndex))){
          effWeight->Fill(tagWeight, m_eventWeight);
        }
      }
    }
    
    mcIter++;
  }
}

void BUSTopJetAnalysis::taggingAnalysis(){
  MsgStream mLog( messageService(), name() );  

  mLog << MSG::DEBUG << "taggingAnalysis()" << endreq;

  if(c_preselectedBJets->size() + c_preselectedLJets->size() >= 2){
    mLog << MSG::DEBUG << "taggingAnalysis(): plotting Truth Info" << endreq;

    //tells you how many tagged as b's are actually b's
    //tells you how many non-tagged are actually b's
    plotTruthInfo(c_preselectedBJets, h_preselected_b_truth_info); 
    plotTruthInfo(c_preselectedLJets, h_preselected_lj_truth_info);
  }

  mLog << MSG::DEBUG << "taggingAnalysis(): plotting Truth Info II" << endreq;

  plotTruthInfo(c_bjets, h_tagged_bj_info);
  plotTruthInfo(c_ljets, h_tagged_lj_info);
  
  mLog << MSG::DEBUG << "taggingAnalysis(): taggingAnalysis..." << endreq;

  taggingAnalysis(c_truthB1, c_bjets, c_ljets, h_tagged_b1_truth_info, h_ntagged_b1_truth_info);
  taggingAnalysis(c_truthB3, c_bjets, c_ljets, h_tagged_b3_truth_info, h_ntagged_b3_truth_info);

  mLog << MSG::DEBUG << "taggingAnalysis(): Done" << endreq;

}

void BUSTopJetAnalysis::taggingAnalysis(const TruthParticleContainer* t, const JetCollection* c_acc, const JetCollection* c_rej,  TH1F* h_acc, TH1F* h_rej){
  MsgStream mLog( messageService(), name() );  

  mLog << MSG::DEBUG << "taggingAnalysis(...)" << endreq;

  TruthParticleContainer::const_iterator mcIter = t->begin();
  TruthParticleContainer::const_iterator mcIterEnd = t->end();

  unsigned int acceptedIndex;
  unsigned int rejectedIndex;

  while(mcIter < mcIterEnd){
    m_truthMatchTool->matchR(*mcIter, c_rej, rejectedIndex);
    m_truthMatchTool->matchR(*mcIter, c_acc, acceptedIndex);

    double acceptedDeltaR = 1000.0;
    double rejectedDeltaR = 1000.0;

    if(c_acc->size() > 0){
      acceptedDeltaR = AnalysisUtils::Delta::R(*mcIter, c_acc->at(acceptedIndex));
    }

    if(c_rej->size() > 0){
      rejectedDeltaR = AnalysisUtils::Delta::R(*mcIter, c_rej->at(rejectedIndex));
    }

    if(rejectedDeltaR < acceptedDeltaR && rejectedDeltaR < m_truthMatchDeltaR){
      plotTruthInfo(c_rej->at(rejectedIndex), h_rej);
    }else if(rejectedDeltaR > acceptedDeltaR && acceptedDeltaR < m_truthMatchDeltaR){
      plotTruthInfo(c_acc->at(acceptedIndex), h_acc);
    }

    mcIter++;
  }
}

void BUSTopJetAnalysis::plotTruthMatch(const TruthParticleContainer* t, const JetCollection* j, JetHistograms* h, TH1F* h_tag){
  MsgStream mLog( messageService(), name() );
  
  mLog << MSG::DEBUG << "plotTruthMatch()" << endreq;
  
  TruthParticleContainer::const_iterator mcIter = t->begin();
  TruthParticleContainer::const_iterator mcIterEnd = t->end();
  
  unsigned int matchIndex;
  
  while(mcIter < mcIterEnd){
    m_truthMatchTool->matchR(*mcIter, j, matchIndex);
   
    double acceptedDeltaR = 1000.0;

    if(j->size() > 0){
      acceptedDeltaR = AnalysisUtils::Delta::R(*mcIter, j->at(matchIndex));
    }

    if(acceptedDeltaR < m_truthMatchDeltaR){
      mLog << MSG::DEBUG << "...plot()" << endreq;
      h->plot(j->at(matchIndex), m_eventWeight);

      mLog << MSG::DEBUG << "...plotTruthInfo()" << endreq;
      plotTruthInfo(j->at(matchIndex), h_tag);      

      mLog << MSG::DEBUG << "done" << endreq;

    }
    
    mcIter++;
  }  
}

void BUSTopJetAnalysis::bjetAnalysis(){
  bjetAnalysis(c_bjets, 0);

  if(m_tagTool->tagged(IEventTagTool::PRESELECTION)){  
    bjetAnalysis(c_preselectedBJets, 1);
  }

  if(m_tagTool->tagged(IEventTagTool::CSCSELECTION)){
    bjetAnalysis(c_cscSelectedBJets, 2);
  }
}

void BUSTopJetAnalysis::bjetAnalysis(const JetCollection* jc, int histIndex){
  //truth match light jet
  //is jet the highest pt?  eta?, combination of the two?

  unsigned int matchIndex;
  TruthParticleContainer::const_iterator mcIter = c_truthB1->begin();
  TruthParticleContainer::const_iterator mcIterEnd = c_truthB1->end();

  while(mcIter < mcIterEnd){
    h_bjet_recon[histIndex]->Fill(0.0, m_eventWeight);
    m_truthMatchTool->matchR(*mcIter, jc, matchIndex);
   
    double acceptedDeltaR = 1000.0;

    if(jc->size() > 0){
      acceptedDeltaR = AnalysisUtils::Delta::R(*mcIter, jc->at(matchIndex));
      if(acceptedDeltaR < m_truthMatchDeltaR){
        h_bjet_recon[histIndex]->Fill(1.0, m_eventWeight);
        h_bjet_recon_ptIndex[histIndex]->Fill(matchIndex, m_eventWeight);

	int etaIndex = 0;
	int eIndex = 0;
	int etIndex = 0;
        int weightIndex = 0;
        int loopIndex = 0;
        
        JetCollection::const_iterator jcIter = jc->begin();
        JetCollection::const_iterator jcIterEnd = jc->end();
	while(jcIter < jcIterEnd){
          if(fabs(jc->at(matchIndex)->eta()) < fabs((*jcIter)->eta())){
            etaIndex++;
          }

          if(fabs(jc->at(matchIndex)->e()) < fabs((*jcIter)->e())){
            eIndex++;
          }

          if(fabs(jc->at(matchIndex)->et()) < fabs((*jcIter)->et())){
            etIndex++;
          }

          if(getFlavourTagWeight(jc->at(matchIndex)) < getFlavourTagWeight(*jcIter)){
            weightIndex++;
          }

          loopIndex++;
          jcIter++;
        }

	h_bjet_recon_etaIndex[histIndex]->Fill(etaIndex, m_eventWeight);
	h_bjet_recon_eIndex[histIndex]->Fill(eIndex, m_eventWeight);
	h_bjet_recon_etIndex[histIndex]->Fill(etIndex, m_eventWeight);
	h_bjet_recon_weightIndex[histIndex]->Fill(weightIndex, m_eventWeight);

        //only plot distribution after preselection
        if(histIndex == 0){
          h_bj_truth_match_res_2->Fill(((*mcIter)->e() - jc->at(matchIndex)->e())/GeV, fabs(jc->at(matchIndex)->eta()), m_eventWeight);
        }else if(histIndex == 1){
  	  h_bj_truth_match->plot(jc->at(matchIndex), m_eventWeight);
          h_bj_truth_match_res->plot(*mcIter, jc->at(matchIndex), m_eventWeight);
        }
      }
    }

    mcIter++;
  }
}

void BUSTopJetAnalysis::lightJetAnalysis(){
  lightJetAnalysis(c_ljets, 0);

  if(m_tagTool->tagged(IEventTagTool::PRESELECTION)){
    lightJetAnalysis(c_preselectedLJets, 1);
  }

  if(m_tagTool->tagged(IEventTagTool::CSCSELECTION)){  
    lightJetAnalysis(c_cscSelectedLJets, 2);
  }

  if(m_tagTool->tagged(IEventTagTool::LJSELECTION)){
    lightJetAnalysis(c_ljSelectedLJets, 3);
  }
}

void BUSTopJetAnalysis::lightJetAnalysis(const JetCollection* jc, int histIndex){
  //truth match light jet
  //is jet the highest pt?  eta?, combination of the two?

  unsigned int matchIndex;
  TruthParticleContainer::const_iterator mcIter = c_truthLj->begin();
  TruthParticleContainer::const_iterator mcIterEnd = c_truthLj->end();

  while(mcIter < mcIterEnd){
    h_ljet_recon[histIndex]->Fill(0.0, m_eventWeight);
    m_truthMatchTool->matchR(*mcIter, jc, matchIndex);
   
    double acceptedDeltaR = 1000.0;

    if(jc->size() > 0){
      acceptedDeltaR = AnalysisUtils::Delta::R(*mcIter, jc->at(matchIndex));
      if(acceptedDeltaR < m_truthMatchDeltaR){
        h_ljet_recon[histIndex]->Fill(1.0, m_eventWeight);
        h_ljet_recon_ptIndex[histIndex]->Fill(matchIndex, m_eventWeight);

	int etaIndex = 0;
	int eIndex = 0;
	int etIndex = 0;
        int loopIndex = 0;

        
        JetCollection::const_iterator jcIter = jc->begin();
        JetCollection::const_iterator jcIterEnd = jc->end();
	while(jcIter < jcIterEnd){
          if(fabs(jc->at(matchIndex)->eta()) < fabs((*jcIter)->eta())){
            etaIndex++;
          }

          if(fabs(jc->at(matchIndex)->e()) < fabs((*jcIter)->e())){
            eIndex++;
          }

          if(fabs(jc->at(matchIndex)->et()) < fabs((*jcIter)->et())){
            etIndex++;
          }

          loopIndex++;
          jcIter++;
        }

	h_ljet_recon_etaIndex[histIndex]->Fill(etaIndex, m_eventWeight);
	h_ljet_recon_eIndex[histIndex]->Fill(eIndex, m_eventWeight);
	h_ljet_recon_etIndex[histIndex]->Fill(etIndex, m_eventWeight);

        //only plot distribution after preselection
        if(histIndex == 0){
          h_lj_truth_match_res_2->Fill(((*mcIter)->e() - jc->at(matchIndex)->e())/GeV, fabs(jc->at(matchIndex)->eta()), m_eventWeight);
        }else if(histIndex == 1){
  	  h_lj_truth_match->plot(jc->at(matchIndex), m_eventWeight);
          h_lj_truth_match_res->plot(*mcIter, jc->at(matchIndex), m_eventWeight);
        }
      }
    }

    mcIter++;
  }
}

void BUSTopJetAnalysis::getEventWeight(){
  if(m_tagTool->tagged(IEventTagTool::IS_ATLFAST) == false && m_tagTool->tagged(IEventTagTool::IS_MC) == true){
    m_eventWeight = m_eventTool->getEventWeight();
  }else{
    m_eventWeight = 1.0;
  }
}

double BUSTopJetAnalysis::getFlavourTagWeight(const Jet* j){
  if(m_jetWeightTagger == "Default"){
    return j->getFlavourTagWeight();
  }else{
    return j->getFlavourTagWeight(m_jetWeightTagger);
  }
}

void BUSTopJetAnalysis::plotSelectedCentrality(){
  MsgStream mLog( messageService(), name() );

  if(m_tagTool->tagged(IEventTagTool::B1SELECTION) && m_tagTool->tagged(IEventTagTool::LJSELECTION)){
    mLog << MSG::DEBUG << "Attempting to plot centrality" << endreq;
    mLog << MSG::DEBUG << c_b1SelectedBJets << " " << c_ljSelectedLJets << endreq;
    if(c_b1SelectedBJets->size() > 0 && c_ljSelectedLJets->size() > 0){
      mLog << MSG::DEBUG << "calculating" <<  endreq;
      double num = c_b1SelectedBJets->at(0)->pt() + c_ljSelectedLJets->at(0)->pt();
      double denom = c_b1SelectedBJets->at(0)->p() + c_ljSelectedLJets->at(0)->p();
      mLog << MSG::DEBUG << "plotting " << num/denom << endreq;
      h_selected_centrality->Fill(num/denom, m_eventWeight);
    }
  }
  mLog << MSG::DEBUG << "done centrality" <<  endreq;

}

void BUSTopJetAnalysis::selectionAnalysis(){
  selectionAnalysis(c_truthB1, c_b1SelectedBJets, IEventTagTool::B1SELECTION, h_matched_selected_bjet_index);
  selectionAnalysis(c_truthLj, c_ljSelectedLJets, IEventTagTool::LJSELECTION, h_matched_selected_ljet_index);
}

void BUSTopJetAnalysis::selectionAnalysis(const TruthParticleContainer* truthTES, const JetCollection* jetTES, int tag, TH1F* h){

  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "selectionAnalysis" << endreq;

  if(jetTES->size() > 0){
    h->Fill(0.0, m_eventWeight);
  }

  if(m_tagTool->tagged(tag) == true && jetTES->size() > 0){

    TruthParticleContainer::const_iterator mcIter = truthTES->begin();
    TruthParticleContainer::const_iterator mcIterEnd = truthTES->end();

    while(mcIter < mcIterEnd){
      double acceptedDeltaR = 1000.0;

      acceptedDeltaR = AnalysisUtils::Delta::R(*mcIter, jetTES->at(0));

      if(acceptedDeltaR < m_truthMatchDeltaR){
        h->Fill(1.0, m_eventWeight);
      }

      mcIter++;
    }
  }
}
