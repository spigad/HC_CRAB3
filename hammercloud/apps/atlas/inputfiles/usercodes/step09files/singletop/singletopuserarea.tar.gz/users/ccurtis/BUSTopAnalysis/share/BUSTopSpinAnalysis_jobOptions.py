if DoSelection:
	from BUSTopAnalysis.BUSTopAnalysisConf import BUSTopSpinAnalysis

	Sequencer += BUSTopSpinAnalysis()
	BUSTopSpinAnalysis.OutputLevel = WARNING

	BUSTopSpinAnalysis.TruthAvailable          = DoTruth

	BUSTopSpinAnalysis.InputBJetContainer      = BUSTopSelection.OutputB1JetContainer
	BUSTopSpinAnalysis.InputLightJetContainer  = BUSTopSelection.OutputLJetContainer
	BUSTopSpinAnalysis.InputMuonContainer      = BUSTopSelection.OutputMuonContainer
	BUSTopSpinAnalysis.InputElectronContainer  = BUSTopSelection.OutputElectronContainer
	BUSTopSpinAnalysis.InputNeutrinoContainer  = BUSTopNuRecon_Selection.OutputNeutrinoContainer
	BUSTopSpinAnalysis.InputTopContainer       = BUSTopTRecon_Selection.OutputTops

	BUSTopSpinAnalysis.InputMETContainer       = BUSTopJES.METOutputContainer
	BUSTopSpinAnalysis.FilterTags              = BUSTopSelection.FilterTags

