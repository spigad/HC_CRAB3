#include "GaudiKernel/DeclareFactoryEntries.h"

#include "BUSTopReconstruction/BUSTopNeutrinoReconstruction.h"
#include "BUSTopReconstruction/BUSTopWReconstruction.h"
#include "BUSTopReconstruction/BUSTopTReconstruction.h"

DECLARE_ALGORITHM_FACTORY( BUSTopNeutrinoReconstruction )
DECLARE_ALGORITHM_FACTORY( BUSTopWReconstruction )
DECLARE_ALGORITHM_FACTORY( BUSTopTReconstruction )

DECLARE_FACTORY_ENTRIES( BUSTopReconstruction ) {
  DECLARE_ALGORITHM( BUSTopNeutrinoReconstruction )
  DECLARE_ALGORITHM( BUSTopWReconstruction )
  DECLARE_ALGORITHM( BUSTopTReconstruction )
}



