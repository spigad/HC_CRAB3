#include "BUSTopTools/BUSTopHistogrammer.h"
#include "BUSTopTools/ResolutionHistograms.h"

#include "ParticleEvent/ParticleBase.h"
#include "StoreGate/StoreGateSvc.h"
#include "StoreGate/DataHandle.h"

#include "McParticleEvent/TruthParticleContainer.h"
#include "EventKernel/PdtPdg.h"
#include "AnalysisUtils/IParticleFilter.h"
#include "AnalysisUtils/AnalysisMisc.h"

#include <iostream>
#include <string>
#include <queue>

#include "TH1.h"
#include "TH2.h"

ResolutionHistograms::ResolutionHistograms(IBUSTopHistogrammer* parent, std::string algName, std::string dirName, std::string hN, double deltaRCut){
  deltaR = new TH1F*[3];
  phi = new TH1F*[3];
  eta = new TH1F*[3];
  p = new TH1F*[3];
  px = new TH1F*[3];
  py = new TH1F*[3];
  pz = new TH1F*[3];
  pt = new TH1F*[3];
  e = new TH1F*[3];
  et = new TH1F*[3];
  costheta = new TH1F*[3];

  deltaRP = new TH2F*[3];

  std::stringstream fname, hname, title;

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "_delta_r";
  fname << "/AANT/" << algName << "/" << dirName << "/" << hname.str();
  title << "\\Delta R";
  parent->registerHistogram(deltaR, fname.str(), hname.str(), title.str(), "\\Delta R", int(deltaRCut/0.05), 0, deltaRCut);

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "_delta_rp";
  fname << "/AANT/" << algName << "/" << dirName << "/" << hname.str();
  title << "\\Delta R vs P";
  parent->registerHistogram(deltaRP, fname.str(), hname.str(), title.str(), "P", 100, 0, 500, "\\Delta R", int(deltaRCut/0.05), 0, deltaRCut);

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "_phi";
  fname << "/AANT/" << algName << "/" << dirName << "/" << hname.str();
  title << "Resolution \\phi";
  parent->registerHistogram(phi, fname.str(), hname.str(), title.str(), "\\Delta\\phi", 100, -2.0*M_PI, 2.0*M_PI);

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "_eta";
  fname << "/AANT/" << algName << "/" << dirName << "/" << hname.str();
  title << "Resolution \\eta";
  parent->registerHistogram(eta, fname.str(), hname.str(), title.str(), "\\Delta\\eta", 100, -10, 10);

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "_p";
  fname << "/AANT/" << algName << "/" << dirName << "/" << hname.str();
  title << "Resolution P";
  parent->registerHistogram(p, fname.str(), hname.str(), title.str(), "\\Delta P [GeV]", 100, -50, 50);

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "_px";
  fname << "/AANT/" << algName << "/" << dirName << "/" << hname.str();
  title << "Resolution P_{x}";
  parent->registerHistogram(px, fname.str(), hname.str(), title.str(), "\\Delta P_{x} [GeV]", 100, -50, 50);

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "_py";
  fname << "/AANT/" << algName << "/" << dirName << "/" << hname.str();
  title << "Resolution P_{y}";
  parent->registerHistogram(py, fname.str(), hname.str(), title.str(), "\\Delta P_{y} [GeV]", 100, -50, 50);

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "_pz";
  fname << "/AANT/" << algName << "/" << dirName << "/" << hname.str();
  title << "Resolution P_{z}";
  parent->registerHistogram(pz, fname.str(), hname.str(), title.str(), "\\Delta P_{z} [GeV]", 100, -50, 50);

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "_pt";
  fname << "/AANT/" << algName << "/" << dirName << "/" << hname.str();
  title << "Resolution P_{T}";
  parent->registerHistogram(pt, fname.str(), hname.str(), title.str(), "\\Delta P_{T} [GeV]", 100, -50, 50);

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "_e";
  fname << "/AANT/" << algName << "/" << dirName << "/" << hname.str();
  title << "Resolution E";
  parent->registerHistogram(e, fname.str(), hname.str(), title.str(), "\\Delta E [GeV]", 100, -500, 500);

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "_et";
  fname << "/AANT/" << algName << "/" << dirName << "/" << hname.str();
  title << "Resolution E_{T}";
  parent->registerHistogram(et, fname.str(), hname.str(), title.str(), "\\Delta E_{T} [GeV]", 100, -50, 50);

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "_costheta";
  fname << "/AANT/" << algName << "/" << dirName << "/" << hname.str();
  title << "Resolution Cos \\theta";
  parent->registerHistogram(costheta, fname.str(), hname.str(), title.str(), "\\Delta Cos\\theta", 100, -2, 2);
}
