#include "GaudiKernel/IToolSvc.h"
#include "GaudiKernel/ITHistSvc.h"

#include "TH1.h"
#include "TH2.h"

#include "egammaEvent/ElectronContainer.h"
#include "muonEvent/MuonContainer.h"
#include "muonEvent/Muon.h"
#include "MissingETEvent/MissingET.h"
#include "CompositeParticleEvent/CompositeParticleContainer.h"
#include "CompositeParticleEvent/CompositeParticle.h"
#include "ParticleEvent/NeutrinoContainer.h"
#include "ParticleEvent/Neutrino.h"
#include "JetEvent/JetCollection.h"

#include "SpecialUtils/NeutrinoUtils.h"

#include "DataModel/ElementLink.h"
#include "JetTagInfo/TruthInfo.h"

#include "AnalysisTools/IAnalysisTools.h"

#include "BUSTopTools/IBUSTopHistogrammer.h"
#include "BUSTopTools/INuSolutionTool.h"
#include "BUSTopTools/KinematicHistograms.h"
#include "BUSTopTools/ResolutionHistograms.h"
#include "BUSTopTools/METResolutionHistograms.h"
#include "BUSTopTools/EventTool.h"
#include "BUSTopTools/EventTagTool.h"

#include "BUSTopAnalysis/BUSTopWAnalysis.h"

#include <stdint.h>
#include <algorithm>
#include <math.h>
#include <functional>

BUSTopWAnalysis::BUSTopWAnalysis(const std::string& name, ISvcLocator* pSvcLocator) : 
                                             Algorithm(name, pSvcLocator){

  declareProperty("WName", m_fullWName);
  declareProperty("PreselectedWName", m_preselectedWName);
  declareProperty("CSCSelectedWName", m_cscSelectedWName);

  declareProperty("SelectedWName", m_selectedWName);
  declareProperty("SelectedBJetName", m_selectedBJetName);

  declareProperty("TruthAvailable", m_truthAvailable);
}

BUSTopWAnalysis::~BUSTopWAnalysis(){
}

StatusCode BUSTopWAnalysis::initialize() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << "Initializing BUSTopWAnalysis" << endreq;

  if (service("StoreGateSvc", m_storeGate).isFailure()) {
     mLog << MSG::ERROR << "Unable to retrieve pointer to StoreGateSvc" << endreq;
     return StatusCode::FAILURE;
  }

  service("THistSvc", m_thistSvc);

  IToolSvc * toolSvc;
  service("ToolSvc", toolSvc);

  IAlgTool *tmp_eventTool;
  toolSvc->retrieveTool("EventTool", tmp_eventTool);
  m_eventTool = dynamic_cast<IEventTool *>(tmp_eventTool);

  IAlgTool *tmp_tagTool;
  toolSvc->retrieveTool("EventTagTool", tmp_tagTool);
  m_tagTool = dynamic_cast<IEventTagTool *>(tmp_tagTool);

  IAlgTool *tmp_histogramTool;
  toolSvc->retrieveTool("BUSTopHistogrammer", tmp_histogramTool);
  m_histogrammer = dynamic_cast<IBUSTopHistogrammer *>(tmp_histogramTool);

  IAlgTool *tmp_nuSolTool;
  toolSvc->retrieveTool("NuSolutionTool", tmp_nuSolTool);
  m_nuSolTool = dynamic_cast<INuSolutionTool *>(tmp_nuSolTool);

  registerHistograms();

  return StatusCode::SUCCESS;
}

void BUSTopWAnalysis::registerHistograms(){
  std::stringstream fName, hName;
  std::string title;

  fName.str("");
  hName.str("");
  hName << "W_selected_centrality";
  fName << "/AANT/WAnalysis/" << "Kinematics" << "/" << hName.str();
  title = "Centrality";
  h_selected_centrality = new TH1F(hName.str().c_str(), title.c_str(), 100, 0, 1.0);
  m_thistSvc->regHist(fName.str().c_str(), h_selected_centrality);

  std::string names[4];
  names[0] = "Full";
  names[1] = "Preselection";
  names[2] = "CSCSelection";
  names[3] = "Selection";

  std::string knames[4];
  knames[0] = "W_full";
  knames[1] = "W_preselection";
  knames[2] = "W_cscSelection";
  knames[3] = "W_selection";

  for(int i = 0; i < 4; i++){
    hName.str("");
    hName << knames[i] << "Kinematics";
    h_wKinematics[i] = new KinematicHistograms(m_histogrammer, "WAnalysis", names[i], hName.str());
  }
}

StatusCode BUSTopWAnalysis::finalize() {
  MsgStream mLog( messageService(), name() );
  
  return StatusCode::SUCCESS;
}

StatusCode BUSTopWAnalysis::execute() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << "execute()" << endreq;

  getEventWeight();
  getStoregateContainers();

  mLog << MSG::DEBUG << "Got containers" << endreq;
  mLog << MSG::DEBUG << "fullW size = " << c_fullW->size() << endreq;

  mLog << MSG::DEBUG << "begin plotting" << endreq;

  plotW(c_fullW, 0);

  mLog << MSG::DEBUG << "begin plotting preselected" << endreq;

  plotW(c_preselectedW, 1);

  mLog << MSG::DEBUG << "begin plotting cscselected" << endreq;
  plotW(c_cscSelectedW, 2);

  mLog << MSG::DEBUG << "Done Plotting" << endreq;

  if(m_tagTool->tagged(IEventTagTool::NUSELECTION)){
    mLog << MSG::DEBUG << "Plotting Selection" << endreq;
    plotW(c_selectedW, 3);
    mLog << MSG::DEBUG << "Done Plotting" << endreq;

    if(m_tagTool->tagged(IEventTagTool::B1SELECTION)){
      plotSelectedCentrality();
    }
  }

  StatusCode sc = StatusCode::SUCCESS;

  return sc;

}

void BUSTopWAnalysis::plotW(const CompositeParticleContainer* wc, int index){
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "Plotting function" << endreq;

  h_wKinematics[index]->plotContainer(wc, m_eventWeight);   
}

void BUSTopWAnalysis::getStoregateContainers(){
  MsgStream mLog( messageService(), name() );

  m_storeGate->retrieve(c_fullW, m_fullWName);
  if(c_fullW == 0){
    mLog << MSG::ERROR << "Problem getting Full W Container" << endreq;
  }

  m_storeGate->retrieve(c_preselectedW, m_preselectedWName);
  if(c_preselectedW == 0){
    mLog << MSG::ERROR << "Problem getting Preselected W Container" << endreq;
  }

  m_storeGate->retrieve(c_cscSelectedW, m_cscSelectedWName);
  if(c_cscSelectedW == 0){
    mLog << MSG::ERROR << "Problem getting CSCSelected W Container" << endreq;
  }

  if(m_tagTool->tagged(IEventTagTool::NUSELECTION)){
    m_storeGate->retrieve(c_selectedW, m_selectedWName);
    if(c_selectedW == 0){
      mLog << MSG::ERROR << "Problem getting Selected W Container" << endreq;
    }
  }


  if(m_tagTool->tagged(IEventTagTool::B1SELECTION)){
    m_storeGate->retrieve(c_selectedBJets, m_selectedBJetName);
    if(c_selectedBJets == 0){
      mLog << MSG::ERROR << "Problem getting Selected BJet Container" << endreq;
    }
  }

  if(m_truthAvailable == true){
    getTruthContainers();
  }
}

void BUSTopWAnalysis::getEventWeight(){
  if(m_tagTool->tagged(IEventTagTool::IS_ATLFAST) == false && m_tagTool->tagged(IEventTagTool::IS_MC) == true){ 
    m_eventWeight = m_eventTool->getEventWeight();
  }else{
    m_eventWeight = 1.0;
  }
}

void BUSTopWAnalysis::getTruthContainers(){
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "Getting Truth W Container" << endreq;
}

void BUSTopWAnalysis::plotSelectedCentrality(){
  if(m_tagTool->tagged(IEventTagTool::B1SELECTION) && m_tagTool->tagged(IEventTagTool::NUSELECTION)){
    if(c_selectedW->size() > 0 && c_selectedBJets->size() > 0){
      double num = c_selectedW->at(0)->pt() + c_selectedBJets->at(0)->pt();
      double denom = c_selectedW->at(0)->p() + c_selectedBJets->at(0)->p();

      h_selected_centrality->Fill(num/denom, m_eventWeight);
    }
  }
}
