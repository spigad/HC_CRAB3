#include "GaudiKernel/IToolSvc.h"
#include "GaudiKernel/ITHistSvc.h"

#include "TH1.h"
#include "TH2.h"

#include "DataModel/ElementLink.h"
#include "JetEvent/JetCollection.h"
#include "JetEvent/Jet.h"
#include "MissingETEvent/MissingET.h"

#include "AnalysisTools/IAnalysisTools.h"
#include "AnalysisUtils/IParticleFilter.h"

#include "BUSTopTools/EventTool.h"
#include "BUSTopTools/EventTagTool.h"

#include "BUSTopPreselection/BUSTopJES.h"

#include <stdint.h>
#include <algorithm>
#include <math.h>
#include <functional>

BUSTopJES::BUSTopJES(const std::string& name, ISvcLocator* pSvcLocator) : 
                     Algorithm(name, pSvcLocator){

  declareProperty("JetInputContainer", m_inputJetContainerName);
  declareProperty("JetOutputContainer", m_outputJetContainerName);

  declareProperty("METInputContainer", m_inputMETContainerName);
  declareProperty("METOutputContainer", m_outputMETContainerName);

  declareProperty("JESScale", m_jesScale);

  declareProperty("TruthAvailable", m_truthAvailable);
}

BUSTopJES::~BUSTopJES(){
}

StatusCode BUSTopJES::initialize() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << "Initializing BUSTopJES" << endreq;

  if (service("StoreGateSvc", m_storeGate).isFailure()) {
     mLog << MSG::ERROR << "Unable to retrieve pointer to StoreGateSvc" << endreq;
     return StatusCode::FAILURE;
  }

  service("THistSvc", m_histSvc);

  IToolSvc * toolSvc;
  service("ToolSvc", toolSvc);

  IAlgTool *tmp_eventTool;
  toolSvc->retrieveTool("EventTool", tmp_eventTool);
  m_eventTool = dynamic_cast<IEventTool *>(tmp_eventTool);

  IAlgTool *tmp_eventTagTool;
  toolSvc->retrieveTool("EventTagTool", tmp_eventTagTool);
  m_tagTool = dynamic_cast<IEventTagTool *>(tmp_eventTagTool);

  registerHistograms();

  return StatusCode::SUCCESS;
}

void BUSTopJES::registerHistograms(){
}

StatusCode BUSTopJES::finalize() {
  MsgStream mLog( messageService(), name() );
  
  return StatusCode::SUCCESS;
}

StatusCode BUSTopJES::execute() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << "execute()" << endreq;

  getEventWeight();
  getStoregateContainers();
  createTemporaryContainers();

  skewJetEnergies();
  recalculateMET();

  registerContainers();
  destroyTemporaryContainers();

  StatusCode sc = StatusCode::SUCCESS;

  return sc;

}

void BUSTopJES::recalculateMET(){
  MsgStream mLog( messageService(), name() );

  JetCollection::const_iterator jIter = jetTES->begin();      
  JetCollection::const_iterator jIterEnd = jetTES->end();      

  double ex = metTES->etx();
  double ey = metTES->ety();

  while(jIter < jIterEnd){
    ex -= (*jIter)->px()*m_jesScale;
    ey -= (*jIter)->py()*m_jesScale;
    jIter++;
  }

  c_scaledMET->setEx(ex);
  c_scaledMET->setEy(ey);

  mLog << MSG::INFO << "Scaled EtMiss = " << metTES->et() << " " << c_scaledMET->et() << endreq;
}

void BUSTopJES::skewJetEnergies(){
  MsgStream mLog( messageService(), name() );

  JetCollection::const_iterator jIter = jetTES->begin();
  JetCollection::const_iterator jIterEnd = jetTES->end();

  mLog << MSG::DEBUG << "Entering JES loop" << endreq;

  while(jIter < jIterEnd){
    Jet* tmp = new Jet(*jIter, true, false);
    //tmp->setE((*jIter)->e()*m_jesScale);
    c_scaledJets->push_back(tmp);
    jIter++;
  }
  mLog << MSG::DEBUG << "Entering JES loop... done" << endreq;

}

void BUSTopJES::getStoregateContainers(){
  MsgStream mLog( messageService(), name() );

  jetTES = 0;
  m_storeGate->retrieve(jetTES, m_inputJetContainerName);
  if(jetTES == 0){
    mLog << MSG::ERROR << "Problem getting input JetContainer" << endreq;
  }

  metTES = 0;
  m_storeGate->retrieve(metTES, m_inputMETContainerName);
  if(metTES == 0){
    mLog << MSG::ERROR << "Problem getting input METContainer" << endreq;
  }
}

void BUSTopJES::createTemporaryContainers(){
  c_scaledJets = new JetCollection();
  c_scaledMET = new MissingET();
}

void BUSTopJES::destroyTemporaryContainers(){
}

void BUSTopJES::registerContainers(){
  registerContainer(c_scaledJets, m_outputJetContainerName);
  registerContainer(c_scaledMET, m_outputMETContainerName);
}

void BUSTopJES::registerContainer(JetCollection* j, std::string n){
  MsgStream mLog( messageService(), name() );

  m_storeGate->record(j, n);
  AnalysisUtils::Sort::pT(j);
  m_storeGate->setConst(j);

  JetCollection::const_iterator iter = j->begin();
  JetCollection::const_iterator iterEnd = j->end();

  while(iter < iterEnd){
    mLog << MSG::DEBUG << "WEIGHT = " << (*iter)->getFlavourTagWeight() << endreq;
    iter++;
  }
}

void BUSTopJES::registerContainer(MissingET* m, std::string n){
  MsgStream mLog( messageService(), name() );

  m_storeGate->record(m, n);
  m_storeGate->setConst(m);
}

void BUSTopJES::getEventWeight(){
  if(m_tagTool->tagged(IEventTagTool::IS_ATLFAST) == false && m_tagTool->tagged(IEventTagTool::IS_MC) == true){
    m_eventWeight = m_eventTool->getEventWeight();
  }else{
    m_eventWeight = 1.0;
  }
}

