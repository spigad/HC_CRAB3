#ifndef BUSTOP_ETMISS_ANALYSIS_H
#define BUSTOP_ETMISS_ANALYSIS_H

#include "GaudiKernel/Algorithm.h"

#include "CLHEP/Units/SystemOfUnits.h"

#include "StoreGate/StoreGateSvc.h"

#include "GaudiKernel/ToolHandle.h"

#include <stdint.h>
#include <string>

class MissingET;
class ElectronContainer;
class NeutrinoContainer;
class METHistograms;
class METResolutionHistograms;
class IBUSTopHistogrammer;
class IEventTool;
class IEventTagTool;
class TH1F;
class TH2F;

namespace Analysis{
  class MuonContainer;
}

class BUSTopEtMissAnalysis : public Algorithm {

 public:

   BUSTopEtMissAnalysis(const std::string& name, ISvcLocator* pSvcLocator);
   ~BUSTopEtMissAnalysis();

   StatusCode initialize();
   StatusCode finalize();
   StatusCode execute();

 private:

   StoreGateSvc* m_storeGate;
   ITHistSvc *m_thistSvc;
   IBUSTopHistogrammer* m_histogrammer;
   IEventTool* m_eventTool;
   IEventTagTool* m_tagTool;
   
   std::string m_metContainerName;
   std::string m_neutrinoContainerName;
   std::string m_preselectedElectronsName;
   std::string m_preselectedMuonsName;
   std::string m_cscSelectedElectronsName;
   std::string m_cscSelectedMuonsName;

   bool m_truthAvailable;
   double m_metCut;
   double m_eventWeight;

   const MissingET* metTES;
   const NeutrinoContainer* neutrinoTES;

   const TruthParticleContainer* c_truth_enu;
   const TruthParticleContainer* c_truth_e;

   const TruthParticleContainer* c_truth_munu;
   const TruthParticleContainer* c_truth_mu;

   const TruthParticleContainer* c_truth_taunu;
   const TruthParticleContainer* c_truth_tau;

   const ElectronContainer* c_preselected_elec;
   const Analysis::MuonContainer* c_preselected_muon;
   const ElectronContainer* c_cscSelected_elec;
   const Analysis::MuonContainer* c_cscSelected_muon;

   METHistograms* h_full_met;

   METResolutionHistograms* h_truth_res;

   METHistograms* h_preselection_met;
   METResolutionHistograms* h_preselection_res;
   METHistograms* h_cscSelection_met;
   METResolutionHistograms* h_cscSelection_res;
   
   virtual void registerHistograms();
   virtual void getEventWeight();

   virtual void getParticleContainers();
   virtual void clearParticleContainers();

   virtual void truthAnalysis();
   virtual void plotResolution(METResolutionHistograms* h);

   virtual void jetAnalysis();

   virtual void nuReconAnalysis();
};

#endif // BUSTOP_ETMISS_ANALYSIS_H



