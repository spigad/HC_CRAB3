#include "GaudiKernel/DeclareFactoryEntries.h"

#include "BUSTopTools/BUSTopHistogrammer.h"
#include "BUSTopTools/DecayVector.h"
#include "BUSTopTools/TruthMatch.h"
#include "BUSTopTools/NuSolutionTool.h"
#include "BUSTopTools/EventTool.h"
#include "BUSTopTools/EventTagTool.h"

DECLARE_TOOL_FACTORY( BUSTopHistogrammer )
DECLARE_TOOL_FACTORY( DecayVector )
DECLARE_TOOL_FACTORY( TruthMatch )
DECLARE_TOOL_FACTORY( NuSolutionTool )
DECLARE_TOOL_FACTORY( EventTool )
DECLARE_TOOL_FACTORY( EventTagTool )

DECLARE_FACTORY_ENTRIES( BUSTopTools ) {
  DECLARE_TOOL( BUSTopHistogrammer );
  DECLARE_TOOL( DecayVector );
  DECLARE_TOOL( TruthMatch );
  DECLARE_TOOL( NuSolutionTool );
  DECLARE_TOOL( EventTool );
  DECLARE_TOOL( EventTagTool );
}

