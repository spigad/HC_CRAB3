#include "GaudiKernel/IToolSvc.h"
#include "GaudiKernel/ITHistSvc.h"

#include "TH1.h"
#include "TH2.h"

#include "egammaEvent/ElectronContainer.h"
#include "muonEvent/MuonContainer.h"
#include "muonEvent/Muon.h"

#include "CompositeParticleEvent/CompositeParticleContainer.h"
#include "CompositeParticleEvent/CompositeParticle.h"

#include "ParticleEvent/NeutrinoContainer.h"
#include "ParticleEvent/Neutrino.h"
#include "MissingETEvent/MissingET.h"

#include "SpecialUtils/NeutrinoUtils.h"

#include "DataModel/ElementLink.h"
#include "JetTagInfo/TruthInfo.h"

#include "AnalysisTools/IAnalysisTools.h"

#include "BUSTopTools/IBUSTopHistogrammer.h"
#include "BUSTopTools/INuSolutionTool.h"
#include "BUSTopTools/KinematicHistograms.h"
#include "BUSTopTools/ResolutionHistograms.h"
#include "BUSTopTools/METResolutionHistograms.h"
#include "BUSTopTools/EventTool.h"
#include "BUSTopTools/EventTagTool.h"

#include "BUSTopReconstruction/BUSTopWReconstruction.h"

#include <stdint.h>
#include <algorithm>
#include <math.h>
#include <functional>

BUSTopWReconstruction::BUSTopWReconstruction(const std::string& name, ISvcLocator* pSvcLocator) : 
                                             Algorithm(name, pSvcLocator){

  declareProperty("InputElectrons", m_inputElectronsName);
  declareProperty("InputMuons", m_inputMuonsName);
  declareProperty("InputNeutrinos", m_inputNeutrinosName);
  declareProperty("OutputWName", m_outputWName);

  declareProperty("TruthAvailable", m_truthAvailable);
  declareProperty("FilterTags", m_filterTags);
}

BUSTopWReconstruction::~BUSTopWReconstruction(){
}

StatusCode BUSTopWReconstruction::initialize() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << "Initializing BUSTopWReconstruction" << endreq;

  if (service("StoreGateSvc", m_storeGate).isFailure()) {
     mLog << MSG::ERROR << "Unable to retrieve pointer to StoreGateSvc" << endreq;
     return StatusCode::FAILURE;
  }

  service("THistSvc", m_histSvc);

  IToolSvc * toolSvc;
  service("ToolSvc", toolSvc);

  IAlgTool *tmp_eventTool;
  toolSvc->retrieveTool("EventTool", tmp_eventTool);
  m_eventTool = dynamic_cast<IEventTool *>(tmp_eventTool);

  IAlgTool *tmp_tagTool;
  toolSvc->retrieveTool("EventTagTool", tmp_tagTool);
  m_tagTool = dynamic_cast<IEventTagTool *>(tmp_tagTool);

  IAlgTool *tmp_histogramTool;
  toolSvc->retrieveTool("BUSTopHistogrammer", tmp_histogramTool);
  m_histogrammer = dynamic_cast<IBUSTopHistogrammer *>(tmp_histogramTool);

  IAlgTool *tmp_nuSolTool;
  toolSvc->retrieveTool("NuSolutionTool", tmp_nuSolTool);
  m_nuSolTool = dynamic_cast<INuSolutionTool *>(tmp_nuSolTool);

  registerHistograms();

  return StatusCode::SUCCESS;
}

void BUSTopWReconstruction::registerHistograms(){
  std::stringstream fName, hName;
  std::string title;

  fName.str("");
  hName.str("");
  hName << "wr_recon";
  fName << "/AANT/WReconstruction/" << m_outputWName << "/" << hName.str();
  title = "N Recon Pass";
  h_recon = new TH1F(hName.str().c_str(), title.c_str(), 1, 0, 1);
  m_histSvc->regHist(fName.str().c_str(), h_recon);

  fName.str("");
  hName.str("");
  hName << "wr_size";
  fName << "/AANT/WReconstruction/" << m_outputWName << "/" << hName.str();
  title = "N Recon Size";
  h_size = new TH1F(hName.str().c_str(), title.c_str(), 10, 0, 10);
  m_histSvc->regHist(fName.str().c_str(), h_size);
}

StatusCode BUSTopWReconstruction::finalize() {
  MsgStream mLog( messageService(), name() );
  
  return StatusCode::SUCCESS;
}

StatusCode BUSTopWReconstruction::execute() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << "execute()" << endreq;

  getEventWeight();
  getStoregateContainers();
  createTemporaryContainers();

  //do full reconstruction

  int elec_tag = m_filterTags.at(0) + 1;
  int muon_tag = m_filterTags.at(0) + 2;

  if(m_tagTool->allTagged(m_filterTags)){
    h_recon->Fill(0.0, m_eventWeight);
    
    if(m_tagTool->tagged(elec_tag)){
      mLog << MSG::DEBUG << "Reconstructing W with electron" << endreq;
      reconstructW(c_electrons);
    }

    if(m_tagTool->tagged(muon_tag)){
      mLog << MSG::DEBUG << "Reconstructing W with muon" << endreq;
      reconstructW(c_muons);
    }

    h_size->Fill(c_w->size(), m_eventWeight);

  }else{
    mLog << MSG::DEBUG << "m_filterTags failed" << endreq;
  }

  registerContainers();
  destroyTemporaryContainers();
  
  StatusCode sc = StatusCode::SUCCESS;

  return sc;

}

void BUSTopWReconstruction::getStoregateContainers(){
  MsgStream mLog( messageService(), name() );

  m_storeGate->retrieve(c_electrons, m_inputElectronsName);
  if(c_electrons == 0){
    mLog << MSG::ERROR << "Problem getting Electron Container" << endreq;
  }

  m_storeGate->retrieve(c_muons, m_inputMuonsName);
  if(c_muons == 0){
    mLog << MSG::ERROR << "Problem getting Muon Container" << endreq;
  }

  m_storeGate->retrieve(c_neutrinos, m_inputNeutrinosName);
  if(c_neutrinos == 0){
    mLog << MSG::ERROR << "Problem getting Neutrino Container" << endreq;
  }else{
    mLog << MSG::DEBUG << "W neutrinos received: " << c_neutrinos->size() << endreq;
  }
}

void BUSTopWReconstruction::createTemporaryContainers(){
  c_w = new CompositeParticleContainer();
}

void BUSTopWReconstruction::destroyTemporaryContainers(){
  delete c_w;
  c_w = 0;
}

void BUSTopWReconstruction::registerContainers(){
  registerContainer(c_w, m_outputWName);
}

void BUSTopWReconstruction::registerContainer(CompositeParticleContainer* c, std::string n){
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "Ws Reconstructed: " << c->size() << endreq;

  CompositeParticleContainer* tmp = new CompositeParticleContainer();
    
  m_storeGate->record(tmp, n);
    
  CompositeParticleContainer::const_iterator cIter = c->begin();
  CompositeParticleContainer::const_iterator cIterEnd = c->end();
  
  while(cIter < cIterEnd){
    tmp->push_back(new CompositeParticle(**cIter));
    cIter++;
  }

  AnalysisUtils::Sort::pT(tmp);
 
  m_storeGate->setConst(tmp);
}

void BUSTopWReconstruction::getEventWeight(){
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "m_tagTool->tagged(IS_ATLFAST) = " << m_tagTool->tagged(IEventTagTool::IS_ATLFAST) << endreq;

  if(m_tagTool->tagged(IEventTagTool::IS_ATLFAST) == false && m_tagTool->tagged(IEventTagTool::IS_MC) == true){  
    m_eventWeight = m_eventTool->getEventWeight();
  }else{
    m_eventWeight = 1.0;
  }
}

template <class LEPTON_COLL>
void BUSTopWReconstruction::reconstructW(const LEPTON_COLL* lc){
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "c_neutrinos size = " << c_neutrinos->size() << endreq;
  mLog << MSG::DEBUG << "lc size = " << lc->size() << endreq;

  if(lc->size() > 0 && c_neutrinos->size() > 0){
    NeutrinoContainer::const_iterator nuIter = c_neutrinos->begin();
    NeutrinoContainer::const_iterator nuIterEnd = c_neutrinos->end();

    while(nuIter < nuIterEnd){
      CompositeParticle* w_tmp = new CompositeParticle();
      w_tmp->add(lc->at(0));
      w_tmp->add((*nuIter));

      if(w_tmp->charge() > 0){   
        w_tmp->set_pdgId(PDG::W_plus);
      }else{
        w_tmp->set_pdgId(PDG::W_minus);
      }

      c_w->push_back(w_tmp);
      nuIter++;
    }
  }
}

