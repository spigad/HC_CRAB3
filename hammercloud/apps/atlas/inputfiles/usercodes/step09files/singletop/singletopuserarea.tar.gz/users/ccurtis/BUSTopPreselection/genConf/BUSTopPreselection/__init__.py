## Hook for BUSTopPreselection genConf module
