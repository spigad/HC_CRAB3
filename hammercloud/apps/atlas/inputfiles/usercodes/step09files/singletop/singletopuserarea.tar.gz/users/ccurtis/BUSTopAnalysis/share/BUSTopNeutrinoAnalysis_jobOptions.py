from BUSTopAnalysis.BUSTopAnalysisConf import BUSTopNeutrinoAnalysis
Sequencer += BUSTopNeutrinoAnalysis()
BUSTopNeutrinoAnalysis.OutputLevel = WARNING

BUSTopNeutrinoAnalysis.Electrons                         = BUSTopPreselection.InputElectronContainer
BUSTopNeutrinoAnalysis.Muons                             = BUSTopPreselection.InputMuonContainer
BUSTopNeutrinoAnalysis.PreselectedElectrons              = BUSTopPreselection.OutputElectronContainer
BUSTopNeutrinoAnalysis.PreselectedMuons                  = BUSTopPreselection.OutputMuonContainer
BUSTopNeutrinoAnalysis.CSCSelectedElectrons              = BUSTopCSCSelection.OutputElectronContainer
BUSTopNeutrinoAnalysis.CSCSelectedMuons                  = BUSTopCSCSelection.OutputMuonContainer
BUSTopNeutrinoAnalysis.MET                               = BUSTopJES.METOutputContainer

BUSTopNeutrinoAnalysis.Neutrinos                         = BUSTopNuRecon_Full.OutputNeutrinoContainer
BUSTopNeutrinoAnalysis.PreselectedNeutrinos              = BUSTopNuRecon_Preselection.OutputNeutrinoContainer
BUSTopNeutrinoAnalysis.CSCSelectedNeutrinos              = BUSTopNuRecon_CSCSelection.OutputNeutrinoContainer

if DoSelection:
	BUSTopNeutrinoAnalysis.SelectedNeutrinos         = BUSTopNuRecon_Selection.OutputNeutrinoContainer

BUSTopNeutrinoAnalysis.WWidth                            = 2.14
BUSTopNeutrinoAnalysis.METSigma                          = 13.04

BUSTopNeutrinoAnalysis.TruthAvailable                    = DoTruth


