#include "GaudiKernel/MsgStream.h"
#include "GaudiKernel/AlgFactory.h"
#include "GaudiKernel/IToolSvc.h"
#include "GaudiKernel/ITHistSvc.h"
#include "StoreGate/StoreGateSvc.h"
#include "StoreGate/DataHandle.h"

#include "TH1.h"
#include "TH2.h"

#include "McParticleEvent/TruthParticle.h"
#include "McParticleEvent/TruthParticleContainer.h"
#include "egammaEvent/ElectronContainer.h"
#include "egammaEvent/Electron.h"
#include "muonEvent/MuonContainer.h"
#include "muonEvent/Muon.h"

#include "JetEvent/JetCollection.h"
#include "JetEvent/Jet.h"

#include "MissingETEvent/MissingET.h"

#include "AnalysisTools/IAnalysisTools.h"
#include "AnalysisUtils/AnalysisCombination.h"
#include "AnalysisUtils/AnalysisMisc.h"
#include "AnalysisUtils/IParticleFilter.h"

#include "BUSTopTools/IBUSTopHistogrammer.h"
#include "BUSTopTools/ElectronHistograms.h"
#include "BUSTopTools/MuonHistograms.h"
#include "BUSTopTools/ResolutionHistograms.h"
#include "BUSTopTools/DecayVector.h"
#include "BUSTopTools/TruthMatch.h"
#include "BUSTopTools/EventTool.h"
#include "BUSTopTools/EventTagTool.h"

#include "BUSTopAnalysis/BUSTopElectronAnalysis.h"

#include <stdint.h>
#include <algorithm>
#include <math.h>
#include <functional>

BUSTopElectronAnalysis::BUSTopElectronAnalysis(const std::string& name,
  ISvcLocator* pSvcLocator) : Algorithm(name, pSvcLocator), m_trigDec("TrigDec::TrigDecisionTool")
{
  /// switches to control the analysis through job options :: these are the default
  /// to changed in the job options

  declareProperty("ElectronInputContainer", m_inputElectronContainerName);
  declareProperty("SelectedElectronContainer", m_selectedElectronContainerName);

  declareProperty("FilteredElectronContainer", m_filteredElectronContainerName);
  declareProperty("FilteredJetContainer", m_filteredJetContainerName);
  declareProperty("FilterRejectsElectronContainer", m_filterRejectsContainerName);

  declareProperty("PreselectedElectronContainer", m_preselectedElectronContainerName);
  declareProperty("PreselectedLJetContainer", m_preselectedLJetContainerName);
  declareProperty("PreselectedBJetContainer", m_preselectedBJetContainerName);
  declareProperty("PreselectedMuonContainer", m_preselectedMuonContainerName);

  declareProperty("TruthMatchDeltaR", m_truthMatchDeltaR);
  declareProperty("TruthAvailable", m_truthAvailable);

  declareProperty("TrigDecisionTool", m_trigDec, "The tool to access TrigDecision");

  declareProperty("DoTrigger", m_doTrigger);
}


/////////////////////////////////////////////////////////////////////////////////////
/// Destructor - check up memory allocation
/// delete any memory allocation on the heap

BUSTopElectronAnalysis::~BUSTopElectronAnalysis() {
}

////////////////////////////////////////////////////////////////////////////////////
/// Initialize
/// initialize StoreGate
/// get a handle on the analysis tools
/// book histograms

StatusCode BUSTopElectronAnalysis::initialize() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO
       << "Initializing BUSTopElectronAnalysis"
       << endreq;

  StatusCode sc;
  
  sc = service("StoreGateSvc", m_storeGate);
  if(sc.isFailure()){
    mLog << MSG::ERROR 
         << "Unable to retrieve pointer to StoreGateSvc"
	 << endreq;
    return sc;
  }
  
  sc = service("THistSvc", m_thistSvc);
  if(sc.isFailure()){
    mLog << MSG::ERROR 
         << "Unable to retrieve pointer to THistSvc"
	 << endreq;
    return sc;
  }

  IToolSvc * toolSvc;
  service("ToolSvc", toolSvc);

  IAlgTool *tmp_analysisTools;
  toolSvc->retrieveTool("AnalysisTools", tmp_analysisTools);
  m_analysisTools = dynamic_cast<IAnalysisTools *>(tmp_analysisTools);

  IAlgTool *tmp_eventTool;
  toolSvc->retrieveTool("EventTool", tmp_eventTool);
  m_eventTool = dynamic_cast<IEventTool *>(tmp_eventTool);

  IAlgTool *tmp_tagTool;
  toolSvc->retrieveTool("EventTagTool", tmp_tagTool);
  m_tagTool = dynamic_cast<IEventTagTool *>(tmp_tagTool);

  IAlgTool *tmp_truthMatch;
  toolSvc->retrieveTool("TruthMatch", tmp_truthMatch);
  m_truthMatchTool = dynamic_cast<ITruthMatch *>(tmp_truthMatch);

  IAlgTool *tmp_decayTool;
  toolSvc->retrieveTool("DecayVector", tmp_decayTool);
  m_truthVector = dynamic_cast<IDecayVector *>(tmp_decayTool);

  IAlgTool *tmp_histogramTool;
  toolSvc->retrieveTool("BUSTopHistogrammer", tmp_histogramTool);
  m_histogrammer = dynamic_cast<IBUSTopHistogrammer *>(tmp_histogramTool);

  m_trigDec.retrieve();

  registerHistograms();
  
  return StatusCode::SUCCESS;
}

void BUSTopElectronAnalysis::registerHistograms(){
  std::stringstream fName, hName;
  std::string title;

  h_full_elec = new ElectronHistograms(m_histogrammer, "ElectronAnalysis", "Kinematic", "ea_full_elec");
  h_filtered_elec = new ElectronHistograms(m_histogrammer, "ElectronAnalysis", "Kinematic", "ea_filtered_elec");

  h_epre_efull = new ElectronHistograms(m_histogrammer, "ElectronAnalysis", "Kinematic", "ea_epre_efull");
  h_epre_eprim = new ElectronHistograms(m_histogrammer, "ElectronAnalysis", "Kinematic", "ea_epre_eprim");
  h_epre_esec = new ElectronHistograms(m_histogrammer, "ElectronAnalysis", "Kinematic", "ea_epre_esec");
  h_epre_musec = new MuonHistograms(m_histogrammer, "ElectronAnalysis", "Kinematic", "ea_epre_musec");

  h_triggered_eprim = new ElectronHistograms(m_histogrammer, "ElectronAnalysis", "Kinematic", "ea_triggered_eprim");
  h_selected_e = new ElectronHistograms(m_histogrammer, "ElectronAnalysis", "Kinematic", "ea_selected_e");

  fName.str("");
  hName.str("");
  hName << "ea_trigger_pt30";
  fName << "/AANT/ElectronAnalysis/" << "TriggerAnalysis" << "/" << hName.str();
  title = "Trigger Efficiency (30GeV)";
  h_trigger_pt30 = new TH1F(hName.str().c_str(), title.c_str(), 2, 0, 2);
  m_thistSvc->regHist(fName.str().c_str(), h_trigger_pt30);

  fName.str("");
  hName.str("");
  hName << "ea_filtered_eJet_deltaR";
  fName << "/AANT/ElectronAnalysis/" << "FilterAnalysis" << "/" << hName.str();
  title = "Filtered Electron/Jet \\Delta R";
  h_filtered_eJet_deltaR = new TH1F(hName.str().c_str(), title.c_str(), 120, 0, 6.0);
  m_thistSvc->regHist(fName.str().c_str(), h_filtered_eJet_deltaR);

  fName.str("");
  hName.str("");
  hName << "ea_preselected_eJet_deltaR";
  fName << "/AANT/ElectronAnalysis/" << "PreselectionAnalysis" << "/" << hName.str();
  title = "Primary Electron/Jet \\Delta R";
  h_preselected_eJet_deltaR = new TH1F(hName.str().c_str(), title.c_str(), 120, 0, 6.0);
  m_thistSvc->regHist(fName.str().c_str(), h_preselected_eJet_deltaR);

  //truth dependent histograms!
  if(m_truthAvailable == true){
    h_matched_filter_rejects_elec = new ElectronHistograms(m_histogrammer, "ElectronAnalysis", "FilterAnalysis", "ea_matched_filter_rejects");
    h_matched_filter_rejects_elec_res = new ResolutionHistograms(m_histogrammer, "ElectronAnalysis", "FilterAnalysis", "ea_matched_filter_rejects_res", m_truthMatchDeltaR);

    h_matched_preselected_elec = new ElectronHistograms(m_histogrammer, "ElectronAnalysis", "PreselectionAnalysis", "ea_matched_preselection");
    h_matched_preselected_elec_res = new ResolutionHistograms(m_histogrammer, "ElectronAnalysis", "PreselectionAnalysis", "ea_matched_preselection_res", m_truthMatchDeltaR);

    fName.str("");
    hName.str("");
    hName << "ea_matched_preselection_index";
    fName << "/AANT/ElectronAnalysis/" << "PreselectionAnalysis" << "/" << hName.str();
    title = "Preselected Truth Match Index";
    h_matched_preselected_elec_index = new TH1F(hName.str().c_str(), title.c_str(), 10, -0.5, 9.5);
    m_thistSvc->regHist(fName.str().c_str(), h_matched_preselected_elec_index);

    fName.str("");
    hName.str("");
    hName << "ea_matched_selection_index";
    fName << "/AANT/ElectronAnalysis/" << "SelectionAnalysis" << "/" << hName.str();
    title = "Selected Truth Match Index";
    h_matched_selected_elec_index = new TH1F(hName.str().c_str(), title.c_str(), 10, 0.0, 10);
    m_thistSvc->regHist(fName.str().c_str(), h_matched_selected_elec_index);

    fName.str("");
    hName.str("");
    hName << "ea_filt_trig_elec";
    fName << "/AANT/ElectronAnalysis/" << "FilterAnalysis" << "/" << hName.str();
    title = "Filtered Electrons";
    h_filt_trig_elec = new TH1F(hName.str().c_str(), title.c_str(), 4, 0, 4);
    m_thistSvc->regHist(fName.str().c_str(), h_filt_trig_elec);
  }
}

StatusCode BUSTopElectronAnalysis::finalize() {
  MsgStream mLog( messageService(), name() );

  return StatusCode::SUCCESS;
}

//////////////////////////////////////////////////////////////////////////////////
/// Execute - called by the event loop on event by event

StatusCode BUSTopElectronAnalysis::execute() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << "execute()" << endreq;

  getEventWeight();  
  getStoregateContainers();

  plotElectrons();
  eJetIsolation();

  if(m_doTrigger == true){
    triggerAnalysis();
  }

  if(m_truthAvailable == true){
    filterAnalysis();
    preselectionAnalysis();
    selectionAnalysis();
  }

  clearParticleContainers();

  return StatusCode::SUCCESS;
}

void BUSTopElectronAnalysis::getStoregateContainers(){
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "Getting storegateContainers..." << endreq;

  elecTES = 0;
  m_storeGate->retrieve(elecTES, m_inputElectronContainerName);
  if(elecTES == 0){
    mLog << MSG::ERROR << "Problem getting input ElectronContainer" << endreq;
  }

  c_selectedElectrons = 0;
  m_storeGate->retrieve(c_selectedElectrons, m_selectedElectronContainerName);
  if(c_selectedElectrons == 0){
    mLog << MSG::ERROR << "Problem getting Selected ElectronContainer" << endreq;
  }

  c_filtered = 0;
  m_storeGate->retrieve(c_filtered, m_filteredElectronContainerName);
  if(c_filtered == 0){
    mLog << MSG::ERROR << "Problem getting Filtered ElectronContainer" << endreq;
  }

  c_filtered_jets = 0;
  m_storeGate->retrieve(c_filtered_jets, m_filteredJetContainerName);
  if(c_filtered_jets == 0){
    mLog << MSG::ERROR << "Problem getting Filtered Jets Container" << endreq;
  }

  c_filter_rejects = 0;
  m_storeGate->retrieve(c_filter_rejects, m_filterRejectsContainerName);
  if(c_filter_rejects == 0){
    mLog << MSG::ERROR << "Problem getting Filter Rejects ElectronContainer" << endreq;
  }

  c_preselected = 0;
  m_storeGate->retrieve(c_preselected, m_preselectedElectronContainerName);
  if(c_preselected == 0){
    mLog << MSG::ERROR << "Problem getting Preselected ElectronContainer" << endreq;
  }

  c_preselected_bjets = 0;
  m_storeGate->retrieve(c_preselected_bjets, m_preselectedBJetContainerName);
  if(c_preselected_bjets == 0){
    mLog << MSG::ERROR << "Problem getting Preselected BJet Container" << endreq;
  }

  c_preselected_ljets = 0;
  m_storeGate->retrieve(c_preselected_ljets, m_preselectedLJetContainerName);
  if(c_preselected_ljets == 0){
    mLog << MSG::ERROR << "Problem getting Preselected LJet Container" << endreq;
  }

  c_preselected_muons = 0;
  m_storeGate->retrieve(c_preselected_muons, m_preselectedMuonContainerName);
  if(c_preselected_muons == 0){
    mLog << MSG::ERROR << "Problem getting Preselected Muon Container" << endreq;
  }

  if(m_truthAvailable == true){
    c_elecTruth = 0;
    m_storeGate->retrieve(c_elecTruth, "BUSTopTruth_e");
    if(c_elecTruth == 0){
      mLog << MSG::ERROR << "Problem getting Truth ElectronContainer" << endreq;
    }
  }
}

void BUSTopElectronAnalysis::plotElectrons(){
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "plotElectrons()" << endreq;

  h_full_elec->plotContainer(elecTES, m_eventWeight);
  h_filtered_elec->plotContainer(c_filtered, m_eventWeight);

  if(m_tagTool->tagged(IEventTagTool::TRIGGERED_ELECTRON) && elecTES->size() > 0){
    h_triggered_eprim->plot(elecTES->at(0), m_eventWeight);
  }

  if(m_tagTool->tagged(IEventTagTool::ELECTRON_SELECTION) && c_selectedElectrons->size() > 0){
    h_selected_e->plot(c_selectedElectrons->at(0), m_eventWeight);
  }

  if(c_preselected->size() > 0){
    h_epre_efull->plotContainer(c_preselected, m_eventWeight);

    if(m_tagTool->tagged(IEventTagTool::ELECTRON_PRESELECTION) == true){
      h_epre_eprim->plot(c_preselected->at(0), m_eventWeight);

      h_epre_esec->n[0]->Fill(c_preselected->size()-1, m_eventWeight);
      for(unsigned int i = 1; i < c_preselected->size(); i++){
        h_epre_esec->plot(c_preselected->at(i), m_eventWeight);
      }
      
      h_epre_musec->plotContainer(c_preselected_muons, m_eventWeight);
    }
  }
}

void BUSTopElectronAnalysis::clearParticleContainers(){

  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "clearParticleContainers()" << endreq;

  elecTES = 0;
  c_filtered = 0;
  c_filtered_jets = 0;
  c_filter_rejects = 0;
  c_preselected = 0;
  c_preselected_bjets = 0;
  c_preselected_ljets = 0;
  c_preselected_muons = 0;
}

void BUSTopElectronAnalysis::filterAnalysis(){    
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "filterAnalysis()" << endreq;

  TruthParticleContainer::const_iterator mcIter = c_elecTruth->begin();
  TruthParticleContainer::const_iterator mcIterEnd = c_elecTruth->end();

  while(mcIter < mcIterEnd){
    unsigned int acceptedIndex = 0; 
    unsigned int rejectedIndex = 0; 

    m_truthMatchTool->matchR(*mcIter, c_filtered, acceptedIndex);
    m_truthMatchTool->matchR(*mcIter, c_filter_rejects, rejectedIndex);

    double acceptedDeltaR = 1000.0;
    double rejectedDeltaR = 1000.0;

    if(c_filtered->size() > 0){
      acceptedDeltaR = AnalysisUtils::Delta::R(*mcIter, c_filtered->at(acceptedIndex));
    }

    if(c_filter_rejects->size() > 0){
      rejectedDeltaR = AnalysisUtils::Delta::R(*mcIter, c_filter_rejects->at(rejectedIndex));
    }

    if(rejectedDeltaR < acceptedDeltaR && rejectedDeltaR < m_truthMatchDeltaR){
      h_matched_filter_rejects_elec->plot(c_filter_rejects->at(rejectedIndex), m_eventWeight);
      h_matched_filter_rejects_elec_res->plot(*mcIter, c_filter_rejects->at(rejectedIndex), m_eventWeight);
    }  

   if(m_tagTool->tagged(IEventTagTool::TRIGGERED)){
     const Analysis::Electron* elec = 0;
     if(rejectedDeltaR < acceptedDeltaR && rejectedDeltaR < m_truthMatchDeltaR){
       //rejected best match
       elec = c_filter_rejects->at(rejectedIndex);
     }else if(acceptedDeltaR < m_truthMatchDeltaR){
       //accepted best match
       elec = c_filtered->at(acceptedIndex);
     }

     if(elec != 0){
       int typeCode = 0;
       if(elec->isem(egammaPID::ElectronTight) == 0){
         typeCode = 3;
       }else if(elec->isem(egammaPID::ElectronMedium) == 0){
         typeCode = 2;
       }else if(elec->isem(egammaPID::ElectronLoose) == 0){
         typeCode = 1;
       }

       h_filt_trig_elec->Fill(typeCode, m_eventWeight);       
     }
   }

    mcIter++;
  }
}

void BUSTopElectronAnalysis::selectionAnalysis(){

  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "selectionAnalysis" << endreq;

  if(c_selectedElectrons->size() > 0){
    h_matched_selected_elec_index->Fill(0.0, m_eventWeight);
  }

  if(m_tagTool->tagged(IEventTagTool::ELECTRON_SELECTION) == true && c_selectedElectrons->size() > 0){
  
    TruthParticleContainer::const_iterator mcIter = c_elecTruth->begin();
    TruthParticleContainer::const_iterator mcIterEnd = c_elecTruth->end();

    while(mcIter < mcIterEnd){
      double acceptedDeltaR = 1000.0;

      acceptedDeltaR = AnalysisUtils::Delta::R(*mcIter, c_selectedElectrons->at(0));
 
      if(acceptedDeltaR < m_truthMatchDeltaR){
        h_matched_selected_elec_index->Fill(1.0, m_eventWeight);
      }
      
      mcIter++;
    }
  }
}

void BUSTopElectronAnalysis::preselectionAnalysis(){

  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "preselectionAnalysis" << endreq;

  //How many events are getting through the preselection stage (raw)?
  //Then truth match the electrons - how many are really from the truth?

  //search for best truth match
  //keep a track of how many best matches are the primary electron...

  if(m_tagTool->tagged(IEventTagTool::ELECTRON_PRESELECTION) == true){
  
    TruthParticleContainer::const_iterator mcIter = c_elecTruth->begin();
    TruthParticleContainer::const_iterator mcIterEnd = c_elecTruth->end();

    while(mcIter < mcIterEnd){
      unsigned int acceptedIndex = 0;
   
      m_truthMatchTool->matchR(*mcIter, c_preselected, acceptedIndex);
    
      double acceptedDeltaR = 1000.0;

      acceptedDeltaR = AnalysisUtils::Delta::R(*mcIter, c_preselected->at(acceptedIndex));
 
      if(acceptedDeltaR < m_truthMatchDeltaR){
        h_matched_preselected_elec->plot(c_preselected->at(acceptedIndex), m_eventWeight);
        h_matched_preselected_elec_res->plot(*mcIter, c_preselected->at(acceptedIndex), m_eventWeight);

        h_matched_preselected_elec_index->Fill(acceptedIndex, m_eventWeight);
      }
      
      mcIter++;
    }
  }
}

void BUSTopElectronAnalysis::getEventWeight(){
  if(m_tagTool->tagged(IEventTagTool::IS_ATLFAST) == false && m_tagTool->tagged(IEventTagTool::IS_MC) == true){
    m_eventWeight = m_eventTool->getEventWeight();
  }else{
    m_eventWeight = 1.0;
  }
}

void BUSTopElectronAnalysis::eJetIsolation(){
  MsgStream mLog( messageService(), name() );
 
  mLog << MSG::DEBUG << "eJetIsolation()" << endreq;

  filteredEJetIsolation();
  preselectedEJetIsolation();
}

void BUSTopElectronAnalysis::filteredEJetIsolation(){
  MsgStream mLog( messageService(), name() );
 
  mLog << MSG::DEBUG << "filteredEJetIsolation()" << endreq;

  ElectronContainer::const_iterator elecIter = c_filtered->begin();
  ElectronContainer::const_iterator elecIterEnd = c_filtered->end();

  while(elecIter < elecIterEnd){
    JetCollection::const_iterator jetIter = c_filtered_jets->begin();
    JetCollection::const_iterator jetIterEnd = c_filtered_jets->end();
    double deltaR = 0;
    double acceptedDeltaR = 1000;
  
    while(jetIter < jetIterEnd){
      deltaR = AnalysisUtils::Delta::R(*elecIter, *jetIter);
      if(deltaR < acceptedDeltaR){
        acceptedDeltaR = deltaR;
      }
      jetIter++;
    }

    h_filtered_eJet_deltaR->Fill(acceptedDeltaR, m_eventWeight);
    elecIter++;
  }
}

void BUSTopElectronAnalysis::preselectedEJetIsolation(){
  MsgStream mLog( messageService(), name() );
 
  mLog << MSG::DEBUG << "preselectedEJetIsolation()" << endreq;

  if(m_tagTool->tagged(IEventTagTool::ELECTRON_PRESELECTION) == true){
    JetCollection::const_iterator jetIter = c_preselected_bjets->begin();
    JetCollection::const_iterator jetIterEnd = c_preselected_bjets->end();
    double deltaR = 0;
    double acceptedDeltaR = 1000;
  
    while(jetIter < jetIterEnd){
      deltaR = AnalysisUtils::Delta::R(c_preselected->at(0), *jetIter);
      if(deltaR < acceptedDeltaR){
        acceptedDeltaR = deltaR;
      }
      jetIter++;
    }

    jetIter = c_preselected_ljets->begin();
    jetIterEnd = c_preselected_ljets->end();

    while(jetIter < jetIterEnd){
      deltaR = AnalysisUtils::Delta::R(c_preselected->at(0), *jetIter);
      if(deltaR < acceptedDeltaR){
        acceptedDeltaR = deltaR;
      }
      jetIter++;
    }

    
    h_preselected_eJet_deltaR->Fill(acceptedDeltaR, m_eventWeight);
  }
}

void BUSTopElectronAnalysis::triggerAnalysis(){
  MsgStream mLog( messageService(), name() );
 
  mLog << MSG::DEBUG << "triggerAnalysis()" << endreq;

  if(elecTES->size() > 0 && elecTES->at(0)->pt() > 30*GeV){
    h_trigger_pt30->Fill(0.0, m_eventWeight);
    if(m_tagTool->tagged(IEventTagTool::TRIGGERED_ELECTRON)){
      h_trigger_pt30->Fill(1.0, m_eventWeight);
    }
  }
}
