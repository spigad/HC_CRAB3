#include "GaudiKernel/IToolSvc.h"
#include "GaudiKernel/ITHistSvc.h"

#include "TH1.h"
#include "TH2.h"

#include "DataModel/ElementLink.h"
#include "JetEvent/JetCollection.h"
#include "JetEvent/Jet.h"

#include "AnalysisTools/IAnalysisTools.h"
#include "AnalysisUtils/IParticleFilter.h"

#include "BUSTopTools/EventTool.h"
#include "BUSTopTools/EventTagTool.h"
#include "BUSTopPreselection/BUSTopBJetTagger.h"

#include <stdint.h>
#include <algorithm>
#include <math.h>
#include <functional>

BUSTopBJetTagger::BUSTopBJetTagger(const std::string& name, ISvcLocator* pSvcLocator) : 
                     Algorithm(name, pSvcLocator){

  declareProperty("InputJetContainer", m_inputJetContainerName);
  declareProperty("OutputBJetContainer", m_outputBJetContainerName);
  declareProperty("OutputLJetContainer", m_outputLightJetContainerName);  

  declareProperty("JetWeightTagger", m_jetWeightTagger);
  declareProperty("RelativeTag", m_useRelativeTag);
  declareProperty("WeightCut", m_weightCut);  

  declareProperty("TruthAvailable", m_truthAvailable);  

}

BUSTopBJetTagger::~BUSTopBJetTagger(){
}

StatusCode BUSTopBJetTagger::initialize() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << "Initializing BUSTopBJetTagger" << endreq;

  if (service("StoreGateSvc", m_storeGate).isFailure()) {
     mLog << MSG::ERROR << "Unable to retrieve pointer to StoreGateSvc" << endreq;
     return StatusCode::FAILURE;
  }

  service("THistSvc", m_histSvc);

  IToolSvc * toolSvc;
  service("ToolSvc", toolSvc);

  IAlgTool *tmp_eventTool;
  toolSvc->retrieveTool("EventTool", tmp_eventTool);
  m_eventTool = dynamic_cast<IEventTool *>(tmp_eventTool);

  IAlgTool *tmp_eventTagTool;
  toolSvc->retrieveTool("EventTagTool", tmp_eventTagTool);
  m_tagTool = dynamic_cast<IEventTagTool *>(tmp_eventTagTool);

  registerHistograms();

  return StatusCode::SUCCESS;
}

void BUSTopBJetTagger::registerHistograms(){
}

StatusCode BUSTopBJetTagger::finalize() {
  MsgStream mLog( messageService(), name() );
  
  return StatusCode::SUCCESS;
}

StatusCode BUSTopBJetTagger::execute() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << "execute()" << endreq;
  
  getEventWeight();
  getStoregateContainers();
  createTemporaryContainers();

  if(m_useRelativeTag){
    tagBestJet();
  }else{
    tagBJets();
  }

  registerContainers();
  destroyTemporaryContainers();

  StatusCode sc = StatusCode::SUCCESS;

  return sc;

}

void BUSTopBJetTagger::getStoregateContainers(){
  MsgStream mLog( messageService(), name() );

  jetTES = 0;

  m_storeGate->retrieve(jetTES, m_inputJetContainerName);
  if(jetTES == 0){
    mLog << MSG::ERROR << "Problem getting intput JetContainer" << endreq;
  }
}

void BUSTopBJetTagger::createTemporaryContainers(){
  c_bjets = new JetCollection(SG::VIEW_ELEMENTS);
  c_ljets = new JetCollection(SG::VIEW_ELEMENTS);
}

void BUSTopBJetTagger::destroyTemporaryContainers(){
}

void BUSTopBJetTagger::registerContainers(){
  registerContainer(c_bjets, m_outputBJetContainerName);
  registerContainer(c_ljets, m_outputLightJetContainerName);
}

void BUSTopBJetTagger::registerContainer(JetCollection* j, std::string name){
  m_storeGate->record(j, name);
  AnalysisUtils::Sort::pT(j);
  m_storeGate->setConst(j);
}

void BUSTopBJetTagger::tagBJets(){
  MsgStream mLog( messageService(), name() );
  JetCollection::const_iterator jIter = jetTES->begin();
  JetCollection::const_iterator jIterEnd = jetTES->end();

  while(jIter < jIterEnd){
    mLog << MSG::DEBUG << "weight = " << (*jIter)->getFlavourTagWeight(m_jetWeightTagger) << endreq;

    double tagWeight = -50.0;
    if(m_jetWeightTagger == "Default"){
      tagWeight = (*jIter)->getFlavourTagWeight();
    }else{
      tagWeight = (*jIter)->getFlavourTagWeight(m_jetWeightTagger);
    }

    if(tagWeight > m_weightCut){
      c_bjets->push_back(*jIter);
    }else{
      c_ljets->push_back(*jIter);
    }
    jIter++;
  }
}

void BUSTopBJetTagger::tagBestJet(){
  MsgStream mLog( messageService(), name() );
  JetCollection::const_iterator jIter = jetTES->begin();
  JetCollection::const_iterator jIterEnd = jetTES->end();

  double highestWeight = -50.0;
  int highestWeightIndex = -1;
  int index = 0;

  IParticleFilter filter;
  filter.setEtaMin(-2.5);
  filter.setEtaMax(2.5);
  filter.setPtMin(15*GeV);
  
  while(jIter < jIterEnd){
    mLog << MSG::DEBUG << "weight = " << (*jIter)->getFlavourTagWeight(m_jetWeightTagger) << endreq;

    double tagWeight = -100.0;
    if(filter.isAccepted(*jIter) == true){
      if(m_jetWeightTagger == "Default"){
        tagWeight = (*jIter)->getFlavourTagWeight();
      }else{
        tagWeight = (*jIter)->getFlavourTagWeight(m_jetWeightTagger);
      }
    }

    if(tagWeight > highestWeight){
      highestWeightIndex = index;
      highestWeight = tagWeight;
    }

    jIter++;
    index++;
  }  

  jIter = jetTES->begin();
  jIterEnd = jetTES->end();

  index = 0;
  while(jIter < jIterEnd){
    if(index == highestWeightIndex){
      c_bjets->push_back(*jIter);
    }else{
      c_ljets->push_back(*jIter);
    }
    jIter++;
    index++;
  }
}

void BUSTopBJetTagger::getEventWeight(){
  if(m_tagTool->tagged(IEventTagTool::IS_ATLFAST) == false && m_tagTool->tagged(IEventTagTool::IS_MC) == true){
    m_eventWeight = m_eventTool->getEventWeight();
  }else{
    m_eventWeight = 1.0;
  }
}

