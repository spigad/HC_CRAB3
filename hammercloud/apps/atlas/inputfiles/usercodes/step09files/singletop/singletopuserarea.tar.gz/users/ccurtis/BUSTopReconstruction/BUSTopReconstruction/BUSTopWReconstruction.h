#ifndef BUSTOP_W_RECONSTRUCTION_H
#define BUSTOP_W_RECONSTRUCTION_H

#include "GaudiKernel/Algorithm.h"

#include "CLHEP/Units/SystemOfUnits.h"

#include "StoreGate/StoreGateSvc.h"

#include "GaudiKernel/ToolHandle.h"

#include "BUSTopTools/IEventTagTool.h"

#include <stdint.h>
#include <string>

class ITHistSvc;
class TH1F;
class TH2F;

class IAnalysisTools;

namespace Analysis {
  class MuonContainer;
}

class ElectronContainer;
class NeutrinoContainer;
class CompositeParticleContainer;

class IBUSTopHistogrammer;
class INuSolutionTool;
class IEventTool;

class BUSTopWReconstruction : public Algorithm {

 public:

   BUSTopWReconstruction(const std::string& name, ISvcLocator* pSvcLocator);
   ~BUSTopWReconstruction();

   StatusCode initialize();
   StatusCode finalize();
   StatusCode execute();
  
 private:
   StoreGateSvc* m_storeGate;
   ITHistSvc*    m_histSvc;
   IBUSTopHistogrammer *m_histogrammer;
   INuSolutionTool *m_nuSolTool;
   IEventTool *m_eventTool;
   IEventTagTool *m_tagTool;

   std::string m_inputNeutrinosName;
   std::string m_inputElectronsName;
   std::string m_inputMuonsName;

   std::string m_outputWName;

   double m_eventWeight;
   bool m_truthAvailable;
   BUSTopTags m_filterTags;

   virtual void registerHistograms();

   virtual void getEventWeight();
   virtual void getStoregateContainers();
   virtual void createTemporaryContainers();
   virtual void destroyTemporaryContainers();

   virtual void registerContainers();
   virtual void registerContainer(CompositeParticleContainer* c, std::string name);

   template <class LEPTON_COLL> void reconstructW(const LEPTON_COLL* lc);

   const ElectronContainer* c_electrons;
   const Analysis::MuonContainer* c_muons;
   const NeutrinoContainer* c_neutrinos;

   CompositeParticleContainer* c_w;

   TH1F* h_recon;
   TH1F* h_size;
};

#endif // BUSTOP_W_RECONSTRUCTION_H


