#ifndef IEVENT_TAG_TOOL_H
#define IEVENT_TAG_TOOL_H

#include <vector>
#include "GaudiKernel/AlgTool.h"
#include "CLIDSvc/CLASS_DEF.h"

static const InterfaceID IID_IEventTagTool("IEventTagTool", 1, 0);

typedef std::vector<int> BUSTopTags;

CLASS_DEF( std::vector<int> , 22592129 , 1 )

class IEventTagTool: virtual public IAlgTool{
   public:
     static const InterfaceID& interfaceID();

     enum BUSTopTag{
       EVENT = 1,
       EVENT_ELECTRON = 2,
       EVENT_MUON = 3,

       ELECTRON_TRUTH = 4,
       MUON_TRUTH = 5,
       TAU_TRUTH = 6,

       TRIGGERED = 7,
       TRIGGERED_ELECTRON = 8,
       TRIGGERED_MUON = 9,

       PRESELECTION = 10,
       ELECTRON_PRESELECTION = 11,
       MUON_PRESELECTION = 12,

       CSCSELECTION = 13,
       ELECTRON_CSCSELECTION = 14,
       MUON_CSCSELECTION = 15,

       NUSELECTION = 16,
       B1SELECTION = 17,
       LJSELECTION = 18,
       LEPTON_SELECTION = 19,
       ELECTRON_SELECTION = 20,
       MUON_SELECTION = 21,

       IS_ATLFAST = 22,
       IS_MC = 23
     };

     virtual void initialiseTags() = 0;
     virtual void tag(int t) = 0;
     virtual bool tagged(int t) = 0;
     virtual bool anyTagged(BUSTopTags& t) = 0;
     virtual bool allTagged(BUSTopTags& t) = 0;
     virtual int numberOfTags() = 0;
     virtual void printTags() = 0;
};

inline const InterfaceID& IEventTagTool::interfaceID(){
   return IID_IEventTagTool;
 }

#endif
