#ifndef TRUTH_HISTOGRAMS_H
#define TRUTH_HISTOGRAMS_H

#include "GaudiKernel/AlgTool.h"
#include "GaudiKernel/MsgStream.h"
#include "GaudiKernel/AlgFactory.h"
#include "StoreGate/StoreGateSvc.h"
#include "StoreGate/DataHandle.h"
#include "AIDA/IHistogram1D.h"
#include "AIDA/IHistogram2D.h"
#include "GaudiKernel/ITHistSvc.h"
#include "EventKernel/PdtPdg.h"

#include "BUSTopTools/KinematicHistograms.h"

class IBUSTopHistogrammer;
class TH1F;
class TH2F;
class TruthParticle;
class TruthParticleContainer;

class TruthHistograms: public KinematicHistograms{
   public:
     TruthHistograms(IBUSTopHistogrammer* parent, std::string algName, std::string dirName, std::string hname);
     virtual ~TruthHistograms(){};

     TH1F** weight;				//[0] = combined, [1] = pos, [2] = neg
     TH1F** status;				//[0] = combined, [1] = pos, [2] = neg
     TH1F** mass;				//[0] = combined, [1] = pos, [2] = neg

     void plotContainer(const TruthParticleContainer* c, double w);
     void plot(TruthParticle* particle, double w);
};

#endif

