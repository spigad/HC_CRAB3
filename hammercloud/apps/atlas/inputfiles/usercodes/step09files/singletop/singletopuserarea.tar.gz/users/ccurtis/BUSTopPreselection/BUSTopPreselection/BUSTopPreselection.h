#ifndef BUSTOP_PRESELECTION_H
#define BUSTOP_PRESELECTION_H

#include "GaudiKernel/Algorithm.h"

#include "CLHEP/Units/SystemOfUnits.h"

#include "StoreGate/StoreGateSvc.h"

#include "GaudiKernel/ToolHandle.h"

#include "muonEvent/MuonContainer.h"

#include <stdint.h>
#include <string>

class ITHistSvc;
class TH1F;
class TH1I;

class IAnalysisTools;
class ElectronContainer;
class MissingET;
class JetCollection;

class IBUSTopHistogrammer;
class IEventTool;
class IEventTagTool;

class ElectronContainer;
class ParticleJetContainer;
class MissingET;

namespace Analysis{
   class MuonContainer;
}

class BUSTopPreselection : public Algorithm {

 public:

   BUSTopPreselection(const std::string& name, ISvcLocator* pSvcLocator);
   ~BUSTopPreselection();

   StatusCode initialize();
   StatusCode finalize();
   StatusCode execute();

 private:

   StoreGateSvc* m_storeGate;
   ITHistSvc *m_thistSvc;
   IBUSTopHistogrammer* m_histogrammer;
   IEventTool *m_eventTool;
   IEventTagTool *m_tagTool;

   std::string m_preselectionResultName;

   std::string m_electronContainerName;

   std::string m_bJetContainerName;
   std::string m_lightJetContainerName;

   std::string m_muonContainerName;
   std::string m_metContainerName;

   std::string m_electronOutputContainerName;
   std::string m_muonOutputContainerName;
   std::string m_bjetOutputContainerName;
   std::string m_ljetOutputContainerName;
   std::string m_metOutputContainerName;

   bool m_truthAvailable;
   bool m_quitOnFail;

   int m_filterID;

   double m_eventWeight;

   bool m_metPassed;
   bool m_lightJetPassed;
   bool m_bJetPassed;
   bool m_elecPassed;
   bool m_muonPassed;
   bool m_leptonPassed;

   const ElectronContainer* elecTES;
   const Analysis::MuonContainer* muonTES;
   const MissingET* metTES;
   const JetCollection* bjetTES;
   const JetCollection* ljetTES;

   virtual void registerHistograms();
   virtual void formatResultsHistogram(TH1F* h);

   virtual void getEventWeight();   
   virtual void getStoregateContainers();
   virtual void createTemporaryContainers();
   virtual void destroyTemporaryContainers();

   virtual void resetFlags();

   virtual int preselectMET();
   virtual int preselectJets();
   virtual int preselectElectrons();
   virtual int preselectMuons();

   virtual void registerPreselected();

   virtual void tagEvent();

   TH1F* h_met_result;
   TH1F* h_jet_result;
   TH1F* h_elec_result;
   TH1F* h_muon_result;
   TH1F* h_full_result_emj;
   TH1F* h_full_result_mmj;
   TH1F* h_full_result_lmj;
   TH1F* h_passed;

   enum MET_RESULT{ 	MET_FAILED_TRIGGER = 1, 
		    	MET_FAILED = 2,
		    	MET_PASSED = 3};

   enum JET_RESULT{	JET_FAILED_TRIGGER = 1,
                        JET_FAILED_MIN = 2,
			JET_FAILED_MAX = 3,
			JET_PASSED = 4};

   enum LEP_RESULT{	LEP_FAILED_TRIGGER = 1,
                        LEP_FAILED_N = 2,
			LEP_FAILED_PE = 3,
			LEP_FAILED_ISO = 4,
			LEP_FAILED_CRACK = 5,
			LEP_FAILED_SE = 6,
			LEP_FAILED_MUON = 7,
			LEP_PASSED = 8 };
};

#endif // BUSTOP_PRESELECTION_H



