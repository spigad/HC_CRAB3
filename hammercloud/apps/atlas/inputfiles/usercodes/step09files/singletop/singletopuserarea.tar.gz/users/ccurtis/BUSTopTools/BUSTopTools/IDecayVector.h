#ifndef IDECAY_VECTOR_H
#define IDECAY_VECTOR_H

#include <vector>
#include "EventKernel/PdtPdg.h"

class TruthParticle;
class TruthParticleContainer;

static const InterfaceID IID_IDecayVector("IDecayVector", 1, 0);

class IDecayVector: virtual public IAlgTool{
   public:
     static const InterfaceID& interfaceID();

     virtual TruthParticleContainer* getTruthVector() = 0;
     virtual TruthParticleContainer* filter(PDG::pidType id, bool matchSign = false) = 0;
     virtual TruthParticleContainer* filterFailed(const TruthParticleContainer* mcTES, PDG::pidType id, bool matchSign = false) = 0;
     virtual void clear() = 0;
     virtual void fill(const TruthParticleContainer* mcTES, PDG::pidType pid, bool siblings, bool sign, int maxDepth = -1) = 0;
     virtual void fill(const TruthParticleContainer* mcTES, PDG::pidType pid, bool siblings = true) = 0;
     virtual void fill(const TruthParticle *p, bool siblings, int maxDepth = -1) = 0;
};

inline const InterfaceID& IDecayVector::interfaceID(){
   return IID_IDecayVector;
 }

#endif
