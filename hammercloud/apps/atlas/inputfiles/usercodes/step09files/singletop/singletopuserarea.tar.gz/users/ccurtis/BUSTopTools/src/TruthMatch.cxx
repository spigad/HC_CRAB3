#include "GaudiKernel/MsgStream.h"
#include "BUSTopTools/TruthMatch.h"

TruthMatch::TruthMatch(const std::string& t, const std::string & n, const IInterface* p): ITruthMatch(t, n, p){
  declareInterface<TruthMatch>(this);
}

StatusCode TruthMatch::initialize(){
  MsgStream m_log(msgSvc(), name());
  m_log << "Initializing TruthMatch Tool" << endreq;
  return StatusCode::SUCCESS;
}
