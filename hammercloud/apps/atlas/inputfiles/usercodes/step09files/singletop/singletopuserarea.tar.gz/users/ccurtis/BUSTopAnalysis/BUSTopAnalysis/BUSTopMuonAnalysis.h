#ifndef BUSTOP_MUON_ANALYSIS_H
#define BUSTOP_MUON_ANALYSIS_H

#include "GaudiKernel/Algorithm.h"

#include "CLHEP/Units/SystemOfUnits.h"

#include "StoreGate/StoreGateSvc.h"

#include "GaudiKernel/ToolHandle.h"
#include "TrigDecision/TrigDecisionTool.h"

#include <stdint.h>
#include <string>

namespace Analysis{
  class MuonContainer;
  class Muon;
}

class JetCollection;
class TruthParticleContainer;
class ElectronContainer;
class IAnalysisTools;
class IDecayVector;
class ITruthMatch;
class IEventTool;
class IEventTagTool;
class IBUSTopHistogrammer;
class MuonHistograms;
class ElectronHistograms;
class ResolutionHistograms;
class TH1F;

class BUSTopMuonAnalysis : public Algorithm {

 public:

   BUSTopMuonAnalysis(const std::string& name, ISvcLocator* pSvcLocator);
   ~BUSTopMuonAnalysis();

   StatusCode initialize();
   StatusCode finalize();
   StatusCode execute();

 private:

   StoreGateSvc* m_storeGate;
   ITHistSvc *m_thistSvc;
   IAnalysisTools *m_analysisTools;
   IDecayVector *m_truthVector;
   ITruthMatch *m_truthMatchTool;
   IEventTool *m_eventTool;
   IEventTagTool *m_tagTool;
   IBUSTopHistogrammer* m_histogrammer;
   ToolHandle<TrigDec::TrigDecisionTool> m_trigDec;

   std::string m_inputMuonContainerName;
   std::string m_selectedMuonContainerName;

   std::string m_preselectedMuonContainerName;
   std::string m_preselectedElecContainerName;
   std::string m_preselectedLJetContainerName;
   std::string m_preselectedBJetContainerName;

   bool m_truthAvailable;
   double m_truthMatchDeltaR;
   double m_eventWeight;
   bool m_doTrigger;

   MuonHistograms* h_full_muon;

   MuonHistograms* h_triggered_muprim;
   MuonHistograms* h_selected_mu;

   MuonHistograms* h_mupre_mufull;
   MuonHistograms* h_mupre_muprim;
   MuonHistograms* h_mupre_musec;
   ElectronHistograms* h_mupre_esec;

   MuonHistograms* h_matched_preselected_muon;
   ResolutionHistograms* h_matched_preselected_muon_res;

   TH1F* h_trigger_pt30;
   TH1F* h_matched_preselected_muon_index;
   TH1F* h_matched_selected_muon_index;
   TH1F* h_preselected_mJet_deltaR;

   const Analysis::MuonContainer* muonTES;
   const Analysis::MuonContainer* c_selectedMuons;
   const Analysis::MuonContainer* c_preselected;  
   const ElectronContainer* c_preselected_elec;  

   const JetCollection* c_preselected_ljets;  
   const JetCollection* c_preselected_bjets;  

   const TruthParticleContainer* c_truthMuons;

   virtual void registerHistograms();

   virtual void getEventWeight();
   virtual void getStoregateContainers();
   virtual void clearParticleContainers();

   virtual void plotMuons();

   virtual void mJetIsolation();
   virtual void preselectedMJetIsolation();
   virtual void triggerAnalysis();
   virtual void truthAnalysis();
   virtual void selectionAnalysis();
};

#endif // BUSTOP_MUON_ANALYSIS_H



