#ifndef BUSTOP_JET_ANALYSIS_H
#define BUSTOP_JET_ANALYSIS_H

#include "GaudiKernel/Algorithm.h"

#include "CLHEP/Units/SystemOfUnits.h"

#include "StoreGate/StoreGateSvc.h"

#include "GaudiKernel/ToolHandle.h"

#include "DataModel/AssociationLink.h"
#include "DataModel/AssociationLinkCollection.h"

#include <stdint.h>
#include <string>
#include <vector>
#include <utility>

class TruthParticleContainer;
class TruthParticle;
class JetCollection;
class Jet;
class ElectronContainer;
class JetHistograms;
class ResolutionHistograms;
class IBUSTopHistogrammer;
class ITruthMatch;
class IEventTool;
class IEventTagTool;

class TH1F;
class TH2F;
class TTree;

namespace Analysis{
  class MuonContainer;
}

class BUSTopJetAnalysis : public Algorithm {

 public:

   BUSTopJetAnalysis(const std::string& name, ISvcLocator* pSvcLocator);
   ~BUSTopJetAnalysis();

   StatusCode initialize();
   StatusCode finalize();
   StatusCode execute();

 private:

   StoreGateSvc* m_storeGate;
   ITHistSvc *m_thistSvc;
   IBUSTopHistogrammer* m_histogrammer;
   ITruthMatch* m_truthMatchTool;
   IEventTool* m_eventTool;
   IEventTagTool* m_tagTool;
   
   std::string m_jetInputContainerName;
   std::string m_overlapJetContainerName;
   std::string m_overlapEJetContainerName;

   std::string m_electronContainerName;
   std::string m_muonContainerName;
   std::string m_bJetContainerName;
   std::string m_lightJetContainerName;

   std::string m_preselectedElectronContainerName;
   std::string m_preselectedMuonContainerName;
   std::string m_preselectedBJetContainerName;
   std::string m_preselectedLightJetContainerName;

   std::string m_b1SelectedBJetContainerName;
   std::string m_ljSelectedLJetContainerName;

   std::string m_cscSelectedElectronContainerName;
   std::string m_cscSelectedMuonContainerName;
   std::string m_cscSelectedBJetContainerName;
   std::string m_cscSelectedLightJetContainerName;

   bool m_plotWeights;
   std::string m_jetWeightTagger;

   bool m_truthAvailable;
   double m_truthMatchDeltaR;
   double m_eventWeight;

   double m_overlapJetH;

   unsigned int m_truthBCount;
   unsigned int m_taggedBCount;
   unsigned int m_preselectedBCount;
   unsigned int m_cscSelectedBCount;
   
   virtual void registerHistograms();
   virtual void registerTruthInfoHistogram(TH1F*& h, std::string a, std::string n);

   virtual void registerTTrees();
   virtual void registerB1TTree(TTree* &t, std::string n, float vars[9]);

   virtual void getEventWeight();  
   virtual void getParticleContainers();
   virtual void createTemporaryContainers();
   virtual void fillTrees();
   virtual void clearParticleContainers();

   virtual void plotJets();
   virtual void plotSelectedCentrality();
   virtual double getFlavourTagWeight(const Jet* j);

   virtual void plotTruthInfo(const JetCollection* j, TH1F* h);
   virtual void plotTruthInfo(const Jet* j, TH1F* h);
   virtual std::string getTruthLabel(const Jet* j);

   virtual void plotTruthMatch(const TruthParticleContainer* t, const JetCollection* j, JetHistograms* h, TH1F* h_tag);

   virtual void truthAnalysis();
   virtual void weightCutAnalysis();
   virtual void b1ReconAnalysis();
   virtual void b1ReconAnalysis(const JetCollection* bj, const JetCollection* lj, int index);
   virtual void b12ReconAnalysis(const JetCollection* bj, const JetCollection* lj, int index);
   
   virtual void bjetAnalysis();
   virtual void bjetAnalysis(const JetCollection* jc, int histIndex);

   virtual void lightJetAnalysis();
   virtual void lightJetAnalysis(const JetCollection* jc, int histIndex);

   virtual void overlapAnalysis();
   virtual void overlapAnalysis(const TruthParticleContainer* t, TH1F* acc, TH1F* accWeight, TH1F* rej, TH1F* effWeight, ResolutionHistograms* rh);
   virtual void overlapAnalysis(const TruthParticleContainer* t, TH1F* h);

   virtual void taggingAnalysis();
   virtual void taggingAnalysis(const TruthParticleContainer* t, const JetCollection* c_acc, const JetCollection* c_rej, TH1F* h_acc, TH1F* h_rej);

   virtual void selectionAnalysis();
   virtual void selectionAnalysis(const TruthParticleContainer* t, const JetCollection* jetTES, int tag, TH1F* h);

   const JetCollection* jetTES;
   const JetCollection* c_overlapJets;
   const JetCollection* c_overlapEJets;

   const JetCollection* c_bjets;
   const JetCollection* c_ljets;

   const JetCollection* c_preselectedBJets;
   const JetCollection* c_preselectedLJets;

   const JetCollection* c_cscSelectedBJets;
   const JetCollection* c_cscSelectedLJets;

   const JetCollection* c_b1SelectedBJets;
   const JetCollection* c_ljSelectedLJets;

   const ElectronContainer* c_electrons;
   const ElectronContainer* c_preselectedElectrons;
   const ElectronContainer* c_cscSelectedElectrons;

   const Analysis::MuonContainer* c_muons;
   const Analysis::MuonContainer* c_preselectedMuons;
   const Analysis::MuonContainer* c_cscSelectedMuons;

   const TruthParticleContainer* c_truthB1;
   const TruthParticleContainer* c_truthB3;
   const TruthParticleContainer* c_truthLj;
   const TruthParticleContainer* c_truthElectron;
   const TruthParticleContainer* c_truthMuon;
   const TruthParticleContainer* c_truthTau;
   const TruthParticleContainer* c_truthW1;

   JetHistograms* h_full_jet;
   JetHistograms* h_overlap_jet;

   JetHistograms* h_b1_truth_match_full;
   JetHistograms* h_b3_truth_match_full;

   JetHistograms* h_bj_truth_match;
   JetHistograms* h_lj_truth_match;

   ResolutionHistograms* h_lj_truth_match_res;
   ResolutionHistograms* h_bj_truth_match_res;

   TH2F* h_lj_truth_match_res_2;
   TH2F* h_bj_truth_match_res_2;

   JetHistograms* h_pre_filter_bjets;
   JetHistograms* h_pre_filter_ljets;

   JetHistograms* h_tagged_b_jets;
   JetHistograms* h_tagged_l_jets;
   JetHistograms* h_tagged_primary_l_jets;

   JetHistograms* h_preselected_b_jets;
   JetHistograms* h_preselected_l_jets;
   JetHistograms* h_preselected_primary_l_jets;

   JetHistograms* h_cscSelected_b_jets;
   JetHistograms* h_cscSelected_l_jets;
   JetHistograms* h_cscSelected_primary_l_jets;

   JetHistograms* h_selected_b_jets;
   JetHistograms* h_selected_b_30pt_jets;
   JetHistograms* h_selected_l_jets;

   ResolutionHistograms* h_overlap_b1_ejet_truth_res;
   ResolutionHistograms* h_overlap_b3_ejet_truth_res;

   TH1F* h_b1_truth_match_full_info;
   TH1F* h_b3_truth_match_full_info;

   TH1F* h_overlap_info;
   TH1F* h_overlap_b1_bjet_truth_info;
   TH1F* h_overlap_b1_bjet_truth_weight;
   TH1F* h_matched_b1_tag_eff_weight;
   TH1F* h_overlap_b1_ejet_truth_info;
   TH1F* h_overlap_b3_bjet_truth_info;
   TH1F* h_overlap_b3_bjet_truth_weight;
   TH1F* h_matched_b3_tag_eff_weight;
   TH1F* h_overlap_b3_ejet_truth_info;


   TH1F* h_tagged_lj_info;
   TH1F* h_tagged_bj_info;

   TH1F* h_tagged_b1_truth_info;
   TH1F* h_tagged_b3_truth_info;

   TH1F* h_ntagged_b1_truth_info;
   TH1F* h_ntagged_b3_truth_info;

   TH1F* h_preselected_b_truth_info;
   TH1F* h_preselected_lj_truth_info;

   TH1F* h_b_jet_efficiency;

   TH1F* h_selected_centrality;

   TH1F* h_1jet_recon[4];
   TH1F* h_2jet_recon[4];

   TH1F* h_bjet_recon[4];
   TH1F* h_bjet_recon_ptIndex[4];
   TH1F* h_bjet_recon_etaIndex[4];
   TH1F* h_bjet_recon_eIndex[4];
   TH1F* h_bjet_recon_etIndex[4];
   TH1F* h_bjet_recon_weightIndex[4];

   TH1F* h_ljet_recon[4];
   TH1F* h_ljet_recon_ptIndex[4];
   TH1F* h_ljet_recon_etaIndex[4];
   TH1F* h_ljet_recon_eIndex[4];
   TH1F* h_ljet_recon_etIndex[4];

   TH1F* h_trig_overlap_jet_n;
   TH1F* h_trig_overlap_b1_match;
   TH1F* h_trig_overlap_lj_match;

   TH1F* h_matched_selected_bjet_index;
   TH1F* h_matched_selected_ljet_index;

   TTree* t_b1[2];

   float t_b1_vars[2][9];

};

#endif // BUSTOP_JET_ANALYSIS_H



