#include "BUSTopTools/MuonHistograms.h"
#include "BUSTopTools/BUSTopHistogrammer.h"

#include "StoreGate/StoreGateSvc.h"
#include "StoreGate/DataHandle.h"

#include "McParticleEvent/TruthParticleContainer.h"
#include "muonEvent/MuonContainer.h"
#include "muonEvent/Muon.h"
#include "egammaEvent/EMShower.h"
#include "EventKernel/PdtPdg.h"
#include "AnalysisUtils/IParticleFilter.h"
#include "AnalysisUtils/AnalysisMisc.h"

#include <iostream>
#include <string>
#include <queue>

#include "TH1.h"
#include "TH2.h"

MuonHistograms::MuonHistograms(IBUSTopHistogrammer* parent, std::string algName, std::string dirName, std::string hN):KinematicHistograms(parent, algName, dirName, hN){
  etcone20 = new TH1F*[3];

  std::stringstream fname, hname, title;

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "_etcone20";
  fname << "/AANT/"<< algName <<"/" << dirName << "/" << hname.str();
  title << "Etcone20";
  parent->registerHistogram(etcone20, fname.str(), hname.str(), title.str(), "Etcone20 [GeV]", 100, 0, 50);
}

void MuonHistograms::plotContainer(const Analysis::MuonContainer* c, double w, int maxCount){

  Analysis::MuonContainer::const_iterator iter = c->begin();
  Analysis::MuonContainer::const_iterator iterEnd = c->end();

  int totCount = 0;
  if(c->size() > 0){
    if(maxCount != -1){
      while(iter < iterEnd && totCount < maxCount){
        plot(*iter, w);
        iter++;
        totCount++;
      }
    }else{
      while(iter < iterEnd){
        plot(*iter, w);
        iter++;
        totCount++;
      }
    }
  }

  n[0]->Fill(totCount, w);
}


void MuonHistograms::plot(const Analysis::Muon* particle, double w){
  double iso = particle->parameter(MuonParameters::etcone20);

  phi[0]->Fill(particle->phi(), w);
  eta[0]->Fill(particle->eta(), w);
  p[0]->Fill(particle->p()/GeV, w);
  px[0]->Fill(particle->px()/GeV, w);
  py[0]->Fill(particle->py()/GeV, w);
  pz[0]->Fill(particle->pz()/GeV, w);
  pt[0]->Fill(particle->pt()/GeV, w);
  ipt[0]->Fill(GeV/particle->pt(), w);
  costheta[0]->Fill(particle->cosTh(), w);
  etcone20[0]->Fill(iso/GeV, w);
  ptop[0]->Fill(fabs(particle->pt()/particle->p()), w);
  etoe[0]->Fill(fabs(particle->pt()/particle->p()), w);
  e[0]->Fill(particle->e()/GeV, w);

  int index = 1;
  if(particle->charge() < 0){
    index = 2;
  }

  phi[index]->Fill(particle->phi(), w);
  eta[index]->Fill(particle->eta(), w);
  p[index]->Fill(particle->p()/GeV, w);
  px[index]->Fill(particle->px()/GeV, w);
  py[index]->Fill(particle->py()/GeV, w);
  pz[index]->Fill(particle->pz()/GeV, w);
  pt[index]->Fill(particle->pt()/GeV, w);
  ipt[index]->Fill(GeV/particle->pt(), w);
  costheta[index]->Fill(particle->cosTh(), w);
  etcone20[index]->Fill(iso/GeV, w);
  ptop[index]->Fill(fabs(particle->pt()/particle->p()), w);
  etoe[index]->Fill(fabs(particle->pt()/particle->p()), w);
  e[index]->Fill(particle->e()/GeV, w);
}

