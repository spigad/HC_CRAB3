#ifndef BUSTOP_W_ANALYSIS_H
#define BUSTOP_W_ANALYSIS_H

#include "GaudiKernel/Algorithm.h"

#include "CLHEP/Units/SystemOfUnits.h"

#include "StoreGate/StoreGateSvc.h"

#include "GaudiKernel/ToolHandle.h"

#include <stdint.h>
#include <string>

class ITHistSvc;
class TH1F;
class TH2F;

class IAnalysisTools;

class CompositeParticleContainer;
class JetCollection;
class IBUSTopHistogrammer;
class INuSolutionTool;
class IEventTool;
class IEventTagTool;

class KinematicHistograms;
class ResolutionHistograms;
class METResolutionHistograms;

class BUSTopWAnalysis : public Algorithm {

 public:

   BUSTopWAnalysis(const std::string& name, ISvcLocator* pSvcLocator);
   ~BUSTopWAnalysis();

   StatusCode initialize();
   StatusCode finalize();
   StatusCode execute();
  
 private:
   StoreGateSvc* m_storeGate;
   ITHistSvc*    m_thistSvc;
   IBUSTopHistogrammer *m_histogrammer;
   INuSolutionTool *m_nuSolTool;
   IEventTool *m_eventTool;
   IEventTagTool *m_tagTool;

   std::string m_fullWName;
   std::string m_preselectedWName;
   std::string m_cscSelectedWName;
   std::string m_selectedWName;
   std::string m_selectedBJetName;

   double m_wWidth;
   double m_metSigma;

   double m_eventWeight;
   bool m_truthAvailable;

   virtual void registerHistograms();

   virtual void getEventWeight();
   virtual void getStoregateContainers();
   virtual void getTruthContainers();

   virtual void plotW(const CompositeParticleContainer* wc, int index);
   virtual void plotSelectedCentrality();

   const CompositeParticleContainer* c_fullW;
   const CompositeParticleContainer* c_preselectedW;
   const CompositeParticleContainer* c_cscSelectedW;
   const CompositeParticleContainer* c_selectedW;

   const JetCollection* c_selectedBJets;

   KinematicHistograms* h_wKinematics[3];
   TH1F* h_wMass[3];

   TH1F* h_selected_centrality;
};

#endif // BUSTOP_W_ANALYSIS_H


