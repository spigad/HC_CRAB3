#ifndef BUSTOP_HISTOGRAM_DUMP_H
#define BUSTOP_HISTOGRAM_DUMP_H

#include "GaudiKernel/Algorithm.h"

#include "CLHEP/Units/SystemOfUnits.h"

#include "StoreGate/StoreGateSvc.h"

#include "GaudiKernel/ToolHandle.h"

#include <stdint.h>
#include <string>

namespace Analysis{
  class MuonContainer;
}

class JetCollection;
class ElectronContainer;
class MissingET;
class IAnalysisTools;
class IDecayVector;
class ITruthMatch;
class IEventTool;
class IEventTagTool;
class IBUSTopHistogrammer;
class MuonHistograms;
class JetHistograms;
class ElectronHistograms;
class METHistograms;
class TruthParticleContainer;

class IParticleFilter;

class BUSTopHistogramDump : public Algorithm {

 public:

   BUSTopHistogramDump(const std::string& name, ISvcLocator* pSvcLocator);
   ~BUSTopHistogramDump();

   StatusCode initialize();
   StatusCode finalize();
   StatusCode execute();

 private:

   StoreGateSvc* m_storeGate;
   ITHistSvc *m_thistSvc;
   IAnalysisTools *m_analysisTools;
   IEventTool *m_eventTool;
   IEventTagTool *m_tagTool;
   IDecayVector *m_truthVector;
   IBUSTopHistogrammer* m_histogrammer;

   std::string m_inputMuonContainerName;
   std::string m_inputElectronContainerName;
   std::string m_inputMetContainerName;
   std::string m_inputBJetContainerName;
   std::string m_inputLJetContainerName;

   std::string m_jetWeightTagger;

   double m_eventWeight;
   bool m_isAtlfast;
   bool m_truthAvailable;
   bool m_dumpTruth;
   bool m_doOverlapRemoval;

   double m_elecPtMin;
   double m_elecEtaMin;
   double m_elecEtaMax;
   bool m_inclusiveElectronEta;

   double m_muonPtMin;
   double m_muonEtaMin;
   double m_muonEtaMax;
   bool m_inclusiveMuonEta;

   double m_bjetPtMin;
   double m_bjetEtaMin;
   double m_bjetEtaMax;
   bool m_inclusiveBJetEta;

   double m_ljetPtMin;
   double m_ljetEtaMin;
   double m_ljetEtaMax;
   bool m_inclusiveJetEta;

   MuonHistograms* h_full_muon;
   ElectronHistograms* h_full_elec;
   METHistograms* h_full_met;
   JetHistograms* h_full_bjet;
   JetHistograms* h_full_ljet;

   const TruthParticleContainer* mcTES;
   const Analysis::MuonContainer* muonTES;
   const ElectronContainer* elecTES;
   const MissingET* metTES;
   const JetCollection* bjetTES;  
   const JetCollection* ljetTES;  

   virtual void registerHistograms();

   virtual void getEventWeight();
   virtual void getStoregateContainers();
   virtual void clearParticleContainers();

   virtual void plotMuons();
   virtual void plotElectrons();
   virtual void plotJets(const JetCollection* jc, JetHistograms* h, IParticleFilter& filter, IParticleFilter& etaFilter, bool etaResult);

   virtual void dumpTruth();

   virtual JetCollection* electronOverlapRemoval(const JetCollection*);

};

#endif // BUSTOP_HISTOGRAM_DUMP_H



