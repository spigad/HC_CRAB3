#include "GaudiKernel/DeclareFactoryEntries.h"

#include "BUSTopPreselection/BUSTopTruth.h"
#include "BUSTopPreselection/BUSTopTruthFilter.h"
#include "BUSTopPreselection/BUSTopMuonFilter.h"
#include "BUSTopPreselection/BUSTopElectronFilter.h"
#include "BUSTopPreselection/BUSTopOverlap.h"
#include "BUSTopPreselection/BUSTopJES.h"
#include "BUSTopPreselection/BUSTopBJetTagger.h"
#include "BUSTopPreselection/BUSTopTriggerDecision.h"
#include "BUSTopPreselection/BUSTopPreselection.h"

DECLARE_ALGORITHM_FACTORY( BUSTopTruth )
DECLARE_ALGORITHM_FACTORY( BUSTopTruthFilter )
DECLARE_ALGORITHM_FACTORY( BUSTopMuonFilter )
DECLARE_ALGORITHM_FACTORY( BUSTopElectronFilter )
DECLARE_ALGORITHM_FACTORY( BUSTopOverlap )
DECLARE_ALGORITHM_FACTORY( BUSTopJES )
DECLARE_ALGORITHM_FACTORY( BUSTopBJetTagger )
DECLARE_ALGORITHM_FACTORY( BUSTopTriggerDecision )
DECLARE_ALGORITHM_FACTORY( BUSTopPreselection )

DECLARE_FACTORY_ENTRIES( BUSTopPreselection ) {
  DECLARE_ALGORITHM( BUSTopTruth )
  DECLARE_ALGORITHM( BUSTopTruthFilter )
  DECLARE_ALGORITHM( BUSTopMuonFilter )
  DECLARE_ALGORITHM( BUSTopElectronFilter )
  DECLARE_ALGORITHM( BUSTopOverlap )
  DECLARE_ALGORITHM( BUSTopJES )
  DECLARE_ALGORITHM( BUSTopBJetTagger )
  DECLARE_ALGORITHM( BUSTopTriggerDecision )
  DECLARE_ALGORITHM( BUSTopPreselection )
}
