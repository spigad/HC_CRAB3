#ifndef BUSTOP_Z_SELECTION_H
#define BUSTOP_Z_SELECTION_H

#include "GaudiKernel/Algorithm.h"

#include "CLHEP/Units/SystemOfUnits.h"

#include "StoreGate/StoreGateSvc.h"

#include "GaudiKernel/ToolHandle.h"

#include <stdint.h>
#include <string>

class ITHistSvc;
class TH1F;
class TH2F;

class IAnalysisTools;
class ElectronContainer;
class MissingET;

namespace Analysis{
  class Electron;
}

class IEventTool;
class IEventTagTool;

class BUSTopZSelection : public Algorithm {

 public:

   BUSTopZSelection(const std::string& name, ISvcLocator* pSvcLocator);
   ~BUSTopZSelection();

   StatusCode initialize();
   StatusCode finalize();
   StatusCode execute();
  
 private:
   StoreGateSvc*  m_storeGate;
   ITHistSvc*     m_histSvc;
   IEventTool*    m_eventTool;
   IEventTagTool* m_tagTool;

   std::string m_electronContainerName;
   std::string m_metContainerName;

   double m_eventWeight;

   virtual void registerHistograms();
   virtual void getEventWeight();
   virtual void getStoregateContainers();

   virtual void electronRecon();
   virtual void reconstructZ(TH1F* h_mass, TH1F* h_count, int mask1, int mas2);
   virtual bool reconstructZ(const Analysis::Electron* e1, const Analysis::Electron* e2);

   const MissingET* metTES;
   const ElectronContainer* elecTES;

   TH1F* h_elec_z_mass[3];
   TH1F* h_elec_z_mass_count[3];
};

#endif // BUSTOP_Z_SELECTION_H


