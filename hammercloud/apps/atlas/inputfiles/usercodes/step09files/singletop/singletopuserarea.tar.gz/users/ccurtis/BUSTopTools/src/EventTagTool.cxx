#include "BUSTopTools/EventTagTool.h"

#include "StoreGate/StoreGateSvc.h"
#include "StoreGate/DataHandle.h"

#include "EventInfo/EventInfo.h"
#include "EventInfo/EventType.h"
#include "McParticleEvent/TruthParticleContainer.h"

#include <iostream>
#include <string>
#include <queue>
#include <vector>
#include <algorithm>

EventTagTool::EventTagTool(const std::string& t, const std::string& n, const IInterface* p):AlgTool(t, n, p), m_log(msgSvc(), n){
  declareInterface<IEventTagTool>(this);
}

EventTagTool::~EventTagTool(){
}

StatusCode EventTagTool::initialize(){
  m_log.setLevel(outputLevel());
  
  service("StoreGateSvc", m_storeGate);
  m_log << MSG::DEBUG << "Initialising EventTagTool" << endreq;

  tags = 0;

  return StatusCode::SUCCESS;
}

StatusCode EventTagTool::finalize(){
  return StatusCode::SUCCESS;
}

void EventTagTool::tag(int t){
  m_log.setLevel(outputLevel());
  if(tagged(t) == false){
    tags->push_back(t);
  }
  m_log << MSG::DEBUG << "EventTagTool tag(" << t << ") = " << std::binary_search(tags->begin(), tags->end(), t) << endreq;
}
 
bool EventTagTool::tagged(int t){
  BUSTopTags::const_iterator iter = tags->begin();
  BUSTopTags::const_iterator iterEnd = tags->end();

  while(iter < iterEnd){
    if((*iter) == t){
      return true;
    }
    iter++;
  }
  
  return false;
}

bool EventTagTool::allTagged(BUSTopTags& t){
  BUSTopTags::const_iterator iter = t.begin();
  BUSTopTags::const_iterator iterEnd = t.end();

  while(iter < iterEnd){
    bool result = tagged(*iter);
    if(result == false){
      return false;
    }
    iter++;
  }
  
  return true;
}

bool EventTagTool::anyTagged(BUSTopTags& t){
  BUSTopTags::const_iterator iter = t.begin();
  BUSTopTags::const_iterator iterEnd = t.end();

  while(iter < iterEnd){
    bool result = tagged(*iter);
    if(result == true){
      return true;
    }
    iter++;
  }
  
  return false;
}

int EventTagTool::numberOfTags(){
  return tags->size();
}

void EventTagTool::initialiseTags(){
  m_log.setLevel(outputLevel());
  m_log << MSG::DEBUG << "initialiseTags()" << endreq;
  tags = new BUSTopTags;
  StatusCode sc = m_storeGate->record(tags, "BUSTopTags", true);
}

void EventTagTool::printTags(){
  m_log.setLevel(outputLevel());
  m_log << MSG::DEBUG << "printTags()" << endreq;
  
  for(unsigned int i = 0; i < tags->size(); i++){
    m_log << MSG::DEBUG << "tag = " << tags->at(i) << endreq;
  }
}
