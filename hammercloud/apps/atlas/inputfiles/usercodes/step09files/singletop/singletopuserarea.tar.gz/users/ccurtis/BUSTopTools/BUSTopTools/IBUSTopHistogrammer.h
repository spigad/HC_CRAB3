#ifndef IBUSTOP_HISTOGRAMMER_H
#define IBUSTOP_HISTOGRAMMER_H

#include <string>

class TH1I;
class TH1F;
class TH2F;
class TH3F;

static const InterfaceID IID_IBUSTopHistogrammer("IBUSTopHistogrammer", 1, 0);

class IBUSTopHistogrammer: virtual public IAlgTool{
   public:
     static const InterfaceID& interfaceID();

     virtual void registerHistogram(TH1I*  &h, std::string fname, std::string hname, std::string title, std::string xname, int bins, double l, double u) = 0;
     virtual void registerHistogram(TH1F*  &h, std::string fname, std::string hname, std::string title, std::string xname, int bins, double l, double u) = 0;
     virtual void registerHistogram(TH1I** &h, std::string fname, std::string hname, std::string title, std::string xname, int bins, double l, double u) = 0;
     virtual void registerHistogram(TH1F** &h, std::string fname, std::string hname, std::string title, std::string xname, int bins, double l, double u) = 0;
     virtual void registerHistogram(TH2F** &h, std::string fname, std::string hname, std::string title,
                                               std::string xname, int xbins, double xl, double xu,
                                               std::string yname, int ybins, double yl, double yu) = 0;
     virtual void registerHistogram(TH2F*  &h, std::string fname, std::string hname, std::string title,
                                               std::string xname, int xbins, double xl, double xu,
                                               std::string yname, int ybins, double yl, double yu) = 0;
     virtual void registerHistogram(TH3F** &h, std::string fname, std::string hname, std::string title,
                                               std::string xname, int xbins, double xl, double xu,
                                               std::string yname, int ybins, double yl, double yu,
                                               std::string zname, int zbins, double zl, double zu) = 0;

};

inline const InterfaceID& IBUSTopHistogrammer::interfaceID(){
   return IID_IBUSTopHistogrammer;
 }

#endif
