from BUSTopReconstruction.BUSTopReconstructionConf import BUSTopTReconstruction

###############################################################################
#  Reconstructed W's based on output from Preselection algorithm              #
###############################################################################

BUSTopTRecon_Full = BUSTopTReconstruction( "BUSTopTRecon_Full" )
BUSTopTRecon_Full.OutputLevel = WARNING

BUSTopTRecon_Full.InputBJets       = BUSTopPreselection.InputBJetContainer
BUSTopTRecon_Full.InputWs          = BUSTopWRecon_Full.OutputWName

BUSTopTRecon_Full.OutputTops       = "FullTops"
BUSTopTRecon_Full.TruthAvailable   = DoTruth
BUSTopTRecon_Full.FilterTags       = BUSTopNuRecon_Full.FilterTags
BUSTopTRecon_Full.ApplyMassVeto    = 0
BUSTopTRecon_Full.LowMassVeto      = 0
BUSTopTRecon_Full.HighMassVeto     = 0

###############################################################################
#  Reconstructed W's based on output from Preselection algorithm              #
###############################################################################

BUSTopTRecon_Preselection = BUSTopTReconstruction( "BUSTopTRecon_Preselection" )
BUSTopTRecon_Preselection.OutputLevel = WARNING

BUSTopTRecon_Preselection.InputBJets       = BUSTopPreselection.OutputBJetContainer
BUSTopTRecon_Preselection.InputWs          = BUSTopWRecon_Preselection.OutputWName

BUSTopTRecon_Preselection.OutputTops       = "PreselectedTops"
BUSTopTRecon_Preselection.TruthAvailable   = DoTruth
BUSTopTRecon_Preselection.FilterTags       = BUSTopNuRecon_Preselection.FilterTags
BUSTopTRecon_Preselection.ApplyMassVeto    = 0
BUSTopTRecon_Preselection.LowMassVeto      = 0
BUSTopTRecon_Preselection.HighMassVeto     = 0

###############################################################################
#  Reconstructed W's based on output from CSCSelection algorithm              #
###############################################################################

BUSTopTRecon_CSCSelection = BUSTopTReconstruction( "BUSTopTRecon_CSCSelection" )
BUSTopTRecon_CSCSelection.OutputLevel = WARNING

BUSTopTRecon_CSCSelection.InputBJets       = BUSTopCSCSelection.OutputBJetContainer
BUSTopTRecon_CSCSelection.InputWs          = BUSTopWRecon_CSCSelection.OutputWName

BUSTopTRecon_CSCSelection.OutputTops       = "CSCSelectedTops"
BUSTopTRecon_CSCSelection.TruthAvailable   = DoTruth
BUSTopTRecon_CSCSelection.FilterTags       = BUSTopNuRecon_CSCSelection.FilterTags
BUSTopTRecon_CSCSelection.ApplyMassVeto    = 0
BUSTopTRecon_CSCSelection.LowMassVeto      = 0
BUSTopTRecon_CSCSelection.HighMassVeto     = 0

###############################################################################
#  Reconstructed W's based on output from Selection algorithm                 #
###############################################################################

if DoSelection:
	BUSTopTRecon_Selection = BUSTopTReconstruction( "BUSTopTRecon_Selection" )
	BUSTopTRecon_Selection.OutputLevel = WARNING

	BUSTopTRecon_Selection.InputBJets       = BUSTopSelection.OutputB1JetContainer
	BUSTopTRecon_Selection.InputWs          = BUSTopWRecon_Selection.OutputWName

	BUSTopTRecon_Selection.OutputTops       = "SelectedTops"
	BUSTopTRecon_Selection.TruthAvailable   = DoTruth
	BUSTopTRecon_Selection.FilterTags       = [NUSELECTION, B1SELECTION, LEPTON_SELECTION]
	BUSTopTRecon_Selection.ApplyMassVeto    = 0
	BUSTopTRecon_Selection.LowMassVeto      = 147
	BUSTopTRecon_Selection.HighMassVeto     = 200

###############################################################################
#  Append Algorithms to main Sequencer                                        #
###############################################################################

Sequencer += BUSTopTRecon_Full
Sequencer += BUSTopTRecon_Preselection
Sequencer += BUSTopTRecon_CSCSelection

if DoSelection:
	Sequencer += BUSTopTRecon_Selection
