#ifndef BUSTOP_JES_H
#define BUSTOP_JES_H

#include "GaudiKernel/Algorithm.h"

#include "CLHEP/Units/SystemOfUnits.h"

#include "StoreGate/StoreGateSvc.h"

#include "GaudiKernel/ToolHandle.h"

#include <stdint.h>
#include <string>

class ITHistSvc;
class TH1F;
class TH2F;

class IAnalysisTools;
class JetCollection;
class MissingET;
class IEventTool;
class IEventTagTool;

class BUSTopJES : public Algorithm {

 public:

   BUSTopJES(const std::string& name, ISvcLocator* pSvcLocator);
   ~BUSTopJES();

   StatusCode initialize();
   StatusCode finalize();
   StatusCode execute();
  
 private:
   StoreGateSvc*  m_storeGate;
   ITHistSvc*     m_histSvc;
   IEventTool*    m_eventTool;
   IEventTagTool* m_tagTool;

   std::string m_inputJetContainerName;
   std::string m_outputJetContainerName;

   std::string m_inputMETContainerName;
   std::string m_outputMETContainerName;

   bool m_truthAvailable;
   double m_eventWeight;
   double m_jesScale;

   const JetCollection* jetTES;
   JetCollection* c_scaledJets;
   
   const MissingET* metTES;
   MissingET* c_scaledMET;

   virtual void getEventWeight();
   virtual void registerHistograms();
   virtual void getStoregateContainers();
   virtual void createTemporaryContainers();
   virtual void destroyTemporaryContainers();

   virtual void skewJetEnergies();
   virtual void recalculateMET();

   virtual void registerContainers();
   virtual void registerContainer(JetCollection* j, std::string n);
   virtual void registerContainer(MissingET* m, std::string n);
};

#endif // BUSTOP_JES_H


