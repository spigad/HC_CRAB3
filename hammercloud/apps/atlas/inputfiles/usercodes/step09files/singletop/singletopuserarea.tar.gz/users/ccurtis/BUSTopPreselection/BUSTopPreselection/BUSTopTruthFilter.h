#ifndef BUSTOP_TRUTH_FILTER_H
#define BUSTOP_TRUTH_FILTER_H

#include "GaudiKernel/Algorithm.h"

#include "CLHEP/Units/SystemOfUnits.h"

#include "StoreGate/StoreGateSvc.h"

#include "GaudiKernel/ToolHandle.h"
#include "EventKernel/PdtPdg.h"

#include <stdint.h>
#include <string>
#include <vector>

class ITHistSvc;
class IAnalysisTools;
class TruthParticleContainer;
class IDecayVector;
class IEventTool;
class IEventTagTool;

class BUSTopTruthFilter : public Algorithm {

 public:

   BUSTopTruthFilter(const std::string& name, ISvcLocator* pSvcLocator);
   ~BUSTopTruthFilter();

   StatusCode initialize();
   StatusCode finalize();
   StatusCode execute();
  
 private:
   StoreGateSvc* m_storeGate;
   ITHistSvc*    m_histSvc;
   IDecayVector* m_truthVector;
   IEventTool* m_eventTool;
   IEventTagTool* m_tagTool;

   int m_datasetID;
   double m_eventCount;
   double m_taggedCount;
   double m_eventWeight;

   std::string m_mcContainerName;
   std::vector<int> m_selectChildren1;
   std::vector<int> m_selectChildren2;

   const TruthParticleContainer* mcTES;

   virtual void getEventWeight();
   virtual void getStoregateContainers();

   virtual void registerHistograms();

   virtual bool doFilter(std::vector<int>& v, PDG::pidType pid, bool sign);
   virtual void do5200Filter();
   virtual void do5500Filter();
   virtual void do5501Filter();
   virtual void do5502Filter();

   virtual const TruthParticle* getPreviousParticle(const TruthParticle* c);

   TH1F* h_eventCount;
   TH1F* h_eventTagged;
};

#endif // BUSTOP_TRUTH_FILTER_H


