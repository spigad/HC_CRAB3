#ifndef BUSTOPTRUTH_H
#define BUSTOPTRUTH_H

#include "GaudiKernel/Algorithm.h"
#include "GaudiKernel/ObjectVector.h"
#include "CLHEP/Units/SystemOfUnits.h"
#include "StoreGate/StoreGateSvc.h"
#include "GaudiKernel/ITHistSvc.h"

#include <stdint.h>

#include <string>
#include <vector>

#include "TH1.h"
#include "TH2.h"

class TruthParticleContainer;
class TruthParticle;
class IDecayVector;
class IBUSTopHistogrammer;
class INuSolutionTool;
class TruthHistograms;
class IEventTool;
class IEventTagTool;

class BUSTopTruth : public Algorithm {

 public:

   BUSTopTruth(const std::string& name, ISvcLocator* pSvcLocator);
   ~BUSTopTruth();

   StatusCode initialize();
   StatusCode finalize();
   StatusCode execute();

 private:

   StoreGateSvc* m_storeGate;
   ITHistSvc *m_thistSvc;
   IToolSvc* m_toolSvc;
   IEventTool* m_eventTool;
   IEventTagTool* m_tagTool;

   IDecayVector *m_truthVector;
   IBUSTopHistogrammer* m_histogrammer;
   INuSolutionTool* m_nuSolTool;
   
   std::string m_mcContainerName;
   bool m_printTable;

   double m_eventWeight;

   virtual void registerHistograms();

   virtual void getEventWeight();   
   virtual void getContainers();
   virtual void publishContainers();
   virtual void publishContainer(const TruthParticleContainer* c, std::string name);
   virtual void clearContainers();

   virtual void fillHistograms();
   virtual void tagEvent();

   virtual void printTruthVector();

   const TruthParticleContainer* mcTES;

   TruthParticleContainer* c_top;
   TruthParticleContainer* c_j;
   TruthParticleContainer* c_b;
   TruthParticleContainer* c_b1;
   TruthParticleContainer* c_b3;
   TruthParticleContainer* c_w1;
   TruthParticleContainer* c_lj;
   TruthParticleContainer* c_e;
   TruthParticleContainer* c_enu;
   TruthParticleContainer* c_mu;
   TruthParticleContainer* c_munu;
   TruthParticleContainer* c_tau;
   TruthParticleContainer* c_taunu;

   TruthHistograms* h_top;
   TruthHistograms* h_b1;
   TruthHistograms* h_b3;
   TruthHistograms* h_w1;
   TruthHistograms* h_lj;
   TruthHistograms* h_e;
   TruthHistograms* h_enu;
   TruthHistograms* h_mu;
   TruthHistograms* h_munu;
   TruthHistograms* h_tau;
   TruthHistograms* h_taunu;

   TH1I* h_t_mother;

   TH1I* h_t_mother_child;
   TH1I* h_t_mother_child_n;

};

#endif // BUSTOPTRUTH_H



