#include "BUSTopTools/KinematicHistograms.h"
#include "BUSTopTools/BUSTopHistogrammer.h"

#include "StoreGate/StoreGateSvc.h"
#include "StoreGate/DataHandle.h"

#include "McParticleEvent/TruthParticleContainer.h"
#include "EventKernel/PdtPdg.h"
#include "AnalysisUtils/IParticleFilter.h"
#include "AnalysisUtils/AnalysisMisc.h"

#include <iostream>
#include <string>
#include <queue>

#include "TH1.h"
#include "TH2.h"

KinematicHistograms::KinematicHistograms(IBUSTopHistogrammer* parent, std::string algName, std::string dirName, std::string hN){
  n = new TH1I*[3];
  phi = new TH1F*[3];
  eta = new TH1F*[3];
  p = new TH1F*[3];
  px = new TH1F*[3];
  py = new TH1F*[3];
  pz = new TH1F*[3];
  pt = new TH1F*[3];
  ipt = new TH1F*[3];
  costheta = new TH1F*[3];
  ptop = new TH1F*[3];
  etoe = new TH1F*[3];
  e = new TH1F*[3];

  std::stringstream fname, hname, title;

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "_n";
  fname << "/AANT/"<< algName <<"/" << dirName << "/" << hname.str();
  title << "N";
  parent->registerHistogram(n, fname.str(), hname.str(), title.str(), "N", 30, -0.5, 29.5);

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "_phi";
  fname << "/AANT/"<< algName <<"/" << dirName << "/" << hname.str();
  title << "\\phi";
  parent->registerHistogram(phi, fname.str(), hname.str(), title.str(), "\\phi [rad]", 100, -M_PI, M_PI);

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "_eta";
  fname << "/AANT/"<< algName <<"/" << dirName << "/" << hname.str();
  title << "\\eta";
  parent->registerHistogram(eta, fname.str(), hname.str(), title.str(), "\\eta", 100, -5, 5);

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "_p";
  fname << "/AANT/"<< algName <<"/" << dirName << "/" << hname.str();
  title << "P";
  parent->registerHistogram(p, fname.str(), hname.str(), title.str(), "P [GeV]", 100, 0, 500);

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "_px";
  fname << "/AANT/"<< algName <<"/" << dirName << "/" << hname.str();
  title << "P_{x}";
  parent->registerHistogram(px, fname.str(), hname.str(), title.str(), "P_{x} [GeV]", 300, -300, 300);

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "_py";
  fname << "/AANT/"<< algName <<"/" << dirName << "/" << hname.str();
  title << "P_{y}";
  parent->registerHistogram(py, fname.str(), hname.str(), title.str(), "P_{y} [GeV]", 300, -300, 300);

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "_pz";
  fname << "/AANT/"<< algName <<"/" << dirName << "/" << hname.str();
  title << "P_{z}";
  parent->registerHistogram(pz, fname.str(), hname.str(), title.str(), "P_{z} [GeV]", 500, -500, 500);

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "_pt";
  fname << "/AANT/"<< algName <<"/" << dirName << "/" << hname.str();
  title << "P_{T}";
  parent->registerHistogram(pt, fname.str(), hname.str(), title.str(), "P_{T} [GeV]", 100, 0, 500);

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "_ipt";
  fname << "/AANT/"<< algName <<"/" << dirName << "/" << hname.str();
  title << "1/P_{T}";
  parent->registerHistogram(ipt, fname.str(), hname.str(), title.str(), "1/P_{T} [GeV^{-1}]", 100, 0, 0.5);

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "_costheta";
  fname << "/AANT/"<< algName <<"/" << dirName << "/" << hname.str();
  title << "Cos \\theta";
  parent->registerHistogram(costheta, fname.str(), hname.str(), title.str(), "Cos \\theta", 100, -1.1, 1.1);

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "_ptop";
  fname << "/AANT/"<< algName <<"/" << dirName << "/" << hname.str();
  title << "P_{T}/P";
  parent->registerHistogram(ptop, fname.str(), hname.str(), title.str(), "P_{T}/P", 100, 0.0, 1.0);

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "_etoe";
  fname << "/AANT/"<< algName <<"/" << dirName << "/" << hname.str();
  title << "E_{T}/E";
  parent->registerHistogram(etoe, fname.str(), hname.str(), title.str(), "E_{T}/E", 100, 0.0, 1.0);

  fname.str("");
  hname.str("");
  title.str("");
  hname << hN << "_e";
  fname << "/AANT/"<< algName <<"/" << dirName << "/" << hname.str();
  title << "E";
  parent->registerHistogram(e, fname.str(), hname.str(), title.str(), "E [GeV]", 100, 0, 500);
}

