#include "GaudiKernel/MsgStream.h"
#include "GaudiKernel/AlgFactory.h"
#include "GaudiKernel/IToolSvc.h"
#include "GaudiKernel/ITHistSvc.h"
#include "StoreGate/StoreGateSvc.h"
#include "StoreGate/DataHandle.h"

#include "TH1.h"
#include "TH2.h"

#include "McParticleEvent/TruthParticle.h"
#include "McParticleEvent/TruthParticleContainer.h"
#include "egammaEvent/ElectronContainer.h"
#include "egammaEvent/Electron.h"
#include "muonEvent/MuonContainer.h"
#include "muonEvent/Muon.h"

#include "JetEvent/JetCollection.h"

#include "MissingETEvent/MissingET.h"

#include "AnalysisTools/IAnalysisTools.h"
#include "AnalysisUtils/AnalysisCombination.h"
#include "AnalysisUtils/AnalysisMisc.h"
#include "AnalysisUtils/IParticleFilter.h"

#include "BUSTopTools/IBUSTopHistogrammer.h"
#include "BUSTopTools/MuonHistograms.h"
#include "BUSTopTools/ElectronHistograms.h"
#include "BUSTopTools/ResolutionHistograms.h"
#include "BUSTopTools/DecayVector.h"
#include "BUSTopTools/TruthMatch.h"
#include "BUSTopTools/EventTool.h"
#include "BUSTopTools/EventTagTool.h"

#include "BUSTopAnalysis/BUSTopMuonAnalysis.h"

#include <stdint.h>
#include <algorithm>
#include <math.h>
#include <functional>

BUSTopMuonAnalysis::BUSTopMuonAnalysis(const std::string& name,
  ISvcLocator* pSvcLocator) : Algorithm(name, pSvcLocator), m_trigDec("TrigDec::TrigDecisionTool")
{
  /// switches to control the analysis through job options :: these are the default
  /// to changed in the job options

  declareProperty("InputMuonContainer", m_inputMuonContainerName);
  declareProperty("SelectedMuonContainer", m_selectedMuonContainerName);

  declareProperty("PreselectedMuonContainer", m_preselectedMuonContainerName);
  declareProperty("PreselectedElectronContainer", m_preselectedElecContainerName);
  declareProperty("PreselectedLJetContainer", m_preselectedLJetContainerName);
  declareProperty("PreselectedBJetContainer", m_preselectedBJetContainerName);

  declareProperty("TruthMatchDeltaR", m_truthMatchDeltaR);
  declareProperty("TruthAvailable", m_truthAvailable);
  declareProperty("DoTrigger", m_doTrigger);

  declareProperty("TrigDecisionTool", m_trigDec, "The tool to access TrigDecision");
}


/////////////////////////////////////////////////////////////////////////////////////
/// Destructor - check up memory allocation
/// delete any memory allocation on the heap

BUSTopMuonAnalysis::~BUSTopMuonAnalysis() {
}

////////////////////////////////////////////////////////////////////////////////////
/// Initialize
/// initialize StoreGate
/// get a handle on the analysis tools
/// book histograms

StatusCode BUSTopMuonAnalysis::initialize() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO
       << "Initializing BUSTopMuonAnalysis"
       << endreq;

  StatusCode sc;
  
  sc = service("StoreGateSvc", m_storeGate);
  if(sc.isFailure()){
    mLog << MSG::ERROR 
         << "Unable to retrieve pointer to StoreGateSvc"
	 << endreq;
    return sc;
  }
  
  sc = service("THistSvc", m_thistSvc);
  if(sc.isFailure()){
    mLog << MSG::ERROR 
         << "Unable to retrieve pointer to THistSvc"
	 << endreq;
    return sc;
  }

  IToolSvc * toolSvc;
  service("ToolSvc", toolSvc);

  IAlgTool *tmp_analysisTools;
  toolSvc->retrieveTool("AnalysisTools", tmp_analysisTools);
  m_analysisTools = dynamic_cast<IAnalysisTools *>(tmp_analysisTools);

  IAlgTool *tmp_eventTool;
  toolSvc->retrieveTool("EventTool", tmp_eventTool);
  m_eventTool = dynamic_cast<IEventTool *>(tmp_eventTool);

  IAlgTool *tmp_tagTool;
  toolSvc->retrieveTool("EventTagTool", tmp_tagTool);
  m_tagTool = dynamic_cast<IEventTagTool *>(tmp_tagTool);

  IAlgTool *tmp_truthMatch;
  toolSvc->retrieveTool("TruthMatch", tmp_truthMatch);
  m_truthMatchTool = dynamic_cast<ITruthMatch *>(tmp_truthMatch);

  IAlgTool *tmp_decayTool;
  toolSvc->retrieveTool("DecayVector", tmp_decayTool);
  m_truthVector = dynamic_cast<IDecayVector *>(tmp_decayTool);

  IAlgTool *tmp_histogramTool;
  toolSvc->retrieveTool("BUSTopHistogrammer", tmp_histogramTool);
  m_histogrammer = dynamic_cast<IBUSTopHistogrammer *>(tmp_histogramTool);

  sc = m_trigDec.retrieve();
  if(sc.isFailure()){
    mLog << MSG::ERROR
         << "Unable to retrieve pointer to TrigDec"
         << endreq;
    return sc;
  }

  registerHistograms();
  
  return StatusCode::SUCCESS;
}

void BUSTopMuonAnalysis::registerHistograms(){
  std::stringstream fName, hName;
  std::string title;

  h_full_muon = new MuonHistograms(m_histogrammer, "MuonAnalysis", "Kinematic", "ma_full_muon");

  h_triggered_muprim = new MuonHistograms(m_histogrammer, "MuonAnalysis", "Kinematic", "ma_triggered_muprim");
  h_selected_mu = new MuonHistograms(m_histogrammer, "MuonAnalysis", "Kinematic", "ma_selected_mu");

  h_mupre_mufull = new MuonHistograms(m_histogrammer, "MuonAnalysis", "Kinematic", "ma_mupre_mufull");
  h_mupre_muprim = new MuonHistograms(m_histogrammer, "MuonAnalysis", "Kinematic", "ma_mupre_muprim");
  h_mupre_musec = new MuonHistograms(m_histogrammer, "MuonAnalysis", "Kinematic", "ma_mupre_musec");
  h_mupre_esec = new ElectronHistograms(m_histogrammer, "MuonAnalysis", "Kinematic", "ma_mupre_esec");

  fName.str("");
  hName.str("");
  hName << "ma_trigger_pt30";
  fName << "/AANT/MuonAnalysis/" << "TriggerAnalysis" << "/" << hName.str();
  title = "Trigger Efficiency (30GeV)";
  h_trigger_pt30 = new TH1F(hName.str().c_str(), title.c_str(), 2, 0, 2);
  m_thistSvc->regHist(fName.str().c_str(), h_trigger_pt30);

  fName.str("");
  hName.str("");
  hName << "ma_preselected_mJet_deltaR";
  fName << "/AANT/MuonAnalysis/" << "PreselectionAnalysis" << "/" << hName.str();
  title = "Primary Muon/Jet \\Delta R";
  h_preselected_mJet_deltaR = new TH1F(hName.str().c_str(), title.c_str(), 100, 0, 6.0);
  m_thistSvc->regHist(fName.str().c_str(), h_preselected_mJet_deltaR);

  //truth dependent histograms!
  if(m_truthAvailable == true){
    h_matched_preselected_muon = new MuonHistograms(m_histogrammer, "MuonAnalysis", "PreselectionAnalysis", "ma_matched_preselection");
    h_matched_preselected_muon_res = new ResolutionHistograms(m_histogrammer, "MuonAnalysis", "PreselectionAnalysis", "ma_matched_preselection_res", m_truthMatchDeltaR);

    fName.str("");
    hName.str("");
    hName << "ma_matched_preselection_index";
    fName << "/AANT/MuonAnalysis/" << "PreselectionAnalysis" << "/" << hName.str();
    title = "Preselected Truth Match Index";
    h_matched_preselected_muon_index = new TH1F(hName.str().c_str(), title.c_str(), 10, -0.5, 9.5);
    m_thistSvc->regHist(fName.str().c_str(), h_matched_preselected_muon_index);

    fName.str("");
    hName.str("");
    hName << "ma_matched_selection_index";
    fName << "/AANT/MuonAnalysis/" << "SelectionAnalysis" << "/" << hName.str();
    title = "Selected Truth Match Index";
    h_matched_selected_muon_index = new TH1F(hName.str().c_str(), title.c_str(), 10, 0, 10);
    m_thistSvc->regHist(fName.str().c_str(), h_matched_selected_muon_index);
  }
}

StatusCode BUSTopMuonAnalysis::finalize() {
  MsgStream mLog( messageService(), name() );

  return StatusCode::SUCCESS;
}

//////////////////////////////////////////////////////////////////////////////////
/// Execute - called by the event loop on event by event

StatusCode BUSTopMuonAnalysis::execute() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << "execute()" << endreq;

  getEventWeight();  
  getStoregateContainers();

  plotMuons();
  mJetIsolation();

  if(m_doTrigger == true){
    triggerAnalysis();
  }

  if(m_truthAvailable == true){
    truthAnalysis();
    selectionAnalysis();
  }

  clearParticleContainers();

  return StatusCode::SUCCESS;
}

void BUSTopMuonAnalysis::getStoregateContainers(){
  MsgStream mLog( messageService(), name() );

  muonTES = 0;
  m_storeGate->retrieve(muonTES, m_inputMuonContainerName);
  if(muonTES == 0){
    mLog << MSG::ERROR << "Problem getting Input MuonContainer" << endreq;
  }

  c_selectedMuons = 0;
  m_storeGate->retrieve(c_selectedMuons, m_selectedMuonContainerName);
  if(c_selectedMuons == 0){
    mLog << MSG::ERROR << "Problem getting Selected MuonContainer" << endreq;
  }

  c_preselected = 0;
  m_storeGate->retrieve(c_preselected, m_preselectedMuonContainerName);
  if(c_preselected == 0){
    mLog << MSG::ERROR << "Problem getting Preselected MuonContainer" << endreq;
  }

  c_preselected_elec = 0;
  m_storeGate->retrieve(c_preselected_elec, m_preselectedElecContainerName);
  if(c_preselected_elec == 0){
    mLog << MSG::ERROR << "Problem getting Preselected ElectronContainer" << endreq;
  }

  c_preselected_bjets = 0;
  m_storeGate->retrieve(c_preselected_bjets, m_preselectedBJetContainerName);
  if(c_preselected_bjets == 0){
    mLog << MSG::ERROR << "Problem getting Preselected BJet Container" << endreq;
  }

  c_preselected_ljets = 0;
  m_storeGate->retrieve(c_preselected_ljets, m_preselectedLJetContainerName);
  if(c_preselected_ljets == 0){
    mLog << MSG::ERROR << "Problem getting Preselected LJet Container" << endreq;
  }

  if(m_truthAvailable == true){
    c_truthMuons = 0;
    m_storeGate->retrieve(c_truthMuons, "BUSTopTruth_mu");
    if(c_truthMuons == 0){
      mLog << MSG::ERROR << "Problem getting TruthMuon Container" << endreq;
    }
  }
}

void BUSTopMuonAnalysis::plotMuons(){
  MsgStream mLog( messageService(), name() );

  h_full_muon->plotContainer(muonTES, m_eventWeight);

  if(m_tagTool->tagged(IEventTagTool::TRIGGERED_MUON) && muonTES->size() > 0){
    h_triggered_muprim->plot(muonTES->at(0), m_eventWeight);
  }

  if(m_tagTool->tagged(IEventTagTool::MUON_SELECTION) && c_selectedMuons->size() > 0){
    h_selected_mu->plot(c_selectedMuons->at(0), m_eventWeight);    
  }

  if(c_preselected->size() > 0){
    mLog << MSG::DEBUG << "plotMuons(): plotting full preselection container" << endreq;    
    h_mupre_mufull->plotContainer(c_preselected, m_eventWeight);

    if(m_tagTool->tagged(IEventTagTool::MUON_PRESELECTION)){
      h_mupre_muprim->plot(c_preselected->at(0), m_eventWeight);
 
      h_mupre_musec->n[0]->Fill(c_preselected->size()-1, m_eventWeight);
      for(unsigned int i = 1; i < c_preselected->size(); i++){
        h_mupre_musec->plot(c_preselected->at(i), m_eventWeight);
      }
   
      h_mupre_esec->plotContainer(c_preselected_elec, m_eventWeight);
    }
  }
}

void BUSTopMuonAnalysis::clearParticleContainers(){
  muonTES = 0;
  c_preselected = 0;
  c_preselected_bjets = 0;
  c_preselected_ljets = 0;
}

void BUSTopMuonAnalysis::getEventWeight(){
  if(m_tagTool->tagged(IEventTagTool::IS_ATLFAST) == false && m_tagTool->tagged(IEventTagTool::IS_MC) == true){  
    m_eventWeight = m_eventTool->getEventWeight();
  }else{
    m_eventWeight = 1.0;
  }
}

void BUSTopMuonAnalysis::mJetIsolation(){
  preselectedMJetIsolation();
}

void BUSTopMuonAnalysis::preselectedMJetIsolation(){
  if(c_preselected->size() > 0){
    JetCollection::const_iterator jetIter = c_preselected_bjets->begin();
    JetCollection::const_iterator jetIterEnd = c_preselected_bjets->end();
    double deltaR = 0;
    double acceptedDeltaR = 1000;
  
    while(jetIter < jetIterEnd){
      deltaR = AnalysisUtils::Delta::R(c_preselected->at(0), *jetIter);
      if(deltaR < acceptedDeltaR){
        acceptedDeltaR = deltaR;
      }
      jetIter++;
    }

    jetIter = c_preselected_ljets->begin();
    jetIterEnd = c_preselected_ljets->end();

    while(jetIter < jetIterEnd){
      deltaR = AnalysisUtils::Delta::R(c_preselected->at(0), *jetIter);
      if(deltaR < acceptedDeltaR){
        acceptedDeltaR = deltaR;
      }
      jetIter++;
    }

    
    h_preselected_mJet_deltaR->Fill(acceptedDeltaR, m_eventWeight);
  }
}

void BUSTopMuonAnalysis::triggerAnalysis(){
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "triggerAnalysis()" << endreq;
  
  if(muonTES->size() > 0 && muonTES->at(0)->pt() > 30*GeV){
    h_trigger_pt30->Fill(0.0, m_eventWeight);
    if(m_tagTool->tagged(IEventTagTool::TRIGGERED_MUON)){
      h_trigger_pt30->Fill(1.0, m_eventWeight);
    }
  }

  mLog << MSG::DEBUG << "triggerAnalysis(): done" << endreq;

}

void BUSTopMuonAnalysis::truthAnalysis(){
  
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "preselectionAnalysis" << endreq;
  
  //How many events are getting through the preselection stage (raw)?
  //Then truth match the muons - how many are really from the truth?
        
  //search for best truth match
  //keep a track of how many best matches are the primary muon...
       
  if(m_tagTool->tagged(IEventTagTool::MUON_PRESELECTION)){
      
    TruthParticleContainer::const_iterator mcIter = c_truthMuons->begin();
    TruthParticleContainer::const_iterator mcIterEnd = c_truthMuons->end();
 
    while(mcIter < mcIterEnd){
      unsigned int acceptedIndex = 0;
  
      m_truthMatchTool->matchR(*mcIter, c_preselected, acceptedIndex);
      
      double acceptedDeltaR = 1000.0;
  
      acceptedDeltaR = AnalysisUtils::Delta::R(*mcIter, c_preselected->at(acceptedIndex));

      if(acceptedDeltaR < m_truthMatchDeltaR){
        h_matched_preselected_muon->plot(c_preselected->at(acceptedIndex), m_eventWeight);
        h_matched_preselected_muon_res->plot(*mcIter, c_preselected->at(acceptedIndex), m_eventWeight);
  
        h_matched_preselected_muon_index->Fill(acceptedIndex, m_eventWeight);
      }
      
      mcIter++;
    }
  }
}

void BUSTopMuonAnalysis::selectionAnalysis(){
     
  MsgStream mLog( messageService(), name() );
       
  mLog << MSG::DEBUG << "selectionAnalysis" << endreq;
  
  if(c_selectedMuons->size()){
    h_matched_selected_muon_index->Fill(0.0, m_eventWeight);    
  }

  if(m_tagTool->tagged(IEventTagTool::MUON_SELECTION) == true && c_selectedMuons->size() > 0){
       
    TruthParticleContainer::const_iterator mcIter = c_truthMuons->begin();
    TruthParticleContainer::const_iterator mcIterEnd = c_truthMuons->end();
  
    while(mcIter < mcIterEnd){
      double acceptedDeltaR = 1000.0;
    
      acceptedDeltaR = AnalysisUtils::Delta::R(*mcIter, c_selectedMuons->at(0));
    
      if(acceptedDeltaR < m_truthMatchDeltaR){
        h_matched_selected_muon_index->Fill(1.0, m_eventWeight);
      }

      mcIter++;
    }
  } 
}



