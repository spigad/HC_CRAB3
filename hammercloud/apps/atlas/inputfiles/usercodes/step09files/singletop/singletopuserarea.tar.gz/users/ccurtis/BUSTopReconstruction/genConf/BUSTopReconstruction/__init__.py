## Hook for BUSTopReconstruction genConf module
