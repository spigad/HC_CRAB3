#include "GaudiKernel/IToolSvc.h"
#include "GaudiKernel/ITHistSvc.h"

#include "TH1.h"
#include "TH2.h"

#include "McParticleEvent/TruthParticle.h"
#include "McParticleEvent/TruthParticleContainer.h"
#include "egammaEvent/ElectronContainer.h"
#include "muonEvent/Muon.h"

#include "JetEvent/JetCollection.h"
#include "JetEvent/Jet.h"
#include "JetEvent/JetKeyDescriptor.h"

#include "CompositeParticleEvent/CompositeParticleContainer.h"
#include "CompositeParticleEvent/CompositeParticle.h"

#include "MissingETEvent/MissingET.h"
#include "ParticleEvent/NeutrinoContainer.h"
#include "ParticleEvent/Neutrino.h"

#include "SpecialUtils/NeutrinoUtils.h"

#include "DataModel/ElementLink.h"
#include "JetTagInfo/TruthInfo.h"

#include "AnalysisTools/IAnalysisTools.h"

#include "BUSTopTools/IBUSTopHistogrammer.h"
#include "BUSTopTools/KinematicHistograms.h"
#include "BUSTopTools/ResolutionHistograms.h"
#include "BUSTopTools/METResolutionHistograms.h"
#include "BUSTopTools/EventTool.h"

#include "BUSTopReconstruction/BUSTopTReconstruction.h"

#include <stdint.h>
#include <algorithm>
#include <math.h>
#include <functional>

BUSTopTReconstruction::BUSTopTReconstruction(const std::string& name, ISvcLocator* pSvcLocator) : 
                                             Algorithm(name, pSvcLocator){

  declareProperty("TruthAvailable", m_truthAvailable);
  declareProperty("FilterTags", m_filterTags);

  declareProperty("InputBJets", m_inputBJetName);
  declareProperty("InputWs", m_inputWName);

  declareProperty("OutputTops", m_outputTopName);

  declareProperty("ApplyMassVeto", m_applyMassVeto);
  declareProperty("LowMassVeto", m_lowMassVeto);
  declareProperty("HighMassVeto", m_highMassVeto);
}

BUSTopTReconstruction::~BUSTopTReconstruction(){
}

StatusCode BUSTopTReconstruction::initialize() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << "Initializing BUSTopTReconstruction" << endreq;

  if (service("StoreGateSvc", m_storeGate).isFailure()) {
     mLog << MSG::ERROR << "Unable to retrieve pointer to StoreGateSvc" << endreq;
     return StatusCode::FAILURE;
  }

  service("THistSvc", m_histSvc);

  IToolSvc * toolSvc;
  service("ToolSvc", toolSvc);

  IAlgTool *tmp_eventTool;
  toolSvc->retrieveTool("EventTool", tmp_eventTool);
  m_eventTool = dynamic_cast<IEventTool *>(tmp_eventTool);

  IAlgTool *tmp_tagTool;
  toolSvc->retrieveTool("EventTagTool", tmp_tagTool);
  m_tagTool = dynamic_cast<IEventTagTool *>(tmp_tagTool);

  IAlgTool *tmp_histogramTool;
  toolSvc->retrieveTool("BUSTopHistogrammer", tmp_histogramTool);
  m_histogrammer = dynamic_cast<IBUSTopHistogrammer *>(tmp_histogramTool);

  registerHistograms();

  return StatusCode::SUCCESS;
}

void BUSTopTReconstruction::registerHistograms(){
  std::stringstream fName, hName;
  std::string title;

  fName.str("");
  hName.str("");
  hName << "tr_recon";
  fName << "/AANT/TopReconstruction/" << m_outputTopName << "/" << hName.str();
  title = "N Recon Pass";
  h_recon = new TH1F(hName.str().c_str(), title.c_str(), 1, 0, 1);
  m_histSvc->regHist(fName.str().c_str(), h_recon);

  fName.str("");
  hName.str("");
  hName << "tr_size";
  fName << "/AANT/TopReconstruction/" << m_outputTopName << "/" << hName.str();
  title = "N Recon Size";
  h_size = new TH1F(hName.str().c_str(), title.c_str(), 10, 0, 10);
  m_histSvc->regHist(fName.str().c_str(), h_size);
}


StatusCode BUSTopTReconstruction::finalize() {
  MsgStream mLog( messageService(), name() );
  
  return StatusCode::SUCCESS;
}

StatusCode BUSTopTReconstruction::execute() {

  MsgStream mLog( messageService(), name() );

  mLog << MSG::INFO << "execute()" << endreq;

  getEventWeight();
  getStoregateContainers();
  createTemporaryContainers();

  if(m_tagTool->allTagged(m_filterTags)){
    h_recon->Fill(0.0, m_eventWeight);

    reconstructTop();

    h_size->Fill(c_top->size(), m_eventWeight);
  }

  registerContainers();

  destroyTemporaryContainers();
  
  StatusCode sc = StatusCode::SUCCESS;

  return sc;
}

void BUSTopTReconstruction::getStoregateContainers(){
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "getting storegate containers" << endreq;

  m_storeGate->retrieve(c_bJets, m_inputBJetName);
  if(c_bJets == 0){
    mLog << MSG::ERROR << "Problem getting BJets Container" << endreq;
  }

  m_storeGate->retrieve(c_w, m_inputWName);
  if(c_w == 0){
    mLog << MSG::ERROR << "Problem getting W Container" << endreq;
  }
}

void BUSTopTReconstruction::createTemporaryContainers(){
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "creating temporary containers" << endreq;

  c_top = new CompositeParticleContainer();
}

void BUSTopTReconstruction::destroyTemporaryContainers(){
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "destroying temporary containers" << endreq;

  delete c_top;
  c_top = 0;
}

void BUSTopTReconstruction::registerContainers(){
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "registering temporary containers" << endreq;

  registerContainer(c_top, m_outputTopName);
}

void BUSTopTReconstruction::registerContainer(CompositeParticleContainer* c, std::string n){
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "Tops Reconstructed: " << c->size() << endreq;

  CompositeParticleContainer* tmp = new CompositeParticleContainer();

  m_storeGate->record(tmp, n);
    
  CompositeParticleContainer::const_iterator cIter = c->begin();
  CompositeParticleContainer::const_iterator cIterEnd = c->end();

  while(cIter < cIterEnd){
    tmp->push_back(new CompositeParticle(**cIter));
    cIter++;
  }

  AnalysisUtils::Sort::pT(tmp);
      
  m_storeGate->setConst(tmp);

  mLog << MSG::DEBUG << "Registering: " << n << " with " << tmp->size() << " entries." << endreq;

}

void BUSTopTReconstruction::reconstructTop(){
  MsgStream mLog( messageService(), name() );

  mLog << MSG::DEBUG << "reconstructingTop()" << endreq;

  if(c_w->size() > 0 && c_bJets->size() > 0){
    mLog << MSG::DEBUG << "passed c_w c_bJets size check" << endreq;
   
    JetCollection::const_iterator jetIter = c_bJets->begin();
    JetCollection::const_iterator jetIterEnd = c_bJets->end();

    mLog << MSG::DEBUG << "defined jet iterators" << endreq;

    while(jetIter < jetIterEnd){
      CompositeParticleContainer::const_iterator wIter = c_w->begin();
      CompositeParticleContainer::const_iterator wIterEnd = c_w->end();

      mLog << MSG::DEBUG << "defined w iterators" << endreq;

      while(wIter < wIterEnd){

        CompositeParticle* tmp_t = new CompositeParticle();
        mLog << MSG::DEBUG << "created top" << endreq;

        tmp_t->add(*wIter);
        mLog << MSG::DEBUG << "added w" << endreq;

        tmp_t->add(*jetIter);
        mLog << MSG::DEBUG << "added jet" << endreq;
  
        if(tmp_t->charge() > 0){
          tmp_t->set_pdgId(PDG::t);
        }else{
          tmp_t->set_pdgId(PDG::anti_t);
        }
   
        mLog << MSG::DEBUG << "set pdgid" << endreq;

        if(m_applyMassVeto == true){
          mLog << MSG::DEBUG << "applying veto... " << tmp_t->m() << endreq;
          if(tmp_t->m() > m_lowMassVeto*GeV && tmp_t->m() < m_highMassVeto*GeV){ 
            mLog << MSG::DEBUG << "passed veto" << endreq;
            c_top->push_back(tmp_t);
          }else{
            mLog << MSG::DEBUG << "failed veto" << endreq;
          }
        }else{
          mLog << MSG::DEBUG << "Adding top" << endreq;
          c_top->push_back(tmp_t);
        }


        wIter++;
      }

      jetIter++;
    }
  }

  mLog << MSG::DEBUG << "done reconstructingTop()" << endreq;

}

void BUSTopTReconstruction::getEventWeight(){
  if(m_tagTool->tagged(IEventTagTool::IS_ATLFAST) == false && m_tagTool->tagged(IEventTagTool::IS_MC) == true){
    m_eventWeight = m_eventTool->getEventWeight();
  }else{
    m_eventWeight = 1.0;
  }
}

