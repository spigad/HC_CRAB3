#ifndef TRUTH_MATCH_H
#define TRUTH_MATCH_H

#include "BUSTopTools/ITruthMatch.h"

static const InterfaceID IID_ITruthMatch("TruthMatch", 1, 0);

class TruthMatch: public ITruthMatch{
   public:
     TruthMatch(const std::string&, const std::string&, const IInterface*);
     StatusCode initialize();
     
     static const InterfaceID& interfaceID(){ return IID_ITruthMatch; }

};

#endif
