j = Job()
j.name='5502'
j.application=Athena()
j.application.option_file=[ 'SUSYValidation_jobOptions.py' ]
j.application.athena_compile=False
j.application.collect_stats=True
j.application.prepare()
j.splitter=DQ2JobSplitter()
#j.splitter.numsubjobs=
#j.splitter.use_blacklist = False
j.inputdata=DQ2Dataset()
j.inputdata.dataset='mc08.105401.SU1_jimmy_susy.recon.AOD.e352_s462_r541_tid026109'
#j.inputdata.type='FILE_STAGER'
j.outputdata=DQ2OutputDataset()
#j.outputdata.outputdata=['SUSYValidation.root']
j.backend=Panda()
#j.backend=LCG()
j.backend.requirements.cloud='DE'

j.submit()


