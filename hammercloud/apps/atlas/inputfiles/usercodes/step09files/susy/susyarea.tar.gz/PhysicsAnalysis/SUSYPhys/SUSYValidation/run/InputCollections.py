ServiceMgr.EventSelector.InputCollections = ["AOD.026109._00001.pool.root.1"]
