#Wed Apr  8 09:43:48 2009
"""Automatically generated. DO NOT EDIT please"""
from GaudiKernel.Proxy.Configurable import *

class FileStagerAlg( ConfigurableAlgorithm ) :
  __slots__ = { 
    'OutputLevel' : 0, # int
    'Enable' : True, # bool
    'ErrorMax' : 1, # int
    'ErrorCount' : 0, # int
    'AuditAlgorithms' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditReinitialize' : False, # bool
    'AuditExecute' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditBeginRun' : False, # bool
    'AuditEndRun' : False, # bool
    'MonitorService' : 'MonitorSvc', # str
    'PipeLength' : 1, # int
    'VerboseStager' : False, # bool
    'VerboseWaiting' : True, # bool
    'FirstFileAlreadyStaged' : False, # bool
    'TreeName' : 'CollectionTree', # str
    'InfilePrefix' : 'gridcopy://', # str
    'OutfilePrefix' : 'file:', # str
    'CpCommand' : 'lcg-cp', # str
    'BaseTmpdir' : '', # str
    'CpArguments' : [  ], # list
    'InputCollections' : [  ], # list
    'OutputCollections' : [  ], # list
    'LogfileDir' : '', # str
    'KeepLogfiles' : False, # bool
    'StoreStatistics' : False, # bool
  }
  _propertyDocDct = { 
    'CpArguments' : """ vector of cp arguments """,
    'InputCollections' : """ vector of input files """,
    'OutputCollections' : """ vector of output files """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(FileStagerAlg, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'FileStager'
  def getType( self ):
      return 'FileStagerAlg'
  pass # class FileStagerAlg
