# Author: Max Baak <mbaak@cern.ch>

# Some global settings (typically, you *only* want to
# do this in the final options file, never in a fragment):

from AthenaCommon.GlobalFlags import GlobalFlags
GlobalFlags.DetGeo.set_atlas()
GlobalFlags.DataSource.set_geant4()
include( "IOVDbSvc/IOVRecExCommon.py" )
include( "AtlasGeoModel/SetGeometryVersion.py" )
include( "AtlasGeoModel/GeoModelInit.py" )
include( "BFieldAth/BFieldAth_jobOptions.py" )
GeoModelSvc = Service("GeoModelSvc")
GeoModelSvc.IgnoreTagDifference = True

# Event selector
include( "AthenaPoolCnvSvc/ReadAthenaPool_jobOptions.py" )
# the POOL converters
#include( "ParticleEventAthenaPool/AOD_PoolCnv_jobOptions.py")
include( "ParticleBuilderOptions/ESD_PoolCnv_jobOptions.py")
include( "ParticleBuilderOptions/AOD_PoolCnv_jobOptions.py")
#include( "ParticleEventAthenaPool/AOD_PoolCnv_jobOptions.py")

#Only for FDR, outside CERN!!!
svcMgr.PoolSvc.SortReplicas=True
from DBReplicaSvc.DBReplicaSvcConf import DBReplicaSvc
svcMgr+=DBReplicaSvc()
svcMgr.DBReplicaSvc.UseCOOLSQLite=False

from McParticleTools.McParticleToolsConf import TruthParticleCnvTool
from TrigDecision.TrigDecisionConf import TrigDec__TrigDecisionTool

# python module to ensure backward compatibility of JetCollection to ParticleJetContainer
#import JetRec.ParticleJetCompatibility

#handle.TrigDec__TrigDecisionTool = TrigDecisionTool('TrigDecisionTool')
   
theApp.Dlls += ["TrigDecision"]

## get a handle on the ServiceManager
svcMgr = theApp.serviceMgr()

## EventSelector Properties
#EventSelector = svcMgr.EventSelector

# reduce POOL verbosity
os.environ['POOL_OUTMSG_LEVEL'] = 'WARNING'
os.environ['CORAL_MSGLEVEL'] = 'WARNING'

# now handle output level on athena command line ...
## get a handle on the ServiceManager
#svcMgr.MessageSvc.OutputLevel = WARNING
#AthenaEventLoopMgr = Service( "AthenaEventLoopMgr" )
#AthenaEventLoopMgr.OutputLevel = WARNING

theApp.HistogramPersistency = "ROOT"

HistogramPersistencySvc = Service( "HistogramPersistencySvc" )
HistogramPersistencySvc.OutputFile = "ama_histograms.root";

## End of FileStager_jobOptions.py

include ("FileStager/input_FileStager.py")

