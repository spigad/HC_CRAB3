#Wed Apr  8 09:33:55 2009
"""Automatically generated. DO NOT EDIT please"""
from GaudiKernel.GaudiHandles import *
from GaudiKernel.Proxy.Configurable import *

class AnalysisSkeleton( ConfigurableAlgorithm ) :
  __slots__ = { 
    'OutputLevel' : 0, # int
    'Enable' : True, # bool
    'ErrorMax' : 1, # int
    'ErrorCount' : 0, # int
    'AuditAlgorithms' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditReinitialize' : False, # bool
    'AuditExecute' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditBeginRun' : False, # bool
    'AuditEndRun' : False, # bool
    'MonitorService' : 'MonitorSvc', # str
    'StreamName' : 'AANT', # str
    'TreeName' : 'CollectionTree', # str
    'AnalysisTools' : PrivateToolHandle('AnalysisTools'), # GaudiHandle
    'MCParticleContainer' : 'SpclMC', # str
    'DeltaRMatchCut' : 0.5, # float
    'DeltaRMatchCutLOW' : 0.5, # float
    'DeltaRMatchCutL1' : 0.5, # float
    'MaxDeltaR' : 0.9999, # float
    'PlateauStep' : 5000.0, # float
    'doMCTruth' : True, # bool
    'doTrigDec' : False, # bool
    'TrigDecisionTool' : PublicToolHandle('TrigDec::TrigDecisionTool'), # GaudiHandle
  }
  _propertyDocDct = { 
    'TrigDecisionTool' : """ The tool to access TrigDecision """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(AnalysisSkeleton, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'UserAnalysis'
  def getType( self ):
      return 'AnalysisSkeleton'
  pass # class AnalysisSkeleton
