#include <sstream>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <vector>

#include "TSystem.h"
#include "TTree.h"
#include "TBranch.h"
#include "TString.h"
#include "TCanvas.h"
#include "TKey.h"
#include "TFile.h"
#include "TClassTable.h"
#include "TStopwatch.h"

#include "UserAnalysisEvent/TruthParticle.h"

using namespace User;

void truthParticleAnalysis () {

  TFile *  f = new TFile("SAN.root");
  TTree *  tree = (TTree*)gDirectory->Get("CollectionTree");

  /** TruthParticle */
  std::vector<TruthParticle> * pTruth=0;
  tree->SetBranchAddress("SpclMC",&pTruth);
  TBranch * mcBranch = tree->GetBranch("SpclMC");

  Long64_t nentries = tree->GetEntriesFast();
  int nbytes = 0; 
  int nb = 0;
  
  TStopwatch timer;
  timer.Start();
  for (Long64_t jentry=0; jentry<1;jentry++) {

    /** Read the MC truth */
    nb = mcBranch->GetEntry(jentry); nbytes += nb;

    /** Loop over TruthParticles and do something */
    std::vector<TruthParticle>::const_iterator itr  = pTruth->begin();
    std::vector<TruthParticle>::const_iterator itrE = pTruth->end();
    unsigned int iPart = 0;
    for (; itr != itrE; ++itr, ++iPart) {
      std::cout << "Part " << iPart
 	        << " PDG-ID: " << (*itr).pdgId()
	        << " nChildren: " << (*itr).nDecay()
	        << " status: " << (*itr).status()
	        << " barcode: " << (*itr).barcode()
                << " pt: " << (*itr).pt()
                << " eta: " << (*itr).eta()
	        << std::endl;
      for ( unsigned int iChild = 0; iChild != (*itr).nDecay(); ++iChild ){
         const TruthParticle * child = (*itr).child( iChild );
         if ( 0 != child ) {
	    std::cout << "\tchild: " << iChild
	              << "\tPDGID: " << child->pdgId()
	              << " status: " << child->status()
	              << " barcode: "     << child->barcode()
	              << " barcode Parents: " << child->nParents() << " [ ";
	   for ( unsigned int iMoth = 0; iMoth != child->nParents(); ++iMoth ) {
	       std::cout << child->mother(iMoth)->barcode() << " ";
	   }
	   std::cout << "]" << std::endl;
         } else {
	   std::cout << "Wrong pointer to child !!" << std::endl;
         }
      }//> loop over children
      
      std::cout << " " << std::endl;
    }
    std::cout << "------------------------------ " << std::endl;    
  }
  timer.Stop();
  Double_t kbytes = 0.001*nbytes;
  Double_t rtime = timer.RealTime();
  Double_t ctime = timer.CpuTime();
  printf("You have %d events and size=%f kb read.\n",nentries,nbytes/1000);
  printf("RealTime=%f seconds, CpuTime=%f seconds\n",rtime,ctime);
  printf("You read %f kb/Realtime seconds\n",kbytes/rtime);
  printf("You read %f kb/Cputime seconds\n",kbytes/ctime);
  
  f->Close();
  
  return;
  
}
