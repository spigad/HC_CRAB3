# echo "Setting UserAnalysis UserAnalysis-00-10-12 in /afs/cern.ch/user/e/elmsheus/athena/testarea/15.9.0/PhysicsAnalysis/AnalysisCommon"

if test "${CMTROOT}" = ""; then
  CMTROOT=/afs/cern.ch/sw/contrib/CMT/v1r21; export CMTROOT
fi
. ${CMTROOT}/mgr/setup.sh

tempfile=`${CMTROOT}/mgr/cmt -quiet build temporary_name`
if test ! $? = 0 ; then tempfile=/tmp/cmt.$$; fi
${CMTROOT}/mgr/cmt setup -sh -pack=UserAnalysis -version=UserAnalysis-00-10-12 -path=/afs/cern.ch/user/e/elmsheus/athena/testarea/15.9.0/PhysicsAnalysis/AnalysisCommon  -no_cleanup $* >${tempfile}
if test $? != 0 ; then
  echo >&2 "${CMTROOT}/mgr/cmt setup -sh -pack=UserAnalysis -version=UserAnalysis-00-10-12 -path=/afs/cern.ch/user/e/elmsheus/athena/testarea/15.9.0/PhysicsAnalysis/AnalysisCommon  -no_cleanup $* >${tempfile}"
  cmtsetupstatus=2
  /bin/rm -f ${tempfile}
  return $cmtsetupstatus
fi
cmtsetupstatus=0
. ${tempfile}
if test $? != 0 ; then
  cmtsetupstatus=2
fi
/bin/rm -f ${tempfile}
return $cmtsetupstatus

