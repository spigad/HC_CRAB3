#! /usr/bin/env sh

export Base=$1
export Release=$2
#export Loc=$Base/builds/AtlasEvent/$Release/PhysicsAnalysis/AnalysisCommon/UserAnalysisEvent
#export Ana=$Base/builds/AtlasAnalysis/$Release/PhysicsAnalysis/AnalysisCommon/UserAnalysis
export Loc=$Base/PhysicsAnalysis/AnalysisCommon/UserAnalysisEvent
export Ana=$Base/PhysicsAnalysis/AnalysisCommon/UserAnalysis
cp -R $Loc/UserAnalysisEvent .
cp -R $Loc/src .
cp -R $Loc/Root .
cd Root
cp $Ana/Root/Makefile .
cd ..
mkdir run
cd run
cp $Ana/Root/*.h .
cp $Ana/Root/*.C .
cd ..
mkdir UserGenReflex
cd UserGenReflex
cp $Ana/Root/generatingDirectonary.txt .
cd ..
gtar -zcvf UserAnalysisEvent.tar.gz UserAnalysisEvent run Root src UserGenReflex
rm -R run
rm -R src
rm -R Root
rm -R UserAnalysisEvent
rm -R UserGenReflex

