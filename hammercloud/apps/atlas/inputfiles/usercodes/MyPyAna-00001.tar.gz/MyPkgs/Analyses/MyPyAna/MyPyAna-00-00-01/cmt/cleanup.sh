if test "${CMTROOT}" = ""; then
  CMTROOT=/afs/cern.ch/sw/contrib/CMT/v1r20p20070720; export CMTROOT
fi
. ${CMTROOT}/mgr/setup.sh
tempfile=`${CMTROOT}/mgr/cmt -quiet build temporary_name`
if test ! $? = 0 ; then tempfile=/tmp/cmt.$$; fi
${CMTROOT}/mgr/cmt cleanup -sh -pack=MyPyAna -version=MyPyAna-00-00-01 -path=/afs/cern.ch/user/e/elmsheus/athena/testarea/14.5.1/MyPkgs/Analyses $* >${tempfile}; . ${tempfile}
/bin/rm -f ${tempfile}

