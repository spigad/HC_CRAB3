j = Job()
j.name='AODtoDPD_thin'
j.application=Athena()
j.application.exclude_from_user_area=["*.o","*.root*","*.exe"]
j.application.prepare(athena_compile=False)
j.application.option_file=['dpdgangamakejob.py' ]
j.application.atlas_release='14.4.0'
j.application.max_events=-1
j.inputdata=DQ2Dataset()
j.inputdata.dataset=["mc08.105200.T1_McAtNlo_Jimmy.recon.AOD.e357_s462_r541"]
j.inputdata.type='DQ2_LOCAL'
# For testing
#j.inputdata.number_of_files=4
#j.outputdata=ATLASOutputDataset()
# 
j.outputdata=DQ2OutputDataset()
j.outputdata.outputdata=['thin_1l.DPD.pool.root','hist.root' ]
# j.splitter=DQ2JobSplitter() 
j.splitter=AthenaSplitterJob()
#j.splitter.numfiles_subjob=10
j.splitter.numsubjobs=20
j.backend=NG()
#j.backend.RejectCE = 'grad.uppmax.uu.se,arc-ce.smokerings.nsc.liu.se,arc01.lcg.cscs.ch,nordugrid.unibe.ch,arc-ce.smokerings.nsc.liu.se'
j.backend.requirements = NGRequirements()
j.backend.requirements.memory=1000
j.backend.requirements.cputime=300
j.backend.requirements.walltime=300
j.backend.requirements.disk=4000
#j.backend.CE=''
j.backend.CE='pikolit.ijs.si'
#j.backend.CE='grid03.unige.ch'
#j.backend.CE='gateway01.dcsc.ku.dk'
j.backend.check_availability=False
#j.submit()
