# @file:    MyPyAna/python/SUSYAna.py
# @purpose: <put some purpose here>
# @author:  Katarina Pajchel <katarina.pajchel@fys.uio.no>

__doc__     = 'some documentation here'
__version__ = '$Revision: 1.1 $'
__author__  = 'Katarina Pajchel <katarina.pajchel@fys.uio.no>'

import AthenaCommon.SystemOfUnits as Units
import AthenaPython.PyAthena as PyAthena
from AthenaPython.PyAthena import StatusCode
from EventViewInserters import TauJetParameters
 
class susyAna (PyAthena.Alg):
    'put some documentation here'
    def __init__(self, name='susyAna', **kw):
        ## init base class
        kw['name'] = name
        super(susyAna, self).__init__(**kw)

        ## properties and data members
        # handle to the event store
        self.sg = None

        # handle to thist-svc
        self.hsvc = None
        
        ## StoreGate keys
        self.electrons = kw.get('electrons', 'ElectronAODCollection')
        self.missingEt = kw.get('missingEt', 'MET_RefFinal')
        self.jets      = kw.get('jets',      'Cone4H1TowerJets')
        self.muons     = kw.get('muons',     'StacoMuonCollection')
        self.taus      = kw.get('taus',      'TauRecContainer')
        self.clusters  = kw.get('clusters',  'CaloCalTopoCluster')
        self.tracks    = kw.get('tracks',    'TrackParticleCandidate')

        # declaration of some cuts which can be set from the joboption file
        ## lepton's cuts
        self.leptonMinEt  = kw.get('leptonMinEt',  10.*Units.GeV)
        self.leptonMaxEta = kw.get('leptonMaxEta', 2.5)

        ## jets' cuts
        self.jetMinEt  = kw.get('jetMinEt',  20.*Units.GeV)
        self.jetMaxEta = kw.get('jetMaxEta', 2.5)

        ## lepton/jet isolation cut
        self.minDeltaRlj = kw.get('minDeltaRlj', 0.2)
        
        ## missing et cut
        self.minMissingEt = kw.get('minMissingEt', 20.*Units.GeV)

        ## B-tag cut 
        self.BtagCut = kw.get('BtagCut', 7.05)
        
        return

    def initialize(self):
        _info = self.msg.info
        _info('==> initialize...')
        # retrieve event store
        self.sg = PyAthena.py_svc ('StoreGateSvc')
        if self.sg is None:
            self.msg.error ('could not retrieve event store')
            return StatusCode.Failure

        # retrieve root histo svc
        self.hsvc = PyAthena.py_svc ('THistSvc/THistSvc')
        if not self.hsvc:
            self.msg.error ('could not retrieve root histo svc')
            return StatusCode.Failure

        # book histograms
        from ROOT import TH1F
        h = self.hsvc # easy on the keyboard
        h['/myoutstream/histos/el_N'] = TH1F ('el_N','El N',10, -0.5, 9.5)
        h['/myoutstream/histos/mu_N'] = TH1F ('mu_N','Muon N',10, -0.5, 9.5)
        h['/myoutstream/histos/tau_N'] = TH1F ('tau_N','Tau N',10, -0.5, 9.5)
        h['/myoutstream/histos/tau_pt'] = TH1F ('tau_pt','Tau P_t',100, 10., 150.)
        h['/myoutstream/histos/tau_likelihood'] = TH1F ('tau_likelihood','TauLikelihood',100, -30., 30.)
        h['/myoutstream/histos/tau_tauellikelihood'] = TH1F ('tau_tauellikelihood','TauElTauLikelihood',100, -30., 30.)
        h['/myoutstream/histos/taug_N'] = TH1F ('taug_N','Tau N',10, -0.5, 9.5)

        h['/myoutstream/histos/lept_N'] = TH1F ('lept_N','Lept N',10, -0.5, 9.5)
        h['/myoutstream/histos/lept_pt'] = TH1F ('lept_pt','Lepton E_t',100, self.leptonMinEt/1000, 150.)
        h['/myoutstream/histos/lept1_pt'] = TH1F ('lept1_pt','Lepton 1 E_t',100, self.leptonMinEt/1000, 150.)
        h['/myoutstream/histos/lept2_pt'] = TH1F ('lept2_pt','Lepton 2 E_t',100, self.leptonMinEt/1000, 150.)
        h['/myoutstream/histos/lept3_pt'] = TH1F ('lept3_pt','Lepton 3 E_t',100, self.leptonMinEt/1000, 150.)

        h['/myoutstream/histos/el_etcone20'] = TH1F ('el_etcone','Elec etcone20',100, -5., 50.)

        h['/myoutstream/histos/mu_etcone20'] = TH1F ('mu_etcone','Muon etcone20',100, -5., 50.)
        
        h['/myoutstream/histos/miss_et'] = TH1F ('miss_et','Missing E_t',100, 0., 200.)
        
        h['/myoutstream/histos/jet_N'] = TH1F ('jet_N','Jet N',15, -0.5, 14.5)
        h['/myoutstream/histos/jet_pt'] = TH1F ('jet_pt','Jet pt',100, self.jetMinEt/1000 , 300.)
        h['/myoutstream/histos/jet1_pt' ] = TH1F ('jet1_pt','Jet 1 pt',100, self.jetMinEt/1000 , 300.)
        h['/myoutstream/histos/jet2_pt' ] = TH1F ('jet2_pt','Jet 2 pt',100, self.jetMinEt/1000 , 300.)
        h['/myoutstream/histos/jet3_pt' ] = TH1F ('jet3_pt','Jet 3 pt',100, self.jetMinEt/1000 , 300.)
        h['/myoutstream/histos/jet4_pt' ] = TH1F ('jet4_pt','Jet 4 pt',100, self.jetMinEt/1000 , 300.)
        h['/myoutstream/histos/jet_btag' ] = TH1F ('jet_btag','Jet btag ',100, -20., 30.)
        h['/myoutstream/histos/bjet_N' ] = TH1F ('bjet_N','B-Jet N ',15, -0.5, 14.5)
        h['/myoutstream/histos/bjet_pt'] = TH1F ('bjet_pt','Jet pt',100, self.jetMinEt/1000 , 300.)
        h['/myoutstream/histos/bjet_m'] = TH1F ('bjet_m','Inv mass B-tagged Jets',80, 0., 200.)

        h['/myoutstream/histos/ossf_m' ] = TH1F ('ossf_m','Inv mass OSSF lep',80, 0., 150.)
        h['/myoutstream/histos/osof_m' ] = TH1F ('osof_m','Inv mass OSOF lep',80, 0., 150.)
        h['/myoutstream/histos/meff'] = TH1F ('meff','M_{eff}',100, 0., 1000.)
        
        ## import some 4-mom utils
        import FourMomUtils.Bindings
        self.utils = { 'deltaR' : PyAthena.P4Helpers.deltaR }

        ## display configuration
        _info("Lepton MinEt:   %r GeV", self.leptonMinEt/Units.GeV)
        _info("Lepton MaxEta:  %r",     self.leptonMaxEta)
        _info("Jets MinEt:     %r GeV", self.jetMinEt/Units.GeV)
        _info("Jets MaxEta:    %r",     self.jetMaxEta)

        ## event counter
        self._evt_cnt = 0
        ## semi-leptonic filter counter
        self._semi_lept_filter_cnt = 0
        return StatusCode.Success

    def execute(self):
        _info = self.msg.info
        self._evt_cnt += 1
        
        # alias...
        _retrieve = self.sg.retrieve
        # retrieve the containers from the event store
        met =  _retrieve ('MissingET',               self.missingEt)
        eles=  _retrieve ('ElectronContainer',       self.electrons)
        jets=  _retrieve ('JetCollection',           self.jets)
        muons= _retrieve ('Analysis::MuonContainer', self.muons)
        taus=  _retrieve ('Analysis::TauJetContainer',self.taus)
                            
        # test that we got all containers
        if not all ([met,eles,jets,muons]):
            _info ('Failed to retrieve one of the input containers')
            _info ('met,eles,jets,muons: %r', [met,eles,jets,muons])
            return StatusCode.Success
        
        hsvc = self.hsvc

        # local variables
        elejets  = [] # electrons overlapping w/ jets
        goodeles = [] # good electrons
        goodmuons= []
        goodjets = []
        goodtaus = []
        bjets = []
        
        deltaR = self.utils['deltaR']
        # helper filtering function
        def eta_et_filter (o, max_eta, min_et):
            return abs (o.eta()) < max_eta and \
                   o.et() > min_et

        # count electrons and mark overlaps with jets
        
        # Different ways of getting isemmask
        # if ec[i].isem(ROOT.egammaPID.ElectronLoose)==0
        import PyCintex
        egdict = PyCintex.loadDict("egammaEventDict")
        isEMmask = getattr(PyAthena.egammaPID, 'ElectronLoose')
        
        for ele in eles:
            if not (ele.author (1) and ele.isem(isEMmask)==0):
                continue
            for jet in jets:
                dRej = deltaR (ele, jet)
                if dRej < self.minDeltaRlj and jet.et() < 2*ele.et():
                     #_info('Jet match: %8.3f %8.3f %8.3f %8.3f %8.3f %8.3f',
                     #     jet.et(), jet.eta(), jet.phi(),
                     #     ele.et(), ele.eta(), ele.phi())
                     elejets += [jet]
            if eta_et_filter(ele,
                             max_eta=self.leptonMaxEta,
                             min_et =self.leptonMinEt):
                hsvc['/myoutstream/histos/el_etcone20'].Fill(ele.detail('EMShower').etcone20()/ Units.GeV)
                goodeles += [ele]

        # count jets not consisting primarily of an isolated electron
        goodjets = [ jet for jet in jets
                     if not (jet in elejets) and \
                        eta_et_filter(jet,
                                      max_eta=self.jetMaxEta,
                                      min_et =self.jetMinEt) ]
        bjets = [ jet for jet in jets
                     if not (jet in elejets) and \
                     eta_et_filter(jet,max_eta=self.jetMaxEta,min_et =self.jetMinEt) \
                     and jet.getFlavourTagWeight() > self.BtagCut ]

        # count muons
        for muon in muons:
            if eta_et_filter(muon,
                              max_eta=self.leptonMaxEta,
                              min_et =self.leptonMinEt) and muon.isHighPt() and  muon.bestMatch() :
                 goodmuons += [muon]
             
        for mu in goodmuons:
            hsvc['/myoutstream/histos/mu_etcone20'].Fill(mu.parameter(1)/ Units.GeV)

        for tau in taus:
            hsvc['/myoutstream/histos/tau_likelihood'].Fill (tau.tauID().discriminant(TauJetParameters.Likelihood))
            hsvc['/myoutstream/histos/tau_tauellikelihood'].Fill (tau.tauID().discriminant(TauJetParameters.TauElTauLikelihood))
            if eta_et_filter(tau,
                             max_eta=self.leptonMaxEta,
                             min_et =self.leptonMinEt) and tau.tauID().discriminant(TauJetParameters.Likelihood) > 4\
                             and tau.tauID().discriminant(TauJetParameters.TauElTauLikelihood) > 0 :

                goodtaus += [tau]

        for tau in goodtaus:
            hsvc['/myoutstream/histos/tau_pt'].Fill (tau.pt() / Units.GeV)

        leptons = [ i for i in goodeles ] + [ i for i in goodmuons ]
        # sort leptons by decreasing et
        leptons.sort (key=lambda x: -x.et())
        
        # check missing Et
        #metCut = met.et() > self.minMissingEt

        hsvc['/myoutstream/histos/tau_N'].Fill (len(taus))
        hsvc['/myoutstream/histos/taug_N'].Fill (len(goodtaus))
        hsvc['/myoutstream/histos/el_N'].Fill (len(goodeles))
        hsvc['/myoutstream/histos/mu_N'].Fill (len(goodmuons))
        hsvc['/myoutstream/histos/lept_N'].Fill (len(leptons))
        hsvc['/myoutstream/histos/jet_N'].Fill (len(goodjets))
        hsvc['/myoutstream/histos/bjet_N'].Fill (len(bjets))
        hsvc['/myoutstream/histos/miss_et'].Fill (met.et()/ Units.GeV)
        
        if len(goodjets) > 0:
            for i in range(len(goodjets)):
                hsvc['/myoutstream/histos/jet_btag'].Fill (goodjets[i].getFlavourTagWeight())
                hsvc['/myoutstream/histos/jet_pt'].Fill (goodjets[i].pt() / Units.GeV)
                if i == 0:
                    hsvc['/myoutstream/histos/jet1_pt'].Fill (goodjets[i].pt() / Units.GeV)
                if i == 1:
                    hsvc['/myoutstream/histos/jet2_pt'].Fill (goodjets[i].pt() / Units.GeV)
                if i == 2:
                    hsvc['/myoutstream/histos/jet3_pt'].Fill (goodjets[i].pt() / Units.GeV)
                if i == 3:
                    hsvc['/myoutstream/histos/jet4_pt'].Fill (goodjets[i].pt() / Units.GeV)

        # Effective mass
        meff = self.Meff(goodjets, leptons, met.et())
        hsvc['/myoutstream/histos/meff'].Fill (meff / Units.GeV)
        

        if len(bjets) > 0:
            for i in range(len(bjets)):
                hsvc['/myoutstream/histos/bjet_pt'].Fill (bjets[i].pt() / Units.GeV)
                for j in range(len(bjets))[i+1:]:
                    jm= bjets[i].hlv() + bjets[j].hlv()
                    m_bj = jm.m()
                    hsvc['/myoutstream/histos/bjet_m'].Fill (m_bj / Units.GeV)


        # signature for leptonic SUSY decays:
        if len(goodeles)+len(goodmuons) > 0:
           filterPassed = True
        else:
           filterPassed = False
                        
        if not filterPassed:
            return StatusCode.Success  
                       
        # now that event has been selected,
        # make some plots

        # fill histograms
        for i in range(len(leptons)):
            #print 'lep pt ', leptons[i].pt()/Units.GeV,' pdg ', leptons[i].pdgId()
            hsvc['/myoutstream/histos/lept_pt'].Fill (leptons[i].pt() / Units.GeV)
            if i == 0:
                hsvc['/myoutstream/histos/lept1_pt'].Fill (leptons[i].pt() / Units.GeV)
            if i == 1:
                hsvc['/myoutstream/histos/lept2_pt'].Fill (leptons[i].pt() / Units.GeV)
            if i == 2:
                hsvc['/myoutstream/histos/lept3_pt'].Fill (leptons[i].pt() / Units.GeV)

        # finf OSSF / OSOF pairs
        ossf, osof = self.do_mll_reco(leptons)
        
        if len(ossf) > 0:
            for lcomb in ossf:
                l1,l2 = lcomb
                lp= l1.hlv() + l2.hlv()
                m_sf = lp.m()
                hsvc['/myoutstream/histos/ossf_m'].Fill (m_sf / Units.GeV)

        if len(osof) > 0:
            for lcomb in osof:
                l1,l2 = lcomb
                lp= l1.hlv() + l2.hlv()
                m_of = lp.m()
                hsvc['/myoutstream/histos/osof_m'].Fill (m_of / Units.GeV)
            
        
        return StatusCode.Success

    def finalize(self):
        self.msg.info('==> finalize...')
        return StatusCode.Success

    def do_mll_reco (self, lep):
        ossf = []
        osof = []

        if len(lep) > 1:
    
            for i in range(len(lep)):
                for j in range(len(lep))[i+1:]:
                    l1 = lep[i]
                    l2 = lep[j]
                    if abs(l1.pdgId()) != abs(l2.pdgId()) and l1.charge()*l2.charge() < 0.:
                        osof += [ (l1, l2) ]
                    elif abs(l1.pdgId()) == abs(l2.pdgId()) and l1.charge()*l2.charge() < 0.:
                        ossf += [ (l1, l2) ]
                    
        return ossf,osof


    def Meff(self, jet, lep, miss_et):

        mjet = min(4,len(jet))

        meff = 0.
        for i in range(mjet):
            meff += jet[i].pt()

        for i in range(len(lep)):
            meff += lep[i].pt()

        meff += miss_et

        return meff
        
