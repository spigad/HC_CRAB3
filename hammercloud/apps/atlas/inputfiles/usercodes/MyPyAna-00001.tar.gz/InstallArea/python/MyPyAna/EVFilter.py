# @file:    MyPyAna/python/EVFilter.py
# @purpose: <put some purpose here>
# @author:  Katarina Pajchel <katarina.pajchel@fys.uio.no>

__doc__     = 'some documentation here'
__version__ = '$Revision: 1.4 $'
__author__  = 'Katarina Pajchel <katarina.pajchel@fys.uio.no>'

import AthenaCommon.SystemOfUnits as Units
import AthenaPython.PyAthena as PyAthena
from AthenaPython.PyAthena import StatusCode
import ROOT

class EVFilter (PyAthena.Alg):
    'put some documentation here'
    def __init__(self, name='EVFilter', **kw):
        ## init base class
        kw['name'] = name
        super(EVFilter, self).__init__(**kw)


        ## properties and data members
        # handle to the event store
        self.sg = None

        # handle to thist-svc
        self.hsvc = None
        
        ## StoreGate keys
        self.electrons = kw.get('electrons', 'ElectronAODCollection')
        self.missingEt = kw.get('missingEt', 'MET_RefFinal')
        self.jets      = kw.get('jets',      'Cone4H1TowerJets')
        self.muons     = kw.get('muons',     'StacoMuonCollection')
        self.tracks    = kw.get('tracks',    'TrackParticleCandidate')

        # declaration of some cuts which can be set from the joboption file
        ## lepton's cuts
        self.leptonMinEt  = kw.get('leptonMinEt',  10.*Units.GeV)
        self.leptonMaxEta = kw.get('leptonMaxEta', 2.5)

        ## jets' cuts
        self.jetMinEt  = kw.get('jetMinEt',  20.*Units.GeV)
        self.jetMaxEta = kw.get('jetMaxEta', 2.5)

        ## electron/jet isolation cut
        self.minDeltaRlj = kw.get('minDeltaRlj', 0.2)
        self.elIsol = kw.get('elIsol', 10)

        ## muon/jet isolation cut
        self.minDeltaRmj = kw.get('minDeltaRmj', 0.4)
        self.muIsol = kw.get('muIsol', 10)

        # DelraR track/lepton
        self.maxDeltaRtl= kw.get('MaxDeltaRtl', 0.4)
        self.trackMinPt = kw.get('TrackMinPt',  3.*Units.GeV)
        
        ## missing et cut
        self.minMissingEt = kw.get('MinMissingEt', 0.*Units.GeV) 

        ## B-tag cut 
        self.BtagCut = kw.get('BtagCut', 7.05)
        
        self.Nlep = kw.get('Nlep', 1)

        return

    def initialize(self):
        _info = self.msg.info
        _info('==> initialize...')
        
        # retrieve event store
        self.sg = PyAthena.py_svc ('StoreGateSvc')
        if self.sg is None:
            self.msg.error ('could not retrieve event store')
            return StatusCode.Failure

        self.thSvc = PyAthena.py_svc("ThinningSvc")
        if not self.thSvc:
            self.msg.error("Could not retrieve ThinningSvc")
            return StatusCode.Failure

        ## display configuration
        _info("Lepton MinEt:   %r GeV", self.leptonMinEt/Units.GeV)
        _info("Lepton MaxEta:  %r",     self.leptonMaxEta)
        _info("Jets MinEt:     %r GeV", self.jetMinEt/Units.GeV)
        _info("Jets MaxEta:    %r",     self.jetMaxEta)
        _info("Min Missing Et: %r GeV", self.minMissingEt/Units.GeV)

        ## import some 4-mom utils
        import FourMomUtils.Bindings
        self.utils = { 'deltaR' : PyAthena.P4Helpers.deltaR }

        ## event counter
        self._evt_cnt = 0
        ## semi-leptonic filter counter
        self._semi_lept_filter_cnt = 0
        
        return StatusCode.Success

    def execute(self):
        _info = self.msg.info
        self._evt_cnt += 1
        # reject all events by default
        self.setFilterPassed (False)

        # alias...
        _retrieve = self.sg.retrieve
        # retrieve the containers from the event store
        met =  _retrieve ('MissingET',               self.missingEt)
        eles =  _retrieve ('ElectronContainer',       self.electrons)
        jets =  _retrieve ('JetCollection',           self.jets)
        muons = _retrieve ('Analysis::MuonContainer', self.muons)
        tracks =  _retrieve ('Rec::TrackParticleContainer',self.tracks)
                            
        # test that we got all containers
        if not all ([met,eles,jets,muons,tracks]):
            _info ('Failed to retrieve one of the input containers')
            _info ('met,eles,jets,muons: %r', [met,eles,jets,muons,tracks])
            return StatusCode.Success
        

        # local variables
        elejets  = [] # electrons overlapping w/ jets
        goodeles = [] # good electrons
        goodmuons= []
        goodjets = []

        deltaR = self.utils['deltaR']
        # helper filtering function
        def eta_et_filter (o, max_eta, min_et):
            return abs (o.eta()) < max_eta and \
                   o.et() > min_et

        # Different ways of getting isemmask
        # if ec[i].isem(ROOT.egammaPID.ElectronLoose)==0
        import PyCintex
        egdict = PyCintex.loadDict("egammaEventDict")
        #isEMmask = getattr(PyAthena.egammaPID, 'ElectronLoose')
        isEMmask = getattr(PyAthena.egammaPID, 'ElectronMedium')
        #isEMmask = getattr(PyAthena.egammaPID, 'ElectronTight')
        
        for ele in eles:
            if not (ele.author(1) and ele.isem(isEMmask)==0 and ele.detail('EMShower').etcone20()/ Units.GeV < 10.):
                continue

            for jet in jets:
                dRej = deltaR (ele, jet)
                if dRej < self.minDeltaRlj and jet.et() < 2*ele.et():
                     elejets += [jet]

            if eta_et_filter(ele,
                             max_eta=self.leptonMaxEta,
                             min_et =self.leptonMinEt) :
                goodeles += [ele]

        goodjets = [ jet for jet in jets
                     if not (jet in elejets) and \
                             eta_et_filter(jet, max_eta=self.jetMaxEta, min_et =self.jetMinEt) ]

        for muon in muons:
            if eta_et_filter(muon,
                              max_eta=self.leptonMaxEta,
                              min_et =self.leptonMinEt) and muon.isHighPt() and \
                              muon.bestMatch() and \
                              muon.parameter(1)/ Units.GeV < 10:
                dRsep = True
                for j in goodjets:
                    dRmj = deltaR (muon, j)
                    if dRmj < self.minDeltaRmj:
                        dRsep = False
                        
                if dRsep:    
                    goodmuons += [muon]

        eletmp = []
        for el in goodeles:
            dRsep = True
            for j in goodjets:
                dRej = deltaR (el, j)
                if dRej < self.minDeltaRmj:
                    dRsep = False
                    
            if dRsep:
                eletmp += [el]
    
        goodeles = eletmp

        # good muons
        goodmuons = [ muon for muon in muons
                      if eta_et_filter(muon,
                                       max_eta=self.leptonMaxEta,
                                       min_et =self.leptonMinEt) ]
            
        # check missing Et
        metCut = met.et() > self.minMissingEt

        #  Events Skimming - filter decision
        # Keep events with loose leptons        
        filterPassed = ( (len(goodeles)+len(goodmuons)) > self.Nlep )
        self.setFilterPassed (filterPassed)

        if not filterPassed:
            return StatusCode.Success
        
        self._semi_lept_filter_cnt += 1

        # Electron Thinning    
        def electron_filter(el):
            return el in goodeles
       
        ele_mask = [ electron_filter(e) for e in eles ]
        
        if self.thSvc.filter(eles, ele_mask) != StatusCode.Success:
            _info('Problem thinning electrons !')
       
       # Muon Thinning    
        def muon_filter(mu):
            return mu in goodmuons
       
        muon_mask = [ muon_filter(m) for m in muons ]
        
        if self.thSvc.filter(muons, muon_mask) != StatusCode.Success:
            _info('Problem thinning muons !')

        # Track thinning

        if not tracks:
            self.msg.info('Could not retrieve tracks at [%r]', self.tracksName)
            return StatusCode.Success

        goodtracks = []

        for el in goodeles:
            goodtracks += [ track for track in tracks
                            if deltaR(track,el) < self.maxDeltaRtl ]

        for mu in goodmuons:
            goodtracks += [ track for track in tracks
                            if deltaR(track,mu) < self.maxDeltaRtl ]
        
        # remove duplicates
        goodtracks = set(goodtracks)

        track_mask = [ True if track in goodtracks else False \
                       for track in tracks ]
        if self.thSvc.filter(tracks, track_mask) != StatusCode.Success:
            _info("Problem while thinning tracks")

        ## -- slim tracks ---
        for track in goodtracks:
            if track.pt() < self.trackMinPt:
                track.removeSummary()
                track.removeErrorMatrix()
       
        return StatusCode.Success

    def finalize(self):
        self.msg.info('==> finalize...')

        eff = self._semi_lept_filter_cnt/self._evt_cnt
        self.msg.info ('nbr evts passed semi-leptonic ttbar filter: %r/%r  efficiency %r',
                       self._semi_lept_filter_cnt,
                       self._evt_cnt,
                       eff)
        
        return StatusCode.Success

    # class EVFilter
