{

  Cintex::Enable();
  gSystem->Load("libMathCore");
  gSystem->Load("libUserAnalysisEventDict");
  gSystem->Load("libUserAnalysisEvent");
  gSystem->SetIncludePath("-I/afs/cern.ch/user/k/ketevi/public/analysis/rel_5/PhysicsAnalysis/AnalysisCommon/UserAnalysisEvent");
  TFile * file = TFile::Open("SAN.root");
  TTree * tree = (TTree*)gDirectory->Get("CollectionTree");
  tree->Process("AnalysisSkeleton.C+");
}
