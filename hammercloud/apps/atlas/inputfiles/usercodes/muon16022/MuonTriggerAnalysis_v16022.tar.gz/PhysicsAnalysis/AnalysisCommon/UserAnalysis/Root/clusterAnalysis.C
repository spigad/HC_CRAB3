#include <sstream>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <vector>

#include "TSystem.h"
#include "TTree.h"
#include "TBranch.h"
#include "TString.h"
#include "TCanvas.h"
#include "TKey.h"
#include "TFile.h"
#include "TClassTable.h"
#include "TStopwatch.h"

#include "UserAnalysisEvent/CaloClusterMomentStore.h"
#include "UserAnalysisEvent/CaloSampling.h"
#include "UserAnalysisEvent/CaloRecoStatus.h"
#include "UserAnalysisEvent/CaloCluster.h"

using namespace User;

void clusterAnalysis () {

  TFile *  f = new TFile("SAN.root");
  TTree *  tree = (TTree*)gDirectory->Get("CollectionTree");

  std::vector<CaloCluster> * pCaloCalTopoCluster=0;
  tree->SetBranchAddress("CaloCalTopoCluster",&pCaloCalTopoCluster);
  TBranch * clusCaloCalTopoClusterBranch = tree->GetBranch("CaloCalTopoCluster");

  Long64_t nentries = tree->GetEntriesFast();
  int nbytes = 0; 
  int nb = 0;
  
  for (Long64_t jentry=0; jentry<nentries;jentry++) {

    std::cout << "Event Number = " << (jentry+1) << std::endl;
    std::cout << " " << std::endl;

    /** Read the Topo clusters */
    nb = clusCaloCalTopoClusterBranch->GetEntry(jentry);  nbytes += nb;

    /** Loop over the TopoClusters and do something */
    std::vector<CaloCluster>::const_iterator clusItr  = pCaloCalTopoCluster->begin();
    std::vector<CaloCluster>::const_iterator clusItrE = pCaloCalTopoCluster->end();
    for (; clusItr != clusItrE; ++clusItr) {

      std::cout << "TopoCluster e()   = " <<  (*clusItr).e() << std::endl;
      std::cout << "Topocluster eta() = " <<  (*clusItr).eta() << std::endl;
      
      /** Access to TopoCluster Moment */
      CaloCluster::moment_iterator mBegin = (*clusItr).beginMoment();
      CaloCluster::moment_iterator mEnd   = (*clusItr).endMoment();

      for (; mBegin != mEnd; ++mBegin) {
         double momentValue = mBegin.getMoment().getValue();
         CaloClusterMomentStore::moment_type type = mBegin.getMomentType();
         std::cout << "MomentType and MomentValue = " << type << " " << momentValue << std::endl;
      } 

      /** Access to Sampling variables */
      for (int i=0; i<CaloVariableType::NO_OF_TYPES; ++i) {
        std::vector<double> varData;
        if ( (*clusItr).getVariable(static_cast<CaloVariableType::VariableType>(i),varData,false) ) {
          std::cout << "Sampling Variable " << static_cast<CaloVariableType::VariableType>(i) << std::endl;
          for (unsigned int i=0; i<varData.size(); ++i) std::cout << "Sampling Data = " << varData[i] << std::endl;
        }

        const CaloRecoStatus recoStatus = (*clusItr).getRecoStatus();
        std::vector<CaloRecoStatus::StatusIndicator> statusList;
        bool status = recoStatus.getStatus(statusList);
        if (status) 
          for (unsigned int i=0; i< statusList.size(); ++i) 
            std::cout << "Reco Status = " << i << " " << std::hex << statusList[i] << std::endl;
      }

      std::cout << " " << std::dec << std::endl;
    }
    std::cout << "------------------------------------- " << std::endl;
  }
  
  f->Close();
  
  return;
  
}
