#export ROOTSYS=/afs/cern.ch/sw/lcg/external/root/5.13.04/slc3_ia32_gcc323/root
export ROOTSYS=/afs/cern.ch/sw/lcg/external/root/5.10.00e/slc3_ia32_gcc323/root
export LD_LIBRARY_PATH=$ROOTSYS/lib:$LD_LIBRARY_PATH
export PATH=$ROOTSYS/bin:$PATH
export LD_LIBRARY_PATH=/afs/cern.ch/user/k/ketevi/public/analysis/rel_5/PhysicsAnalysis/AnalysisCommon/UserAnalysisEvent/i686-slc3-gcc323-opt:$LD_LIBRARY_PATH
export PATH=/afs/cern.ch/user/k/ketevi/public/analysis/rel_5/PhysicsAnalysis/AnalysisCommon/UserAnalysisEvent/i686-slc3-gcc323-opt:$PATH

