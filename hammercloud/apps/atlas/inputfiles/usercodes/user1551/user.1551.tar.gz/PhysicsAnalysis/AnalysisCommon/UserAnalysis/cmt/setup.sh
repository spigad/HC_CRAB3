# echo "Setting UserAnalysis UserAnalysis-00-14-00 in /home/elmsheus/testarea/15.5.1/PhysicsAnalysis/AnalysisCommon"

if test "${CMTROOT}" = ""; then
  CMTROOT=/opt/atlas/software/15.5.1/15.5.1/CMT/v1r20p20090520; export CMTROOT
fi
. ${CMTROOT}/mgr/setup.sh

tempfile=`${CMTROOT}/mgr/cmt -quiet build temporary_name`
if test ! $? = 0 ; then tempfile=/tmp/cmt.$$; fi
${CMTROOT}/mgr/cmt setup -sh -pack=UserAnalysis -version=UserAnalysis-00-14-00 -path=/home/elmsheus/testarea/15.5.1/PhysicsAnalysis/AnalysisCommon  -no_cleanup $* >${tempfile}; . ${tempfile}
/bin/rm -f ${tempfile}

