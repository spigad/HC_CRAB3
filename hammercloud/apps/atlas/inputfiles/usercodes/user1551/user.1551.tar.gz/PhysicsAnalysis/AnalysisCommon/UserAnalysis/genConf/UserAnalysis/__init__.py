## Hook for UserAnalysis genConf module
