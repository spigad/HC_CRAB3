#Fri Oct 23 11:45:05 2009
"""Automatically generated. DO NOT EDIT please"""
from GaudiKernel.GaudiHandles import *
from GaudiKernel.Proxy.Configurable import *

class AnalysisSkeleton( ConfigurableAlgorithm ) :
  __slots__ = { 
    'OutputLevel' : 0, # int
    'Enable' : True, # bool
    'ErrorMax' : 1, # int
    'ErrorCount' : 0, # int
    'AuditAlgorithms' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditReinitialize' : False, # bool
    'AuditRestart' : False, # bool
    'AuditExecute' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditBeginRun' : False, # bool
    'AuditEndRun' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'MonitorService' : 'MonitorSvc', # str
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'StreamName' : 'AANT', # str
    'TreeName' : 'CollectionTree', # str
    'AnalysisTools' : PublicToolHandle('AnalysisTools'), # GaudiHandle
    'AnalysisSelectionTool' : PublicToolHandle('UserAnalysisSelectionTool'), # GaudiHandle
    'AnalysisPreparationTool' : PublicToolHandle('UserAnalysisPreparationTool'), # GaudiHandle
    'AnalysisOverlapCheckingTool' : PublicToolHandle('UserAnalysisOverlapCheckingTool'), # GaudiHandle
    'AnalysisOverlapRemovalTool' : PublicToolHandle('UserAnalysisOverlapRemovalTool'), # GaudiHandle
    'TrigDecisionTool' : PublicToolHandle('Trig::TrigDecisionTool'), # GaudiHandle
    'ElectronContainer' : 'ElectronAODCollection', # str
    'McParticleContainer' : 'SpclMC', # str
    'MissingETObject' : 'MET_RefFinal', # str
    'DeltaRMatchCut' : 0.2, # float
    'MaxDeltaR' : 0.9999, # float
    'ElectronEtCut' : 10000.0, # float
    'ElectronEtaCut' : 2.5, # float
    'ElectronCone' : 0.9, # float
    'bjetWt_IP3DSV1Cut' : 6.0, # float
    'bjet_etaCut' : 2.5, # float
    'bjet_etCut' : 15000.0, # float
    'MissingETCut' : 20000.0, # float
    'IsAtlFastData' : True, # bool
    'SusyJetMinEt' : 50000.0, # float
    'DoTrigger' : True, # bool
  }
  _propertyDocDct = { 
    'DoTrigger' : """ enable trigger example """,
    'TrigDecisionTool' : """ The tool to access TrigDecision """,
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(AnalysisSkeleton, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'UserAnalysis'
  def getType( self ):
      return 'AnalysisSkeleton'
  pass # class AnalysisSkeleton
