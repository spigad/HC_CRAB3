#Mon Sep  7 09:04:42 2009
"""Automatically generated. DO NOT EDIT please"""
from GaudiKernel.GaudiHandles import *
from GaudiKernel.Proxy.Configurable import *

class AnalysisSkeleton( ConfigurableAlgorithm ) :
  __slots__ = { 
    'OutputLevel' : 0, # int
    'Enable' : True, # bool
    'ErrorMax' : 1, # int
    'ErrorCount' : 0, # int
    'AuditAlgorithms' : False, # bool
    'AuditInitialize' : False, # bool
    'AuditReinitialize' : False, # bool
    'AuditRestart' : False, # bool
    'AuditExecute' : False, # bool
    'AuditFinalize' : False, # bool
    'AuditBeginRun' : False, # bool
    'AuditEndRun' : False, # bool
    'AuditStart' : False, # bool
    'AuditStop' : False, # bool
    'MonitorService' : 'MonitorSvc', # str
    'EvtStore' : ServiceHandle('StoreGateSvc'), # GaudiHandle
    'DetStore' : ServiceHandle('StoreGateSvc/DetectorStore'), # GaudiHandle
    'StreamName' : 'AANT', # str
    'TreeName' : 'CollectionTree', # str
    'AnalysisTools' : PrivateToolHandle('AnalysisTools'), # GaudiHandle
    'MCParticleContainer' : 'SpclMC', # str
    'DeltaRMatchCut' : 0.5, # float
    'DeltaRMatchCutLOW' : 0.5, # float
    'DeltaRMatchCutL1' : 0.5, # float
    'MaxDeltaR' : 0.9999, # float
    'PlateauStep' : 5000.0, # float
    'doMCTruth' : True, # bool
    'doTrigDec' : False, # bool
    'TrigDecisionTool' : PublicToolHandle('TrigDec::TrigDecisionTool'), # GaudiHandle
  }
  _propertyDocDct = { 
    'TrigDecisionTool' : """ The tool to access TrigDecision """,
    'EvtStore' : """ Handle to a StoreGateSvc instance: it will be used to retrieve data during the course of the job """,
    'DetStore' : """ Handle to a StoreGateSvc/DetectorStore instance: it will be used to retrieve data during the course of the job """,
  }
  def __init__(self, name = Configurable.DefaultName, **kwargs):
      super(AnalysisSkeleton, self).__init__(name)
      for n,v in kwargs.items():
         setattr(self, n, v)
  def getDlls( self ):
      return 'UserAnalysis'
  def getType( self ):
      return 'AnalysisSkeleton'
  pass # class AnalysisSkeleton
